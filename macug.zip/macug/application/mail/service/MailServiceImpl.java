/*    */ package com.bsf.macug.application.mail.service;
/*    */ 
/*    */ import com.bsf.macug.application.mail.dto.MailServerDTO;
/*    */ import com.bsf.macug.mt101.entity.MacPaymentDetail;
/*    */ import com.bsf.macug.util.InterUtils;
/*    */ import java.io.StringWriter;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ import java.util.Set;
/*    */ import javax.mail.MessagingException;
/*    */ import javax.mail.internet.InternetAddress;
/*    */ import javax.mail.internet.MimeMessage;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.apache.velocity.VelocityContext;
/*    */ import org.apache.velocity.app.VelocityEngine;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.mail.javamail.JavaMailSenderImpl;
/*    */ import org.springframework.mail.javamail.MimeMessageHelper;
/*    */ import org.springframework.stereotype.Service;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Service
/*    */ public class MailServiceImpl
/*    */   implements InterMailService
/*    */ {
/* 28 */   private static final Logger logger = Logger.getLogger(MailServiceImpl.class.getName());
/*    */   
/*    */   @Autowired
/*    */   InterUtils utils;
/*    */   
/*    */   public boolean sendMailToKondor(MacPaymentDetail details)
/*    */   {
/* 35 */     boolean status = false;
/*    */     try {
/* 37 */       MailServerDTO mailDto = this.utils.getMailDTO();
/* 38 */       logger.info("mailDto : " + mailDto.toString());
/* 39 */       JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
/* 40 */       mailSender.setHost(mailDto.getMailHost());
/* 41 */       mailSender.setPort(mailDto.getMailPort().intValue());
/*    */       
/* 43 */       MimeMessage mimeMessage = mailSender.createMimeMessage();
/* 44 */       MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true, "UTF-8");
/* 45 */       VelocityEngine ve = new VelocityEngine();
/* 46 */       Properties p = new Properties();
/* 47 */       p.put("resource.loader", "class");
/* 48 */       p.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
/*    */       
/* 50 */       ve.init(p);
/*    */       
/* 52 */       VelocityContext vc = new VelocityContext();
/* 53 */       Map<String, Object> dataMap = new HashMap();
/* 54 */       dataMap.put("tradeDate", details.getTradeDate());
/* 55 */       dataMap.put("amount", details.getTransactionAmount());
/* 56 */       dataMap.put("amount2", details.getDebitAmount());
/* 57 */       dataMap.put("valueDate", details.getValueDate());
/* 58 */       dataMap.put("valueDateIslamic", details.getValueDate());
/* 59 */       dataMap.put("ref", details.getTransactionReference());
/* 60 */       dataMap.put("correspReceiveAcct", details.getDebitAccount());
/* 61 */       dataMap.put("correspPaytoAcct", details.getBeneficiaryInfo59());
/* 62 */       dataMap.put("correspPayfromAcct", details.getDebitAccount());
/* 63 */       dataMap.put("cpt", "");
/* 64 */       dataMap.put("currencies", details.getCurrency());
/*    */       
/* 66 */       vc.put("map", dataMap);
/* 67 */       StringWriter sw = new StringWriter();
/* 68 */       ve.mergeTemplate("/templates/KONDOR_FORMAT.vm", "UTF-8", vc, sw);
/*    */       
/* 70 */       InternetAddress[] address = { new InternetAddress(mailDto.getMailTo()) };
/* 71 */       message.setTo(address);
/*    */       
/* 73 */       Set<String> ccIds = mailDto.getMailCC();
/* 74 */       if ((ccIds != null) && (ccIds.size() > 0)) {
/* 75 */         InternetAddress[] ccAddress = new InternetAddress[ccIds.size()];
/* 76 */         int i = 0;
/* 77 */         for (String email : ccIds) {
/* 78 */           ccAddress[i] = new InternetAddress(email);
/* 79 */           i++;
/*    */         }
/* 81 */         message.setCc(ccAddress);
/*    */       }
/*    */       
/* 84 */       message.setSubject(mailDto.getMailSubject());
/* 85 */       message.setFrom(mailDto.getMailFrom());
/* 86 */       logger.info("text : ");
/* 87 */       logger.info(sw.toString());
/* 88 */       message.setText(sw.toString());
/* 89 */       mailSender.send(message.getMimeMessage());
/* 90 */       status = true;
/*    */     } catch (MessagingException e) {
/* 92 */       logger.error("Error : " + e.getMessage(), e);
/*    */     } catch (Exception e) {
/* 94 */       logger.error("Error : " + e.getMessage(), e);
/*    */     }
/*    */     
/* 97 */     return status;
/*    */   }
/*    */ }


/* Location:              D:\MT101Code\MT101.jar!\BOOT-INF\classes\com\bsf\macug\application\mail\service\MailServiceImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */