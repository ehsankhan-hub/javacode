package com.bsf.macug.application.mail.service;

import com.bsf.macug.mt101.entity.MacPaymentDetail;

public abstract interface InterMailService
{
  public abstract boolean sendMailToKondor(MacPaymentDetail paramMacPaymentDetail);
}
