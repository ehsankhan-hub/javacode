package com.bsf.macug.application.pool;

import java.io.IOException;
import java.util.HashSet;

import org.json.simple.JSONObject;

public interface SocketPool {
	Connection getSocketConnection() throws IOException, InterruptedException;
	long getExpirationTimeout();
	void notifyConnectionStateChanged();
	void resetConnections();
	JSONObject getConnectionPoolStatus();
	void resetManually() throws Throwable;
	HashSet getConnections();
}
