package com.bsf.macug.application.pool;

import java.io.IOException;
import java.net.Socket;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

public class Connection {

	private static final Logger logger = Logger.getLogger(Connection.class);
	static class Reaper {
        private final HashSet connections = new HashSet();
        private final Reap reap = new Reap();
        private volatile long sleepTime = Long.MAX_VALUE;
        private Thread thread;

        class Reap implements Runnable {
            public void run() {
                do {
                    try {
                        Thread.sleep(sleepTime);
                    } catch (InterruptedException e) {}
                } while (doReap());
            }

            private boolean doReap() {
                boolean result = true;
                long currentTime = System.currentTimeMillis();
                List connToClose = new ArrayList();
                synchronized (Reaper.this) {
                    for (Iterator iter = connections.iterator(); iter.hasNext();) {
                        Connection conn = (Connection)iter.next();
                        if (conn.getCloseTime() > currentTime) continue;
                        switch (conn.acquire()) {
                            case USED:
                            case CLOSED:
                                break;
                            case READY:
                                connToClose.add(conn);
                        }
                        iter.remove();
                    }
                    if (connections.isEmpty()) {
                        thread = null;
                        result = false;
                    }
                }
                for (Iterator iter = connToClose.iterator(); iter.hasNext();) {
                    Connection conn = (Connection)iter.next();
                    logger.info("Closing Connection for Port:"+conn.socket.getLocalPort());
                    conn.close();
                }
                return result;
            }
        }
        void registerConnection(Connection conn, long closeDelay) {
            if (conn.isClosed()) {
                return;
            }
            synchronized (this) {
                connections.add(conn);
                if (closeDelay < sleepTime) {
                    sleepTime = closeDelay;
                }
                if (thread == null) {
                    thread = (Thread)AccessController.doPrivileged(new PrivilegedAction() {
                        public Object run() {
                            Thread thread = new Thread(reap, "Reaper");
                            thread.setDaemon(true);
                            thread.start();
                            return thread;
                        }
                    });
                }
            }
        }
    }

    static final byte USED = -1, CLOSED = 0, READY = 1;
    static final Reaper reaper = new Reaper();
    final SocketPool pool;
    final Socket socket;
    long expires = -1;
    Connection(Socket socket, SocketPool pool) {
        this.socket = socket;
        this.pool = pool;
    }
    public void returnToPool() {
        release(System.currentTimeMillis() + pool.getExpirationTimeout());
        pool.getConnections().add(this);
        Connection.reaper.registerConnection(this, pool.getExpirationTimeout());
        pool.notifyConnectionStateChanged();
    }
    public void close() {
        try {
            socket.close();
            logger.info("|Disconnected "+  socket.getInetAddress().getHostAddress() + " on " +  socket.getPort()+"|");
        } catch (IOException e) {}
        pool.notifyConnectionStateChanged();
    }
    public synchronized Socket getSocket() {
        return socket;
    }
    synchronized byte acquire() {
        if (socket.isClosed()) {
            return CLOSED;
        } else if (expires == -1) {
            return USED;
        }
       // expires = -1;
        return READY;
    }
    synchronized void release(long closeTime) {
    	logger.info(closeTime + " : Disconnected Start : "+ socket.isClosed());
        if (socket.isClosed()) {
            return;
        }
        else if (expires == -1) {
            expires = closeTime;
        }
        else {
            throw new IllegalStateException("Not currently used");
        }
    }

    synchronized long getCloseTime() {
        return expires;
    }

    synchronized boolean isClosed() {
        return socket.isClosed();
    }

    synchronized boolean isUsed() {
        return expires == -1;
    }
	public long getExpires() {
		return expires;
	}
	public void setExpires(long expires) {
		this.expires = expires;
	}
    
    
}
