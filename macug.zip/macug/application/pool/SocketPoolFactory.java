package com.bsf.macug.application.pool;

import org.apache.log4j.Logger;


public class SocketPoolFactory {

	private static final Logger logger = Logger.getLogger(SocketPoolFactory.class);
	
	private volatile static SocketPoolImpl socketPoolFactory;
	
	public static SocketPool getSocketPool(String ftsServer,String ftsPort,long expirationTimeout, int capacity){
		logger.info("(getSocketPool) ==> "+socketPoolFactory);
		if (socketPoolFactory == null) {
			synchronized (SocketPoolImpl.class) {
				if (socketPoolFactory == null) {
					try{
		                logger.info("|Connected "+ ftsServer + " on " + ftsPort+"|");
						String portsList = ftsPort;
						String ports[] = portsList.split(",");
						int port[] = new int[ports.length];
						for (int i = 0; i < ports.length; i++) {

							port[i]=new Integer(ports[i]);
						}
						socketPoolFactory = new SocketPoolImpl(ftsServer, port,expirationTimeout, capacity);
						}catch(Exception e){
							logger.error(e.getMessage(),e);
						}
				}
			}
		}
		return socketPoolFactory;
	}
	
}
