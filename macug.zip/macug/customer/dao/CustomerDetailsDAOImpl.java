package com.bsf.macug.customer.dao;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.exception.DataAccessException;

@Repository("customerDetailsDao")
public class CustomerDetailsDAOImpl implements InterCustomerDetailsDAO {
	private static final Logger logger = Logger
			.getLogger(CustomerDetailsDAOImpl.class.getName());

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public CustomerDetails getCustomerDetails(String customerId, String status) throws CustomerNotFoundException {
		CustomerDetails client = null;
		Session session = null;
		logger.info("(getCustomerDetails)==> Search by customer ID "+customerId);
		if(!StringUtils.isEmpty(customerId)){
			status = (StringUtils.isEmpty(status))?"ACTIVE":status;
			try {
				session = sessionFactory.getCurrentSession();
				Criteria criteria = session.createCriteria(CustomerDetails.class);
				criteria.add(Restrictions.eq("customerId", customerId));
				criteria.add(Restrictions.eq("customerStatus", status));
				client = (CustomerDetails) criteria.uniqueResult();
			} catch (Exception e) {
				logger.error("(getCustomerDetails)==> Error in getting customer details. Error "+e.getMessage(), e);
				throw new CustomerNotFoundException("Customer is not registered or invalid.");
			}
		}else{
			logger.info("(getCustomerDetails)==> Customer id cannot be null or empty");
			throw new CustomerNotFoundException("Customer is not registered or invalid.");
		}
		return client;
	}

	@Override
	public boolean updateCustomerDetails(CustomerDetails details)
			throws DataAccessException {
		Session session = null;
		boolean status = false;
		try {
			logger.info("(updateCustomerDetails)==> updateCustomerDetails STARTED");
			session = sessionFactory.getCurrentSession();
			session.update(details);
			status = true;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new DataAccessException("Error ehile saving custmer details");
		}
		logger.info("(updateCustomerDetails)==>  updateCustomerDetails STARTED END");
		return status;
	}
}
