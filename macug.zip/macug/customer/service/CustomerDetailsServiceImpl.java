package com.bsf.macug.customer.service;

import java.util.Map;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.dao.InterCustomerDetailsDAO;
import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.exception.SystemPropertyNotConfigurationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;

@Service("customerDetailsService")
@Transactional
public class CustomerDetailsServiceImpl implements InterCustomerDetailsService {

	private static final Logger logger = Logger
			.getLogger(CustomerDetailsServiceImpl.class.getName());
	
	@Autowired
	InterCustomerDetailsDAO customerDetailsDao;
	
	@Autowired
	InterSystemParameterService systemParameterService;

	@Override
	public CustomerDetails getCustomerDetails(String clientId) throws CustomerNotFoundException {
		CustomerDetails customerDetails = null;
		if(!StringUtils.isEmpty(clientId)){
			Map<String, SystemParameters> mpCustomerCode =null;
			String strCustStatus = "ACTIVE";
			try {
				try {
					mpCustomerCode = systemParameterService.getSystemParametersByTableCode("CUSSTSCOD");
				} catch (SystemPropertyNotConfigurationException e) {
					logger.error("(getCustomerDetails)==> CUSSTSCOD table is not configured");
					throw new CustomerNotFoundException("Customer is not registered or invalid");
				}
				if(mpCustomerCode!=null){
					strCustStatus = systemParameterService.getSystemParametersDescription1("ACTIVE", mpCustomerCode);
				}
				strCustStatus =(StringUtils.isEmpty(strCustStatus))?"ACTIVE":strCustStatus;
				customerDetails = customerDetailsDao.getCustomerDetails(clientId, strCustStatus);
			} catch (CustomerNotFoundException e) {
				logger.error("(getCustomerDetails)==> Customer not found. Error occured "+e.getMessage(), e);
				throw new CustomerNotFoundException("Customer is not registered or invalid");
			}
		}else{
			logger.info("(getCustomerDetails)==> Customer details cannot be null or empty. Customer is "+clientId);
			throw new CustomerNotFoundException("Customer is not registered or invalid");
		}
		return customerDetails;
	}
	
	@Override
	public boolean updateCustomer(CustomerDetails customerDetails){
		boolean status = false;
		try {
			status = customerDetailsDao.updateCustomerDetails(customerDetails);
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
		}
		return status;
	}
}
