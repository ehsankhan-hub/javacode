package com.bsf.macug.customer.service;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.exception.CustomerNotFoundException;

public interface InterCustomerDetailsService {
	CustomerDetails getCustomerDetails(String clientId)  throws CustomerNotFoundException;

	boolean updateCustomer(CustomerDetails customerDetails);
}
