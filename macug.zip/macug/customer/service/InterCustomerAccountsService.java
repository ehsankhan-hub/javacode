package com.bsf.macug.customer.service;

import java.util.List;

import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.exception.AccountsNotFoundException;
import com.bsf.macug.exception.ProcessException;

public interface InterCustomerAccountsService {
	CustomerAccounts getCustomerAccountDetails(String clientId,
			String accountNumber, String accountService) throws ProcessException;

	List<CustomerAccounts> listAllActiveAccounts(String strCustomer,
			String string)throws AccountsNotFoundException;

	Integer getSequenceByAccount(String companyCode, String strAccount);
}
