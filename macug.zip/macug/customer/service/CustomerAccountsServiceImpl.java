package com.bsf.macug.customer.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.dao.InterCustomerAccountsDAO;
import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.exception.AccountsNotFoundException;
import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.exception.ProcessException;

@Service("customerAccountsService")
@Transactional
public class CustomerAccountsServiceImpl implements InterCustomerAccountsService{

	private final Logger logger = Logger.getLogger(CustomerAccountsServiceImpl.class.getName());
	
	@Autowired
	InterCustomerAccountsDAO customerAccountsDao;
	
	@Override
	public CustomerAccounts getCustomerAccountDetails(String clientId,
			String accountNumber, String accountService) throws ProcessException {
		CustomerAccounts customerAccount = null;
		logger.info("(getCustomerAccountDetails)==> Trying to find customer account : " + clientId+" : "+ accountNumber+" : "+accountService);
		if(!(StringUtils.isEmpty(clientId) && StringUtils.isEmpty(accountNumber) && StringUtils.isEmpty(accountService))){
			try {
				customerAccount = customerAccountsDao.getCustomerAccountDetails(clientId, accountNumber, accountService);	
			} catch (DataAccessException de) {
				logger.error("Error in fetching customer account details . Error "+de.getMessage(), de);
				throw new ProcessException("Cannot found account for service ");
			}
		}else{
			logger.info("(getCustomerAccountDetails)==> Account search information is null or empty");
		}
		return customerAccount;
	}

	@Override
	public List<CustomerAccounts> listAllActiveAccounts(String strCustomer, String strService) throws AccountsNotFoundException {
		List<CustomerAccounts> lstAccounts = null;
		if(!(StringUtils.isEmpty(strCustomer) && StringUtils.isEmpty(strService))){
			try {
				lstAccounts = customerAccountsDao.listAllActiveAccounts(strCustomer, strService);
			} catch (Exception e) {
				logger.error("Error in fetching customer account list. Error "+e.getMessage(), e);
				throw new AccountsNotFoundException("Cannot found accounts");
			}
		}else{
			throw new AccountsNotFoundException("Cannot found accounts");
		}
		return lstAccounts;
	}
	
	
	@Override
	public Integer getSequenceByAccount(String companyCode,String strAccount) {
		Integer sequence = null;
		try {		
			
			if(!(StringUtils.isEmpty(companyCode) && !(StringUtils.isEmpty(strAccount)))){
				
				sequence = customerAccountsDao.getSequenceByAccount(companyCode,strAccount);
				
			}
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(),e);
		}
		if(sequence == null) {
			sequence = 1;
		}
		return sequence;
		
		
	}
	
	

}
