package com.bsf.macug.customer.service;

import java.math.BigDecimal;
import java.util.Date;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsf.macug.customer.dao.InterCustomerLimitsDAO;
import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.entity.CustomerLimits;

@Service("customerLimitsService")
@Transactional
public class CustomerLimitsServiceImpl implements InterCustomerLimitsService {

	private static final Logger logger = Logger.getLogger(CustomerLimitsServiceImpl.class.getName());

	@Autowired
	InterCustomerLimitsDAO customerLimitsDao;

	@Override
	public boolean insertData(CustomerDetails customerDetails, Date valueDate) {
		boolean status = false;
		try {
			CustomerLimits customerNewLimits = new CustomerLimits();
			customerNewLimits.setCustomerId(customerDetails.getCustomerId());
			customerNewLimits.setValueDate(valueDate);
			customerNewLimits.setLimitsCreated(new Date());

			status = customerLimitsDao.saveLimitDetails(customerNewLimits);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public boolean updateData(CustomerLimits limits) {
		boolean status = false;
		try {
			limits.setModifiedId("SYSTEM");
			limits.setModifiedDate(new Date());
			status = customerLimitsDao.updateLimitDetails(limits);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public CustomerLimits getData(String customerId, Date valueDate) {
		CustomerLimits limits = null;
		try {
			limits = customerLimitsDao.getCustomerLimits(customerId, valueDate);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return limits;
	}

	@Override
	public CustomerLimits getData(String customerId, Date valueDate, String account) {
		CustomerLimits limits = null;
		try {
			limits = customerLimitsDao.getCustomerLimits(customerId, valueDate, account);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return limits;
	}

	@Override
	public boolean insertData(CustomerDetails customerDetails, Date valueDate, CustomerAccounts accountInfo) {
		boolean status = false;
		try {
			CustomerLimits customerNewLimits = new CustomerLimits();
			customerNewLimits.setCustomerId(customerDetails.getCustomerId());
			customerNewLimits.setValueDate(valueDate);
			customerNewLimits.setAccountNumber(accountInfo.getAccountNumber());
			customerNewLimits.setLimitsCreated(new Date());
			customerNewLimits.setAvailableBSFLimit(new BigDecimal(accountInfo.getAccountTransferLimit()));
			status = customerLimitsDao.saveLimitDetails(customerNewLimits);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;

	}

}
