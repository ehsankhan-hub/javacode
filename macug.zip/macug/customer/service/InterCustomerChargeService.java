package com.bsf.macug.customer.service;

import java.math.BigDecimal;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.exception.ProcessException;

public interface InterCustomerChargeService {
	BigDecimal getCharge(String customerId,String services,String paymnetType) throws ProcessException, DataAccessException ;
}
