package com.bsf.macug.customer.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "MAC_CUST_LIMITS")
public class CustomerLimits implements Serializable {
	@Id
	@Column(name = "CUST_ID")
	private String customerId;
	@Id
	@Column(name = "LIMITS_VALUEDATE")
	@Temporal(TemporalType.DATE)
	private Date valueDate;

	@Id
	@Column(name = "ACCOUNT_NUMBER")
	private String accountNumber;


	@Column(name = "LIMITS_BSF_AVAILABLE")
	private BigDecimal availableBSFLimit;

	@Column(name = "LIMITS_CREATED")
	@Temporal(TemporalType.TIMESTAMP)
	private Date limitsCreated;

	@Column(name = "MODIFIED_ID")
	private String modifiedId;

	@Column(name = "MODIFIED_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public CustomerLimits() {
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Date getValueDate() {
		return valueDate;
	}

	public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public BigDecimal getAvailableBSFLimit() {
		return availableBSFLimit;
	}

	public void setAvailableBSFLimit(BigDecimal availableBSFLimit) {
		this.availableBSFLimit = availableBSFLimit;
	}

	public Date getLimitsCreated() {
		return limitsCreated;
	}

	public void setLimitsCreated(Date limitsCreated) {
		this.limitsCreated = limitsCreated;
	}

	public String getModifiedId() {
		return modifiedId;
	}

	public void setModifiedId(String modifiedId) {
		this.modifiedId = modifiedId;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	

}
