package com.bsf.macug.mt101.processlog;

import com.bsf.macug.mt101.dto.MacPaymentActivityLogDTO;

public interface InterMT100ProcessLogService {

	boolean saveMT100PaymentActivityLog(MacPaymentActivityLogDTO activityLogDTO);

}
