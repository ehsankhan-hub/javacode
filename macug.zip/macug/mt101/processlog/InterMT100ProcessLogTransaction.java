package com.bsf.macug.mt101.processlog;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.mt101.entity.MacPaymentActivityLog;

public interface InterMT100ProcessLogTransaction {

	boolean saveMT100ProcessLog(MacPaymentActivityLog activityLog)throws DataAccessException;

}
