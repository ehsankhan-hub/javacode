package com.bsf.macug.mt101.processlog;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.mt101.dao.InterPaymentDAO;
import com.bsf.macug.mt101.entity.MacPaymentActivityLog;

@Transactional
@Service
public class MT100ProcessLogTransactionImpl implements InterMT100ProcessLogTransaction {

	@Autowired
	InterPaymentDAO paymentDAO;

	@Override
	public boolean saveMT100ProcessLog(MacPaymentActivityLog activityLog) throws DataAccessException{
		try {
			return paymentDAO.savePaymentProcessLog(activityLog);
		} catch (DataAccessException e) {
			return false;
		}
	}

}
