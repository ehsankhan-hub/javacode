package com.bsf.macug.mt101.service;

public interface InterMT101Service
{
  public void processFile();
}