package com.bsf.macug.mt101.service;

import com.bsf.macug.mt101.dao.InterPaymentUniqeSeriesDAO;
import com.bsf.macug.mt101.entity.PaymentUniqeSeries;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class PaymentUniqeSeriesServiceImpl implements InterPaymentUniqeSeriesService {
	private static final Logger logger = Logger.getLogger(PaymentUniqeSeriesServiceImpl.class.getName());
	@Autowired
	InterPaymentUniqeSeriesDAO paymentUniqeSeriesDAO;

	public boolean save(PaymentUniqeSeries entity) {
		boolean status = false;
		try {
			status = this.paymentUniqeSeriesDAO.save(entity);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}
}
