package com.bsf.macug.mt101.service;

import java.io.StringReader;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.ws.WebServiceException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bsf.macug.application.mail.service.InterMailService;
import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.entity.CustomerLimits;
import com.bsf.macug.customer.service.InterCustomerAccountsService;
import com.bsf.macug.customer.service.InterCustomerLimitsService;
import com.bsf.macug.exception.CurrencyConversionException;
import com.bsf.macug.exception.DuplicateFileException;
import com.bsf.macug.exception.PossibleDuplicationException;
import com.bsf.macug.exception.SystemPropertyNotConfigurationException;
import com.bsf.macug.exception.TCPConnectionException;
import com.bsf.macug.exception.ValidationException;
import com.bsf.macug.exception.XMLParsingException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.dto.ExchangeRateDTO;
import com.bsf.macug.mt101.dto.ValueDateSoapDTO;
import com.bsf.macug.mt101.dto.fileact.request.Message;
import com.bsf.macug.mt101.entity.FTSTuxKey;
import com.bsf.macug.mt101.entity.ForeignHoliday;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.entity.MacPaymentHeader;
import com.bsf.macug.mt101.entity.MacFileLog;
import com.bsf.macug.mt101.entity.PaymentUniqeSeries;
import com.bsf.macug.mt101.service.tuxedo.InterAccountEnquiryService;
import com.bsf.macug.util.IConstants;
import com.bsf.macug.util.IConstants.RATE_INDICATOR;
import com.bsf.macug.util.InterUtils;

@Service
public class MT100Util implements InterMT100Util {
	private static final Logger logger = Logger.getLogger(MT100Util.class.getName());

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterAccountEnquiryService accountEnquiryService;

	@Autowired
	InterPaymentService paymentService;

	@Autowired
	InterUtils utils;

	@Autowired
	InterForexSOAPService forexSOAPService;

	@Autowired
	InterValueDateSOAPService valueDateSOAPService;

	@Autowired
	InterFTSTuxKeyService ftsTuxKeyService;

	@Autowired
	InterPaymentUniqeSeriesService paymentUniqeSeriesService;

	@Autowired
	InterCustomerLimitsService customerLimitsService;

	@Autowired
	InterMailService mailService;

	@Autowired
	InterCustomerAccountsService customerAccountsService;

	@Override
	public MacPaymentDetail setStatusAndDescription(MacPaymentDetail details, String status, String errorCode,
			Map<String, SystemParameters> map) {
		try {
			String description = systemParameterService.getSystemParametersDescription1(errorCode, map);
			String action = systemParameterService.getSystemParametersDescription2(errorCode, map);
			details.setStatus(status);
			details.setDescription(description);
			details.setAction(action);
		} catch (Exception e) {
			details.setStatus(status);
			details.setDescription("Description not found.");
			details.setAction("Action not found");
		}
		return details;
	}

	@Override
	public String getCurrentRateSequence() {
		String strSquence = null;
		DateFormat dfYear = new SimpleDateFormat("yy");
		Long sequence = paymentService.getSequence("MAC_SEQ_RATE");
		strSquence = utils.appendCharacter(sequence + "", 10, "L", "0") + dfYear.format(new Date());
		logger.info("(getCurrentRateSequence) ==> sequence " + strSquence);
		return strSquence;
	}

	@Override
	public BigDecimal getAmountInSAR(BigDecimal amount, String transactionCurrency, String debitAccount,
			Map<String, SystemParameters> exchangeRateMap) throws WebServiceException, CurrencyConversionException {
		BigDecimal sarAmount = amount;
		if (!transactionCurrency.equalsIgnoreCase("SAR")) {
			ExchangeRateDTO exchangeRate = forexSOAPService.getExchangeRate("SAR", transactionCurrency, "1",
					debitAccount, exchangeRateMap, "Macug");
			String xeRateSar = exchangeRate.getExchangeRate();
			if (xeRateSar.contains(","))
				xeRateSar = xeRateSar.replace(",", ".");

			BigDecimal exAmount = new BigDecimal(xeRateSar);
			sarAmount = exAmount.multiply(sarAmount);
		}
		return sarAmount;
	}

	@Override
	public BigDecimal calulateCharge(BigDecimal charge, BigDecimal xeRate) {

		if (StringUtils.isEmpty(charge)) {
			return new BigDecimal("0");
		} else if (StringUtils.isEmpty(xeRate)) {
			return new BigDecimal("0");
		}

		BigDecimal newCharge = xeRate.multiply(charge);

		return newCharge;
	}

	@Override
	public BigDecimal getConversionRate(String amount, String fromCurrency, String debitAccount, String baseCurrency,
			Map<String, SystemParameters> exchangeRateMap) throws WebServiceException, CurrencyConversionException {
		try {
			if (fromCurrency.equals(baseCurrency)) {
				return new BigDecimal("1");
			}

			ExchangeRateDTO exchangeRate;
			BigDecimal exAmount = new BigDecimal("1");
			exchangeRate = forexSOAPService.getExchangeRate(fromCurrency, baseCurrency, amount, debitAccount,
					exchangeRateMap, "Macug");
			String xeRateSar = exchangeRate.getExchangeRate();
			if (xeRateSar.contains(","))
				xeRateSar = xeRateSar.replace(",", ".");

			if (!StringUtils.isEmpty(xeRateSar)) {
				exAmount = new BigDecimal(xeRateSar);
			}

			return exAmount;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new CurrencyConversionException();
		}

	}

	@Override
	public ValueDateSoapDTO getApplicableValueObj(String currency, String country, Date valueDate,
			Map<String, SystemParameters> mpB2BProperties) throws TCPConnectionException {
		DateFormat valueDateValidateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		ValueDateSoapDTO valueDateSoapDto = null;

		try {
			valueDateSoapDto = new ValueDateSoapDTO();
			String requestValueDate = valueDateValidateFormat.format(valueDate);
			valueDateSoapDto.setMsgType("100");
			valueDateSoapDto.setCurrency(currency);
			valueDateSoapDto.setRequestValueDate(requestValueDate);
			valueDateSoapDto.setCountryCode(country);
			ValueDateSoapDTO valueDateResponse = valueDateSOAPService.getNextValueDate(valueDateSoapDto,
					mpB2BProperties);
			if (valueDateResponse != null) {
				Date applicableValueDate = valueDateResponse.getCalulatedExpressValueDate();
				if (applicableValueDate == null) {
					throw new TCPConnectionException("Applicable value date not found");
				}
			}
		} catch (WebServiceException e) {
			logger.error("Error :" + e.getMessage(), e);
			throw new TCPConnectionException("Applicable value date not found");
		} catch (Exception e) {
			logger.error("Error :" + e.getMessage(), e);
			throw new TCPConnectionException("Applicable value date not found");
		}

		return valueDateSoapDto;
	}

	@Override
	public boolean saveFTSKey(String transactionRef, String ftsRef, String requestMessage, String type)
			throws PossibleDuplicationException {
		boolean blStatus = false;
		try {
			logger.info("(saveFTSKey)==> Trying to save FTS key to avoid duplication.");
			if (StringUtils.isEmpty(ftsRef)) {
				throw new PossibleDuplicationException();
			}
			FTSTuxKey ftsTuxKey = null;
			ftsTuxKey = new FTSTuxKey();
			ftsTuxKey.setFtsReference(ftsRef);
			ftsTuxKey.setCreatedTime(new Date());
			ftsTuxKey.setTransReference(transactionRef);
			ftsTuxKey.setTuxedoRequest(requestMessage);
			ftsTuxKey.setType(type);
			ftsTuxKey.setSource("ONLINE");
			blStatus = ftsTuxKeyService.saveFTSTuxKey(ftsTuxKey);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new PossibleDuplicationException();
		}
		return blStatus;
	}

	@Override
	public void updateFTSKey(String trnRef, String ftsRef, String acToAcTransferResponseString) {
		try {
			FTSTuxKey ftsREfObj = ftsTuxKeyService.getFTSTuxKey(ftsRef);
			if (ftsREfObj != null) {
				ftsREfObj.setResponseTime(new Date());
				ftsREfObj.setTuxedoResponse(acToAcTransferResponseString);
				ftsTuxKeyService.updateFTSTuxKey(ftsREfObj);
			}
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
	}

	@Override
	public boolean savePaymentUniqueSeries(String custId, String remAccount, String benAccount, BigDecimal amount,
			Date valueDate, CustomerDetails customer) throws PossibleDuplicationException {
		boolean status = false;
		try {
			logger.info("custId " + custId + " remAccount " + remAccount + " benAccount " + benAccount + " amount "
					+ amount + "valueDate " + valueDate);

			Integer series = customer.getPaymentSeries();
			if (series == 0) {
				return true;
			}
			DateFormat vFormat = new SimpleDateFormat("yyyyMMddHHmm");

			DateFormat format = new SimpleDateFormat("yyyyMMddHHmm");
			String strDate = format.format(valueDate);
			Long seriesL = Long.parseLong(strDate);
			for (int i = 0; i < series; i++) {
				seriesL = seriesL + i;
				String key = custId + remAccount + benAccount + amount.toString() + strDate
						+ seriesL;
				PaymentUniqeSeries seriesObj = new PaymentUniqeSeries();
				seriesObj.setTransactionSeries(key);
				seriesObj.setCreatedDate(new Date());
				status = paymentUniqeSeriesService.save(seriesObj);
				if (!status) {
					logger.warn("(savePaymentUniqueSeries)==> saving failed...");
					break;
				}
			}
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new PossibleDuplicationException();
		}
		return status;
	}

	@Override
	public void updateLimit(MacPaymentDetail details, BigDecimal amountInSAR,
			CustomerDetails customerDetails, String account) {
		try {
			CustomerLimits customerLimits = customerLimitsService.getData(details.getCustomerId(),
					details.getValueDate(), account);
			CustomerAccounts accountInfo = customerAccountsService
					.getCustomerAccountDetails(customerDetails.getCustomerId(), account, "PAYMENT");
			if (!accountInfo.getAccountTransferLimit().toString().equals("-1")) {
				BigDecimal bsfLimitAmount = customerLimits.getAvailableBSFLimit().subtract(amountInSAR);
				customerLimits.setAvailableBSFLimit(bsfLimitAmount);
				customerLimitsService.updateData(customerLimits);
			}
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}

	}

	@Override
	public Message parseXMLMessage(String data) throws XMLParsingException {
		Unmarshaller unmarshaller;
		Message requestObj = null;
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(Message.class);
			unmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(data);
			requestObj = (Message) unmarshaller.unmarshal(reader);
		} catch (JAXBException e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new XMLParsingException();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new XMLParsingException();
		}
		if (requestObj == null) {
			logger.error("(parseClassicXMLToObject) ==> RequestObject is null");
			throw new XMLParsingException();
		}
		return requestObj;
	}

	@Override
	public boolean checkIfValidRequestDateTime(String requestDateTime, Map<String, SystemParameters> macPropertyMap) {
		if (StringUtils.isEmpty(requestDateTime)) {
			return false;
		}
		String formatType = systemParameterService.getSystemParametersDescription1("MACREQDTF", macPropertyMap);
		SimpleDateFormat format = new SimpleDateFormat(formatType);
		try {
			Date date = format.parse(requestDateTime);
			Date today = new Date();
			format = new SimpleDateFormat("yyyy-MM-dd");
			String strDate = format.format(today);
			String reqDateTime = format.format(date);
			if (strDate.equals(reqDateTime)) {
				return true;
			}
		} catch (Exception e) {
			logger.error("Error " + e.getMessage(), e);
		}
		return false;
	}

	@Override
	public boolean checkIfFileIdExists(String fileId, String customerId) throws DuplicateFileException {
		boolean fileExistFlag=false;
		try {
			MacPaymentHeader header = paymentService.getHeader(customerId, fileId);
			if (header != null) {
				fileExistFlag=true;
				throw new DuplicateFileException(
						"Header already exists. fileID : " + fileId + " , CustId : " + customerId);
			}
		} catch (DuplicateFileException e) {
			throw e;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new DuplicateFileException();
		}
		return fileExistFlag;
	}

	@Override
	public MacFileLog saveLog(String uniqueId, byte[] requestData) {
		MacFileLog log = null;
		try {
			UUID guid = UUID.randomUUID();
			String id = guid.toString();
			log = new MacFileLog();
			log.setId(id);
			log.setFileLinkId(uniqueId);
			log.setData(requestData);
			log.setStatus("NEW");
			log.setDescription("Logged successfully.");
			paymentService.savePaymentLog(log);
			log = paymentService.getFileLog(id);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return log;
	}

	@Override
	public boolean updateLog(MacFileLog log) {
		boolean status = false;
		try {
			if (log != null)
				status = paymentService.updateFileLog(log);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public MacPaymentDetail generateKondorFileIfNeeded(MacPaymentDetail macPaymentDetail) {
		try {
			Map<String, Map<String, SystemParameters>> allSystemProperties = utils.loadSystemProperties();
			Map<String, SystemParameters> macPropertyMap = allSystemProperties.get("macPropertyMap");
			String paymentTypeAccountToAccount = systemParameterService.getSystemParametersDescription1("PMTTYPACC",
					macPropertyMap);

			String type = macPaymentDetail.getTransactionType();
			if (type.equals(paymentTypeAccountToAccount)) {
				return macPaymentDetail;
			} else if (macPaymentDetail.getCurrency().equals(macPaymentDetail.getDebitCurrency())) {
				return macPaymentDetail;
			}

			String debitAccount = macPaymentDetail.getDebitAccount();
			String customerId = macPaymentDetail.getCustomerId();
			CustomerAccounts account = customerAccountsService.getCustomerAccountDetails(customerId, debitAccount,
					"PAYMENT");
			RATE_INDICATOR rateIndicator = account.getRateIndicator();
			if (rateIndicator == IConstants.RATE_INDICATOR.SAME_CUR) {
				return macPaymentDetail;
			} else if (rateIndicator == IConstants.RATE_INDICATOR.NOT_SUPPORTED) {
				return macPaymentDetail;
			} else if (rateIndicator == IConstants.RATE_INDICATOR.CROS_CUR) {
				return macPaymentDetail;
			}

			boolean sentStatus = mailService.sendMailToKondor(macPaymentDetail);
			if (sentStatus) {
				macPaymentDetail.setKondorFile("SENT");
			} else {
				macPaymentDetail.setKondorFile("FAILED");
			}
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return macPaymentDetail;
	}

	@Override
	public Date getValidTradeDate(MacPaymentDetail details, CustomerAccounts debitAccountObj)
			throws ValidationException {
		Date tradeDate = null;
		try {
			String debitCurrency = debitAccountObj.getCurrencyCode();
			String transactionCurrency = details.getCurrency();
			Date valueDate = details.getValueDate();

			try {
				Map<String, Map<String, SystemParameters>> allSystemProperties = utils.loadSystemProperties();
				Map<String, SystemParameters> macPropertyMap = allSystemProperties.get("macPropertyMap");

				BigDecimal swiftDay = systemParameterService.getSystemParametersValue2("SWFVALDAY", macPropertyMap);
				String paymentTypeSwift = systemParameterService.getSystemParametersDescription1("PMTTYPSWF",
						macPropertyMap);

				Calendar date = new GregorianCalendar();
				// reset hour, minutes, seconds and millis
				date.setTime(valueDate);
				date.add(Calendar.DATE, -2);
				tradeDate = date.getTime();

				tradeDate = getTradeDate(tradeDate, debitCurrency, transactionCurrency);

				if (tradeDate != null) {
					return tradeDate;
				}

			} catch (SystemPropertyNotConfigurationException e) {
				logger.error("Error : " + e.getMessage(), e);
				throw new ValidationException("MACVER027");
			} catch (Exception e) {
				logger.error("Error : " + e.getMessage(), e);
				throw new ValidationException("MACVER027");
			}

		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			tradeDate = null;
		}
		if (tradeDate == null) {
			throw new ValidationException("MACVER027");
		}
		return tradeDate;
	}

	private Date getTradeDate(Date tradeDate, String debitCurrency, String transactionCurrency) {
		try {
			Calendar date = new GregorianCalendar();
			// reset hour, minutes, seconds and millis
			date.set(Calendar.HOUR_OF_DAY, 0);
			date.set(Calendar.MINUTE, 0);
			date.set(Calendar.SECOND, 0);
			date.set(Calendar.MILLISECOND, 0);
			Date today = date.getTime();

			// date.add(Calendar.DATE, -1 * swiftDay.intValue());

			if (tradeDate.before(today)) {
				return null;
			}

			boolean validTrade = validateCurrencyWithTrade(debitCurrency, transactionCurrency, tradeDate);
			if (validTrade) {
				return tradeDate;
			} else {
				Calendar cal = Calendar.getInstance();
				cal.setTime(tradeDate);
				cal.add(Calendar.DATE, -1);
				Date tradeDateReduced = cal.getTime();
				return getTradeDate(tradeDateReduced, debitCurrency, transactionCurrency);
			}

		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			return null;
		}
	}

	private boolean validateCurrencyWithTrade(String debitCurrency, String transactionCurrency, Date tradeDate) {
		try {
			List<ForeignHoliday> list = paymentService.getForeignHoliday(tradeDate, debitCurrency, transactionCurrency);
			if (list.size() > 0) {
				return false;
			}
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			return false;
		}
		return true;
	}

	@Override
	public boolean isFutureValueDate(String valueDateStr) {
		Calendar cal = Calendar.getInstance();
		Date today = cal.getTime();
		SimpleDateFormat format = new SimpleDateFormat("yyMMdd");
		boolean passed = false;
		try {
			Date valueDate = format.parse(valueDateStr);
			if (valueDate.after(today)) {
				passed = true;
			}
		} catch (Exception e) {
			passed = false;
			logger.error("Error : " + e.getMessage(), e);
		}
		return passed;
	}

}
