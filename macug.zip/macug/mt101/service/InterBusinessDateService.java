package com.bsf.macug.mt101.service;

import java.util.Map;

import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.mt101.dto.BusinessDateDTO;

public interface InterBusinessDateService {

	BusinessDateDTO getBusinessDate(String strSource,
			Map<String, SystemParameters> b2BPropertyMap);

}
