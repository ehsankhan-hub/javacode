package com.bsf.macug.mt101.service.handler;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.bsf.macug.mt101.dto.ExchangeRateDTO;
import com.bsf.macug.mt101.dto.FxDealResponseDTO;

public class ExchangeRateHandler {	
	private static final Logger logger = Logger.getLogger(ExchangeRateHandler.class.getName());	
	public ExchangeRateDTO parseExchangeRateResponse(String inputXml) throws IOException {
		ExchangeRateDTO exchangeRate = new ExchangeRateDTO();
		try {
			Document document = loadXMLFromString(inputXml);
			NodeList nodes = document.getElementsByTagName("getCurrRateResult");
			
			for (int i = 0; i < nodes.getLength(); i++) {
				Element element = (Element) nodes.item(i);

				Element line = (Element) element.getElementsByTagName("ReplyStatus").item(0);
				exchangeRate.setReplyStatus(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("ReplyDescription").item(0);
				exchangeRate.setReplyDescription(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("Segment").item(0);
				exchangeRate.setSegment(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("BaseCurrency").item(0);
				exchangeRate.setBaseCurrency(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("ToCurrency").item(0);
				exchangeRate.setToCurrency(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("ExchangeRate").item(0);
				exchangeRate.setExchangeRate(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("BuyRate").item(0);
				exchangeRate.setBuyRate(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("SellRate").item(0);
				//exchangeRate.setReplyStatus(getCharacterDataFromElement(line));
				exchangeRate.setSellRate(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("Amount").item(0);
				//exchangeRate.setSellRate(getCharacterDataFromElement(line));
				exchangeRate.setSellRate(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("AmountInBaseCurrency").item(0);
				exchangeRate.setAmountInBaseCurrency(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("CeilingAmount").item(0);
				exchangeRate.setCeilingAmount(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("ValueDate").item(0);
				//exchangeRate.setReplyStatus(getCharacterDataFromElement(line));
				exchangeRate.setValueDate(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("Status").item(0);
				exchangeRate.setStatus(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("RequestReference").item(0);
				exchangeRate.setRequestReference(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("SourceApplication").item(0);
				exchangeRate.setSourceApplication(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("ReplyDateTime").item(0);
				exchangeRate.setReplyDateTime(getCharacterDataFromElement(line));
				
			}
			
			
		} catch (Exception e) {
			logger.error("Error in the Method parseExchangeRateResponse() "+e);
		} 
		
		return exchangeRate;
	}
	
	public FxDealResponseDTO parseDealTicketResponse(String inputXml) throws IOException {		
		FxDealResponseDTO fxDealResponse = new FxDealResponseDTO();
		try {
			Document document = loadXMLFromString(inputXml);
			NodeList nodes = document.getElementsByTagName("GetGTDTicketDetailsResult");			
			for (int i = 0; i < nodes.getLength(); i++) {
				Element element = (Element) nodes.item(i);

				Element line = (Element) element.getElementsByTagName("ReplyStatus").item(0);
				fxDealResponse.setReplyStatus(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("ProfitCenter").item(0);
				fxDealResponse.setProfitCenter(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("CurrencySell").item(0);
				fxDealResponse.setCurrencySell(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("CurrencyBuy").item(0);
				fxDealResponse.setCurrencyBuy(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("ExchangeRate").item(0);
				fxDealResponse.setExchangeRate(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("AmountSell").item(0);
				fxDealResponse.setAmountSell(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("AmountBuy").item(0);
				fxDealResponse.setAmountBuy(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("TradeDate").item(0);
				fxDealResponse.setTradeDate(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("SoldDate").item(0);
				fxDealResponse.setSoldDate(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("PurchasedDate").item(0);
				fxDealResponse.setPurchasedDate(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("Status").item(0);
				fxDealResponse.setStatus(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("TransactionReference").item(0);
				fxDealResponse.setTransactionRef(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("TransactionType").item(0);
				fxDealResponse.setTransactionType(getCharacterDataFromElement(line));
				
				line = (Element) element.getElementsByTagName("LastStatusModifiedDate").item(0);
				fxDealResponse.setLastStatusModifiedDate(getCharacterDataFromElement(line));				
			}			
			
		} catch (Exception e) {
			logger.error("Error in the Method parseDealTicketResponse()"+e);
		} 
		
		return fxDealResponse;
	}
	public String parseUpdateDealRes(String inputXml){
		String result = "";
		Document document = loadXMLFromString(inputXml);
		NodeList nodes = document.getElementsByTagName("UpdateGTDTicketResult");	
		for (int i = 0; i < nodes.getLength(); i++) {
			Element element = (Element) nodes.item(i);
			Element line = (Element) element.getElementsByTagName("ResponseCode").item(0);
			result = getCharacterDataFromElement(line);
		}
		return result;
	}
	private Document loadXMLFromString(String xml) {
		Document document = null;
		try {
		    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		    DocumentBuilder builder = factory.newDocumentBuilder();
		    InputSource is = new InputSource(new StringReader(xml));
		    document = builder.parse(is);
		} catch(Exception e) {
			logger.error("Error : "+e.getMessage(), e);
		}
		return document;
	}
	
	private static String getCharacterDataFromElement(Element e) {
		
		if(e != null) {
			Node child = e.getFirstChild();
			if (child instanceof CharacterData) {
				CharacterData cd = (CharacterData) child;
				return cd.getData();
			}
		}
		return null;
	}

}
