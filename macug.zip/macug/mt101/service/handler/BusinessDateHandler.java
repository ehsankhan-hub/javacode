package com.bsf.macug.mt101.service.handler;

import java.io.StringReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.bsf.macug.mt101.dto.BusinessDateDTO;

public class BusinessDateHandler {

	private static final Logger logger = Logger
			.getLogger(BusinessDateHandler.class.getName());

	// To parse the business date xml and map it to business date DTO
	public BusinessDateDTO parseBusinessDateResponse(String xmlResponse)
			throws Exception {
		BusinessDateDTO busDateDTO = null;
		DocumentBuilderFactory factory = null;
		DocumentBuilder builder = null;
		InputSource inputSource = null;
		Document document = null;
		NodeList serviceResult = null;
		Date dtBusinessDate = null;
		DateFormat dfFormat = null;

		factory = DocumentBuilderFactory.newInstance();
		builder = factory.newDocumentBuilder();
		logger.info("(parseBusinessDateResponse)==> Inside");
		inputSource = new InputSource(new StringReader(xmlResponse));
		logger.info("(parseBusinessDateResponse)==> Starting to parse");
		document = builder.parse(inputSource);
		logger.info("(parseBusinessDateResponse)==> Getting service result");
		serviceResult = document.getElementsByTagName("ServiceRs");
		try {
			busDateDTO = new BusinessDateDTO();
			if (serviceResult != null) {
				for (int i = 0; i < serviceResult.getLength(); i++) {
					NodeList busDate = null;
					Element element = (Element) serviceResult.item(i);

					logger.info("(parseBusinessDateResponse)==> Getting status code");
					Element statusCode = (Element) element.getElementsByTagName(
							"StatusCode").item(0);
					String strStatus = getCharacterDataFromElement(statusCode);
					busDateDTO.setStatusCode(strStatus);

					logger.info("(parseBusinessDateResponse)==> Getting status description");
					Element statusDesc = (Element) element.getElementsByTagName(
							"StatusDescription").item(0);
					String strDesc = getCharacterDataFromElement(statusDesc);
					busDateDTO.setDescription(strDesc);
					logger.info("(parseBusinessDateResponse)==> Status is "
							+ strStatus + " description is " + strDesc);

					if (strDesc != null && strDesc.equals("Success")
							&& strStatus != null && strStatus.equals("00")) {
						logger.info("(parseBusinessDateResponse)==> Status is success");
						dfFormat = new SimpleDateFormat("yyyy-MM-dd");
						busDate = element.getElementsByTagName("GetBusinessDate");
						for (int x = 0; x < busDate.getLength(); x++) {
							Element busDateElement = (Element) busDate.item(i);

							logger.info("(parseBusinessDateResponse)==> Setting business date");
							Element businessDate = (Element) busDateElement
									.getElementsByTagName("BusinessDate").item(0);
							String strBusDate = getCharacterDataFromElement(businessDate);
							busDateDTO
									.setBusinessDate((strBusDate != null) ? dfFormat
											.parse(strBusDate) : new Date());

							logger.info("(parseBusinessDateResponse)==> Setting system date");
							Element systemDate = (Element) busDateElement
									.getElementsByTagName("SystemDate").item(0);
							String sysDate = getCharacterDataFromElement(systemDate);
							busDateDTO.setSystemDate((sysDate != null) ? dfFormat
									.parse(sysDate) : new Date());

							logger.info("(parseBusinessDateResponse)==> Setting system time");
							Element sysTime = (Element) busDateElement
									.getElementsByTagName("SystemTime").item(0);
							busDateDTO
									.setTime(getCharacterDataFromElement(sysTime));
						}
					} else {
						logger.info("(parseBusinessDateResponse)==> Setting business date as server date");
						dtBusinessDate = new Date();
						busDateDTO.setBusinessDate(dtBusinessDate);
					}
				}
			} else {
				logger.info("(parseBusinessDateResponse)==> Setting business date as server date");
				dtBusinessDate = new Date();
				busDateDTO.setBusinessDate(dtBusinessDate);
			}
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
		}

		return busDateDTO;
	}
	
	
	private static String getCharacterDataFromElement(Element e) {
		if (e != null) {
			Node child = e.getFirstChild();
			if (child instanceof CharacterData) {
				CharacterData cd = (CharacterData) child;
				return cd.getData();
			}
		}
		return null;
	}

}
