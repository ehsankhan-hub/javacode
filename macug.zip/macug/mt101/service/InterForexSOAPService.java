package com.bsf.macug.mt101.service;

import java.util.Map;

import javax.xml.ws.WebServiceException;

import com.bsf.macug.exception.CurrencyConversionException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.mt101.dto.ExchangeRateDTO;
import com.bsf.macug.mt101.dto.FxDealResponseDTO;

public interface InterForexSOAPService {
	ExchangeRateDTO getExchangeRate(String baseCurrency, String currency,
			String amount, String accountNo,
			Map<String, SystemParameters> b2bPropertyMap, String segment)
			throws WebServiceException, CurrencyConversionException;

	public FxDealResponseDTO getDealDetails(String dealTicketNumber,
			Map<String, SystemParameters> properties) throws WebServiceException;

	FxDealResponseDTO updateDealDetails(String dealTicketNumber,
			String transactionRef, String financialTransactionType,
			String status, Map<String, SystemParameters> properties)
			throws WebServiceException;
}
