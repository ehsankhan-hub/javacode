package com.bsf.macug.mt101.service;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsf.macug.mt101.entity.ForeignHoliday;
import com.bsf.macug.mt101.entity.MacFileLog;
import com.bsf.macug.mt101.entity.MacPaymentActivityLog;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.entity.MacPaymentHeader;
import com.bsf.macug.mt101.transaction.InterPaymentTransactionalService;

@Service
public class PaymentServiceImpl implements InterPaymentService {
	private static final Logger logger = Logger.getLogger(PaymentServiceImpl.class.getName());

	@Autowired
	InterPaymentTransactionalService transaction;

	public boolean saveHeader(MacPaymentHeader header) {
		boolean status = false;
		try {
			status = transaction.saveHeader(header);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	public boolean updateHeader(MacPaymentHeader header) {
		boolean status = false;
		try {
			status = transaction.updateHeader(header);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}
	
	public boolean updatePaymnetProcessLog(MacPaymentActivityLog activityLog) {
		boolean status = false;
		try {
			status = transaction.updatePaymnetProcessLog(activityLog);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
		
	}

	public List<MacPaymentHeader> findAllHeader(String status) {
		List<MacPaymentHeader> headerList = null;
		try {
			headerList = transaction.findAllHeader(status);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return headerList;
	}

	public MacPaymentHeader getHeader(String customerId, String fileId) {
		MacPaymentHeader header = null;
		try {
			header = transaction.getHeader(customerId, fileId);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return header;
	}
	
	
	public MacPaymentActivityLog getPaymentProcessLogByFileName(String fileName) {
		MacPaymentActivityLog macPaymentActLog=null;
		try {
		macPaymentActLog=transaction.getPaymentProcessLogByFileName(fileName);
		}
		catch(Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return macPaymentActLog;
	}

	public boolean saveDetail(MacPaymentDetail detail) {
		boolean status = false;
		try {
			UUID guid = UUID.randomUUID();
			detail.setId(guid.toString());
			detail.setCreatedBy("SYSTEM");
			detail.setCreatedOn(new Timestamp(new Date().getTime()));
			status = transaction.saveDetail(detail);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	public boolean updateDetail(MacPaymentDetail detail) {
		boolean status = false;
		try {
			detail.setModifiedBy("SYSTEM");
			detail.setModifiedOn(new Timestamp(new Date().getTime()));
			status = transaction.updateDetail(detail);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}
	
	

	public List<MacPaymentDetail> findAllDetail(String customerId, String fileId, String status) {
		List<MacPaymentDetail> detailList = null;
		try {
			detailList = transaction.findAllDetail(customerId, fileId, status);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detailList;
	}

	public MacPaymentDetail getDetail(String customerId, String fileId, String transactionId) {
		MacPaymentDetail detail = null;
		try {
			detail = transaction.getDetail(customerId, fileId, transactionId);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detail;
	}

	public Long getSequence(String sequenceName) {
		Long value = null;
		try {
			value = transaction.getSequence(sequenceName);
			if (value != null) {
				value = Long.valueOf(value.longValue());
			}
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return value;
	}

	public List<MacPaymentHeader> getMT199Pendings() {
		List<MacPaymentHeader> list = null;
		try {
			list = transaction.getMT199Pendings();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return list;
	}
	
	public List<MacPaymentActivityLog>  getMT199BasicValidation(){
		List<MacPaymentActivityLog> list=null;
		try {
		list = transaction.getMT199BasicValidation();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return list;
		
	}
	
	
	
	
	

	public List<MacPaymentDetail> getAllFailedTransactions(String fileReference) {
		List<MacPaymentDetail> list = null;
		try {
			list = transaction.getAllFailedTransactions(fileReference);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return list;
	}

	public boolean savePaymentLog(MacFileLog log) {
		boolean status = false;
		try {			
			log.setType("PAYMENT");
			log.setCreatedBy("SYSTEM");
			log.setCreatedOn(new Timestamp(new Date().getTime()));
			status = transaction.savePaymentLog(log);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	public List<ForeignHoliday> getForeignHoliday(Date tradeDate, String debitCurrency, String transactionCurrency) {
		List<ForeignHoliday> list = null;
		try {
			list = transaction.getForeignHoliday(tradeDate, debitCurrency.substring(0, 2),
					transactionCurrency.substring(0, 2));
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return list;
	}

	public List<Object[]> getTransactionTypeCount(String customerId, String fileId) {
		List<Object[]> list = null;
		try {
			list = transaction.getTransactionTypeCount(customerId, fileId);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return list;
	}

	public List<Object[]> getStatusCount(String customerId, String fileId) {
		List<Object[]> list = null;
		try {
			list = transaction.getStatusCount(customerId, fileId);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return list;
	}

	@Override
	public MacFileLog getFileLog(String id) {
		MacFileLog log = null;
		try {
			log = transaction.getFileLog(id);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return log;
	}

	@Override
	public boolean updateFileLog(MacFileLog log) {
		boolean status = false;
		try {			
			log.setModifiedBy("SYSTEM");
			log.setModifiedOn(new Timestamp(new Date().getTime()));
			status = transaction.updateFileLog(log);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}
	
	
}
