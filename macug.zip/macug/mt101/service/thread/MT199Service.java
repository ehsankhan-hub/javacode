package com.bsf.macug.mt101.service.thread;

import java.io.FileOutputStream;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.service.InterCustomerDetailsService;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.exception.FileHandlerException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.dto.fileact.response.ObjectFactory;
import com.bsf.macug.mt101.dto.fileact.response.PaymentFileActResponse;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.entity.MacPaymentHeader;
import com.bsf.macug.mt101.service.InterPaymentService;
import com.bsf.macug.util.FileUtilsImpl;
import com.bsf.macug.util.InterFileUtils;
import com.bsf.macug.util.InterUtils;
import com.prowidesoftware.swift.model.field.Field20;
import com.prowidesoftware.swift.model.field.Field21;
import com.prowidesoftware.swift.model.field.Field79;
import com.prowidesoftware.swift.model.field.Field91A;
import com.prowidesoftware.swift.model.field.Field92A;
import com.prowidesoftware.swift.model.mt.mt1xx.MT199;

@Component
@Scope("prototype")
public class MT199Service implements Runnable {
	private static final Logger logger = Logger.getLogger(MT199Service.class.getName());

	private MacPaymentHeader macPaymentHeader;
	
	private String envelopSourcePath;

	@Autowired
	InterPaymentService paymentService;
	
	@Autowired
	InterCustomerDetailsService customerDetailsService;
	
	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterFileUtils fileUtils;
	
	@Autowired
	InterUtils utils;
	
	private int count=1;	

	@Override
	public void run() {
		String responseFileAct="";
		
		try {
            		
			String fileReference = macPaymentHeader.getFileReference();
			String customerID=macPaymentHeader.getCustomerId() ;
			
			String messageType=macPaymentHeader.getMessageType();
			
			List<MacPaymentDetail> list = paymentService.getAllFailedTransactions(fileReference);
			
			//MacPaymentActivityLog macPaymentActLogList= paymentService.getPaymentProcessLogByFileName(macPaymentHeader.getCustReqFile());
			
			//List<MacPaymentDetail> list=new ArrayList<MacPaymentDetail>();
			
						
			//List<MacPaymentDetail> successTrans =paymentService.findAllDetail(customerID, fileReference, "OK");
			String customerId = macPaymentHeader.getCustomerId();
			CustomerDetails customerDetails=customerDetailsService.getCustomerDetails(customerId);
			String reqFileValue=macPaymentHeader.getCustReqFile();
			String concenateFileValue=macPaymentHeader.getResponseFileValue();
			
			
			if (customerDetails == null) {
				logger.info("Customer not registred. ");
				throw new CustomerNotFoundException("Customer not registred.");
			}
			
		String swNetServicName=customerDetails.getSwNetServicName();
			
			if(StringUtils.isEmpty(swNetServicName)) {
				logger.info("SWNET_SERVICE Field = "+swNetServicName);	
				throw new Exception("SWNET_SERVICE Field is null");
			}
			
			if(StringUtils.isEmpty(concenateFileValue) ) {
				logger.info("File response column value is = "+concenateFileValue);	
				throw new Exception("File response column value is null");
			}
			String custNameFull=customerDetails.getCustNameFull();
			
			if(StringUtils.isEmpty(custNameFull)) {
				logger.info("Customer Name Full = "+custNameFull);	
				throw new Exception("Customer Full name is null");
				
			}
			
			String mt199BulkFlag=customerDetails.getMt199BulkFlag();
			if(StringUtils.isEmpty(mt199BulkFlag)) {
				logger.info("MT199 Bulk Flag = "+mt199BulkFlag);	
				throw new Exception("MT199 Bulk Flag is null");
				
			}
			
			String compName=customerDetails.getCustomerName();
			
			if(StringUtils.isEmpty(compName)) {
				logger.info("Customer name = "+compName);	
				throw new Exception("Customer name is null");
				
			}
			
		
			// Fin format 
			//For existing customer will receive files one transaction one mt199  file and save the file in MacPaymentDetail table 
			if(messageType.equalsIgnoreCase("FIN")&&!mt199BulkFlag.trim().equals("Y")) {
				Field20 field20 = new Field20(fileReference);
			for (MacPaymentDetail macPaymentDetail : list) {
				try {
					
					//field79.SET
					MT199 mt199 = new MT199();
					mt199.setReceiver(customerId);
					mt199.setSender("BSFRSARIXXX");
					String reletadReference = macPaymentDetail.getTransactionReference();
					String status = macPaymentDetail.getStatus();
					String description = macPaymentDetail.getDescription();
					String action=macPaymentDetail.getAction();
					//macPaymentDetail.getDescription()
					
					Field21 field21=new Field21(reletadReference);
					//String freeText = ":21:" + reletadReference + "\r\n:90:" + status + "\r\n:91:" + description;
					//String freeText = ":21:" + reletadReference ;
					mt199.addField(field20);
					//Changes done by Ehsan
					mt199.addField(field21);
					String freeText="\r\nStatus Detail: "+description+"\r\n"+"Action required: "+action+"\r\n";
					Field79 field79 = new Field79("Payment Status: Rejected" +freeText);
					mt199.addField(field79);
					String mt199Message = mt199.message();
					
					String fileName = reqFileValue+concenateFileValue;
					boolean fileCreateStatus = fileUtils.createFile(mt199Message, customerId, fileName,
							macPaymentHeader.getMessageType());
					if (!fileCreateStatus) {
						macPaymentDetail.setMt199Status("FAILED");
					} else {
						macPaymentDetail.setMt199Status("GENERATED");
						macPaymentDetail.setMt199Data(mt199Message.getBytes());
						macPaymentDetail.setMt199SentTime(new Timestamp(new Date().getTime()));
						logger.info("MT199 File generated successfully ");
						writeEnvelopeFile(fileName,customerId,compName,swNetServicName,custNameFull,fileReference);
					}
				} catch (FileHandlerException e) {
					logger.error("Error : " + e.getMessage(), e);
					macPaymentDetail.setMt199Status("FAILED");
				} catch (Exception e) {
					logger.error("Error : " + e.getMessage(), e);
					macPaymentDetail.setMt199Status("FAILED");
				}
				updateDetails(macPaymentDetail);
			}
		}
			            // File-Act format 
						// For existing customer will receive files one transaction one mt199  file and save the file in MacPaymentDetail table 
			if(messageType.equalsIgnoreCase("FILE_ACT")) {
			try {
				
				                DateFormat dfToday = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
								ObjectFactory responseObjectFactory = new ObjectFactory();
								PaymentFileActResponse response = responseObjectFactory.createPaymentFileActResponse();
								PaymentFileActResponse.Header header  = responseObjectFactory.createPaymentFileActResponseHeader();
								header.setSender("BSFK");
								header.setReceiver(customerId);
								header.setMessageType("MT101Response");
								header.setMessageDescription("Payment Response Message");
								//header.setTimeStamp(new Date());
								header.setTimeStamp(dfToday.format(new Date()));
								response.setHeader(header);
								//create body 
								PaymentFileActResponse.Body body=responseObjectFactory.createPaymentFileActResponseBody();
								//create PaymentResponse
								PaymentFileActResponse.Body.PaymentResponse paymentResponse=responseObjectFactory.createPaymentFileActResponseBodyPaymentResponse();
								paymentResponse.setPaymentMessageRef(macPaymentHeader.getFileReference());
								paymentResponse.setPaymentMessageType("MT199-PaymentResponse");
								String frameMultiResopnse=frameMultipleResponseMT199(list);
								paymentResponse.setPaymentMessageBlock(frameMultiResopnse);
								//set PaymentResponse to body
								body.setPaymentResponse(paymentResponse);
							    //set body to response
								response.setBody(body);
							responseFileAct=	convertPaymentFileActResponseToString(response);
														
							String fileName = reqFileValue+concenateFileValue;
							
							boolean fileCreateStatus = fileUtils.createFile(responseFileAct, customerId, fileName,macPaymentHeader.getMessageType());
							
							
							if (!fileCreateStatus) {
								//macPaymentDetail.setMt199Status("FAILED");
								macPaymentHeader.setMt199Status("FAILED");
							} else {
								macPaymentHeader.setMt199Status("GENERATED");
								macPaymentHeader.setMt199Data(responseFileAct.getBytes());
								macPaymentHeader.setProcessingStatus(0);
								macPaymentHeader.setProcessedTime(new Timestamp(new Date().getTime()));
								logger.info("MT199 File generated successfully ");
								writeEnvelopeFile(fileName,customerId,compName,swNetServicName,custNameFull,macPaymentHeader.getFileReference());
								logger.info("Envelope File generated successfully ");
							}
						}
							/*catch (FileHandlerException e) {
								logger.error("Error : " + e.getMessage(), e);
								macPaymentHeader.setMt199Status("FAILED");
							}*/
							catch(Exception e) {
								logger.error("Error : " + e.getMessage(), e);
								macPaymentHeader.setMt199Status("FAILED");
							}
			paymentService.updateHeader(macPaymentHeader);
			}
						
			// All file will be saved in MacPaymentHeader table
			if(messageType.equalsIgnoreCase("FIN")&&mt199BulkFlag.trim().equals("Y")) {	
				Field20 field20 = new Field20(fileReference);
				MT199 mt199 = new MT199();
				String mt199Message ="";
				try {
				for (MacPaymentDetail macPaymentDetail : list) {
					mt199.setReceiver(customerId);
					mt199.setSender("BSFRSARIXXX");
					String reletadReference = macPaymentDetail.getTransactionReference();
					String status = macPaymentDetail.getStatus();
					String description = macPaymentDetail.getDescription();
					String action=macPaymentDetail.getAction();
					//macPaymentDetail.getDescription()
					
					Field21 field21=new Field21(reletadReference);
					mt199.addField(field20);
					//Changes done by Ehsan
					mt199.addField(field21);
					if(macPaymentDetail.getStatus().equals("OK")) {					
						String freeText="\r\nStatus Detail: "+description+"\r\n"+"Action required: "+action+"\r\n";
						Field79 field79 = new Field79("Payment Status: Success - " +freeText);
						mt199.addField(field79);
						mt199Message = mt199.message();	
					}
					else {
						String freeText="\r\nStatus Detail: "+description+"\r\n"+"Action required: "+action+"\r\n";
						Field79 field79 = new Field79("Payment Status: Rejected" +freeText);
						mt199.addField(field79);
						mt199Message = mt199.message();	
					}
				}
				
				String fileName = reqFileValue+concenateFileValue;
				boolean fileCreateStatus = fileUtils.createFile(mt199Message, customerId, fileName,macPaymentHeader.getMessageType());
				if (!fileCreateStatus) {
					macPaymentHeader.setMt199Status("FAILED");
				} else {
					macPaymentHeader.setMt199Status("GENERATED");
					macPaymentHeader.setMt199Data(mt199Message.getBytes());
					macPaymentHeader.setProcessingStatus(0);
					//macPaymentHeader.setMt199SentTime(new Timestamp(new Date().getTime()));
					logger.info("MT199 File generated successfully ");
					writeEnvelopeFile(fileName,customerId,compName,swNetServicName,custNameFull,macPaymentHeader.getFileReference());
					logger.info("Envelope File generated successfully ");
				}
			   
				}
				catch (Exception e) {
					logger.error("Error : " + e.getMessage(), e);
					macPaymentHeader.setMt199Status("FAILED");
				
				}
				 paymentService.updateHeader(macPaymentHeader);	
			}
		}
			catch(Exception e) {
				logger.error("Error : " + e.getMessage(), e);
				macPaymentHeader.setMt199Status("FAILED");	
			}
		
				
			}
		
	
	private String frameMultipleResponseMT199(List<MacPaymentDetail> list) {
		String customerId = macPaymentHeader.getCustomerId();
		String fileReference = macPaymentHeader.getFileReference();
		//Field20 field20 = new Field20(fileReference);
		String mt199Message="";
		MT199 mt199 = new MT199();
		Field20 field20 = new Field20(fileReference);
		mt199.addField(field20);
		for (MacPaymentDetail macPaymentDetail : list) {
			try {
			
				
				mt199.setReceiver(customerId);
				mt199.setSender("BSFRSARIXXX");
				String reletadReference = macPaymentDetail.getTransactionReference();
				String status = macPaymentDetail.getStatus();
				String description = macPaymentDetail.getDescription();
				String action=macPaymentDetail.getAction();
				
				Field21 field21=new Field21(reletadReference);
				
				//Changes done by Ehsan
				mt199.addField(field21);
			 
			   if(macPaymentDetail.getStatus().equals("OK")) {
					 //String freeText="\r\n91:"+"0000"+"\r\n"+"92: "+ "Success"+"\r\n"+"21:"+reletadReference+"\r\n";
						String freeText="\r\n91:"+"0000"+"\r\n"+"92: "+ "Success - "+macPaymentDetail.getDescription();
					Field79 field79 = new Field79("21:"+reletadReference +freeText);
					mt199.addField(field79);
					}
					else {
								
					//String freeText="\r\n91:"+"0033"+"\r\n"+"92:"+ "Failed - "+macPaymentDetail.getDescription()+ "\r\n"+"21:"+fileReference+"\r\n";
					   String freeText="\r\n91:"+"0033"+"\r\n"+"92:"+ "Failed - "+macPaymentDetail.getDescription();
						Field79 field79 = new Field79("21:"+fileReference +freeText);	
						mt199.addField(field79);
					}
				
				mt199Message = mt199.message();
				
				//paymentMessageBlock.append(mt199Message);
				
			} 
			catch (Exception e) {
					   
				logger.error("Error : " + e.getMessage(), e);
				macPaymentDetail.setMt199Status("FAILED");
			}
			updateDetails(macPaymentDetail);
		}
		return mt199Message;
	}
	/*
	private List<String> frameMultipleResponseMT199(List<MacPaymentDetail> list) {
		String customerId = macPaymentHeader.getCustomerId();
		String fileReference = macPaymentHeader.getFileReference();
		//Field20 field20 = new Field20(fileReference);
		List<String> paymentMessageBlock =new ArrayList<>();   
		for (MacPaymentDetail macPaymentDetail : list) {
			try {
			
				MT199 mt199 = new MT199();
				mt199.setReceiver(customerId);
				mt199.setSender("BSFRSARIXXX");
				String reletadReference = macPaymentDetail.getTransactionReference();
				String status = macPaymentDetail.getStatus();
				String description = macPaymentDetail.getDescription();
				String action=macPaymentDetail.getAction();
				Field20 field20 = new Field20(fileReference);
				Field21 field21=new Field21(reletadReference);
				mt199.addField(field20);
				//Changes done by Ehsan
				mt199.addField(field21);
			   if(macPaymentDetail.getStatus().equals("DE")) {
					String freeText="\r\n91:"+"0033"+"\r\n"+"92:"+ "Failed - "+macPaymentDetail.getDescription()+ "\r\n"+"21:"+fileReference+"\r\n";
					Field79 field79 = new Field79("21:"+fileReference +freeText);	
					mt199.addField(field79);
				}
				else {
				String freeText="\r\n91:"+"0000"+"\r\n"+"92: "+ "Success"+"\r\n"+"21:"+reletadReference+"\r\n";
				Field79 field79 = new Field79("21:"+reletadReference +freeText);
				mt199.addField(field79);
				}
				
				String mt199Message = mt199.message();
				System.out.println("mt199Message--"+mt199Message);
				paymentMessageBlock.add(mt199Message);
				
			} 
			catch (Exception e) {
					   
				logger.error("Error : " + e.getMessage(), e);
				macPaymentDetail.setMt199Status("FAILED");
			}
			updateDetails(macPaymentDetail);
		}
		return paymentMessageBlock;
	}

	private void updateHeader(MacPaymentHeader macPaymetHeader) {
		try {
			paymentService.updateHeader(macPaymetHeader);
		}
		catch(Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
	}
*/
	private void updateDetails(MacPaymentDetail macPaymentDetail) {
		try {
			paymentService.updateDetail(macPaymentDetail);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		
	}
	
	//Added by Ehsan for Payment/mt101 File-Act Response 
	public String convertPaymentFileActResponseToString(PaymentFileActResponse response) {
        String strFinalResponse = "";
        JAXBContext jaxbContext;
        try {
               jaxbContext = JAXBContext.newInstance(PaymentFileActResponse.class);
               Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
               StringWriter sw = new StringWriter();
               jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
               jaxbMarshaller.marshal(response, sw);
               strFinalResponse = sw.toString();
        } catch (JAXBException e) {
               logger.error("Error in framing final response. Error " + e.getMessage(), e);
        } catch (Exception e) {
               logger.error("Error in framing final response. Error " + e.getMessage(), e);
        }
        return strFinalResponse;
 }
	
	
	public void setHeaderObj(MacPaymentHeader macPaymentHeader) {
		this.macPaymentHeader = macPaymentHeader;
	}
	
	
	public void setEnvelopSourcePath(String envelopSourcePath) {
		this.envelopSourcePath = envelopSourcePath;
	}


	public boolean writeEnvelopeFile(String actualFileLocation,String 
			customerId,String customerName,String swNetServicName,String custNameFull,String fileReference) {
		
		//String sourceEnvelopePath="D:\\macug\\sftp\\fileact_response\\source\\";
		Random r = new Random( System.currentTimeMillis() );
	    int count= ((1 + r.nextInt(2)) * 10000 + r.nextInt(10000));
		//String sourceEnvelopePath="D:\\macug\\MT101TestFile\\FTP";
		
		StringBuffer fileContent=new StringBuffer();
        fileContent.append("0000 APP_APPLI_CODE "+"FICOUT");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_FILE_NB 000001");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_FLOW IMPORT");
        fileContent.append(Character.toString ((char)23));
        fileContent.append(Character.toString ((char)3));
        fileContent.append("\n");
        fileContent.append("0101 APP_MSG_NB 001");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_COMPANY BSF");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_SERVICE FILEACT");
        fileContent.append(Character.toString ((char)23));
        
        fileContent.append("APP_TRANS_CODE ");
        //fileContent.append(Character.toString ((char)23));
        fileContent.append("FACT_MACUGRT");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_CORR_ID ");
        //it should be from database
        fileContent.append(custNameFull);
        fileContent.append(Character.toString ((char)23));
        
        fileContent.append("APP_REQUESTOR_DN ");
        
        fileContent.append("o=bsfrsari,o=swift");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_FILE_DESC ");
        
        fileContent.append("MT101");
        fileContent.append(Character.toString ((char)23));   
         
        
        fileContent.append("APP_MSG_NAT FIC");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_MSG_TYPE FIC"); 
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_MSG_PRIO_CAT ");
       // fileContent.append("\n");
        fileContent.append("N"+Character.toString ((char)23));
        fileContent.append("APP_MSG_TXT_TYPE FIC");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_RESPONDER_DN o=");
        
        //fileContent.append("o="+actualFileLocation.substring(21,29)+","+"o=swift");
        fileContent.append(customerName+",o=swift");
        fileContent.append(Character.toString ((char)23));
        
        fileContent.append("APP_SWNET_SERVICE ");
        
        //fileContent.append("bsfrsa.macugst!p");
        fileContent.append(swNetServicName);
        fileContent.append(Character.toString ((char)23));
        
        fileContent.append("APP_REQ_TYPE ");
        fileContent.append("pacs.fin.mt9xx");
        fileContent.append(Character.toString ((char)23));
        
        fileContent.append("APP_MSG_TXT ");
        //fileContent.append("\n");
        
       // fileContent.append("/stelinkt/fileact/BLK/Storage/ActualFileToBeSent.xml");
        //System.out.println("---Remote path "+"/stelink/v2.2/fileact/out/"+actualFileLocation.substring(34));
        fileContent.append("/stelink/v2.2/fileact/out/"+actualFileLocation);
        
       // fileContent.append("N"+Character.toString ((char)23));
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_ENDFCT EOM");
        fileContent.append(Character.toString ((char)23));
        fileContent.append(Character.toString ((char)3));
        fileContent.append("\n");
        fileContent.append("0000 APP_ENDFILE EOF");
        fileContent.append(Character.toString ((char)23));
        fileContent.append(Character.toString ((char)3));
        
        byte[] byRemoteContents = null;
       //   String todayPath=fielUtils.createTodayFolder(sourceEnvelopePath);
        //String pattern = "yyyyMMddHHmmss"; 
        String pattern = "yyyyMMddHHmmssSS";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        String date = simpleDateFormat.format(new Date());
        
        try {
      // 	Map<String, Map<String, SystemParameters>> allProperties = utils.loadSystemProperties();
    //	Map<String, SystemParameters> macPathProperties = allProperties.get("macPathMap");
    //	String sourcePath = systemParameterService.getSystemParametersDescription2("ENVELOP_FILE",macPathProperties);	
    	System.out.println("envelopSourcePath--"+envelopSourcePath);
        byRemoteContents=fileContent.toString().getBytes();
        String path= envelopSourcePath+"/envelop_"+date+"_"+fileReference+".txt";
        logger.info("envelop file path :"+path);
        FileOutputStream fout = new FileOutputStream(path);
		fout.write(byRemoteContents, 0, byRemoteContents.length);
		fout.close();
        }
        catch(Exception fn) {
       	return false; 	
        }
       
		return true;
	}

}
