package com.bsf.macug.mt101.service.thread;

import java.io.FileOutputStream;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.service.InterCustomerDetailsService;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.exception.FileHandlerException;
import com.bsf.macug.mt101.dto.fileact.response.ObjectFactory;
import com.bsf.macug.mt101.dto.fileact.response.PaymentFileActResponse;
import com.bsf.macug.mt101.entity.MacPaymentActivityLog;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.entity.MacPaymentHeader;
import com.bsf.macug.mt101.service.InterPaymentService;

import com.bsf.macug.util.InterFileUtils;
import com.prowidesoftware.swift.model.field.Field20;
import com.prowidesoftware.swift.model.field.Field21;
import com.prowidesoftware.swift.model.field.Field79;
import com.prowidesoftware.swift.model.field.Field91A;
import com.prowidesoftware.swift.model.field.Field92A;
import com.prowidesoftware.swift.model.mt.mt1xx.MT199;

@Component
@Scope("prototype")
public class MT199BasicValidationService implements Runnable {
	private static final Logger logger = Logger.getLogger(MT199BasicValidationService.class.getName());

	private MacPaymentActivityLog macPaymnetActivLog;
	
	private String envelopSourcePath;

	@Autowired
	InterPaymentService paymentService;
	
	@Autowired
	InterCustomerDetailsService customerDetailsService;

	@Autowired
	InterFileUtils fileUtils;
	
	private String customerId ="";

	@Override
	public void run() {
		String responseFileAct="";
		
		try {

			String fileReference = " ";
			//String customerID=macPaymentHeader.getCustomerId() ;
			
			//String messageType=macPaymnetActivLog.getProcessType();
	     	String  reqFileName=macPaymnetActivLog.getCustReqFile();
	     	
			MacPaymentActivityLog macPaymActivLog=paymentService.getPaymentProcessLogByFileName(reqFileName);
			
			String messageType=macPaymnetActivLog.getProcessType();
			
			List<MacPaymentActivityLog> list=new ArrayList<MacPaymentActivityLog>();
			list.add(macPaymActivLog);
			customerId = macPaymnetActivLog.getCustomerId();
			
			CustomerDetails customerDetails=customerDetailsService.getCustomerDetails(customerId);
			
			if (customerDetails == null) {
				logger.info("Customer not registred. ");
				throw new CustomerNotFoundException("Customer not registred.");
			}
			
		String swNetServicName=customerDetails.getSwNetServicName();
			
			if(StringUtils.isEmpty(swNetServicName)) {
				logger.info("SWNET_SERVICE Field = "+swNetServicName);	
				throw new Exception("SWNET_SERVICE Field is null");
			}
			
			/*if(StringUtils.isEmpty(concenateFileValue) ) {
				logger.info("File response column value is = "+concenateFileValue);	
				throw new Exception("File response column value is null");
			}*/
			String custNameFull=customerDetails.getCustNameFull();
			
			if(StringUtils.isEmpty(custNameFull)) {
				logger.info("Customer Name Full = "+custNameFull);	
				throw new Exception("Customer Full name is null");
				
			}
			
			String mt199BulkFlag=customerDetails.getMt199BulkFlag();
			if(StringUtils.isEmpty(mt199BulkFlag)) {
				logger.info("MT199 Bulk Flag = "+mt199BulkFlag);	
				throw new Exception("MT199 Bulk Flag is null");
				
			}
			
			String compName=customerDetails.getCustomerName();
			
			if(StringUtils.isEmpty(compName)) {
				logger.info("Customer name = "+compName);	
				throw new Exception("Customer name is null");
				
			}
			
			
			// Fin format 
			//For existing customer will receive files one transaction one mt199  file and save the file in MacPaymentDetail table 
			 if(messageType.equalsIgnoreCase("FIN")) {
			try {
					Field20 field20 = new Field20(fileReference);
					Field21 field21=new Field21(fileReference);
					MT199 mt199 = new MT199();
					mt199.setReceiver(customerId);
					mt199.setSender("BSFRSARIXXX");
					mt199.addField(field20);
					//Changes done by Ehsan
					mt199.addField(field21);
					String freeText="\r\nStatus Detail: "+macPaymActivLog.getProcessDescription()+"\r\n"+"Action required: "+macPaymActivLog.getProcessDescription()+"\r\n";
					Field79 field79 = new Field79("Payment Status: Rejected" +freeText);
					mt199.addField(field79);
					//mt199.addField(field79.setNarrativeLine14(freeText));
					
					String mt199Message = mt199.message();
					
					String rquFile=macPaymnetActivLog.getCustReqFile();
					String appendFilePart=macPaymnetActivLog.getResponseFileValue();
					
					String fileName = rquFile+appendFilePart;
					boolean fileCreateStatus = fileUtils.createFile(mt199Message, customerId, fileName,
							macPaymnetActivLog.getProcessType());
					if (!fileCreateStatus) {
						macPaymnetActivLog.setResStatus("FAILED");
					} else {
						macPaymnetActivLog.setProcessStatus(2);
						macPaymnetActivLog.setResStatus("GENERATED");
						logger.info("MT199 File generated successfully ");
						writeEnvelopeFile(fileName,customerId,compName,swNetServicName);
						logger.info("Envelope File generated successfully ");
					}
				} catch (FileHandlerException e) {
					logger.error("Error : " + e.getMessage(), e);
					macPaymnetActivLog.setResStatus("FAILED");
				} catch (Exception e) {
					logger.error("Error : " + e.getMessage(), e);
					macPaymnetActivLog.setResStatus("FAILED");
				}
			
		}
			
			            // File-Act format 
						// For existing customer will receive files one transaction one mt199  file and save the file in MacPaymentDetail table 
			if(messageType.equalsIgnoreCase("FILE_ACT")) {
			
							try {
								DateFormat dfToday = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
								ObjectFactory responseObjectFactory = new ObjectFactory();
								PaymentFileActResponse response = responseObjectFactory.createPaymentFileActResponse();
								PaymentFileActResponse.Header header  = responseObjectFactory.createPaymentFileActResponseHeader();
								header.setSender("BSFK");
								header.setReceiver(customerId);
								header.setMessageType("MT101Response");
								header.setMessageDescription("Payment Response Message");
								//header.setTimeStamp(new Date());
								header.setTimeStamp(dfToday.format(new Date()));
								response.setHeader(header);
								//response.setHeader(header);
								//create body 
								PaymentFileActResponse.Body body=responseObjectFactory.createPaymentFileActResponseBody();
								//create PaymentResponse
								
								PaymentFileActResponse.Body.PaymentResponse paymentResponse=responseObjectFactory.createPaymentFileActResponseBodyPaymentResponse();
								
								
								
								//set values to PaymentResponse
								
								//paymentResponse.setPaymentMessageRef(macPaymentDetail.getFileReference());
								paymentResponse.setPaymentMessageRef("MacFileReference");
							    paymentResponse.setPaymentMessageType("MT199-PaymentResponse");
								
								

								String frameMultiResopnse=frameMultipleResponseMT199(list);
								paymentResponse.setPaymentMessageBlock(frameMultiResopnse);	
								
								//set PaymentResponse to body
								body.setPaymentResponse(paymentResponse);
							    //set body to response
								response.setBody(body);
							
							responseFileAct=	convertPaymentFileActResponseToString(response);
							//for (MacPaymentDetail macPaymentDetail : list) {
							String rquFile=macPaymnetActivLog.getCustReqFile();
							String appendFilePart=macPaymnetActivLog.getResponseFileValue();
							
							String fileName =rquFile+ appendFilePart;
							boolean fileCreateStatus = fileUtils.createFile(responseFileAct, customerId, fileName,macPaymnetActivLog.getProcessType());
							
							
							if (!fileCreateStatus) {
								macPaymnetActivLog.setResStatus("FAILED");
								
							} else {
							
								macPaymnetActivLog.setProcessStatus(2);
								macPaymnetActivLog.setResStatus("GENERATED");
								logger.info("MT199 File generated successfully ");
								//customerId,String customerName,String swNetServicName
								writeEnvelopeFile(fileName,customerId,compName,swNetServicName);
								
								logger.info("Envelpe File generated successfully ");
							}
							
							
						}
							catch (FileHandlerException e) {
								logger.error("Error : " + e.getMessage(), e);
								macPaymnetActivLog.setResStatus("FAILED");
							}
							catch(Exception e) {
								logger.error("Error : " + e.getMessage(), e);
								macPaymnetActivLog.setResStatus("FAILED");
							}
							
							
			}
			
		
			
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		
		try {
			paymentService.updatePaymnetProcessLog(macPaymnetActivLog);
			
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
	}
	
	private String frameMultipleResponseMT199(List<MacPaymentActivityLog> list) {
		String customerId =" "; //macPaymentHeader.getCustomerId();
		String fileReference ="  "; //macPaymentHeader.getFileReference();
		String mt199Message="";
		List<String> paymentMessageBlock =new ArrayList<>();   
		for (MacPaymentActivityLog macPaymentDetail : list) {
			try {
			
				MT199 mt199 = new MT199();
				
				mt199.setReceiver(customerId);
				mt199.setSender("BSFRSARIXXX");
				//String reletadReference = macPaymentDetail.getTransactionReference();
				//String status = macPaymentDetail.getStatus();
				//String description = macPaymentDetail.getDescription();
				//String action=macPaymentDetail.getAction();
				
				Field21 field21=new Field21(fileReference);
				Field20 field20 = new Field20(fileReference);
				
				mt199.addField(field20);
				
				
				//Changes done by Ehsan
				mt199.addField(field21);
				
				//String freeText="\r\n91:"+"0033"+"\r\n"+"92:"+ "Failed - "+macPaymentDetail.getProcessDescription()+ "\r\n"+"21:"+fileReference+"\r\n";
				String freeText="\r\n91:"+"0033"+"\r\n"+"92:"+ "Failed - "+macPaymentDetail.getProcessDescription();
				Field79 field79 = new Field79("21:"+fileReference +freeText);
				
				mt199.addField(field79);
				
				mt199Message = mt199.message();
		
				//paymentMessageBlock.add(mt199Message);
				
			} 
			
			catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
				macPaymentDetail.setResStatus("NOT_GENERATED");
			}
			//updateDetails(macPaymentDetail);
		}
		return mt199Message;
	}

	
	//Added by Ehsan for Payment/mt101 File-Act Response 
	public String convertPaymentFileActResponseToString(PaymentFileActResponse response) {
        String strFinalResponse = "";
        JAXBContext jaxbContext;
        try {
               jaxbContext = JAXBContext.newInstance(PaymentFileActResponse.class);
               Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
               StringWriter sw = new StringWriter();
               jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
               jaxbMarshaller.marshal(response, sw);
               strFinalResponse = sw.toString();
        } catch (JAXBException e) {
               logger.error("Error in framing final response. Error " + e.getMessage(), e);
        } catch (Exception e) {
               logger.error("Error in framing final response. Error " + e.getMessage(), e);
        }
        return strFinalResponse;
 }
	
public boolean writeEnvelopeFile(String actualFileLocation,String customerId,String customerName,String swNetServicName) {
		
	  // Random r = new Random( System.currentTimeMillis() );
      // int count= ((1 + r.nextInt(2)) * 10000 + r.nextInt(10000));
	     Random r = new Random();
	     int count=r.nextInt(100000);
		//String sourceEnvelopePath=getProperty().getProperty("fileactpayment.upload.sourcepath.envelope");
       // String sourceEnvelopePath="D:\\macug\\sftp\\fileact_response\\source\\";
		StringBuffer fileContent=new StringBuffer();
        //fileContent.append("0000 APP_APPLI_CODE APP1 "+"FICOUT");
		fileContent.append("0000 APP_APPLI_CODE "+"FICOUT");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_FILE_NB 000001");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_FLOW IMPORT");
        fileContent.append(Character.toString ((char)23));
        fileContent.append(Character.toString ((char)3));
        fileContent.append("\n");
        fileContent.append("0101 APP_MSG_NB 001");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_COMPANY BSF");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_SERVICE FILEACT");
        fileContent.append(Character.toString ((char)23));
        
        fileContent.append("APP_TRANS_CODE ");
        //fileContent.append(Character.toString ((char)23));
        fileContent.append("FACT_MACUGRT");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_CORR_ID ");
        //it should be from database
        fileContent.append(customerId);
        fileContent.append(Character.toString ((char)23));
        
        fileContent.append("APP_REQUESTOR_DN ");
        
        fileContent.append("o=bsfrsari,o=swift");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_FILE_DESC ");
        
        fileContent.append("MT101");
        fileContent.append(Character.toString ((char)23));   
         
        
        fileContent.append("APP_MSG_NAT FIC");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_MSG_TYPE FIC"); 
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_MSG_PRIO_CAT ");
       // fileContent.append("\n");
        fileContent.append("N"+Character.toString ((char)23));
        fileContent.append("APP_MSG_TXT_TYPE FIC");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_RESPONDER_DN o=");
        
        //fileContent.append("o="+actualFileLocation.substring(21,29)+","+"o=swift");
        fileContent.append(customerName+",o=swift");
        fileContent.append(Character.toString ((char)23));
        
        fileContent.append("APP_SWNET_SERVICE ");
        
        //fileContent.append("bsfrsa.macugst!p");
        fileContent.append(swNetServicName);
        fileContent.append(Character.toString ((char)23));
        
        fileContent.append("APP_REQ_TYPE ");
        fileContent.append("pacs.fin.mt9xx");
        fileContent.append(Character.toString ((char)23));
        
        fileContent.append("APP_MSG_TXT ");
        //fileContent.append("\n");
        
       // fileContent.append("/stelinkt/fileact/BLK/Storage/ActualFileToBeSent.xml");
        //System.out.println("---Remote path "+"/stelink/v2.2/fileact/out/"+actualFileLocation.substring(34));
        fileContent.append(actualFileLocation);
        
       // fileContent.append("N"+Character.toString ((char)23));
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_ENDFCT EOM");
        fileContent.append(Character.toString ((char)23));
        fileContent.append(Character.toString ((char)3));
        fileContent.append("\n");
        fileContent.append("0000 APP_ENDFILE EOF");
        fileContent.append(Character.toString ((char)23));
        fileContent.append(Character.toString ((char)3));
        
        byte[] byRemoteContents = null;
        //FileUtils fielUtils=new FileUtils();
        //String todayPath=fielUtils.createTodayFolder(sourceEnvelopePath);
        //String pattern = "yyyyMMddHHmmss"; 
        String pattern = "yyyyMMddHHmmssSS";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        String date = simpleDateFormat.format(new Date());
        
        try {
        byRemoteContents=fileContent.toString().getBytes();
        String path= envelopSourcePath+"/envelop_"+date+".txt";
        logger.info("envelop file path : "+path);
        FileOutputStream fout = new FileOutputStream(envelopSourcePath+"/envelop_"+date+count+".txt");
		fout.write(byRemoteContents, 0, byRemoteContents.length);
		fout.close();
        }
        catch(Exception fn) {
       	return false; 	
        }
       
		return true;
	}

	
	
	public void setActivityLogObj(MacPaymentActivityLog macPaymnetActivLog) {
		this.macPaymnetActivLog = macPaymnetActivLog;
	}
	
	public void setEnvelopSourcePath(String envelopSourcePath) {
		this.envelopSourcePath = envelopSourcePath;
	}

}
