package com.bsf.macug.mt101.service.thread;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.service.InterCustomerDetailsService;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.exception.DuplicateFileException;
import com.bsf.macug.exception.FileHandlerException;
import com.bsf.macug.exception.InvalidRequestDateTimeException;
import com.bsf.macug.exception.SystemPropertyNotConfigurationException;
import com.bsf.macug.exception.TagNotFoundException;
import com.bsf.macug.exception.ValidationException;
import com.bsf.macug.exception.XMLParsingException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.dto.fileact.request.Message;
import com.bsf.macug.mt101.entity.MacFileLog;
import com.bsf.macug.mt101.entity.MacPaymentActivityLog;
import com.bsf.macug.mt101.entity.MacPaymentHeader;
import com.bsf.macug.mt101.service.InterMT100Util;
import com.bsf.macug.mt101.service.InterPaymentService;
import com.bsf.macug.util.InterFileUtils;
import com.bsf.macug.util.InterUtils;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.field.Field;

@Component
@Scope("prototype")
public class ProcessNewFileActFile implements Runnable {
	private static final Logger logger = Logger.getLogger(ProcessNewFileActFile.class.getName());
    
	
	@Autowired
	InterCustomerDetailsService customerDetailsService;
		
	@Autowired
	InterFileUtils fileUtils;

	@Autowired
	InterPaymentService paymentService;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterMT100Util mT100Util;

	@Autowired
	InterUtils utils;

	private String sourcePath;

	public void run() {
		logger.info("Thread started for : " + sourcePath);
		
		File sourcFileName=new File(sourcePath);
		logger.info("FileName "+sourcFileName.getName());
		boolean parsedSucessfully = false;
		String destinationPath = null;
		String errorPath = null;
		String fileName = null;
		String sender="";
		boolean fileMovedToDestination = false;
		File destinationFile = null;
		Map<String, Map<String, SystemParameters>> allProperties = null;
		MacFileLog fileLog = null;
		try {
			allProperties = utils.loadSystemProperties();
			Map<String, SystemParameters> macPathProperties = (Map<String, SystemParameters>) allProperties
					.get("macPathMap");
			Map<String, SystemParameters> macPropertyMap = (Map<String, SystemParameters>) allProperties
					.get("macPropertyMap");

			destinationPath = systemParameterService.getSystemParametersDescription2("MT101_FIL_DEST",
					macPathProperties);

			errorPath = systemParameterService.getSystemParametersDescription2("MT101_FIL_ERR", macPathProperties);

			byte[] requestData = fileUtils.readFile(sourcePath);
			UUID uuid = UUID.randomUUID();
			String uniqueId = uuid.toString();
             
			///  Log saving 
			fileLog = mT100Util.saveLog(uniqueId, requestData);
			

			File sourceFile = new File(sourcePath);
			fileName = sourceFile.getName();
			String fileNameWithoutExt=sourceFile.getName();
			
			
			
			/*MacPaymentActivityLog macPaymnetActivLog=paymentService.getPaymentProcessLogByFileName(fileNameWithoutExt.substring(0,fileNameWithoutExt.lastIndexOf('.')));
			
			if(macPaymnetActivLog!=null) {
				throw new ValidationException("Same file already exist in destination folder. Failed to move."+fileNameWithoutExt);	
			}*/
			
			destinationFile = new File(destinationPath + fileName);

			fileUtils.moveFile(sourceFile, destinationFile, "FILE_ACT");
			fileMovedToDestination = true;

			String data = new String(requestData, "UTF-8");
			data = data.trim();
			data = utils.removeStealinkCharacter(data.getBytes("UTF-8"));			
			Message message = mT100Util.parseXMLMessage(data);
			Message.Header header = message.getHeader();
			if (header == null) {
				throw new TagNotFoundException("header Tag");
			}
			Message.Body body =message.getBody();
			if (body == null) {
				throw new TagNotFoundException("Body Tag");
			}

			sender = header.getSender();
			String reciver = header.getReceiver();
			
			
			
			
			//String fileNameDB=macPaymnetActivLog.getCustReqFile()+".dat";
			
			
			
			if (StringUtils.isEmpty(sender)) {
				throw new ValidationException("Invalid Sender or Sender tag is missing");
			}

			if (StringUtils.isEmpty(reciver)) {
				throw new ValidationException("Invalid Reciever or Reciever tag is missing");
			}

			Message.Body.PaymentMessageRequest requestObj = body.getPaymentMessageRequest();
			if (requestObj == null) {
				throw new TagNotFoundException("PaymentMessageRequest");
			}

			boolean validTimeStamp = mT100Util.checkIfValidRequestDateTime(header.getTimeStamp(), macPropertyMap);
			if (!validTimeStamp) {
				throw new InvalidRequestDateTimeException(header.getTimeStamp() + " is invalid.");
			}

			String fileId = requestObj.getPaymentMessageRef();
			if (StringUtils.isEmpty(fileId)) {
				throw new ValidationException("Invalid fileId.");
			}

			boolean fileExistFlag=mT100Util.checkIfFileIdExists(fileId, sender);
			
			if(fileExistFlag) {
			throw new ValidationException("Same file already exist in destination folder. Failed to move."+fileNameWithoutExt);	
		    }

			String mtData = requestObj.getPaymentMessageBlock();

			SwiftMessage sm = SwiftMessage.parse(mtData);
			Field[] fi = sm.getBlock4().getFieldsByName("20");
			Field field20 = fi[0];

			MacPaymentHeader headerObj = new MacPaymentHeader();
			
				
			
			CustomerDetails customerDetails = customerDetailsService.getCustomerDetails(sender);
			if (customerDetails == null) {
				throw new CustomerNotFoundException("Customer not registred.");
			}
						
			headerObj.setId(uniqueId);
			headerObj.setCustomerId(sm.getSender().substring(0, 8));
			headerObj.setFileReference(field20.getValue());
			headerObj.setRequestContent(requestData);
			headerObj.setMtContent(mtData.getBytes("UTF-8"));
			headerObj.setMessageType("FILE_ACT");
			headerObj.setStatus("RECEIVED");
			headerObj.setDescription("Recieved successfully");
			headerObj.setProcessingStatus(Integer.valueOf(0));
			
			headerObj.setCustReqFile(fileNameWithoutExt.substring(0,fileNameWithoutExt.lastIndexOf('.')));
			headerObj.setResponseFileValue(customerDetails.getResponseFileValue());

			paymentService.saveHeader(headerObj);
			parsedSucessfully = true;
			/*if(parsedSucessfully) {
			fileLog.setStatus("OK");
			fileLog.setDescription("Saved in header. Check header for further details.");
			utils.logMT100Activity(sender,"PaymentHeader", "Payment header saved. Status "+parsedSucessfully, "FILE_ACT", sourcFileName.getName(),3);
			}*/
			} catch (FileHandlerException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(sender,"FAILED", "File reading failed "+e.getMessage(), "FILE_ACT", sourcePath,0);
		} catch (UnsupportedEncodingException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(sender,"FAILED", "Unsupported encoding "+e.getMessage(), "FILE_ACT", sourcePath,0);
		} catch (IOException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(sender,"FAILED", "File reading failed IO Error "+e.getMessage(), "FILE_ACT", sourcePath,0);
		} catch (XMLParsingException e) {
			logger.error("(processFile)==> Error while while parsing the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(sender,"FAILED", "XML parsing failed "+e.getMessage(), "FILE_ACT", sourcePath,0);
		} catch (ValidationException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getErrorCode(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getErrorCode());
			utils.logMT100Activity(sender,"FAILED", "Validation failed "+e.getErrorCode(), "FILE_ACT", sourcePath,0);
		} catch (TagNotFoundException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			   
			logger.error("Tag not found. Error : " + e.getTag(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getTag());
			utils.logMT100Activity(sender,"FAILED", "Tag not found "+e.getTag(), "FILE_ACT", sourcePath,0);
		} catch (InvalidRequestDateTimeException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(sender,"FAILED", "Invalid request datetime "+e.getMessage(), "FILE_ACT", sourcePath,0);
		} catch (SystemPropertyNotConfigurationException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			//fileLog.setStatus("FAILED");
			//fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(sender,"FAILED", "System property failed "+e.getMessage(), "FILE_ACT", sourcePath,0);
		} catch (DuplicateFileException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(sender,"FAILED", "Duplicate faile "+e.getMessage(), "FILE_ACT", sourcePath,0);
		} catch (Exception e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			if (fileLog != null) {
				fileLog.setStatus("FAILED");
				fileLog.setDescription(e.getMessage());
			}
			utils.logMT100Activity(sender,"FAILED", "Exception occured "+e.getMessage(), "FILE_ACT", sourcePath,0);
		}
		if ((!parsedSucessfully) && (fileMovedToDestination)) {
			try {
				File errorFile = new File(errorPath + fileName);
				fileUtils.moveFile(destinationFile, errorFile, "FILE_ACT");
			} catch (FileHandlerException e) {
				logger.error("Error : " + e.getMessage(), e);
			} catch (Exception e) {
				logger.error("Error : " + e.getMessage(), e);
			}
		}
		mT100Util.updateLog(fileLog);
		//utils.logMT100Activity("File Log", "File content saved to FILE log table", "FILE_ACT", sourcePath,3);
		logger.info("Thread ended for : " + sourcePath);
	}

	public String getReuestFileName() {
		return sourcePath;
	}

	public void setReuestFileName(String sourcePath) {
		this.sourcePath = sourcePath;
	}
	/*
	public void setActivityLogObj(MacPaymentActivityLog macPaymnetActivLog) {
		this.macPaymnetActivLog = macPaymnetActivLog;
	}*/
}
