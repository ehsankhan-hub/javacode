package com.bsf.macug.mt101.service.thread;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.service.InterCustomerDetailsService;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.exception.DuplicateFileException;
import com.bsf.macug.exception.FileHandlerException;
import com.bsf.macug.exception.SystemPropertyNotConfigurationException;
import com.bsf.macug.exception.ValidationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.entity.MacFileLog;
import com.bsf.macug.mt101.entity.MacPaymentHeader;
import com.bsf.macug.mt101.service.InterMT100Util;
import com.bsf.macug.mt101.service.InterPaymentService;
import com.bsf.macug.util.InterFileUtils;
import com.bsf.macug.util.InterUtils;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.field.Field;

@Component
@Scope("prototype")
public class ProcessNewFINFile implements Runnable {
	private static final Logger logger = Logger.getLogger(ProcessNewFINFile.class.getName());
    
	@Autowired
	InterCustomerDetailsService customerDetailsService;
	
	@Autowired
	InterFileUtils fileUtils;

	@Autowired
	InterPaymentService paymentService;

	@Autowired
	Environment environment;

	@Autowired
	InterMT100Util mT100Util;

	@Autowired
	InterUtils utils;

	@Autowired
	InterSystemParameterService systemParameterService;

	private String sourcePath;

	public void run() {
		logger.info("Thread started for : " + sourcePath);
		boolean parsedSucessfully = false;
		String destinationPath = null;
		String errorPath = null;
		String fileName = null;
		boolean fileMovedToDestination = false;
		File destinationFile = null;
		MacFileLog fileLog = null;
		String customer="";
		
		try {
			Map<String, Map<String, SystemParameters>> allProperties = utils.loadSystemProperties();
			Map<String, SystemParameters> macPathProperties = (Map<String, SystemParameters>) allProperties
					.get("macPathMap");

			destinationPath = systemParameterService.getSystemParametersDescription2("MT101_FIN_DEST",
					macPathProperties);

			errorPath = systemParameterService.getSystemParametersDescription2("MT101_FIN_ERR", macPathProperties);

			byte[] requestData = fileUtils.readFile(sourcePath);

			UUID uuid = UUID.randomUUID();
			String uniqueId = uuid.toString();
			fileLog = mT100Util.saveLog(uniqueId, requestData);

			//utils.logMT100Activity("","File Log", "File content saved to FILE log table", "FIN", sourcePath,3);

			File sourceFile = new File(sourcePath);
			String fileNameWithoutExt=sourceFile.getName();
			fileName = sourceFile.getName();
			destinationFile = new File(destinationPath + fileName);

			fileUtils.moveFile(sourceFile, destinationFile, "FIN");
			fileMovedToDestination = true;

			String data = new String(requestData, "UTF-8");
			data = data.trim();
			data = utils.removeStealinkCharacter(data.getBytes("UTF-8"));

			if (data.contains("(?!\r\n|\n)([^\\x20-\\x7e])")) {
				logger.error("Message contains arabic data.");
				throw new ValidationException("Arabic characters not allowed.");
			}
			
			SwiftMessage sm = SwiftMessage.parse(data);
			Field[] fi = sm.getBlock4().getFieldsByName("20");
			customer=sm.getSender().substring(0, 8);
			Field field20 = fi[0];

			if (StringUtils.isEmpty(sm.getSender())) {
				throw new ValidationException("Invalid sender.");
			}

			if (StringUtils.isEmpty(sm.getReceiver())) {
				throw new ValidationException("Invalid reciever.");
			}

			if (StringUtils.isEmpty(field20.getValue())) {
				throw new ValidationException("Invalid fileId.");
			}

			boolean fileExistFlag=mT100Util.checkIfFileIdExists(field20.getValue(), customer);
			
			if(fileExistFlag) {
				throw new ValidationException("Same file already exist in destination folder. Failed to move."+fileNameWithoutExt);	
			    }

			MacPaymentHeader header = new MacPaymentHeader();
			
			CustomerDetails customerDetails = customerDetailsService.getCustomerDetails(customer);
			if (customerDetails == null) {
				throw new CustomerNotFoundException("Customer not registred.");
			}
			
			header.setId(uniqueId);
			String strCustomer = sm.getSender().substring(0, 8);
			logger.info("Original customer ID " + sm.getSender() + " substring " + strCustomer);
			header.setCustomerId(strCustomer);
			header.setFileReference(field20.getValue());
			header.setMtContent(requestData);
			header.setMessageType("FIN");
			header.setStatus("RECEIVED");
			header.setDescription("Recieved successfully");
			header.setProcessingStatus(Integer.valueOf(0));
			header.setCustReqFile(fileNameWithoutExt.substring(0,fileNameWithoutExt.lastIndexOf('.')));
			header.setResponseFileValue(customerDetails.getResponseFileValue());
			paymentService.saveHeader(header);
			parsedSucessfully = true;
			/*fileLog.setStatus("OK");
			fileLog.setDescription("Saved in header. Check header for further details.");
			utils.logMT100Activity("","PaymentHeader", "Payment header saved. Status " + parsedSucessfully, "FIN", "", 3);*/
		} catch (FileHandlerException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(customer,"FAILED", "File reading failed " + e.getMessage(), "FIN", sourcePath,0);
		} catch (UnsupportedEncodingException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(customer,"FAILED", "Unsupported encoding " + e.getMessage(), "FIN", sourcePath,0);
		} catch (IOException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(customer,"FAILED", "File reading failed IO Error " + e.getMessage(), "FIN", sourcePath,0);
		} catch (ValidationException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getErrorCode(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getErrorCode());
			utils.logMT100Activity(customer,"FAILED", "Validation failed " + e.getErrorCode(), "FIN", sourcePath,0);
		} catch (DuplicateFileException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(customer,"FAILED", "Validation failed " + e.getMessage(), "FIN", sourcePath,0);
		} catch (SystemPropertyNotConfigurationException e) {
			logger.error("(processFile)==> Error while loading system properties" + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			utils.logMT100Activity(customer,"FAILED", "Validation failed " + e.getMessage(), "FIN", sourcePath,0);
		} catch (Exception e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			if (fileLog != null) {
				fileLog.setStatus("FAILED");
				fileLog.setDescription(e.getMessage());
			}
			utils.logMT100Activity(customer,"FAILED", "Exception occured " + e.getMessage(), "FIN", sourcePath,0);
		}
		if ((!parsedSucessfully) && (fileMovedToDestination)) {
			try {
				File errorFile = new File(errorPath + fileName);
				fileUtils.moveFile(destinationFile, errorFile, "FIN");
				utils.logMT100Activity("","Error file", "File moved to ERROR from " + destinationFile.getAbsolutePath(),
						"FIN", errorPath + fileName,0);
			} catch (FileHandlerException e) {
				logger.error("Error : " + e.getMessage(), e);
			} catch (Exception e) {
				logger.error("Error : " + e.getMessage(), e);
			}
		}
		mT100Util.updateLog(fileLog);
		logger.info("Thread ended for : " + sourcePath);
	}

	public String getReuestFileName() {
		return sourcePath;
	}

	public void setReuestFileName(String sourcePath) {
		this.sourcePath = sourcePath;
	}
}
