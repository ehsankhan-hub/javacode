package com.bsf.macug.mt101.service.thread;

import com.bsf.macug.customer.service.InterCustomerAccountsService;
import com.bsf.macug.exception.ValidationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.entity.MacPaymentHeader;
import com.bsf.macug.mt101.service.InterAccountToAccountService;
import com.bsf.macug.mt101.service.InterMT100Util;
import com.bsf.macug.mt101.service.InterMT100ValidationUtil;
import com.bsf.macug.mt101.service.InterPaymentService;
import com.bsf.macug.mt101.service.InterSarieService;
import com.bsf.macug.mt101.service.InterSwiftService;
import com.bsf.macug.util.InterUtils;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class ProcessPaymentService implements Runnable {
	private static final Logger logger = Logger.getLogger(ProcessPaymentService.class.getName());

	@Autowired
	InterPaymentService paymentService;

	@Autowired
	InterUtils utils;

	@Autowired
	InterAccountToAccountService accountToAccountService;

	@Autowired
	InterSarieService sarieService;

	@Autowired
	InterSwiftService swiftService;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterMT100ValidationUtil mT100ValidationUtil;

	@Autowired
	InterMT100Util mt100Util;

	@Autowired
	InterCustomerAccountsService customerAccountsService;

	private MacPaymentHeader headerObj;

	public void run() {
		logger.info("Posting started for customer Id : " + headerObj.getCustomerId() + " and fileId : "
				+ headerObj.getFileReference());
		List<MacPaymentDetail> detailsList = null;
		Map<String, Map<String, SystemParameters>> allSystemProperties = null;
		try {
			allSystemProperties = utils.loadSystemProperties();

			detailsList = paymentService.findAllDetail(headerObj.getCustomerId(),
					headerObj.getFileReference(), "READY");

			List<MacPaymentDetail> holdList = paymentService.findAllDetail(headerObj.getCustomerId(),
					headerObj.getFileReference(), "HOLD");

			detailsList.addAll(holdList);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			return;
		}

		Map<String, SystemParameters> macPropertyMap = (Map) allSystemProperties.get("macPropertyMap");
		Map<String, SystemParameters> errorCodeMap = (Map) allSystemProperties.get("errorCodeMap");
		String paymentTypeAccountToAccount = systemParameterService.getSystemParametersDescription1("PMTTYPACC",
				macPropertyMap);

		String paymentTypeSarie = systemParameterService.getSystemParametersDescription1("PMTTYPSAR",
				macPropertyMap);

		for (MacPaymentDetail macPaymentDetail : detailsList) {
			try {
				String paymentType = utils.getPaymentType(macPaymentDetail, allSystemProperties);
				macPaymentDetail.setTransactionType(paymentType);

				mT100ValidationUtil.isValueDateAlreadyPassed(macPaymentDetail);

				String currency = macPaymentDetail.getCurrency();
				if (paymentType.equalsIgnoreCase(paymentTypeAccountToAccount)) {
					macPaymentDetail = accountToAccountService.processPayment(macPaymentDetail,
							allSystemProperties);
				} else if ((paymentType.equalsIgnoreCase(paymentTypeSarie)) && (currency.equalsIgnoreCase("SAR"))) {
					macPaymentDetail = sarieService.processPayment(macPaymentDetail, allSystemProperties);
				} else {
					macPaymentDetail = swiftService.processPayment(macPaymentDetail, allSystemProperties);
				}
			} catch (ValidationException e) {
				logger.error("Error : " + e.getErrorCode(), e);
				logger.error("errorCodeMap : " + errorCodeMap);
				macPaymentDetail.setStatus("DE");
				macPaymentDetail.setDescription(
						systemParameterService.getSystemParametersDescription1(e.getErrorCode(), errorCodeMap));
				macPaymentDetail.setAction(systemParameterService.getSystemParametersDescription2(e.getErrorCode(), errorCodeMap));
			} catch (Exception e) {
				logger.error("Error : " + e.getMessage(), e);
				macPaymentDetail.setStatus("FAILED");
				macPaymentDetail.setDescription("Unhandled exeption.");
			}
			if ("OK".equals(macPaymentDetail.getStatus())) {
				macPaymentDetail = mt100Util.generateKondorFileIfNeeded(macPaymentDetail);
			}
			updateDetails(macPaymentDetail);
		}

		updateHeader();
	}

	private void updateHeader() {
		try {
			Long acACCount = Long.valueOf(0L);
			Long sarieCount = Long.valueOf(0L);
			Long swiftCount = Long.valueOf(0L);
			Long rejectCount = Long.valueOf(0L);
			Long processedCount = Long.valueOf(0L);
			Long holdCount = Long.valueOf(0L);
			List<Object[]> statusTypeList = paymentService.getStatusCount(headerObj.getCustomerId(),
					headerObj.getFileReference());
			for (Object[] statusType : statusTypeList) {
				String status = (String) statusType[0];
				Long count = (Long) statusType[1];
				if ("OK".equalsIgnoreCase(status)) {
					processedCount = count;
				} else if ("HOLD".equalsIgnoreCase(status)) {
					processedCount = Long.valueOf(processedCount.longValue() + count.longValue());
					holdCount = count;
				} else {
					rejectCount = count;
				}
			}

			List<Object[]> transactionTypeList = paymentService
					.getTransactionTypeCount(headerObj.getCustomerId(), headerObj.getFileReference());

			for (Object[] transactionType : transactionTypeList) {
				String type = (String) transactionType[0];
				Long count = (Long) transactionType[1];
				if ("SARIE".equalsIgnoreCase(type)) {
					sarieCount = count;
				} else if ("SWIFT".equalsIgnoreCase(type)) {
					swiftCount = count;
				} else {
					acACCount = count;
				}
			}

			if (processedCount.longValue() - holdCount.longValue() != acACCount.longValue() + sarieCount.longValue()
					+ swiftCount.longValue()) {
				headerObj.setMt199Status("PENDING");
			}
			
			else {
				 headerObj.setMt199Status("PENDING");
				//headerObj.setMt199Status("ALLOK.NOTGENERATING.");
			}

			headerObj.setTotalAcAc(new BigDecimal(acACCount.longValue()));
			headerObj.setTotalSarie(new BigDecimal(sarieCount.longValue()));
			headerObj.setTotalSwift(new BigDecimal(swiftCount.longValue()));
			headerObj.setTotalProcessed(new BigDecimal(processedCount.longValue()));
			headerObj.setTotalFailed(new BigDecimal(rejectCount.longValue()));
			headerObj.setTotalTransaction(new BigDecimal(processedCount.longValue() + rejectCount.longValue()));
			headerObj.setProcessingStatus(Integer.valueOf(0));
			if (holdCount.intValue() > 0) {
				headerObj.setStatus("READY");
				headerObj
						.setDescription("Partial Processing Completed. Waiting for trade dates for further posting.");
			} else {
				headerObj.setStatus("COMPLETED");
				headerObj.setDescription("Processing completed.");
			}

			headerObj.setProcessedTime(new Timestamp(new Date().getTime()));
			paymentService.updateHeader(headerObj);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
	}

	private void updateDetails(MacPaymentDetail macPaymentDetail) {
		try {
			paymentService.updateDetail(macPaymentDetail);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
	}

	public MacPaymentHeader getHeaderObj() {
		return headerObj;
	}

	public void setHeaderObj(MacPaymentHeader headerObj) {
		this.headerObj = headerObj;
	}
}
