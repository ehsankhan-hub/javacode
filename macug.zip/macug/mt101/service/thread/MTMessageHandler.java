package com.bsf.macug.mt101.service.thread;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.service.InterCustomerDetailsService;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.exception.ValidationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.entity.MacPaymentHeader;
import com.bsf.macug.mt101.service.InterMT100Util;
import com.bsf.macug.mt101.service.InterPaymentService;
import com.bsf.macug.mt101.service.parser.InterMTParser;
import com.bsf.macug.util.InterUtils;

@Component
@Scope("prototype")
public class MTMessageHandler implements Runnable {

	private static final Logger logger = Logger.getLogger(MTMessageHandler.class.getName());

	@Autowired
	InterPaymentService paymentService;

	@Autowired
	InterMTParser mtParser;

	@Autowired
	InterMT100Util mT100Util;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterCustomerDetailsService customerDetailsService;

	@Autowired
	InterUtils utils;

	private MacPaymentHeader headerObj;

	@Override
	public void run() {
		Map<String, SystemParameters> errorCodeMap = null;
		try {
			errorCodeMap = systemParameterService.getSystemParametersByTableCode("MACERRCOD");
			if (headerObj != null) {
				logger.info("Starting to process customer " + headerObj.getCustomerId() + " file id "
						+ headerObj.getFileReference());
			}
			byte[] requestContent = headerObj.getMtContent();
			  
			String custReqFile=headerObj.getCustReqFile();
			
			String msgType=headerObj.getMessageType();

			CustomerDetails customerDetails = customerDetailsService.getCustomerDetails(headerObj.getCustomerId());
			if (customerDetails == null) {
				utils.logMT100Activity(headerObj.getCustomerId(),"FAILED", "Customer not found for " + headerObj.getFileReference(), msgType, custReqFile, 0);
				throw new CustomerNotFoundException("Customer not registred.");
			}

			List<MacPaymentDetail> detailsList = mtParser.parseMT101(requestContent,custReqFile,msgType);
			boolean allFailed = true;
			MacPaymentDetail macPaymentDetail=null;
			for (MacPaymentDetail details : detailsList) {
								
				if (allFailed && details.getStatus().equalsIgnoreCase("READY")) {
					allFailed = false;
				}
				details.setValidatedDate(new Timestamp(new Date().getTime()));
				macPaymentDetail=paymentService.getDetail(headerObj.getCustomerId(), details.getFileReference(), details.getTransactionReference());
				if(macPaymentDetail==null) { 
				paymentService.saveDetail(details);
				}
				else {        
				utils.logMT100Activity(headerObj.getCustomerId(),"FAILED", "Same Transaction reference exist :"+details.getTransactionReference(),headerObj.getMessageType() ,headerObj.getCustReqFile(), 0);	
				}
					
			}
			if (allFailed) {
				headerObj.setStatus("FAILED");
				headerObj.setDescription(
						systemParameterService.getSystemParametersDescription1("MACSUC003", errorCodeMap));
				utils.logMT100Activity(headerObj.getCustomerId(),"FAILED",
						"Failed to save details for file reference " + headerObj.getFileReference(), "", "",0);
			} else {
				headerObj.setStatus("READY");
				headerObj.setDescription(systemParameterService.getSystemParametersDescription1("MACSUC002", errorCodeMap));
				utils.logMT100Activity(headerObj.getCustomerId(),"Details Saved",
						"Failed to save details for file reference " + headerObj.getFileReference(), "",
						headerObj.getFileReference(),3);
			}

		} catch (ValidationException e) {
			headerObj.setStatus("FAILED");
			headerObj.setDescription(
					systemParameterService.getSystemParametersDescription1(e.getErrorCode(), errorCodeMap));
		} catch (CustomerNotFoundException e) {
			logger.error("Error : " + e.getMessage(), e);
			headerObj.setStatus("FAILED");
			headerObj.setDescription(systemParameterService.getSystemParametersDescription1("MACVER008", errorCodeMap));
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error : " + e.getMessage(), e);
			   
			headerObj.setStatus("FAILED");
			headerObj.setDescription("Unhandled exception.");
		}

		try {
			headerObj.setProcessingStatus(0);
			paymentService.updateHeader(headerObj);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
	}

	public void setHeaderObj(MacPaymentHeader headerObj) {
		this.headerObj = headerObj;
	}

}
