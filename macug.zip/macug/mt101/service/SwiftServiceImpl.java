package com.bsf.macug.mt101.service;

import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.service.InterCustomerAccountsService;
import com.bsf.macug.customer.service.InterCustomerChargeService;
import com.bsf.macug.customer.service.InterCustomerDetailsService;
import com.bsf.macug.exception.CurrencyConversionException;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.exception.PossibleDuplicationException;
import com.bsf.macug.exception.ProcessException;
import com.bsf.macug.exception.TCPConnectionException;
import com.bsf.macug.exception.ValidationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.mt101.dto.AccountEnquiryResponseDTO;
import com.bsf.macug.mt101.dto.BusinessDateDTO;
import com.bsf.macug.mt101.dto.SarieSwiftTRansferResponseDTO;
import com.bsf.macug.mt101.dto.ValueDateSoapDTO;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.service.tuxedo.InterAccountEnquiryService;
import com.bsf.macug.mt101.service.tuxedo.InterSarieAndSwiftTransferService;
import com.bsf.macug.util.InterUtils;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Map;
import javax.xml.ws.WebServiceException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SwiftServiceImpl implements InterSwiftService {
	private static final Logger logger = Logger.getLogger(SwiftServiceImpl.class.getName());

	@Autowired
	InterMT100ValidationUtil mT100ValidationUtil;

	@Autowired
	InterBusinessDateService businessDateService;

	@Autowired
	InterAccountEnquiryService accountEnquiryService;

	@Autowired
	InterMT100Util mT100Util;

	@Autowired
	InterUtils utils;

	@Autowired
	InterCustomerChargeService customerChargeService;

	@Autowired
	InterCustomerDetailsService customerDetailsService;

	@Autowired
	InterSarieAndSwiftTransferService sarieAndSwiftTransferService;

	@Autowired
	InterCustomerAccountsService customerAccountsService;

	public MacPaymentDetail processPayment(MacPaymentDetail details,
			Map<String, Map<String, SystemParameters>> allSystemProperties) {
		Map<String, SystemParameters> errorCodeMap = null;
		try {
			logger.info("(processPayment) ==> Swift payment insitated : "+details.getTransactionReference());
			Map<String, SystemParameters> macPropertyMap = (Map<String, SystemParameters>) allSystemProperties
					.get("macPropertyMap");
			errorCodeMap = (Map<String, SystemParameters>) allSystemProperties.get("errorCodeMap");
			Map<String, SystemParameters> tuxDetailMap = (Map<String, SystemParameters>) allSystemProperties
					.get("tuxDetailMap");
			Map<String, SystemParameters> tuxErrorCodeMap = (Map<String, SystemParameters>) allSystemProperties
					.get("tuxErrorCodeMap");
			Map<String, SystemParameters> exchangeRateMap = (Map<String, SystemParameters>) allSystemProperties
					.get("exchangeRateMap");

			BigDecimal sarieCharge = this.customerChargeService.getCharge(details.getCustomerId(), "PAYMENT", "SARIE");
			CustomerDetails customerDetails = this.customerDetailsService.getCustomerDetails(details.getCustomerId());

			BusinessDateDTO businessDateDto = this.businessDateService.getBusinessDate("B2B", macPropertyMap);
			if (!this.mT100ValidationUtil.isValidBusinessDate(businessDateDto)) {
				return this.mT100Util.setStatusAndDescription(details, "FAILED", "MACVER001", errorCodeMap);
			}

			String debitAccount = details.getDebitAccount();

			CustomerAccounts debitAccountObj = this.customerAccountsService
					.getCustomerAccountDetails(details.getCustomerId(), debitAccount, "PAYMENT");
			if (debitAccountObj == null) {
				return this.mT100Util.setStatusAndDescription(details, "DE", "MACVER018", errorCodeMap);
			}

			AccountEnquiryResponseDTO enquiryResponseForDebitAccount = this.accountEnquiryService
					.buildAccountEnquiryResponse(debitAccount, tuxDetailMap);
			MacPaymentDetail erroDetails = this.mT100ValidationUtil.validateDebitAccount(details,
					enquiryResponseForDebitAccount, allSystemProperties);

			if (erroDetails != null) {
				return erroDetails;
			}

			String debitCurrency = enquiryResponseForDebitAccount.getAccountCurrency();
			String transactionCurrency = details.getCurrency();
			details.setDebitCurrency(debitCurrency);

			if (!this.mT100ValidationUtil.isValidRateIndicatorSW(details, debitAccountObj)) {
				logger.info("(validateAndProcessPayment)==> isValidRateIndicator failed");
				return this.mT100Util.setStatusAndDescription(details, "DE", "MACVER026", errorCodeMap);
			}

			boolean fxPayments = this.mT100ValidationUtil.isFXPayments(details, debitAccountObj);
			if ((fxPayments) && (!"HOLD".equalsIgnoreCase(details.getStatus()))) {
				Date validTradeDate = this.mT100Util.getValidTradeDate(details, debitAccountObj);
				details.setTradeDate(validTradeDate);
				details.setStatus("HOLD");
				details.setDescription("Transaction will be processed on trade date.");
				return details;
			}
			if ((fxPayments) && ("HOLD".equalsIgnoreCase(details.getStatus())) && (this.mT100ValidationUtil
					.checkValidTradeExecutionTime(details.getTradeDate(), allSystemProperties))) {
				logger.warn("Waiting for the trade interval to execute.");
				return details;
			}

			BigDecimal transactionAmount = details.getTransactionAmount();
			BigDecimal debitRate = this.mT100Util.getConversionRate(transactionAmount.toString(), debitCurrency,
					debitAccount, transactionCurrency, exchangeRateMap);

			BigDecimal creditRate = BigDecimal.ONE;

			logger.info("(processPayment)==> transactionAmount : " + transactionAmount + "DebitRate : " + debitRate
					+ " , CreditRate : " + creditRate);

			BigDecimal debitAmount = debitRate.multiply(transactionAmount);
			BigDecimal creditAmount = creditRate.multiply(transactionAmount);

			BigDecimal amountInSAR = this.mT100Util.getAmountInSAR(transactionAmount, transactionCurrency, debitAccount,
					exchangeRateMap);

			BigDecimal debitAmountInSAR = this.mT100Util.getAmountInSAR(debitAmount, debitCurrency, debitAccount,
					exchangeRateMap);

			BigDecimal chargeAmount = this.mT100Util.calulateCharge(sarieCharge, debitRate);
			BigDecimal debitAmountWithCharge = debitAmount.add(chargeAmount);

			if (!mT100ValidationUtil.isLimitAvailable(customerDetails, details.getValueDate(), debitAmountInSAR,
					debitAccount)) {
				return this.mT100Util.setStatusAndDescription(details, "DE", "MACVER006", errorCodeMap);
			}

			details.setDebitAmount(debitAmountWithCharge);
			details.setCreditAmount(creditAmount);
			details.setDebitRate(debitRate);
			details.setCreditRate(creditRate);

			details.setTransactionAmountInSar(amountInSAR);
			details.setChargeAmount(chargeAmount);
			details.setDebitAccountBranch(enquiryResponseForDebitAccount.getAccountBranch());

			ValueDateSoapDTO valueDateResponse = null;

			if ("HOLD".equalsIgnoreCase(details.getStatus())) {
				valueDateResponse = this.mT100Util.getApplicableValueObj("SAR", "SA", details.getTradeDate(),
						macPropertyMap);
			} else {
				valueDateResponse = this.mT100Util.getApplicableValueObj("SAR", "SA", details.getValueDate(),
						macPropertyMap);
			}

			Date applicableValueDate = valueDateResponse.getCalulatedExpressValueDate();
			details.setApplicableValueDate(applicableValueDate);

			String strAvailableBalance = enquiryResponseForDebitAccount.getAvailableBalance();
			if (!mT100ValidationUtil.isBalanceAvailable(strAvailableBalance, debitAmountWithCharge)) {
				return this.mT100Util.setStatusAndDescription(details, "DE", "MACVER022", errorCodeMap);
			}

			SarieSwiftTRansferResponseDTO swiftResponse = this.sarieAndSwiftTransferService
					.buildSarieSwiftTransferResponse(details, businessDateDto, "SARIE", customerDetails,
							allSystemProperties);

			details.setPostedDate(new Timestamp(new Date().getTime()));

			if (swiftResponse == null) {
				logger.info("(validateAndProcessPayment)==> Transfer returned null. May be network error.");
				return this.mT100Util.setStatusAndDescription(details, "FAILED", "MACVER002", errorCodeMap);
			}

			String ftsActionCode = swiftResponse.getFtsActionCode();
			String cammActionCode = swiftResponse.getCammActionCode();

			details.setCammActionCode(cammActionCode);
			details.setFtsActionCode(ftsActionCode);

			if ((ftsActionCode.equals("0000")) && (cammActionCode.equals("0000"))) {
				details = this.mT100Util.setStatusAndDescription(details, "OK", "MACSUC001", errorCodeMap);
				mT100Util.updateLimit(details, debitAmountInSAR, customerDetails, debitAccount);
				return details;
			}
			return this.mT100Util.setStatusAndDescription(details, "DE", cammActionCode, tuxErrorCodeMap);

		} catch (WebServiceException e) {
			logger.error("Error : " + e.getMessage(), e);
			details = this.mT100Util.setStatusAndDescription(details, "FAILED", "MACVER002", errorCodeMap);
		} catch (CurrencyConversionException e) {
			logger.error("Error : " + e.getMessage(), e);
			details = this.mT100Util.setStatusAndDescription(details, "FAILED", "MACVER002", errorCodeMap);
		} catch (ProcessException e) {
			logger.error("Error : " + e.getMessage(), e);
			details = this.mT100Util.setStatusAndDescription(details, "FAILED", "MACVER002", errorCodeMap);
		} catch (DataAccessException e) {
			logger.error("Error : " + e.getMessage(), e);
			details = this.mT100Util.setStatusAndDescription(details, "FAILED", "MACVER002", errorCodeMap);
		} catch (CustomerNotFoundException e) {
			logger.error("Error : " + e.getMessage(), e);
			details = this.mT100Util.setStatusAndDescription(details, "FAILED", "MACVER008", errorCodeMap);
		} catch (TCPConnectionException e) {
			logger.error("Error : " + e.getMessage(), e);
			details = this.mT100Util.setStatusAndDescription(details, "FAILED", "MACVER002", errorCodeMap);
		} catch (PossibleDuplicationException e) {
			logger.error("Error : " + e.getMessage(), e);
			details = this.mT100Util.setStatusAndDescription(details, "FAILED", "MACVER007", errorCodeMap);
		} catch (ValidationException e) {
			logger.error("Error : " + e.getMessage(), e);
			details = this.mT100Util.setStatusAndDescription(details, "DE", e.getErrorCode(), errorCodeMap);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			details = this.mT100Util.setStatusAndDescription(details, "FAILED", "MACVER002", errorCodeMap);
		}
		return details;
	}
}

/*
 * Location:
 * D:\MT101Code\MT101.jar!\BOOT-INF\classes\com\bsf\macug\mt101\service\
 * SwiftServiceImpl.class Java compiler version: 8 (52.0) JD-Core Version: 0.7.1
 */