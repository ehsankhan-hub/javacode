package com.bsf.macug.mt101.service;

import com.bsf.macug.mt101.entity.PaymentUniqeSeries;

public interface InterPaymentUniqeSeriesService {
	public boolean save(PaymentUniqeSeries paramPaymentUniqeSeries);
}