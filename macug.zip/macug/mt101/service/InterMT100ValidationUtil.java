package com.bsf.macug.mt101.service;

import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.exception.ValidationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.mt101.dto.AccountEnquiryResponseDTO;
import com.bsf.macug.mt101.dto.BusinessDateDTO;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.prowidesoftware.swift.model.field.Field30;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

public interface InterMT100ValidationUtil {
	public void validExcutionDate(Field30 paramField30) throws ValidationException;

	public void validateTransactionReference(String paramString) throws ValidationException;

	public void validateAmountAndCurrency(String paramString, Map<String, SystemParameters> paramMap)
			throws ValidationException;

	public void validateBenBank(String paramString) throws ValidationException;

	public void validateBenAccount(String paramString) throws ValidationException;

	public void validateDetailsOfCharge(String paramString) throws ValidationException;

	public boolean isValidBusinessDate(BusinessDateDTO paramBusinessDateDTO);

	public boolean ifTransactionCurrencyEqualsDebitOrCreditCurrency(String paramString1, String paramString2,
			String paramString3);

	public MacPaymentDetail validateDebitAccount(MacPaymentDetail paramMacPaymentDetail,
			AccountEnquiryResponseDTO paramAccountEnquiryResponseDTO,
			Map<String, Map<String, SystemParameters>> paramMap);

	public MacPaymentDetail validateBeneficiaryAccount(MacPaymentDetail paramMacPaymentDetail,
			AccountEnquiryResponseDTO paramAccountEnquiryResponseDTO,
			Map<String, Map<String, SystemParameters>> paramMap);

	public boolean isAccountTypeAllowedForDebit(String paramString1, Map<String, SystemParameters> paramMap,
			String paramString2);

	public boolean isAccountStatusAllowedForDebit(String paramString1, Map<String, SystemParameters> paramMap,
			String paramString2);

	public boolean validateBSFLimit(CustomerDetails paramCustomerDetails, String paramString);

	public boolean isLimitAvailable(CustomerDetails paramCustomerDetails, Date paramDate,BigDecimal paramBigDecimal, String paramString);

	public void validateDebitAccount(String paramString) throws ValidationException;

	public void isValueDateAlreadyPassed(MacPaymentDetail paramMacPaymentDetail) throws ValidationException;

	public boolean isBalanceAvailable(String paramString, BigDecimal paramBigDecimal);

	public boolean isValidRateIndicator(MacPaymentDetail paramMacPaymentDetail, CustomerAccounts paramCustomerAccounts);

	public boolean isValidRateIndicatorSW(MacPaymentDetail paramMacPaymentDetail,
			CustomerAccounts paramCustomerAccounts);

	public boolean isFXPayments(MacPaymentDetail paramMacPaymentDetail, CustomerAccounts paramCustomerAccounts);

	public boolean checkValidTradeExecutionTime(Date paramDate, Map<String, Map<String, SystemParameters>> paramMap);
}