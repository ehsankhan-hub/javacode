package com.bsf.macug.mt101.service.parser;

import java.util.List;

import com.bsf.macug.exception.ValidationException;
import com.bsf.macug.mt101.entity.MacPaymentDetail;

public interface InterMTParser {
	public List<MacPaymentDetail> parseMT101(byte[] requestContent,String custReqFile,String msgType) throws ValidationException;
}
