package com.bsf.macug.mt101.service.parser;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bsf.macug.exception.ValidationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.service.InterMT100ValidationUtil;
import com.bsf.macug.util.InterUtils;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.SwiftTagListBlock;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field20;
import com.prowidesoftware.swift.model.field.Field21;
import com.prowidesoftware.swift.model.field.Field30;
import com.prowidesoftware.swift.model.field.Field50H;
import com.prowidesoftware.swift.model.field.Field59;
import com.prowidesoftware.swift.model.field.Field59A;
import com.prowidesoftware.swift.model.field.Field70;
import com.prowidesoftware.swift.model.field.Field71A;
import com.prowidesoftware.swift.model.mt.mt1xx.MT101;

@Service
public class MTParserImpl implements InterMTParser{

	private static final Logger logger = Logger.getLogger(MTParserImpl.class.getName());
	
		
	@Autowired
	InterMT100ValidationUtil mT100ValidationUtil;
	
	@Autowired
	InterSystemParameterService systemParameterService;
	
	@Autowired
	InterUtils utils;
	
	@Override
	public List<MacPaymentDetail> parseMT101(byte[] requestContent,String custReqFile,String msgType) throws ValidationException {
		List<MacPaymentDetail> parsedList = null;
		Map<String, SystemParameters> errorCodeMap = null;
		Map<String, SystemParameters> currencyCodeMap =null;
		try {
			errorCodeMap = systemParameterService.getSystemParametersByTableCode("MACERRCOD");
			currencyCodeMap = systemParameterService.getSystemParametersByTableCode("CURCYCODE");
			String data = new String(requestContent, "UTF-8");
			data = data.trim();
			data = utils.removeStealinkCharacter(data.getBytes("UTF-8"));	
			SwiftMessage sm = SwiftMessage.parse(data);	
			
			MT101 mt101 = new MT101(sm);
			Field20 field20 = mt101.getField20();
			String fileReference = field20.getValue();
			String customerId = mt101.getSender();
			customerId = customerId.substring(0, 8);
			Field30 field30 = mt101.getField30();			
			
			mT100ValidationUtil.validExcutionDate(field30);			
			String executionDate = field30.getValue();
			DateFormat format = new SimpleDateFormat("yyMMdd");
			Date valueDate = format.parse(executionDate);

			parsedList = new ArrayList<>();			
			MacPaymentDetail detailsObj = null;
			List<Field21> field21List = mt101.getField21();
			if(field21List == null || field21List.size() < 1) {
				throw new ValidationException("MACVER009");//no transaction found
			}
			
			
			List<SwiftTagListBlock> blockListnnn = sm.getBlock4().getSubBlocks("21", "71A");
			
			for (SwiftTagListBlock swiftTagListBlock : blockListnnn) {
				List<Tag> tagArray = swiftTagListBlock.getTags();
				detailsObj = new MacPaymentDetail();
				detailsObj.setCustomerId(customerId);
				detailsObj.setFileReference(fileReference);
				detailsObj.setValueDate(valueDate);
				detailsObj = prepareDetails(detailsObj,tagArray,errorCodeMap,currencyCodeMap);
				
				String fts = utils.getFTSReference("MAC");
				detailsObj.setFtsReference(fts);
				String ttReference = utils.getTTReference("MAC");
				detailsObj.setTtReference(ttReference);						
				
				String markingReference = utils.getTransactionReference(7);
				String naretiveRef = utils.getDynamicNarativeReferenceNumber(10);
				detailsObj.setMarkingReference(markingReference);
				detailsObj.setMarkingNarative(naretiveRef);
				if((detailsObj.getValidTrans()!=null)&&detailsObj.getValidTrans().equals("FAILED")) {
				utils.logMT100Activity(customerId,"FAILED", detailsObj.getDescription(), msgType , custReqFile,0);
				}
				else {
					parsedList.add(detailsObj);
					detailsObj.setValidTrans(null);
				}
				
			}
			
		} catch (ValidationException e) {
			throw e;
		}catch (Exception e) {
			   
			logger.error("Error : "+e.getMessage(), e);
			throw new ValidationException("MACVER010");
		}
		return parsedList;
	}
	int count=0;

	private MacPaymentDetail prepareDetails(MacPaymentDetail detailsObj, List<Tag> tagArray, Map<String, SystemParameters> errorCodeMap, Map<String, SystemParameters> currencyCodeMap) {
		try {
			count++;
			for(Tag tag : tagArray) {
				String tagName = tag.getField().getName();
				if(!StringUtils.isEmpty(tagName) && tagName.equalsIgnoreCase("21")) {
					String transactionReference = tag.getField().getValue();
					detailsObj.setTransactionReference(transactionReference);
					mT100ValidationUtil.validateTransactionReference(transactionReference);					
				  // break;
				}
				
				if(!StringUtils.isEmpty(tagName) && tagName.equalsIgnoreCase("32B")) {
					String currencyAndAmount = tag.getField().getValue();
					mT100ValidationUtil.validateAmountAndCurrency(currencyAndAmount,currencyCodeMap);
					String currency = currencyAndAmount.substring(0, 3);
					String amount = currencyAndAmount.substring(3);
					BigDecimal transactionAmount = new BigDecimal(amount.replace(",", "."));
					detailsObj.setCurrency(currency);
					detailsObj.setTransactionAmount(transactionAmount);
				}else if(!StringUtils.isEmpty(tagName) && tagName.equalsIgnoreCase("50H")) {
					Field50H field50H = (Field50H) tag.getField();
					mT100ValidationUtil.validateDebitAccount(field50H.getAccount());	
					detailsObj.setOrderingCustomer50(field50H.getAccount());
					detailsObj.setDebitAccount(field50H.getAccount());
					detailsObj.setOrderingCustomer501(field50H.getComponent2());
					detailsObj.setOrderingCustomer502(field50H.getComponent3());
					detailsObj.setOrderingCustomer503(field50H.getComponent4());
					detailsObj.setOrderingCustomer504(field50H.getComponent5());
					detailsObj.setAccountInstituion57(tag.getField().getValue());
				}else if(!StringUtils.isEmpty(tagName) && tagName.equalsIgnoreCase("57a")) {
					mT100ValidationUtil.validateBenBank(tag.getField().getValue());	
					detailsObj.setAccountInstituion57(tag.getField().getValue());
				}else if(!StringUtils.isEmpty(tagName) && tagName.equalsIgnoreCase("59")) {
					Field59 field59A = (Field59) tag.getField();
					mT100ValidationUtil.validateBenAccount(field59A.getAccount());	
					detailsObj.setBeneficiaryInfo59(field59A.getAccount());
					detailsObj.setBeneficiaryInfo591(field59A.getComponent2());
					detailsObj.setBeneficiaryInfo592(field59A.getComponent3());
					detailsObj.setBeneficiaryInfo593(field59A.getComponent4());
					detailsObj.setBeneficiaryInfo594(field59A.getComponent5());
				}else if(!StringUtils.isEmpty(tagName) && tagName.equalsIgnoreCase("59a")) {
					Field59A field59A = (Field59A) tag.getField();
					mT100ValidationUtil.validateBenAccount(field59A.getAccount());	
					detailsObj.setBeneficiaryInfo59(field59A.getAccount());
					detailsObj.setBeneficiaryInfo591(field59A.getComponent2());
				}else if(!StringUtils.isEmpty(tagName) && tagName.equalsIgnoreCase("70")) {
					Field70 field70 = (Field70) tag.getField();
					detailsObj.setRemittanceInfo70(field70.getComponent1());
					detailsObj.setRemittanceInfo701(field70.getComponent2());
					detailsObj.setRemittanceInfo702(field70.getComponent3());
					detailsObj.setRemittanceInfo703(field70.getComponent4());
				}else if(!StringUtils.isEmpty(tagName) && tagName.equalsIgnoreCase("71a")) {
					Field71A field71a = (Field71A) tag.getField();
					mT100ValidationUtil.validateDetailsOfCharge(field71a.getComponent1());	
					logger.info("Field71A--"+field71a.getComponent1().toString().substring(0,3));
					detailsObj.setDetailsOfCharge(field71a.getComponent1().toString().substring(0,3));
					detailsObj.setStatus("READY");
					//break;
				}
				/*else if((!tagName.equalsIgnoreCase("71a")||(!tagName.equalsIgnoreCase("70"))||(!tagName.equalsIgnoreCase("59a"))
						||(!tagName.equalsIgnoreCase("59"))||(!tagName.equalsIgnoreCase("57a"))||(!tagName.equalsIgnoreCase("50H"))
						||(!tagName.equalsIgnoreCase("32B"))||(!tagName.equalsIgnoreCase("21")))) {
					detailsObj.setValidTrans("FAILED");
					detailsObj.setDescription("Invalid tag received "+ tagName +" in transaction number : "+ count);
					throw new ValidationException("Invalid tag received "+ tagName +" in transaction number : "+ count);
				}*/
				
			}
		} catch (ValidationException e) {
			logger.error("Error : "+e.getErrorCode(), e);
			detailsObj.setStatus("FAILED");
			detailsObj.setDescription(systemParameterService.getSystemParametersDescription1(e.getErrorCode(), errorCodeMap));// e.getErrorCode(); get message
			detailsObj.setAction(systemParameterService.getSystemParametersDescription2(e.getErrorCode(), errorCodeMap));
			
		
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
			detailsObj.setStatus("FAILED");
			detailsObj.setDescription("Unhandled validation.");
		}
		
		return detailsObj;
	}

}
