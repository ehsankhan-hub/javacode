package com.bsf.macug.mt101.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import javax.xml.ws.WebServiceException;

import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.exception.CurrencyConversionException;
import com.bsf.macug.exception.DuplicateFileException;
import com.bsf.macug.exception.PossibleDuplicationException;
import com.bsf.macug.exception.TCPConnectionException;
import com.bsf.macug.exception.ValidationException;
import com.bsf.macug.exception.XMLParsingException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.mt101.dto.ValueDateSoapDTO;
import com.bsf.macug.mt101.dto.fileact.request.Message;
import com.bsf.macug.mt101.entity.MacFileLog;
import com.bsf.macug.mt101.entity.MacPaymentDetail;

public interface InterMT100Util {
	public MacPaymentDetail setStatusAndDescription(MacPaymentDetail paramMacPaymentDetail, String paramString1,
			String paramString2, Map<String, SystemParameters> paramMap);

	public String getCurrentRateSequence();

	public BigDecimal calulateCharge(BigDecimal paramBigDecimal1, BigDecimal paramBigDecimal2);

	public BigDecimal getConversionRate(String paramString1, String paramString2, String paramString3,
			String paramString4, Map<String, SystemParameters> paramMap)
			throws WebServiceException, CurrencyConversionException;

	public ValueDateSoapDTO getApplicableValueObj(String paramString1, String paramString2, Date paramDate,
			Map<String, SystemParameters> paramMap) throws TCPConnectionException;

	public BigDecimal getAmountInSAR(BigDecimal paramBigDecimal, String paramString1, String paramString2,
			Map<String, SystemParameters> paramMap) throws WebServiceException, CurrencyConversionException;

	public boolean saveFTSKey(String paramString1, String paramString2, String paramString3, String paramString4)
			throws PossibleDuplicationException;

	public void updateFTSKey(String paramString1, String paramString2, String paramString3);

	public boolean savePaymentUniqueSeries(String paramString1, String paramString2, String paramString3,
			BigDecimal paramBigDecimal, Date paramDate, CustomerDetails paramCustomerDetails)
			throws PossibleDuplicationException;

	public void updateLimit(MacPaymentDetail paramMacPaymentDetail, BigDecimal paramBigDecimal,
			CustomerDetails paramCustomerDetails, String paramString);


	public Message parseXMLMessage(String paramString) throws XMLParsingException;

	public boolean checkIfValidRequestDateTime(String paramString, Map<String, SystemParameters> paramMap);

	public boolean checkIfFileIdExists(String paramString1, String paramString2) throws DuplicateFileException;

	public MacFileLog saveLog(String paramString, byte[] paramArrayOfByte);

	public MacPaymentDetail generateKondorFileIfNeeded(MacPaymentDetail paramMacPaymentDetail);

	public Date getValidTradeDate(MacPaymentDetail paramMacPaymentDetail, CustomerAccounts paramCustomerAccounts)
			throws ValidationException;

	boolean updateLog(MacFileLog log);

	boolean isFutureValueDate(String valueDateStr);
}