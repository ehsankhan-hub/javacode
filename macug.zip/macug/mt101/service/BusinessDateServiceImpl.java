package com.bsf.macug.mt101.service;

import java.io.ByteArrayOutputStream;
import java.util.Date;
import java.util.Map;

import javax.transaction.Transactional;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.dto.BusinessDateDTO;
import com.bsf.macug.mt101.service.handler.BusinessDateHandler;

@Service("businessDateService")
@Transactional
public class BusinessDateServiceImpl implements InterBusinessDateService {
	private static final Logger logger = Logger
			.getLogger(BusinessDateServiceImpl.class.getName());

	@Autowired
	InterSystemParameterService systemParameterService;

	@Override
	public BusinessDateDTO getBusinessDate(String strSource,
			Map<String, SystemParameters> b2BPropertyMap) {
		BusinessDateDTO busDate = null;
		SOAPConnectionFactory soapConnectionFactory = null;
		SOAPConnection soapConnection = null;
		SOAPMessage soapResponse = null;
		ByteArrayOutputStream baos = null;
		String strURL = null;
		try {
			soapConnectionFactory = SOAPConnectionFactory.newInstance();
			soapConnection = soapConnectionFactory.createConnection();
			strURL = systemParameterService.getSystemParametersDescription1(
					"BUSDATURL", b2BPropertyMap);
			soapResponse = soapConnection.call(
					businessDateRequestMessage(strSource), strURL);
			baos = new ByteArrayOutputStream();
			soapResponse.writeTo(baos);
			String output = new String(baos.toByteArray());
			logger.info("(createSOAPRequest)==> Business date response message is "
					+ output);
			soapConnection.close();
			busDate = new BusinessDateHandler()
					.parseBusinessDateResponse(output);
		} catch (Exception e) {
			logger.info(
					"(getBusinessDate)==> Error occured taking business Date "
							+ e.getMessage(), e);
			busDate = new BusinessDateDTO();
			busDate.setBusinessDate(new Date());
		}
		return busDate;
	}

	private SOAPMessage businessDateRequestMessage(String strSource)
			throws Exception {
		MessageFactory messageFactory = null;
		SOAPMessage soapRequest = null;
		SOAPPart soapPart = null;
		ByteArrayOutputStream baos = null;
		messageFactory = MessageFactory.newInstance();
		soapRequest = messageFactory.createMessage();
		soapPart = soapRequest.getSOAPPart();
		SOAPHeader soapHeader = soapRequest.getSOAPHeader();
		SOAPEnvelope soapEnvelope = soapPart.getEnvelope();
		soapEnvelope.addNamespaceDeclaration("bsf",
				"http://BSF.ITD.ECORP.Schemas.InquirySchema");
		SOAPBody soapBody = soapEnvelope.getBody();
		SOAPElement soapBodyElem = soapBody.addChildElement("GeneralInquiries",
				"bsf");
		SOAPElement inquiryElement = soapBodyElem.addChildElement("Inquiry",
				"bsf");
		SOAPElement serviceRequest = inquiryElement
				.addChildElement("ServiceRq");
		SOAPElement busDate = serviceRequest.addChildElement("GetBusinessDate");
		SOAPElement sourceSystem = busDate.addChildElement("SourceSystem")
				.addTextNode(strSource);
		MimeHeaders headers = soapRequest.getMimeHeaders();
		headers.addHeader(
				"SOAPAction",
				"http://BSF.ITD.ECORP.Schemas.InquirySchema/GeneralInquiriesService/GeneralInquiries");
		soapRequest.saveChanges();
		baos = new ByteArrayOutputStream();
		soapRequest.writeTo(baos);
		logger.info("(createSOAPRequest)==> Business date request message is "
				+ new String(baos.toByteArray()));
		return soapRequest;

	}

}
