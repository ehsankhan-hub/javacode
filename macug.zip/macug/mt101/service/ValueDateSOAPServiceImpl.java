package com.bsf.macug.mt101.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.WebServiceException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.dto.ValueDateSoapDTO;

@Service("valueDateSOAPService")
@Transactional
public class ValueDateSOAPServiceImpl implements InterValueDateSOAPService {

	private static final Logger logger = Logger.getLogger(ValueDateSOAPServiceImpl.class.getName());

	@Autowired
	InterSystemParameterService systemParameterService;

	@Override
	public ValueDateSoapDTO getNextValueDate(ValueDateSoapDTO valueDateSoapDto, Map<String, SystemParameters> properties)
			throws WebServiceException {
		String wsdlUrl = systemParameterService.getSystemParametersDescription1("VALDATURL", properties);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		SOAPConnection soapConnection = null;
		SOAPConnectionFactory soapConnectionFactory = null;
		logger.info(
				"ValidateValueDateSOAPService=====> (valueDateValidationResponse) Inside valueDateValidationResponse");
		try {
			SOAPMessage soapRequest = getValueDateValidationDetails(properties, valueDateSoapDto);
			soapConnectionFactory = SOAPConnectionFactory.newInstance();
			soapConnection = soapConnectionFactory.createConnection();
			logger.info(
					"ValidateValueDateSOAPService=====> (valueDateValidationResponse) Trying to call Value date SOAP Service on URL "
							+ wsdlUrl);
			SOAPMessage soapResponse = soapConnection.call(soapRequest, wsdlUrl);
			soapResponse.writeTo(baos);
			String soapOutput = new String(baos.toByteArray());
			logger.info(
					"ValidateValueDateSOAPService=====> (valueDateValidationResponse) SOAP Response : " + soapOutput);
			valueDateSoapDto = parseValueDateValidationResponse(valueDateSoapDto, soapOutput);
			baos.reset();
			logger.info(
					"ValidateValueDateSOAPService=====> (valuDateValidationResponse) response : " + valueDateSoapDto);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new WebServiceException(
					"Request can't be processed by BSF due to technical problem-valueDateValidationResponse");
		} finally {
			try {
				if (baos != null)
					baos.close();
				if (soapConnection != null)
					soapConnection.close();
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
		return valueDateSoapDto;
	}

	private static SOAPMessage getValueDateValidationDetails(Map<String, SystemParameters> properties,
			ValueDateSoapDTO valueDateReq) throws SOAPException, IOException {
		logger.info("Message Type " + valueDateReq.getMsgType() + " Currency: " + valueDateReq.getCurrency()
				+ "Country " + valueDateReq.getCountryCode() + "Date " + valueDateReq.getRequestValueDate());
		StringBuilder strBuilder = new StringBuilder(
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.otms.ipp.bsf.com/\"><soapenv:Header/><soapenv:Body><ser:ComputeValueDateOp><ser:computeValueDate><messageType>");
		strBuilder.append(valueDateReq.getMsgType());
		strBuilder.append("</messageType><currency>");
		strBuilder.append(valueDateReq.getCurrency());
		strBuilder.append("</currency><country>");
		strBuilder.append(valueDateReq.getCountryCode());
		strBuilder.append("</country><requestedValueDate>");
		strBuilder.append(valueDateReq.getRequestValueDate());
		strBuilder.append(
				"</requestedValueDate></ser:computeValueDate></ser:ComputeValueDateOp></soapenv:Body></soapenv:Envelope>");
		InputStream is = new ByteArrayInputStream(strBuilder.toString().getBytes());
		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage soapMessage = messageFactory.createMessage(new MimeHeaders(), is);
		MimeHeaders headers = soapMessage.getMimeHeaders();
		headers.addHeader("SOAPAction", "http://service.otms.ipp.bsf.com/Service/ComputeValueDateOp");
		soapMessage.saveChanges();
		ByteArrayOutputStream baos = null;
		baos = new ByteArrayOutputStream();
		soapMessage.writeTo(baos);
		String strRequest = new String(baos.toByteArray());
		logger.info("ValidateValueDateSOAPService=====> (getValueDateValidationDetails) Request is " + strRequest
				+ " \r\n");
		return soapMessage;
	}

	private ValueDateSoapDTO parseValueDateValidationResponse(ValueDateSoapDTO valueDateReq, String responseXml) {
		try {
			Document document = loadXMLFromString(responseXml);
			NodeList nodess = document.getElementsByTagName("computeValueDateResponse");
			for (int i = 0; i < nodess.getLength(); i++) {
				Element element = (Element) nodess.item(i);
				NodeList nodeList = element.getElementsByTagName("return");
				if (null != nodeList) {
					int nodeLen = nodeList.getLength();
					for (int temp = 0; temp < nodeLen; temp++) {
						Element childElement = (Element) nodeList.item(temp);
						Element applicableValueDateEle = (Element) childElement
								.getElementsByTagName("applicableValueDate").item(0);
						Element correspondentChargesEle = (Element) childElement
								.getElementsByTagName("correspondentCharges").item(0);
						Element expressChargesEle = (Element) childElement.getElementsByTagName("expressCharges")
								.item(0);
						Element expressFlagEle = (Element) childElement.getElementsByTagName("expressFlag").item(0);
						Element expressValueDateEle = (Element) childElement.getElementsByTagName("expressValueDate")
								.item(0);
						if (applicableValueDateEle != null)
							valueDateReq.setApplicableValueDate(getCharacterDataFromElement(applicableValueDateEle));
						if (correspondentChargesEle != null)
							valueDateReq.setCorrespondentCharges(getCharacterDataFromElement(correspondentChargesEle));
						if (expressChargesEle != null)
							valueDateReq.setExpressCharges(getCharacterDataFromElement(expressChargesEle));
						if (expressFlagEle != null)
							valueDateReq.setExpressFlag(getCharacterDataFromElement(expressFlagEle));
						if (expressValueDateEle != null)
							valueDateReq.setExpressValueDate(getCharacterDataFromElement(expressValueDateEle));
					}
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return valueDateReq;
	}

	private Document loadXMLFromString(String xml) {
		Document document = null;
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			InputSource is = new InputSource(new StringReader(xml));
			document = builder.parse(is);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return document;
	}

	private String getCharacterDataFromElement(Element e) {
		Node child = e.getFirstChild();
		if (child instanceof CharacterData) {
			CharacterData cd = (CharacterData) child;
			return cd.getData();
		}
		return "";
	}

}
