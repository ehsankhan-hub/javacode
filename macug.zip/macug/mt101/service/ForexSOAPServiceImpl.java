package com.bsf.macug.mt101.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.transaction.Transactional;
import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.ws.WebServiceException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bsf.macug.exception.CurrencyConversionException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.dto.ExchangeRateDTO;
import com.bsf.macug.mt101.dto.FxDealResponseDTO;
import com.bsf.macug.mt101.service.handler.ExchangeRateHandler;

@Service("forexSOAPService")
@Transactional
public class ForexSOAPServiceImpl implements InterForexSOAPService {

	private static final Logger logger = Logger.getLogger(ForexSOAPServiceImpl.class.getName());

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterMT100Util mT100Util;

	@Override
	public ExchangeRateDTO getExchangeRate(String baseCurrency, String currency, String amount, String accountNo,
			Map<String, SystemParameters> properties, String segment)
			throws WebServiceException, CurrencyConversionException {
		String xeUrl = systemParameterService.getSystemParametersDescription1("XE_URL", properties);

		SOAPConnectionFactory soapConnectionFactory = null;
		SOAPConnection soapConnection = null;
		SOAPMessage soapResponse = null;
		ByteArrayOutputStream baos = null;
		ExchangeRateDTO exchangeRate = null;
		logger.info("(getExchangeRate) Inside getExchangeRate \r\n");
		try {
			doTrustToCertificates();
			baos = new ByteArrayOutputStream();
			ExchangeRateHandler xeHandler = new ExchangeRateHandler();
			soapConnectionFactory = SOAPConnectionFactory.newInstance();
			soapConnection = soapConnectionFactory.createConnection();
			soapResponse = soapConnection
					.call(getCurrentRate(baseCurrency, currency, amount, accountNo, properties, segment), xeUrl);
			soapResponse.writeTo(baos);
			String fxResponse = new String(baos.toByteArray());
			logger.info("(getExchangeRate) Response SOAP--- " + fxResponse + " ---\r\n");
			exchangeRate = xeHandler.parseExchangeRateResponse(fxResponse);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new WebServiceException("Request can't be processed by BSF due to technical problem");
		} finally {
			try {
				if (soapConnection != null)
					soapConnection.close();
				if (baos != null)
					baos.close();
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}

		if (exchangeRate == null) {
			throw new CurrencyConversionException();
		}

		String xeRateSar = exchangeRate.getExchangeRate();
		String replyStatus = exchangeRate.getReplyStatus();
		String replyDescription = exchangeRate.getReplyDescription();
		if (StringUtils.isEmpty(replyStatus) || !replyStatus.equalsIgnoreCase("0")) {
			throw new CurrencyConversionException();
		}

		return exchangeRate;
	}

	public void doTrustToCertificates() throws Exception {
		Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkServerTrusted(X509Certificate[] certs, String authType) throws CertificateException {
				return;
			}

			public void checkClientTrusted(X509Certificate[] certs, String authType) throws CertificateException {
				return;
			}
		} };

		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, new SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		HostnameVerifier hv = new HostnameVerifier() {
			public boolean verify(String urlHostName, SSLSession session) {
				if (!urlHostName.equalsIgnoreCase(session.getPeerHost())) {
					logger.info("Warning: URL host '" + urlHostName + "' is different to SSLSession host '"
							+ session.getPeerHost() + "'.");
				}
				return true;
			}
		};
		HttpsURLConnection.setDefaultHostnameVerifier(hv);
	}

	@Override
	public FxDealResponseDTO getDealDetails(String dealTicketNumber, Map<String, SystemParameters> properties)
			throws WebServiceException {
		String xeUrl = systemParameterService.getSystemParametersDescription1("XE_URL", properties);
		SOAPConnectionFactory soapConnectionFactory = null;
		SOAPConnection soapConnection = null;
		SOAPMessage soapResponse = null;
		ByteArrayOutputStream baos = null;
		FxDealResponseDTO fxDealResponse = null;
		logger.info("(getExchangeRate) Inside getExchangeRate \r\n");
		try {

			baos = new ByteArrayOutputStream();
			ExchangeRateHandler xeHandler = new ExchangeRateHandler();
			soapConnectionFactory = SOAPConnectionFactory.newInstance();
			soapConnection = soapConnectionFactory.createConnection();
			soapResponse = soapConnection.call(getGtdTicketDetails(dealTicketNumber, properties), xeUrl);
			soapResponse.writeTo(baos);
			String fxResponse = new String(baos.toByteArray());
			logger.info("(FX exchangeService)GetGTDTicketDetails Response SOAP--- " + fxResponse + " ---\r\n");
			fxDealResponse = xeHandler.parseDealTicketResponse(fxResponse);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new WebServiceException("Request can't be processed by BSF due to technical problem");
		} finally {
			try {
				if (soapConnection != null)
					soapConnection.close();
				if (baos != null)
					baos.close();
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
		return fxDealResponse;
	}

	private SOAPMessage getCurrentRate(String baseCurrency, String currency, String amount,
			String orderingCustomerAccount, Map<String, SystemParameters> properties, String segment)
			throws SOAPException, IOException, ParseException {

		String serverURI = systemParameterService.getSystemParametersDescription1("BZPXESURI", properties);
		String nameSpaceUrl = systemParameterService.getSystemParametersDescription1("BZPXESPUR", properties);
		String nameSpacePort = systemParameterService.getSystemParametersDescription1("BZPXEPORT", properties);

		String headerUrl = systemParameterService.getSystemParametersDescription1("BZPXEHURI", properties);
		String headerPrefix = systemParameterService.getSystemParametersDescription1("BZPXEHPRE", properties);

		String serverPrefix = systemParameterService.getSystemParametersDescription1("BZPXESPRE", properties);

		String fxValueDate = null;// properties.getFxValueDate();
		String strRateType = "BUY";// (properties.getRateType()==null)?"BUY":properties.getRateType();
		logger.info("(getCurrentRate) Invoking to get Current Rate serverURI" + serverURI + " nameSpaceUrl"
				+ nameSpaceUrl + " nameSpacePort" + nameSpacePort + " headerUrl" + headerUrl + " \r\n");
		logger.info("(getCurrentRate) headerPrefix" + headerPrefix + " serverPrefix" + serverPrefix);
		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage soapMessage = messageFactory.createMessage();
		SOAPPart soapPart = soapMessage.getSOAPPart();
		SOAPEnvelope envelope = soapPart.getEnvelope();
		envelope.addNamespaceDeclaration("xsi", "http://www.w3.org/2001/XMLSchema-instance");
		envelope.addNamespaceDeclaration("xsd", "http://www.w3.org/2001/XMLSchema");
		envelope.addNamespaceDeclaration(serverPrefix, serverURI);
		SOAPBody soapBody = envelope.getBody();
		// QName bodyName = new QName("http://tempuri.org/", "getCurrRate");
		QName bodyName = new QName(nameSpaceUrl, nameSpacePort);
		SOAPBodyElement soapBodyElem = soapBody.addBodyElement(bodyName);
		Date currentDate = new Date();
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		DateFormat ftValueDate = new SimpleDateFormat("yyMMdd");
		DateFormat refFormat = new SimpleDateFormat("yyMMddHHmmss");
		String strUniqueRef = mT100Util.getCurrentRateSequence();// refFormat.format(new Date());

		// soapBodyElem.addChildElement("SourceReference").addTextNode("ABCDXYZ1234");
		// //changed as ninar suggested to put yyMMddHHmmss
		soapBodyElem.addChildElement("SourceReference").addTextNode(strUniqueRef);
		soapBodyElem.addChildElement("SourceSystem").addTextNode("B2B");
		if (fxValueDate == null)
			soapBodyElem.addChildElement("RequestTime").addTextNode(format.format(currentDate));
		else
			soapBodyElem.addChildElement("RequestTime").addTextNode(format.format(ftValueDate.parse(fxValueDate)));
		soapBodyElem.addChildElement("BaseCurrency").addTextNode(baseCurrency);
		soapBodyElem.addChildElement("ToCurrency").addTextNode(currency);
		amount = (amount.contains(",")) ? amount.replace(",", ".") : amount;
		soapBodyElem.addChildElement("AmountReq").addTextNode(amount);
		// soapBodyElem.addChildElement("Segment").addTextNode("Customer");
		soapBodyElem.addChildElement("Segment").addTextNode(segment);
		soapBodyElem.addChildElement("Type").addTextNode(strRateType);
		soapBodyElem.addChildElement("TranType").addTextNode("TRAN");
		soapBodyElem.addChildElement("DestCountry").addTextNode("SA");
		soapBodyElem.addChildElement("AcctNo").addTextNode(orderingCustomerAccount);
		MimeHeaders headers = soapMessage.getMimeHeaders();
		headers.addHeader(headerPrefix, headerUrl);
		soapMessage.saveChanges();
		logger.info("(getCurrentRate)Request SOAP Message Object Saved.....\r\n");
		ByteArrayOutputStream baos = null;
		baos = new ByteArrayOutputStream();
		soapMessage.writeTo(baos);
		String strRequest = new String(baos.toByteArray());
		logger.info("(getCurrentRate) SOAP request for getting current rate is " + strRequest + " \r\n");
		return soapMessage;
	}

	private SOAPMessage getGtdTicketDetails(String dealTicket, Map<String, SystemParameters> properties)
			throws SOAPException, IOException {
		String serverURI = systemParameterService.getSystemParametersDescription1("BZPXESURI", properties);
		String nameSpaceUrl = systemParameterService.getSystemParametersDescription1("BZPXESPUR", properties);
		String nameSpacePort = systemParameterService.getSystemParametersDescription1("BZPDLHPRT", properties);

		String headerUrl = systemParameterService.getSystemParametersDescription1("BZPDLHINQ", properties);
		String headerPrefix = systemParameterService.getSystemParametersDescription1("BZPXEHPRE", properties);

		String serverPrefix = systemParameterService.getSystemParametersDescription1("BZPXESPRE", properties);

		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage soapMessage = messageFactory.createMessage();
		SOAPPart soapPart = soapMessage.getSOAPPart();
		SOAPEnvelope envelope = soapPart.getEnvelope();
		envelope.addNamespaceDeclaration("xsi", "http://www.w3.org/2001/XMLSchema-instance");
		envelope.addNamespaceDeclaration("xsd", "http://www.w3.org/2001/XMLSchema");
		envelope.addNamespaceDeclaration(serverPrefix, serverURI);
		SOAPBody soapBody = envelope.getBody();
		// QName bodyName = new QName("http://tempuri.org/",
		// "GetGTDTicketDetails");
		QName bodyName = new QName(nameSpaceUrl, nameSpacePort);
		SOAPBodyElement soapBodyElem = soapBody.addBodyElement(bodyName);
		soapBodyElem.addChildElement("SourceSystem").addTextNode("B2B");
		soapBodyElem.addChildElement("GTDTicket").addTextNode(dealTicket);
		MimeHeaders headers = soapMessage.getMimeHeaders();
		headers.addHeader(headerPrefix, headerUrl);
		soapMessage.saveChanges();
		ByteArrayOutputStream baos = null;
		baos = new ByteArrayOutputStream();
		soapMessage.writeTo(baos);
		String strRequest = new String(baos.toByteArray());
		logger.info("(getGtdTicketDetails)Request SOAP " + strRequest + " \r\n");
		return soapMessage;
	}

	@Override
	public FxDealResponseDTO updateDealDetails(String dealTicketNumber, String transactionRef,
			String financialTransactionType, String status, Map<String, SystemParameters> properties)
			throws WebServiceException {
		String xeUrl = systemParameterService.getSystemParametersDescription1("XE_URL", properties);
		SOAPConnectionFactory soapConnectionFactory = null;
		SOAPConnection soapConnection = null;
		SOAPMessage soapResponse = null;
		ByteArrayOutputStream baos = null;
		FxDealResponseDTO fxDealResponse = null;
		logger.info("(updateDealDetails) Inside getExchangeRate \r\n");
		try {

			baos = new ByteArrayOutputStream();
			ExchangeRateHandler xeHandler = new ExchangeRateHandler();
			soapConnectionFactory = SOAPConnectionFactory.newInstance();
			soapConnection = soapConnectionFactory.createConnection();
			soapResponse = soapConnection.call(
					updateGtdTicket(dealTicketNumber, transactionRef, financialTransactionType, status, properties),
					xeUrl);
			soapResponse.writeTo(baos);
			String fxResponse = new String(baos.toByteArray());
			logger.info("(FX updateDealDetails)updateDealDetails Response SOAP--- " + fxResponse + " ---\r\n");
			fxDealResponse = xeHandler.parseDealTicketResponse(fxResponse);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new WebServiceException("Request can't be processed by BSF due to technical problem");
		} finally {
			try {
				if (soapConnection != null)
					soapConnection.close();
				if (baos != null)
					baos.close();
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
		return fxDealResponse;
	}

	private SOAPMessage updateGtdTicket(String dealTicket, String trnRef, String trnType, String status,
			Map<String, SystemParameters> properties) throws SOAPException, IOException {
		String serverURI = systemParameterService.getSystemParametersDescription1("BZPXESURI", properties);
		String nameSpaceUrl = systemParameterService.getSystemParametersDescription1("BZPXESPUR", properties);
		String nameSpacePort = systemParameterService.getSystemParametersDescription1("BZPDLUPT", properties);

		String headerUrl = systemParameterService.getSystemParametersDescription1("BZPDLHUPD", properties);
		String headerPrefix = systemParameterService.getSystemParametersDescription1("BZPXEHPRE", properties);

		String serverPrefix = systemParameterService.getSystemParametersDescription1("BZPXESPRE", properties);

		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage soapMessage = messageFactory.createMessage();
		SOAPPart soapPart = soapMessage.getSOAPPart();
		SOAPEnvelope envelope = soapPart.getEnvelope();
		envelope.addNamespaceDeclaration("xsi", "http://www.w3.org/2001/XMLSchema-instance");
		envelope.addNamespaceDeclaration("xsd", "http://www.w3.org/2001/XMLSchema");
		envelope.addNamespaceDeclaration(serverPrefix, serverURI);
		SOAPBody soapBody = envelope.getBody();
		// QName bodyName = new QName("http://tempuri.org/", "UpdateGTDTicket");
		QName bodyName = new QName(nameSpaceUrl, nameSpacePort);
		SOAPBodyElement soapBodyElem = soapBody.addBodyElement(bodyName);
		soapBodyElem.addChildElement("SourceSystem").addTextNode("B2B");
		soapBodyElem.addChildElement("GTDTicket").addTextNode(dealTicket);
		soapBodyElem.addChildElement("TranRef").addTextNode(trnRef);
		soapBodyElem.addChildElement("TranType").addTextNode(trnType);
		soapBodyElem.addChildElement("Status").addTextNode(status);
		MimeHeaders headers = soapMessage.getMimeHeaders();
		headers.addHeader(headerPrefix, headerUrl);
		soapMessage.saveChanges();
		ByteArrayOutputStream baos = null;
		baos = new ByteArrayOutputStream();
		soapMessage.writeTo(baos);
		String strRequest = new String(baos.toByteArray());
		logger.info("(updateGtdTicket)Request SOAP " + strRequest + " ----\r\n");
		return soapMessage;
	}

}
