package com.bsf.macug.mt101.service;

import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.service.InterCustomerAccountsService;
import com.bsf.macug.customer.service.InterCustomerChargeService;
import com.bsf.macug.customer.service.InterCustomerDetailsService;
import com.bsf.macug.exception.CurrencyConversionException;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.exception.PossibleDuplicationException;
import com.bsf.macug.exception.ProcessException;
import com.bsf.macug.exception.TCPConnectionException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.mt101.dto.AcToAcTransferResponseDTO;
import com.bsf.macug.mt101.dto.AccountEnquiryResponseDTO;
import com.bsf.macug.mt101.dto.BusinessDateDTO;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.service.tuxedo.InterAcToAcTransferService;
import com.bsf.macug.mt101.service.tuxedo.InterAccountEnquiryService;
import com.bsf.macug.util.InterUtils;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Map;
import javax.xml.ws.WebServiceException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountToAccountServiceImpl implements InterAccountToAccountService {
	private static final Logger logger = Logger.getLogger(AccountToAccountServiceImpl.class.getName());

	@Autowired
	InterMT100ValidationUtil mT100ValidationUtil;

	@Autowired
	InterBusinessDateService businessDateService;

	@Autowired
	InterAccountEnquiryService accountEnquiryService;

	@Autowired
	InterMT100Util mT100Util;

	@Autowired
	InterUtils utils;

	@Autowired
	InterCustomerChargeService customerChargeService;

	@Autowired
	InterCustomerDetailsService customerDetailsService;

	@Autowired
	InterAcToAcTransferService acToAcTransferService;

	@Autowired
	InterCustomerAccountsService customerAccountsService;

	public MacPaymentDetail processPayment(MacPaymentDetail details,
			Map<String, Map<String, SystemParameters>> allSystemProperties) {
		Map<String, SystemParameters> errorCodeMap = null;
		try {
			logger.info("(processPayment) ==> ACtoAc payment insitated : "+details.getTransactionReference());
			Map<String, SystemParameters> macPropertyMap = (Map<String, SystemParameters>) allSystemProperties.get("macPropertyMap");
			errorCodeMap = (Map<String, SystemParameters>) allSystemProperties.get("errorCodeMap");
			Map<String, SystemParameters> tuxDetailMap = (Map<String, SystemParameters>) allSystemProperties.get("tuxDetailMap");
			Map<String, SystemParameters> tuxErrorCodeMap = (Map<String, SystemParameters>) allSystemProperties.get("tuxErrorCodeMap");
			Map<String, SystemParameters> exchangeRateMap = (Map<String, SystemParameters>) allSystemProperties.get("exchangeRateMap");

			BigDecimal accountToAccountCharge = customerChargeService.getCharge(details.getCustomerId(), "PAYMENT",
					"ACTOAC");

			CustomerDetails customerDetails = customerDetailsService.getCustomerDetails(details.getCustomerId());

			BusinessDateDTO businessDateDto = businessDateService.getBusinessDate("MACUG", macPropertyMap);
			if (!mT100ValidationUtil.isValidBusinessDate(businessDateDto)) {
				logger.error("(processPayment)==> Invalid business date.");
				return mT100Util.setStatusAndDescription(details, "FAILED", "MACVER001", errorCodeMap);
			}

			String debitAccount = details.getDebitAccount();
			CustomerAccounts debitAccountObj = customerAccountsService
					.getCustomerAccountDetails(details.getCustomerId(), debitAccount, "PAYMENT");
			if (debitAccountObj == null) {
				logger.error("(processPayment)==> Invalid debit account.");
				return mT100Util.setStatusAndDescription(details, "DE", "MACVER018", errorCodeMap);
			}

			AccountEnquiryResponseDTO enquiryResponseForDebitAccount = accountEnquiryService
					.buildAccountEnquiryResponse(debitAccount, tuxDetailMap);
			MacPaymentDetail errorDetails = mT100ValidationUtil.validateDebitAccount(details,
					enquiryResponseForDebitAccount, allSystemProperties);

			if (errorDetails != null) {
				logger.error("(processPayment)==>Debit account validation failed.");
				return errorDetails;
			}

			AccountEnquiryResponseDTO enquiryResponseForBenAccount = accountEnquiryService
					.buildAccountEnquiryResponse(details.getBeneficiaryInfo59(), tuxDetailMap);
			errorDetails = mT100ValidationUtil.validateBeneficiaryAccount(details, enquiryResponseForBenAccount,
					allSystemProperties);

			if (errorDetails != null) {
				logger.error("(processPayment)==> Ben account validation failed.");
				return errorDetails;
			}

			String debitCurrency = enquiryResponseForDebitAccount.getAccountCurrency();
			String creditCurrency = enquiryResponseForBenAccount.getAccountCurrency();
			String transactionCurrency = details.getCurrency();
			if (!mT100ValidationUtil.ifTransactionCurrencyEqualsDebitOrCreditCurrency(transactionCurrency,
					debitCurrency, creditCurrency)) {
				logger.info(
						"(validateAndProcessPayment)==> Checking IfTransactionCurrencyEqualsDebitOrCreditCurrency failed");

				return mT100Util.setStatusAndDescription(details, "DE", "MACVER005", errorCodeMap);
			}

			details.setCreditCurrency(creditCurrency);
			details.setDebitCurrency(debitCurrency);

			if (!mT100ValidationUtil.isValidRateIndicator(details, debitAccountObj)) {
				logger.info("(validateAndProcessPayment)==> isValidRateIndicator failed");

				return mT100Util.setStatusAndDescription(details, "DE", "MACVER026", errorCodeMap);
			}

			BigDecimal transactionAmount = details.getTransactionAmount();
			BigDecimal debitRate = mT100Util.getConversionRate(transactionAmount.toString(), debitCurrency,
					debitAccount, transactionCurrency, exchangeRateMap);

			BigDecimal creditRate = mT100Util.getConversionRate(transactionAmount.toString(), creditCurrency,
					debitAccount, transactionCurrency, exchangeRateMap);

			logger.info("(processPayment)==> transactionAmount : " + transactionAmount + "DebitRate : " + debitRate
					+ " , CreditRate : " + creditRate);

			BigDecimal debitAmount = debitRate.multiply(transactionAmount);
			BigDecimal creditAmount = creditRate.multiply(transactionAmount);

			BigDecimal amountInSAR = mT100Util.getAmountInSAR(transactionAmount, transactionCurrency, debitAccount,
					exchangeRateMap);

			BigDecimal debitAmountInSAR = mT100Util.getAmountInSAR(debitAmount, debitCurrency, debitAccount,
					exchangeRateMap);

			BigDecimal chargeAmount = mT100Util.calulateCharge(accountToAccountCharge, debitRate);
			BigDecimal debitAmountWithCharge = debitAmount.add(chargeAmount);

			String strAvailableBalance = enquiryResponseForDebitAccount.getAvailableBalance();
			if (!mT100ValidationUtil.isBalanceAvailable(strAvailableBalance, debitAmountWithCharge)) {
				logger.error("(processPayment)==>Insufficient balance.");
				return mT100Util.setStatusAndDescription(details, "DE", "MACVER022", errorCodeMap);
			}

			//boolean bsfLimit = mT100ValidationUtil.validateBSFLimit(customerDetails,enquiryResponseForBenAccount.getAccountNumber());
			if (!mT100ValidationUtil.isLimitAvailable(customerDetails, details.getValueDate(), 
					debitAmountInSAR, debitAccount)) {
				logger.error("(processPayment)==>Limit not availbale.");
				return mT100Util.setStatusAndDescription(details, "DE", "MACVER006", errorCodeMap);
			}

			details.setDebitAmount(debitAmountWithCharge);
			details.setCreditAmount(creditAmount);
			details.setDebitRate(debitRate);
			details.setCreditRate(creditRate);

			details.setTransactionAmountInSar(amountInSAR);
			details.setChargeAmount(chargeAmount);
			details.setDebitAccountBranch(enquiryResponseForDebitAccount.getAccountBranch());
			details.setCreditAccountBranch(enquiryResponseForBenAccount.getAccountBranch());

			AcToAcTransferResponseDTO acToAcTransferResponse = acToAcTransferService
					.buildAccountToAccountTransferResponse(details, customerDetails, businessDateDto,
							allSystemProperties);
			details.setPostedDate(new Timestamp(new Date().getTime()));

			if (acToAcTransferResponse == null) {
				logger.info("(validateAndProcessPayment)==> Transfer returned null. May be network error.");
				return mT100Util.setStatusAndDescription(details, "FAILED", "MACVER002", errorCodeMap);
			}

			String ftsActionCode = acToAcTransferResponse.getFtsActionCode();
			String cammActionCode = acToAcTransferResponse.getCammActionCode();
			details.setCammActionCode(cammActionCode);
			details.setFtsActionCode(ftsActionCode);
			if ((ftsActionCode.equals("0000")) && (cammActionCode.equals("0000"))) {
				details = mT100Util.setStatusAndDescription(details, "OK", "MACSUC001", errorCodeMap);
				mT100Util.updateLimit(details, debitAmountInSAR, customerDetails, debitAccount);
				return details;
			}
			logger.error("(processPayment)==> ftsActionCode : " + ftsActionCode);
			logger.error("(processPayment)==> calmActionCode : " + cammActionCode);
			return mT100Util.setStatusAndDescription(details, "DE", cammActionCode , tuxErrorCodeMap);
		} catch (WebServiceException e) {
			logger.error("Error : " + e.getMessage(), e);
			details = mT100Util.setStatusAndDescription(details, "FAILED", "MACVER002", errorCodeMap);
		} catch (CurrencyConversionException e) {
			logger.error("Error : " + e.getMessage(), e);
			details = mT100Util.setStatusAndDescription(details, "FAILED", "MACVER002", errorCodeMap);
		} catch (ProcessException e) {
			logger.error("Error : " + e.getMessage(), e);
			details = mT100Util.setStatusAndDescription(details, "FAILED", "MACVER002", errorCodeMap);
		} catch (DataAccessException e) {
			logger.error("Error : " + e.getMessage(), e);
			details = mT100Util.setStatusAndDescription(details, "FAILED", "MACVER002", errorCodeMap);
		} catch (CustomerNotFoundException e) {
			logger.error("Error : " + e.getMessage(), e);
			details = mT100Util.setStatusAndDescription(details, "FAILED", "MACVER008", errorCodeMap);
		} catch (TCPConnectionException e) {
			logger.error("Error : " + e.getMessage(), e);
			details = mT100Util.setStatusAndDescription(details, "FAILED", "MACVER002", errorCodeMap);
		} catch (PossibleDuplicationException e) {
			logger.error("Error : " + e.getMessage(), e);
			details = mT100Util.setStatusAndDescription(details, "FAILED", "MACVER007", errorCodeMap);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			details = mT100Util.setStatusAndDescription(details, "FAILED", "MACVER002", errorCodeMap);
		}
		return details;
	}
}