package com.bsf.macug.mt101.service;

import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.entity.CustomerLimits;
import com.bsf.macug.customer.service.InterCustomerAccountsService;
import com.bsf.macug.customer.service.InterCustomerLimitsService;
import com.bsf.macug.exception.SystemPropertyNotConfigurationException;
import com.bsf.macug.exception.ValidationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.dto.AccountEnquiryResponseDTO;
import com.bsf.macug.mt101.dto.BusinessDateDTO;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.util.IConstants;
import com.bsf.macug.util.IConstants.RATE_INDICATOR;
import com.bsf.macug.util.InterUtils;
import com.prowidesoftware.swift.model.field.Field30;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class MT100ValidationUtilImpl implements InterMT100ValidationUtil {
	private static final Logger logger = Logger.getLogger(MT100ValidationUtilImpl.class.getName());

	@Autowired
	InterMT100Util mT100Util;

	@Autowired
	InterCustomerAccountsService customerAccountsService;

	@Autowired
	InterCustomerLimitsService customerLimitsService;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterUtils utils;

	public void validExcutionDate(Field30 field30) throws ValidationException {
		try {
			if (field30 == null) {
				logger.error("(validExcutionDate)==> field30 is null.");
				throw new ValidationException("MACVER012");
			}

			String executionDate = field30.getValue();

			if (StringUtils.isEmpty(executionDate)) {
				logger.error("(validExcutionDate)==> executionDate is null or empty.");
				throw new ValidationException("MACVER012");
			}
			if (executionDate.length() != 6) {
				logger.error("(validExcutionDate)==> executionDate length is not equal to 6");
				throw new ValidationException("MACVER012");
			}

			DateFormat format = new SimpleDateFormat("yyMMdd");
			format.parse(executionDate);
		} catch (ValidationException e) {
			throw e;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new ValidationException("MACVER012");
		}
	}

	public void validateTransactionReference(String transactionReference) throws ValidationException {
		try {
			if (StringUtils.isEmpty(transactionReference)) {
				logger.error("(validateTransactionReference)==> Invalid transaction reference.");
				throw new ValidationException("MACVER011");
			}
			if (transactionReference.length() > 16) {
				logger.error("(validateTransactionReference)==> Invalid transaction reference.");
				throw new ValidationException("MACVER011");
			}
		} catch (ValidationException e) {
			throw e;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new ValidationException("MACVER011");
		}
	}

	public void validateAmountAndCurrency(String currencyAndAmount, Map<String, SystemParameters> currencyCodeMap)
			throws ValidationException {
		try {
			if (StringUtils.isEmpty(currencyAndAmount)) {
				logger.error("(validateAmountAndCurrency)==> Invalid currency.");
				throw new ValidationException("MACVER013");
			}
			if (currencyAndAmount.length() < 3)
				throw new ValidationException("MACVER013");
			if (currencyAndAmount.length() == 3) {
				throw new ValidationException("MACVER014");
			}

			String currency = currencyAndAmount.substring(0, 3);
			String amount = currencyAndAmount.substring(3);

			if (!currencyCodeMap.containsKey(currency)) {
				throw new ValidationException("MACVER013");
			}
			try {
				new BigDecimal(amount.replace(",", "."));
			} catch (Exception e) {
				throw new ValidationException("MACVER014");
			}
		} catch (ValidationException e) {
			throw e;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new ValidationException("MACVER013");
		}
	}

	public void validateBenBank(String benBank) throws ValidationException {
		try {
			if (StringUtils.isEmpty(benBank)) {
				logger.error("(validateBenBank)==> Invalid beneficiary bank.");
				throw new ValidationException("MACVER015");
			}
		} catch (ValidationException e) {
			throw e;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new ValidationException("MACVER015");
		}
	}

	public void validateBenAccount(String benAccount) throws ValidationException {
		try {
			if (StringUtils.isEmpty(benAccount)) {
				logger.error("(validateBenAccount)==> Invalid ben account.");
				throw new ValidationException("MACVER016");
			}
		} catch (ValidationException e) {
			throw e;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new ValidationException("MACVER016");
		}
	}

	public void validateDetailsOfCharge(String detailsOfCharge) throws ValidationException {
		try {
			if (StringUtils.isEmpty(detailsOfCharge)) {
				logger.error("(validateDetailsOfCharge)==> Invalid details of charge.");
				throw new ValidationException("MACVER017");
			}
		} catch (ValidationException e) {
			throw e;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new ValidationException("MACVER017");
		}
	}

	public boolean isValidBusinessDate(BusinessDateDTO businessDateDto) {
		logger.info("(isValidBusinessDate) == > businessDateDto : " + businessDateDto);
		if (businessDateDto == null) {
			return false;
		}
		Date businessDate = businessDateDto.getBusinessDate();
		Date systemDate = businessDateDto.getSystemDate();
		String time = businessDateDto.getTime();
		String statusCode = businessDateDto.getStatusCode();

		if (StringUtils.isEmpty(statusCode)) {
			return false;
		}

		if (!statusCode.equalsIgnoreCase("00")) {
			return false;
		}

		if (StringUtils.isEmpty(businessDate)) {
			return false;
		}

		if (StringUtils.isEmpty(systemDate)) {
			return false;
		}

		if (StringUtils.isEmpty(time)) {
			return false;
		}

		return true;
	}

	public boolean isAccountTypeAllowedForDebit(String accTypeDbt, Map<String, SystemParameters> accountTypeMap,
			String debitOrCredit) {
		logger.info("Check type " + debitOrCredit + " " + accTypeDbt);
		if (StringUtils.isEmpty(accTypeDbt)) {
			return false;
		}
		SystemParameters systemProperty = (SystemParameters) accountTypeMap.get(accTypeDbt.trim());
		boolean allowed = false;

		if (debitOrCredit.equals("D")) {
			if (systemProperty != null) {
				String description = systemProperty.getItemDescription1();
				if ((!StringUtils.isEmpty(description)) && (description.trim().equalsIgnoreCase("B"))) {
					allowed = true;
				} else if ((!StringUtils.isEmpty(description)) && (description.trim().equalsIgnoreCase("D"))) {
					allowed = true;
				}
			}
		} else if ((debitOrCredit.equals("C")) && (systemProperty != null)) {
			String description = systemProperty.getItemDescription1();
			if ((!StringUtils.isEmpty(description)) && (description.trim().equalsIgnoreCase("B"))) {
				allowed = true;
			} else if ((!StringUtils.isEmpty(description)) && (description.trim().equalsIgnoreCase("C"))) {
				allowed = true;
			}
		}
		return allowed;
	}

	public boolean isAccountStatusAllowedForDebit(String accStatusCodeDbt,
			Map<String, SystemParameters> accountStatusMap, String debitOrCredit) {
		boolean allowed = false;
		if (StringUtils.isEmpty(accStatusCodeDbt)) {
			return false;
		}

		if (debitOrCredit.equals("D")) {
			SystemParameters systemProperty = (SystemParameters) accountStatusMap.get(accStatusCodeDbt.trim());
			if (systemProperty != null) {
				String descirption = systemProperty.getItemDescription1();
				if ((!StringUtils.isEmpty(descirption)) && (descirption.trim().equalsIgnoreCase("B"))) {
					allowed = true;
				} else if ((!StringUtils.isEmpty(descirption)) && (descirption.trim().equalsIgnoreCase("D"))) {
					allowed = true;
				}
			}
		} else if (debitOrCredit.equals("C")) {
			SystemParameters systemProperty = (SystemParameters) accountStatusMap.get(accStatusCodeDbt.trim());
			if (systemProperty != null) {
				String descirption = systemProperty.getItemDescription1();
				if ((!StringUtils.isEmpty(descirption)) && (descirption.trim().equalsIgnoreCase("B"))) {
					allowed = true;
				} else if ((!StringUtils.isEmpty(descirption)) && (descirption.trim().equalsIgnoreCase("C"))) {
					allowed = true;
				}
			}
		}

		return allowed;
	}

	public MacPaymentDetail validateDebitAccount(MacPaymentDetail details,
			AccountEnquiryResponseDTO enquiryResponseForDebitAccount,
			Map<String, Map<String, SystemParameters>> allSystemProperties) {
		Map<String, SystemParameters> accountStatusMap = (Map) allSystemProperties.get("accountStatusMap");
		Map<String, SystemParameters> accountTypeMap = (Map) allSystemProperties.get("accountTypeMap");
		Map<String, SystemParameters> errorCodeMap = (Map) allSystemProperties.get("errorCodeMap");
		Map<String, SystemParameters> tuxErrorMap = (Map) allSystemProperties.get("tuxErrorMap");

		if (enquiryResponseForDebitAccount == null) {
			logger.info("(validateAndProcessPayment)==> Enquiry returned null. May be network error.");
			details = this.mT100Util.setStatusAndDescription(details, "FAILED", "MACVER002", errorCodeMap);
			return details;
		}

		String camActCodeDbt = enquiryResponseForDebitAccount.getCammActionCode();
		String ftsActCodeDbt = enquiryResponseForDebitAccount.getFtsActionCode();
		String accStatusCodeDbt = enquiryResponseForDebitAccount.getAccountStatusCode();
		String accTypeDbt = enquiryResponseForDebitAccount.getAccountType();
		String freezeFlag = enquiryResponseForDebitAccount.getFreezeFlag();
		if (!isAccountStatusAllowedForDebit(accStatusCodeDbt, accountStatusMap, "D")) {
			logger.info("(validateAndProcessPayment)==> Checking for staus code is valid failed");
			details = this.mT100Util.setStatusAndDescription(details, "DE", "MACVER003", errorCodeMap);
			return details;
		}

		if (!isAccountTypeAllowedForDebit(accTypeDbt, accountTypeMap, "D")) {
			logger.info("(validateAndProcessPayment)==> Checking for account type is valid failed");
			details = this.mT100Util.setStatusAndDescription(details, "DE", "MACVER004", errorCodeMap);
			return details;
		}

		if ((!"0000".equals(camActCodeDbt)) || (!"0000".equals(ftsActCodeDbt))) {
			logger.info("(validateAndProcessPayment)==> Checking for camm and fts code failed");
			details = this.mT100Util.setStatusAndDescription(details, "DE", ftsActCodeDbt, tuxErrorMap);
			return details;
		}

		if ("Y".equalsIgnoreCase(freezeFlag)) {
			logger.info("(validateAndProcessPayment)==> Checking freeze failed");
			details = this.mT100Util.setStatusAndDescription(details, "DE", "MACVER024", errorCodeMap);
			return details;
		}

		return null;
	}

	public MacPaymentDetail validateBeneficiaryAccount(MacPaymentDetail details,
			AccountEnquiryResponseDTO enquiryResponseForBenAccount,
			Map<String, Map<String, SystemParameters>> allSystemProperties) {
		Map<String, SystemParameters> accountStatusMap = allSystemProperties.get("accountStatusMap");
		Map<String, SystemParameters> accountTypeMap = allSystemProperties.get("accountTypeMap");
		Map<String, SystemParameters> errorCodeMap = allSystemProperties.get("errorCodeMap");
		Map<String, SystemParameters> tuxErrorMap = allSystemProperties.get("tuxErrorMap");

		if (enquiryResponseForBenAccount == null) {
			logger.info("(validateAndProcessPayment)==> Enquiry returned null. May be network error.");
			details = this.mT100Util.setStatusAndDescription(details, "DE", "MACVER002", errorCodeMap);
			return details;
		}

		String camActCodeBen = enquiryResponseForBenAccount.getCammActionCode();
		String ftsActCodeBen = enquiryResponseForBenAccount.getFtsActionCode();
		String accStatusCodeBen = enquiryResponseForBenAccount.getAccountStatusCode();
		String accTypeBen = enquiryResponseForBenAccount.getAccountType();
		String freezeFlag = enquiryResponseForBenAccount.getFreezeFlag();
		if (!isAccountStatusAllowedForDebit(accStatusCodeBen, accountStatusMap, "C")) {
			logger.info("(validateAndProcessPayment)==> Checking for staus code is valid failed");
			details = this.mT100Util.setStatusAndDescription(details, "DE", "MACVER003", errorCodeMap);
			return details;
		}

		if (!isAccountTypeAllowedForDebit(accTypeBen, accountTypeMap, "C")) {
			logger.info("(validateAndProcessPayment)==> Checking for account type is valid failed");
			details = this.mT100Util.setStatusAndDescription(details, "DE", "MACVER004", errorCodeMap);
			return details;
		}

		if ((!"0000".equals(camActCodeBen)) || (!"0000".equals(ftsActCodeBen))) {
			logger.info("(validateAndProcessPayment)==> Checking for camm and fts code for beneficary account failed");
			details = this.mT100Util.setStatusAndDescription(details, "FAILED", ftsActCodeBen, tuxErrorMap);
			return details;
		}

		if ("Y".equalsIgnoreCase(freezeFlag)) {
			logger.info("(validateAndProcessPayment)==> Checking freeze failed");
			details = this.mT100Util.setStatusAndDescription(details, "DE", "MACVER025", errorCodeMap);
			return details;
		}
		return null;
	}

	public boolean ifTransactionCurrencyEqualsDebitOrCreditCurrency(String transactionCurrency, String debitCurrency,
			String creditCurrency) {
		boolean status = false;
		if (transactionCurrency.equals(debitCurrency)) {
			status = true;
		} else if (transactionCurrency.equals(creditCurrency)) {
			status = true;
		}
		return status;
	}

	public boolean validateBSFLimit(CustomerDetails customerDetails, String accountNumber) {
		boolean bsfLimit = true;
		try {
			CustomerAccounts accounts = this.customerAccountsService
					.getCustomerAccountDetails(customerDetails.getCustomerId(), accountNumber, "PAYMENT");
			if (accounts != null) {
				bsfLimit = false;
			}
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return bsfLimit;
	}

	public boolean isLimitAvailable(CustomerDetails customerDetails, Date valueDate, BigDecimal debitAmountInSAR,
			String debitAccount) {
		try {
			CustomerAccounts accountInfo = customerAccountsService
					.getCustomerAccountDetails(customerDetails.getCustomerId(), debitAccount, "PAYMENT");
			if (accountInfo.getAccountTransferLimit().toString().equals("-1"))
				return true;

			CustomerLimits limitDetails = this.customerLimitsService.getData(customerDetails.getCustomerId(), valueDate,
					debitAccount);

			if (limitDetails == null) {
				this.customerLimitsService.insertData(customerDetails, valueDate, accountInfo);
				return true;
			}
			BigDecimal limit = limitDetails.getAvailableBSFLimit();

			if (debitAmountInSAR.compareTo(limit) == 1) {
				logger.warn(
						"(isACTOACLimitAvailable)==> limit : " + limit + " ,debitAmountInSAR : " + debitAmountInSAR);

				return false;
			}
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			return false;
		}
		return true;
	}

	public void validateDebitAccount(String account) throws ValidationException {
		try {
			if (StringUtils.isEmpty(account)) {
				logger.error("(validateBenAccount)==> Invalid ben account.");
				throw new ValidationException("MACVER018");
			}
		} catch (ValidationException e) {
			throw e;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new ValidationException("MACVER018");
		}
	}


	public void isValueDateAlreadyPassed(MacPaymentDetail macPaymentDetail) throws ValidationException {
		boolean passed = false;
		try {
			Map<String, Map<String, SystemParameters>> allSystemProperties = this.utils.loadSystemProperties();
			Map<String, SystemParameters> macPropertyMap = (Map) allSystemProperties.get("macPropertyMap");

			BigDecimal swiftDay = this.systemParameterService.getSystemParametersValue2("SWFVALDAY", macPropertyMap);
			String paymentTypeSwift = this.systemParameterService.getSystemParametersDescription1("PMTTYPSWF",
					macPropertyMap);

			Date valueDate = macPaymentDetail.getValueDate();
			String trnType = macPaymentDetail.getTransactionType();
			if (trnType.equalsIgnoreCase(paymentTypeSwift)) {
				Calendar date = new GregorianCalendar();

				date.set(11, 0);
				date.set(12, 0);
				date.set(13, 0);
				date.set(14, 0);
				date.add(5, swiftDay.intValue());
				Date today = date.getTime();
				logger.info("Today Date"+today);
				if (valueDate.before(today)) {
					passed = true;
				}
				logger.info("Value Date"+valueDate);
			} else {
				Calendar date = new GregorianCalendar();

				date.set(11, 0);
				date.set(12, 0);
				date.set(13, 0);
				date.set(14, 0);

				Date today = date.getTime();

				if (valueDate.before(today)) {
					passed = true;
				}
			}
		} catch (SystemPropertyNotConfigurationException e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new ValidationException("MACVER012");
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new ValidationException("MACVER012");
		}

		if (passed) {
			throw new ValidationException("MACVER012");
		}
	}

	public boolean isBalanceAvailable(String strAvailableBalance, BigDecimal debitAmountWithCharge) {
		try {
			logger.info("(isBalanceAvailable)==> strAvailableBalance : " + strAvailableBalance);
			logger.info("(isBalanceAvailable)==> debitAmountWithCharge : " + debitAmountWithCharge);
			BigDecimal availableBalance = new BigDecimal(strAvailableBalance.replace(",", "."));
			if (debitAmountWithCharge.compareTo(availableBalance) == 1) {
				return false;
			}
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			return false;
		}
		return true;
	}

	public boolean isValidRateIndicator(MacPaymentDetail details, CustomerAccounts debitAccountObj) {
		boolean status = false;
		IConstants.RATE_INDICATOR rateIndicator = debitAccountObj.getRateIndicator();
		//debitAccountObj.getRateIndicator();
		String creditCurrency = details.getCreditCurrency();
		String debitCurrency = details.getDebitCurrency();
		String transactionCurrency = details.getCurrency();
		boolean crossCurrency = false;
		if (!transactionCurrency.equalsIgnoreCase(debitCurrency)) {
			crossCurrency = true;
		} else if (!transactionCurrency.equalsIgnoreCase(creditCurrency)) {
			crossCurrency = true;
		}
		if (((IConstants.RATE_INDICATOR.SAME_CUR.ordinal() == rateIndicator.ordinal()))
				|| (IConstants.RATE_INDICATOR.NOT_SUPPORTED.ordinal() == rateIndicator.ordinal())
				&& (crossCurrency)) {
			status = false;
		} else {
			status = true;
		}

		return status;
	}

	public boolean isValidRateIndicatorSW(MacPaymentDetail details, CustomerAccounts debitAccountObj) {
		boolean status = false;
		IConstants.RATE_INDICATOR rateIndicator = debitAccountObj.getRateIndicator();
		String debitCurrency = details.getDebitCurrency();
		String transactionCurrency = details.getCurrency();
		boolean crossCurrency = false;
		if (!transactionCurrency.equalsIgnoreCase(debitCurrency)) {
			crossCurrency = true;
		}

		if (((rateIndicator == IConstants.RATE_INDICATOR.SAME_CUR)
				|| (rateIndicator == IConstants.RATE_INDICATOR.NOT_SUPPORTED)) && (crossCurrency)) {
			status = false;
		} else {
			status = true;
		}

		return status;
	}

	public boolean isFXPayments(MacPaymentDetail details, CustomerAccounts debitAccountObj) {
		boolean status = false;
		IConstants.RATE_INDICATOR rateIndicator = debitAccountObj.getRateIndicator();
		String debitCurrency = details.getDebitCurrency();
		String transactionCurrency = details.getCurrency();
		boolean crossCurrency = false;
		if (!transactionCurrency.equalsIgnoreCase(debitCurrency)) {
			crossCurrency = true;
		}

		if (((rateIndicator == IConstants.RATE_INDICATOR.URG_AUTO_FX)
				|| (rateIndicator == IConstants.RATE_INDICATOR.AUTO_FX)) && (crossCurrency)) {
			status = true;
		} else {
			status = false;
		}

		return status;
	}

	public boolean checkValidTradeExecutionTime(Date tradeDate,
			Map<String, Map<String, SystemParameters>> allSystemProperties) {
		try {
			Map<String, SystemParameters> macPropertyMap = allSystemProperties.get("macPropertyMap");
			String startTime = this.systemParameterService.getSystemParametersDescription1("TRADE_TIME",
					macPropertyMap);
			String endTime = this.systemParameterService.getSystemParametersDescription2("TRADE_TIME", macPropertyMap);
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
			Date d1 = sdf.parse(startTime);
			Date d2 = sdf.parse(endTime);

			Date today = new Date();

			if ((today.getTime() >= d1.getTime()) && (today.getTime() < d2.getTime())) {
				return true;
			}
			return false;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return false;
	}
}