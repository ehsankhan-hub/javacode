package com.bsf.macug.mt101.service;

import com.bsf.macug.application.mail.service.InterMailService;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.entity.MacPaymentActivityLog;
import com.bsf.macug.mt101.entity.MacPaymentHeader;
import com.bsf.macug.mt101.service.thread.MT199BasicValidationService;
import com.bsf.macug.mt101.service.thread.MT199Service;
import com.bsf.macug.mt101.service.thread.MTMessageHandler;
import com.bsf.macug.mt101.service.thread.ProcessNewFINFile;
import com.bsf.macug.mt101.service.thread.ProcessNewFileActFile;
import com.bsf.macug.mt101.service.thread.ProcessPaymentService;
import com.bsf.macug.util.GenericExtFilter;
import com.bsf.macug.util.InterFileUtils;
import com.bsf.macug.util.InterUtils;
import java.io.File;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

@Service
public class MT101ServiceImpl implements InterMT101Service {
	private static final Logger logger = Logger.getLogger(MT101ServiceImpl.class.getName());

	@Value("${mt100.src.ext}")
	private String FILE_EXT;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterFileUtils fileUtils;

	@Autowired
	InterPaymentService paymentService;

	@Autowired
	TaskExecutor taskExecutor;

	@Autowired
	private ApplicationContext applicationContext;

	@Autowired
	InterUtils utils;

	@Autowired
	InterMailService mailService;

	public void processFile() {
		try {
			ThreadPoolTaskExecutor taskExecutorPool = (ThreadPoolTaskExecutor) taskExecutor;
			logger.info("\r\nProcess MT101 started at " + new Date());
			Map<String, Map<String, SystemParameters>> allProperties = utils.loadSystemProperties();

			Map<String, SystemParameters> macPathProperties = (Map<String, SystemParameters>) allProperties
					.get("macPathMap");
			Map<String, SystemParameters> macProperties = allProperties.get("macPropertyMap");
			// 400 size
			BigDecimal maxThreadCount = systemParameterService.getSystemParametersValue1("MACTHRDQUE", macProperties);
			String finSourcePath = systemParameterService.getSystemParametersDescription2("MT101_FIN_SRC",
					macPathProperties);
			String envelopSourcePath = systemParameterService.getSystemParametersDescription2("ENVELOP_FILE",
					macPathProperties);	
			logger.info("FIN source path location is " + finSourcePath);
			int totalThread = maxThreadCount.intValue() / 6;
			File folder = new File(finSourcePath);
			File[] listOfFiles = folder.listFiles(new GenericExtFilter(FILE_EXT));
			int i = 1;
			logger.info("Total files found under the location " + finSourcePath + " is " + listOfFiles.length);
			listOfFiles = fileUtils.sortFilesByCreationTime(listOfFiles);
			for (File file : listOfFiles) {
				if (fileUtils.isFileReadyToRead(file)) {
					if (i == totalThread) {
						break;
					}
					logger.info("(processFile)==> Processing of FIN file starts...." + file.getAbsolutePath());
					ProcessNewFINFile validationHandler = (ProcessNewFINFile) applicationContext
							.getBean(ProcessNewFINFile.class);
					validationHandler.setReuestFileName(file.getAbsolutePath());
					taskExecutor.execute(validationHandler);
					i++;
				}
			}

			String fileactSourcePath = systemParameterService.getSystemParametersDescription2("MT101_FIL_SRC",
					macPathProperties);
			logger.info("FILEACT source path location is " + finSourcePath);
			File filFolder = new File(fileactSourcePath);
			File[] listOfFilFiles = filFolder.listFiles(new GenericExtFilter(FILE_EXT));
			int j = 1;
			logger.info("FILEACT Total files found under the location " + fileactSourcePath + " is "
					+ listOfFilFiles.length);
			listOfFilFiles = fileUtils.sortFilesByCreationTime(listOfFilFiles);
			for (File file : listOfFilFiles) {
				if (fileUtils.isFileReadyToRead(file)) {
					if (j == totalThread) {
						break;
					}
					logger.info("(processFile)==> Processing of FILEACT file starts...." + file.getAbsolutePath());
					ProcessNewFileActFile validationHandler = (ProcessNewFileActFile) applicationContext
							.getBean(ProcessNewFileActFile.class);
					validationHandler.setReuestFileName(file.getAbsolutePath());
					// validationHandler.setActivityLogObj(macPaymnetActivLog);
					taskExecutor.execute(validationHandler);
					j++;
				}
			}

			int k = 1;
			List<MacPaymentHeader> recievedHeaderList = paymentService.findAllHeader("RECEIVED");
			logger.info("Total header records with RECEIVED status is "
					+ ((recievedHeaderList != null) ? recievedHeaderList.size() : 0));
			for (MacPaymentHeader macPaymentHeader : recievedHeaderList) {
				try {
					if (k == totalThread) {
						break;
					}
					macPaymentHeader.setProcessingStatus(Integer.valueOf(1));
					paymentService.updateHeader(macPaymentHeader);
					macPaymentHeader = paymentService.getHeader(macPaymentHeader.getCustomerId(),
							macPaymentHeader.getFileReference());
					MTMessageHandler mtMessage = (MTMessageHandler) applicationContext.getBean(MTMessageHandler.class);
					mtMessage.setHeaderObj(macPaymentHeader);

					taskExecutor.execute(mtMessage);
					k++;
				} catch (Exception e) {
					logger.error("Payment header thread creation error. Error " + e.getMessage(), e);
				}

			}

			int l = 1;
			List<MacPaymentHeader> readyHeaderList = paymentService.findAllHeader("READY");
			logger.info("Total header records with READY status is "
					+ ((readyHeaderList != null) ? readyHeaderList.size() : 0));
			for (MacPaymentHeader macPaymentHeader : readyHeaderList) {
				if (l == totalThread) {
					break;
				}
				macPaymentHeader.setProcessingStatus(Integer.valueOf(1));
				paymentService.updateHeader(macPaymentHeader);
				macPaymentHeader = paymentService.getHeader(macPaymentHeader.getCustomerId(),
						macPaymentHeader.getFileReference());
				ProcessPaymentService paymentService = (ProcessPaymentService) applicationContext
						.getBean(ProcessPaymentService.class);
				paymentService.setHeaderObj(macPaymentHeader);

				taskExecutor.execute(paymentService);
				l++;
			}

			// MT199 Response file generation if basic validation is getting failed

			int n = 1;
			List<MacPaymentActivityLog> macPaymentActiLog = paymentService.getMT199BasicValidation();
			logger.info("Total MT199 count is " + ((macPaymentActiLog != null) ? macPaymentActiLog.size() : 0));
			if(macPaymentActiLog!=null) {
			for (MacPaymentActivityLog macPaymentActLog : macPaymentActiLog) {
				if (n == totalThread) {
					break;
				}

				logger.info("Request File Name :" + macPaymentActLog.getCustReqFile());
				macPaymentActLog.setProcessStatus(Integer.valueOf(1));
				paymentService.updatePaymnetProcessLog(macPaymentActLog);
				macPaymentActLog = paymentService
						.getPaymentProcessLogByFileName(macPaymentActLog.getCustReqFile().trim());

				MT199BasicValidationService basicValidationService = (MT199BasicValidationService) applicationContext
						.getBean(MT199BasicValidationService.class);

				basicValidationService.setActivityLogObj(macPaymentActLog);
				basicValidationService.setEnvelopSourcePath(envelopSourcePath);
				taskExecutor.execute(basicValidationService);
				n++;

			}
			}
			int m = 1;
			List<MacPaymentHeader> mt199Headers = paymentService.getMT199Pendings();
            
			logger.info("Total MT199 count is " + ((mt199Headers != null) ? mt199Headers.size() : 0));
			if(mt199Headers!=null) {
			for (MacPaymentHeader macPaymentHeader : mt199Headers) {
				if (m == totalThread) {
					break;
				}
				macPaymentHeader.setProcessingStatus(Integer.valueOf(1));
				paymentService.updateHeader(macPaymentHeader);
				macPaymentHeader = paymentService.getHeader(macPaymentHeader.getCustomerId(),
						macPaymentHeader.getFileReference());
				MT199Service paymentService = (MT199Service) applicationContext.getBean(MT199Service.class);
				paymentService.setHeaderObj(macPaymentHeader);
				paymentService.setEnvelopSourcePath(envelopSourcePath);

				taskExecutor.execute(paymentService);
				m++;
			}
			}
			for (;;) {
				int count = taskExecutorPool.getActiveCount();
				logger.info("Active Threads : " + count);
				try {
					Thread.sleep(30000);
					// Thread.sleep(60000);
				} catch (InterruptedException e) {

				}
				if (count == 0) {
					logger.info("Shutting down task executor pool, active thread count is " + count);
					taskExecutorPool.shutdown();
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error : " + e.getMessage(), e);
		} finally {
			System.exit(0);
		}

	}
}
