package com.bsf.macug.mt101.service;

import java.util.Map;

import javax.xml.ws.WebServiceException;

import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.mt101.dto.ValueDateSoapDTO;

public interface InterValueDateSOAPService {

	ValueDateSoapDTO getNextValueDate(ValueDateSoapDTO valueDateSoapDto, Map<String, SystemParameters> properties)
			throws WebServiceException;

}
