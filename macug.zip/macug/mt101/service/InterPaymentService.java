package com.bsf.macug.mt101.service;

import java.util.Date;
import java.util.List;

import com.bsf.macug.mt101.entity.ForeignHoliday;
import com.bsf.macug.mt101.entity.MacFileLog;
import com.bsf.macug.mt101.entity.MacPaymentActivityLog;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.entity.MacPaymentHeader;

public interface InterPaymentService {
	public boolean saveHeader(MacPaymentHeader paramMacPaymentHeader);

	public boolean updateHeader(MacPaymentHeader paramMacPaymentHeader);

	public List<MacPaymentHeader> findAllHeader(String paramString);

	public MacPaymentHeader getHeader(String paramString1, String paramString2);

	public boolean saveDetail(MacPaymentDetail paramMacPaymentDetail);

	public boolean updateDetail(MacPaymentDetail paramMacPaymentDetail);

	public List<MacPaymentDetail> findAllDetail(String paramString1, String paramString2, String paramString3);

	public MacPaymentDetail getDetail(String paramString1, String paramString2, String paramString3);

	public Long getSequence(String paramString);

	public List<MacPaymentHeader> getMT199Pendings();

	public List<MacPaymentDetail> getAllFailedTransactions(String fileReference);

	public boolean savePaymentLog(MacFileLog paramMacFileLog);

	public List<ForeignHoliday> getForeignHoliday(Date paramDate, String paramString1, String paramString2);

	public List<Object[]> getTransactionTypeCount(String paramString1, String paramString2);

	public List<Object[]> getStatusCount(String paramString1, String paramString2);
	
	public MacFileLog getFileLog(String id);

	public boolean updateFileLog(MacFileLog log);
	public List<MacPaymentActivityLog>  getMT199BasicValidation();
	public boolean updatePaymnetProcessLog(MacPaymentActivityLog activityLog);
	public MacPaymentActivityLog getPaymentProcessLogByFileName(String fileName) ;
}