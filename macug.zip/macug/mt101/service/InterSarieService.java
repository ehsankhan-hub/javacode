package com.bsf.macug.mt101.service;

import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import java.util.Map;

public interface InterSarieService {
	public MacPaymentDetail processPayment(MacPaymentDetail paramMacPaymentDetail,
			Map<String, Map<String, SystemParameters>> paramMap);
}