package com.bsf.macug.mt101.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.bsf.macug.exception.TCPConnectionException;
import com.bsf.macug.mt101.dao.InterFTSTuxKeyDAO;
import com.bsf.macug.mt101.entity.FTSTuxKey;

@Service
@Transactional
public class FTSTuxKeyServiceImpl implements InterFTSTuxKeyService {

	private static final Logger logger = Logger
			.getLogger(FTSTuxKeyServiceImpl.class);

	@Autowired
	InterFTSTuxKeyDAO ftsTuxKeyDAO;

	@Override
	public boolean saveFTSTuxKey(FTSTuxKey ftsTuxKey)
			throws Exception {
		if(ftsTuxKey==null){
			logger.info("FTS key saving failed. Canceling posting");
			throw new TCPConnectionException("FTS key duplicated");			
		}
		if(StringUtils.isEmpty(ftsTuxKey.getFtsReference())){
			logger.info("FTS key not avaiable. Canceling posting");
			throw new TCPConnectionException("FTS key not present");	
		}
		try {
			logger.info("Saving FTS key "+ftsTuxKey.toString());
			ftsTuxKeyDAO.saveFTSTuxKey(ftsTuxKey);
		} catch (Exception e) {
			logger.info("Error in saving FTS key to avoid duplication. Error "
					+ e.getMessage(), e);
			throw new Exception("FTS key duplicated");
		}
		return true;
	}

	@Override
	public boolean updateFTSTuxKey(FTSTuxKey ftsTuxKey) throws Exception {
		boolean status = false;
		try {
			logger.info("updateFTSTuxKey FTS key "+ftsTuxKey.toString());
			ftsTuxKeyDAO.updateFTSTuxKey(ftsTuxKey);
			status = true;
		} catch (Exception e) {
			logger.info("Error in update FTS key to avoid duplication. Error "
					+ e.getMessage(), e);
		}
		return status;
	}

	@Override
	public FTSTuxKey getFTSTuxKey(String ftsTuxKey) throws Exception {
		FTSTuxKey obj = null;
		try {
			obj = ftsTuxKeyDAO.getFTSTuxKey(ftsTuxKey);
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
		}
		return obj;
	}

}
