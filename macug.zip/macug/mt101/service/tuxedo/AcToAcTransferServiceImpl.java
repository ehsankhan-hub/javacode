package com.bsf.macug.mt101.service.tuxedo;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.exception.PossibleDuplicationException;
import com.bsf.macug.exception.TCPConnectionException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.dto.AcToAcTransferRequestDTO;
import com.bsf.macug.mt101.dto.AcToAcTransferResponseDTO;
import com.bsf.macug.mt101.dto.BusinessDateDTO;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.service.InterMT100Util;

@Service("accountTransferService")
public class AcToAcTransferServiceImpl implements InterAcToAcTransferService {
	private static final Logger logger = Logger.getLogger(AcToAcTransferServiceImpl.class.getName());

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterTuxedoPosting tuxedoPosting;

	@Autowired
	InterMT100Util mT100Util;

	@Override
	public AcToAcTransferResponseDTO buildAccountToAccountTransferResponse(MacPaymentDetail detailsObj,
			CustomerDetails customerDetails, BusinessDateDTO businessDateDto,
			Map<String, Map<String, SystemParameters>> allSystemProperties)
			throws TCPConnectionException, PossibleDuplicationException {

		Map<String, SystemParameters> tuxDetailMap = allSystemProperties.get("tuxDetailMap");
		Map<String, SystemParameters> chargeMap = allSystemProperties.get("chargeMap");

		String sourceSystem = systemParameterService.getSystemParametersDescription1("TUXSOURCE", tuxDetailMap);

		// To append init branch officer, camm code, fts code and transaction
		// type
		String strInitBranch = systemParameterService.getSystemParametersDescription1("INTBRANCH", tuxDetailMap);
		String strInitOfficer = systemParameterService.getSystemParametersDescription1("INTOFFICE", tuxDetailMap);
		String strACCAMMCode = systemParameterService.getSystemParametersDescription1("ACCAMCOD", tuxDetailMap);
		String strACFTSCode = systemParameterService.getSystemParametersDescription1("ACFTSCOD", tuxDetailMap);
		String strACType = systemParameterService.getSystemParametersDescription1("TRACTYPE", tuxDetailMap);

		String requestFunction = systemParameterService.getSystemParametersDescription2("PAYTUXREQ", tuxDetailMap);
		AcToAcTransferResponseDTO response = null;
		try {
			String acToAcTransferRequestString = buildAccountToAccountTransferRequest(detailsObj, businessDateDto,
					sourceSystem, strInitBranch, strInitOfficer, strACCAMMCode, strACFTSCode, strACType,
					requestFunction);
			String ftsRef = detailsObj.getFtsReference();
			if (!mT100Util.saveFTSKey(detailsObj.getTransactionReference(), ftsRef, acToAcTransferRequestString,
					"FIN")) {
				logger.error("Duplicate fts trying to save...");
				throw new PossibleDuplicationException();
			}
			if (!mT100Util.savePaymentUniqueSeries(detailsObj.getCustomerId(), detailsObj.getDebitAccount(),
					detailsObj.getBeneficiaryInfo59(), detailsObj.getTransactionAmount(), detailsObj.getValueDate(),
					customerDetails)) {
				logger.error("Duplicate fts trying to save...");
				throw new PossibleDuplicationException();
			}
			String acToAcTransferResponseString = postAccountToAccountTransferResponse(acToAcTransferRequestString,
					tuxDetailMap);

			mT100Util.updateFTSKey(detailsObj.getTransactionReference(), ftsRef, acToAcTransferResponseString);

			if (StringUtils.isEmpty(acToAcTransferResponseString)) {
				return null;
			} else if(acToAcTransferResponseString.equals("-1")) {
				logger.error("Tuxedo has given response as -1");
				return null;
			}
			
			response = new AcToAcTransferResponseDTO();
			acToAcTransferResponseString = acToAcTransferResponseString.substring(4);
			response.setSrcSystem(acToAcTransferResponseString.substring(0, 3));
			response.setReqFunction(acToAcTransferResponseString.substring(3, 11));
			response.setSeverDate(acToAcTransferResponseString.substring(11, 19));
			response.setServerTime(acToAcTransferResponseString.substring(19, 25));
			response.setFtsReference(acToAcTransferResponseString.substring(25, 35));
			response.setFtsTransFunc(acToAcTransferResponseString.substring(35, 45));
			response.setCammTranNum(acToAcTransferResponseString.substring(45, 51));
			response.setNumOfBlocks(acToAcTransferResponseString.substring(51, 54));
			response.setCurrBlockNum(acToAcTransferResponseString.substring(54, 57));
			response.setNumOfItems(acToAcTransferResponseString.substring(57, 60));
			response.setCustCode(acToAcTransferResponseString.substring(60, 70));
			response.setAccountNumberAsPerRequest(acToAcTransferResponseString.substring(70, 90));
			response.setInitBranch(acToAcTransferResponseString.substring(90, 96));
			response.setInitOfficer(acToAcTransferResponseString.substring(96, 105));
			response.setCardNumber(acToAcTransferResponseString.substring(105, 128));
			response.setCammActionCode(acToAcTransferResponseString.substring(128, 132));
			response.setLastUpdateDate(acToAcTransferResponseString.substring(132, 140));
			response.setLastUpdateTime(acToAcTransferResponseString.substring(140, 146));
			response.setTranStatus(acToAcTransferResponseString.substring(146, 149));
			response.setFtsActionCode(acToAcTransferResponseString.substring(149, 153));
			response.setProcessingSeq(acToAcTransferResponseString.substring(153, 156));
			response.setDetailLength(acToAcTransferResponseString.substring(156, 160));

			logger.info("Response message : " + response);
		} catch (PossibleDuplicationException e) {
			logger.error("Error : " + e.getMessage(), e);
			throw e;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			response = null;
		}

		return response;
	}

	private String buildAccountToAccountTransferRequest(MacPaymentDetail detailsObj, BusinessDateDTO businessDateDto,
			String sourceSystem, String strInitBranch, String strInitOfficer, String strACCAMMCode, String strACFTSCode,
			String strACType, String requestFunction) throws Exception {
		AcToAcTransferRequestDTO acToAcTransferRequest = new AcToAcTransferRequestDTO();
		DecimalFormat formatChargedAmount = new DecimalFormat("0000000000000.00");

		DecimalFormat foramtRateAmount = new DecimalFormat("00.000000");
		// chargeAmount=5.0;
		// chargedAccount="00000000001187000446";
		String chargedAmountFormat = formatChargedAmount.format(detailsObj.getChargeAmount());

		String creditAmount = formatChargedAmount.format(detailsObj.getCreditAmount());
		String amount = formatChargedAmount.format(detailsObj.getTransactionAmount());
		String debitAmount = formatChargedAmount.format(detailsObj.getDebitAmount());
		String amountInSar = formatChargedAmount.format(detailsObj.getTransactionAmountInSar());
		if (new BigDecimal(creditAmount).compareTo(BigDecimal.ZERO) == 0
				|| new BigDecimal(amount).compareTo(BigDecimal.ZERO) == 0
				|| new BigDecimal(debitAmount).compareTo(BigDecimal.ZERO) == 0
				|| new BigDecimal(amountInSar).compareTo(BigDecimal.ZERO) == 0) {
			logger.error("(buildAccountToAccountTransferRequest)==> One of the amount is zero...");
			throw new Exception();
		}

		String orderingAccount = detailsObj.getDebitAccount();
		String benAccount = detailsObj.getBeneficiaryInfo59();
		String formatedOrderingAccount = getFormattedAccountNumber(orderingAccount, 20);
		String formatedBenAccount = getFormattedAccountNumber(benAccount, 20);
		String dbtAccBranch = detailsObj.getDebitAccountBranch();
		String crdAccBranch = detailsObj.getCreditAccountBranch();
		String debitAccountCurrency = detailsObj.getDebitCurrency();
		String creditAccountCurrency = detailsObj.getCreditCurrency();

		String creditCurrencyRate = foramtRateAmount.format(detailsObj.getCreditRate());
		String debitCurrencyRate = foramtRateAmount.format(detailsObj.getDebitRate());

		DateFormat format = new SimpleDateFormat("yyyyMMdd");
		Date businessDateObj = businessDateDto.getBusinessDate();
		String currentDate = format.format(businessDateDto.getSystemDate());
		String currentTime = businessDateDto.getTime().replace(":", "");
		String businessDate = format.format(businessDateObj);

		Date date = new Date();
		DateFormat timeformat = new SimpleDateFormat("HHmmss");
		String lastUpdatedDate = format.format(date);
		String lastUpdateTime = timeformat.format(date);

		// Date valueDateObj = valueDateDto.getCalulatedExpressValueDate();
		SimpleDateFormat vformat = new SimpleDateFormat("yyMMdd");
		String valueDate = format.format(detailsObj.getValueDate());

		// logger.info(" Debit amount=" + debitAmount);
		String transactionAmount = getFormattedTransactionAmount(amount);

		String debitAmountFormated = getFormattedTransactionAmount(debitAmount);
		// logger.info(" Debit debitAmountFormated value=" +
		// debitAmountFormated);
		String creditAmountFormated = getFormattedTransactionAmount(creditAmount);
		String transactionAmountInSar = getFormattedTransactionAmount(amountInSar);
		String generalNarrative = getGeneralNarrative(detailsObj.getTransactionReference(), benAccount,
				detailsObj.getRemittanceInfo70(), strACType);
		detailsObj.setTuxNarative(generalNarrative);
		// String screenNarrative = "Transaction by MAC";
		acToAcTransferRequest.setSrcSystem(sourceSystem);
		if (!StringUtils.isEmpty(requestFunction)) {
			requestFunction = requestFunction.trim();
		} else {
			requestFunction = "FINUPD04";
		}
		acToAcTransferRequest.setReqFunction(requestFunction);
		/*
		 * if(mT100Util.isFutureValueDate(valueDate)) {
		 * acToAcTransferRequest.setReqFunction("FINUPD04"); }
		 */
		acToAcTransferRequest.setServerDate(businessDate);
		acToAcTransferRequest.setServerTime(lastUpdateTime);

		String ftsRef = detailsObj.getFtsReference();

		acToAcTransferRequest.setFtsReference(ftsRef);// generateFtsRefNumber
		acToAcTransferRequest.setFtsTransFunc("          ");
		acToAcTransferRequest.setCammTranNum("000000");
		acToAcTransferRequest.setNumOfBlocks("001");
		acToAcTransferRequest.setCurrBlockNum("001");
		acToAcTransferRequest.setNumOfItems("001");
		acToAcTransferRequest.setCustomerCode("          ");
		acToAcTransferRequest.setAccountNumber("                    ");
		if (strInitBranch != null) {
			if (strInitBranch.trim().length() == 3)
				acToAcTransferRequest.setInitBranch(strInitBranch + "   ");
			else
				acToAcTransferRequest.setInitBranch("066   ");
		} else {
			acToAcTransferRequest.setInitBranch("066   ");
		}
		if (strInitOfficer != null) {
			if (strInitOfficer.trim().length() == 7)
				acToAcTransferRequest.setInitOfficer(strInitOfficer + "  ");
			else
				acToAcTransferRequest.setInitOfficer("MACAUTO  ");
		} else {
			acToAcTransferRequest.setInitOfficer("MACAUTO  ");
		}
		acToAcTransferRequest.setCardNumber("                       ");
		// acToAcTransferRequest.setFunctionCode(" "); // Function code is not
		// set
		if (strACCAMMCode != null) {
			if (strACCAMMCode.trim().length() == 4)
				acToAcTransferRequest.setCammActionCode(strACCAMMCode);
			else
				acToAcTransferRequest.setCammActionCode("5555");
		} else {
			acToAcTransferRequest.setCammActionCode("5555");
		}

		acToAcTransferRequest.setLastUpdateDate(lastUpdatedDate);
		acToAcTransferRequest.setLastUpdateTime(lastUpdateTime);
		acToAcTransferRequest.setTransactionStatus("NOR");
		if (strACFTSCode != null) {
			if (strACFTSCode.length() == 4)
				acToAcTransferRequest.setFtsActionCode(strACFTSCode);
			else
				acToAcTransferRequest.setFtsActionCode("6666");
		} else {
			acToAcTransferRequest.setFtsActionCode("6666");
		}
		acToAcTransferRequest.setProcessingSeq("000");
		acToAcTransferRequest.setDetailLength("0971"); // 0971
		if (strACType != null) {
			if (strACType.length() == 4)
				acToAcTransferRequest.setTransactionType(strACType);
			else
				acToAcTransferRequest.setTransactionType("#050");
		} else {
			acToAcTransferRequest.setTransactionType("#050");
		}
		// acToAcTransferRequest.setTransactionDate(currentDate);
		// To add business Date from SOAP service
		acToAcTransferRequest.setTransactionDate(businessDate);
		acToAcTransferRequest.setValueDate(valueDate);
		acToAcTransferRequest.setTransactionCurrency(detailsObj.getCurrency());
		acToAcTransferRequest.setTransactionAmount(transactionAmount);
		acToAcTransferRequest.setTransactionAmountSAR(transactionAmountInSar);
		acToAcTransferRequest.setGeneralNarrative(generalNarrative); // /MAC#0509911111%BSFRSARI
																		// %48748600136%/ROC/200099486
																		// -
		acToAcTransferRequest.setScreenNarrative("                    ");
		acToAcTransferRequest.setDbAccountNumber(formatedOrderingAccount);
		acToAcTransferRequest.setDbAccountCurrency(debitAccountCurrency);
		acToAcTransferRequest.setDbAmount(debitAmountFormated);
		acToAcTransferRequest.setDbCurrencyRate(debitCurrencyRate);
		acToAcTransferRequest.setDbValueDate(valueDate);
		acToAcTransferRequest.setDbSrfFlag("Y");
		acToAcTransferRequest.setDbBranch(dbtAccBranch);
		acToAcTransferRequest.setCrAccountNumber(formatedBenAccount);
		acToAcTransferRequest.setCrAccountCurrency(creditAccountCurrency);
		acToAcTransferRequest.setCrAmount(creditAmountFormated);
		acToAcTransferRequest.setCrCurrencyRate(creditCurrencyRate);
		acToAcTransferRequest.setCrValueDate(valueDate);
		acToAcTransferRequest.setCrSrfFlag("N");
		acToAcTransferRequest.setCrBranch(crdAccBranch);
		acToAcTransferRequest.setCommissionCurrency("SAR");
		acToAcTransferRequest.setCommissionAmount("0000000000000.00");
		acToAcTransferRequest.setCommissionAccount("00000000000000000000");
		acToAcTransferRequest.setChargesCurrency(debitAccountCurrency);
		acToAcTransferRequest.setChargesAmount(chargedAmountFormat);
		acToAcTransferRequest.setChargesAccount("00000000000000000000");
		acToAcTransferRequest.setGtdDealTicket("                    ");
		acToAcTransferRequest.setInitTime(lastUpdateTime);
		acToAcTransferRequest.setValidationOfficer("         ");
		acToAcTransferRequest.setValidationTime(lastUpdateTime);
		acToAcTransferRequest.setAuthorizationOfficer("         ");
		acToAcTransferRequest.setAuthorizationTime(lastUpdateTime);
		acToAcTransferRequest.setAuthorizationReason("          ");
		acToAcTransferRequest.setAuthorizationStatus("      ");
		acToAcTransferRequest.setDynamicPartLength("160"); // 088
		acToAcTransferRequest.setStaticPartChequeNumber("               ");
		acToAcTransferRequest.setStaticPartIdType("      ");
		acToAcTransferRequest.setStaticPartIdNumber("                    ");
		acToAcTransferRequest.setStaticPartPrintDetail(" ");
		acToAcTransferRequest.setStaticPartMailAdvice(" ");
		StringBuilder acToAcTransferRequestMsg = new StringBuilder();
		acToAcTransferRequestMsg.append(acToAcTransferRequest.getSrcSystem())
				.append(acToAcTransferRequest.getReqFunction()).append(acToAcTransferRequest.getServerDate())
				.append(acToAcTransferRequest.getServerTime()).append(acToAcTransferRequest.getFtsReference())
				.append(acToAcTransferRequest.getFtsTransFunc()).append(acToAcTransferRequest.getCammTranNum())
				.append(acToAcTransferRequest.getNumOfBlocks()).append(acToAcTransferRequest.getCurrBlockNum())
				.append(acToAcTransferRequest.getNumOfItems()).append(acToAcTransferRequest.getCustomerCode())
				.append(acToAcTransferRequest.getAccountNumber()).append(acToAcTransferRequest.getInitBranch())
				.append(acToAcTransferRequest.getInitOfficer()).append(acToAcTransferRequest.getCardNumber())
				// .append(acToAcTransferRequest.getFunctionCode())
				.append(acToAcTransferRequest.getCammActionCode()).append(acToAcTransferRequest.getLastUpdateDate())
				.append(acToAcTransferRequest.getLastUpdateTime()).append(acToAcTransferRequest.getTransactionStatus())
				.append(acToAcTransferRequest.getFtsActionCode()).append(acToAcTransferRequest.getProcessingSeq())
				.append(acToAcTransferRequest.getDetailLength()).append(acToAcTransferRequest.getTransactionType())
				.append(acToAcTransferRequest.getTransactionDate()).append(acToAcTransferRequest.getValueDate())
				.append(acToAcTransferRequest.getTransactionCurrency())
				.append(acToAcTransferRequest.getTransactionAmount())
				.append(acToAcTransferRequest.getTransactionAmountSAR())
				.append(acToAcTransferRequest.getGeneralNarrative()).append(acToAcTransferRequest.getScreenNarrative())
				.append(acToAcTransferRequest.getDbAccountNumber()).append(acToAcTransferRequest.getDbAccountCurrency())
				.append(acToAcTransferRequest.getDbAmount()).append(acToAcTransferRequest.getDbCurrencyRate())
				.append(acToAcTransferRequest.getDbValueDate()).append(acToAcTransferRequest.getDbSrfFlag())
				.append(acToAcTransferRequest.getDbBranch()).append(acToAcTransferRequest.getCrAccountNumber())
				.append(acToAcTransferRequest.getCrAccountCurrency()).append(acToAcTransferRequest.getCrAmount())
				.append(acToAcTransferRequest.getCrCurrencyRate()).append(acToAcTransferRequest.getCrValueDate())
				.append(acToAcTransferRequest.getCrSrfFlag()).append(acToAcTransferRequest.getCrBranch())
				.append(acToAcTransferRequest.getCommissionCurrency())
				.append(acToAcTransferRequest.getCommissionAmount())
				.append(acToAcTransferRequest.getCommissionAccount()).append(acToAcTransferRequest.getChargesCurrency())
				.append(acToAcTransferRequest.getChargesAmount()).append(acToAcTransferRequest.getChargesAccount())
				.append(acToAcTransferRequest.getGtdDealTicket()).append(acToAcTransferRequest.getInitTime())
				.append(acToAcTransferRequest.getValidationOfficer()).append(acToAcTransferRequest.getValidationTime())
				.append(acToAcTransferRequest.getAuthorizationOfficer())
				.append(acToAcTransferRequest.getAuthorizationTime())
				.append(acToAcTransferRequest.getAuthorizationReason())
				.append(acToAcTransferRequest.getAuthorizationStatus())
				.append(acToAcTransferRequest.getDynamicPartLength())
				.append(acToAcTransferRequest.getStaticPartChequeNumber())
				.append(acToAcTransferRequest.getStaticPartIdType())
				.append(acToAcTransferRequest.getStaticPartIdNumber())
				.append(acToAcTransferRequest.getStaticPartPrintDetail())
				.append(acToAcTransferRequest.getStaticPartMailAdvice());

		logger.info("acToAcTransferRequestMsg:::::" + acToAcTransferRequest.toString() + "\n\r");

		return acToAcTransferRequestMsg.toString();
	}

	private String getFormattedTransactionAmount(String amount) {
		int leadingZerosToAppend = 16 - amount.length();
		StringBuilder zeroes = new StringBuilder();
		for (int i = 0; i < leadingZerosToAppend; i++) {
			zeroes.append('0');
		}
		return zeroes.toString() + amount;
	}

	private String getGeneralNarrative(String trnRef, String benAccNo, String detailPayment, String strACType) {
		String trnType = "#050";
		String benBank = "BSFRSARI";
		// trnRef = String.format("%16s", trnRef);
		// benAccNo = String.format("%34s", benAccNo);
		if (detailPayment == null)
			detailPayment = "";
		if (strACType != null) {
			if (strACType.length() == 4) {
				trnType = strACType;
			}
		}
		String generalNarrative = "/MAC" + trnType + trnRef + "%" + benBank + "%" + benAccNo + "%" + detailPayment;
		if (generalNarrative.length() > 60)
			generalNarrative = generalNarrative.substring(0, 60);
		else
			generalNarrative = String.format("%-60s", generalNarrative);
		return generalNarrative;
	}

	private String getFormattedAccountNumber(String accountNumber, int length) {
		int leadingZerosToAppend = length - accountNumber.length();

		StringBuilder zeroes = new StringBuilder();
		for (int i = 0; i < leadingZerosToAppend; i++) {
			zeroes.append('0');
		}

		return zeroes.toString() + accountNumber;
	}

	private synchronized String generateFtsRefNumber1() {
		String millis = System.currentTimeMillis() + "";
		return "MAC" + millis.substring(6);
	}

	private String postAccountToAccountTransferResponse(String acToAcTransferRequestString,
			Map<String, SystemParameters> tuxDetails) throws TCPConnectionException {

		String result = tuxedoPosting.postMessage(acToAcTransferRequestString, tuxDetails);

		return result;

	}

}
