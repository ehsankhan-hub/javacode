package com.bsf.macug.mt101.service.tuxedo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bsf.macug.exception.TCPConnectionException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.dto.AccountEnquiryRequestDTO;
import com.bsf.macug.mt101.dto.AccountEnquiryResponseDTO;

@Service("accountEnquiryService")
public class AccountEnquiryServiceImpl implements InterAccountEnquiryService {

	private static final Logger logger = Logger
			.getLogger(AccountEnquiryServiceImpl.class.getName());

	@Autowired
	InterSystemParameterService systemParameterService;
	
	@Autowired
	InterTuxedoPosting tuxedoPosting;
	
	public AccountEnquiryResponseDTO buildAccountEnquiryResponse(
			String accountNo, Map<String, SystemParameters> tuxDetaiMap) {
		String sourceSystem = systemParameterService.getSystemParametersDescription1("TUXSOURCE", tuxDetaiMap);
		
		AccountEnquiryResponseDTO response = null;
		try {
			String enquiryRequest = buildAccountEnquiryRequest(accountNo,
					sourceSystem);
			String enquiryResponseString = postAccountEnquiryResponse(
					enquiryRequest, tuxDetaiMap);
			if(StringUtils.isEmpty(enquiryResponseString)){
				return null;
			}
			response = new AccountEnquiryResponseDTO();
			enquiryResponseString = enquiryResponseString.substring(4);
			response.setSrcSystem(enquiryResponseString.substring(0, 3));
			response.setReqFunction(enquiryResponseString.substring(3, 11));
			response.setSeverDate(enquiryResponseString.substring(11, 19));
			response.setServerTime(enquiryResponseString.substring(19, 25));
			response.setFtsReference(enquiryResponseString.substring(25, 35));
			response.setFtsTransFunc(enquiryResponseString.substring(35, 45));
			response.setCammTranNum(enquiryResponseString.substring(45, 51));
			response.setNumOfBlocks(enquiryResponseString.substring(51, 54));
			response.setCurrBlockNum(enquiryResponseString.substring(54, 57));
			response.setNumOfItems(enquiryResponseString.substring(57, 60));
			response.setCustCode(enquiryResponseString.substring(60, 70));
			response.setAccountNumberAsPerRequest(enquiryResponseString
					.substring(70, 90));
			response.setInitBranch(enquiryResponseString.substring(90, 96));
			response.setInitOfficer(enquiryResponseString.substring(96, 105));
			response.setCardNumber(enquiryResponseString.substring(105, 128));
			response.setCammActionCode(enquiryResponseString
					.substring(128, 132));
			response.setLastUpdateDate(enquiryResponseString
					.substring(132, 140));
			response.setLastUpdateTime(enquiryResponseString
					.substring(140, 146));
			response.setTranStatus(enquiryResponseString.substring(146, 149));
			response.setFtsActionCode(enquiryResponseString.substring(149, 153));
			if (response.getCammActionCode().equalsIgnoreCase("0000")
					&& response.getFtsActionCode().equalsIgnoreCase("0000")) {
				response.setProcessingSeq(enquiryResponseString.substring(153,
						156));
				response.setDetailLength(enquiryResponseString.substring(156,
						160));
				response.setAccountNumber(enquiryResponseString.substring(160,
						171));
				response.setAccountCurrency(enquiryResponseString.substring(
						171, 174));
				response.setProductTypeCode(enquiryResponseString.substring(
						174, 180));
				response.setProductTypeDesc(enquiryResponseString.substring(
						180, 220));
				response.setClientSegmentCode(enquiryResponseString.substring(
						220, 226));
				response.setClientSegmentDesc(enquiryResponseString.substring(
						226, 246));
				response.setAccountStatusCode(enquiryResponseString.substring(
						246, 252));
				response.setAccountStatusDesc(enquiryResponseString.substring(
						252, 272));
				response.setAccountBranch(enquiryResponseString.substring(272,
						278));
				response.setCustomerFullName(enquiryResponseString.substring(
						278, 318));
				response.setSarrafCardFlag(enquiryResponseString.substring(318,
						319));
				response.setLanguageIndicator(enquiryResponseString.substring(
						319, 320));
				response.setAvailableBalance(enquiryResponseString.substring(
						320, 336));
				response.setCalendarPref(enquiryResponseString.substring(336,
						342));
				response.setCustomerType(enquiryResponseString.substring(342,
						348));
				response.setCustomerSubType(enquiryResponseString.substring(
						348, 354));
				response.setCustomerTypeDesc(enquiryResponseString.substring(
						354, 389));
				response.setRelOfficerCode(enquiryResponseString.substring(389,
						395));
				response.setRelOficerDesc(enquiryResponseString.substring(395,
						435));
				response.setProfitCenter(enquiryResponseString.substring(435,
						441));
				response.setRiskApprCode(enquiryResponseString.substring(441,
						447));
				response.setRiskApprDesc(enquiryResponseString.substring(447,
						482));
				response.setRemedialFlag(enquiryResponseString.substring(482,
						483));
				response.setDeceasedFlag(enquiryResponseString.substring(483,
						484));
				response.setIdType(enquiryResponseString.substring(484, 490));
				response.setIdNumber(enquiryResponseString.substring(490, 505));
				response.setIdExtNumber(enquiryResponseString.substring(505,
						508));
				response.setLedgerBalance(enquiryResponseString.substring(508,
						524));
				response.setFundsOnHold(enquiryResponseString.substring(524,
						540));
				response.setOdLimitAuthorised(enquiryResponseString.substring(
						540, 556));
				response.setOdLimitExpDate(enquiryResponseString.substring(556,
						564));
				response.setOriginalOdLimit(enquiryResponseString.substring(
						564, 580));
				response.setRestraintIndicator(enquiryResponseString.substring(
						580, 581));
				response.setChecqueNumber(enquiryResponseString.substring(581,
						594));
				response.setChequeStatus(enquiryResponseString.substring(594,
						595));
				response.setOdAmountTotal(enquiryResponseString.substring(595,
						611));
				response.setTotTxnsInProgressAmount(enquiryResponseString
						.substring(611, 627));
				response.setTotPledgedAmount(enquiryResponseString.substring(
						627, 643));
				response.setAccountType(enquiryResponseString.substring(643,
						647));
				response.setIdExpiryDate(enquiryResponseString.substring(647,
						655));
				response.setIdExpiryIndicator(enquiryResponseString.substring(
						655, 656));
				response.setIdExpiryMessage(enquiryResponseString.substring(
						656, 696));
				response.setFreezeFlag(enquiryResponseString
						.substring(696, 697));
				response.setPreviousFlag(enquiryResponseString.substring(697,
						703));
				response.setInternalKey(enquiryResponseString.substring(703,
						713));
				response.setAddress(enquiryResponseString.substring(713, 763));

			}
			logger.info("Response message is : "+response.toString());

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			logger.error("AccountEnquiry->buildAccountEnquiryResponse() Unable to build Enquiry Request in the method: buildAccountEnquiryResponse() due to the error: "
					+ e);
			return null;
		}
		return response;
	}
	private String buildAccountEnquiryRequest(String accountNumber,
			String sourceSytem) {
		AccountEnquiryRequestDTO requestMessage = null;
		//logger.info("(buildAccountEnquiryRequest)==> Inside buildAccountEnquiryRequest \r\n");
		requestMessage = new AccountEnquiryRequestDTO();
		DateFormat format = new SimpleDateFormat("yyyyMMdd");
		Date currentDate = new Date();
		requestMessage.setSrcSystem(sourceSytem);
		requestMessage.setReqFunction("FININQ01");
		requestMessage.setServerDate(format.format(currentDate));
		requestMessage.setServerTime("000000");
		requestMessage.setFtsReference(generateFtsRefNumber()); // ENQ1234567
		requestMessage.setFtsTransFunc("          "); // PRECAMM -
		requestMessage.setCammTranNum("      ");
		requestMessage.setNumOfBlocks("001");
		requestMessage.setCurrentBlockNum("001");
		requestMessage.setNumOfItems("001");
		requestMessage.setCustCode("          "); // 0000000000
		requestMessage.setAccountNumber(getFormattedAccountNumber(accountNumber, 20));
		requestMessage.setInitBranch("066   ");
		requestMessage.setInitOfficer("B2BAUTO  ");
		requestMessage.setCardNumber("                       ");
		requestMessage.setCammActionCode("5555");
		requestMessage.setLastUpdateDate("        ");
		requestMessage.setLastUpdateTime("      ");
		requestMessage.setTranStatus("NOR");
		requestMessage.setFtsActionCode("6666");
		requestMessage.setProcessingSeq("000");
		requestMessage.setDetailsLength("0000");
		logger.info("(buildAccountEnquiryRequest)==> Request message is "+requestMessage);
		StringBuilder enquiryRequest = new StringBuilder();
		enquiryRequest.append(requestMessage.getSrcSystem())
				.append(requestMessage.getReqFunction())
				.append(requestMessage.getServerDate())
				.append(requestMessage.getServerTime())
				.append(requestMessage.getFtsReference())
				.append(requestMessage.getFtsTransFunc())
				.append(requestMessage.getCammTranNum())
				.append(requestMessage.getNumOfBlocks())
				.append(requestMessage.getCurrentBlockNum())
				.append(requestMessage.getNumOfItems())
				.append(requestMessage.getCustCode())
				.append(requestMessage.getAccountNumber())
				.append(requestMessage.getInitBranch())
				.append(requestMessage.getInitOfficer())
				.append(requestMessage.getCardNumber())
				.append(requestMessage.getCammActionCode())
				.append(requestMessage.getLastUpdateDate())
				.append(requestMessage.getLastUpdateTime())
				.append(requestMessage.getTranStatus())
				.append(requestMessage.getFtsActionCode())
				.append(requestMessage.getProcessingSeq())
				.append(requestMessage.getDetailsLength());
		return enquiryRequest.toString();
	}

	private String generateFtsRefNumber() {
		String millis = System.currentTimeMillis() + ""; // 1454868024458
															// //ENQ1234567
		return "ENQ" + millis.substring(6);
	}

	private String getFormattedAccountNumber(String accountNumber,
			int length) {
		int lengthOfZeros = length - accountNumber.length();
		StringBuilder zeroes = new StringBuilder();
		for (int i = 0; i < lengthOfZeros; i++) {
			zeroes.append('0');
		}
		return zeroes.toString() + accountNumber;
	}

	public String postAccountEnquiryResponse(String enquiryRequest,
			Map<String, SystemParameters> tuxDetaiMap) throws TCPConnectionException {
		
		return tuxedoPosting.postMessage(enquiryRequest, tuxDetaiMap);
	}

	

}
