package com.bsf.macug.mt101.service.tuxedo;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.exception.PossibleDuplicationException;
import com.bsf.macug.exception.TCPConnectionException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.dto.BusinessDateDTO;
import com.bsf.macug.mt101.dto.SarieSwiftTRansferRequestDTO;
import com.bsf.macug.mt101.dto.SarieSwiftTRansferResponseDTO;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.service.InterMT100Util;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service("sarieAndSwiftTransferService")
public class SarieAndSwiftTransferServiceImpl implements InterSarieAndSwiftTransferService {
	private static final Logger logger = Logger.getLogger(SarieAndSwiftTransferServiceImpl.class.getName());

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterTuxedoPosting tuxedoPosting;

	@Autowired
	InterMT100Util mT100Util;

	public SarieSwiftTRansferResponseDTO buildSarieSwiftTransferResponse(MacPaymentDetail details,
			BusinessDateDTO businessDateDto, String type, CustomerDetails customerDetails,
			Map<String, Map<String, SystemParameters>> allSystemProperties)
			throws TCPConnectionException, PossibleDuplicationException {
		Map<String, SystemParameters> tuxDetails = (Map) allSystemProperties.get("tuxDetailMap");
		Map<String, SystemParameters> washAccountMap = (Map) allSystemProperties.get("washAccountMap");

		String strSARIEType = systemParameterService.getSystemParametersDescription1("TRSRTYPE", tuxDetails);

		String strSWIFTCAMMCode = systemParameterService.getSystemParametersDescription1("SWCAMCOD", tuxDetails);
		String strSWIFTFTSCode = systemParameterService.getSystemParametersDescription1("SWFTSCOD", tuxDetails);
		String strSWIFTType = systemParameterService.getSystemParametersDescription1("TRSWTYPE", tuxDetails);

		String sourceSytem = systemParameterService.getSystemParametersDescription1("TUXSOURCE", tuxDetails);

		String washAccount = systemParameterService.getSystemParametersDescription1(details.getCurrency(),
				washAccountMap);

		String strInitBranch = systemParameterService.getSystemParametersDescription1("INTBRANCH", tuxDetails);
		String strInitOfficer = systemParameterService.getSystemParametersDescription1("INTOFFICE", tuxDetails);
		String strSARIECAMMCode = systemParameterService.getSystemParametersDescription1("SRCAMCOD", tuxDetails);
		String strSARIEFTSCode = systemParameterService.getSystemParametersDescription1("SRFTSCOD", tuxDetails);

		String requestFunction = systemParameterService.getSystemParametersDescription2("PAYTUXREQ", tuxDetails);
		SarieSwiftTRansferResponseDTO response = null;
		try {
			String telexTransferRequestString = buildSarieSwiftTRanferRequest(details, businessDateDto, sourceSytem,
					washAccount, businessDateDto, strInitBranch, strInitOfficer, strSARIECAMMCode, strSARIEFTSCode,
					strSARIEType, strSWIFTCAMMCode, strSWIFTFTSCode, strSWIFTType, requestFunction, type);

			String ftsRef = details.getFtsReference();
			if (!mT100Util.saveFTSKey(details.getTransactionReference(), ftsRef, telexTransferRequestString,
					"FIN")) {
				logger.error("Duplicate fts trying to save...");
				throw new PossibleDuplicationException();
			}
			if (!mT100Util.savePaymentUniqueSeries(details.getCustomerId(), details.getDebitAccount(),
					details.getBeneficiaryInfo59(), details.getTransactionAmount(), details.getValueDate(),
					customerDetails)) {
				logger.error("Duplicate fts trying to save...");
				throw new PossibleDuplicationException();
			}
			String telexTransferResponseString = postSarieSwiftMessage(telexTransferRequestString, tuxDetails);

			mT100Util.updateFTSKey(details.getTransactionReference(), ftsRef, telexTransferResponseString);
			
			if (StringUtils.isEmpty(telexTransferResponseString)) {
				return null;
			} else if(telexTransferResponseString.equals("-1")) {
				logger.error("Tuxedo has given response as -1");
				return null;
			}

			response = new SarieSwiftTRansferResponseDTO();
			telexTransferResponseString = telexTransferResponseString.substring(4);
			response.setSrcSystem(telexTransferResponseString.substring(0, 3));
			response.setReqFunction(telexTransferResponseString.substring(3, 11));
			response.setSeverDate(telexTransferResponseString.substring(11, 19));
			response.setServerTime(telexTransferResponseString.substring(19, 25));
			response.setFtsReference(telexTransferResponseString.substring(25, 35));
			response.setFtsTransFunc(telexTransferResponseString.substring(35, 45));
			response.setCammTranNum(telexTransferResponseString.substring(45, 51));
			response.setNumOfBlocks(telexTransferResponseString.substring(51, 54));
			response.setCurrBlockNum(telexTransferResponseString.substring(54, 57));
			response.setNumOfItems(telexTransferResponseString.substring(57, 60));
			response.setCustCode(telexTransferResponseString.substring(60, 70));
			response.setAccountNumberAsPerRequest(telexTransferResponseString.substring(70, 90));
			response.setInitBranch(telexTransferResponseString.substring(90, 96));
			response.setInitOfficer(telexTransferResponseString.substring(96, 105));
			response.setCardNumber(telexTransferResponseString.substring(105, 128));
			response.setCammActionCode(telexTransferResponseString.substring(128, 132));
			response.setLastUpdateDate(telexTransferResponseString.substring(132, 140));
			response.setLastUpdateTime(telexTransferResponseString.substring(140, 146));
			response.setTranStatus(telexTransferResponseString.substring(146, 149));
			response.setFtsActionCode(telexTransferResponseString.substring(149, 153));
			response.setProcessingSeq(telexTransferResponseString.substring(153, 156));
			response.setDetailLength(telexTransferResponseString.substring(156, 160));

			logger.info("Response message : " + response.toString());
		} catch (PossibleDuplicationException e) {
			logger.error("Error : " + e.getMessage(), e);
			throw e;
		} catch (Exception e) {
			logger.error("Error e " + e.getMessage(), e);
			response = null;
		}

		return response;
	}

	private String buildSarieSwiftTRanferRequest(MacPaymentDetail details, BusinessDateDTO businessDateDto,
			String sourceSytem, String washAccount, BusinessDateDTO businessDateDto2, String strInitBranch,
			String strInitOfficer, String strSARIECAMMCode, String strSARIEFTSCode, String strSARIEType,
			String strSWIFTCAMMCode, String strSWIFTFTSCode, String strSWIFTType, String requestFunction,
			String transferType) throws Exception {
		String accWithInst57A = details.getAccountInstituion57();
		String accWithInst57C = "";
		String accWithInst57D = "";
		BigDecimal chargeAmount = details.getChargeAmount();

		DecimalFormat formatChargedAmount = new DecimalFormat("0000000000000.00");
		String chargedAmountFormat = formatChargedAmount.format(chargeAmount);
		String accWithInst = "";
		if ((accWithInst57C != null) && (accWithInst57C != "")) {
			accWithInst = accWithInst57C;
		} else if ((accWithInst57D != null) && (accWithInst57D != "")) {
			accWithInst = accWithInst57D;
		} else {
			accWithInst = accWithInst57A;
		}

		String orderingAccount = details.getDebitAccount();
		String formatedOrderingAccount = getFormattedAccountNumber(orderingAccount, 20);
		String debitAccountCurrency = details.getDebitCurrency();

		String benAccNo = details.getBeneficiaryInfo59();
		SarieSwiftTRansferRequestDTO telexTransferRequest = new SarieSwiftTRansferRequestDTO();
		DateFormat format = new SimpleDateFormat("yyyyMMdd");
		BigDecimal amount = details.getTransactionAmount();

		BigDecimal debitAmount = details.getDebitAmount();
		BigDecimal trnAmountSar = details.getTransactionAmountInSar();
		if ((amount.compareTo(BigDecimal.ZERO) == 0) || (debitAmount.compareTo(BigDecimal.ZERO) == 0)
				|| (trnAmountSar.compareTo(BigDecimal.ZERO) == 0)) {
			logger.error("(buildAccountToAccountTransferRequest)==> One of the amount is zero...");
			throw new Exception();
		}
		DecimalFormat formatAmount = new DecimalFormat("0000000000000.00");
		DecimalFormat exchangeRateFormat = new DecimalFormat("00.000000");
		String transactionAmountFormat = formatAmount.format(amount);
		String debitAmountFormat = formatAmount.format(debitAmount);
		String transactionAmountSarFormat = formatAmount.format(trnAmountSar);

		String creditCurrencyRate = exchangeRateFormat.format(details.getCreditRate());
		String debitCurrencyRate = exchangeRateFormat.format(details.getDebitRate());

		String strTransType = null;
		if (transferType.equalsIgnoreCase("SARIE")) {
			if (strSARIEType != null) {
				if (strSARIEType.trim().length() == 4) {
					strTransType = strSARIEType;
				} else
					strTransType = "#063";
			} else {
				strTransType = "#063";
			}
		} else if (transferType.equalsIgnoreCase("SWIFT")) {
			if (strSWIFTType != null) {
				if (strSWIFTType.trim().length() == 4) {
					strTransType = strSWIFTType;
				} else
					strTransType = "#060";
			} else {
				strTransType = "#060";
			}
		}
		String generalNarrative = getGeneralNarrative(details, transferType, accWithInst, strTransType);
		details.setTuxNarative(generalNarrative);
		String screenNarrative = "                    ";
		String initBranch = "066   ";
		String initOfficer = "MACAUTO  ";
		String cammActionCode = "5555";
		String ftsActioncode = "6666";
		String transactionType = null;
		if ((strInitBranch != null) && (strInitBranch.trim().length() == 3)) {
			initBranch = appendSpaces(strInitBranch, 6, "R");
		}
		if ((strInitOfficer != null) && (strInitOfficer.trim().length() == 7)) {
			initOfficer = appendSpaces(strInitOfficer, 9, "R");
		}
		if (transferType.equalsIgnoreCase("SARIE")) {
			if ((strSARIECAMMCode != null) && (strSARIECAMMCode.trim().length() == 4)) {
				cammActionCode = strSARIECAMMCode;
			}
			if ((strSARIEFTSCode != null) && (strSARIEFTSCode.trim().length() == 4)) {
				ftsActioncode = strSARIEFTSCode;
			}
			if ((strSARIEType != null) && (strSARIEType.trim().length() == 4)) {
				transactionType = strSARIEType;
			}
		} else if (transferType.equalsIgnoreCase("SWIFT")) {
			if ((strSWIFTCAMMCode != null) && (strSWIFTCAMMCode.trim().length() == 4)) {
				cammActionCode = strSWIFTCAMMCode;
			}
			if ((strSWIFTFTSCode != null) && (strSWIFTFTSCode.trim().length() == 4)) {
				ftsActioncode = strSWIFTFTSCode;
			}
			if ((strSWIFTType != null) && (strSWIFTType.trim().length() == 4)) {
				transactionType = strSWIFTType;
			}
		}
		SimpleDateFormat formatTime = new SimpleDateFormat("hhmmss");

		Date businessDateObj = businessDateDto.getBusinessDate();
		String currentDate = format.format(businessDateDto.getSystemDate());
		String currentTime = businessDateDto.getTime().replace(":", "");
		String businessDate = format.format(businessDateObj);

		Date date = new Date();
		DateFormat timeformat = new SimpleDateFormat("HHmmss");
		String lastUpdatedDate = format.format(date);
		String lastUpdateTime = timeformat.format(date);
		String valueDate = null;
		if (!"HOLD".equals(details.getStatus())) {
			Date valueDateObj = details.getApplicableValueDate();
			valueDate = format.format(valueDateObj);
		} else {
			Date valueDateObj = details.getTradeDate();
			valueDate = format.format(valueDateObj);
		}

		telexTransferRequest.setSrcSystem(sourceSytem);
		if (!StringUtils.isEmpty(requestFunction)) {
			requestFunction = requestFunction.trim();
		} else {
			requestFunction = "FINUPD04";
		}
		telexTransferRequest.setReqFunction(requestFunction);
		telexTransferRequest.setServerDate(businessDate);
		telexTransferRequest.setServerTime(lastUpdateTime);

		String ftsRef = details.getFtsReference();

		telexTransferRequest.setFtsReference(ftsRef);
		telexTransferRequest.setFtsTransFunc("          ");
		telexTransferRequest.setCammTranNum("000000");
		telexTransferRequest.setNumOfBlocks("001");
		telexTransferRequest.setCurrBlockNum("001");
		telexTransferRequest.setNumOfItems("001");
		telexTransferRequest.setCustomerCode("0000000000");
		telexTransferRequest.setAccountNumber("00000000000000000000");
		telexTransferRequest.setInitBranch(initBranch);
		telexTransferRequest.setInitOfficer(initOfficer);
		telexTransferRequest.setCardNumber("                       ");
		telexTransferRequest.setCammActionCode(cammActionCode);
		telexTransferRequest.setLastUpdateDate(lastUpdatedDate);
		telexTransferRequest.setLastUpdateTime(lastUpdateTime);
		telexTransferRequest.setTransactionStatus("NOR");
		telexTransferRequest.setFtsActionCode(ftsActioncode);
		telexTransferRequest.setProcessingSeq("000");
		telexTransferRequest.setDetailLength("0971");
		if (transferType.equalsIgnoreCase("Sarie")) {
			telexTransferRequest.setTransactionType(transactionType == null ? "#063" : transactionType);
			telexTransferRequest.setCrAccountNumber(washAccount);
			telexTransferRequest.setCrCurrencyRate(creditCurrencyRate);
			telexTransferRequest.setBenAccount("                    ");
			if (benAccNo.startsWith("SA")) {
				telexTransferRequest.setIsIbanFlag("Y");
			} else
				telexTransferRequest.setIsIbanFlag("N");
			telexTransferRequest.setiBanBbanAccount(appendSpaces(benAccNo, 34, "R"));
		} else if (transferType.equalsIgnoreCase("Swift")) {
			telexTransferRequest.setTransactionType(transactionType == null ? "#060" : transactionType);
			telexTransferRequest.setCrAccountNumber(washAccount);
			telexTransferRequest.setCrCurrencyRate(creditCurrencyRate);

			telexTransferRequest.setBenAccount("                    ");
			telexTransferRequest.setIsIbanFlag("N");
			telexTransferRequest.setiBanBbanAccount(appendSpaces(benAccNo, 34, "R"));
		}

		telexTransferRequest.setTransactionDate(businessDate);
		telexTransferRequest.setValueDate(valueDate);

		telexTransferRequest.setTransactionCurrency(details.getCurrency());
		telexTransferRequest.setTransactionAmount(transactionAmountFormat);
		telexTransferRequest.setTransactionAmountSAR(transactionAmountSarFormat);
		telexTransferRequest.setGeneralNarrative(generalNarrative);
		telexTransferRequest.setScreenNarrative(screenNarrative);
		telexTransferRequest.setDbAccountNumber(formatedOrderingAccount);
		telexTransferRequest.setDbAccountCurrency(debitAccountCurrency);
		telexTransferRequest.setDbAmount(debitAmountFormat);
		telexTransferRequest.setDbCurrencyRate(debitCurrencyRate);
		telexTransferRequest.setDbValueDate(valueDate);

		telexTransferRequest.setDbSrfFlag("N");
		telexTransferRequest.setDbBranch("004   ");

		telexTransferRequest.setCrAccountCurrency(details.getCurrency());
		telexTransferRequest.setCrAmount(transactionAmountFormat);

		telexTransferRequest.setCrValueDate(valueDate);

		telexTransferRequest.setCrSrfFlag(" ");
		telexTransferRequest.setCrBranch("      ");
		telexTransferRequest.setCommissionCurrency("SAR");
		telexTransferRequest.setCommissionAmount("0000000000000.00");
		telexTransferRequest.setCommissionAccount("00000000000000000000");
		telexTransferRequest.setChargesCurrency(debitAccountCurrency);

		telexTransferRequest.setChargesAmount(chargedAmountFormat);
		telexTransferRequest.setChargesAccount("00000000000000000000");
		telexTransferRequest.setGtdDealTicket("                    ");
		telexTransferRequest.setInitTime(lastUpdateTime);
		telexTransferRequest.setValidationOfficer("         ");
		telexTransferRequest.setValidationTime(lastUpdateTime);
		telexTransferRequest.setAuthorizationOfficer("         ");
		telexTransferRequest.setAuthorizationTime(lastUpdateTime);
		telexTransferRequest.setAuthorizationReason("          ");
		telexTransferRequest.setAuthorizationStatus("      ");
		telexTransferRequest.setDynamicPartLength("080");
		telexTransferRequest.setStaticPartChequeNumber("               ");
		telexTransferRequest.setStaticPartIdType("      ");
		telexTransferRequest.setStaticPartIdNumber("                    ");
		telexTransferRequest.setStaticPartPrintDetail(" ");
		telexTransferRequest.setStaticPartMailAdvice(" ");

		String ttReference = details.getTtReference();

		telexTransferRequest.setTtRefNumber(ttReference);
		telexTransferRequest.setTtCorrespondant("Correspond");
		telexTransferRequest.setChargesDetails("2");
		telexTransferRequest.setPaymentValueDate(valueDate);

		String remitDetails = details.getOrderingCustomer50() + "   ";
		if (remitDetails.length() > 120) {
			remitDetails = remitDetails.substring(0, 120);
		} else {
			remitDetails = appendSpaces(remitDetails, 120, "R");
		}
		String strRemitterName = details.getOrderingCustomer50();
		String strAddress = "   ";
		String strPhone = "";
		String strPurpouse = "Other";
		String strNationality = appendSpaces("SA", 10, "R");

		if (strRemitterName.trim().length() > 40) {
			strRemitterName = strRemitterName.substring(0, 40);
		} else {
			strRemitterName = appendSpaces(strRemitterName, 40, "R");
		}

		if (strAddress.trim().length() > 10) {
			strPhone = strAddress.substring(0, 10);
		} else {
			strPhone = appendSpaces(strAddress, 10, "R");
		}

		if (strAddress.trim().length() > 40) {
			strAddress = strAddress.substring(0, 40);
		} else {
			strAddress = appendSpaces(strAddress, 40, "R");
		}

		if (strAddress.trim().length() > 109) {
			strPurpouse = strAddress.substring(100, 109);
		} else {
			strPurpouse = appendSpaces(strPurpouse, 10, "R");
		}
		telexTransferRequest.setRemitterName(strRemitterName);
		telexTransferRequest.setRemitterNationality(strNationality);
		telexTransferRequest.setRemitterPhoneNumber(strPhone);
		telexTransferRequest.setRemitterAddress(strAddress);

		telexTransferRequest.setRemittencePurpose(strPurpouse);

		String benDetails = benAccNo + details.getBeneficiaryInfo591() + details.getBeneficiaryInfo592()
				+ details.getBeneficiaryInfo593() + details.getBeneficiaryInfo594();
		if (benDetails.length() > 120) {
			benDetails = benDetails.substring(0, 120);
		} else {
			benDetails = appendSpaces(benDetails, 120, "R");
		}
		String strBenName = details.getBeneficiaryInfo591();

		String strBenAddress = details.getBeneficiaryInfo591() + details.getBeneficiaryInfo592()
				+ details.getBeneficiaryInfo593() + details.getBeneficiaryInfo594();

		if (strBenName.trim().length() > 40) {
			strBenName = strBenName.substring(0, 40);
		} else {
			strBenName = appendSpaces(strBenName, 40, "R");
		}

		if (transferType.equalsIgnoreCase("Swift")) {
			String strBIC = "";
			if (accWithInst.trim().length() > 6)
				strBIC = accWithInst.substring(4, 6);
			strNationality = appendSpaces(strBIC, 10, "R");
		}

		if (strBenAddress.trim().length() > 40) {
			strBenAddress = strBenAddress.substring(0, 40);
		} else {
			strBenAddress = appendSpaces(strBenAddress, 40, "R");
		}
		telexTransferRequest.setBenName(strBenName);
		telexTransferRequest.setBenCountry(strNationality);
		telexTransferRequest.setBenAddress(strBenAddress);

		telexTransferRequest.setBenBankName("          ");
		telexTransferRequest.setPaymentDetails(
				"MAC Payment                                                                                                                                 ");

		telexTransferRequest.setPaymentMsgType("1");
		telexTransferRequest.setChargesCollectionMethod("A");

		telexTransferRequest.setBenBankAddressLine1(appendSpaces(details.getBeneficiaryInfo591(), 40, "R"));
		telexTransferRequest.setBenBankAddressLine2(appendSpaces(details.getBeneficiaryInfo592(), 40, "R"));

		if (transferType.equalsIgnoreCase("Sarie")) {
			if ((accWithInst != null) && (accWithInst.trim().length() > 4)) {
				accWithInst = accWithInst.substring(0, 4);
			}
		} else if (accWithInst.length() == 8) {
			accWithInst = accWithInst + "XXX";
		}
		telexTransferRequest.setBenBankCode(appendSpaces(accWithInst, 20, "R"));

		telexTransferRequest.setBenBankCountry("          ");
		telexTransferRequest.setRemitterFullAddress(
				"                                                                                                                        ");

		telexTransferRequest.setBenBankFullName("                                   ");
		logger.info("TelexTranfer request is " + telexTransferRequest.toString());
		StringBuilder telexTransferRequestMsg = new StringBuilder();
		telexTransferRequestMsg.append(telexTransferRequest.getSrcSystem())
				.append(telexTransferRequest.getReqFunction()).append(telexTransferRequest.getServerDate())
				.append(telexTransferRequest.getServerTime()).append(telexTransferRequest.getFtsReference())
				.append(telexTransferRequest.getFtsTransFunc()).append(telexTransferRequest.getCammTranNum())
				.append(telexTransferRequest.getNumOfBlocks()).append(telexTransferRequest.getCurrBlockNum())
				.append(telexTransferRequest.getNumOfItems()).append(telexTransferRequest.getCustomerCode())
				.append(telexTransferRequest.getAccountNumber()).append(telexTransferRequest.getInitBranch())
				.append(telexTransferRequest.getInitOfficer()).append(telexTransferRequest.getCardNumber())
				.append(telexTransferRequest.getCammActionCode()).append(telexTransferRequest.getLastUpdateDate())
				.append(telexTransferRequest.getLastUpdateTime()).append(telexTransferRequest.getTransactionStatus())
				.append(telexTransferRequest.getFtsActionCode()).append(telexTransferRequest.getProcessingSeq())
				.append(telexTransferRequest.getDetailLength()).append(telexTransferRequest.getTransactionType())
				.append(telexTransferRequest.getTransactionDate()).append(telexTransferRequest.getValueDate())
				.append(telexTransferRequest.getTransactionCurrency())
				.append(telexTransferRequest.getTransactionAmount())
				.append(telexTransferRequest.getTransactionAmountSAR())
				.append(telexTransferRequest.getGeneralNarrative()).append(telexTransferRequest.getScreenNarrative())
				.append(telexTransferRequest.getDbAccountNumber()).append(telexTransferRequest.getDbAccountCurrency())
				.append(telexTransferRequest.getDbAmount()).append(telexTransferRequest.getDbCurrencyRate())
				.append(telexTransferRequest.getDbValueDate()).append(telexTransferRequest.getDbSrfFlag())
				.append(telexTransferRequest.getDbBranch()).append(telexTransferRequest.getCrAccountNumber())
				.append(telexTransferRequest.getCrAccountCurrency()).append(telexTransferRequest.getCrAmount())
				.append(telexTransferRequest.getCrCurrencyRate()).append(telexTransferRequest.getCrValueDate())
				.append(telexTransferRequest.getCrSrfFlag()).append(telexTransferRequest.getCrBranch())
				.append(telexTransferRequest.getCommissionCurrency()).append(telexTransferRequest.getCommissionAmount())
				.append(telexTransferRequest.getCommissionAccount()).append(telexTransferRequest.getChargesCurrency())
				.append(telexTransferRequest.getChargesAmount()).append(telexTransferRequest.getChargesAccount())
				.append(telexTransferRequest.getGtdDealTicket()).append(telexTransferRequest.getInitTime())
				.append(telexTransferRequest.getValidationOfficer()).append(telexTransferRequest.getValidationTime())
				.append(telexTransferRequest.getAuthorizationOfficer())
				.append(telexTransferRequest.getAuthorizationTime())
				.append(telexTransferRequest.getAuthorizationReason())
				.append(telexTransferRequest.getAuthorizationStatus())
				.append(telexTransferRequest.getDynamicPartLength())
				.append(telexTransferRequest.getStaticPartChequeNumber())
				.append(telexTransferRequest.getStaticPartIdType()).append(telexTransferRequest.getStaticPartIdNumber())
				.append(telexTransferRequest.getStaticPartPrintDetail())
				.append(telexTransferRequest.getStaticPartMailAdvice()).append(telexTransferRequest.getTtRefNumber())
				.append(telexTransferRequest.getTtCorrespondant()).append(telexTransferRequest.getChargesDetails())
				.append(telexTransferRequest.getPaymentValueDate()).append(telexTransferRequest.getRemitterName())
				.append(telexTransferRequest.getRemitterNationality())
				.append(telexTransferRequest.getRemitterPhoneNumber()).append(telexTransferRequest.getRemitterAddress())
				.append(telexTransferRequest.getRemittencePurpose()).append(telexTransferRequest.getBenName())
				.append(telexTransferRequest.getBenBankCountry()).append(telexTransferRequest.getBenAddress())
				.append(telexTransferRequest.getBenAccount()).append(telexTransferRequest.getBenBankName())
				.append(telexTransferRequest.getPaymentDetails()).append(telexTransferRequest.getPaymentMsgType())
				.append(telexTransferRequest.getChargesCollectionMethod())
				.append(telexTransferRequest.getBenBankAddressLine1())
				.append(telexTransferRequest.getBenBankAddressLine2()).append(telexTransferRequest.getBenBankCode())
				.append(telexTransferRequest.getBenBankCountry()).append(telexTransferRequest.getRemitterFullAddress())
				.append(telexTransferRequest.getIsIbanFlag()).append(telexTransferRequest.getiBanBbanAccount())
				.append(telexTransferRequest.getBenBankFullName());
		return telexTransferRequestMsg.toString();

	}

	private String postSarieSwiftMessage(String telexTransferRequestString, Map<String, SystemParameters> tuxDetails)
			throws TCPConnectionException {
		String resultData = tuxedoPosting.postMessage(telexTransferRequestString, tuxDetails);
		return resultData;
	}

	private static String generateFtsRefNumber1(String sourceSystem) {
		String millis = System.currentTimeMillis() + "";
		return sourceSystem + "" + millis.substring(6);
	}

	private static String getFormattedAccountNumber(String accountNumber, int length) {
		int leadingZerosToAppend = length - accountNumber.length();

		StringBuilder zeroes = new StringBuilder();
		for (int i = 0; i < leadingZerosToAppend; i++) {
			zeroes.append('0');
		}

		return zeroes.toString() + accountNumber;
	}

	private static String appendSpaces(String input, int length, String direction) {
		int spacesToAppend = length - input.length();

		StringBuilder spaces = new StringBuilder();
		for (int i = 0; i < spacesToAppend; i++) {
			spaces.append(' ');
		}

		if (direction.equalsIgnoreCase("R")) {
			input = input + spaces.toString();
		} else {
			input = spaces.toString() + input;
		}
		return input;
	}

	private static synchronized String generateTtRefNum1(String sourceSystem) {
		String millis = System.currentTimeMillis() + "";
		DateFormat dfYear = new SimpleDateFormat("yy");
		return sourceSystem + "TT" + millis.substring(7) + dfYear.format(new Date());
	}

	private static String getGeneralNarrative(MacPaymentDetail details, String transferType, String accWithInst,
			String strTransType) {
		String trnType = "";
		if (transferType.equalsIgnoreCase("SARIE")) {
			trnType = "#063";
		} else if (transferType.equalsIgnoreCase("SWIFT")) {
			trnType = "#060";
		}
		String trnRef = details.getTransactionReference();
		if ((strTransType != null) && (strTransType.trim().length() == 4)) {
			trnType = strTransType;
		}

		String benAccount = details.getBeneficiaryInfo59();

		String detailPayment = details.getRemittanceInfo70();
		if (detailPayment == null)
			detailPayment = "";
		String generalNarrative = "/MAC" + trnType + trnRef + "%" + accWithInst + "%" + benAccount + "%"
				+ detailPayment;

		if (generalNarrative.length() > 60) {
			generalNarrative = generalNarrative.substring(0, 60);
		} else
			generalNarrative = String.format("%-60s", new Object[] { generalNarrative });
		return generalNarrative;
	}
}