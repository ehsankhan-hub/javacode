package com.bsf.macug.mt101.service.tuxedo;

import java.util.Map;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.exception.PossibleDuplicationException;
import com.bsf.macug.exception.TCPConnectionException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.mt101.dto.AcToAcTransferResponseDTO;
import com.bsf.macug.mt101.dto.BusinessDateDTO;
import com.bsf.macug.mt101.entity.MacPaymentDetail;

public interface InterAcToAcTransferService {
	AcToAcTransferResponseDTO buildAccountToAccountTransferResponse(MacPaymentDetail detailsObj,
			CustomerDetails customerDetails, BusinessDateDTO businessDateDto,
			Map<String, Map<String, SystemParameters>> allSystemProperties)
			throws TCPConnectionException, PossibleDuplicationException;

}
