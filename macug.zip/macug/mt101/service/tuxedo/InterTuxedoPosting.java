package com.bsf.macug.mt101.service.tuxedo;

import java.util.Map;

import com.bsf.macug.exception.TCPConnectionException;
import com.bsf.macug.general.entity.SystemParameters;

public interface InterTuxedoPosting {
	String postMessage(String message,
			Map<String, SystemParameters> tuxDetails) throws TCPConnectionException;
}
