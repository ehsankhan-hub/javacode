package com.bsf.macug.mt101.service.tuxedo;

import java.util.Map;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.exception.PossibleDuplicationException;
import com.bsf.macug.exception.TCPConnectionException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.mt101.dto.BusinessDateDTO;
import com.bsf.macug.mt101.dto.SarieSwiftTRansferResponseDTO;
import com.bsf.macug.mt101.entity.MacPaymentDetail;

public interface InterSarieAndSwiftTransferService {
	SarieSwiftTRansferResponseDTO buildSarieSwiftTransferResponse(MacPaymentDetail details,
			BusinessDateDTO businessDateDto, String type, CustomerDetails customerDetails,
			Map<String, Map<String, SystemParameters>> allSystemProperties)
			throws TCPConnectionException, PossibleDuplicationException;
}
