package com.bsf.macug.mt101.service;

import com.bsf.macug.mt101.entity.FTSTuxKey;

public interface InterFTSTuxKeyService {

	boolean saveFTSTuxKey(FTSTuxKey ftsTuxKey) throws Exception;
	
	boolean updateFTSTuxKey(FTSTuxKey ftsTuxKey) throws Exception;
	
	FTSTuxKey getFTSTuxKey(String ftsTuxKey) throws Exception;
	
}
