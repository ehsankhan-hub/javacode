package com.bsf.macug.mt101.transaction;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.mt101.dao.InterPaymentDAO;
import com.bsf.macug.mt101.entity.ForeignHoliday;
import com.bsf.macug.mt101.entity.MacFileLog;
import com.bsf.macug.mt101.entity.MacPaymentActivityLog;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.entity.MacPaymentHeader;

@Service
@Transactional
public class PaymentTransactionalServiceImpl implements InterPaymentTransactionalService {

	@Autowired
	InterPaymentDAO paymentDao;

	@Override
	public boolean saveHeader(MacPaymentHeader header) throws DataAccessException {
		boolean blStatus = false;
		header.setCreatedBy("SYSTEM");
		header.setCreatedOn(new Timestamp(new Date().getTime()));
		blStatus = paymentDao.saveHeader(header);
		return blStatus;
	}

	@Override
	public boolean updateHeader(MacPaymentHeader header) throws DataAccessException {
		boolean blStatus = false;
		header.setModifiedBy("SYSTEM");
		header.setModifiedOn(new Timestamp(new Date().getTime()));
		blStatus = paymentDao.updateHeader(header);
		return blStatus;
	}

	@Override
	public List<MacPaymentHeader> findAllHeader(String status) throws DataAccessException {
		List<MacPaymentHeader> lstPaymentHeader = null;
		lstPaymentHeader = paymentDao.findAllHeader(status);
		return lstPaymentHeader;
	}
	@Override
	public List<MacPaymentActivityLog>  getMT199BasicValidation() throws DataAccessException{
		List<MacPaymentActivityLog> list=null;
		list = paymentDao.getMT199BasicValidation();
		return list;
		
	}
	@Override
	public List<MacPaymentHeader> getMT199Pendings()  throws DataAccessException {
		List<MacPaymentHeader> list = null;
		list = paymentDao.getMT199Pendings();
		return list;
	}
	@Override
	public MacPaymentHeader getHeader(String customerId, String fileId) throws DataAccessException{
		MacPaymentHeader header = null;
		header = paymentDao.getHeader(customerId, fileId);
		return header;
	}
	
	@Override
	public MacPaymentActivityLog getPaymentProcessLogByFileName(String fileName)throws DataAccessException {
		MacPaymentActivityLog macPaymentActLog=null;
		macPaymentActLog=paymentDao.getPaymentProcessLogByFileName(fileName);
		return macPaymentActLog;
	}
	@Override
	public boolean updatePaymnetProcessLog(MacPaymentActivityLog activityLog) throws DataAccessException{
		boolean status = false;
		status = paymentDao.updatePaymnetProcessLog(activityLog);
		return status;
		
	}
	@Override
	public boolean saveDetail(MacPaymentDetail detail) throws DataAccessException{
		boolean status = false;
			UUID guid = UUID.randomUUID();
			detail.setId(guid.toString());
			detail.setCreatedBy("SYSTEM");
			detail.setCreatedOn(new Timestamp(new Date().getTime()));
			status = paymentDao.saveDetail(detail);
			return status;
	}
	
	@Override
	public boolean updateDetail(MacPaymentDetail detail) throws DataAccessException{
		boolean status = false;
			detail.setModifiedBy("SYSTEM");
			detail.setModifiedOn(new Timestamp(new Date().getTime()));
			status = paymentDao.updateDetail(detail);
			return status;
	}
	
	
	@Override
	public List<MacPaymentDetail> findAllDetail(String customerId, String fileId, String status)throws DataAccessException {
		List<MacPaymentDetail> detailList = null;
		detailList = paymentDao.findAllDetail(customerId, fileId, status);
		return detailList;
	}
	@Override
	public MacPaymentDetail getDetail(String customerId, String fileId, String transactionId)throws DataAccessException {
		MacPaymentDetail detail = null;
		
		detail = paymentDao.getDetail(customerId, fileId, transactionId);
		
		return detail;
	}
	@Override
	public Long getSequence(String sequenceName) throws DataAccessException{
		Long value = null;
		BigDecimal valueBig = paymentDao.getSequence(sequenceName);
			if (valueBig != null) {
				value = Long.valueOf(valueBig.longValue());
			}
		
		return value;
	}
	
	@Override
	public List<MacPaymentDetail> getAllFailedTransactions(String fileReference) throws DataAccessException {
		List<MacPaymentDetail> list = null;
		
			list = paymentDao.getAllFailedTransactions(fileReference);
			return list;
	}
	@Override
	public boolean savePaymentLog(MacFileLog log) throws DataAccessException{
		boolean status = false;
			
			log.setType("PAYMENT");
			log.setCreatedBy("SYSTEM");
			log.setCreatedOn(new Timestamp(new Date().getTime()));
			status = paymentDao.savePaymentLog(log);
		
		return status;
	}
	@Override
	public List<ForeignHoliday> getForeignHoliday(Date tradeDate, String debitCurrency, String transactionCurrency) throws DataAccessException{
		List<ForeignHoliday> list = null;
		
			list = paymentDao.getForeignHoliday(tradeDate, debitCurrency.substring(0, 2),
					transactionCurrency.substring(0, 2));
		
		return list;
	}
	@Override
	public List<Object[]> getTransactionTypeCount(String customerId, String fileId)throws DataAccessException {
		List<Object[]> list = null;
		list = paymentDao.getTransactionTypeCount(customerId, fileId);
		return list;
	}
	@Override
	public List<Object[]> getStatusCount(String customerId, String fileId)throws DataAccessException {
		List<Object[]> list = null;
		list = paymentDao.getStatusCount(customerId, fileId);
		return list;
	}

	@Override
	public MacFileLog getFileLog(String id) throws DataAccessException{
		MacFileLog log = null;
		
		log = paymentDao.getFileLog(id);
		return log;
	}

	@Override
	public boolean updateFileLog(MacFileLog log)throws DataAccessException {
		boolean status = false;
			
			log.setModifiedBy("SYSTEM");
			log.setModifiedOn(new Timestamp(new Date().getTime()));
			status = paymentDao.updateFileLog(log);
		return status;
	}
	
	
	
	
	

}
