package com.bsf.macug.mt101.transaction;

import java.util.Date;
import java.util.List;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.mt101.entity.ForeignHoliday;
import com.bsf.macug.mt101.entity.MacFileLog;
import com.bsf.macug.mt101.entity.MacPaymentActivityLog;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.entity.MacPaymentHeader;

public interface InterPaymentTransactionalService {

	boolean saveHeader(MacPaymentHeader header) throws DataAccessException;

	boolean updateHeader(MacPaymentHeader header) throws DataAccessException;
	
	List<MacPaymentHeader> findAllHeader(String status) throws DataAccessException;
	
	public List<MacPaymentActivityLog>  getMT199BasicValidation() throws DataAccessException;
	
	public List<MacPaymentHeader> getMT199Pendings()  throws DataAccessException;
	
	public MacPaymentHeader getHeader(String customerId, String fileId) throws DataAccessException;
	
	public MacPaymentActivityLog getPaymentProcessLogByFileName(String fileName)throws DataAccessException;
	
	public boolean updatePaymnetProcessLog(MacPaymentActivityLog activityLog) throws DataAccessException;
	
	public boolean saveDetail(MacPaymentDetail detail) throws DataAccessException;
	
	public boolean updateDetail(MacPaymentDetail detail) throws DataAccessException;
	public List<MacPaymentDetail> findAllDetail(String customerId, String fileId, String status)throws DataAccessException;
	
	public MacPaymentDetail getDetail(String customerId, String fileId, String transactionId)throws DataAccessException;
	
	public Long getSequence(String sequenceName) throws DataAccessException;
	
	public List<MacPaymentDetail> getAllFailedTransactions(String fileReference) throws DataAccessException;
	public boolean savePaymentLog(MacFileLog log) throws DataAccessException;
	public List<ForeignHoliday> getForeignHoliday(Date tradeDate, String debitCurrency, String transactionCurrency) throws DataAccessException;
	public List<Object[]> getTransactionTypeCount(String customerId, String fileId)throws DataAccessException;
	public List<Object[]> getStatusCount(String customerId, String fileId)throws DataAccessException;
	public MacFileLog getFileLog(String id) throws DataAccessException;

	public boolean updateFileLog(MacFileLog log)throws DataAccessException; 

}
