package com.bsf.macug.mt101.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.Version;



/**
 * The persistent class for the MAC_PAYMNET_DETAIL database table.
 * 
 */
@Entity
@Table(name = "MAC_PAYMENT_DETAIL")
public class MacPaymentDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CUSTOMER_ID")
	private String customerId;

	@Id
	@Column(name = "FILE_REFERENCE")
	private String fileReference;

	@Id
	@Column(name = "TRANSACTION_REFERENCE")
	private String transactionReference;

	private String id;

	@Column(name = "ACCOUNT_INSTITUION_57")
	private String accountInstituion57;

	@Column(name = "ACCOUNT_INSTITUION_57_1")
	private String accountInstituion571;

	@Column(name = "ACCOUNT_INSTITUION_57_2")
	private String accountInstituion572;

	@Column(name = "ACCOUNT_INSTITUION_57_3")
	private String accountInstituion573;

	@Column(name = "ACCOUNT_INSTITUION_57_4")
	private String accountInstituion574;

	@Column(name = "BENEFICIARY_INFO_59")
	private String beneficiaryInfo59;

	@Column(name = "BENEFICIARY_INFO_59_1")
	private String beneficiaryInfo591;

	@Column(name = "BENEFICIARY_INFO_59_2")
	private String beneficiaryInfo592;

	@Column(name = "BENEFICIARY_INFO_59_3")
	private String beneficiaryInfo593;

	@Column(name = "BENEFICIARY_INFO_59_4")
	private String beneficiaryInfo594;

	@Column(name = "BUY_CURRENCY")
	private String buyCurrency;

	@Column(name = "BUY_RATE")
	private BigDecimal buyRate;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_ON")
	private Timestamp createdOn;

	@Column(name = "CREDIT_CURRENCY")
	private String creditCurrency;

	private String currency;

	@Column(name = "DEBIT_ACCOUNT")
	private String debitAccount;

	@Column(name = "DEBIT_CURRENCY")
	private String debitCurrency;

	private String description;
	
	private String action;

	@Column(name = "DETAILS_OF_CHARGE")
	private String detailsOfCharge;

	@Column(name = "EXCHANGE_RATE")
	private String exchangeRate;

	@Column(name = "FX_DEAL_ID")
	private String fxDealId;

	@Column(name = "FX_DEAL_REFERENCE")
	private String fxDealReference;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "MODIFIED_ON")
	private Timestamp modifiedOn;

	@Column(name = "ORDERING_CUSTOMER_50")
	private String orderingCustomer50;

	@Column(name = "ORDERING_CUSTOMER_50_1")
	private String orderingCustomer501;

	@Column(name = "ORDERING_CUSTOMER_50_2")
	private String orderingCustomer502;

	@Column(name = "ORDERING_CUSTOMER_50_3")
	private String orderingCustomer503;

	@Column(name = "ORDERING_CUSTOMER_50_4")
	private String orderingCustomer504;

	@Column(name = "REMITTANCE_INFO_70")
	private String remittanceInfo70;

	@Column(name = "REMITTANCE_INFO_70_1")
	private String remittanceInfo701;

	@Column(name = "REMITTANCE_INFO_70_2")
	private String remittanceInfo702;

	@Column(name = "REMITTANCE_INFO_70_3")
	private String remittanceInfo703;

	@Column(name = "SELL_CURRENCY")
	private String sellCurrency;

	@Column(name = "SELL_RATE")
	private BigDecimal sellRate;

	private String status;

	@Column(name = "TRANSACTION_AMOUNT")
	private BigDecimal transactionAmount;

	@Column(name = "TT_REFERENCE")
	private String ttReference;

	@Column(name = "FTS_REFERENCE")
	private String ftsReference;

	@Column(name = "MARKING_REFERENCE")
	private String markingReference;

	@Column(name = "MARKING_NARATIVE")
	private String markingNarative;

	@Column(name = "VALUE_DATE")
	private Date valueDate;

	@Column(name = "TRADE_DATE")
	private Date tradeDate;

	@Column(name = "DEBIT_AMOUNT")
	private BigDecimal debitAmount;

	@Column(name = "CREDIT_AMOUNT")
	private BigDecimal creditAmount;

	@Column(name = "DEBIT_RATE")
	private BigDecimal debitRate;

	@Column(name = "CREDIT_RATE")
	private BigDecimal creditRate;

	@Column(name = "TRANSACTION_AMOUNT_SAR")
	private BigDecimal transactionAmountInSar;

	@Column(name = "CHARGE_AMOUNT")
	private BigDecimal chargeAmount;

	@Column(name = "TUX_NARATIVE")
	private String tuxNarative;

	@Column(name = "CR_AC_BRANCH")
	private String creditAccountBranch;

	@Column(name = "DB_ACC_BRANCH")
	private String debitAccountBranch;

	@Column(name = "POSTED_DATE")
	private Timestamp postedDate;

	@Column(name = "APP_VALUE_DATE")
	private Date applicableValueDate;

	@Column(name = "TRANSACTION_TYPE")
	private String transactionType;

	@Lob
	@Column(name = "MT199_DATA")
	private byte[] mt199Data;

	@Column(name = "MT199_STATUS")
	private String mt199Status;

	@Column(name = "MT199_SENT_TIME")
	private Timestamp mt199SentTime;

	@Column(name = "KONDOR_FILE")
	private String kondorFile;

	@Column(name = "CAMM_ACTION_CODE")
	private String cammActionCode;

	@Column(name = "FTS_ACTION_CODE")
	private String ftsActionCode;

	@Version
	@Column(name = "VERSION")
	private Integer version;

	@Column(name = "VALIDATED_DATE")
	private Timestamp validatedDate;
	
	@Transient
	private String validTrans;

	public MacPaymentDetail() {
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getFileReference() {
		return fileReference;
	}

	public void setFileReference(String fileReference) {
		this.fileReference = fileReference;
	}

	public String getTransactionReference() {
		return transactionReference;
	}

	public void setTransactionReference(String transactionReference) {
		this.transactionReference = transactionReference;
	}

	public String getAccountInstituion57() {
		return accountInstituion57;
	}

	public void setAccountInstituion57(String accountInstituion57) {
		this.accountInstituion57 = accountInstituion57;
	}

	public String getAccountInstituion571() {
		return accountInstituion571;
	}

	public void setAccountInstituion571(String accountInstituion571) {
		this.accountInstituion571 = accountInstituion571;
	}

	public String getAccountInstituion572() {
		return accountInstituion572;
	}

	public void setAccountInstituion572(String accountInstituion572) {
		this.accountInstituion572 = accountInstituion572;
	}

	public String getAccountInstituion573() {
		return accountInstituion573;
	}

	public void setAccountInstituion573(String accountInstituion573) {
		this.accountInstituion573 = accountInstituion573;
	}

	public String getAccountInstituion574() {
		return accountInstituion574;
	}

	public void setAccountInstituion574(String accountInstituion574) {
		this.accountInstituion574 = accountInstituion574;
	}

	public String getBeneficiaryInfo59() {
		return beneficiaryInfo59;
	}

	public void setBeneficiaryInfo59(String beneficiaryInfo59) {
		this.beneficiaryInfo59 = beneficiaryInfo59;
	}

	public String getBeneficiaryInfo591() {
		return beneficiaryInfo591;
	}

	public void setBeneficiaryInfo591(String beneficiaryInfo591) {
		this.beneficiaryInfo591 = beneficiaryInfo591;
	}

	public String getBeneficiaryInfo592() {
		return beneficiaryInfo592;
	}

	public void setBeneficiaryInfo592(String beneficiaryInfo592) {
		this.beneficiaryInfo592 = beneficiaryInfo592;
	}

	public String getBeneficiaryInfo593() {
		return beneficiaryInfo593;
	}

	public void setBeneficiaryInfo593(String beneficiaryInfo593) {
		this.beneficiaryInfo593 = beneficiaryInfo593;
	}

	public String getBeneficiaryInfo594() {
		return beneficiaryInfo594;
	}

	public void setBeneficiaryInfo594(String beneficiaryInfo594) {
		this.beneficiaryInfo594 = beneficiaryInfo594;
	}

	public String getBuyCurrency() {
		return buyCurrency;
	}

	public void setBuyCurrency(String buyCurrency) {
		this.buyCurrency = buyCurrency;
	}

	public BigDecimal getBuyRate() {
		return buyRate;
	}

	public void setBuyRate(BigDecimal buyRate) {
		this.buyRate = buyRate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreditCurrency() {
		return creditCurrency;
	}

	public void setCreditCurrency(String creditCurrency) {
		this.creditCurrency = creditCurrency;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getDebitAccount() {
		return debitAccount;
	}

	public void setDebitAccount(String debitAccount) {
		this.debitAccount = debitAccount;
	}

	public String getDebitCurrency() {
		return debitCurrency;
	}

	public void setDebitCurrency(String debitCurrency) {
		this.debitCurrency = debitCurrency;
	}
    
		
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDetailsOfCharge() {
		return detailsOfCharge;
	}

	public void setDetailsOfCharge(String detailsOfCharge) {
		this.detailsOfCharge = detailsOfCharge;
	}

	public String getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getFxDealId() {
		return fxDealId;
	}

	public void setFxDealId(String fxDealId) {
		this.fxDealId = fxDealId;
	}

	public String getFxDealReference() {
		return fxDealReference;
	}

	public void setFxDealReference(String fxDealReference) {
		this.fxDealReference = fxDealReference;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getOrderingCustomer50() {
		return orderingCustomer50;
	}

	public void setOrderingCustomer50(String orderingCustomer50) {
		this.orderingCustomer50 = orderingCustomer50;
	}

	public String getOrderingCustomer501() {
		return orderingCustomer501;
	}

	public void setOrderingCustomer501(String orderingCustomer501) {
		this.orderingCustomer501 = orderingCustomer501;
	}

	public String getOrderingCustomer502() {
		return orderingCustomer502;
	}

	public void setOrderingCustomer502(String orderingCustomer502) {
		this.orderingCustomer502 = orderingCustomer502;
	}

	public String getOrderingCustomer503() {
		return orderingCustomer503;
	}

	public void setOrderingCustomer503(String orderingCustomer503) {
		this.orderingCustomer503 = orderingCustomer503;
	}

	public String getOrderingCustomer504() {
		return orderingCustomer504;
	}

	public void setOrderingCustomer504(String orderingCustomer504) {
		this.orderingCustomer504 = orderingCustomer504;
	}

	public String getRemittanceInfo70() {
		return remittanceInfo70;
	}

	public void setRemittanceInfo70(String remittanceInfo70) {
		this.remittanceInfo70 = remittanceInfo70;
	}

	public String getRemittanceInfo701() {
		return remittanceInfo701;
	}

	public void setRemittanceInfo701(String remittanceInfo701) {
		this.remittanceInfo701 = remittanceInfo701;
	}

	public String getRemittanceInfo702() {
		return remittanceInfo702;
	}

	public void setRemittanceInfo702(String remittanceInfo702) {
		this.remittanceInfo702 = remittanceInfo702;
	}

	public String getRemittanceInfo703() {
		return remittanceInfo703;
	}

	public void setRemittanceInfo703(String remittanceInfo703) {
		this.remittanceInfo703 = remittanceInfo703;
	}

	public String getSellCurrency() {
		return sellCurrency;
	}

	public void setSellCurrency(String sellCurrency) {
		this.sellCurrency = sellCurrency;
	}

	public BigDecimal getSellRate() {
		return sellRate;
	}

	public void setSellRate(BigDecimal sellRate) {
		this.sellRate = sellRate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public BigDecimal getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(BigDecimal transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getTtReference() {
		return ttReference;
	}

	public void setTtReference(String ttReference) {
		this.ttReference = ttReference;
	}

	public String getFtsReference() {
		return ftsReference;
	}

	public void setFtsReference(String ftsReference) {
		this.ftsReference = ftsReference;
	}

	public String getMarkingReference() {
		return markingReference;
	}

	public void setMarkingReference(String markingReference) {
		this.markingReference = markingReference;
	}

	public String getMarkingNarative() {
		return markingNarative;
	}

	public void setMarkingNarative(String markingNarative) {
		this.markingNarative = markingNarative;
	}

	public Date getValueDate() {
		return valueDate;
	}

	public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}

	public BigDecimal getDebitAmount() {
		return debitAmount;
	}

	public void setDebitAmount(BigDecimal debitAmount) {
		this.debitAmount = debitAmount;
	}

	public BigDecimal getCreditAmount() {
		return creditAmount;
	}

	public void setCreditAmount(BigDecimal creditAmount) {
		this.creditAmount = creditAmount;
	}

	public BigDecimal getDebitRate() {
		return debitRate;
	}

	public void setDebitRate(BigDecimal debitRate) {
		this.debitRate = debitRate;
	}

	public BigDecimal getCreditRate() {
		return creditRate;
	}

	public void setCreditRate(BigDecimal creditRate) {
		this.creditRate = creditRate;
	}

	public BigDecimal getTransactionAmountInSar() {
		return transactionAmountInSar;
	}

	public void setTransactionAmountInSar(BigDecimal transactionAmountInSar) {
		this.transactionAmountInSar = transactionAmountInSar;
	}

	public BigDecimal getChargeAmount() {
		return chargeAmount;
	}

	public void setChargeAmount(BigDecimal chargeAmount) {
		this.chargeAmount = chargeAmount;
	}

	public String getTuxNarative() {
		return tuxNarative;
	}

	public void setTuxNarative(String tuxNarative) {
		this.tuxNarative = tuxNarative;
	}

	public String getCreditAccountBranch() {
		return creditAccountBranch;
	}

	public void setCreditAccountBranch(String creditAccountBranch) {
		this.creditAccountBranch = creditAccountBranch;
	}

	public String getDebitAccountBranch() {
		return debitAccountBranch;
	}

	public void setDebitAccountBranch(String debitAccountBranch) {
		this.debitAccountBranch = debitAccountBranch;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Timestamp getPostedDate() {
		return postedDate;
	}

	public void setPostedDate(Timestamp postedDate) {
		this.postedDate = postedDate;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getApplicableValueDate() {
		return applicableValueDate;
	}

	public void setApplicableValueDate(Date applicableValueDate) {
		this.applicableValueDate = applicableValueDate;
	}

	public byte[] getMt199Data() {
		return mt199Data;
	}

	public void setMt199Data(byte[] mt199Data) {
		this.mt199Data = mt199Data;
	}

	public String getMt199Status() {
		return mt199Status;
	}

	public void setMt199Status(String mt199Status) {
		this.mt199Status = mt199Status;
	}

	public Timestamp getMt199SentTime() {
		return mt199SentTime;
	}

	public void setMt199SentTime(Timestamp mt199SentTime) {
		this.mt199SentTime = mt199SentTime;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getKondorFile() {
		return kondorFile;
	}

	public void setKondorFile(String kondorFile) {
		this.kondorFile = kondorFile;
	}

	public Date getTradeDate() {
		return tradeDate;
	}

	public void setTradeDate(Date tradeDate) {
		this.tradeDate = tradeDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getCammActionCode() {
		return cammActionCode;
	}

	public void setCammActionCode(String cammActionCode) {
		this.cammActionCode = cammActionCode;
	}

	public String getFtsActionCode() {
		return ftsActionCode;
	}

	public void setFtsActionCode(String ftsActionCode) {
		this.ftsActionCode = ftsActionCode;
	}

	public Timestamp getValidatedDate() {
		return validatedDate;
	}

	public void setValidatedDate(Timestamp validatedDate) {
		this.validatedDate = validatedDate;
	}

	public String getValidTrans() {
		return validTrans;
	}

	public void setValidTrans(String validTrans) {
		this.validTrans = validTrans;
	}
	
	

}