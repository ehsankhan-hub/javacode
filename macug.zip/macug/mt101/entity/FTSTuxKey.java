package com.bsf.macug.mt101.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

@Entity
@Table(name = "MAC_FTS_TUXEDO_UNIQUECON")
public class FTSTuxKey {

	@Id
	@Column(name = "FTS_REF")
	private String ftsReference;
	@Column(name = "CREATED_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdTime;
	@Column(name = "PAYDETAIL_TRAN_ID")
	private String transReference;
	@Column(name = "TUX_REQUEST")
	private String tuxedoRequest;
	@Column(name = "TUX_RESPONSE")
	private String tuxedoResponse;
	@Column(name = "SOURCE")
	private String source;

	@Version
	private int version;
	
	@Column(name = "TYPE")
	private String type;
	
	@Column(name = "TUX_RESPONSETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date responseTime;
	
	public FTSTuxKey() {
		super();
	}

	public FTSTuxKey(String ftsReference, Date createdTime,
			String transReference) {
		super();
		this.ftsReference = ftsReference;
		this.createdTime = createdTime;
		this.transReference = transReference;
	}

	public String getFtsReference() {
		return ftsReference;
	}

	public void setFtsReference(String ftsReference) {
		this.ftsReference = ftsReference;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getTransReference() {
		return transReference;
	}

	public void setTransReference(String transReference) {
		this.transReference = transReference;
	}

	public String getTuxedoRequest() {
		return tuxedoRequest;
	}

	public void setTuxedoRequest(String tuxedoRequest) {
		this.tuxedoRequest = tuxedoRequest;
	}

	public String getTuxedoResponse() {
		return tuxedoResponse;
	}

	public void setTuxedoResponse(String tuxedoResponse) {
		this.tuxedoResponse = tuxedoResponse;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	
	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Date getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(Date responseTime) {
		this.responseTime = responseTime;
	}

	@Override
	public String toString() {
		return "FTSTuxKey [ftsReference=" + ftsReference + ", createdTime="
				+ createdTime + ", transReference=" + transReference
				+ ", tuxedoRequest=" + tuxedoRequest + ", tuxedoResponse="
				+ tuxedoResponse + ", source=" + source + ", version="
				+ version + ", type=" + type + ", responseTime=" + responseTime
				+ "]";
	}

	
}
