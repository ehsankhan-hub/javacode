package com.bsf.macug.mt101.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;













@Entity
@Table(name="FOREIGN_HOLIDAY")
@NamedQuery(name="ForeignHoliday.findAll", query="SELECT f FROM ForeignHoliday f")
public class ForeignHoliday
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  @Id
  private long id;
  @Column(name="COUNTRY_CODE")
  private String countryCode;
  @Column(name="COUNTRY_NAME")
  private String countryName;
  @Column(name="CREATED_BY")
  private String createdBy;
  @Column(name="CREATED_DATE")
  private Timestamp createdDate;
  @Column(name="HOLIDAY_DATE")
  private Date holidayDate;
  @Column(name="HOLIDAY_DESCRIPTION")
  private String holidayDescription;
  @Column(name="HOLIDAY_TYPE")
  private String holidayType;
  @Column(name="MODIFIED_BY")
  private String modifiedBy;
  @Column(name="MODIFIED_DATE")
  private Timestamp modifiedDate;
  private BigDecimal status;
  
  public long getId()
  {
/*  56 */     return this.id;
  }
  
  public void setId(long id) {
/*  60 */     this.id = id;
  }
  
  public String getCountryCode() {
/*  64 */     return this.countryCode;
  }
  
  public void setCountryCode(String countryCode) {
/*  68 */     this.countryCode = countryCode;
  }
  
  public String getCountryName() {
/*  72 */     return this.countryName;
  }
  
  public void setCountryName(String countryName) {
/*  76 */     this.countryName = countryName;
  }
  
  public String getCreatedBy() {
/*  80 */     return this.createdBy;
  }
  
  public void setCreatedBy(String createdBy) {
/*  84 */     this.createdBy = createdBy;
  }
  
  public Timestamp getCreatedDate() {
/*  88 */     return this.createdDate;
  }
  
  public void setCreatedDate(Timestamp createdDate) {
/*  92 */     this.createdDate = createdDate;
  }
  
  public Date getHolidayDate() {
/*  96 */     return this.holidayDate;
  }
  
  public void setHolidayDate(Date holidayDate) {
/* 100 */     this.holidayDate = holidayDate;
  }
  
  public String getHolidayDescription() {
/* 104 */     return this.holidayDescription;
  }
  
  public void setHolidayDescription(String holidayDescription) {
/* 108 */     this.holidayDescription = holidayDescription;
  }
  
  public String getHolidayType() {
/* 112 */     return this.holidayType;
  }
  
  public void setHolidayType(String holidayType) {
/* 116 */     this.holidayType = holidayType;
  }
  
  public String getModifiedBy() {
/* 120 */     return this.modifiedBy;
  }
  
  public void setModifiedBy(String modifiedBy) {
/* 124 */     this.modifiedBy = modifiedBy;
  }
  
  public Timestamp getModifiedDate() {
/* 128 */     return this.modifiedDate;
  }
  
  public void setModifiedDate(Timestamp modifiedDate) {
/* 132 */     this.modifiedDate = modifiedDate;
  }
  
  public BigDecimal getStatus() {
/* 136 */     return this.status;
  }
  
  public void setStatus(BigDecimal status) {
/* 140 */     this.status = status;
  }
}


/* Location:              D:\MT101Code\MT101.jar!\BOOT-INF\classes\com\bsf\macug\mt101\entity\ForeignHoliday.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */