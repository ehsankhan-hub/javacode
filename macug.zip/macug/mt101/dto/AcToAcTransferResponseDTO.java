package com.bsf.macug.mt101.dto;

public class AcToAcTransferResponseDTO {

	private String srcSystem;					// Length: 3
	private String reqFunction;					// Length: 8
	private String severDate;						// Length: 8
	private String serverTime;					// Length: 6
	private String ftsReference;				// Length: 10
	private String ftsTransFunc;				// Length: 10
	private String cammTranNum;					// Length: 6
	private String numOfBlocks;					// Length: 3
	private String currBlockNum;					// Length: 3
	private String NumOfItems;						// Length: 3
	private String custCode;						// Length: 10
	private String accountNumberAsPerRequest;	// Length: 20
	private String initBranch;					// Length: 6
	private String initOfficer;					// Length: 9
	private String cardNumber; 					// Length: 23
	private String cammActionCode;					// Length: 4; 0000=Success
	private String lastUpdateDate;				// Length: 8
	private String lastUpdateTime;				// Length: 6
	private String tranStatus;					// Length: 3; "NOR"
	private String ftsActionCode;					// Length: 4; 0000=Success
	private String processingSeq;					// Length: 3
	private String detailLength;					// Length: 4;
	
	public String getSrcSystem() {
		return srcSystem;
	}
	
	public void setSrcSystem(String srcSystem) {
		this.srcSystem = srcSystem;
	}
	
	public String getReqFunction() {
		return reqFunction;
	}
	
	public void setReqFunction(String reqFunction) {
		this.reqFunction = reqFunction;
	}
	
	public String getSeverDate() {
		return severDate;
	}
	
	public void setSeverDate(String severDate) {
		this.severDate = severDate;
	}
	
	public String getServerTime() {
		return serverTime;
	}
	
	public void setServerTime(String serverTime) {
		this.serverTime = serverTime;
	}
	
	public String getFtsReference() {
		return ftsReference;
	}
	
	public void setFtsReference(String ftsReference) {
		this.ftsReference = ftsReference;
	}
	
	public String getFtsTransFunc() {
		return ftsTransFunc;
	}
	
	public void setFtsTransFunc(String ftsTransFunc) {
		this.ftsTransFunc = ftsTransFunc;
	}
	
	public String getCammTranNum() {
		return cammTranNum;
	}
	
	public void setCammTranNum(String cammTranNum) {
		this.cammTranNum = cammTranNum;
	}
	
	public String getNumOfBlocks() {
		return numOfBlocks;
	}
	
	public void setNumOfBlocks(String numOfBlocks) {
		this.numOfBlocks = numOfBlocks;
	}
	
	public String getCurrBlockNum() {
		return currBlockNum;
	}
	
	public void setCurrBlockNum(String currBlockNum) {
		this.currBlockNum = currBlockNum;
	}
	
	public String getNumOfItems() {
		return NumOfItems;
	}
	
	public void setNumOfItems(String numOfItems) {
		NumOfItems = numOfItems;
	}
	
	public String getCustCode() {
		return custCode;
	}
	
	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	
	public String getAccountNumberAsPerRequest() {
		return accountNumberAsPerRequest;
	}
	
	public void setAccountNumberAsPerRequest(String accountNumberAsPerRequest) {
		this.accountNumberAsPerRequest = accountNumberAsPerRequest;
	}
	
	public String getInitBranch() {
		return initBranch;
	}
	
	public void setInitBranch(String initBranch) {
		this.initBranch = initBranch;
	}
	
	public String getInitOfficer() {
		return initOfficer;
	}
	
	public void setInitOfficer(String initOfficer) {
		this.initOfficer = initOfficer;
	}
	
	public String getCardNumber() {
		return cardNumber;
	}
	
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	
	public String getCammActionCode() {
		return cammActionCode;
	}
	
	public void setCammActionCode(String cammActionCode) {
		this.cammActionCode = cammActionCode;
	}
	
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}
	
	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	
	public String getLastUpdateTime() {
		return lastUpdateTime;
	}
	
	public void setLastUpdateTime(String lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}
	
	public String getTranStatus() {
		return tranStatus;
	}
	
	public void setTranStatus(String tranStatus) {
		this.tranStatus = tranStatus;
	}
	
	public String getFtsActionCode() {
		return ftsActionCode;
	}
	
	public void setFtsActionCode(String ftsActionCode) {
		this.ftsActionCode = ftsActionCode;
	}
	
	public String getProcessingSeq() {
		return processingSeq;
	}
	
	public void setProcessingSeq(String processingSeq) {
		this.processingSeq = processingSeq;
	}
	
	public String getDetailLength() {
		return detailLength;
	}
	
	public void setDetailLength(String detailLength) {
		this.detailLength = detailLength;
	}

	@Override
	public String toString() {
		return "AcToAcTransferResponse [srcSystem=" + srcSystem
				+ ", reqFunction=" + reqFunction + ", severDate=" + severDate
				+ ", serverTime=" + serverTime + ", ftsReference="
				+ ftsReference + ", ftsTransFunc=" + ftsTransFunc
				+ ", cammTranNum=" + cammTranNum + ", numOfBlocks="
				+ numOfBlocks + ", currBlockNum=" + currBlockNum
				+ ", NumOfItems=" + NumOfItems + ", custCode=" + custCode
				+ ", accountNumberAsPerRequest=" + accountNumberAsPerRequest
				+ ", initBranch=" + initBranch + ", initOfficer=" + initOfficer
				+ ", cardNumber=" + cardNumber + ", cammActionCode="
				+ cammActionCode + ", lastUpdateDate=" + lastUpdateDate
				+ ", lastUpdateTime=" + lastUpdateTime + ", tranStatus="
				+ tranStatus + ", ftsActionCode=" + ftsActionCode
				+ ", processingSeq=" + processingSeq + ", detailLength="
				+ detailLength + "]";
	}
	
	
}
