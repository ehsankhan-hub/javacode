package com.bsf.macug.mt101.dto;

public class AccountEnquiryResponseDTO {

	@Override
	public String toString() {
		return "{\"srcSystem\":\"" + srcSystem
				+ "\",\"reqFunction\":\"" + reqFunction + "\",\"severDate\":\"" + severDate
				+ "\",\"serverTime\":\"" + serverTime + "\",\"ftsReference\":\""
				+ ftsReference + "\",\"ftsTransFunc\":\"" + ftsTransFunc
				+ "\",\"cammTranNum\":\"" + cammTranNum + "\",\"numOfBlocks\":\""
				+ numOfBlocks + "\",\"currBlockNum\":\"" + currBlockNum
				+ "\",\"NumOfItems\":\"" + NumOfItems + "\",\"custCode\":\"" + custCode
				+ "\",\"accountNumberAsPerRequest\":\"" + accountNumberAsPerRequest
				+ "\",\"initBranch\":\"" + initBranch + "\",\"initOfficer\":\"" + initOfficer
				+ "\",\"cardNumber\":\"" + cardNumber + "\",\"cammActionCode\":\""
				+ cammActionCode + "\",\"lastUpdateDate\":\"" + lastUpdateDate
				+ "\",\"lastUpdateTime\":\"" + lastUpdateTime + "\",\"tranStatus\":\""
				+ tranStatus + "\",\"ftsActionCode\":\"" + ftsActionCode
				+ "\",\"processingSeq\":\"" + processingSeq + "\",\"detailLength\":\""
				+ detailLength + "\",\"accountNumber\":\"" + accountNumber
				+ "\",\"accountCurrency\":\"" + accountCurrency + "\",\"productTypeCode\":\""
				+ productTypeCode + "\",\"productTypeDesc\":\"" + productTypeDesc
				+ "\",\"clientSegmentCode\":\"" + clientSegmentCode
				+ "\",\"clientSegmentDesc\":\"" + clientSegmentDesc
				+ "\",\"accountStatusCode\":\"" + accountStatusCode
				+ "\",\"accountStatusDesc\":\"" + accountStatusDesc
				+ "\",\"accountBranch\":\"" + accountBranch + "\",\"customerFullName\":\""
				+ customerFullName + "\",\"sarrafCardFlag\":\"" + sarrafCardFlag
				+ "\",\"languageIndicator\":\"" + languageIndicator
				+ "\",\"availableBalance\":\"" + availableBalance + "\",\"calendarPref\":\""
				+ calendarPref + "\",\"customerType\":\"" + customerType
				+ "\",\"customerSubType\":\"" + customerSubType
				+ "\",\"customerTypeDesc\":\"" + customerTypeDesc
				+ "\",\"relOfficerCode\":\"" + relOfficerCode + "\",\"relOficerDesc\":\""
				+ relOficerDesc + "\",\"profitCenter\":\"" + profitCenter
				+ "\",\"riskApprCode\":\"" + riskApprCode + "\",\"riskApprDesc\":\""
				+ riskApprDesc + "\",\"remedialFlag\":\"" + remedialFlag
				+ "\",\"deceasedFlag\":\"" + deceasedFlag + "\",\"idType\":\"" + idType
				+ "\",\"idNumber\":\"" + idNumber + "\",\"idExtNumber\":\"" + idExtNumber
				+ "\",\"ledgerBalance\":\"" + ledgerBalance + "\",\"fundsOnHold\":\""
				+ fundsOnHold + "\",\"odLimitAuthorised\":\"" + odLimitAuthorised
				+ "\",\"odLimitExpDate\":\"" + odLimitExpDate + "\",\"originalOdLimit\":\""
				+ originalOdLimit + "\",\"restraintIndicator\":\""
				+ restraintIndicator + "\",\"checqueNumber\":\"" + checqueNumber
				+ "\",\"chequeStatus\":\"" + chequeStatus + "\",\"odAmountTotal\":\""
				+ odAmountTotal + "\",\"totTxnsInProgressAmount\":\""
				+ totTxnsInProgressAmount + "\",\"totPledgedAmount\":\""
				+ totPledgedAmount + "\",\"accountType\":\"" + accountType
				+ "\",\"idExpiryDate\":\"" + idExpiryDate + "\",\"idExpiryIndicator\":\""
				+ idExpiryIndicator + "\",\"idExpiryMessage\":\"" + idExpiryMessage
				+ "\",\"freezeFlag\":\"" + freezeFlag + "\",\"previousFlag\":\""
				+ previousFlag + "\",\"internalKey\":\"" + internalKey + "\",\"address\":\""
				+ address + "\",\"dormantFlag\":\"" + dormantFlag + "\",\"currencyRate\":\""
				+ currencyRate + "\"}";
	}

	private String srcSystem; // Length: 3
	private String reqFunction; // Length: 8
	private String severDate; // Length: 8
	private String serverTime; // Length: 6
	private String ftsReference; // Length: 10
	private String ftsTransFunc; // Length: 10
	private String cammTranNum; // Length: 6
	private String numOfBlocks; // Length: 3
	private String currBlockNum; // Length: 3
	private String NumOfItems; // Length: 3
	private String custCode; // Length: 10
	private String accountNumberAsPerRequest; // Length: 20
	private String initBranch; // Length: 6
	private String initOfficer; // Length: 9
	private String cardNumber; // Length: 23
	private String cammActionCode; // Length: 4; 0000=Success
	private String lastUpdateDate; // Length: 8
	private String lastUpdateTime; // Length: 6
	private String tranStatus; // Length: 3; "NOR"
	private String ftsActionCode; // Length: 4; 0000=Success
	private String processingSeq; // Length: 3
	private String detailLength; // Length: 4;
	private String accountNumber; // Length: 11
	private String accountCurrency; // Length: 3
	private String productTypeCode; // Length: 6
	private String productTypeDesc; // Length: 40
	private String clientSegmentCode; // Length: 6
	private String clientSegmentDesc; // Length: 20
	private String accountStatusCode; // Length: 6
	private String accountStatusDesc; // Length: 20
	private String accountBranch; // Length: 6
	private String customerFullName; // Length: 40
	private String sarrafCardFlag; // Length: 1
	private String languageIndicator; // Length: 1
	private String availableBalance; // Length: 16
	private String calendarPref; // Length: 6
	private String customerType; // Length: 6
	private String customerSubType; // Length: 6
	private String customerTypeDesc; // Length: 35
	private String relOfficerCode; // Length: 6
	private String relOficerDesc; // Length: 40
	private String profitCenter; // Length: 6
	private String riskApprCode; // Length: 6
	private String riskApprDesc; // Length: 35
	private String remedialFlag; // Length: 1
	private String deceasedFlag; // Length: 1
	private String idType; // Length: 6
	private String idNumber; // Length: 15
	private String idExtNumber; // Length: 3
	private String ledgerBalance; // Length: 16
	private String fundsOnHold; // Length: 16
	private String odLimitAuthorised; // Length: 16
	private String odLimitExpDate; // Length: 8
	private String originalOdLimit;
	private String restraintIndicator; // Length: 1
	private String checqueNumber; // Length: 13
	private String chequeStatus; // Length: 1
	private String odAmountTotal; // Length: 16
	private String totTxnsInProgressAmount; // Length: 16
	private String totPledgedAmount; // Length: 16
	private String accountType; // Length: 4
	private String idExpiryDate; // Length: 8
	private String idExpiryIndicator; // Length: 1
	private String idExpiryMessage; // Length: 40
	private String freezeFlag; // Length: 1
	private String previousFlag; // Length: 6
	private String internalKey; // Length: 10
	private String address; // Length: 50
	private String dormantFlag; // Length: 1; Desc: D-Dormant, I- Inactive or
								// Spaces.
	private String currencyRate;

	public String getCurrencyRate() {
		return currencyRate;
	}

	public void setCurrencyRate(String currencyRate) {
		this.currencyRate = currencyRate;
	}

	public String getSrcSystem() {
		return srcSystem;
	}

	public void setSrcSystem(String srcSystem) {
		this.srcSystem = srcSystem;
	}

	public String getReqFunction() {
		return reqFunction;
	}

	public void setReqFunction(String reqFunction) {
		this.reqFunction = reqFunction;
	}

	public String getSeverDate() {
		return severDate;
	}

	public void setSeverDate(String severDate) {
		this.severDate = severDate;
	}

	public String getServerTime() {
		return serverTime;
	}

	public void setServerTime(String serverTime) {
		this.serverTime = serverTime;
	}

	public String getFtsReference() {
		return ftsReference;
	}

	public void setFtsReference(String ftsReference) {
		this.ftsReference = ftsReference;
	}

	public String getFtsTransFunc() {
		return ftsTransFunc;
	}

	public void setFtsTransFunc(String ftsTransFunc) {
		this.ftsTransFunc = ftsTransFunc;
	}

	public String getCammTranNum() {
		return cammTranNum;
	}

	public void setCammTranNum(String cammTranNum) {
		this.cammTranNum = cammTranNum;
	}

	public String getNumOfBlocks() {
		return numOfBlocks;
	}

	public void setNumOfBlocks(String numOfBlocks) {
		this.numOfBlocks = numOfBlocks;
	}

	public String getCurrBlockNum() {
		return currBlockNum;
	}

	public void setCurrBlockNum(String currBlockNum) {
		this.currBlockNum = currBlockNum;
	}

	public String getNumOfItems() {
		return NumOfItems;
	}

	public void setNumOfItems(String numOfItems) {
		NumOfItems = numOfItems;
	}

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	public String getAccountNumberAsPerRequest() {
		return accountNumberAsPerRequest;
	}

	public void setAccountNumberAsPerRequest(String accountNumberAsPerRequest) {
		this.accountNumberAsPerRequest = accountNumberAsPerRequest;
	}

	public String getInitBranch() {
		return initBranch;
	}

	public void setInitBranch(String initBranch) {
		this.initBranch = initBranch;
	}

	public String getInitOfficer() {
		return initOfficer;
	}

	public void setInitOfficer(String initOfficer) {
		this.initOfficer = initOfficer;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCammActionCode() {
		return cammActionCode;
	}

	public void setCammActionCode(String cammActionCode) {
		this.cammActionCode = cammActionCode;
	}

	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getLastUpdateTime() {
		return lastUpdateTime;
	}

	public void setLastUpdateTime(String lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}

	public String getTranStatus() {
		return tranStatus;
	}

	public void setTranStatus(String tranStatus) {
		this.tranStatus = tranStatus;
	}

	public String getFtsActionCode() {
		return ftsActionCode;
	}

	public void setFtsActionCode(String ftsActionCode) {
		this.ftsActionCode = ftsActionCode;
	}

	public String getProcessingSeq() {
		return processingSeq;
	}

	public void setProcessingSeq(String processingSeq) {
		this.processingSeq = processingSeq;
	}

	public String getDetailLength() {
		return detailLength;
	}

	public void setDetailLength(String detailLength) {
		this.detailLength = detailLength;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountCurrency() {
		return accountCurrency;
	}

	public void setAccountCurrency(String accountCurrency) {
		this.accountCurrency = accountCurrency;
	}

	public String getProductTypeCode() {
		return productTypeCode;
	}

	public void setProductTypeCode(String productTypeCode) {
		this.productTypeCode = productTypeCode;
	}

	public String getProductTypeDesc() {
		return productTypeDesc;
	}

	public void setProductTypeDesc(String productTypeDesc) {
		this.productTypeDesc = productTypeDesc;
	}

	public String getClientSegmentCode() {
		return clientSegmentCode;
	}

	public void setClientSegmentCode(String clientSegmentCode) {
		this.clientSegmentCode = clientSegmentCode;
	}

	public String getClientSegmentDesc() {
		return clientSegmentDesc;
	}

	public void setClientSegmentDesc(String clientSegmentDesc) {
		this.clientSegmentDesc = clientSegmentDesc;
	}

	public String getAccountStatusCode() {
		return accountStatusCode;
	}

	public void setAccountStatusCode(String accountStatusCode) {
		this.accountStatusCode = accountStatusCode;
	}

	public String getAccountStatusDesc() {
		return accountStatusDesc;
	}

	public void setAccountStatusDesc(String accountStatusDesc) {
		this.accountStatusDesc = accountStatusDesc;
	}

	public String getAccountBranch() {
		return accountBranch;
	}

	public void setAccountBranch(String accountBranch) {
		this.accountBranch = accountBranch;
	}

	public String getCustomerFullName() {
		return customerFullName;
	}

	public void setCustomerFullName(String customerFullName) {
		this.customerFullName = customerFullName;
	}

	public String getSarrafCardFlag() {
		return sarrafCardFlag;
	}

	public void setSarrafCardFlag(String sarrafCardFlag) {
		this.sarrafCardFlag = sarrafCardFlag;
	}

	public String getLanguageIndicator() {
		return languageIndicator;
	}

	public void setLanguageIndicator(String languageIndicator) {
		this.languageIndicator = languageIndicator;
	}

	public String getAvailableBalance() {
		return availableBalance;
	}

	public void setAvailableBalance(String availableBalance) {
		this.availableBalance = availableBalance;
	}

	public String getCalendarPref() {
		return calendarPref;
	}

	public void setCalendarPref(String calendarPref) {
		this.calendarPref = calendarPref;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getCustomerSubType() {
		return customerSubType;
	}

	public void setCustomerSubType(String customerSubType) {
		this.customerSubType = customerSubType;
	}

	public String getCustomerTypeDesc() {
		return customerTypeDesc;
	}

	public void setCustomerTypeDesc(String customerTypeDesc) {
		this.customerTypeDesc = customerTypeDesc;
	}

	public String getRelOfficerCode() {
		return relOfficerCode;
	}

	public void setRelOfficerCode(String relOfficerCode) {
		this.relOfficerCode = relOfficerCode;
	}

	public String getRelOficerDesc() {
		return relOficerDesc;
	}

	public void setRelOficerDesc(String relOficerDesc) {
		this.relOficerDesc = relOficerDesc;
	}

	public String getProfitCenter() {
		return profitCenter;
	}

	public void setProfitCenter(String profitCenter) {
		this.profitCenter = profitCenter;
	}

	public String getRiskApprCode() {
		return riskApprCode;
	}

	public void setRiskApprCode(String riskApprCode) {
		this.riskApprCode = riskApprCode;
	}

	public String getRiskApprDesc() {
		return riskApprDesc;
	}

	public void setRiskApprDesc(String riskApprDesc) {
		this.riskApprDesc = riskApprDesc;
	}

	public String getRemedialFlag() {
		return remedialFlag;
	}

	public void setRemedialFlag(String remedialFlag) {
		this.remedialFlag = remedialFlag;
	}

	public String getDeceasedFlag() {
		return deceasedFlag;
	}

	public void setDeceasedFlag(String deceasedFlag) {
		this.deceasedFlag = deceasedFlag;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public String getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	public String getIdExtNumber() {
		return idExtNumber;
	}

	public void setIdExtNumber(String idExtNumber) {
		this.idExtNumber = idExtNumber;
	}

	public String getLedgerBalance() {
		return ledgerBalance;
	}

	public void setLedgerBalance(String ledgerBalance) {
		this.ledgerBalance = ledgerBalance;
	}

	public String getFundsOnHold() {
		return fundsOnHold;
	}

	public void setFundsOnHold(String fundsOnHold) {
		this.fundsOnHold = fundsOnHold;
	}

	public String getOdLimitAuthorised() {
		return odLimitAuthorised;
	}

	public void setOdLimitAuthorised(String odLimitAuthorised) {
		this.odLimitAuthorised = odLimitAuthorised;
	}

	public String getOdLimitExpDate() {
		return odLimitExpDate;
	}

	public void setOdLimitExpDate(String odLimitExpDate) {
		this.odLimitExpDate = odLimitExpDate;
	}

	public String getRestraintIndicator() {
		return restraintIndicator;
	}

	public void setRestraintIndicator(String restraintIndicator) {
		this.restraintIndicator = restraintIndicator;
	}

	public String getChecqueNumber() {
		return checqueNumber;
	}

	public void setChecqueNumber(String checqueNumber) {
		this.checqueNumber = checqueNumber;
	}

	public String getChequeStatus() {
		return chequeStatus;
	}

	public void setChequeStatus(String chequeStatus) {
		this.chequeStatus = chequeStatus;
	}

	public String getOdAmountTotal() {
		return odAmountTotal;
	}

	public void setOdAmountTotal(String odAmountTotal) {
		this.odAmountTotal = odAmountTotal;
	}

	public String getTotTxnsInProgressAmount() {
		return totTxnsInProgressAmount;
	}

	public void setTotTxnsInProgressAmount(String totTxnsInProgressAmount) {
		this.totTxnsInProgressAmount = totTxnsInProgressAmount;
	}

	public String getTotPledgedAmount() {
		return totPledgedAmount;
	}

	public void setTotPledgedAmount(String totPledgedAmount) {
		this.totPledgedAmount = totPledgedAmount;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getIdExpiryDate() {
		return idExpiryDate;
	}

	public void setIdExpiryDate(String idExpiryDate) {
		this.idExpiryDate = idExpiryDate;
	}

	public String getIdExpiryIndicator() {
		return idExpiryIndicator;
	}

	public void setIdExpiryIndicator(String idExpiryIndicator) {
		this.idExpiryIndicator = idExpiryIndicator;
	}

	public String getIdExpiryMessage() {
		return idExpiryMessage;
	}

	public void setIdExpiryMessage(String idExpiryMessage) {
		this.idExpiryMessage = idExpiryMessage;
	}

	public String getFreezeFlag() {
		return freezeFlag;
	}

	public void setFreezeFlag(String freezeFlag) {
		this.freezeFlag = freezeFlag;
	}

	public String getPreviousFlag() {
		return previousFlag;
	}

	public void setPreviousFlag(String previousFlag) {
		this.previousFlag = previousFlag;
	}

	public String getInternalKey() {
		return internalKey;
	}

	public void setInternalKey(String internalKey) {
		this.internalKey = internalKey;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDormantFlag() {
		return dormantFlag;
	}

	public void setDormantFlag(String dormantFlag) {
		this.dormantFlag = dormantFlag;
	}

	public String getOriginalOdLimit() {
		return originalOdLimit;
	}

	public void setOriginalOdLimit(String originalOdLimit) {
		this.originalOdLimit = originalOdLimit;
	}

}
