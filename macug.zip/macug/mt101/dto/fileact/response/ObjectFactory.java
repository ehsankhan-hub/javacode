package com.bsf.macug.mt101.dto.fileact.response;

import javax.xml.bind.annotation.XmlRegistry;

@XmlRegistry
public class ObjectFactory {

	/**
	 * Create a new ObjectFactory that can be used to create new instances of schema
	 * derived classes for package: com.bsf.macug.application.fileact
	 * 
	 */
	public ObjectFactory() {
		
	}

	/**
	 * Create an instance of {@link PaymentFileActResponse.Header }
	 * 
	 */
	public PaymentFileActResponse.Header createPaymentFileActResponseHeader() {
		return new PaymentFileActResponse.Header();
	}

	/**
	 * Create an instance of {@link PaymentFileActResponse.Body }
	 * 
	 */
	public PaymentFileActResponse.Body createPaymentFileActResponseBody() {
		return new PaymentFileActResponse.Body();
	}

	/**
	 * Create an instance of {@link PaymentFileActResponse }
	 * 
	 */
	public PaymentFileActResponse createPaymentFileActResponse() {
		return new PaymentFileActResponse();
	}

	/**
	 * Create an instance of {@link Message.Body.PaymentResponse }
	 * 
	 */
	public PaymentFileActResponse.Body.PaymentResponse createPaymentFileActResponseBodyPaymentResponse() {
		return new PaymentFileActResponse.Body.PaymentResponse();
	}

}
