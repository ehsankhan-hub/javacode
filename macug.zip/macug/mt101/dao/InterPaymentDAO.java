package com.bsf.macug.mt101.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.mt101.entity.ForeignHoliday;
import com.bsf.macug.mt101.entity.MacFileLog;
import com.bsf.macug.mt101.entity.MacPaymentActivityLog;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.entity.MacPaymentHeader;

public interface InterPaymentDAO {

	boolean saveHeader(MacPaymentHeader header) throws DataAccessException;

	boolean updateHeader(MacPaymentHeader header) throws DataAccessException;

	List<MacPaymentHeader> findAllHeader(String status) throws DataAccessException;

	MacPaymentHeader getHeader(String customerId, String fileId) throws DataAccessException;

	boolean saveDetail(MacPaymentDetail Detail) throws DataAccessException;

	boolean updateDetail(MacPaymentDetail Detail) throws DataAccessException;

	List<MacPaymentDetail> findAllDetail(String customerId, String fileId, String status) throws DataAccessException;

	MacPaymentDetail getDetail(String customerId, String fileId, String transactionId) throws DataAccessException;

	BigDecimal getSequence(String sequenceName) throws DataAccessException;

	List<MacPaymentHeader> getMT199Pendings() throws DataAccessException;

	List<MacPaymentDetail> getAllFailedTransactions(String fileReference) throws DataAccessException;

	boolean savePaymentLog(MacFileLog log) throws DataAccessException;

	List<ForeignHoliday> getForeignHoliday(Date tradeDate, String debitCurrency, String transactionCurrency)
			throws DataAccessException;

	List<Object[]> getStatusCount(String customerId, String fileId) throws DataAccessException;

	List<Object[]> getTransactionTypeCount(String customerId, String fileId) throws DataAccessException;

	MacFileLog getFileLog(String id) throws DataAccessException;

	boolean updateFileLog(MacFileLog log) throws DataAccessException;

	boolean savePaymentProcessLog(MacPaymentActivityLog activityLog) throws DataAccessException;

	public List<MacPaymentActivityLog> getMT199BasicValidation() throws DataAccessException;

	public boolean updatePaymnetProcessLog(MacPaymentActivityLog activityLog) throws DataAccessException;

	public MacPaymentActivityLog getPaymentProcessLogByFileName(String fileName) throws DataAccessException;
}
