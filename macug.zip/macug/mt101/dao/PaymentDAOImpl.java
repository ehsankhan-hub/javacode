package com.bsf.macug.mt101.dao;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.mt101.entity.ForeignHoliday;
import com.bsf.macug.mt101.entity.MacFileLog;
import com.bsf.macug.mt101.entity.MacPaymentActivityLog;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.entity.MacPaymentHeader;

@Repository
public class PaymentDAOImpl implements InterPaymentDAO {

	private static final Logger logger = Logger.getLogger(PaymentDAOImpl.class.getName());

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public boolean saveHeader(MacPaymentHeader header) throws DataAccessException {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(header);
			status = true;
		} catch (Exception e) {
			logger.error("Error in saving payment header. Error " + e.getMessage(), e);
			throw new DataAccessException(e);
		}
		return status;
	}

	@Override
	public boolean updateHeader(MacPaymentHeader header) throws DataAccessException {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.update(header);
			status = true;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new DataAccessException(e);
		}
		return status;
	}
	
	
	@Override
	public boolean updatePaymnetProcessLog(MacPaymentActivityLog activityLog) throws DataAccessException {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.update(activityLog);
			status = true;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new DataAccessException(e);
		}
		return status;
	}

	@Override
	public List<MacPaymentHeader> findAllHeader(String status) throws DataAccessException {
		List<MacPaymentHeader> headerList = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentHeader.class);
			if (!StringUtils.isEmpty(status)) {
				criteria.add(Restrictions.eq("status", status));
			}
			criteria.add(Restrictions.ne("processingStatus", 1));

			headerList = criteria.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new DataAccessException(e);
		}
		return headerList;
	}

	@Override
	public MacPaymentHeader getHeader(String customerId, String fileId) {
		MacPaymentHeader header = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentHeader.class);
			criteria.add(Restrictions.eq("customerId", customerId));
			criteria.add(Restrictions.eq("fileReference", fileId));
			header = (MacPaymentHeader) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return header;
	}
	@Override
	public MacPaymentActivityLog getPaymentProcessLogByFileName(String fileName) {
		MacPaymentActivityLog macPaymnentActivLog=null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentActivityLog.class);
			criteria.add(Restrictions.eq("custReqFile", fileName));
			criteria.add(Restrictions.eq("processSubject", "FAILED"));
			macPaymnentActivLog = (MacPaymentActivityLog) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return macPaymnentActivLog;
	}

	@Override
	public boolean saveDetail(MacPaymentDetail detail) {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(detail);
			status = true;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public boolean updateDetail(MacPaymentDetail detail) {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.update(detail);
			status = true;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public List<MacPaymentDetail> findAllDetail(String customerId, String fileId, String status) {
		List<MacPaymentDetail> detailList = null;
		
		
		try {
			
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentDetail.class);
			logger.info("customerId--"+customerId);
			logger.info("fileId/fileReference--"+fileId);
			logger.info("status--"+status);
			if (!StringUtils.isEmpty(customerId)) {
				criteria.add(Restrictions.eq("customerId", customerId));
			}
			if (!StringUtils.isEmpty(fileId)) {
				criteria.add(Restrictions.eq("fileReference", fileId));
			}
			if (!StringUtils.isEmpty(status)) {
				criteria.add(Restrictions.eq("status", status));
			}

			if ("HOLD".equalsIgnoreCase(status)) {
				Date today = new Date();
				DateFormat sdf = new SimpleDateFormat("ddMMyyyy");
				String strToday = sdf.format(today);
				today = sdf.parse(strToday);
				criteria.add(Restrictions.eq("tradeDate", today));
			}

			detailList = criteria.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detailList;
	}

	@Override
	public MacPaymentDetail getDetail(String customerId, String fileId, String transactionId) {
		MacPaymentDetail detail = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentDetail.class);
			criteria.add(Restrictions.eq("customerId", customerId));
			criteria.add(Restrictions.eq("fileReference", fileId));
			criteria.add(Restrictions.eq("transactionReference", transactionId));
			detail = (MacPaymentDetail) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detail;
	}

	@Override
	public BigDecimal getSequence(String sequenceName) {
		Session session = null;
		BigDecimal sequenceVal = null;
		try {
			logger.info("(getSequence)==> updatePaymentHeader STARTED");
			session = sessionFactory.getCurrentSession();
			SQLQuery query = session.createSQLQuery("select " + sequenceName + ".NEXTVAL as id from dual")
					.addScalar("id");
			sequenceVal = (BigDecimal) query.uniqueResult();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		logger.info("(getSequence)==> return value" + sequenceVal);
		return sequenceVal;
	}

	@Override
	public List<MacPaymentHeader> getMT199Pendings() {
		List<MacPaymentHeader> detailList = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentHeader.class);
			criteria.add(Restrictions.eq("mt199Status", "PENDING"));
			criteria.add(Restrictions.or(Restrictions.eq("status", "COMPLETED"), Restrictions.eq("status", "FAILED")));
			criteria.add(Restrictions.ne("processingStatus", 1));
			detailList = criteria.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detailList;
	}
	
	
	
	
	public List<MacPaymentActivityLog> getMT199BasicValidation(){
		List<MacPaymentActivityLog> detailList = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentActivityLog.class);
			//criteria.add(Restrictions.eq("mt199Status", "PENDING"));
			criteria.add(Restrictions.eq("processStatus", 0));
			criteria.add(Restrictions.eq("processSubject", "FAILED"));
			//criteria.add(Restrictions.ne("processingStatus", 1));
			detailList = criteria.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detailList;
	}
	
	

	@Override
	public List<MacPaymentDetail> getAllFailedTransactions(String fileReference) {
		List<MacPaymentDetail> detailList = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentDetail.class);
			criteria.add(Restrictions.eq("fileReference", fileReference));
			//criteria.add(Restrictions.or(Restrictions.eq("status", "DE"),Restrictions.eq("status", "FAILED"),Restrictions.eq("status", "NETE")));
			detailList = criteria.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detailList;
	}

	@Override
	public boolean savePaymentLog(MacFileLog log) {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(log);
			status = true;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public List<ForeignHoliday> getForeignHoliday(Date tradeDate, String debitCurrency, String transactionCurrency) {
		List<ForeignHoliday> list = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(ForeignHoliday.class);
			criteria.add(Restrictions.eq("holidayDate", tradeDate));

			criteria.add(Restrictions.or(Restrictions.eq("holidayType", "W"), Restrictions.eq("holidayType", "H")));
			criteria.add(Restrictions.or(Restrictions.eq("countryCode", debitCurrency),
					Restrictions.eq("countryCode", transactionCurrency)));
			criteria.add(Restrictions.eq("status", BigDecimal.ONE));
			list = criteria.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return list;
	}

	@Override
	public List<Object[]> getStatusCount(String customerId, String fileId) {
		List<Object[]> result = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentDetail.class);
			criteria.add(Restrictions.eq("customerId", customerId));
			criteria.add(Restrictions.eq("fileReference", fileId));

			ProjectionList projectionList = Projections.projectionList();
			projectionList.add(Projections.groupProperty("status"));
			projectionList.add(Projections.rowCount());
			criteria.setProjection(projectionList);

			result = criteria.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return result;
	}

	@Override
	public List<Object[]> getTransactionTypeCount(String customerId, String fileId) {
		List<Object[]> result = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentDetail.class);
			criteria.add(Restrictions.eq("customerId", customerId));
			criteria.add(Restrictions.eq("fileReference", fileId));

			ProjectionList projectionList = Projections.projectionList();
			projectionList.add(Projections.groupProperty("transactionType"));
			projectionList.add(Projections.rowCount());
			criteria.setProjection(projectionList);

			result = criteria.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return result;
	}

	@Override
	public MacFileLog getFileLog(String id) {
		MacFileLog detail = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacFileLog.class);
			criteria.add(Restrictions.eq("id", id));
			detail = (MacFileLog) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detail;
	}

	@Override
	public boolean updateFileLog(MacFileLog log) {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.update(log);
			status = true;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public boolean savePaymentProcessLog(MacPaymentActivityLog activityLog) {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(activityLog);
			status = true;
		} catch (Exception e) {
			logger.error("(savePaymentProcessLog)==> Error in saving payment activity log : " + e.getMessage(), e);
		}
		return status;
	}

}
