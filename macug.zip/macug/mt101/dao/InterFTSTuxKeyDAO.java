package com.bsf.macug.mt101.dao;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.mt101.entity.FTSTuxKey;

public interface InterFTSTuxKeyDAO {

	boolean saveFTSTuxKey(FTSTuxKey ftsTuxKey) throws DataAccessException;

	boolean updateFTSTuxKey(FTSTuxKey ftsTuxKey) throws DataAccessException;

	FTSTuxKey getFTSTuxKey(String key);
	
}
