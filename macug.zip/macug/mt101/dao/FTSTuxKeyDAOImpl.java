package com.bsf.macug.mt101.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.mt101.entity.FTSTuxKey;

@Repository
public class FTSTuxKeyDAOImpl implements InterFTSTuxKeyDAO {

	private static final Logger logger = Logger
			.getLogger(FTSTuxKeyDAOImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public boolean saveFTSTuxKey(FTSTuxKey ftsTuxKey)
			throws DataAccessException {
		DateFormat dfDate = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
		Session session = null;
		boolean status = false;
		try {
			session = sessionFactory.getCurrentSession();
			logger.info("Saving FTS key " + ftsTuxKey.getFtsReference()
					+ " for transaction " + ftsTuxKey.getTransReference()
					+ " at " + dfDate.format(new Date()));
			session.save(ftsTuxKey);
			status = true;
		} catch (Exception e) {
			logger.error(
					"Failed to save FTS tux key at "
							+ dfDate.format(new Date()) + ". Error "
							+ e.getMessage(), e);
			throw new DataAccessException();
		}
		return status;
	}

	@Override
	public boolean updateFTSTuxKey(FTSTuxKey ftsTuxKey)
			throws DataAccessException {
		DateFormat dfDate = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
		Session session = null;
		boolean status = false;
		try {
			session = sessionFactory.getCurrentSession();
			session.update(ftsTuxKey);
			status = true;
		} catch (Exception e) {
			logger.error(
					"Failed to update FTS tux key at "
							+ dfDate.format(new Date()) + ". Error "
							+ e.getMessage(), e);
			throw new DataAccessException();
		}
		return status;
	}

	@Override
	public FTSTuxKey getFTSTuxKey(String key){
		FTSTuxKey ftsTuxKey = null;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(FTSTuxKey.class);
			criteria.add(Restrictions.eq("ftsReference", key));
			ftsTuxKey = (FTSTuxKey) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
		}
		return ftsTuxKey;
	}
}
