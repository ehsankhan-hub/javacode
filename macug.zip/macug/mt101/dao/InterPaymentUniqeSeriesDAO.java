package com.bsf.macug.mt101.dao;

import com.bsf.macug.mt101.entity.PaymentUniqeSeries;

public interface InterPaymentUniqeSeriesDAO {
	boolean save(PaymentUniqeSeries entity);
}
