package com.bsf.macug.mt101.dao;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bsf.macug.mt101.entity.PaymentUniqeSeries;

@Repository
public class PaymentUniqeSeriesDAOImpl implements InterPaymentUniqeSeriesDAO{
	private static final Logger logger = Logger
			.getLogger(PaymentUniqeSeriesDAOImpl.class.getName());
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public boolean save(PaymentUniqeSeries entity) {
		Session session = null;
		boolean status = false;
		try {
			session = sessionFactory.getCurrentSession();
			session.save(entity);
			status = true;
		} catch (Exception e) {
			logger.error(
					"(save)==> Failed to save unique seiries"
							+ e.getMessage(), e);
		}
		return status;
	}

}
