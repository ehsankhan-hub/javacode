package com.bsf.macug.exception;

public class ValidationException extends Exception{
	private String errorCode;

	public ValidationException(String errorCode) {
		super();
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}
	
}
