package com.bsf.macug.util;

import com.bsf.macug.exception.FileHandlerException;
import java.io.File;

public interface InterFileUtils {
	byte[] readFile(String paramString) throws FileHandlerException;

	boolean moveFile(File paramFile1, File paramFile2, String paramString) throws FileHandlerException;

	boolean createFile(String paramString1, String paramString2, String paramString3, String paramString4)
			throws FileHandlerException;

	String getFileExtension(File paramFile);

	String getFileNameWithoutExtension(File paramFile);

	boolean isFileReadyToRead(File paramFile);

	File[] sortFilesByCreationTime(File[] files);
}
