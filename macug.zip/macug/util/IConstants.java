package com.bsf.macug.util;

public class IConstants {
	public enum RATE_INDICATOR {
		NOT_SUPPORTED,SAME_CUR,CROS_CUR,AUTO_FX,URG_AUTO_FX;		
	}
}
