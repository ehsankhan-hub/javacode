package com.bsf.macug.util;

import java.math.BigInteger;
import org.springframework.util.StringUtils;

public class IbanUtils {
	private static final BigInteger BD_97 = new BigInteger("97");
	private static final BigInteger BD_98 = new BigInteger("98");

	public static String genIBAN(String bankCode, String accNumber, String countryCode) {
		if (isValidSaudiIBAN(accNumber)) {
			return accNumber;
		}
		String ibanStr = "";

		if (accNumber.length() < 18) {
		}

		String sIban = bankCode + accNumber;

		ibanStr = (countryCode != null ? countryCode.toUpperCase() : "") + getChecksum(sIban, countryCode) + sIban;
		return ibanStr;
	}

	public static boolean isValidSaudiIBAN(String ibanStr) {
		if (StringUtils.isEmpty(ibanStr))
			return false;
		if (ibanStr.length() < 24) {
			return false;
		}

		return getChecksum(ibanStr, null) == 97;
	}

	public static int getChecksum(String sIban, String countryCode) {
		String ibanStr = "";
		String sLCCS = "";
		String sIbanMixed = "";
		String sIbanDigits = "";

		String skipChars = " .-_,/";

		if ((countryCode != null) && (countryCode.length() > 0)) {
			sLCCS = countryCode + "00";
			sIbanMixed = sIban + sLCCS.toUpperCase();
		} else {
			sLCCS = sIban.substring(0, 4);
			sIbanMixed = sIban.substring(4, sIban.length()) + sLCCS.toUpperCase();
		}

		for (int i = 0; i < sIbanMixed.length(); i++) {
			char ch = sIbanMixed.charAt(i);

			if (Character.isDigit(ch)) {
				sIbanDigits = sIbanDigits + ch;
			} else if (skipChars.indexOf(ch) == -1) {

				if ((ch < 'A') || (ch > 'Z')) {
					int checkSum = -1;
					return checkSum;
				}

				sIbanDigits = sIbanDigits + (ch - '7');
			}
		}

		int largeModulous = modulo97(sIbanDigits);
		int checkSum = 98 - largeModulous;
		return checkSum;
	}

	public static int modulo97(String bban) {
		BigInteger b = new BigInteger(bban);
		b = b.divideAndRemainder(BD_97)[1];
		b = BD_98.min(b);
		b = b.divideAndRemainder(BD_97)[1];

		return b.intValue();
	}

	public static String removeNonAlpha(String iban) {
		StringBuffer result = new StringBuffer();
		for (int i = 0; i < iban.length(); i++) {
			char c = iban.charAt(i);
			if ((Character.isLetter(c)) || (Character.isDigit(c))) {
				result.append(c);
			}
		}
		return result.toString();
	}

	public static String getCustomerCPTFromAccount(String customerAccountNo) {
		String cptNumber = null;

		if (customerAccountNo != null) {
			int acctLength = customerAccountNo.length();
			if (acctLength == 11) {
				cptNumber = customerAccountNo.substring(0, 6);

			} else if ((acctLength > 11) && (acctLength < 24)) {
				int startIndex = acctLength - 11;
				cptNumber = customerAccountNo.substring(startIndex, startIndex + 6);

			} else if (acctLength == 24) {
				cptNumber = customerAccountNo.substring(13, 19);
			} else if (acctLength == 6) {
				cptNumber = customerAccountNo;
			}
		}
		return cptNumber;
	}
}
