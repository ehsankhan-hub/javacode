package com.bsf.macug.util;

import com.bsf.macug.application.mail.dto.MailServerDTO;
import com.bsf.macug.exception.SystemPropertyNotConfigurationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.mt101.entity.MacPaymentDetail;

import java.io.IOException;
import java.util.Map;

public interface InterUtils {
	String getTTReference(String paramString);

	String getFTSReference(String paramString);

	String getTransactionReference(int paramInt);

	String getDynamicNarativeReferenceNumber(int paramInt);

	String appendCharacter(String paramString1, int paramInt, String paramString2, String paramString3);

	String getPaymentType(MacPaymentDetail paramMacPaymentDetail, Map<String, Map<String, SystemParameters>> paramMap);

	String trimFromEnd(String paramString, int paramInt);

	Map<String, Map<String, SystemParameters>> loadSystemProperties() throws SystemPropertyNotConfigurationException;

	MailServerDTO getMailDTO();

	String removeStealinkCharacter(byte[] message) throws IOException;

	/**
	 * This method will log MT100 process activity to MAC_PAYMENT_PROCESSLOG table
	 * 
	 * @param subject
	 * @param description
	 * @param finOrFileAct
	 * @param fileName
	 * @return true or false
	 */
	boolean logMT100Activity(String customerId,String subject, String description, String finOrFileAct, String fileName,Integer staus);
}
