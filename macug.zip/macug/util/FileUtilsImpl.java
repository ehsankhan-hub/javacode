package com.bsf.macug.util;

import com.bsf.macug.exception.FileHandlerException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;
import java.util.Random;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class FileUtilsImpl implements InterFileUtils {
	private static final Logger logger = Logger.getLogger(FileUtilsImpl.class.getName());

	@Autowired
	InterUtils utils;

	@Autowired
	InterSystemParameterService systemParameterService;
	@Value("${mt100.bkp.ext}")
	private String BK_FILE_EXT;

	@Override
	public byte[] readFile(String path) throws FileHandlerException {
		byte[] byContents = null;
		FileInputStream fin = null;
		try {
			if (path != null) {
				File fPath = new File(path);
				if ((fPath.exists()) && (fPath.canRead())) {
					fin = new FileInputStream(fPath);
					byContents = new byte[fin.available()];
					fin.read(byContents, 0, fin.available());
				} else {
					throw new FileHandlerException("Cannot read file contents");
				}
			} else {
				throw new FileHandlerException("Cannot read file contents");
			}

			return byContents;
		} catch (Exception e) {
			throw new FileHandlerException("Error in reading file contents");
		} finally {
			if (fin != null) {
				try {
					fin.close();
				} catch (IOException e) {
					logger.error("Error in closing file", e);
				}
			}
		}
	}

	@Override
	public boolean moveFile(File sourceFile, File destinationFile, String type) throws FileHandlerException {
		boolean status = false;
		
		try {
			Map<String, Map<String, SystemParameters>> allProperties = this.utils.loadSystemProperties();
			Map<String, SystemParameters> macPathProperties = (Map) allProperties.get("macPathMap");
			String errorPath = this.systemParameterService.getSystemParametersDescription2("MT101_FIL_ERR",
					macPathProperties);

			if (type.equals("FIN")) {
				errorPath = this.systemParameterService.getSystemParametersDescription2("MT101_FIN_ERR",
						macPathProperties);
			}
			
			if (destinationFile.exists()) {
				
				logger.info("File exist in destination folder.");
				File errorFile = new File(errorPath + sourceFile.getName());
				if (errorFile.exists()) {
					Random rand = new Random();
					int n = rand.nextInt(1000) + 1;
					String newName = "DUPLICATE_" + n + "_" + sourceFile.getName();
					logger.info("File exist in error folder also. Prefixing with DUPLICATE_" + n + "_");
					errorFile = new File(errorPath + newName);
					
				}
				if (!moveFile(sourceFile, errorFile, type)) {
					errorFile = new File(errorPath + sourceFile.getName());
					moveFile(sourceFile, errorFile, type);
				}
				throw new FileHandlerException("Same file already exist in destination folder. Failed to move.");
			}

			/*if (destinationFile.exists()) {
				logger.info("File exist in destination folder.");
				File errorFile = new File(errorPath + sourceFile.getName());
				if (errorFile.exists()) {
					Random rand = new Random();
					int n = rand.nextInt(1000) + 1;
					String newName = "DUPLICATE_" + n + "_" + sourceFile.getName();
					logger.info("File exist in error folder also. Prefixing with DUPLICATE_" + n + "_");
					errorFile = new File(errorPath + newName);
				}
				if (!moveFile(sourceFile, errorFile, type)) {
					errorFile = new File(errorPath + sourceFile.getName());
					moveFile(sourceFile, errorFile, type);
				}
				throw new FileHandlerException("Same file already exist in destination folder. Failed to move.");
			}*/

			logger.info("Moving file from path : " + sourceFile.getAbsolutePath() + "  to path : "
					+ destinationFile.getAbsolutePath());
			status = sourceFile.renameTo(destinationFile);

			if (!status) {
				//throw new FileHandlerException("Error while moving the file.");
				throw new FileHandlerException("Same file already exist in destination folder. Failed to move.");
				
			}

			String bkSourceFileName = getFileNameWithoutExtension(sourceFile);
			String bkDestFileName = getFileNameWithoutExtension(destinationFile);
			String sourceDir = sourceFile.getParent();
			String destinationDir = destinationFile.getParent();

			File bkSourceFile = new File(sourceDir + "\\" + bkSourceFileName + this.BK_FILE_EXT);
			File bkDestinationFile = new File(destinationDir + "\\" + bkDestFileName + this.BK_FILE_EXT);

			status = bkSourceFile.renameTo(bkDestinationFile);

			if (!status) {
				logger.error("Move failed.");
				//throw new FileHandlerException("Error while moving the file.");
				throw new FileHandlerException("Same file already exist in destination folder. Failed to move.");
			}
			logger.info("File from path : " + sourceFile.getAbsolutePath() + "  to path : "
					+ destinationFile.getAbsolutePath() + "  ---Moved successfully.");
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			//throw new FileHandlerException("Error while moving the file.");
		}
		return status;
	}

	@Override
	public boolean createFile(String mt199Message, String customerId, String fileName, String type)
			throws FileHandlerException {
		boolean status = false;
		try {
			Map<String, Map<String, SystemParameters>> allProperties = this.utils.loadSystemProperties();
			Map<String, SystemParameters> macPathProperties = (Map) allProperties.get("macPathMap");
			String sourcePath = this.systemParameterService.getSystemParametersDescription2("MT199_FIL_SRC",
					macPathProperties);

			if (type.equals("FIN")) {
				sourcePath = this.systemParameterService.getSystemParametersDescription2("MT199_FIN_SRC",
						macPathProperties);
			}
			
			//sourcePath = sourcePath + customerId;
			
			File sourceFolder = new File(sourcePath);
			if (!sourceFolder.exists()) {
				sourceFolder.mkdirs();
			}
			FileOutputStream fos = null;
			fos = new FileOutputStream(sourcePath  + fileName);
			fos.write(mt199Message.getBytes("UTF-8"));
			fos.close();
			status = true;
			logger.info("Location of mt199 file "+sourcePath  + fileName);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new FileHandlerException("Error while moving the file.");
		}
		return status;
	}

	@Override
	public String getFileExtension(File file) {
		String extension = "";
		try {
			extension = FilenameUtils.getExtension(file.getName());
		} catch (Exception e) {
			extension = "";
			logger.error("Error : " + e.getMessage(), e);
		}
		return extension;
	}

	@Override
	public String getFileNameWithoutExtension(File file) {
		String fileNameWithOutExt = "";
		try {
			fileNameWithOutExt = FilenameUtils.removeExtension(file.getName());
		} catch (Exception e) {
			fileNameWithOutExt = "";
			logger.error("Error : " + e.getMessage(), e);
		}
		return fileNameWithOutExt;
	}

	@Override
	public boolean isFileReadyToRead(File file) {
		try {
			if (!file.isFile()) {
				return false;
			}
			String fileName = getFileNameWithoutExtension(file);
			String direcotryPath = file.getParent();
			File histFile = new File(direcotryPath + "\\" + fileName + this.BK_FILE_EXT);
			if (histFile.exists()) {
				return true;
			}
		} catch (Exception e) {
			logger.error("Error :" + e.getMessage(), e);
		}

		return false;
	}

	@SuppressWarnings("unchecked")
	@Override
	public File[] sortFilesByCreationTime(File[] files) {
		try {
			Arrays.sort(files, new Comparator<File>() {
				@Override
				public int compare(File f1, File f2) {
					long lngFile1CreatedAt = getFileCreationTime(f1);
					long lngFile2CreatedAt = getFileCreationTime(f2);
					return Long.valueOf(lngFile1CreatedAt).compareTo(lngFile2CreatedAt);
				}

				private long getFileCreationTime(File file) {
					try {
						BasicFileAttributes attr = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
						return attr.creationTime().toInstant().toEpochMilli();
					} catch (IOException e) {
						throw new RuntimeException(file.getAbsolutePath(), e);
					}
				}

			});
		} catch (Exception e) {
			logger.error("Error in sorting file creation :" + e.getMessage(), e);
		}
		return files;
	}
}
