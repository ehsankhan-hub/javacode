package com.bsf.macug.util;

import java.io.File;

public class GenericExtFilter implements java.io.FilenameFilter {
	private String ext;

	public GenericExtFilter(String ext) {
		this.ext = ext;
	}

	public boolean accept(File dir, String name) {
		return name.endsWith(this.ext);
	}
}
