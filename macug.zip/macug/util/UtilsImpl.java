package com.bsf.macug.util;

import com.bsf.macug.application.mail.dto.MailServerDTO;
import com.bsf.macug.exception.SystemPropertyNotConfigurationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt101.dto.MacPaymentActivityLogDTO;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.processlog.InterMT100ProcessLogService;
import com.bsf.macug.mt101.service.InterPaymentService;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class UtilsImpl implements InterUtils {
	private static final Logger logger = Logger.getLogger(UtilsImpl.class.getName());

	@Autowired
	InterPaymentService paymentService;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterMT100ProcessLogService processLogService;

	private static volatile Map<String, Map<String, SystemParameters>> allSystemProperties;

	public String getTTReference(String sourceSystem) {
		Long sequence = this.paymentService.getSequence("MAC_TTREFERENCE_SEQ");
		DateFormat dfYear = new SimpleDateFormat("yy");
		String strSquence = null;
		if (sequence == null) {
			String millis = System.currentTimeMillis() + "";
			strSquence = sourceSystem + "TT" + millis.substring(7) + dfYear.format(new Date());
		} else {
			strSquence = sourceSystem
					+ appendCharacter(new StringBuilder().append(sequence).append("").toString(), 8, "L", "0")
					+ dfYear.format(new Date());
		}
		logger.info("(getTTReference) ==> UPS_B2B_TTREFERENCE_SEQ - ttref " + strSquence);
		return strSquence;
	}

	public String getFTSReference(String sourceSystem) {
		String strSquence = null;
		DateFormat dfYear = new SimpleDateFormat("yy");
		Long sequence = this.paymentService.getSequence("MAC_TRANS_REF_SEQ");
		if (sequence == null) {
			String millis = System.currentTimeMillis() + "";
			strSquence = sourceSystem + "" + millis.substring(6);
		} else {
			strSquence = appendCharacter(new StringBuilder().append(sequence).append("").toString(), 8, "L", "0")
					+ dfYear.format(new Date());
		}
		logger.info("(getTTReference) ==> UPS_B2B_FTSREFERENCE_SEQ - FTSReference " + strSquence);
		return strSquence;
	}

	public String getTransactionReference(int i) {
		String strSquence = null;
		DateFormat dfYear = new SimpleDateFormat("yy");
		Long sequence = this.paymentService.getSequence("MAC_TRANS_REF_SEQ");
		strSquence = appendCharacter(new StringBuilder().append(sequence).append("").toString(), 8, "L", "0")
				+ dfYear.format(new Date());
		logger.info("(getDynamicTransactionReferenceNumber) ==> UPS_B2B_FTSREFERENCE_SEQ for marking reference "
				+ strSquence);

		return strSquence;
	}

	public String getDynamicNarativeReferenceNumber(int i) {
		String strSquence = null;
		DateFormat dfYear = new SimpleDateFormat("yy");
		Long sequence = this.paymentService.getSequence("MAC_FUTURE_NARAT_REFERENCE");
		strSquence = "M" + appendCharacter(new StringBuilder().append(sequence).append("").toString(), 10, "L", "0")
				+ dfYear.format(new Date());
		logger.info(
				"(getDynamicTransactionReferenceNumber) ==> SEQ_FTS_FUTURE_NARAT_REFERENCE - sequence " + strSquence);

		return strSquence;
	}

	public String appendCharacter(String input, int length, String direction, String appender) {
		int spacesToAppend = length - input.length();

		StringBuilder spaces = new StringBuilder();
		for (int i = 0; i < spacesToAppend; i++) {
			spaces.append(appender);
		}

		if (direction.equalsIgnoreCase("R")) {
			input = input + spaces.toString();
		} else {
			input = spaces.toString() + input;
		}

		return input;
	}

	public String trimFromEnd(String data, int length) {
		if (StringUtils.isEmpty(data))
			return "";
		if (data.length() < length) {
			return data;
		}
		return data.substring(data.length() - length);
	}

	public String getPaymentType(MacPaymentDetail macPaymentDetail,
			Map<String, Map<String, SystemParameters>> allSystemProperties) {
		String beneficaryBank = macPaymentDetail.getAccountInstituion57();
		Map<String, SystemParameters> macPropertyMap = (Map) allSystemProperties.get("macPropertyMap");
		String propReciverCode = systemParameterService.getSystemParametersDescription1("UPSBNKCOD",
				macPropertyMap);
		String propReciverCode2 = systemParameterService.getSystemParametersDescription2("UPSBNKCOD",
				macPropertyMap);
		String paymentTypeAccountToAccount = systemParameterService.getSystemParametersDescription1("PMTTYPACC",
				macPropertyMap);

		String paymentTypeSarie = systemParameterService.getSystemParametersDescription1("PMTTYPSAR",
				macPropertyMap);
		String paymentTypeSwift = systemParameterService.getSystemParametersDescription1("PMTTYPSWF",
				macPropertyMap);

		if (StringUtils.isEmpty(beneficaryBank))
			return paymentTypeSwift;
		if (beneficaryBank.length() < 6) {
			return paymentTypeSwift;
		}
		String shorBenBank = beneficaryBank.substring(4, 6);
		if (beneficaryBank.equalsIgnoreCase(propReciverCode))
			return paymentTypeAccountToAccount;
		if (beneficaryBank.equalsIgnoreCase(propReciverCode2))
			return paymentTypeAccountToAccount;
		if ((shorBenBank.equals("SA")) && ("SAR".equals(macPaymentDetail.getCurrency()))) {
			return paymentTypeSarie;
		}
		return paymentTypeSwift;
	}

	public Map<String, Map<String, SystemParameters>> loadSystemProperties()
			throws SystemPropertyNotConfigurationException {
		if (allSystemProperties == null) {
			synchronized (UtilsImpl.class) {
				if (allSystemProperties == null) {
					logger.info("(loadAllProperties)==> Loading all properties ");
					Map<String, SystemParameters> countryCodeMaps = null;
					Map<String, SystemParameters> currencyCodeMaps = null;
					Map<String, SystemParameters> cuttoffTimeMap = null;
					Map<String, SystemParameters> accountTypeMap = null;
					Map<String, SystemParameters> accountStatusMap = null;
					Map<String, SystemParameters> tuxDetailMap = null;
					Map<String, SystemParameters> tuxErrorMap = null;
					Map<String, SystemParameters> washAccountMap = null;
					Map<String, SystemParameters> holidayListMap = null;
					Map<String, SystemParameters> errorCodeMap = null;
					Map<String, SystemParameters> exchangeRateMap = null;
					Map<String, SystemParameters> macPropertyMap = null;
					Map<String, SystemParameters> bicListMap = null;
					Map<String, SystemParameters> macPathMap = null;
					Map<String, SystemParameters> mailProperties = null;
					Map<String, SystemParameters> emailProperties = null;
					try {
						errorCodeMap = systemParameterService.getSystemParametersByTableCode("MACERRCOD");
						macPropertyMap = systemParameterService.getSystemParametersByTableCode("MACSERPRO");
						exchangeRateMap = systemParameterService.getSystemParametersByTableCode("EXCNGERTE");
						countryCodeMaps = systemParameterService.getSystemParametersByTableCode("CONTRCODE");
						currencyCodeMaps = systemParameterService.getSystemParametersByTableCode("CURCYCODE");
						cuttoffTimeMap = systemParameterService.getSystemParametersByTableCode("BNKCUTTIM");
						accountTypeMap = systemParameterService.getSystemParametersByTableCode("BNKACTYPE");
						accountStatusMap = systemParameterService.getSystemParametersByTableCode("BNKACSTAS");
						tuxDetailMap = systemParameterService.getSystemParametersByTableCode("BNKTUXDET");
						tuxErrorMap = systemParameterService.getSystemParametersByTableCode("TUXERCODE");
						washAccountMap = systemParameterService.getSystemParametersByTableCode("BNKWASACC");
						holidayListMap = systemParameterService.getSystemParametersByTableCode("BNKPUBHOL");
						bicListMap = systemParameterService.getSystemParametersByTableCode("BNKBICCOD");
						macPathMap = systemParameterService.getSystemParametersByTableCode("MACFLPATH");
						mailProperties = systemParameterService.getSystemParametersByTableCode("BNKSMTPSR");
						emailProperties = systemParameterService.getSystemParametersByTableCode("BNKSMTPEM");
						HashMap<String, Map<String, SystemParameters>> allProperties = new HashMap();
						allProperties.put("errorCodeMap", errorCodeMap);
						allProperties.put("exchangeRateMap", exchangeRateMap);
						allProperties.put("countryCodeMap", countryCodeMaps);
						allProperties.put("currencyCodeMap", currencyCodeMaps);
						allProperties.put("cuttoffTimeMap", cuttoffTimeMap);
						allProperties.put("accountTypeMap", accountTypeMap);
						allProperties.put("accountStatusMap", accountStatusMap);
						allProperties.put("tuxDetailMap", tuxDetailMap);
						allProperties.put("tuxErrorMap", tuxErrorMap);
						allProperties.put("washAccountMap", washAccountMap);
						allProperties.put("holidayListMap", holidayListMap);
						allProperties.put("macPropertyMap", macPropertyMap);
						allProperties.put("macPathMap", macPathMap);
						allProperties.put("mailProperties", mailProperties);
						allProperties.put("emailProperties", emailProperties);

						logger.info("(loadAllProperties)==> Checking for property from system general parameters");

						if (countryCodeMaps == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  CONTRCODE ,not configured properly");
						}
						if (currencyCodeMaps == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  CURCYCODE ,not configured properly");
						}
						if (macPropertyMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  MACSERPRO ,not configured properly");
						}
						if (cuttoffTimeMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKCUTTIM ,not configured properly");
						}
						if (accountTypeMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKACTYPE ,not configured properly");
						}
						if (accountStatusMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKACSTAS ,not configured properly");
						}
						if (tuxDetailMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKTUXDET ,not configured properly");
						}
						if (tuxErrorMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  TUXERCODE ,not configured properly");
						}
						if (washAccountMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKWASACC ,not configured properly");
						}
						if (bicListMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKBICCOD ,not configured properly");
						}
						if (holidayListMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKPUBHOL ,not configured properly");
						}
						if (errorCodeMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  MACERRCOD ,not configured properly");
						}
						if (exchangeRateMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  EXCNGERTE ,not configured properly");
						}
						if (macPathMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  MACFLPATH ,not configured properly");
						}
						if (mailProperties == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKSMTPSR ,not configured properly");
						}
						if (emailProperties == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKSMTPEM ,not configured properly");
						}
						allSystemProperties = allProperties;
						logger.info("(loadAllProperties)==> All properties are loaded suucessfully...");
					} catch (SystemPropertyNotConfigurationException e) {
						logger.info("(loadAllProperties)==> Error occured while loading system general property");
						throw e;
					}

				}
			}
		}
		return allSystemProperties;
	}

	public MailServerDTO getMailDTO() {
		MailServerDTO dto = null;
		try {
			Map<String, Map<String, SystemParameters>> allProperties = loadSystemProperties();
			Map<String, SystemParameters> mailProperties = (Map) allProperties.get("mailProperties");
			Map<String, SystemParameters> emails = (Map) allProperties.get("emailProperties");

			String host = systemParameterService.getSystemParametersDescription1("HOST", mailProperties);
			String port = systemParameterService.getSystemParametersDescription1("PORT", mailProperties);
			String sender = systemParameterService.getSystemParametersDescription1("SENDER", mailProperties);
			String messageFlag = systemParameterService.getSystemParametersDescription1("MLSNDFLG",
					mailProperties);

			String messageSubject = systemParameterService.getSystemParametersDescription1("MLFUTSUB",
					mailProperties);

			if ((!StringUtils.isEmpty(messageFlag)) && (messageFlag.equals("Y"))) {
				if ((emails != null) && (emails.keySet().size() > 0)) {
					dto = new MailServerDTO();
					dto.setMailHost(host);
					dto.setMailPort(Integer.valueOf(Integer.parseInt(port)));
					dto.setMailFrom(sender);
					dto.setMailSubject(messageSubject);
					Set<String> emailList = getListOfEmails(emails);
					Set<String> ccList = new HashSet();
					int i = 0;
					for (String email : emailList) {
						if (i == 0) {
							dto.setMailTo(email);
						} else {
							ccList.add(email);
						}
						i++;
					}
					dto.setMailCC(ccList);
				} else {
					logger.info("No email list found in table code BNKSMTPEM ");
				}
			} else {
				logger.info("Mail send flag MLSNDFLG is set to : " + messageFlag + " , in tale code BNKSMTPSR.");
			}
		} catch (SystemPropertyNotConfigurationException e) {
			dto = null;
			logger.error("Error :" + e.getMessage(), e);
		} catch (Exception e) {
			dto = null;
			logger.error("Error :" + e.getMessage(), e);
		}
		return dto;
	}

	private Set<String> getListOfEmails(Map<String, SystemParameters> emails) {
		Set<String> emailList = new HashSet();
		Set<String> keys = emails.keySet();
		for (String key : keys) {
			String email = systemParameterService.getSystemParametersDescription1(key, emails);
			emailList.add(email);
		}
		return emailList;
	}

	@Override
	public String removeStealinkCharacter(byte[] message) throws IOException {
		int character = 0;
		InputStream messageInputStream = new ByteArrayInputStream(message);
		StringBuffer swiftMessageBuffer = new StringBuffer();
		while ((character = messageInputStream.read()) != -1) {
			if (character == 0x2) {
				swiftMessageBuffer = new StringBuffer();
			} else if (character == 0x3) {
				logger.info("Not adding this chracter...");
			} else {
				swiftMessageBuffer.append((char) character);
			}
		}
		String data = swiftMessageBuffer.toString();
		data = data.trim();
		return data;
	}

	/**
	 * This method will log MT100 process activity to MAC_PAYMENT_PROCESSLOG table
	 * 
	 * @param subject
	 * @param description
	 * @param finOrFileAct
	 * @param fileName
	 * @return true or false
	 */
	@Override
	public boolean logMT100Activity(String custName,String subject, String description, String finOrFileAct, String fileName,Integer staus) {
		boolean blStatus = false;
		MacPaymentActivityLogDTO activityLogDTO = null;
		File actuatFileName=new File(fileName);
		try {
			activityLogDTO = new MacPaymentActivityLogDTO();
			activityLogDTO.setCustomerId(custName);
			activityLogDTO.setProcessSubject(subject);
			activityLogDTO.setProcessDescription(description);
			activityLogDTO.setProcessType(finOrFileAct);
			activityLogDTO.setProcessFileName(fileName);
			activityLogDTO.setResponseFileValue("DWNLDGTW.RESULT");
			activityLogDTO.setProcessStatus(staus);
			activityLogDTO.setCustReqFile(actuatFileName.getName());
			blStatus = processLogService.saveMT100PaymentActivityLog(activityLogDTO);
			logger.info("MT100 activity log details saved status is " + blStatus);
		} catch (Exception e) {
			logger.error("Error in logging MT100 process information to DB " + e.getMessage(), e);
		}
		return blStatus;
	}
}
