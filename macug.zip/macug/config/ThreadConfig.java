package com.bsf.macug.config;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.util.InterUtils;

@Configuration
public class ThreadConfig {

	private static final Logger logger = Logger.getLogger(ThreadConfig.class);

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterUtils utils;

	@Bean
	public TaskExecutor threadPoolTaskExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		try {
			Map<String, Map<String, SystemParameters>> allProperties = utils.loadSystemProperties();
			Map<String, SystemParameters> macProperties = allProperties.get("macPropertyMap");
             //200 size
			BigDecimal bgPoolMaxValue = systemParameterService.getSystemParametersValue1("MACTHRDPOOL", macProperties);
			BigDecimal bgQueueMaxValue = systemParameterService.getSystemParametersValue1("MACTHRDQUE", macProperties);
			
			if(bgPoolMaxValue==null)
				bgPoolMaxValue=BigDecimal.valueOf(300);	
			if(bgQueueMaxValue==null)
				bgQueueMaxValue=BigDecimal.valueOf(600);	
			
			executor.setCorePoolSize(bgPoolMaxValue.intValue());
			executor.setMaxPoolSize(bgPoolMaxValue.intValue());
			executor.setQueueCapacity(bgQueueMaxValue.intValue());
			executor.setThreadNamePrefix("macug_payment_thread");
			executor.setWaitForTasksToCompleteOnShutdown(true);
			executor.initialize();
			logger.info("Payment pool initailzed with maximum size  " + executor.getMaxPoolSize()
					+ " and capacity set as " + bgQueueMaxValue + " core size is " + bgPoolMaxValue.intValue());
		} catch (Exception e) {
			logger.error("Failed to inialize payment thread pool. Error " + e.getMessage(), e);
		}
		return executor;
	}
}