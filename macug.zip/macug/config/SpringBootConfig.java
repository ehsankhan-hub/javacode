package com.bsf.macug.config;

import com.bsf.macug.mt101.service.InterMT101Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({ "com.bsf.macug" })
public class SpringBootConfig implements CommandLineRunner {
	@Autowired
	InterMT101Service paymentService;

	public static void main(String[] args) throws Exception {
		SpringApplication.run(SpringBootConfig.class, args);
	}
     
	public void run(String... arg0) throws Exception {
		this.paymentService.processFile();
	}
}