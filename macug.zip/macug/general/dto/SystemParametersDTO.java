package com.bsf.macug.general.dto;

import java.math.BigDecimal;
import java.util.Date;

public class SystemParametersDTO {
	private String tableCode;
	private String itemCode;
	private String itemDescription1;
	private String itemDescription2;
	private BigDecimal itemValue1;
	private BigDecimal itemValue2;
	private String createdUser;
	private Date createdDate;
	private Date modifiedDate;

	public String getTableCode() {
		return tableCode;
	}

	public void setTableCode(String tableCode) {
		this.tableCode = tableCode;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemDescription1() {
		return itemDescription1;
	}

	public void setItemDescription1(String itemDescription1) {
		this.itemDescription1 = itemDescription1;
	}

	public String getItemDescription2() {
		return itemDescription2;
	}

	public void setItemDescription2(String itemDescription2) {
		this.itemDescription2 = itemDescription2;
	}

	public BigDecimal getItemValue1() {
		return itemValue1;
	}

	public void setItemValue1(BigDecimal itemValue1) {
		this.itemValue1 = itemValue1;
	}

	public BigDecimal getItemValue2() {
		return itemValue2;
	}

	public void setItemValue2(BigDecimal itemValue2) {
		this.itemValue2 = itemValue2;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

}
