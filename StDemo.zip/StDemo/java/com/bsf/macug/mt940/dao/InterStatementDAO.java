package com.bsf.macug.mt940.dao;

import java.util.Date;
import java.util.List;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.mt940.entity.CustomerAccounts;
import com.bsf.macug.mt940.entity.MacStatmentReport;
import com.bsf.macug.mt940.entity.StatementHeader;

public interface InterStatementDAO {

	StatementHeader fetchHeaderInformation(String account, String bicCode, String valueDate) throws DataAccessException;

	List<Object[]> fetchDetailInformation(String account, String bicCode, String fromDate, String toDate)
			throws DataAccessException;

	List<Object[]> fetchStatementForOneAccountRange(String clientID, String accountNumber, String fromDate,
			String toDate) throws DataAccessException;

	List<Object[]> fetchStatementForAllAccountOneDay(String clientID, String fromDate) throws DataAccessException;

	MacStatmentReport getStatmentReport(String custId, String accountNumber, Date valueDate);

	boolean saveStatmentReport(MacStatmentReport report);

	boolean updateStatmentReport(MacStatmentReport report);

	CustomerAccounts getCustomerAccountDetails(String customerId, String accountNumber, String accountService);

	List<CustomerAccounts> getAllAccountsForMT940Generation();
}
