package com.bsf.macug.mt940.dao;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.mt940.entity.CustomerAccounts;
import com.bsf.macug.mt940.entity.MacStatmentReport;
import com.bsf.macug.mt940.entity.StatementHeader;

@Repository
public class StatementDAOImpl implements InterStatementDAO {

	private static final Logger logger = Logger.getLogger(StatementDAOImpl.class.getName());

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public StatementHeader fetchHeaderInformation(String account, String bicCode, String valueDate)
			throws DataAccessException {
		StatementHeader header = null;
		Session session = null;
		logger.info("(fetchHeaderInformation)==> Getting header statement for account " + account + " BIC code "
				+ bicCode + " value date " + valueDate);
		if (!(StringUtils.isEmpty(account) && StringUtils.isEmpty(bicCode) && StringUtils.isEmpty(valueDate))) {
			try {
				session = sessionFactory.getCurrentSession();
				StringBuilder sbHeaderQuery = new StringBuilder("FROM StatementHeader h where ");
				sbHeaderQuery.append("h.headerID.accountNumber='");
				sbHeaderQuery.append(account);
				sbHeaderQuery.append("' and h.headerID.bicCode='");
				sbHeaderQuery.append(bicCode);
				sbHeaderQuery.append("' and h.headerID.valueDate='");
				sbHeaderQuery.append(valueDate);
				sbHeaderQuery.append("'");
				logger.info("(fetchHeaderInformation)==> Header query is " + sbHeaderQuery.toString());
				Query qryHeader = session.createQuery(sbHeaderQuery.toString());
				List<StatementHeader> lstHeader = qryHeader.list();
				// header = (StatementHeader)qryHeader.uniqueResult();
				if (lstHeader != null) {
					if (lstHeader.size() > 0)
						header = lstHeader.get(0);
				} else {
					logger.info("(fetchHeaderInformation)==> Header data not present for account date");
				}
			} catch (Exception e) {
				logger.error(
						"(fetchHeaderInformation)==> Error occured while parsing statement. Error " + e.getMessage(),
						e);
				throw new DataAccessException("No header information found");
			}
		} else {
			logger.info("(fetchHeaderInformation)==> Search parameter cannot be null or empty");
		}
		return header;
	}

	@Override
	public List<Object[]> fetchDetailInformation(String account, String bicCode, String fromDate, String toDate)
			throws DataAccessException {
		List<Object[]> lstObjArrStatementDetails = null;
		Session session = null;
		logger.info("(fetchDetailInformation)==> Getting detail information for account " + account + " BIC " + bicCode
				+ " from " + fromDate + " to " + toDate);
		try {
			session = sessionFactory.getCurrentSession();
			StringBuilder sbDetails = new StringBuilder(
					"SELECT D.* FROM MAC_STATEMENT_DETAILS D INNER JOIN MAC_STATEMENT_HEAD H ON H.STM_KEY = D.STM_KEY ");
			sbDetails.append("WHERE H.ACC_NUMBER='");
			sbDetails.append(account);
			sbDetails.append("' AND H.BIC_CODE='");
			sbDetails.append(bicCode);
			sbDetails.append("' AND H.STMTH_VALUEDATE BETWEEN '");
			sbDetails.append(fromDate);
			sbDetails.append("' AND '");
			sbDetails.append(toDate);
			sbDetails.append("'");
			logger.info("(fetchDetailInformation)==> Detail query is " + sbDetails.toString());
			// Query qryDetails = session.createQuery(sbDetails.toString());
			Query qryDetails = session.createSQLQuery(sbDetails.toString());
			// Object[] objResults = qryDetails.list();
			lstObjArrStatementDetails = qryDetails.list();
			if (lstObjArrStatementDetails != null) {
				logger.info("(fetchDetailInformation)==> Total details found is " + lstObjArrStatementDetails.size());
			}
		} catch (Exception e) {
			throw new DataAccessException("No detail information found");
		}
		return lstObjArrStatementDetails;
	}

	@Override
	public List<Object[]> fetchStatementForOneAccountRange(String clientID, String accountNumber, String fromDate,
			String toDate) throws DataAccessException {
		Session session = null;
		List<Object[]> lstStatements = null;
		logger.info("(fetchStatementForOneAccountRange)==> Fetching statement for one account range");
		if (!StringUtils.isEmpty(clientID)) {
			if (!StringUtils.isEmpty(accountNumber)) {
				if (!StringUtils.isEmpty(fromDate)) {
					if (!StringUtils.isEmpty(toDate)) {
						StringBuilder queryBuilder = new StringBuilder();
						queryBuilder.append(
								"SELECT STMH_TRNREFNO,H.ACC_NUMBER,STMH_RELREFNO,STMH_MSGTYPE ,STMH_SENDERCODE,STMH_OPENBAL60_TYPE,STMH_OPENBAL60F_MARK,STMH_OPENBAL60F_VALDATE,STMH_OPENBAL60F_CUR,STMH_OPENBAL60F_AMT,STMH_CLOSEBAL62_TYPE,STMH_CLOSEBAL62F_MARK,STMH_CLOSEBAL62F_VALDATE,STMH_CLOSEBAL62F_CUR,STMH_CLOSEBAL62F_AMT,STMH_AVALBAL64_MARK,STMH_AVALBAL64_VALDATE,STMH_AVALBAL64_CUR,STMH_AVALBAL64_AMT,STMH_AVALBAL65_MARK,STMH_AVALBAL65_VALDATE,STMH_AVALBAL65_CUR,STMH_AVALBAL65_AMT,STMTD_VALUEDATE,STMTD_ENTRYDATE,STMTD_MARK,STMTD_FUNDCODE,STMTD_AMT,STMTD_TRAN_TYPECODE,STMTD_ACC_OWNERREF,STMTD_ACCSERV_INSTREF,STMTD_SUPP_DETAILS,STMTD_ACC_86OWNERINFO,d.client_trn_ref, d.source ");
						queryBuilder
								.append(" FROM MAC_STATEMENT_HEAD H  , MAC_STATEMENT_DETAILS D, MAC_V_CUST_ACCOUNTS A");
						queryBuilder.append(" WHERE");
						queryBuilder.append(" A.CUST_ID = '" + clientID + "' AND ");
						queryBuilder.append(" A.ACC_NUMBER = RPAD ('" + accountNumber + "',35)");
						/*queryBuilder.append(" AND H.STM_KEY  BETWEEN  ACC_KEY || ");
						queryBuilder.append(" UTL_RAW.CAST_TO_RAW ( '" + fromDate + "')   AND ACC_KEY ||");
						queryBuilder.append(" UTL_RAW.CAST_TO_RAW ( '" + toDate + "')");*/
						queryBuilder.append(" AND H.STM_KEY = D.STM_KEY ORDER BY D.STM_KEY , PAGE_SEQUENCE");
						try {
							logger.info("(fetchStatementForOneAccountRange)==> Query is " + queryBuilder.toString());
							session = sessionFactory.getCurrentSession();
							Query qryDetails = session.createSQLQuery(queryBuilder.toString());
							lstStatements = qryDetails.list();
							if (lstStatements != null) {
								logger.info("(fetchStatementForOneAccountRange)==> Result list size is "
										+ lstStatements.size());
							} else {
								logger.info("(fetchStatementForOneAccountRange)==> Result list is null or empty");
							}
						} catch (Exception e) {
							logger.error("(fetchStatementForOneAccountRange)==> Error is " + e.getMessage(), e);
							throw new DataAccessException();
						}
					} else {
						logger.info("(fetchStatementForOneAccountRange)==> To date is null or empty");
					}
				} else {
					logger.info("(fetchStatementForOneAccountRange)==> From date is null or empty");
				}
			} else {
				logger.info("(fetchStatementForOneAccountRange)==> AccountNumber is null or empty");
			}
		} else {
			logger.info("(fetchStatementForOneAccountRange)==> ClientId is null or empty");
		}
		return lstStatements;
	}

	@Override
	public List<Object[]> fetchStatementForAllAccountOneDay(String clientID, String fromDate)
			throws DataAccessException {
		Session session = null;
		List<Object[]> lstStatements = null;
		logger.info("(fetchStatementForAllAccountOneDay)==> Fetch all acoount one day");
		if (StringUtils.isEmpty(clientID)) {
			if (StringUtils.isEmpty(fromDate)) {
				try {
					StringBuilder queryBuilder = new StringBuilder();
					queryBuilder
							.append("SELECT STMH_TRNREFNO ,H.ACC_NUMBER,STMH_RELREFNO ,STMH_MSGTYPE ,STMH_SENDERCODE "
									+ ",STMH_OPENBAL60_TYPE ,STMH_OPENBAL60F_MARK ,STMH_OPENBAL60F_VALDATE "
									+ ",STMH_OPENBAL60F_CUR ,STMH_OPENBAL60F_AMT ,STMH_CLOSEBAL62_TYPE"
									+ " ,STMH_CLOSEBAL62F_MARK ,STMH_CLOSEBAL62F_VALDATE ,STMH_CLOSEBAL62F_CUR"
									+ " ,STMH_CLOSEBAL62F_AMT ,STMH_AVALBAL64_MARK ,STMH_AVALBAL64_VALDATE ,"
									+ "STMH_AVALBAL64_CUR ,STMH_AVALBAL64_AMT ,STMH_AVALBAL65_MARK ,STMH_AVALBAL65_VALDATE"
									+ " ,STMH_AVALBAL65_CUR ,STMH_AVALBAL65_AMT, STMTD_VALUEDATE ,STMTD_ENTRYDATE ,STMTD_MARK ,STMTD_FUNDCODE"
									+ " ,STMTD_AMT ,STMTD_TRAN_TYPECODE ,STMTD_ACC_OWNERREF ,STMTD_ACCSERV_INSTREF,STMTD_SUPP_DETAILS"
									+ " ,STMTD_ACC_86OWNERINFO FROM MAC_STATEMENT_HEAD H , MAC_STATEMENT_DETAILS D ,"
									+ " MAC_V_CUST_ACCOUNTS A ");
					queryBuilder.append(" WHERE A.CUST_ID = '" + clientID + "'");
					queryBuilder.append(" AND H.STM_KEY = ACC_KEY || ");
					queryBuilder.append(" UTL_RAW.CAST_TO_RAW ( '" + fromDate + "') ");
					queryBuilder.append(" AND H.STM_KEY = D.STM_KEY ORDER BY D.STM_KEY ");
					logger.info("(fetchStatementForAllAccountOneDay)==>  Query is " + queryBuilder.toString());
					Query qryDetails = session.createSQLQuery(queryBuilder.toString());
					lstStatements = qryDetails.list();

					if (lstStatements != null) {
						logger.info("(fetchStatementForAllAccountOneDay)==> fetched count is " + lstStatements.size());
					} else {
						logger.info("(fetchStatementForAllAccountOneDay)==> fetched count is 0");
					}

				} catch (Exception e) {
					logger.error("(fetchStatementForAllAccountOneDay)==> Error : " + e.getMessage(), e);
				}
			} else {
				logger.info("(fetchStatementForAllAccountOneDay)==> Date is null or empty");
			}
		} else {
			logger.info("(fetchStatementForAllAccountOneDay)==> Client ID is null or empty");
		}

		return lstStatements;
	}

	@Override
	public MacStatmentReport getStatmentReport(String custId, String accountNumber, Date valueDate) {
		MacStatmentReport report = null;
		try {
			Session currentSession = sessionFactory.getCurrentSession();
			Criteria criteria = currentSession.createCriteria(MacStatmentReport.class);
			criteria.add(Restrictions.eq("customerId", custId));
			criteria.add(Restrictions.eq("accountNumber", accountNumber));
			criteria.add(Restrictions.eq("valueDate", valueDate));
			report = (MacStatmentReport) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return report;
	}

	@Override
	public boolean saveStatmentReport(MacStatmentReport report) {
		boolean status = false;
		try {
			Session currentSession = sessionFactory.getCurrentSession();
			currentSession.save(report);
			status = true;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public boolean updateStatmentReport(MacStatmentReport report) {
		boolean status = false;
		try {
			Session currentSession = sessionFactory.getCurrentSession();
			currentSession.update(report);
			status = true;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public CustomerAccounts getCustomerAccountDetails(String customerId, String accountNumber, String accountService) {

		CustomerAccounts accounts = null;
		Session session = null;
		if (!(StringUtils.isEmpty(customerId) && StringUtils.isEmpty(accountNumber)
				&& StringUtils.isEmpty(accountService))) {
			try {
				session = sessionFactory.getCurrentSession();
				Criteria criteria = session.createCriteria(CustomerAccounts.class);
				criteria.add(Restrictions.eq("customerId", customerId));
				criteria.add(Restrictions.eq("accountNumber", accountNumber));
				criteria.add(Restrictions.eq("accountService", accountService));
				criteria.add(Restrictions.eq("accountStatus", "ACTIVE"));
				accounts = (CustomerAccounts) criteria.uniqueResult();
			} catch (Exception e) {
				logger.error("(getCustomerAccountDetails)==> Error in getting account " + e.getMessage(), e);
			}
		} else {
			logger.info("(getCustomerAccountDetails)==> Search information is null or empty");
		}

		return accounts;
	}

	@Override
	public List<CustomerAccounts> getAllAccountsForMT940Generation() {
		List<CustomerAccounts> list = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(CustomerAccounts.class);
			criteria.add(Restrictions.eq("accountService", "STATEMENT"));
			criteria.add(Restrictions.eq("accountStatus", "ACTIVE"));
			criteria.add(Restrictions.eq("mt940generateFlag", 1));
			list = criteria.list();
		} catch (Exception e) {
			logger.error("(getAllAccountsForMT940Generation)==> Error in getting account list " + e.getMessage(), e);
		}
		return list;
	}
}
