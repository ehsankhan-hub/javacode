package com.bsf.macug.mt940.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "MAC_STATEMENT_DETAILS")
public class StatementDetails implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "B2BSTMTDETID")
	////@TableGenerator(name="book_generator", table="id_generator", schema="bookstore")
	@TableGenerator(name = "B2BSTMTDETID", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "B2BSTMT_DETAILSID", valueColumnName = "ID_VALUE")
	@Column(name = "STMTD_SEQ")
	private Integer sequence;
	@Column(name = "STM_KEY")
	private byte[] statementKey;
	@Temporal(TemporalType.DATE)
	@Column(name = "STMTD_VALUEDATE")
	private Date detailValuedate;
	@Temporal(TemporalType.DATE)
	@Column(name = "STMTD_ENTRYDATE")
	private Date detailEntrydate;
	@Column(name = "STMTD_MARK", length = 2)
	private String detailMark;
	@Column(name = "STMTD_FUNDCODE", length = 1)
	private String detailFundCode;
	@Column(name = "STMTD_AMT", length = 16)
	private String detailAmount;
	@Column(name = "STMTD_TRAN_TYPECODE", length = 10)
	private String detailTransTypeCode;
	@Column(name = "STMTD_ACC_OWNERREF", length = 16)
	private String detailOwnerReference;
	@Column(name = "STMTD_ACCSERV_INSTREF", length = 20)
	private String detailServingInstutionReference;
	@Column(name = "STMTD_SUPP_DETAILS", length = 34)
	private String detailSupplierDetails;
	@Column(name = "STMTD_ACC_86OWNERINFO", length = 130)
	private String detailOwnerInformation;
	@Transient
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATED_DATE")
	private Date createdDate;

	public StatementDetails() {
	}

	public StatementDetails(Integer sequence, byte[] statementKey,
			Date detailValuedate, Date detailEntrydate, String detailMark,
			String detailFundCode, String detailAmount,
			String detailTransTypeCode, String detailOwnerReference,
			String detailServingInstutionReference,
			String detailSupplierDetails, String detailOwnerInformation,
			Date createdDate) {
		super();
		this.sequence = sequence;
		this.statementKey = statementKey;
		this.detailValuedate = detailValuedate;
		this.detailEntrydate = detailEntrydate;
		this.detailMark = detailMark;
		this.detailFundCode = detailFundCode;
		this.detailAmount = detailAmount;
		this.detailTransTypeCode = detailTransTypeCode;
		this.detailOwnerReference = detailOwnerReference;
		this.detailServingInstutionReference = detailServingInstutionReference;
		this.detailSupplierDetails = detailSupplierDetails;
		this.detailOwnerInformation = detailOwnerInformation;
		this.createdDate = createdDate;
	}

	public Integer getSequence() {
		return sequence;
	}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}

	public byte[] getStatementKey() {
		return statementKey;
	}

	public void setStatementKey(byte[] statementKey) {
		this.statementKey = statementKey;
	}

	public Date getDetailValuedate() {
		return detailValuedate;
	}

	public void setDetailValuedate(Date detailValuedate) {
		this.detailValuedate = detailValuedate;
	}

	public Date getDetailEntrydate() {
		return detailEntrydate;
	}

	public void setDetailEntrydate(Date detailEntrydate) {
		this.detailEntrydate = detailEntrydate;
	}

	public String getDetailMark() {
		return detailMark;
	}

	public void setDetailMark(String detailMark) {
		this.detailMark = detailMark;
	}

	public String getDetailFundCode() {
		return detailFundCode;
	}

	public void setDetailFundCode(String detailFundCode) {
		this.detailFundCode = detailFundCode;
	}

	public String getDetailAmount() {
		return detailAmount;
	}

	public void setDetailAmount(String detailAmount) {
		this.detailAmount = detailAmount;
	}

	public String getDetailTransTypeCode() {
		return detailTransTypeCode;
	}

	public void setDetailTransTypeCode(String detailTransTypeCode) {
		this.detailTransTypeCode = detailTransTypeCode;
	}

	public String getDetailOwnerReference() {
		return detailOwnerReference;
	}

	public void setDetailOwnerReference(String detailOwnerReference) {
		this.detailOwnerReference = detailOwnerReference;
	}

	public String getDetailServingInstutionReference() {
		return detailServingInstutionReference;
	}

	public void setDetailServingInstutionReference(
			String detailServingInstutionReference) {
		this.detailServingInstutionReference = detailServingInstutionReference;
	}

	public String getDetailSupplierDetails() {
		return detailSupplierDetails;
	}

	public void setDetailSupplierDetails(String detailSupplierDetails) {
		this.detailSupplierDetails = detailSupplierDetails;
	}

	public String getDetailOwnerInformation() {
		return detailOwnerInformation;
	}

	public void setDetailOwnerInformation(String detailOwnerInformation) {
		this.detailOwnerInformation = detailOwnerInformation;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
