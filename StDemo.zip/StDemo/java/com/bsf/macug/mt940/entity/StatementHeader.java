package com.bsf.macug.mt940.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "MAC_STATEMENT_HEAD")
public class StatementHeader implements Serializable {

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "accountNumber", column = @Column(name = "ACC_NUMBER", nullable = false, length = 35)),
			@AttributeOverride(name = "valueDate", column = @Column(name = "STMTH_VALUEDATE", nullable = false, length = 8)),
			@AttributeOverride(name = "bicCode", column = @Column(name = "BIC_CODE", nullable = false, length = 11)) })
	private StatementHeaderID headerID;
	@Column(name = "STM_KEY")
	private byte[] statementKey;
	@Column(name = "STMH_TRNREFNO", length = 16)
	private String transactionRefernce;
	@Column(name = "STMH_RELREFNO", length = 16)
	private String relatedReference;
	@Column(name = "STMH_STATEMENTNO")
	private Integer statementNo;
	@Column(name = "STMH_SEQUENCENO")
	private Integer statementSequence;
	@Column(name = "STMH_MSGTYPE", length = 3)
	private String messageType;
	@Column(name = "STMH_SENDERCODE", length = 12)
	private String senderCode;
	@Column(name = "STMH_RECEIVERCODE", length = 12)
	private String receiverCode;
	@Column(name = "STMH_OPENBAL60_TYPE", length = 1)
	private String openBalanceType;
	@Column(name = "STMH_OPENBAL60F_MARK", length = 1)
	private String openBalanceMark;
	@Temporal(TemporalType.DATE)
	@Column(name = "STMH_OPENBAL60F_VALDATE")
	private Date openBalanceValueDate;
	@Column(name = "STMH_OPENBAL60F_CUR", length = 3)
	private String openBalanceCurrency;
	@Column(name = "STMH_OPENBAL60F_AMT", length = 16)
	private String openBalanceAmount;
	@Column(name = "STMH_CLOSEBAL62_TYPE", length = 1)
	private String closeBalanceType;
	@Column(name = "STMH_CLOSEBAL62F_MARK", length = 1)
	private String closeBalanceMark;
	@Temporal(TemporalType.DATE)
	@Column(name = "STMH_CLOSEBAL62F_VALDATE")
	private Date closeBalanceValueDate;
	@Column(name = "STMH_CLOSEBAL62F_CUR", length = 3)
	private String closeBalanceCurrency;
	@Column(name = "STMH_CLOSEBAL62F_AMT", length = 16)
	private String closeBalanceAmount;
	@Column(name = "STMH_AVALBAL64_MARK", length = 1)
	private String fundBalanceMark;
	@Temporal(TemporalType.DATE)
	@Column(name = "STMH_AVALBAL64_VALDATE")
	private Date fundBalanceValueDate;
	@Column(name = "STMH_AVALBAL64_CUR", length = 3)
	private String fundBalanceCurrency;
	@Column(name = "STMH_AVALBAL64_AMT", length = 16)
	private String fundBalanceAmount;
	@Column(name = "STMH_AVALBAL65_MARK", length = 1)
	private String forwardBalanceMark;
	@Temporal(TemporalType.DATE)
	@Column(name = "STMH_AVALBAL65_VALDATE")
	private Date forwardBalanceValueDate;
	@Column(name = "STMH_AVALBAL65_CUR", length = 3)
	private String forwardBalanceCurrency;
	@Column(name = "STMH_AVALBAL65_AMT", length = 16)
	private String forwardBalanceAmount;
	@Transient
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATED_DATE", nullable = false)
	private Date createdDate;

	public StatementHeader() {
	}

	public StatementHeader(StatementHeaderID headerID, byte[] statementKey,
			String transactionRefernce, String relatedReference,
			Integer statementNo, Integer statementSequence, String messageType,
			String senderCode, String receiverCode, String openBalanceType,
			String openBalanceMark, Date openBalanceValueDate,
			String openBalanceCurrency, String openBalanceAmount,
			String closeBalanceType, String closeBalanceMark,
			Date closeBalanceValueDate, String closeBalanceCurrency,
			String closeBalanceAmount, String fundBalanceMark,
			Date fundBalanceValueDate, String fundBalanceCurrency,
			String fundBalanceAmount, String forwardBalanceMark,
			Date forwardBalanceValueDate, String forwardBalanceCurrency,
			String forwardBalanceAmount, Date createdDate) {
		super();
		this.headerID = headerID;
		this.statementKey = statementKey;
		this.transactionRefernce = transactionRefernce;
		this.relatedReference = relatedReference;
		this.statementNo = statementNo;
		this.statementSequence = statementSequence;
		this.messageType = messageType;
		this.senderCode = senderCode;
		this.receiverCode = receiverCode;
		this.openBalanceType = openBalanceType;
		this.openBalanceMark = openBalanceMark;
		this.openBalanceValueDate = openBalanceValueDate;
		this.openBalanceCurrency = openBalanceCurrency;
		this.openBalanceAmount = openBalanceAmount;
		this.closeBalanceType = closeBalanceType;
		this.closeBalanceMark = closeBalanceMark;
		this.closeBalanceValueDate = closeBalanceValueDate;
		this.closeBalanceCurrency = closeBalanceCurrency;
		this.closeBalanceAmount = closeBalanceAmount;
		this.fundBalanceMark = fundBalanceMark;
		this.fundBalanceValueDate = fundBalanceValueDate;
		this.fundBalanceCurrency = fundBalanceCurrency;
		this.fundBalanceAmount = fundBalanceAmount;
		this.forwardBalanceMark = forwardBalanceMark;
		this.forwardBalanceValueDate = forwardBalanceValueDate;
		this.forwardBalanceCurrency = forwardBalanceCurrency;
		this.forwardBalanceAmount = forwardBalanceAmount;
		this.createdDate = createdDate;
	}

	public StatementHeaderID getHeaderID() {
		return headerID;
	}

	public void setHeaderID(StatementHeaderID headerID) {
		this.headerID = headerID;
	}

	public byte[] getStatementKey() {
		return statementKey;
	}

	public void setStatementKey(byte[] statementKey) {
		this.statementKey = statementKey;
	}

	public String getTransactionRefernce() {
		return transactionRefernce;
	}

	public void setTransactionRefernce(String transactionRefernce) {
		this.transactionRefernce = transactionRefernce;
	}

	public String getRelatedReference() {
		return relatedReference;
	}

	public void setRelatedReference(String relatedReference) {
		this.relatedReference = relatedReference;
	}

	public Integer getStatementNo() {
		return statementNo;
	}

	public void setStatementNo(Integer statementNo) {
		this.statementNo = statementNo;
	}

	public Integer getStatementSequence() {
		return statementSequence;
	}

	public void setStatementSequence(Integer statementSequence) {
		this.statementSequence = statementSequence;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getSenderCode() {
		return senderCode;
	}

	public void setSenderCode(String senderCode) {
		this.senderCode = senderCode;
	}

	public String getReceiverCode() {
		return receiverCode;
	}

	public void setReceiverCode(String receiverCode) {
		this.receiverCode = receiverCode;
	}

	public String getOpenBalanceType() {
		return openBalanceType;
	}

	public void setOpenBalanceType(String openBalanceType) {
		this.openBalanceType = openBalanceType;
	}

	public String getOpenBalanceMark() {
		return openBalanceMark;
	}

	public void setOpenBalanceMark(String openBalanceMark) {
		this.openBalanceMark = openBalanceMark;
	}

	public Date getOpenBalanceValueDate() {
		return openBalanceValueDate;
	}

	public void setOpenBalanceValueDate(Date openBalanceValueDate) {
		this.openBalanceValueDate = openBalanceValueDate;
	}

	public String getOpenBalanceCurrency() {
		return openBalanceCurrency;
	}

	public void setOpenBalanceCurrency(String openBalanceCurrency) {
		this.openBalanceCurrency = openBalanceCurrency;
	}

	public String getOpenBalanceAmount() {
		return openBalanceAmount;
	}

	public void setOpenBalanceAmount(String openBalanceAmount) {
		this.openBalanceAmount = openBalanceAmount;
	}

	public String getCloseBalanceType() {
		return closeBalanceType;
	}

	public void setCloseBalanceType(String closeBalanceType) {
		this.closeBalanceType = closeBalanceType;
	}

	public String getCloseBalanceMark() {
		return closeBalanceMark;
	}

	public void setCloseBalanceMark(String closeBalanceMark) {
		this.closeBalanceMark = closeBalanceMark;
	}

	public Date getCloseBalanceValueDate() {
		return closeBalanceValueDate;
	}

	public void setCloseBalanceValueDate(Date closeBalanceValueDate) {
		this.closeBalanceValueDate = closeBalanceValueDate;
	}

	public String getCloseBalanceCurrency() {
		return closeBalanceCurrency;
	}

	public void setCloseBalanceCurrency(String closeBalanceCurrency) {
		this.closeBalanceCurrency = closeBalanceCurrency;
	}

	public String getCloseBalanceAmount() {
		return closeBalanceAmount;
	}

	public void setCloseBalanceAmount(String closeBalanceAmount) {
		this.closeBalanceAmount = closeBalanceAmount;
	}

	public String getFundBalanceMark() {
		return fundBalanceMark;
	}

	public void setFundBalanceMark(String fundBalanceMark) {
		this.fundBalanceMark = fundBalanceMark;
	}

	public Date getFundBalanceValueDate() {
		return fundBalanceValueDate;
	}

	public void setFundBalanceValueDate(Date fundBalanceValueDate) {
		this.fundBalanceValueDate = fundBalanceValueDate;
	}

	public String getFundBalanceCurrency() {
		return fundBalanceCurrency;
	}

	public void setFundBalanceCurrency(String fundBalanceCurrency) {
		this.fundBalanceCurrency = fundBalanceCurrency;
	}

	public String getFundBalanceAmount() {
		return fundBalanceAmount;
	}

	public void setFundBalanceAmount(String fundBalanceAmount) {
		this.fundBalanceAmount = fundBalanceAmount;
	}

	public String getForwardBalanceMark() {
		return forwardBalanceMark;
	}

	public void setForwardBalanceMark(String forwardBalanceMark) {
		this.forwardBalanceMark = forwardBalanceMark;
	}

	public Date getForwardBalanceValueDate() {
		return forwardBalanceValueDate;
	}

	public void setForwardBalanceValueDate(Date forwardBalanceValueDate) {
		this.forwardBalanceValueDate = forwardBalanceValueDate;
	}

	public String getForwardBalanceCurrency() {
		return forwardBalanceCurrency;
	}

	public void setForwardBalanceCurrency(String forwardBalanceCurrency) {
		this.forwardBalanceCurrency = forwardBalanceCurrency;
	}

	public String getForwardBalanceAmount() {
		return forwardBalanceAmount;
	}

	public void setForwardBalanceAmount(String forwardBalanceAmount) {
		this.forwardBalanceAmount = forwardBalanceAmount;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
