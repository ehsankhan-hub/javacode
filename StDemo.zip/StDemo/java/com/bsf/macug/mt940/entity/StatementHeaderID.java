package com.bsf.macug.mt940.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Embeddable
public class StatementHeaderID implements Serializable {

	@Column(name = "ACC_NUMBER", nullable = false, length = 35)
	private String accountNumber;
	@Column(name = "STMTH_VALUEDATE", nullable = false)
	private String valueDate;
	@Column(name = "BIC_CODE", nullable = false, length = 11)
	private String bicCode;

	public StatementHeaderID() {
	}

	public StatementHeaderID(String accountNumber, String valueDate,
			String bicCode) {
		super();
		this.accountNumber = accountNumber;
		this.valueDate = valueDate;
		this.bicCode = bicCode;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getValueDate() {
		return valueDate;
	}

	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}

	public String getBicCode() {
		return bicCode;
	}

	public void setBicCode(String bicCode) {
		this.bicCode = bicCode;
	}

}
