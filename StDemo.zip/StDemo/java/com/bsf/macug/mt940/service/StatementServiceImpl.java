package com.bsf.macug.mt940.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.mt940.dao.InterStatementDAO;
import com.bsf.macug.mt940.dao.StatementDAOImpl;
import com.bsf.macug.mt940.entity.CustomerAccounts;
import com.bsf.macug.mt940.entity.MacStatmentReport;
import com.bsf.macug.mt940.entity.StatementHeader;

@Transactional
@Service
public class StatementServiceImpl implements InterStatmentService {
	private static final Logger logger = Logger.getLogger(StatementServiceImpl.class.getName());

	@Autowired
	InterStatementDAO statementDAO;

	@Override
	public StatementHeader fetchHeaderInformation(String account, String bicCode, String valueDate)
			throws DataAccessException {
		StatementHeader header = null;
		try {
			header = statementDAO.fetchHeaderInformation(account, bicCode, valueDate);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return header;
	}

	@Override
	public List<Object[]> fetchDetailInformation(String account, String bicCode, String fromDate, String toDate)
			throws DataAccessException {
		List<Object[]> detailsInfo = null;
		try {
			detailsInfo = statementDAO.fetchDetailInformation(account, bicCode, fromDate, toDate);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detailsInfo;
	}

	@Override
	public List<Object[]> fetchStatementForOneAccountRange(String clientID, String accountNumber, String fromDate,
			String toDate) throws DataAccessException {
		List<Object[]> detailsInfo = null;
		try {
			detailsInfo = statementDAO.fetchStatementForOneAccountRange(clientID, accountNumber, fromDate, toDate);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detailsInfo;
	}

	@Override
	public List<Object[]> fetchStatementForAllAccountOneDay(String clientID, String fromDate)
			throws DataAccessException {
		List<Object[]> detailsInfo = null;
		try {
			detailsInfo = statementDAO.fetchStatementForAllAccountOneDay(clientID, fromDate);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detailsInfo;
	}

	@Override
	public MacStatmentReport getStatmentReport(String custId, String accountNumber, Date valueDate) {
		MacStatmentReport header = null;
		try {
			header = statementDAO.getStatmentReport(custId, accountNumber, valueDate);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return header;
	}

	@Override
	public boolean saveStatmentReport(MacStatmentReport report) {
		boolean status = false;
		try {
			status = statementDAO.saveStatmentReport(report);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public boolean updateStatmentReport(MacStatmentReport report) {
		boolean status = false;
		try {
			status = statementDAO.updateStatmentReport(report);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public CustomerAccounts getCustomerAccountDetails(String customerId, String accountNumber, String accountService) {
		CustomerAccounts header = null;
		try {
			header = statementDAO.getCustomerAccountDetails(customerId, accountNumber, accountService);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return header;
	}

	@Override
	public List<CustomerAccounts> getAllAccountsForMT940Generation() {
		List<CustomerAccounts> list = new ArrayList<>();
		try {
			list = statementDAO.getAllAccountsForMT940Generation();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return list;
	}

}
