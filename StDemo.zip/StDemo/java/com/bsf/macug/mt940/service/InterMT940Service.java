package com.bsf.macug.mt940.service;

import java.util.Date;

public interface InterMT940Service {
	void process(Date valueDate);
}
