package com.bsf.macug.mt940.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt940.entity.CustomerAccounts;
import com.bsf.macug.mt940.thread.MT940Generator;

@Service
public class MT940ServiceImpl implements InterMT940Service {
	private static final Logger logger = Logger.getLogger(MT940ServiceImpl.class.getName());

	@Autowired
	InterStatmentService statmentService;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	TaskExecutor taskExecutor;

	@Autowired
	private ApplicationContext applicationContext;

	@Override
	public void process(Date valueDate) {
		try {
			if (valueDate == null) {
				logger.info("Value date is null. Setting value date to d-1");
				valueDate = yesterday();
			}

			if (!validateValueDate(valueDate)) {
				logger.warn("Invalid value date exiting the job.");
				return;
			}
			DateFormat format = new SimpleDateFormat("yyyyMMdd");
			String strValueDate = format.format(valueDate);
			List<CustomerAccounts> accounts = statmentService.getAllAccountsForMT940Generation();
			for (CustomerAccounts account : accounts) {
				MT940Generator validationHandler = applicationContext.getBean(MT940Generator.class);
				validationHandler.setAccountNumber(account);
				validationHandler.setValeDate(strValueDate);
				taskExecutor.execute(validationHandler);
			}

			ThreadPoolTaskExecutor taskExecutorPool = (ThreadPoolTaskExecutor) taskExecutor;

			for (;;) {
				int count = taskExecutorPool.getActiveCount();
				logger.info("Active Threads : " + count);
				try {
					Thread.sleep(15000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if (count == 0) {
					taskExecutorPool.shutdown();
					break;
				}
			}
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
	}

	private boolean validateValueDate(Date valueDate) {
		boolean status = false;
		try {
			if (valueDate == null) {
				status = false;
			}

			Calendar date = new GregorianCalendar();
			// reset hour, minutes, seconds and millis
			date.set(Calendar.HOUR_OF_DAY, 0);
			date.set(Calendar.MINUTE, 0);
			date.set(Calendar.SECOND, 0);
			date.set(Calendar.MILLISECOND, 0);
			Date today = date.getTime();

			if (valueDate.before(today)) {
				status = true;
			} else {
				status = false;
			}
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			status = false;
		}
		return status;
	}

	private Date yesterday() {
		try {
			final Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -1);
			Date yesterday = cal.getTime();
			DateFormat format = new SimpleDateFormat("yyyyMMdd");
			String strDate = format.format(yesterday);
			yesterday = format.parse(strDate);
			return yesterday;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			return null;
		}

	}
}
