package com.bsf.macug.mt940.thread;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.hibernate.type.descriptor.java.BigIntegerTypeDescriptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.mt940.entity.CustomerAccounts;
import com.bsf.macug.mt940.entity.MacStatmentReport;
import com.bsf.macug.mt940.entity.StatementHeader;
import com.bsf.macug.mt940.service.InterStatmentService;
import com.bsf.macug.util.InterFileUtils;
import com.bsf.macug.util.InterUtils;
import com.prowidesoftware.swift.model.field.Field20;
import com.prowidesoftware.swift.model.field.Field25;
import com.prowidesoftware.swift.model.field.Field28C;
import com.prowidesoftware.swift.model.field.Field60F;
import com.prowidesoftware.swift.model.field.Field60M;
import com.prowidesoftware.swift.model.field.Field61;
import com.prowidesoftware.swift.model.field.Field62F;
import com.prowidesoftware.swift.model.field.Field62M;
import com.prowidesoftware.swift.model.field.Field86;
import com.prowidesoftware.swift.model.mt.mt9xx.MT940;

@Component
@Scope("prototype")
public class MT940Generator implements Runnable {
	private static final Logger logger = Logger.getLogger(MT940Generator.class.getName());

	@Autowired
	InterStatmentService statmentService;

	@Autowired
	InterFileUtils fileUtils;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterUtils utils;

	@Override
	public void run() {
		logger.info("MT940 generation initiating for account number : " + account);
		try {
			saveReport();
			String accountNumber = account.getAccountNumber();
			String customerId = account.getCustomerId();
			logger.info("accountNumber---"+accountNumber);
			StatementHeader headerDetails = statmentService.fetchHeaderInformation(accountNumber, "BSFRSARIXXX",
					valeDate);
			if (headerDetails == null) {
				logger.error("HEader not ready for date : " + valeDate + " and account : " + accountNumber);
				return;
			}
			List<Object[]> statmentDataList = statmentService.fetchStatementForOneAccountRange(customerId,
					accountNumber, valeDate, valeDate);

			Map<String, Map<String, SystemParameters>> allProperties = utils.loadSystemProperties();
			Map<String, SystemParameters> macPropertyMap = allProperties.get("macPropertyMap");
			BigDecimal max = systemParameterService.getSystemParametersValue1("MT940MAXLEN", macPropertyMap);
			processForMultipleFiles(headerDetails, statmentDataList, 0, max.intValue());

		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
	}

	private void processForMultipleFiles(StatementHeader headerDetails, List<Object[]> statmentDataList, int index,
			int maxLines) {
		try {
			if ((statmentDataList.size() - (index * maxLines)) <= maxLines) {
				List<Object[]> newStatementDetailsList = statmentDataList.subList(index * maxLines,
						statmentDataList.size());
				prepareInduvidualFile(headerDetails, newStatementDetailsList, index, -1);
			} else {
				int newIndex = index + 1;

				List<Object[]> newStatementDetailsList = statmentDataList.subList(index * maxLines,
						((index * maxLines) + maxLines));
				String closingAmount = prepareInduvidualFile(headerDetails, newStatementDetailsList, index, index);
				StatementHeader newHeaderDetails = new StatementHeader();
				Object[] openingData = statmentDataList.get((index * maxLines));
				newHeaderDetails.setOpenBalanceAmount(closingAmount);
				if (openingData[8] != null) {
					String currency = (String) openingData[8];
					newHeaderDetails.setOpenBalanceCurrency(currency);
				}

				processForMultipleFiles(newHeaderDetails, statmentDataList, newIndex, maxLines);
			}
		} catch (

		Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
	}

	private String prepareInduvidualFile(StatementHeader headerDetails, List<Object[]> statmentDataList, int index,
			int firstOrLast) {
		String closingAmount = "";
		String pattern = "ddMMyyyyHHmmss";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        String sequence = simpleDateFormat.format(new Date());
		try {
			String accountNumber = account.getAccountNumber();
			String customerId = account.getCustomerId();
			MT940 mt940 = new MT940();
			mt940.setReceiver(customerId);
			mt940.setSender("BSFRSARIXXX");

			Field20 field20 = new Field20();
			field20.setReference(sequence);
			Field25 field25 = new Field25();
			field25.setAccount(accountNumber);

			Field28C field28c = new Field28C();
			field28c.setSequenceNumber(0);
			field28c.setStatementNumber(index);

			mt940.addField(field20);
			mt940.addField(field25);
			mt940.addField(field28c);

			String strOpneing = "";
			if (index == 0) {
				Field60F field60F = getField60F(headerDetails);
				mt940.addField(field60F);
				strOpneing = field60F.getAmount();
			} else {
				Field60M field60M = getField60M(headerDetails);
				mt940.addField(field60M);
				strOpneing = field60M.getAmount();
			}

			if (statmentDataList != null) {				
				BigDecimal totalAmount = new BigDecimal(strOpneing.replace(",", "."));
				for (Object[] statmentData : statmentDataList) {
					Field61 field61 = prepareField61(statmentData);
					Field86 field86 = prepareField86(statmentData);
					mt940.addField(field61);
					mt940.addField(field86);
					if (field61.getDCMark().equalsIgnoreCase("c")) {
						totalAmount = totalAmount.add(new BigDecimal(field61.getAmountAsNumber().doubleValue()));
					} else {
						totalAmount = totalAmount.subtract(new BigDecimal(field61.getAmountAsNumber().doubleValue()));
					}

				}

				closingAmount = totalAmount.toString().replace(".", ",");
			}

			
			
			
			if (firstOrLast == -1) {
				Field62F field62f = prepare62F(statmentDataList.get(statmentDataList.size() - 1), closingAmount);
				mt940.addField(field62f);
			} else  {
				Field62M field62M = getField62M(statmentDataList.get(statmentDataList.size() - 1), closingAmount);
				mt940.addField(field62M);
			}
			

			String mt940MEssage = mt940.message();
			mt940MEssage = mt940MEssage.replaceAll("(?!\r\n|\n)([^\\x20-\\x7e])", "");

			DateFormat dateFormatter = new SimpleDateFormat("yyyyMMdd");
			Date valDt = dateFormatter.parse(valeDate);
			dateFormatter = new SimpleDateFormat("yyMMdd");

			String date = dateFormatter.format(valDt);

			//String fileName = "E940_SCH_" + date + "_" + customerId + "_" + accountNumber + "_" + index + ".dat";
			String fileName = "MAC940P_" + customerId + "_" + date + "_" +accountNumber +"_"+ index + ".dat";
			fileUtils.createFile(mt940MEssage, customerId, fileName);

		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}

		return closingAmount;
	}

	private Field62M getField62M(Object[] objStatement, String closingAmount) throws ParseException {
		String debitCreditMark = "";
		String date = "";
		String currency = "";

		if (objStatement[13] != null) {
			currency = (String) objStatement[13];
		}

		DateFormat dateFormatter = new SimpleDateFormat("yyyyMMdd");
		Date valDt = dateFormatter.parse(valeDate);
		dateFormatter = new SimpleDateFormat("yyMMdd");

		date = dateFormatter.format(valDt);

		Field62M field62f = new Field62M();
		field62f.setDCMark(debitCreditMark);
		field62f.setDate(date);
		field62f.setCurrency(currency);
		field62f.setAmount(closingAmount);

		if (!StringUtils.isEmpty(closingAmount) && closingAmount.startsWith("-")) {
			field62f.setDCMark("D");
		} else {
			field62f.setDCMark("C");
		}

		return field62f;
	}

	private Field60M getField60M(StatementHeader headerDetails) throws ParseException {
		if (headerDetails == null) {
			return null;
		}
		String date = null;
		String currency = null;
		String amount = "";

		if (headerDetails.getOpenBalanceAmount() != null) {
			amount = headerDetails.getOpenBalanceAmount();
		}

		if (headerDetails.getOpenBalanceCurrency() != null) {
			currency = headerDetails.getOpenBalanceCurrency();
		}

		DateFormat dateFormatter = new SimpleDateFormat("yyyyMMdd");
		Date valDt = dateFormatter.parse(valeDate);
		dateFormatter = new SimpleDateFormat("yyMMdd");

		String strValueDate = dateFormatter.format(valDt);

		Field60M field60f = new Field60M();

		field60f.setDate(strValueDate);
		field60f.setCurrency(currency);
		field60f.setAmount(amount);

		if (!StringUtils.isEmpty(amount) && amount.startsWith("-")) {
			field60f.setDCMark("D");
		} else {
			field60f.setDCMark("C");
		}

		return field60f;
	}

	private Field62F prepare62F(Object[] objStatement, String closingAmount) throws ParseException {
		String debitCreditMark = "";
		String date = "";
		String currency = "";

		if (objStatement[13] != null) {
			currency = (String) objStatement[13];
		}

		DateFormat dateFormatter = new SimpleDateFormat("yyyyMMdd");
		Date valDt = dateFormatter.parse(valeDate);
		dateFormatter = new SimpleDateFormat("yyMMdd");

		date = dateFormatter.format(valDt);

		Field62F field62f = new Field62F();
		field62f.setDCMark(debitCreditMark);
		field62f.setDate(date);
		field62f.setCurrency(currency);
		field62f.setAmount(closingAmount);

		if (!StringUtils.isEmpty(closingAmount) && closingAmount.startsWith("-")) {
			field62f.setDCMark("D");
		} else {
			field62f.setDCMark("C");
		}

		return field62f;
	}

	private Field86 prepareField86(Object[] statmentData) {
		Field86 field86 = new Field86();

		String strOwnnRef = (String) statmentData[32];
		if (strOwnnRef.length() <= 35) {
			field86.setNarrativeLine1(strOwnnRef);
			field86.setNarrativeLine2("");
			field86.setNarrativeLine3("");
			field86.setNarrativeLine4("");
			field86.setNarrativeLine5("");
			field86.setNarrativeLine6("");
		} else if (strOwnnRef.length() > 35 && strOwnnRef.length() <= 70) {
			field86.setNarrativeLine1(strOwnnRef.substring(0, 35));
			field86.setNarrativeLine2(strOwnnRef.substring(35));
			field86.setNarrativeLine3("");
			field86.setNarrativeLine4("");
			field86.setNarrativeLine5("");
			field86.setNarrativeLine6("");
		} else if (strOwnnRef.length() > 70 && strOwnnRef.length() <= 105) {
			field86.setNarrativeLine1(strOwnnRef.substring(0, 35));
			field86.setNarrativeLine2(strOwnnRef.substring(35, 70));
			field86.setNarrativeLine3(strOwnnRef.substring(70));
			field86.setNarrativeLine4("");
			field86.setNarrativeLine5("");
			field86.setNarrativeLine6("");
		} else if (strOwnnRef.length() > 105 && strOwnnRef.length() <= 140) {
			field86.setNarrativeLine1(strOwnnRef.substring(0, 35));
			field86.setNarrativeLine2(strOwnnRef.substring(35, 70));
			field86.setNarrativeLine3(strOwnnRef.substring(70, 105));
			field86.setNarrativeLine4(strOwnnRef.substring(105));
			field86.setNarrativeLine5("");
			field86.setNarrativeLine6("");
		} else if (strOwnnRef.length() > 140 && strOwnnRef.length() <= 175) {
			field86.setNarrativeLine1(strOwnnRef.substring(0, 35));
			field86.setNarrativeLine2(strOwnnRef.substring(35, 70));
			field86.setNarrativeLine3(strOwnnRef.substring(70, 105));
			field86.setNarrativeLine4(strOwnnRef.substring(105, 140));
			field86.setNarrativeLine5(strOwnnRef.substring(140));
			field86.setNarrativeLine6("");
		} else if (strOwnnRef.length() > 175) {
			field86.setNarrativeLine1(strOwnnRef.substring(0, 35));
			field86.setNarrativeLine2(strOwnnRef.substring(35, 70));
			field86.setNarrativeLine3(strOwnnRef.substring(70, 105));
			field86.setNarrativeLine4(strOwnnRef.substring(105, 140));
			field86.setNarrativeLine5(strOwnnRef.substring(140, 175));
			field86.setNarrativeLine6(strOwnnRef.substring(175));
		}

		return field86;
	}

	private Field61 prepareField61(Object[] statmentData) throws ParseException {
		Field61 field61 = new Field61();
		DateFormat dateFormatter = new SimpleDateFormat("yyyyMMdd");
		Date valDt = dateFormatter.parse(valeDate);
		dateFormatter = new SimpleDateFormat("yyMMdd");

		String date = dateFormatter.format(valDt);

		String amount = "";
		if (statmentData[27] != null) {
			amount = (String) statmentData[27];
		}

		if (statmentData[23] != null) {
			Date dtTransDate = (Date) statmentData[23];
			if (dtTransDate != null) {
				DateFormat dfOpenDate = new SimpleDateFormat("yyMMdd");
				String strTransDate = dfOpenDate.format(dtTransDate);
				field61.setValueDate(strTransDate);
			}
		}

		if (statmentData[24] != null) {
			Date dtEntryDate = (Date) statmentData[24];
			if (dtEntryDate != null) {
				DateFormat dfOpenDate = new SimpleDateFormat("yyMMdd");
				String strTransDate = dfOpenDate.format(dtEntryDate);
				field61.setEntryDate(strTransDate);
			}

		}
		if (!StringUtils.isEmpty(amount) && amount.startsWith("-")) {
			field61.setDCMark("D");
		} else {
			field61.setDCMark("C");
		}

		/*if (statmentData[28] != null) {
			String strTransMark = (String) statmentData[28];
			field61.setFundsCode(strTransMark.trim());
		}*/

		field61.setAmount(amount);
		if (statmentData[28] != null) {
			String strTransMark = (String) statmentData[28];
			field61.setTransactionType(strTransMark.trim());
		}

		field61.setIdentificationCode("");

		if (statmentData[33] != null) {
			String clientTransactionReference = (String) statmentData[33];
			field61.setReferenceForTheAccountOwner(clientTransactionReference);

		} else {
			field61.setReferenceForTheAccountOwner("NONREF");
		}

		if (statmentData[30] != null) {
			String strTransOwnRef = (String) statmentData[30];
			field61.setReferenceForTheAccountOwner(strTransOwnRef);

		}
		if (statmentData[31] != null) {
			String strTransInstRef = (String) statmentData[31];
			field61.setReferenceOfTheAccountServicingInstitution(strTransInstRef);
		}

		field61.setSupplementaryDetails("");

		return field61;
	}

	private Field60F getField60F(StatementHeader headerDetails) throws ParseException {
		if (headerDetails == null) {
			return null;
		}
		String date = null;
		String currency = null;
		String amount = "";

		if (headerDetails.getOpenBalanceAmount() != null) {
			amount = headerDetails.getOpenBalanceAmount();
		}

		if (headerDetails.getOpenBalanceCurrency() != null) {
			currency = headerDetails.getOpenBalanceCurrency();
		}

		DateFormat dateFormatter = new SimpleDateFormat("yyyyMMdd");
		Date valDt = dateFormatter.parse(valeDate);
		dateFormatter = new SimpleDateFormat("yyMMdd");

		String strValueDate = dateFormatter.format(valDt);

		Field60F field60f = new Field60F();

		field60f.setDate(strValueDate);
		field60f.setCurrency(currency);
		field60f.setAmount(amount);

		if (!StringUtils.isEmpty(amount) && amount.startsWith("-")) {
			field60f.setDCMark("D");
		} else {
			field60f.setDCMark("C");
		}

		return field60f;
	}

	private void saveReport() {
		MacStatmentReport report = new MacStatmentReport();
		UUID guid = java.util.UUID.randomUUID();
		report.setId(guid.toString());
		report.setAccountNumber(account.getAccountNumber());
		report.setCustomerId(account.getCustomerId());
		report.setStatus("INIT");
		report.setCreatedBy("SYSTEM");
		report.setCreatedDate(new Timestamp(new Date().getTime()));
		statmentService.saveStatmentReport(report);
	}

	private CustomerAccounts account;
	private String valeDate;

	public void setAccountNumber(CustomerAccounts account) {
		this.account = account;
	}

	public void setValeDate(String valeDate) {
		this.valeDate = valeDate;
	}

}
