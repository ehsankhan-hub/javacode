package com.bsf.macug.config;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.bsf.macug.mt940.service.InterMT940Service;

/**
 * Created by Prosant.
 */
@SpringBootApplication
@ComponentScan("com.bsf.macug")
public class SpringBootConfig implements CommandLineRunner {
		
	private static final Logger logger = Logger.getLogger(SpringBootConfig.class.getName());

	@Autowired
	InterMT940Service mT940Service;
	
    public static void main(String[] args) throws Exception {
        SpringApplication.run(SpringBootConfig.class, args);           
    }

	@Override
	public void run(String... arg0) throws Exception {
		Date valueDate = null;
		if(arg0.length < 1) {
			logger.info("No arguments specified specified.");
		}else if(arg0.length > 2) {
			logger.error("Program exiting. As arguments not specified properly.");
			return;
		}else if(arg0.length == 2){
			String value = arg0[0];
			
			if(!value.equalsIgnoreCase("-d")) {
				logger.error("Program exiting. First parametr must be -d");
				return;
			}
			String strValueDate = arg0[1];
			valueDate = checkValidFormat(strValueDate);
			if(valueDate == null) {
				logger.error("Program exiting. Value date must be in format yyyy-MM-dd");
				return;
			}
		}
		
		mT940Service.process(valueDate);
	}

	private Date checkValidFormat(String strValueDate) {
		Date valueDate = null;
		try {
			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			valueDate = formatter.parse(strValueDate);
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
			valueDate = null;
		}
		return valueDate;
	}
}