package com.bsf.macug.util;

import java.util.Map;

import com.bsf.macug.exception.SystemPropertyNotConfigurationException;
import com.bsf.macug.general.entity.SystemParameters;

public interface InterUtils {
	String appendCharacter(String input, int length, String direction, String appender);

	String trimFromEnd(String data, int length);

	Map<String, Map<String, SystemParameters>> loadSystemProperties() throws SystemPropertyNotConfigurationException;

}
