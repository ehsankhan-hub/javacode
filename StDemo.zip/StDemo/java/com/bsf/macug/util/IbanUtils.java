package com.bsf.macug.util;

import java.math.BigInteger;

import org.springframework.util.StringUtils;

public class IbanUtils {

	private static final BigInteger BD_97 = new BigInteger("97");
	private static final BigInteger BD_98 = new BigInteger("98");
	
	/** 
	 * Generates IBAN from Bank code, Country code and Account number
	 * 55 , 000000000 123456789 , SA Would result in IBAN SA7055000000000123456789
	 * @param bankCode
	 * @param accNumber
	 * @param countryCode
	 * @return
	 */
	public static String genIBAN(String bankCode,String accNumber, String countryCode) {
		
		// IBAN = COUNTRY_CODE  +  CHECKSUM  +  BANK_CODE +  ACCOUNT
		//      =     SA        +   00..99   +  00..99    +  7-ZEROS +  11-DIGIT
		//      =     SA        +     71     +    56      +  0000000 +  23428288927
		
		if(isValidSaudiIBAN(accNumber))
			return accNumber;
		
		String ibanStr = "";
		// left pad Account number with Zeros in case account number is less than 18
		if(accNumber.length() <18) {
			//accNumber = StringUtils.leftPad( removeNonAlpha(accNumber), 18, '0'); by prosant
		}

		//Build sIban to get Checksum.
		String sIban = bankCode+ accNumber; // 55000000000123456789

		// Build ibanStr after getting checksum
	    ibanStr = ((countryCode != null) ? countryCode.toUpperCase():"") + getChecksum(sIban, countryCode) + sIban;
	    return ibanStr; // SA7055000000000123456789
	}
	
	
	/**
	 * Verify if iban provided is valid for SA
	 * @param ibanStr
	 * @return
	 */
	public static boolean isValidSaudiIBAN(String ibanStr) {
		
		//Check IBAN length
		if(StringUtils.isEmpty(ibanStr)){
			return false;
		}if (ibanStr.length() <24){
			return false;
		}
		else { // Verify the checksum
			return (getChecksum(ibanStr, null) == 97);
		}
	}
	  
	
	/** 
	 * Generates checkSum 
	 * 55000000000123456789  and SA Would result in 70
	 * @param sIban
	 * @param countryCode
	 * @return int checkSum of 2 digits 
	 */

	public static int getChecksum(String sIban, String countryCode) {
		
		String ibanStr = "";
		String sLCCS = "";
		String sIbanMixed = "";
		String sIbanDigits = "";
		char ch; 
		int checkSum;
		String skipChars = " .-_,/";
		
		// Build sLCCS and sIbanMixed
		if (countryCode != null && countryCode.length()>0)  {
			sLCCS = countryCode + "00"; 
			sIbanMixed = sIban + sLCCS.toUpperCase();
		}
		else {
			sLCCS = sIban.substring(0, 4); 
			sIbanMixed = sIban.substring(4, sIban.length())  + sLCCS.toUpperCase();
		}
		// sLCCS= SA00 , sIbanMixed= 55000000000123456789SA00
		
		//Build sIbanDigits
	    for (int i = 0; i < sIbanMixed.length(); i++) {
	    	ch = sIbanMixed.charAt(i);
	    	
	    	if (Character.isDigit(ch)) {
	    		sIbanDigits = sIbanDigits + ch;
	    	}
	    	else if (skipChars.indexOf(ch) != -1) {
	    		
	    	}
	    	else if(ch <65 || ch >90 ) {
	    		checkSum = -1;
	    		return checkSum;
	    	}
	    	else {
	    		sIbanDigits = sIbanDigits + (ch - 55);
	    	}
	    	
		}
	    // final sIbanDigits =  55000000000123456789281000
	    
	    int largeModulous = modulo97(sIbanDigits); // Large Modulo of 97
	    checkSum = 98- largeModulous; // Checksum
	    return checkSum; // 70
	}
	
	/** Return Modulo 97
	 * @param bban
	 * @return
	 */
	public static int modulo97(String bban) {
		BigInteger b = new BigInteger(bban);
		b = b.divideAndRemainder(BD_97)[1];
		b = BD_98.min(b);
		b = b.divideAndRemainder(BD_97)[1];
		
		 //result of ((int)(98 - (Long.parseLong(bban) * 100) % 97L)) % 97;
		return b.intValue();
       
	}
	
	/**
	 * Remove non alpha characters
	 * @param iban
	 * @return the resulting IBAN
	 */
	public static String removeNonAlpha(final String iban) {
		final StringBuffer result = new StringBuffer();
		for (int i=0;i<iban.length();i++) {
			char c = iban.charAt(i);
			if (Character.isLetter(c) || Character.isDigit(c) ) {
				result.append((char)c);
			}
		}
		return result.toString();
	}
	
	
/**
 * Method to get CPT number from account number or from IBAN 
 * @param customerAccountNo
 * @return
 */
	public static String getCustomerCPTFromAccount(String customerAccountNo){
		String cptNumber=null;
		// If passes account number
		if(customerAccountNo!=null){
			int acctLength = customerAccountNo.length();
			if(acctLength == 11){
				cptNumber= customerAccountNo.substring(0, 6);	
			}
			// get last 11 digits then first 6
			else if( (acctLength > 11) && (acctLength < 24) )
			{
				int startIndex = acctLength - 11;
				cptNumber = customerAccountNo.substring(startIndex, startIndex + 6);
			}
			// if passing valid IBAN
			else if(acctLength == 24){
				cptNumber=customerAccountNo.substring(13,19);
			}
			else if(acctLength == 6){
				cptNumber=customerAccountNo;
			}
		}
		return cptNumber;
	}
}
