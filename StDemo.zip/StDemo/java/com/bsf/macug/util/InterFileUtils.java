package com.bsf.macug.util;

import java.io.File;

import com.bsf.macug.exception.FileHandlerException;

public interface InterFileUtils {
	byte[] readFile(String path) throws FileHandlerException;

	boolean moveFile(File sourceFile, File destinationFile, String type) throws FileHandlerException;

	String getFileExtension(File file);

	String getFileNameWithoutExtension(File file);

	boolean isFileReadyToRead(File file);

	boolean createFile(String mt940Message, String customerId, String fileName) throws FileHandlerException;
}
