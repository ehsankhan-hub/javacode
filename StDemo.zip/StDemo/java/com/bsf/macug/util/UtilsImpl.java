package com.bsf.macug.util;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bsf.macug.exception.SystemPropertyNotConfigurationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;

@Service
public class UtilsImpl implements InterUtils {

	private static final Logger logger = Logger.getLogger(UtilsImpl.class.getName());


	@Autowired
	InterSystemParameterService systemParameterService;

	private volatile static Map<String, Map<String, SystemParameters>> allSystemProperties;

	

	@Override
	public String appendCharacter(String input, int length, String direction, String appender) {
		int spacesToAppend = length - input.length();

		StringBuilder spaces = new StringBuilder();
		for (int i = 0; i < spacesToAppend; i++) {
			spaces.append(appender);
		}

		if (direction.equalsIgnoreCase("R")) {
			input = input + spaces.toString();
		} else {
			input = spaces.toString() + input;
		}

		return input;
	}

	@Override
	public String trimFromEnd(String data, int length) {
		if (StringUtils.isEmpty(data)) {
			return "";
		} else if (data.length() < length) {
			return data;
		} else {
			return data.substring(data.length() - length);
		}
	}

	

	@Override
	public Map<String, Map<String, SystemParameters>> loadSystemProperties()
			throws SystemPropertyNotConfigurationException {
		if (allSystemProperties == null) {
			synchronized (UtilsImpl.class) {
				if (allSystemProperties == null) {
					logger.info("(loadAllProperties)==> Loading all properties ");
					Map<String, SystemParameters> countryCodeMaps = null;
					Map<String, SystemParameters> currencyCodeMaps = null;
					Map<String, SystemParameters> cuttoffTimeMap = null;
					Map<String, SystemParameters> accountTypeMap = null;
					Map<String, SystemParameters> accountStatusMap = null;
					Map<String, SystemParameters> tuxDetailMap = null;
					Map<String, SystemParameters> tuxErrorMap = null;
					Map<String, SystemParameters> washAccountMap = null;
					Map<String, SystemParameters> holidayListMap = null;
					Map<String, SystemParameters> errorCodeMap = null;
					Map<String, SystemParameters> exchangeRateMap = null;
					Map<String, SystemParameters> macPropertyMap = null;
					Map<String, SystemParameters> bicListMap = null;
					Map<String, SystemParameters> macPathMap = null;
					Map<String, SystemParameters> mailProperties = null;
					Map<String, SystemParameters> emailProperties = null;
					HashMap<String, Map<String, SystemParameters>> allProperties;
					try {
						errorCodeMap = systemParameterService.getSystemParametersByTableCode("MACERRCOD");
						macPropertyMap = systemParameterService.getSystemParametersByTableCode("MACSERPRO");
						exchangeRateMap = systemParameterService.getSystemParametersByTableCode("EXCNGERTE");
						countryCodeMaps = systemParameterService.getSystemParametersByTableCode("CONTRCODE");
						currencyCodeMaps = systemParameterService.getSystemParametersByTableCode("CURCYCODE");
						cuttoffTimeMap = systemParameterService.getSystemParametersByTableCode("BNKCUTTIM");
						accountTypeMap = systemParameterService.getSystemParametersByTableCode("BNKACTYPE");
						accountStatusMap = systemParameterService.getSystemParametersByTableCode("BNKACSTAS");
						tuxDetailMap = systemParameterService.getSystemParametersByTableCode("BNKTUXDET");
						tuxErrorMap = systemParameterService.getSystemParametersByTableCode("TUXERCODE");
						washAccountMap = systemParameterService.getSystemParametersByTableCode("BNKWASACC");
						holidayListMap = systemParameterService.getSystemParametersByTableCode("BNKPUBHOL");
						bicListMap = systemParameterService.getSystemParametersByTableCode("BNKBICCOD");
						macPathMap = systemParameterService.getSystemParametersByTableCode("MACFLPATH");
						mailProperties = systemParameterService.getSystemParametersByTableCode("BNKSMTPSR");
						emailProperties = systemParameterService.getSystemParametersByTableCode("BNKSMTPEM");
						allProperties = new HashMap<String, Map<String, SystemParameters>>();
						allProperties.put("errorCodeMap", errorCodeMap);
						allProperties.put("exchangeRateMap", exchangeRateMap);
						allProperties.put("countryCodeMap", countryCodeMaps);
						allProperties.put("currencyCodeMap", currencyCodeMaps);
						allProperties.put("cuttoffTimeMap", cuttoffTimeMap);
						allProperties.put("accountTypeMap", accountTypeMap);
						allProperties.put("accountStatusMap", accountStatusMap);
						allProperties.put("tuxDetailMap", tuxDetailMap);
						allProperties.put("tuxErrorMap", tuxErrorMap);
						allProperties.put("washAccountMap", washAccountMap);
						allProperties.put("holidayListMap", holidayListMap);
						allProperties.put("macPropertyMap", macPropertyMap);
						allProperties.put("macPathMap", macPathMap);
						allProperties.put("mailProperties", mailProperties);
						allProperties.put("emailProperties", emailProperties);

						logger.info("(loadAllProperties)==> Checking for property from system general parameters");

						if (countryCodeMaps == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  CONTRCODE ,not configured properly");
						} else if (currencyCodeMaps == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  CURCYCODE ,not configured properly");
						} else if (macPropertyMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  MACSERPRO ,not configured properly");
						} else if (cuttoffTimeMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKCUTTIM ,not configured properly");
						} else if (accountTypeMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKACTYPE ,not configured properly");
						} else if (accountStatusMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKACSTAS ,not configured properly");
						} else if (tuxDetailMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKTUXDET ,not configured properly");
						} else if (tuxErrorMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  TUXERCODE ,not configured properly");
						} else if (washAccountMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKWASACC ,not configured properly");
						} else if (bicListMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKBICCOD ,not configured properly");
						} else if (holidayListMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKPUBHOL ,not configured properly");
						} else if (errorCodeMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  MACERRCOD ,not configured properly");
						} else if (exchangeRateMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  EXCNGERTE ,not configured properly");
						} else if (macPathMap == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  MACFLPATH ,not configured properly");
						} else if (mailProperties == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKSMTPSR ,not configured properly");
						} else if (emailProperties == null) {
							throw new SystemPropertyNotConfigurationException(
									"System property for table code :  BNKSMTPEM ,not configured properly");
						} else {
							logger.info("(loadAllProperties)==> All properties are loaded suucessfully...");
						}
					} catch (SystemPropertyNotConfigurationException e) {
						logger.info("(loadAllProperties)==> Error occured while loading system general property");
						throw e;
					}
					allSystemProperties = allProperties;
				}
			}
		}
		return allSystemProperties;
	}

}
