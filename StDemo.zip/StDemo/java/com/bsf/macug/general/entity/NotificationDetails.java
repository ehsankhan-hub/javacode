package com.bsf.macug.general.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "UPS_NOTIFICATION_DET")
public class NotificationDetails {
	@Id
	@Column(name = "NOTIFICATION_ID")
	private String notificationId;
	@Column(name = "CUSTOMER_ID")
	private String customerId;
	@Column(name = "FILE_ID")
	private String fileId;
	@Column(name = "EVENT_TYPE")
	private String eventType;
	@Column(name = "COMMUNICATION_TYPE")
	private String communicationType;	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "RECEIVED")
	@Temporal(TemporalType.TIMESTAMP)
	private Date received;
	
	@Column(name = "PROCESSED")
	@Temporal(TemporalType.TIMESTAMP)
	private Date processed;

	public String getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getCommunicationType() {
		return communicationType;
	}

	public void setCommunicationType(String communicationType) {
		this.communicationType = communicationType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getReceived() {
		return received;
	}

	public void setReceived(Date received) {
		this.received = received;
	}

	public Date getProcessed() {
		return processed;
	}

	public void setProcessed(Date processed) {
		this.processed = processed;
	}
}
