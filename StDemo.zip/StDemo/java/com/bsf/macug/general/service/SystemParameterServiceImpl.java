package com.bsf.macug.general.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.exception.SystemPropertyNotConfigurationException;
import com.bsf.macug.general.dao.InterSystemParametersDAO;
import com.bsf.macug.general.entity.SystemParameters;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service("systemParameterService")
@Transactional
public class SystemParameterServiceImpl implements InterSystemParameterService {

	private static final Logger logger = Logger
			.getLogger(SystemParameterServiceImpl.class.getName());

	@Autowired
	InterSystemParametersDAO systemParameterDao;

	@Override
	public SystemParameters getSystemParameters(String tableCode,
			String itemCode) {

		SystemParameters result = null;
		try {

			SystemParameters resultObj = systemParameterDao
					.getSystemParameters(tableCode, itemCode);
			if (resultObj != null) {
				result = new SystemParameters();
				BeanUtils.copyProperties(resultObj, result);
			}
		} catch (DataAccessException e) {
			logger.error("Error : " + e.getMessage(), e);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return result;
	}

	@Override
	public Map<String, SystemParameters> getSystemParametersByTableCode(
			String tableCode) throws SystemPropertyNotConfigurationException {
		Map<String, SystemParameters> map = null;
		try {
			List<SystemParameters> paramList = systemParameterDao
					.getSystemParametersByTableCode(tableCode);
			map = new HashMap<String, SystemParameters>();
			for (SystemParameters param : paramList) {
				SystemParameters obj = new SystemParameters();
				BeanUtils.copyProperties(param, obj);
				map.put(param.getItemCode().trim(), obj);
			}
		} catch (DataAccessException e) {
			logger.error("Error : " + e.getMessage(), e);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return map;
	}

	@Override
	public String getSystemParametersDescription1(String itemCode,
			Map<String, SystemParameters> map) {
		String description = null;
		SystemParameters property = map.get(itemCode);
		if (property != null) {
			description = property.getItemDescription1().trim();
		}
		return description;
	}

	@Override
	public String getSystemParametersDescription2(String itemCode,
			Map<String, SystemParameters> map) {
		String description = null;
		SystemParameters property = map.get(itemCode);
		if (property != null) {
			description = property.getItemDescription2().trim();
		}
		return description;
	}

	@Override
	public JSONObject getItemCodeList(String tableCode) {
		JSONObject result = new JSONObject();
		JSONArray resultArray = new JSONArray();
		try {
			List<SystemParameters> paramList = systemParameterDao
					.getSystemParametersByTableCode(tableCode);
			if (paramList != null) {
				for (SystemParameters entity : paramList) {
					JSONObject resultObj = new JSONObject();
					resultObj.put("itemCode", entity.getItemCode().trim());
					resultObj.put("description1", entity.getItemDescription1()
							.trim());
					resultArray.add(resultObj);
				}
			}
			result.put("data", resultArray);
			result.put("status", "success");
		} catch (DataAccessException e) {
			logger.error("Error : " + e.getMessage(), e);
			result.put("data", resultArray);
			result.put("status", "fail");
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			result.put("data", resultArray);
			result.put("status", "fail");
		}
		return result;
	}

	@Override
	public JSONObject getSystemParametersList(String searchParam,
			String sSearch, int displaystart, int idisplaylength) {
		JSONObject result = new JSONObject();
		List<SystemParameters> resultList = null;
		JSONArray resultArray = new JSONArray();
		try {
			Long count = systemParameterDao
					.getRecordCount(searchParam, sSearch);
			resultList = systemParameterDao.getSystemParameterList(searchParam,
					sSearch, displaystart, idisplaylength);
			if (resultList != null) {
				for (SystemParameters entity : resultList) {
					entity.setItemCode(entity.getItemCode().trim());
					ObjectMapper mapper = new ObjectMapper();
					String jsonString = mapper.writeValueAsString(entity);
					JSONObject jsonObject = (JSONObject) JSONValue
							.parse(jsonString);
					resultArray.add(jsonObject);
				}
			}
			result.put("aaData", resultArray);
			result.put("iTotalDisplayRecords", count);
			result.put("iTotalRecords", count);
		} catch (DataAccessException e) {
			logger.error("Error : " + e.getMessage(), e);
			result.put("aaData", resultArray);
			result.put("iTotalDisplayRecords", resultArray.size());
			result.put("iTotalRecords", resultArray.size());
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			result.put("aaData", resultArray);
			result.put("iTotalDisplayRecords", resultArray.size());
			result.put("iTotalRecords", resultArray.size());
		}
		return result;
	}
	
	
	@Override
	public BigDecimal getSystemParametersValue1(String strItemCode,
			Map<String, SystemParameters> map) {
		BigDecimal bgValue1 = null;
		SystemParameters property = map.get(strItemCode);
		if (property != null) {
			bgValue1 = property.getItemValue1();
		}
		return bgValue1;
	}

	@Override
	public BigDecimal getSystemParametersValue2(String strItemCode,
			Map<String, SystemParameters> map) {
		BigDecimal bgValue2 = null;
		SystemParameters property = map.get(strItemCode);
		if (property != null) {
			bgValue2 = property.getItemValue2();
		}
		return bgValue2;
	}
	
}
