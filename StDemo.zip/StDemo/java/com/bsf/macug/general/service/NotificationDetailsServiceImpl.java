package com.bsf.macug.general.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.bsf.macug.general.dao.InterNotificationDetailsDAO;
import com.bsf.macug.general.entity.NotificationDetails;

@Service
@Transactional
public class NotificationDetailsServiceImpl implements InterNotificationDetailsService{

	private static final Logger logger = Logger
			.getLogger(NotificationDetailsServiceImpl.class.getName());
	
	@Autowired
	InterNotificationDetailsDAO notificationDetailsDAO;
	
	@Override
	public NotificationDetails getNotificationDetails(String notificationId) {
		NotificationDetails notification = null;
		try {
			notification = notificationDetailsDAO.getNotificationDetails(notificationId);
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
		}
		return notification;
	}

	@Override
	public List<NotificationDetails> getNotificationDetailsList(
			String searchParam, String sSearch, int displaystart,
			int idisplaylength) {
		List<NotificationDetails> listOfNotification = null;
		try {
			listOfNotification = notificationDetailsDAO.getNotificationDetailsList(searchParam, sSearch, displaystart, idisplaylength);
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
		}
		return listOfNotification;
	}

	@Override
	public boolean saveNotificationDetails(NotificationDetails details) {
		boolean status = false;
		try {			
			if (StringUtils.isEmpty(details.getNotificationId())) {
				String id = java.util.UUID.randomUUID().toString();
				details.setNotificationId(id);
			}
			status = notificationDetailsDAO.saveNotificationDetails(details);
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
		}
		return status;
	}

	@Override
	public boolean updateNotificationDetails(NotificationDetails details) {
		boolean status = false;
		try {
			status = notificationDetailsDAO.updateNotificationDetails(details);
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
		}
		return status;
	}

	@Override
	public List<NotificationDetails> getNotificationDetailsListByStatus(
			String status) {
		return notificationDetailsDAO.getNotificationDetailsListByStatus(status);
	}



}
