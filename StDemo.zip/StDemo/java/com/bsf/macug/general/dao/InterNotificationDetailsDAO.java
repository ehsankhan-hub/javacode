package com.bsf.macug.general.dao;

import java.util.List;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.general.entity.NotificationDetails;

public interface InterNotificationDetailsDAO {
	NotificationDetails getNotificationDetails(String notificationId)
			throws DataAccessException;

	public List<NotificationDetails> getNotificationDetailsList(
			String searchParam, String sSearch, int displaystart,
			int idisplaylength) throws DataAccessException;

	boolean saveNotificationDetails(NotificationDetails details)
			throws DataAccessException;

	boolean updateNotificationDetails(NotificationDetails details)
			throws DataAccessException;

	List<NotificationDetails> getNotificationDetailsListByStatus(String status);
}
