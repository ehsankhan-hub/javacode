package com.bsf.macug.application.mail.dto;

import java.io.Serializable;
import java.util.Set;

public class MailServerDTO implements Serializable {

	private String mailHost;
	private Integer mailPort;
	private String mailFrom;
	private String mailFromPass;
	private String mailSubject;
	private String mailTo;
	private Set<String> mailCC;
	private Set<String> mailBCC;
	private String mailContents;
	private String mailattachmentPath;
	private String mailProtocol;
	private String mailAuth;
	private String mailTLS;
	private String mailDebug;
	private String mailServerTableCode;

	public MailServerDTO() {
	}

	public MailServerDTO(String mailHost, Integer mailPort, String mailFrom,
			String mailFromPass, String mailSubject, String mailTo,
			String mailContents) {
		super();
		this.mailHost = mailHost;
		this.mailPort = mailPort;
		this.mailFrom = mailFrom;
		this.mailFromPass = mailFromPass;
		this.mailSubject = mailSubject;
		this.mailTo = mailTo;
		this.mailContents = mailContents;
	}

	public MailServerDTO(String mailHost, Integer mailPort, String mailFrom,
			String mailFromPass, String mailSubject, String mailTo,
			String mailContents, Set<String> mailCC, Set<String> mailBCC,
			String mailattachmentPath, String mailProtocol, String mailAuth,
			String mailTLS, String mailDebug) {
		super();
		this.mailHost = mailHost;
		this.mailPort = mailPort;
		this.mailFrom = mailFrom;
		this.mailFromPass = mailFromPass;
		this.mailSubject = mailSubject;
		this.mailTo = mailTo;
		this.mailCC = mailCC;
		this.mailBCC = mailBCC;
		this.mailContents = mailContents;
		this.mailattachmentPath = mailattachmentPath;
		this.mailProtocol = mailProtocol;
		this.mailAuth = mailAuth;
		this.mailTLS = mailTLS;
		this.mailDebug = mailDebug;
	}

	public String getMailHost() {
		return mailHost;
	}

	public void setMailHost(String mailHost) {
		this.mailHost = mailHost;
	}

	public Integer getMailPort() {
		return mailPort;
	}

	public void setMailPort(Integer mailPort) {
		this.mailPort = mailPort;
	}

	public String getMailFrom() {
		return mailFrom;
	}

	public void setMailFrom(String mailFrom) {
		this.mailFrom = mailFrom;
	}

	public String getMailFromPass() {
		return mailFromPass;
	}

	public void setMailFromPass(String mailFromPass) {
		this.mailFromPass = mailFromPass;
	}

	public String getMailSubject() {
		return mailSubject;
	}

	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}

	public String getMailTo() {
		return mailTo;
	}

	public void setMailTo(String mailTo) {
		this.mailTo = mailTo;
	}

	public Set<String> getMailCC() {
		return mailCC;
	}

	public void setMailCC(Set<String> mailCC) {
		this.mailCC = mailCC;
	}

	public Set<String> getMailBCC() {
		return mailBCC;
	}

	public void setMailBCC(Set<String> mailBCC) {
		this.mailBCC = mailBCC;
	}

	public String getMailattachmentPath() {
		return mailattachmentPath;
	}

	public String getMailContents() {
		return mailContents;
	}

	public void setMailContents(String mailContents) {
		this.mailContents = mailContents;
	}

	public void setMailattachmentPath(String mailattachmentPath) {
		this.mailattachmentPath = mailattachmentPath;
	}

	public String getMailProtocol() {
		return mailProtocol;
	}

	public void setMailProtocol(String mailProtocol) {
		this.mailProtocol = mailProtocol;
	}

	public String getMailAuth() {
		return mailAuth;
	}

	public void setMailAuth(String mailAuth) {
		this.mailAuth = mailAuth;
	}

	public String getMailTLS() {
		return mailTLS;
	}

	public void setMailTLS(String mailTLS) {
		this.mailTLS = mailTLS;
	}

	public String getMailDebug() {
		return mailDebug;
	}

	public void setMailDebug(String mailDebug) {
		this.mailDebug = mailDebug;
	}

	public String getMailServerTableCode() {
		return mailServerTableCode;
	}

	public void setMailServerTableCode(String mailServerTableCode) {
		this.mailServerTableCode = mailServerTableCode;
	}

	@Override
	public String toString() {
		return "MailServerDTO [mailHost=" + mailHost + ", mailPort=" + mailPort
				+ ", mailFrom=" + mailFrom + ", mailFromPass=" + mailFromPass
				+ ", mailSubject=" + mailSubject + ", mailTo=" + mailTo
				+ ", mailCC=" + mailCC + ", mailBCC=" + mailBCC
				+ ", mailContents=" + mailContents + ", mailattachmentPath="
				+ mailattachmentPath + ", mailProtocol=" + mailProtocol
				+ ", mailAuth=" + mailAuth + ", mailTLS=" + mailTLS
				+ ", mailDebug=" + mailDebug + ", mailServerTableCode="
				+ mailServerTableCode + "]";
	}

	
	
}
