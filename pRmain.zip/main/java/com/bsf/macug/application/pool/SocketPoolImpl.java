package com.bsf.macug.application.pool;

import java.io.IOException;
import java.net.Socket;
import java.rmi.server.RMIClientSocketFactory;
import java.util.HashSet;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class SocketPoolImpl implements SocketPool{
	
	private static final Logger logger = Logger.getLogger(SocketPoolImpl.class);
	
    static final long DEFAULT_EXPIRATION_TIMEOUT = 15000;
    static final int DEFAULT_CAPACITY = 10;
    public final HashSet connections = new HashSet();
    private final String hostName;
    private final int ports[];
    private int assignedIndex=0;
    private final RMIClientSocketFactory socketFactory;
    final long expirationTimeout;
	private final int capacity;
	
	public long getExpirationTimeout() {
		return expirationTimeout;
	}
    
    
    public SocketPoolImpl(String hostName, int port[]) {
        this(hostName, port, null);
    }
   
    public SocketPoolImpl(String hostName, int port[],
                          RMIClientSocketFactory socketFactory)
    {
        this(hostName, port, socketFactory,
             DEFAULT_EXPIRATION_TIMEOUT, DEFAULT_CAPACITY);
    }
   
    public SocketPoolImpl(String hostName, int port[],
                          long expirationTimeout, int capacity)
    {
        this(hostName, port, null, expirationTimeout, capacity);
    }   
    
    
    public SocketPoolImpl(
        String hostName,
        int ports[],
        RMIClientSocketFactory socketFactory,
        long expirationTimeout,
        int capacity)
    {
        if (capacity <= 0 || expirationTimeout < 0) {
            throw new IllegalArgumentException();
        }
        this.hostName = hostName;
        this.ports = ports;
        this.socketFactory = socketFactory;
        this.expirationTimeout = expirationTimeout;
        this.capacity = capacity;
    }

    private Connection findConnection() {
        Connection result = null;
        for (Iterator iter = connections.iterator(); iter.hasNext();) {
            Connection conn = (Connection)iter.next();
            byte connStatus = conn.acquire();
            if (connStatus == Connection.READY) {
            	conn.setExpires(-1);
                result = conn;
                break;
            } else if (connStatus == Connection.CLOSED) {
                iter.remove();
            }
        }
        return result;
    }

    public synchronized void notifyConnectionStateChanged() {
        notify();
    }

    /**
     * Requests a connection from the pool. If an existing idle connection is
     * found, it is returned. Otherwise, if pool capacity has not been reached,
     * new connection is created. Otherwise, the operation blocks until
     * a connection is available.
     *
     * @return a connection
     * @throws IOException if I/O error occurs
     * @throws InterruptedException if interrupted while waiting for
     *                              a connection
     */
    public synchronized Connection getSocketConnection()
        throws IOException, InterruptedException
    {
        // make sure that connection pooling does not circumvent security
        // policy by allowing unauthorized clients to use network sockets
       // checkConnectPermission();

        Connection conn = findConnection();
        while (conn == null) {
            if (connections.size() == capacity) {
               // wait();
            	Thread.sleep(2000);
                conn = findConnection();
            } else {
                Socket socket = socketFactory != null
                    ? socketFactory.createSocket(hostName, getPort())
                    : new Socket(hostName, getPort());
                conn = new Connection(socket, this);
                connections.add(conn);
            }
        }
        return conn;
    }
    
    public  synchronized void resetConnections(){
    	logger.warn("System reset connections due to internal proplems");
        for (Iterator iter = connections.iterator(); iter.hasNext();) {
        	iter.remove();
        }
    } 

/*    private void checkConnectPermission() {
        SecurityManager security = System.getSecurityManager();
        if (security != null) {
            security.checkConnect(hostName, port);
        }
    }*/
    
    private int getPort()	{
    	
    	if(ports.length==1)	{
    		
    		return ports[0];
    	}else	{
    	
    		if(assignedIndex==(ports.length-1))	{
    			
    			assignedIndex=0;
    			
    		}else	{
    			
    			assignedIndex++;
    		}
    		return ports[assignedIndex];
    	}
    }    
    
    @Override
    public JSONObject getConnectionPoolStatus() {
    	JSONObject finalObject = new JSONObject();
    	JSONArray results = new JSONArray();
    	Connection result = null;
    	int totalConnectionInPool = 0;
    	HashSet<Connection> temp = new HashSet<Connection>();
    	temp.addAll(connections);
        for (Iterator iter = temp.iterator(); iter.hasNext();) {
            Connection conn = (Connection)iter.next();
            byte connStatus = conn.acquire();
            JSONObject obj = new JSONObject();
            if(connStatus == Connection.USED){
            	obj.put("id", totalConnectionInPool);
            	obj.put("expires", conn.expires);
            	obj.put("status", "USED");
            }else if(connStatus == Connection.READY){
            	obj.put("id", totalConnectionInPool);
            	obj.put("expires", conn.expires);
            	obj.put("status", "READY");
            }else if(connStatus == Connection.CLOSED){
            	obj.put("id", totalConnectionInPool);
            	obj.put("expires", conn.expires);
            	obj.put("status", "CLOSED");
            }
            results.add(obj);
            totalConnectionInPool++;
        }       
        
        finalObject.put("conectionDetails", results);
        finalObject.put("totalConnection", totalConnectionInPool);
        
        return finalObject;
    }

	@Override
    public void resetManually() throws Throwable{
		for (Iterator iter = connections.iterator(); iter.hasNext();) {
           Connection conn = (Connection)iter.next();
           try {
        	   conn.close();
        	   iter.remove();
		   } catch (Exception e) {
			   logger.error("Error : "+e.getMessage(), e);
		   }
        }
	}


	public synchronized HashSet getConnections() {
		return connections;
	}
}
