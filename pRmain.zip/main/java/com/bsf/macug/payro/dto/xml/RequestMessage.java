package com.bsf.macug.payro.dto.xml;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "header",
    "body"
})
@XmlRootElement(name = "Message")
public class RequestMessage {

    @XmlElement(name = "Header", required = true)
    protected RequestMessage.Header header;
    @XmlElement(name = "Body", required = true)
    protected RequestMessage.Body body;
    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link RequestMessage.Header }
     *     
     */
    public RequestMessage.Header getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link RequestMessage.Header }
     *     
     */
    public void setHeader(RequestMessage.Header value) {
        this.header = value;
    }

    /**
     * Gets the value of the body property.
     * 
     * @return
     *     possible object is
     *     {@link RequestMessage.Body }
     *     
     */
    public RequestMessage.Body getBody() {
        return body;
    }

    /**
     * Sets the value of the body property.
     * 
     * @param value
     *     allowed object is
     *     {@link RequestMessage.Body }
     *     
     */
    public void setBody(RequestMessage.Body value) {
        this.body = value;
    }

    
    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="PayrollMessage">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="PayrollMessageRef" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *                   &lt;element name="PayrollMessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="PayrollTransactionCount" type="{http://www.w3.org/2001/XMLSchema}byte"/>
     *                   &lt;element name="PayrollTransactionAmount" type="{http://www.w3.org/2001/XMLSchema}byte"/>
     *                   &lt;element name="PayrollTransaction" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="SequenceNum" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *                             &lt;element name="TransactionData" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "payrollMessage"
    })
    public static class Body {

        @XmlElement(name = "PayrollMessage", required = true)
        protected RequestMessage.Body.PayrollMessage payrollMessage;

        /**
         * Gets the value of the payrollMessage property.
         * 
         * @return
         *     possible object is
         *     {@link RequestMessage.Body.PayrollMessage }
         *     
         */
        public RequestMessage.Body.PayrollMessage getPayrollMessage() {
            return payrollMessage;
        }

        /**
         * Sets the value of the payrollMessage property.
         * 
         * @param value
         *     allowed object is
         *     {@link RequestMessage.Body.PayrollMessage }
         *     
         */
        public void setPayrollMessage(RequestMessage.Body.PayrollMessage value) {
            this.payrollMessage = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="PayrollMessageRef" type="{http://www.w3.org/2001/XMLSchema}int"/>
         *         &lt;element name="PayrollMessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="PayrollTransactionCount" type="{http://www.w3.org/2001/XMLSchema}byte"/>
         *         &lt;element name="PayrollTransactionAmount" type="{http://www.w3.org/2001/XMLSchema}byte"/>
         *         &lt;element name="PayrollTransaction" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="SequenceNum" type="{http://www.w3.org/2001/XMLSchema}int"/>
         *                   &lt;element name="TransactionData" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "payrollMessageRef",
            "payrollMessageType",
            "payrollTransactionCount",
            "payrollTransactionAmount",
            "payrollTransaction"
        })
        public static class PayrollMessage {

            @XmlElement(name = "PayrollMessageRef")
            protected String payrollMessageRef;
            @XmlElement(name = "PayrollMessageType", required = true)
            protected String payrollMessageType;
            @XmlElement(name = "PayrollTransactionCount")
            protected String payrollTransactionCount;
            @XmlElement(name = "PayrollTransactionAmount")
            protected String payrollTransactionAmount;
            @XmlElement(name = "PayrollTransaction")
            protected List<RequestMessage.Body.PayrollMessage.PayrollTransaction> payrollTransaction;

            /**
             * Gets the value of the payrollMessageRef property.
             * 
             */
            public String getPayrollMessageRef() {
                return payrollMessageRef;
            }

            /**
             * Sets the value of the payrollMessageRef property.
             * 
             */
            public void setPayrollMessageRef(String value) {
                this.payrollMessageRef = value;
            }

            /**
             * Gets the value of the payrollMessageType property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getPayrollMessageType() {
                return payrollMessageType;
            }

            /**
             * Sets the value of the payrollMessageType property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setPayrollMessageType(String value) {
                this.payrollMessageType = value;
            }

            /**
             * Gets the value of the payrollTransactionCount property.
             * 
             */
            public String getPayrollTransactionCount() {
                return payrollTransactionCount;
            }

            /**
             * Sets the value of the payrollTransactionCount property.
             * 
             */
            public void setPayrollTransactionCount(String value) {
                this.payrollTransactionCount = value;
            }

            /**
             * Gets the value of the payrollTransactionAmount property.
             * 
             */
            public String getPayrollTransactionAmount() {
                return payrollTransactionAmount;
            }

            /**
             * Sets the value of the payrollTransactionAmount property.
             * 
             */
            public void setPayrollTransactionAmount(String value) {
                this.payrollTransactionAmount = value;
            }

            /**
             * Gets the value of the payrollTransaction property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the payrollTransaction property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getPayrollTransaction().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link RequestMessage.Body.PayrollMessage.PayrollTransaction }
             * 
             * 
             */
            public List<RequestMessage.Body.PayrollMessage.PayrollTransaction> getPayrollTransaction() {
                if (payrollTransaction == null) {
                    payrollTransaction = new ArrayList<RequestMessage.Body.PayrollMessage.PayrollTransaction>();
                }
                return this.payrollTransaction;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="SequenceNum" type="{http://www.w3.org/2001/XMLSchema}int"/>
             *         &lt;element name="TransactionData" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "sequenceNum",
                "transactionData"
            })
            public static class PayrollTransaction {

                @XmlElement(name = "SequenceNum")
                protected int sequenceNum;
                @XmlElement(name = "TransactionData", required = true)
                protected String transactionData;

                /**
                 * Gets the value of the sequenceNum property.
                 * 
                 */
                public int getSequenceNum() {
                    return sequenceNum;
                }

                /**
                 * Sets the value of the sequenceNum property.
                 * 
                 */
                public void setSequenceNum(int value) {
                    this.sequenceNum = value;
                }

                /**
                 * Gets the value of the transactionData property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getTransactionData() {
                    return transactionData;
                }

                /**
                 * Sets the value of the transactionData property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setTransactionData(String value) {
                    this.transactionData = value;
                }

            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Sender" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="Receiver" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="MessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="MessageDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="TimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "sender",
        "receiver",
        "messageType",
        "messageDescription",
        "timeStamp"
    })
    public static class Header {

        @XmlElement(name = "Sender", required = true)
        protected String sender;
        @XmlElement(name = "Receiver", required = true)
        protected String receiver;
        @XmlElement(name = "MessageType", required = true)
        protected String messageType;
        @XmlElement(name = "MessageDescription", required = true)
        protected String messageDescription;
        @XmlElement(name = "TimeStamp", required = true)
        protected String timeStamp;

        /**
         * Gets the value of the sender property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSender() {
            return sender;
        }

        /**
         * Sets the value of the sender property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSender(String value) {
            this.sender = value;
        }

        /**
         * Gets the value of the receiver property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getReceiver() {
            return receiver;
        }

        /**
         * Sets the value of the receiver property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setReceiver(String value) {
            this.receiver = value;
        }

        /**
         * Gets the value of the messageType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMessageType() {
            return messageType;
        }

        /**
         * Sets the value of the messageType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMessageType(String value) {
            this.messageType = value;
        }

        /**
         * Gets the value of the messageDescription property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMessageDescription() {
            return messageDescription;
        }

        /**
         * Sets the value of the messageDescription property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMessageDescription(String value) {
            this.messageDescription = value;
        }

        /**
         * Gets the value of the timeStamp property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public String getTimeStamp() {
            return timeStamp;
        }

        /**
         * Sets the value of the timeStamp property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setTimeStamp(String value) {
            this.timeStamp = value;
        }

    }	
}
