package com.bsf.macug.payro.dto.xml;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Header">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Sender" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="Receiver" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="MessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="MessageDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="TimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Body">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="PayrollResponse">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="PayrollMessageRef" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="PayrollMessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="PayrollTransactionCount" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *                             &lt;element name="PayrollTransactionAmount" type="{http://www.w3.org/2001/XMLSchema}float"/>
 *                             &lt;element name="PayrollTransactionResponse" maxOccurs="unbounded" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="SequenceNum" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="TransactionRef" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="StatusCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="StatusDetail" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ResponseStatus">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="StatusCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="StatusDetail" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "header",
    "body",
    "responseStatus"
})
@XmlRootElement(name = "Message")
public class AcknowledgementResponseXMLDTO {

    @XmlElement(name = "Header", required = true)
    protected AcknowledgementResponseXMLDTO.Header header;
    @XmlElement(name = "Body", required = true)
    protected AcknowledgementResponseXMLDTO.Body body;
    @XmlElement(name = "ResponseStatus", required = true)
    protected AcknowledgementResponseXMLDTO.ResponseStatus responseStatus;

    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link AcknowledgementResponseXMLDTO.Header }
     *     
     */
    public AcknowledgementResponseXMLDTO.Header getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link AcknowledgementResponseXMLDTO.Header }
     *     
     */
    public void setHeader(AcknowledgementResponseXMLDTO.Header value) {
        this.header = value;
    }

    /**
     * Gets the value of the body property.
     * 
     * @return
     *     possible object is
     *     {@link AcknowledgementResponseXMLDTO.Body }
     *     
     */
    public AcknowledgementResponseXMLDTO.Body getBody() {
        return body;
    }

    /**
     * Sets the value of the body property.
     * 
     * @param value
     *     allowed object is
     *     {@link AcknowledgementResponseXMLDTO.Body }
     *     
     */
    public void setBody(AcknowledgementResponseXMLDTO.Body value) {
        this.body = value;
    }

    /**
     * Gets the value of the responseStatus property.
     * 
     * @return
     *     possible object is
     *     {@link AcknowledgementResponseXMLDTO.ResponseStatus }
     *     
     */
    public AcknowledgementResponseXMLDTO.ResponseStatus getResponseStatus() {
        return responseStatus;
    }

    /**
     * Sets the value of the responseStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link AcknowledgementResponseXMLDTO.ResponseStatus }
     *     
     */
    public void setResponseStatus(AcknowledgementResponseXMLDTO.ResponseStatus value) {
        this.responseStatus = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="PayrollResponse">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="PayrollMessageRef" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="PayrollMessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="PayrollTransactionCount" type="{http://www.w3.org/2001/XMLSchema}short"/>
     *                   &lt;element name="PayrollTransactionAmount" type="{http://www.w3.org/2001/XMLSchema}float"/>
     *                   &lt;element name="PayrollTransactionResponse" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="SequenceNum" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="TransactionRef" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="StatusCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="StatusDetail" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "payrollResponse"
    })
    public static class Body {

        @XmlElement(name = "PayrollResponse", required = true)
        protected AcknowledgementResponseXMLDTO.Body.PayrollResponse payrollResponse;

        /**
         * Gets the value of the payrollResponse property.
         * 
         * @return
         *     possible object is
         *     {@link AcknowledgementResponseXMLDTO.Body.PayrollResponse }
         *     
         */
        public AcknowledgementResponseXMLDTO.Body.PayrollResponse getPayrollResponse() {
            return payrollResponse;
        }

        /**
         * Sets the value of the payrollResponse property.
         * 
         * @param value
         *     allowed object is
         *     {@link AcknowledgementResponseXMLDTO.Body.PayrollResponse }
         *     
         */
        public void setPayrollResponse(AcknowledgementResponseXMLDTO.Body.PayrollResponse value) {
            this.payrollResponse = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="PayrollMessageRef" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="PayrollMessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="PayrollTransactionCount" type="{http://www.w3.org/2001/XMLSchema}short"/>
         *         &lt;element name="PayrollTransactionAmount" type="{http://www.w3.org/2001/XMLSchema}float"/>
         *         &lt;element name="PayrollTransactionResponse" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="SequenceNum" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="TransactionRef" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="StatusCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="StatusDetail" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "payrollMessageRef",
            "payrollMessageType",
            "payrollTransactionCount",
            "payrollTransactionAmount",
            "payrollTransactionResponse"
        })
        public static class PayrollResponse {

            @XmlElement(name = "PayrollMessageRef", required = true)
            protected String payrollMessageRef;
            @XmlElement(name = "PayrollMessageType", required = true)
            protected String payrollMessageType;
            @XmlElement(name = "PayrollTransactionCount")
            protected Integer payrollTransactionCount;
            @XmlElement(name = "PayrollTransactionAmount")
            protected double payrollTransactionAmount;
            @XmlElement(name = "PayrollTransactionResponse")
            protected List<AcknowledgementResponseXMLDTO.Body.PayrollResponse.PayrollTransactionResponse> payrollTransactionResponse;

            /**
             * Gets the value of the payrollMessageRef property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getPayrollMessageRef() {
                return payrollMessageRef;
            }

            /**
             * Sets the value of the payrollMessageRef property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setPayrollMessageRef(String value) {
                this.payrollMessageRef = value;
            }

            /**
             * Gets the value of the payrollMessageType property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getPayrollMessageType() {
                return payrollMessageType;
            }

            /**
             * Sets the value of the payrollMessageType property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setPayrollMessageType(String value) {
                this.payrollMessageType = value;
            }

            /**
             * Gets the value of the payrollTransactionCount property.
             * 
             */
            public Integer getPayrollTransactionCount() {
                return payrollTransactionCount;
            }

            /**
             * Sets the value of the payrollTransactionCount property.
             * 
             */
            public void setPayrollTransactionCount(Integer value) {
                this.payrollTransactionCount = value;
            }

            /**
             * Gets the value of the payrollTransactionAmount property.
             * 
             */
            public double getPayrollTransactionAmount() {
                return payrollTransactionAmount;
            }

            /**
             * Sets the value of the payrollTransactionAmount property.
             * 
             */
            public void setPayrollTransactionAmount(double value) {
                this.payrollTransactionAmount = value;
            }

            /**
             * Gets the value of the payrollTransactionResponse property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the payrollTransactionResponse property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getPayrollTransactionResponse().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link Message.Body.PayrollResponse.PayrollTransactionResponse }
             * 
             * 
             */
            public List<AcknowledgementResponseXMLDTO.Body.PayrollResponse.PayrollTransactionResponse> getPayrollTransactionResponse() {
                if (payrollTransactionResponse == null) {
                    payrollTransactionResponse = new ArrayList<AcknowledgementResponseXMLDTO.Body.PayrollResponse.PayrollTransactionResponse>();
                }
                return this.payrollTransactionResponse;
            }
            
            public void setPayrollTransactionResponse(
					List<AcknowledgementResponseXMLDTO.Body.PayrollResponse.PayrollTransactionResponse> payrollTransactionResponse) {
				this.payrollTransactionResponse = payrollTransactionResponse;
			}




			/**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="SequenceNum" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="TransactionRef" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="StatusCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="StatusDetail" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "sequenceNum",
                "transactionRef",
                "statusCode",
                "statusDetail"
            })
            public static class PayrollTransactionResponse {

                @XmlElement(name = "SequenceNum", required = true)
                protected String sequenceNum;
                @XmlElement(name = "TransactionRef", required = true)
                protected String transactionRef;
                @XmlElement(name = "StatusCode", required = true)
                protected String statusCode;
                @XmlElement(name = "StatusDetail", required = true)
                protected String statusDetail;

                /**
                 * Gets the value of the sequenceNum property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getSequenceNum() {
                    return sequenceNum;
                }

                /**
                 * Sets the value of the sequenceNum property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setSequenceNum(String value) {
                    this.sequenceNum = value;
                }

                /**
                 * Gets the value of the transactionRef property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getTransactionRef() {
                    return transactionRef;
                }

                /**
                 * Sets the value of the transactionRef property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setTransactionRef(String value) {
                    this.transactionRef = value;
                }

                /**
                 * Gets the value of the statusCode property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getStatusCode() {
                    return statusCode;
                }

                /**
                 * Sets the value of the statusCode property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setStatusCode(String value) {
                    this.statusCode = value;
                }

                /**
                 * Gets the value of the statusDetail property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getStatusDetail() {
                    return statusDetail;
                }

                /**
                 * Sets the value of the statusDetail property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setStatusDetail(String value) {
                    this.statusDetail = value;
                }

            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Sender" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="Receiver" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="MessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="MessageDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="TimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "sender",
        "receiver",
        "messageType",
        "messageDescription",
        "timeStamp"
    })
    public static class Header {

        @XmlElement(name = "Sender", required = true)
        protected String sender;
        @XmlElement(name = "Receiver", required = true)
        protected String receiver;
        @XmlElement(name = "MessageType", required = true)
        protected String messageType;
        @XmlElement(name = "MessageDescription", required = true)
        protected String messageDescription;
        @XmlElement(name = "TimeStamp", required = true)
        @XmlSchemaType(name = "dateTime")
        protected String timeStamp;

        /**
         * Gets the value of the sender property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSender() {
            return sender;
        }

        /**
         * Sets the value of the sender property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSender(String value) {
            this.sender = value;
        }

        /**
         * Gets the value of the receiver property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getReceiver() {
            return receiver;
        }

        /**
         * Sets the value of the receiver property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setReceiver(String value) {
            this.receiver = value;
        }

        /**
         * Gets the value of the messageType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMessageType() {
            return messageType;
        }

        /**
         * Sets the value of the messageType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMessageType(String value) {
            this.messageType = value;
        }

        /**
         * Gets the value of the messageDescription property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMessageDescription() {
            return messageDescription;
        }

        /**
         * Sets the value of the messageDescription property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMessageDescription(String value) {
            this.messageDescription = value;
        }

        /**
         * Gets the value of the timeStamp property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public String getTimeStamp() {
            return timeStamp;
        }

        /**
         * Sets the value of the timeStamp property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setTimeStamp(String value) {
            this.timeStamp = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="StatusCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="StatusDetail" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "statusCode",
        "statusDetail"
    })
    public static class ResponseStatus {

        @XmlElement(name = "StatusCode", required = true)
        protected String statusCode;
        @XmlElement(name = "StatusDetail", required = true)
        protected String statusDetail;

        /**
         * Gets the value of the statusCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getStatusCode() {
            return statusCode;
        }

        /**
         * Sets the value of the statusCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setStatusCode(String value) {
            this.statusCode = value;
        }

        /**
         * Gets the value of the statusDetail property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getStatusDetail() {
            return statusDetail;
        }

        /**
         * Sets the value of the statusDetail property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setStatusDetail(String value) {
            this.statusDetail = value;
        }

    }
	
}
