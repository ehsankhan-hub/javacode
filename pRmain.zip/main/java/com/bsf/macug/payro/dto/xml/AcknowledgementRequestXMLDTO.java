package com.bsf.macug.payro.dto.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * <p>
 * Java class for anonymous complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
* &lt;complexType>
*   &lt;complexContent>
*     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
*       &lt;sequence>
*         &lt;element name="Header">
*           &lt;complexType>
*             &lt;complexContent>
*               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
*                 &lt;sequence>
*                   &lt;element name="Sender" type="{http://www.w3.org/2001/XMLSchema}string"/>
*                   &lt;element name="Receiver" type="{http://www.w3.org/2001/XMLSchema}string"/>
*                   &lt;element name="MessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
*                   &lt;element name="MessageDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
*                   &lt;element name="TimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
*                 &lt;/sequence>
*               &lt;/restriction>
*             &lt;/complexContent>
*           &lt;/complexType>
*         &lt;/element>
*         &lt;element name="Body">
*           &lt;complexType>
*             &lt;complexContent>
*               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
*                 &lt;sequence>
*                   &lt;element name="PayrollResponseRequest">
*                     &lt;complexType>
*                       &lt;complexContent>
*                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
*                           &lt;sequence>
*                             &lt;element name="PayrollMessageRef" type="{http://www.w3.org/2001/XMLSchema}string"/>
*                             &lt;element name="PayrollMessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
*                           &lt;/sequence>
*                         &lt;/restriction>
*                       &lt;/complexContent>
*                     &lt;/complexType>
*                   &lt;/element>
*                 &lt;/sequence>
*               &lt;/restriction>
*             &lt;/complexContent>
*           &lt;/complexType>
*         &lt;/element>
*       &lt;/sequence>
*     &lt;/restriction>
*   &lt;/complexContent>
* &lt;/complexType>
 * </pre>
 * 
 * 
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "header", "body" })
@XmlRootElement(name = "Message")
public class AcknowledgementRequestXMLDTO {

	@XmlElement(name = "Header", required = true)
	protected AcknowledgementRequestXMLDTO.Header header;
	@XmlElement(name = "Body", required = true)
	protected AcknowledgementRequestXMLDTO.Body body;

	/**
	 * Gets the value of the header property.
	 * 
	 * @return possible object is {@link Message.Header }
	 * 
	 */
	public AcknowledgementRequestXMLDTO.Header getHeader() {
		return header;
	}

	/**
	 * Sets the value of the header property.
	 * 
	 * @param value
	 *            allowed object is {@link Message.Header }
	 * 
	 */
	public void setHeader(AcknowledgementRequestXMLDTO.Header value) {
		this.header = value;
	}

	/**
	 * Gets the value of the body property.
	 * 
	 * @return possible object is {@link Message.Body }
	 * 
	 */
	public AcknowledgementRequestXMLDTO.Body getBody() {
		return body;
	}

	/**
	 * Sets the value of the body property.
	 * 
	 * @param value
	 *            allowed object is {@link Message.Body }
	 * 
	 */
	public void setBody(AcknowledgementRequestXMLDTO.Body value) {
		this.body = value;
	}

	/**
	 * <p>
	 * Java class for anonymous complex type.
	 * 
	 * <p>
	 * The following schema fragment specifies the expected content contained
	 * within this class.
	 * 
	 * <pre>
	 * &lt;complexType>
	 *   &lt;complexContent>
	 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
	 *       &lt;sequence>
	 *         &lt;element name="PayrollResponseRequest">
	 *           &lt;complexType>
	 *             &lt;complexContent>
	 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
	 *                 &lt;sequence>
	 *                   &lt;element name="PayrollMessageRef" type="{http://www.w3.org/2001/XMLSchema}string"/>
	 *                   &lt;element name="PayrollMessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
	 *                 &lt;/sequence>
	 *               &lt;/restriction>
	 *             &lt;/complexContent>
	 *           &lt;/complexType>
	 *         &lt;/element>
	 *       &lt;/sequence>
	 *     &lt;/restriction>
	 *   &lt;/complexContent>
	 * &lt;/complexType>
	 * </pre>
	 * 
	 * 
	 */
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(name = "", propOrder = { "payrollResponseRequest" })
	public static class Body {

		@XmlElement(name = "PayrollResponseRequest", required = true)
		protected AcknowledgementRequestXMLDTO.Body.PayrollResponseRequest payrollResponseRequest;

		/**
		 * Gets the value of the payrollResponseRequest property.
		 * 
		 * @return possible object is
		 *         {@link Message.Body.PayrollResponseRequest }
		 * 
		 */
		public AcknowledgementRequestXMLDTO.Body.PayrollResponseRequest getPayrollResponseRequest() {
			return payrollResponseRequest;
		}

		/**
		 * Sets the value of the payrollResponseRequest property.
		 * 
		 * @param value
		 *            allowed object is
		 *            {@link Message.Body.PayrollResponseRequest }
		 * 
		 */
		public void setPayrollResponseRequest(AcknowledgementRequestXMLDTO.Body.PayrollResponseRequest value) {
			this.payrollResponseRequest = value;
		}

		/**
		 * <p>
		 * Java class for anonymous complex type.
		 * 
		 * <p>
		 * The following schema fragment specifies the expected content
		 * contained within this class.
		 * 
		 * <pre>
		 * &lt;complexType>
		 *   &lt;complexContent>
		 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
		 *       &lt;sequence>
		 *         &lt;element name="PayrollMessageRef" type="{http://www.w3.org/2001/XMLSchema}string"/>
		 *         &lt;element name="PayrollMessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
		 *       &lt;/sequence>
		 *     &lt;/restriction>
		 *   &lt;/complexContent>
		 * &lt;/complexType>
		 * </pre>
		 * 
		 * 
		 */
		@XmlAccessorType(XmlAccessType.FIELD)
		@XmlType(name = "", propOrder = { "payrollMessageRef", "payrollMessageType" })
		public static class PayrollResponseRequest {

			@XmlElement(name = "PayrollMessageRef", required = true)
			protected String payrollMessageRef;
			@XmlElement(name = "PayrollMessageType", required = true)
			protected String payrollMessageType;

			/**
			 * Gets the value of the payrollMessageRef property.
			 * 
			 * @return possible object is {@link String }
			 * 
			 */
			public String getPayrollMessageRef() {
				return payrollMessageRef;
			}

			/**
			 * Sets the value of the payrollMessageRef property.
			 * 
			 * @param value
			 *            allowed object is {@link String }
			 * 
			 */
			public void setPayrollMessageRef(String value) {
				this.payrollMessageRef = value;
			}

			/**
			 * Gets the value of the payrollMessageType property.
			 * 
			 * @return possible object is {@link String }
			 * 
			 */
			public String getPayrollMessageType() {
				return payrollMessageType;
			}

			/**
			 * Sets the value of the payrollMessageType property.
			 * 
			 * @param value
			 *            allowed object is {@link String }
			 * 
			 */
			public void setPayrollMessageType(String value) {
				this.payrollMessageType = value;
			}

		}

	}

	/**
	 * <p>
	 * Java class for anonymous complex type.
	 * 
	 * <p>
	 * The following schema fragment specifies the expected content contained
	 * within this class.
	 * 
	 * <pre>
	 * &lt;complexType>
	 *   &lt;complexContent>
	 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
	 *       &lt;sequence>
	 *         &lt;element name="Sender" type="{http://www.w3.org/2001/XMLSchema}string"/>
	 *         &lt;element name="Receiver" type="{http://www.w3.org/2001/XMLSchema}string"/>
	 *         &lt;element name="MessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
	 *         &lt;element name="MessageDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
	 *         &lt;element name="TimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
	 *       &lt;/sequence>
	 *     &lt;/restriction>
	 *   &lt;/complexContent>
	 * &lt;/complexType>
	 * </pre>
	 * 
	 * 
	 */
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(name = "", propOrder = { "sender", "receiver", "messageType", "messageDescription", "timeStamp" })
	public static class Header {

		@XmlElement(name = "Sender", required = true)
		protected String sender;
		@XmlElement(name = "Receiver", required = true)
		protected String receiver;
		@XmlElement(name = "MessageType", required = true)
		protected String messageType;
		@XmlElement(name = "MessageDescription", required = true)
		protected String messageDescription;
		@XmlElement(name = "TimeStamp", required = true)
		@XmlSchemaType(name = "dateTime")
		protected String timeStamp;

		/**
		 * Gets the value of the sender property.
		 * 
		 * @return possible object is {@link String }
		 * 
		 */
		public String getSender() {
			return sender;
		}

		/**
		 * Sets the value of the sender property.
		 * 
		 * @param value
		 *            allowed object is {@link String }
		 * 
		 */
		public void setSender(String value) {
			this.sender = value;
		}

		/**
		 * Gets the value of the receiver property.
		 * 
		 * @return possible object is {@link String }
		 * 
		 */
		public String getReceiver() {
			return receiver;
		}

		/**
		 * Sets the value of the receiver property.
		 * 
		 * @param value
		 *            allowed object is {@link String }
		 * 
		 */
		public void setReceiver(String value) {
			this.receiver = value;
		}

		/**
		 * Gets the value of the messageType property.
		 * 
		 * @return possible object is {@link String }
		 * 
		 */
		public String getMessageType() {
			return messageType;
		}

		/**
		 * Sets the value of the messageType property.
		 * 
		 * @param value
		 *            allowed object is {@link String }
		 * 
		 */
		public void setMessageType(String value) {
			this.messageType = value;
		}

		/**
		 * Gets the value of the messageDescription property.
		 * 
		 * @return possible object is {@link String }
		 * 
		 */
		public String getMessageDescription() {
			return messageDescription;
		}

		/**
		 * Sets the value of the messageDescription property.
		 * 
		 * @param value
		 *            allowed object is {@link String }
		 * 
		 */
		public void setMessageDescription(String value) {
			this.messageDescription = value;
		}

		/**
		 * Gets the value of the timeStamp property.
		 * 
		 * @return possible object is {@link XMLGregorianCalendar }
		 * 
		 */
		public String getTimeStamp() {
			return timeStamp;
		}

		/**
		 * Sets the value of the timeStamp property.
		 * 
		 * @param value
		 *            allowed object is {@link XMLGregorianCalendar }
		 * 
		 */
		public void setTimeStamp(String value) {
			this.timeStamp = value;
		}

	}

}
