package com.bsf.macug.util;

import java.io.File;

import com.bsf.macug.exception.FileHandlerException;

public interface InterFileUtils {
	byte[] readFile(String path) throws FileHandlerException;
	boolean createFile(String payrollMessage, String customerId, String fileName)
			throws FileHandlerException;
	String getFileExtension(File file);
	String getFileNameWithoutExtension(File file);
	boolean isFileReadyToRead(File file);
	boolean moveFile(File sourceFile, File destinationFile) throws FileHandlerException;
}
