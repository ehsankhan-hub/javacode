package com.bsf.macug.util;

import java.io.IOException;
import java.util.Map;

import com.bsf.macug.application.mail.dto.MailServerDTO;
import com.bsf.macug.exception.SystemPropertyNotConfigurationException;
import com.bsf.macug.general.entity.SystemParameters;

public interface InterUtils {
	public String getTTReference(String sourceSystem);

	public String getFTSReference(String sourceSystem);

	public String getTransactionReference(int i);

	public String getDynamicNarativeReferenceNumber(int i);

	String appendCharacter(String input, int length, String direction, String appender);

	String trimFromEnd(String data, int length);

	Map<String, Map<String, SystemParameters>> loadSystemProperties() throws SystemPropertyNotConfigurationException;

	MailServerDTO getMailDTO();

	String removeStealinkCharacter(byte[] message) throws IOException;
	
	public boolean logMT100Activity(String custName,String fileRefer,String subject, String description, String finOrFileAct, String fileName,Integer staus);
}
