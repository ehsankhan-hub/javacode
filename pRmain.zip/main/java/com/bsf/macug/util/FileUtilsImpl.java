package com.bsf.macug.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Random;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bsf.macug.exception.FileHandlerException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;

@Service
public class FileUtilsImpl implements InterFileUtils {
	private static final Logger logger = Logger.getLogger(FileUtilsImpl.class.getName());

	@Autowired
	InterUtils utils;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Value("${payroll.bkp.ext}")
	private String BK_FILE_EXT;

	@Override
	public byte[] readFile(String path) throws FileHandlerException {
		byte[] byContents = null;
		FileInputStream fin = null;
		try {
			if (path != null) {
				File fPath = new File(path);
				if (fPath.exists() && fPath.canRead()) {
					fin = new FileInputStream(fPath);
					byContents = new byte[fin.available()];
					fin.read(byContents, 0, fin.available());
				} else {
					throw new FileHandlerException("Cannot read file contents");
				}
			} else {
				throw new FileHandlerException("Cannot read file contents");
			}
		} catch (Exception e) {
			throw new FileHandlerException("Error in reading file contents");
		} finally {
			if (fin != null) {
				try {
					fin.close();
				} catch (IOException e) {
					logger.error("Error in closing file", e);
				}
			}
		}
		return byContents;
	}

	@Override
	public boolean moveFile(File sourceFile, File destinationFile) throws FileHandlerException {
		boolean status = false;
		try {
			Map<String, Map<String, SystemParameters>> allProperties = utils.loadSystemProperties();
			Map<String, SystemParameters> macPathProperties = allProperties.get("macPathMap");
			String errorPath = systemParameterService.getSystemParametersDescription2("PAYROLL_ERR", macPathProperties);

			if (destinationFile.exists()) {
				logger.info("File exist in destination folder.");
				File errorFile = new File(errorPath + sourceFile.getName());
				if (errorFile.exists()) {
					Random rand = new Random();
					int n = rand.nextInt(1000) + 1;
					String newName = "DUPLICATE_" + n + "_" + sourceFile.getName();
					logger.info("File exist in error folder also. Prefixing with " + "DUPLICATE_" + n + "_");
					errorFile = new File(errorPath + newName);
				}
				if (!moveFile(sourceFile, errorFile)) {
					errorFile = new File(errorPath + sourceFile.getName());
					moveFile(sourceFile, errorFile);
				}
				throw new FileHandlerException("Same file already exist in destination folder. Failed to move.");

			}
			logger.info("Moving file from path : " + sourceFile.getAbsolutePath() + "  to path : "
					+ destinationFile.getAbsolutePath());
			status = sourceFile.renameTo(destinationFile);

			if (!status) {
				throw new FileHandlerException("Error while moving the file.");
			}

			String bkSourceFileName = getFileNameWithoutExtension(sourceFile);
			String bkDestFileName = getFileNameWithoutExtension(destinationFile);
			String sourceDir = sourceFile.getParent();
			String destinationDir = destinationFile.getParent();

			File bkSourceFile = new File(sourceDir + "\\" + bkSourceFileName + BK_FILE_EXT);
			File bkDestinationFile = new File(destinationDir + "\\" + bkDestFileName + BK_FILE_EXT);

			status = bkSourceFile.renameTo(bkDestinationFile);

			if (!status) {
				throw new FileHandlerException("Error while moving the file.");
			} else {
				logger.info("File from path : " + sourceFile.getAbsolutePath() + "  to path : "
						+ destinationFile.getAbsolutePath() + "  ---Moved successfully.");
			}
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new FileHandlerException("Error while moving the file.");
		}
		return status;
	}

	@Override
	public boolean createFile(String payrollMessage, String customerId, String fileName)
			throws FileHandlerException {
		boolean status = false;
		try {
			Map<String, Map<String, SystemParameters>> allProperties = utils.loadSystemProperties();
			Map<String, SystemParameters> macPathProperties = allProperties.get("macPathMap");
			String sourcePath = systemParameterService.getSystemParametersDescription2("PAYROLL_OUT",
					macPathProperties);
			//sourcePath = sourcePath + customerId;
			File sourceFolder = new File(sourcePath);
			if (!sourceFolder.exists()) {
				sourceFolder.mkdirs();
			}
			FileOutputStream fos = null;
			fos = new FileOutputStream(sourcePath + fileName);
			fos.write(payrollMessage.getBytes("UTF-8"));
			fos.close();
			status = true;

		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new FileHandlerException("Error while moving the file.");
		}
		return status;
	}

	@Override
	public String getFileExtension(File file) {
		String extension = "";
		try {
			extension = FilenameUtils.getExtension(file.getName());
		} catch (Exception e) {
			extension = "";
			logger.error("Error : " + e.getMessage(), e);
		}
		return extension;
	}

	@Override
	public String getFileNameWithoutExtension(File file) {
		String fileNameWithOutExt = "";
		try {
			fileNameWithOutExt = FilenameUtils.removeExtension(file.getName());
		} catch (Exception e) {
			fileNameWithOutExt = "";
			logger.error("Error : " + e.getMessage(), e);
		}
		return fileNameWithOutExt;
	}

	@Override
	public boolean isFileReadyToRead(File file) {
		try {
			if (!file.isFile()) {
				return false;
			}
			String fileName = getFileNameWithoutExtension(file);
			String direcotryPath = file.getParent();
			File histFile = new File(direcotryPath + "\\" + fileName + BK_FILE_EXT);
			if (histFile.exists()) {
				return true;
			}

		} catch (Exception e) {
			logger.error("Error :" + e.getMessage(), e);
		}

		return false;
	}

}
