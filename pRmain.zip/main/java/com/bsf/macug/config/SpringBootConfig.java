package com.bsf.macug.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.bsf.macug.payroll.service.InterPayrollProcess;
/**
 * Created by Ehsan.
 */
@SpringBootApplication
@ComponentScan("com.bsf.macug")
public class SpringBootConfig implements CommandLineRunner {
	
	@Autowired
	InterPayrollProcess payrollProcess;
	
    public static void main(String[] args) throws Exception {
        SpringApplication.run(SpringBootConfig.class, args);           
    }

	@Override
	public void run(String... arg0) throws Exception {
		payrollProcess.processFile();
	}
}