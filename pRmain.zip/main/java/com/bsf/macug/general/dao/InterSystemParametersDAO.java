package com.bsf.macug.general.dao;

import java.util.List;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.general.entity.SystemParameters;

public interface InterSystemParametersDAO {
	SystemParameters getSystemParameters(String tableCode, String itemCode)
			throws DataAccessException;

	List<SystemParameters> getSystemParametersByTableCode(String tableCode)
			throws DataAccessException;

	public List<SystemParameters> getSystemParameterList(String searchParam,
			String sSearch, int displaystart, int idisplaylength)
			throws DataAccessException;

	boolean saveSystemParameter(SystemParameters details)
			throws DataAccessException;
	
	boolean updateSystemParameter(SystemParameters details)
			throws DataAccessException;

	Long getRecordCount(String searchParam, String sSearch)
			throws DataAccessException;
}
