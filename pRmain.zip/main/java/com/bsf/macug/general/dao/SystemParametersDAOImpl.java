package com.bsf.macug.general.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.general.entity.SystemParameters;

@Repository("systemParameterDao")
public class SystemParametersDAOImpl implements InterSystemParametersDAO {

	private static final Logger logger = Logger
			.getLogger(SystemParametersDAOImpl.class.getName());

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public SystemParameters getSystemParameters(String tableCode,
			String itemCode) throws DataAccessException {
		SystemParameters systemProperties = null;
		Session session = null;
		try {
			logger.info("************getSystemParameters STARTED");
			session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(SystemParameters.class);
			tableCode = appendSpaces(tableCode, 9, "R");
			itemCode = appendSpaces(itemCode, 20, "R");
			criteria.add(Restrictions.eq("tableCode", tableCode));
			criteria.add(Restrictions.eq("itemCode", itemCode.toUpperCase()));
			systemProperties = (SystemParameters) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error while fetching data for table code :"
					+ tableCode + " and item code : " + itemCode + ". Error :"
					+ e.getMessage(), e);
			throw new DataAccessException(
					"Error while fetching data for table code :" + tableCode
							+ " and item code : " + itemCode);
		}
		logger.info("******** getSystemParameters STARTED END");
		return systemProperties;
	}

	@Override
	public List<SystemParameters> getSystemParametersByTableCode(
			String tableCode) throws DataAccessException {
		List<SystemParameters> systemPropertiesList = null;
		Session session = null;
		try {
			logger.info("************getSystemParametersByTableCode STARTED");
			session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(SystemParameters.class);
			tableCode = appendSpaces(tableCode, 9, "R");
			criteria.add(Restrictions.eq("tableCode", tableCode));
			systemPropertiesList = criteria.list();
		} catch (Exception e) {
			logger.error("Error while fetching data for table code :"
					+ tableCode + " . Error :" + e.getMessage(), e);
			throw new DataAccessException(
					"Error while fetching data for table code :" + tableCode);
		}
		logger.info("******** getSystemParametersByTableCode STARTED END");
		return systemPropertiesList;
	}

	@Override
	public List<SystemParameters> getSystemParameterList(String searchParam,
			String sSearch, int displaystart, int idisplaylength)
			throws DataAccessException {
		List<SystemParameters> paramList = null;
		try {
			logger.info("************getSystemParameterList STARTED");
			Criteria criteria = getSearchCriteria(searchParam, sSearch);
			criteria.setFirstResult(displaystart);
			criteria.setMaxResults(idisplaylength);
			paramList = criteria.list();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new DataAccessException(
					"Error while fetching system parameter list.");
		}
		logger.info("******** getSystemParameterList STARTED END");
		return paramList;
	}

	private Criteria getSearchCriteria(String searchParam, String sSearch)
			throws DataAccessException {
		Criteria criteria = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			criteria = session.createCriteria(SystemParameters.class);
			JSONParser parser = new JSONParser();
			String tableCode = null;
			String itemCode = null;
			if (!StringUtils.isEmpty(searchParam)) {
				JSONObject searchObject = (JSONObject) parser
						.parse(searchParam);
				tableCode = (String) searchObject.get("tableCode");
				itemCode = (String) searchObject.get("itemCode");
			}
			if (!StringUtils.isEmpty(tableCode)) {
				tableCode = appendSpaces(tableCode, 9, "R");
				criteria.add(Restrictions.eq("tableCode", tableCode));
			}
			if (!StringUtils.isEmpty(itemCode)) {
				itemCode = appendSpaces(itemCode, 20, "R");
				criteria.add(Restrictions.eq("itemCode", itemCode));
			}
			if (sSearch != null && !sSearch.isEmpty()) {
				Disjunction or = Restrictions.disjunction();
				or.add(Restrictions.like("itemCode", sSearch + "%")
						.ignoreCase());
				criteria.add(or);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new DataAccessException("Error while creating criteria.");
		}
		return criteria;
	}

	@Override
	public boolean saveSystemParameter(SystemParameters details)
			throws DataAccessException {
		Session session = null;
		boolean status = false;
		try {
			logger.info("************saveSystemParameter STARTED");
			session = sessionFactory.getCurrentSession();
			session.save(details);
			status = true;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new DataAccessException(
					"Error ehile saving system paramete details");
		}
		logger.info("*********saveSystemParameter STARTED END");
		return status;
	}

	@Override
	public boolean updateSystemParameter(SystemParameters details)
			throws DataAccessException {
		Session session = null;
		boolean status = false;
		try {
			logger.info("************updateSystemParameter STARTED");
			session = sessionFactory.getCurrentSession();
			session.update(details);
			status = true;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new DataAccessException(
					"Error ehile updating system parameter details");
		}
		logger.info("*********updateSystemParameter STARTED END");
		return status;
	}

	@Override
	public Long getRecordCount(String searchParam, String sSearch)
			throws DataAccessException {
		Long count = (long) 0;
		try {
			Criteria criteria = getSearchCriteria(searchParam, sSearch);
			count = (Long) criteria.setProjection(Projections.rowCount())
					.uniqueResult();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new DataAccessException("Error while fetching record count.");
		}
		return count;
	}
	private String appendSpaces(String input, int length,
			String direction) {
		int spacesToAppend = length - input.length();

		StringBuilder spaces = new StringBuilder();
		for (int i = 0; i < spacesToAppend; i++) {
			spaces.append(' ');
		}

		if (direction.equalsIgnoreCase("R")) {
			input = input + spaces.toString();
		} else {
			input = spaces.toString() + input;
		}

		return input;
	}

}
