package com.bsf.macug.general.service;

import java.util.List;

import com.bsf.macug.general.entity.NotificationDetails;

public interface InterNotificationDetailsService {
	NotificationDetails getNotificationDetails(String notificationId);

	public List<NotificationDetails> getNotificationDetailsList(
			String searchParam, String sSearch, int displaystart,
			int idisplaylength);

	boolean saveNotificationDetails(NotificationDetails details);

	boolean updateNotificationDetails(NotificationDetails details);
	
	public List<NotificationDetails> getNotificationDetailsListByStatus(String status);
}
