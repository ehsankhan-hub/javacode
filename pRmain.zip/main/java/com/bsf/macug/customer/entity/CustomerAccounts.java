package com.bsf.macug.customer.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.bsf.macug.util.IConstants;

@Entity
@Table(name = "MAC_CUST_ACCOUNTS")
public class CustomerAccounts implements Serializable {

	@Id
	@Column(name = "CUST_ID")
	private String customerId;
	@Id
	@Column(name = "ACC_NUMBER")
	private String accountNumber;
	@Id
	@Column(name = "ACC_SERVICE")
	private String accountService;
	@Column(name = "CURRENCY_CODE")
	private String currencyCode;
	@Column(name = "BIC_CODE")
	private String bicCode;
	@Column(name = "ACC_TRANSFER_LIMIT")
	private String accountTransferLimit;
	@Column(name = "ACC_STATUS")
	private String accountStatus;

	@Column(name = "CREATED_ID")
	private String customerCraetedId;
	@Column(name = "VERIFIED_ID")
	private String customerVerifiedId;
	@Column(name = "CREATED_DATE")
	@Temporal(TemporalType.DATE)
	private Date customerCraetedDate;
	@Column(name = "VERIFIED_DATE")
	@Temporal(TemporalType.DATE)
	private Date customerVarifiedDate;

	@Column(name = "MODIFIED_ID")
	private String modifiedId;
	
	@Column(name = "MODIFIED_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;
	
	
	@Column(name = "SEQUENCE_NUMBER")
	private Integer sequenceNumber;
	
	@Column(name = "RATE_INDICATOR")
	@Enumerated(EnumType.ORDINAL)
	private IConstants.RATE_INDICATOR rateIndicator;
	
	@Column(name = "MT940_GEN_FLAG")
	private Integer mt940generateFlag;
	
	public CustomerAccounts() {
	}

	public CustomerAccounts(String customerId, String accountNumber,
			String accountService, String currencyCode, String bicCode,
			String accountTransferLimit, String accountStatus,
			String customerCraetedId, String customerVerifiedId,
			Date customerCraetedDate, Date customerVarifiedDate, int sequenceNumber) {
		super();
		this.customerId = customerId;
		this.accountNumber = accountNumber;
		this.accountService = accountService;
		this.currencyCode = currencyCode;
		this.bicCode = bicCode;
		this.accountTransferLimit = accountTransferLimit;
		this.accountStatus = accountStatus;
		this.customerCraetedId = customerCraetedId;
		this.customerVerifiedId = customerVerifiedId;
		this.customerCraetedDate = customerCraetedDate;
		this.customerVarifiedDate = customerVarifiedDate;
		this.sequenceNumber =  sequenceNumber;
		
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountService() {
		return accountService;
	}

	public void setAccountService(String accountService) {
		this.accountService = accountService;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getBicCode() {
		return bicCode;
	}

	public void setBicCode(String bicCode) {
		this.bicCode = bicCode;
	}

	public String getAccountTransferLimit() {
		return accountTransferLimit;
	}

	public void setAccountTransferLimit(String accountTransferLimit) {
		this.accountTransferLimit = accountTransferLimit;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public String getCustomerCraetedId() {
		return customerCraetedId;
	}

	public void setCustomerCraetedId(String customerCraetedId) {
		this.customerCraetedId = customerCraetedId;
	}

	public String getCustomerVerifiedId() {
		return customerVerifiedId;
	}

	public void setCustomerVerifiedId(String customerVerifiedId) {
		this.customerVerifiedId = customerVerifiedId;
	}

	public Date getCustomerCraetedDate() {
		return customerCraetedDate;
	}

	public void setCustomerCraetedDate(Date customerCraetedDate) {
		this.customerCraetedDate = customerCraetedDate;
	}

	public Date getCustomerVarifiedDate() {
		return customerVarifiedDate;
	}

	public void setCustomerVarifiedDate(Date customerVarifiedDate) {
		this.customerVarifiedDate = customerVarifiedDate;
	}

	public String getModifiedId() {
		return modifiedId;
	}

	public void setModifiedId(String modifiedId) {
		this.modifiedId = modifiedId;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(Integer sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public IConstants.RATE_INDICATOR getRateIndicator() {
		return rateIndicator;
	}

	public void setRateIndicator(IConstants.RATE_INDICATOR rateIndicator) {
		this.rateIndicator = rateIndicator;
	}

	public Integer getMt940generateFlag() {
		return mt940generateFlag;
	}

	public void setMt940generateFlag(Integer mt940generateFlag) {
		this.mt940generateFlag = mt940generateFlag;
	}

		
	
}
