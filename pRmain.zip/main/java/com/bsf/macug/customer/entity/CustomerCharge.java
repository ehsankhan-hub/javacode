package com.bsf.macug.customer.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "MAC_CUST_CHARGE")
public class CustomerCharge implements Serializable {
	@Id
	@Column(name = "CUST_ID")
	private String customerId;
	@Id
	@Column(name = "CHARGE_SERVICES")
	private String services;
	@Id
	@Column(name = "CHARGE_PAYMENTTYPE")
	private String paymentType;

	@Column(name = "CHARGE_AMOUNT")
	private BigDecimal chargeAmount;
	@Column(name = "CHARGE_STATUS")
	private String status;
	@Column(name = "CHARGE_SLABFLAG")
	private Integer slabFlag;

	@Column(name = "CREATED_ID")
	private String customerCreatedId;
	@Column(name = "VERIFIED_ID")
	private String customerVerifiedId;
	@Column(name = "CREATED_DATE")
	@Temporal(TemporalType.DATE)
	private Date customerCreatedDate;
	@Column(name = "VERIFIED_DATE")
	@Temporal(TemporalType.DATE)
	private Date customerVarifiedDate;

	@Column(name = "MODIFIED_ID")
	private String modifiedId;
	
	@Column(name = "MODIFIED_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;
	public CustomerCharge() {
	}

	public CustomerCharge(String customerId, String services,
			String paymentType, BigDecimal chargeAmount, String status,
			Integer slabFlag, String customerCreatedId,
			String customerVerifiedId, Date customerCreatedDate,
			Date customerVarifiedDate) {
		super();
		this.customerId = customerId;
		this.services = services;
		this.paymentType = paymentType;
		this.chargeAmount = chargeAmount;
		this.status = status;
		this.slabFlag = slabFlag;
		this.customerCreatedId = customerCreatedId;
		this.customerVerifiedId = customerVerifiedId;
		this.customerCreatedDate = customerCreatedDate;
		this.customerVarifiedDate = customerVarifiedDate;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getServices() {
		return services;
	}

	public void setServices(String services) {
		this.services = services;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public BigDecimal getChargeAmount() {
		return chargeAmount;
	}

	public void setChargeAmount(BigDecimal chargeAmount) {
		this.chargeAmount = chargeAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getSlabFlag() {
		return slabFlag;
	}

	public void setSlabFlag(Integer slabFlag) {
		this.slabFlag = slabFlag;
	}

	public String getCustomerCreatedId() {
		return customerCreatedId;
	}

	public void setCustomerCreatedId(String customerCreatedId) {
		this.customerCreatedId = customerCreatedId;
	}

	public String getCustomerVerifiedId() {
		return customerVerifiedId;
	}

	public void setCustomerVerifiedId(String customerVerifiedId) {
		this.customerVerifiedId = customerVerifiedId;
	}

	public Date getCustomerCreatedDate() {
		return customerCreatedDate;
	}

	public void setCustomerCreatedDate(Date customerCreatedDate) {
		this.customerCreatedDate = customerCreatedDate;
	}

	public Date getCustomerVarifiedDate() {
		return customerVarifiedDate;
	}

	public void setCustomerVarifiedDate(Date customerVarifiedDate) {
		this.customerVarifiedDate = customerVarifiedDate;
	}

	public String getModifiedId() {
		return modifiedId;
	}

	public void setModifiedId(String modifiedId) {
		this.modifiedId = modifiedId;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	
}
