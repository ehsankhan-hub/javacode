package com.bsf.macug.customer.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "MAC_CUST_DETAILS")
public class CustomerDetails implements Serializable {
	@Id
	@Column(name = "CUST_ID")
	private String customerId;
	@Column(name = "CUST_NAME")
	private String customerName;
	@Column(name = "CUST_CATEGORY")
	private String customerCategory;
	@Column(name = "CUST_VALUEDATE_FLAG")
	private String customerValueDateFlag;
	@Column(name = "CUST_MOLID")
	private String customerMolId;
	@Column(name = "CUST_PERSON")
	private String customerPerson;
	@Column(name = "CUST_ADDRESS")
	private String customerAddress;
	@Column(name = "COUNTRY_CODE")
	private String customerCountryCode;
	@Column(name = "CUST_ZIPCODE")
	private String customerZipCode;
	@Column(name = "CUST_EMAIL")
	private String customerEmail;
	@Column(name = "CUST_PHONE")
	private String customerPhone;
	@Column(name = "CUST_MOBILE")
	private String customerMobile;
	@Column(name = "CUST_STATUS")
	private String customerStatus;
	@Column(name = "CREATED_ID")
	private String customerCraetedId;
	@Column(name = "VERIFIED_ID")
	private String customerVerifiedId;
	@Column(name = "CREATED_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date customerCraetedDate;
	@Column(name = "VERIFIED_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date customerVarifiedDate;
	
	@Column(name = "SWNET_SERVICE")
	private String swNetServicName;
	@Column(name = "CUST_NAME_FULL")
	private String custNameFull;
	
	@Column(name = "MT199_FLAG")
	private String mt199BulkFlag;

	@Column(name = "MODIFIED_ID")
	private String modifiedId;

	@Column(name = "MODIFIED_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	@Column(name = "WPS_FLAG")
	private String wpsFlag; // Y or N default N

	@Column(name = "CUST_REPLY_TAG20")
	private String tag20ReplyFlag; // Y or N default N

	@Column(name = "PAYROLL_ID")
	private String payrollId;

	@Column(name = "MT940_ARABIC_FLAG")
	private String mt940ArabicFlag;

	@Column(name = "PAYROLL_BAL_CHECK")
	private String payrollBalanceCheckFlag;

	@Column(name = "PAMENT_SERIES")
	private Integer paymentSeries;
	
	@Column(name = "RESPONSE_FILE_VALUE")
	private String responseFileValue;
	
	public CustomerDetails() {
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerCategory() {
		return customerCategory;
	}

	public void setCustomerCategory(String customerCategory) {
		this.customerCategory = customerCategory;
	}

	public String getCustomerValueDateFlag() {
		return customerValueDateFlag;
	}

	public void setCustomerValueDateFlag(String customerValueDateFlag) {
		this.customerValueDateFlag = customerValueDateFlag;
	}

	public String getCustomerMolId() {
		return customerMolId;
	}

	public void setCustomerMolId(String customerMolId) {
		this.customerMolId = customerMolId;
	}

	public String getCustomerPerson() {
		return customerPerson;
	}

	public void setCustomerPerson(String customerPerson) {
		this.customerPerson = customerPerson;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerCountryCode() {
		return customerCountryCode;
	}

	public void setCustomerCountryCode(String customerCountryCode) {
		this.customerCountryCode = customerCountryCode;
	}

	public String getCustomerZipCode() {
		return customerZipCode;
	}

	public void setCustomerZipCode(String customerZipCode) {
		this.customerZipCode = customerZipCode;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getCustomerMobile() {
		return customerMobile;
	}

	public void setCustomerMobile(String customerMobile) {
		this.customerMobile = customerMobile;
	}

	public String getCustomerStatus() {
		return customerStatus;
	}

	public void setCustomerStatus(String customerStatus) {
		this.customerStatus = customerStatus;
	}

	public String getCustomerCraetedId() {
		return customerCraetedId;
	}

	public void setCustomerCraetedId(String customerCraetedId) {
		this.customerCraetedId = customerCraetedId;
	}

	public String getCustomerVerifiedId() {
		return customerVerifiedId;
	}

	public void setCustomerVerifiedId(String customerVerifiedId) {
		this.customerVerifiedId = customerVerifiedId;
	}

	public Date getCustomerCraetedDate() {
		return customerCraetedDate;
	}

	public void setCustomerCraetedDate(Date customerCraetedDate) {
		this.customerCraetedDate = customerCraetedDate;
	}

	public Date getCustomerVarifiedDate() {
		return customerVarifiedDate;
	}

	public void setCustomerVarifiedDate(Date customerVarifiedDate) {
		this.customerVarifiedDate = customerVarifiedDate;
	}

	public String getModifiedId() {
		return modifiedId;
	}

	public void setModifiedId(String modifiedId) {
		this.modifiedId = modifiedId;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getWpsFlag() {
		return wpsFlag;
	}

	public void setWpsFlag(String wpsFlag) {
		this.wpsFlag = wpsFlag;
	}

	public String getTag20ReplyFlag() {
		return tag20ReplyFlag;
	}

	public void setTag20ReplyFlag(String tag20ReplyFlag) {
		this.tag20ReplyFlag = tag20ReplyFlag;
	}

	public String getPayrollId() {
		return payrollId;
	}

	public void setPayrollId(String payrollId) {
		this.payrollId = payrollId;
	}

	public String getMt940ArabicFlag() {
		return mt940ArabicFlag;
	}

	public void setMt940ArabicFlag(String mt940ArabicFlag) {
		this.mt940ArabicFlag = mt940ArabicFlag;
	}

	public String getPayrollBalanceCheckFlag() {
		return payrollBalanceCheckFlag;
	}

	public void setPayrollBalanceCheckFlag(String payrollBalanceCheckFlag) {
		this.payrollBalanceCheckFlag = payrollBalanceCheckFlag;
	}

	public Integer getPaymentSeries() {
		return paymentSeries;
	}

	public void setPaymentSeries(Integer paymentSeries) {
		this.paymentSeries = paymentSeries;
	}

	public String getResponseFileValue() {
		return responseFileValue;
	}

	public void setResponseFileValue(String responseFileValue) {
		this.responseFileValue = responseFileValue;
	}

	public String getSwNetServicName() {
		return swNetServicName;
	}

	public void setSwNetServicName(String swNetServicName) {
		this.swNetServicName = swNetServicName;
	}

	public String getCustNameFull() {
		return custNameFull;
	}

	public void setCustNameFull(String custNameFull) {
		this.custNameFull = custNameFull;
	}

	public String getMt199BulkFlag() {
		return mt199BulkFlag;
	}

	public void setMt199BulkFlag(String mt199BulkFlag) {
		this.mt199BulkFlag = mt199BulkFlag;
	}

	
	
	
	

}
