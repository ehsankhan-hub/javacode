package com.bsf.macug.customer.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "MAC_CUST_LIMITS")
public class CustomerLimits implements Serializable {
	@Id
	@Column(name = "CUST_ID")
	private String customerId;
	@Id
	@Column(name = "LIMITS_VALUEDATE")
	@Temporal(TemporalType.DATE)
	private Date valueDate;
	@Column(name = "LIMITS_CORP_AVAILABLE")
	private BigDecimal availableCorporateLimit;

	@Column(name = "LIMITS_BSF_AVAILABLE")
	private BigDecimal availableBSFLimit;

	@Column(name = "LIMITS_SARIE_AVAILABLE")
	private BigDecimal availableSARIELimit;

	@Column(name = "LIMITS_SWIFT_AVAILABLE")
	private BigDecimal availableSWIFTLimit;

	@Column(name = "LIMITS_CREATED")
	@Temporal(TemporalType.TIMESTAMP)
	private Date limitsCreated;

	@Column(name = "MODIFIED_ID")
	private String modifiedId;

	@Column(name = "MODIFIED_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public CustomerLimits() {
	}

	public CustomerLimits(String customerId, Date valueDate,
			BigDecimal availableCorporateLimit, BigDecimal availableBSFLimit,
			BigDecimal availableSARIELimit, BigDecimal availableSWIFTLimit,
			Date limitsCreated) {
		super();
		this.customerId = customerId;
		this.valueDate = valueDate;
		this.availableCorporateLimit = availableCorporateLimit;
		this.availableBSFLimit = availableBSFLimit;
		this.availableSARIELimit = availableSARIELimit;
		this.availableSWIFTLimit = availableSWIFTLimit;
		this.limitsCreated = limitsCreated;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Date getValueDate() {
		return valueDate;
	}

	public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}

	public BigDecimal getAvailableCorporateLimit() {
		return availableCorporateLimit;
	}

	public void setAvailableCorporateLimit(BigDecimal availableCorporateLimit) {
		this.availableCorporateLimit = availableCorporateLimit;
	}

	public BigDecimal getAvailableBSFLimit() {
		return availableBSFLimit;
	}

	public void setAvailableBSFLimit(BigDecimal availableBSFLimit) {
		this.availableBSFLimit = availableBSFLimit;
	}

	public BigDecimal getAvailableSARIELimit() {
		return availableSARIELimit;
	}

	public void setAvailableSARIELimit(BigDecimal availableSARIELimit) {
		this.availableSARIELimit = availableSARIELimit;
	}

	public BigDecimal getAvailableSWIFTLimit() {
		return availableSWIFTLimit;
	}

	public void setAvailableSWIFTLimit(BigDecimal availableSWIFTLimit) {
		this.availableSWIFTLimit = availableSWIFTLimit;
	}

	public Date getLimitsCreated() {
		return limitsCreated;
	}

	public void setLimitsCreated(Date limitsCreated) {
		this.limitsCreated = limitsCreated;
	}

	public String getModifiedId() {
		return modifiedId;
	}

	public void setModifiedId(String modifiedId) {
		this.modifiedId = modifiedId;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	@Override
	public String toString() {
		return "CustomerLimits [customerId=" + customerId + ", valueDate="
				+ valueDate + ", availableCorporateLimit="
				+ availableCorporateLimit + ", availableBSFLimit="
				+ availableBSFLimit + ", availableSARIELimit="
				+ availableSARIELimit + ", availableSWIFTLimit="
				+ availableSWIFTLimit + ", limitsCreated=" + limitsCreated
				+ ", modifiedId=" + modifiedId + ", modifiedDate="
				+ modifiedDate + "]";
	}

}
