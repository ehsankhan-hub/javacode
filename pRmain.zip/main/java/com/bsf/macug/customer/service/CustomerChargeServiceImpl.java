package com.bsf.macug.customer.service;

import java.math.BigDecimal;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.dao.InterCustomerChargeDAO;
import com.bsf.macug.customer.entity.CustomerCharge;
import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.exception.ProcessException;

@Service("customerChargeService")
@Transactional
public class CustomerChargeServiceImpl implements InterCustomerChargeService {

	private static final Logger logger = Logger
			.getLogger(CustomerChargeServiceImpl.class.getName());

	@Autowired
	InterCustomerChargeDAO customerChargeDao;

	@Override
	public BigDecimal getCharge(String customerId, String services,
			String paymentType) throws ProcessException, DataAccessException  {
		BigDecimal charge = new BigDecimal("0");
		logger.info("(getCharge)==> Get the charge for customer "+customerId+" service "+services+" type "+paymentType);
		if(!(StringUtils.isEmpty(customerId) && StringUtils.isEmpty(services) && StringUtils.isEmpty(paymentType))){
			CustomerCharge customerCharge = customerChargeDao.getCustomerCharge(customerId, services, paymentType);
			if(customerCharge != null){
				int slabFlag = customerCharge.getSlabFlag();
				logger.info("(getCharge)==> Slab flag is "+slabFlag);
				if(slabFlag != 1){
					charge = customerCharge.getChargeAmount();
					if(charge == null){
						charge = new BigDecimal("0");
					}
					logger.info("(getCharge)==> Charge amount is "+charge);
				}else{
					charge = new BigDecimal("0");
					logger.info("(getCharge)==> Slab based calculation");
					//slab calculation later...
				}
			}else{
				charge = new BigDecimal("0");
				logger.info("(getCharge)==> Cannot locate customer charge");
			}
		}else{
			charge = new BigDecimal("0");
			logger.info("(getCharge)==> Charge search parameters cannot be null or empty");
		}
		return charge;
	}

}
