package com.bsf.macug.customer.dao;

import java.util.Date;

import com.bsf.macug.customer.entity.CustomerLimits;
import com.bsf.macug.exception.DataAccessException;

public interface InterCustomerLimitsDAO {
	
	boolean saveLimitDetails(CustomerLimits limits) throws DataAccessException;

	boolean updateLimitDetails(CustomerLimits limits)
			throws DataAccessException;

	CustomerLimits getCustomerLimits(String customerId, Date valueDate)
			throws DataAccessException;
}
