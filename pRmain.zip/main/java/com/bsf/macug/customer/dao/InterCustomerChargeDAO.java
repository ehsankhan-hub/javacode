package com.bsf.macug.customer.dao;

import com.bsf.macug.customer.entity.CustomerCharge;
import com.bsf.macug.exception.DataAccessException;

public interface InterCustomerChargeDAO {
	
	CustomerCharge getCustomerCharge(String customerID, String services,
			String paymentType) throws DataAccessException;
}
