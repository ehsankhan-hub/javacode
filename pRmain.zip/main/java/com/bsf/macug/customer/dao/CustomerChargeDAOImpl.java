package com.bsf.macug.customer.dao;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.entity.CustomerCharge;
import com.bsf.macug.exception.DataAccessException;

@Repository("customerChargeDao")
public class CustomerChargeDAOImpl implements InterCustomerChargeDAO {

	private static final Logger logger = Logger.getLogger(CustomerChargeDAOImpl.class.getName());

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public CustomerCharge getCustomerCharge(String customerID, String services,
			String paymentType)  throws DataAccessException {
		CustomerCharge customerCharge = null;
		Session session = null;
		logger.info("(getCustomerCharge)==> Customer "+customerID+" service "+services+" type "+paymentType);
		if(!(StringUtils.isEmpty(customerID) && StringUtils.isEmpty(services) && StringUtils.isEmpty(paymentType))){
			try {
				logger.info("(getCustomerCharge)==> Fetching customer charges");
				session = sessionFactory.getCurrentSession();
				Criteria criteria = session.createCriteria(CustomerCharge.class);
				criteria.add(Restrictions.eq("customerId", customerID));
				criteria.add(Restrictions.eq("services", services));
				criteria.add(Restrictions.eq("paymentType", paymentType));
				criteria.add(Restrictions.eq("status", "ACTIVE"));
				customerCharge = (CustomerCharge) criteria.uniqueResult();
			} catch (Exception e) {
				logger.error("(getCustomerCharge)==> Error in getting customer charge . Error "+e.getMessage(), e);
				throw new DataAccessException(" Error in getting customer charge");
			}
		}else{
			logger.info("(getCustomerCharge)==> Customer charge cannot be null or empty");
		}
		return customerCharge;
	}

}
