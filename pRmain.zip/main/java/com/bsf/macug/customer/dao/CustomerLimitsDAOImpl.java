package com.bsf.macug.customer.dao;

import java.util.Date;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.entity.CustomerLimits;

@Repository("customerLimitsDao")
public class CustomerLimitsDAOImpl implements InterCustomerLimitsDAO{

	private static final Logger logger = Logger
			.getLogger(CustomerLimitsDAOImpl.class.getName());

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public boolean saveLimitDetails(CustomerLimits limits) {
		Session session = null;
		boolean status = false;
		logger.info("(saveLimitDetails)==> Saving customer limits. "+limits);
		if(limits!=null){
			try {
				session = sessionFactory.getCurrentSession();
				session.save(limits);
				status = true;
			} catch (Exception e) {
				logger.error("(saveLimitDetails)==>Error in saving limits "+e.getMessage(), e);
			}
		}else{
			logger.info("(saveLimitDetails)==> Customer limits cannot be null or empty.");
		}
		return status;
	}

	@Override
	public boolean updateLimitDetails(CustomerLimits limits) {
		Session session = null;
		boolean status = false;
		logger.info("(updateLimitDetails)==> Updating limits");
		if(limits!=null){
			try {
				session = sessionFactory.getCurrentSession();
				session.update(limits);
				status = true;
			} catch (Exception e) {
				logger.error("(updateLimitDetails)==> Error in updating customer limits "+e.getMessage(), e);
			}
		}else{
			logger.info("(updateLimitDetails)==> Customer limits cannot be null or empty.");
		}
		return status;
	}

	@Override
	public CustomerLimits getCustomerLimits(String customerId, Date valueDate) {
		CustomerLimits limits = null;
		Session session = null;
		logger.info("(getCustomerLimits)==> Fetch customer limit");
		if(!StringUtils.isEmpty(customerId)){
			if(valueDate!=null){
				try {
					session = sessionFactory.getCurrentSession();
					Criteria criteria = session.createCriteria(CustomerLimits.class);
					criteria.add(Restrictions.eq("customerId", customerId));
					criteria.add(Restrictions.eq("valueDate", valueDate));
					limits = (CustomerLimits) criteria.uniqueResult();
				} catch (Exception e) {
					logger.error("(getCustomerLimits)==> Error in getting customer limit. Error "+e.getMessage(), e);
				}
			}else{
				logger.info("(getCustomerLimits)==> Value date cannot be null or empty");
			}
		}else{
			logger.info("(getCustomerLimits)==> Customer id cannot be null or empty");
		}
		return limits;
	}

}
