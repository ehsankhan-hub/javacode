package com.bsf.macug.customer.dao;

import java.util.List;

import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.exception.DataAccessException;

public interface InterCustomerAccountsDAO {
	
	CustomerAccounts getCustomerAccountDetails(String clientId,
			String accountNumber, String accountService)
			throws DataAccessException;

	List<CustomerAccounts> listAllActiveAccounts(String strCustomer, String string) throws DataAccessException;

	Integer getSequenceByAccount(String companyCode, String strAccount) throws DataAccessException;
}
