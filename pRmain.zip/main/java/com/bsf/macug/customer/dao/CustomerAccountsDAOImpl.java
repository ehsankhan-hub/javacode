package com.bsf.macug.customer.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.exception.DataAccessException;

@Repository("customerAccountsDao")
public class CustomerAccountsDAOImpl implements InterCustomerAccountsDAO {
	
	private final Logger logger = Logger
			.getLogger(CustomerAccountsDAOImpl.class.getName());

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public CustomerAccounts getCustomerAccountDetails(String customerId,
			String accountNumber, String accountService)
			throws DataAccessException {
		
		CustomerAccounts client = null;
		Session session = null;
		if(!(StringUtils.isEmpty(customerId) && StringUtils.isEmpty(accountNumber) && StringUtils.isEmpty(accountService))){
			try {
				session = sessionFactory.getCurrentSession();
				
				logger.info("customerId--"+customerId);
				logger.info("accountNumber--"+accountNumber);
				logger.info("accountService--"+accountService);
				logger.info("customerId--"+customerId);
				Criteria criteria = session.createCriteria(CustomerAccounts.class);
				criteria.add(Restrictions.eq("customerId", customerId));
				criteria.add(Restrictions.eq("accountNumber", accountNumber));
				criteria.add(Restrictions.eq("accountService", accountService));
				criteria.add(Restrictions.eq("accountStatus", "ACTIVE"));
				
				client = (CustomerAccounts) criteria.uniqueResult();
				logger.info("client--"+client);
			} catch (Exception e) {
				logger.error("(getCustomerAccountDetails)==> Error in getting customer "+e.getMessage(), e);
				throw new DataAccessException("Invalid customer");
			}
		}else{
			logger.info("(getCustomerAccountDetails)==> Search information is null or empty");
		}
		
		return client;
	}

	@Override
	public List<CustomerAccounts> listAllActiveAccounts(String strCustomer,
			String accountService) throws DataAccessException {
		List<CustomerAccounts> lstAccount = null;
		Session session = null;
		if(!(StringUtils.isEmpty(strCustomer) && StringUtils.isEmpty(accountService))){
			try {
				session = sessionFactory.getCurrentSession();
				Criteria criteria = session.createCriteria(CustomerAccounts.class);
				criteria.add(Restrictions.eq("customerId", strCustomer));
				criteria.add(Restrictions.eq("accountService", accountService));
				criteria.add(Restrictions.eq("accountStatus", "ACTIVE"));				
				criteria.addOrder(Order.asc("sequenceNumber"));
				lstAccount = criteria.list();
			} catch (Exception e) {
				logger.error("(getCustomerAccountDetails)==> Error in getting customer "+e.getMessage(), e);
				throw new DataAccessException("Invalid customer");
			}
		}else{
			logger.info("(getCustomerAccountDetails)==> Search information is null or empty");
		}
		return lstAccount;
	}
	
	
	
	@Override
	public Integer getSequenceByAccount(String companyCode, String strAccount) throws DataAccessException {
		Session session = null;
		Integer result = null;
		if (!(StringUtils.isEmpty(companyCode) && !(StringUtils.isEmpty(strAccount)))) {

			try {
				session = sessionFactory.getCurrentSession();
				Criteria criteria = session.createCriteria(CustomerAccounts.class);
				criteria.add(Restrictions.eq("customerId", companyCode));
				criteria.add(Restrictions.eq("accountNumber", strAccount));
				criteria.add(Restrictions.eq("accountService", "STATEMENT"));
				
				
				CustomerAccounts cust = (CustomerAccounts) criteria.uniqueResult();
				result = cust.getSequenceNumber();
				
				
			} catch (Exception e) {
				logger.error("(getSequenceByAccount)==> Error in getting Sequence of account number :"+strAccount +" companyCode : "+companyCode+" " + e.getMessage(), e);
				throw new DataAccessException("Invalid customer");
			}
		} else {
			logger.info("(getSequenceByAccount)==>  information is null or empty");
		}

		return result;
	}
	

}
