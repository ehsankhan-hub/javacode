package com.bsf.macug.payroll.dao;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;
import com.bsf.macug.payroll.entity.MacFileLog;
import com.bsf.macug.payroll.entity.MacPayrollActivityLog;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;

@Repository
public class PayrollDAOImpl implements InterPayrollDAO {

	private static final Logger logger = Logger.getLogger(PayrollDAOImpl.class.getName());

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public boolean saveHeader(MacPayrollHeader header) {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(header);
			status = true;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public boolean updateHeader(MacPayrollHeader header) {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.update(header);
			status = true;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}
	
	@Override
	public boolean updatePayrollActivity(MacPayrollActivityLog header) {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.update(header);
			status = true;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public List<MacPayrollHeader> findAllHeader(String status) {
		List<MacPayrollHeader> headerList = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPayrollHeader.class);
			if (!StringUtils.isEmpty(status)) {
				criteria.add(Restrictions.eq("status", status));
			}
			criteria.add(Restrictions.ne("processingStatus", 1));

			headerList = criteria.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return headerList;
	}

	@Override
	public MacPayrollHeader getHeader(String customerId, String fileId) {
		MacPayrollHeader header = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPayrollHeader.class);
			criteria.add(Restrictions.eq("clientId", customerId));
			criteria.add(Restrictions.eq("fileId", fileId));
			header = (MacPayrollHeader) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return header;
	}

	@Override
	public boolean saveDetail(MacPayrollDetail detail) {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(detail);
			status = true;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public boolean updateDetail(MacPayrollDetail detail) {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.update(detail);
			status = true;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public List<MacPayrollDetail> findAllDetail(String customerId, String fileId, String status) {
		List<MacPayrollDetail> detailList = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPayrollDetail.class);

			if (!StringUtils.isEmpty(customerId)) {
				criteria.add(Restrictions.eq("clientId", customerId));
			}
			if (!StringUtils.isEmpty(fileId)) {
				criteria.add(Restrictions.eq("fileId", fileId));
			}
			if (!StringUtils.isEmpty(status)) {
				criteria.add(Restrictions.eq("status", status));
			}
			detailList = criteria.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detailList;
	}

	@Override
	public MacPayrollDetail getDetail(String customerId, String fileId, String transRef) {
		MacPayrollDetail detail = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPayrollDetail.class);
			criteria.add(Restrictions.eq("clientId", customerId));
			criteria.add(Restrictions.eq("fileId", fileId));
			criteria.add(Restrictions.eq("transRef", transRef));
			detail = (MacPayrollDetail) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detail;
	}

	@Override
	public BigDecimal getSequence(String sequenceName) {
		Session session = null;
		BigDecimal sequenceVal = null;
		try {
			logger.info("(getSequence)==> updatePayrollHeader STARTED");
			session = sessionFactory.getCurrentSession();
			SQLQuery query = session.createSQLQuery("select " + sequenceName + ".NEXTVAL as id from dual")
					.addScalar("id");
			sequenceVal = (BigDecimal) query.uniqueResult();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		logger.info("(getSequence)==> return value" + sequenceVal);
		return sequenceVal;
	}

	@Override
	public boolean savePayrollLog(MacFileLog log) {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(log);
			status = true;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public int updateDetail(String clientId, String fileId, String status, String description) {
		int count = -1;
		try {
			Session session = sessionFactory.getCurrentSession();
			String qryString2 = "update MacPayrollDetail set status = :status , statusDesc = :statusDesc "
					+ "where clientId= :clientId and fileId = :fileId";
			Query query = session.createQuery(qryString2);
			query.setParameter("clientId", clientId);
			query.setParameter("fileId", fileId);
			query.setParameter("status", status);
			query.setParameter("statusDesc", description);
			
			count = query.executeUpdate();

			logger.info(count + " Record(s) Updated.");
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
			count = -1;
		}
		return count;
	}

	@Override
	public MacPayrollDetail getDetailWithRecordNumber(String clientId, String fileId, String strRecord) {
		MacPayrollDetail detail = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPayrollDetail.class);
			criteria.add(Restrictions.eq("clientId", clientId));
			criteria.add(Restrictions.eq("fileId", fileId));
			criteria.add(Restrictions.eq("recordNo", strRecord));
			detail = (MacPayrollDetail) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detail;
	}

	@Override
	public List<MacPayrollHeader> findAllForResponseFile() {
		List<MacPayrollHeader> headerList = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPayrollHeader.class);
			
			LogicalExpression re = Restrictions.or(Restrictions.eq("status", "FAILED"),Restrictions.eq("status", "PROCESSED"));
			
			criteria.add(re);
			criteria.add(Restrictions.ne("processingStatus", 1));
			criteria.add(Restrictions.ne("responseStatus", "GENERATED"));

			headerList = criteria.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return headerList;
	}
	
	@Override
	public List<MacPayrollActivityLog> findAllFailedResponseFile() {
		List<MacPayrollActivityLog> macPayActLog = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPayrollActivityLog.class);
			criteria.add(Restrictions.eq("processStatus", 0));
			criteria.add(Restrictions.eq("processSubject", "FAILED"));
			//criteria.add(Restrictions.ne("responseStatus", "GENERATED"));

			macPayActLog = criteria.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return macPayActLog;
	}

	@Override
	public MacFileLog getFileLog(String id) {
		MacFileLog detail = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacFileLog.class);
			criteria.add(Restrictions.eq("id", id));
			detail = (MacFileLog) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detail;
	}
	
	@Override
	public boolean updateFileLog(MacFileLog log) {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.update(log);
			status = true;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}
	
	@Override
	public boolean savePayrollProcessLog(MacPayrollActivityLog activityLog) {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(activityLog);
			status = true;
		} catch (Exception e) {
			logger.error("(savePaymentProcessLog)==> Error in saving payment activity log : " + e.getMessage(), e);
		}
		return status;
	}
	
	@Override
	public MacPayrollActivityLog getPayrollProcessLogByFileName(String fileName) {
		MacPayrollActivityLog macPaymnentActivLog=null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPayrollActivityLog.class);
			criteria.add(Restrictions.eq("custReqFile", fileName));
			criteria.add(Restrictions.eq("processSubject", "FAILED"));
			macPaymnentActivLog = (MacPayrollActivityLog) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return macPaymnentActivLog;
	}
}
