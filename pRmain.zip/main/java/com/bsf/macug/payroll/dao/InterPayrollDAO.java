package com.bsf.macug.payroll.dao;

import java.math.BigDecimal;
import java.util.List;

import com.bsf.macug.payroll.entity.MacFileLog;
import com.bsf.macug.payroll.entity.MacPayrollActivityLog;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;

public interface InterPayrollDAO {
	boolean saveHeader(MacPayrollHeader header);

	boolean updateHeader(MacPayrollHeader header);

	List<MacPayrollHeader> findAllHeader(String status);

	MacPayrollHeader getHeader(String customerId, String fileId);

	boolean saveDetail(MacPayrollDetail Detail);

	boolean updateDetail(MacPayrollDetail Detail);

	List<MacPayrollDetail> findAllDetail(String customerId, String fileId, String status);

	MacPayrollDetail getDetail(String customerId, String fileId, String transactionId);

	BigDecimal getSequence(String sequenceName);

	boolean savePayrollLog(MacFileLog log);

	int updateDetail(String clientId, String fileId, String status, String description);

	MacPayrollDetail getDetailWithRecordNumber(String clientId, String fileId, String strRecord);

	List<MacPayrollHeader> findAllForResponseFile();
	
	public List<MacPayrollActivityLog> findAllFailedResponseFile();

	MacFileLog getFileLog(String id);

	boolean updateFileLog(MacFileLog log);
	
	public boolean savePayrollProcessLog(MacPayrollActivityLog activityLog) ;
	
	public boolean updatePayrollActivity(MacPayrollActivityLog header);
	
	public MacPayrollActivityLog getPayrollProcessLogByFileName(String fileName);
}
