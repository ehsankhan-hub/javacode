package com.bsf.macug.payroll.service.tuxedo;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.DecimalFormat;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsf.macug.application.pool.Connection;
import com.bsf.macug.application.pool.SocketPool;
import com.bsf.macug.application.pool.SocketPoolFactory;
import com.bsf.macug.exception.TCPConnectionException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;

@Service("tuxedoPosting")
public class TuxedoPostingImpl implements InterTuxedoPosting{
	private static final Logger logger = Logger
			.getLogger(TuxedoPostingImpl.class.getName());

	@Autowired
	InterSystemParameterService systemParameterService;
	
	@Override
	public String postMessage(String message,
			Map<String, SystemParameters> tuxDetails) throws TCPConnectionException {
		logger.info("Prepared tuxedo request message : " +message);
		Socket socket = null;
		long expirationTimeout = Long.parseLong(systemParameterService
				.getSystemParametersDescription1("TIMEOUT", tuxDetails));
		int capacity = Integer.parseInt(systemParameterService
				.getSystemParametersDescription1("CAPACITY", tuxDetails));
		String serverHostname = systemParameterService
				.getSystemParametersDescription1("HOST", tuxDetails);
		String serverPort = systemParameterService
				.getSystemParametersDescription1("PORT", tuxDetails);

		OutputStream osr = null;
		BufferedInputStream in = null;
		String resultData = "";
		DecimalFormat format = new DecimalFormat("0000");
		message = format
				.format((long) message.length())
				+ message;
		Connection connection = null;
		logger.info("Tuxedo host name "+serverHostname+" port "+serverPort+" capacity "+capacity+" timeout "+expirationTimeout); 
		boolean executionNotCompleted = true;
		int count = 0;
		do{
			count++;
			try {		
				
				SocketPool socketPool = SocketPoolFactory.getSocketPool(
						serverHostname, serverPort, expirationTimeout, capacity);
				connection = socketPool.getSocketConnection();
				socket = connection.getSocket();
				
				
				
				StringBuilder result = new StringBuilder("");		
				
				byte []msg = message.getBytes("cp1256");
				
				
				osr = socket.getOutputStream(); 
				PrintStream pStream = new PrintStream(osr,true);

				in = new BufferedInputStream(socket
						.getInputStream(), 1024);

				pStream.write(msg);
				
				byte[] data = new byte[1024];
				int size = 0;
				do {
					size = in.read(data);
					if (size != -1) {
						result.append(new String(data, 0, size));
					} else {
						result.append("-1");
					}

				} while (size == 1024);

				resultData = result.toString();
			
				executionNotCompleted = false;
				logger.info("Recieved tuxedo response message : " +resultData);
			} catch (UnknownHostException e) {
				logger.error(e.getMessage(), e);
				closeConnection(connection);
				connection = null;
				if(count>3){
					logger.warn("(postMessage) ==> Tuxedo posting failed in "+count+" tries.");
					throw new TCPConnectionException(
							"Request can't be processed by BSF due to technical problem");
				}
				
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
				closeConnection(connection);
				connection = null;
				if(count>3){
					logger.warn("(postMessage) ==> Tuxedo posting failed in "+count+" tries.");
					throw new TCPConnectionException(
							"Request can't be processed by BSF due to technical problem");
				}
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				closeConnection(connection);
				connection = null;
				if(count>3){
					logger.warn("(postMessage) ==> Tuxedo posting failed in "+count+" tries.");
					throw new TCPConnectionException(
							"Request can't be processed by BSF due to technical problem");
				}
			} finally {
				try {
					if (connection != null){
						connection.returnToPool();
					}
						
				} catch (Exception e2) {
					logger.error("Error : "+e2.getMessage(), e2);
				}
			}
		}while(executionNotCompleted && count <= 3);
		if(count > 1){
			logger.warn("(postMessage) ==> Tuxedo posting completed in "+count+" tries.");
		}		
		return resultData;
	}

	private void closeConnection(Connection connection) {
		logger.info("(closeConnection) exception occured. Forcefully closing the connection");
		try {
			if(connection != null){
				connection.close();
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		
	}

}
