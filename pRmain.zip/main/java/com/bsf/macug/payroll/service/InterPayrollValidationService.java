package com.bsf.macug.payroll.service;

import java.util.List;
import java.util.Map;

import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.exception.TCPConnectionException;
import com.bsf.macug.exception.TuxedoException;
import com.bsf.macug.exception.ValidationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.payroll.dto.AccountEnquiryResponseDTO;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;

public interface InterPayrollValidationService {
	boolean isCommonValidationsPassed(MacPayrollHeader header, List<MacPayrollDetail> lstPayrollTransaction)
			throws ValidationException;

	void validateAccountAndBalance(AccountEnquiryResponseDTO enquiryResponseForDebitAccount, MacPayrollHeader newHeader,
			CustomerDetails customerDetails, CustomerAccounts customerAccount,
			Map<String, Map<String, SystemParameters>> allSystemProperties)
			throws TCPConnectionException, ValidationException, TuxedoException;

}
