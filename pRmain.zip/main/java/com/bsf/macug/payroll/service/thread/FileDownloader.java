package com.bsf.macug.payroll.service.thread;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.service.InterCustomerDetailsService;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.exception.ProcessException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.payroll.dto.PayrollHeaderTransferDTO;
import com.bsf.macug.payroll.dto.PayrollReqestTransferDTO;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;
import com.bsf.macug.payroll.rest.InterRestClient;
import com.bsf.macug.payroll.service.InterPayrollService;
import com.bsf.macug.payroll.service.InterPayrollUtil;
import com.bsf.macug.util.InterUtils;

@Component
@Scope("prototype")
public class FileDownloader implements Runnable {

	private static final Logger logger = Logger.getLogger(FileDownloader.class.getName());

	private MacPayrollHeader newHeader;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterCustomerDetailsService customerDetailsService;

	@Autowired
	InterRestClient restClient;

	@Autowired
	InterUtils utils;

	@Autowired
	InterPayrollUtil payrollUtil;

	@Autowired
	InterPayrollService payrollService;

	@Override
	public void run() {
		Map<String, SystemParameters> errorCodeMap = null;
		try {
			Map<String, Map<String, SystemParameters>> allProperties = utils.loadSystemProperties();
			errorCodeMap = allProperties.get("errorCodeMap");
			String result = downloadFromPayrollServer(allProperties);
			JSONArray jsArrFailArray = null;
			if (!StringUtils.isEmpty(result)) {
				JSONParser jsParser = new JSONParser();
				JSONObject jsObjResponse = (JSONObject) jsParser.parse(result);
				String strResponseStatus = (String) jsObjResponse.get("status");
				String strResponseMessage = (String) jsObjResponse.get("message");
				if (!StringUtils.isEmpty(strResponseStatus) && strResponseStatus.equalsIgnoreCase("OK")) {
					List<MacPayrollDetail> lstPayrollTransaction = payrollService.findAllDetail(newHeader.getClientId(),
							newHeader.getFileId(), null);
					payrollUtil.updateDetails(newHeader, lstPayrollTransaction, "OK", "Processed successfully.");
					if (jsObjResponse.get("failureData") != null) {
						jsArrFailArray = (JSONArray) jsObjResponse.get("failureData");
					}

					if (jsArrFailArray != null && jsArrFailArray.size() > 0) {
						for (int iJSCount = 0; iJSCount < jsArrFailArray.size(); iJSCount++) {
							JSONObject jsObjFailData = (JSONObject) jsParser
									.parse(jsArrFailArray.get(iJSCount).toString());
							String strRecord = (String) jsObjFailData.get("recordNumber");
							String strFailMessage = (String) jsObjFailData.get("description");
							MacPayrollDetail newDetails = payrollService.getDetailWithSequence(newHeader.getClientId(),
									newHeader.getFileId(), strRecord);
							newDetails.setStatus("DE");
							newDetails.setStatusDesc(strFailMessage);
						}
					}
					newHeader.setDescription("Payroll processed successfully.");
					newHeader.setStatus("PROCESSED");
				}
			}
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		newHeader.setProcessingStatus(0);
		payrollUtil.updateHeader(newHeader);

	}

	private String downloadFromPayrollServer(Map<String, Map<String, SystemParameters>> allProperties)
			throws ProcessException {
		String strResponse = null;
		PayrollHeaderTransferDTO restTransferHeader = null;
		try {

			Map<String, SystemParameters> mpRestProperties = allProperties.get("payrollProperties");
			Map<String, SystemParameters> macPropertyMap = allProperties.get("macPropertyMap");

			String strDEStatus = "DE";// systemParameterService.getSystemParametersDescription1("PAYSTADE",
										// mpB2BProperties);
			String strFAILStatus = "FAILED";// systemParameterService.getSystemParametersDescription1("PAYSTAFL",
											// mpB2BProperties);
			String strReqDateFormat = systemParameterService.getSystemParametersDescription1("PYRRSTFRM",
					macPropertyMap);
			CustomerDetails customerDetails = customerDetailsService.getCustomerDetails(newHeader.getClientId());
			if (customerDetails == null) {
				logger.info("(acknowledgeMTPayroll)==> Customer not found. Error code UPSB2BE01");
				throw new CustomerNotFoundException("Customer not found in the system");
			}
			String strResponseURI = systemParameterService.getSystemParametersDescription2("RSTFILRES",
					mpRestProperties);
			String strWPSFlag = customerDetails.getWpsFlag();
			String strMOLID = customerDetails.getCustomerMolId();
			boolean blWPSFlag = false;
			if (StringUtils.isEmpty(strWPSFlag)) {
				blWPSFlag = false;
				strWPSFlag = "N";
			} else {
				blWPSFlag = (strWPSFlag.equalsIgnoreCase("Y") ? true : false);
			}
			restTransferHeader = new PayrollHeaderTransferDTO();
			String strCustomerID = newHeader.getClientId();
			String strFileRefernce = newHeader.getFileId();
			restTransferHeader.setClientId(strCustomerID);
			restTransferHeader.setFileId(strFileRefernce);
			restTransferHeader.setMessageType(newHeader.getMessageType());
			restTransferHeader.setWpsFlag(strWPSFlag);
			restTransferHeader.setMolId(strMOLID);
			restTransferHeader.setPayrollId(customerDetails.getPayrollId());
			restTransferHeader.setMessageDescription("");
			restTransferHeader.setOrderingCustomerAccount(newHeader.getOrdCustAcc());
			restTransferHeader.setRequestFileName(newHeader.getFileName());
			PayrollReqestTransferDTO dtoTransfer = null;
			dtoTransfer = new PayrollReqestTransferDTO();
			dtoTransfer.setHeaderObj(restTransferHeader);
			logger.info("(getPayrollAckResponse)==> Calling rest service");
			strResponse = restClient.transferPayrollToBulkSystem(dtoTransfer, strResponseURI);
		} catch (Exception ex) {
			logger.error("Error : " + ex.getMessage(), ex);
		}
		return strResponse;
	}

	public void setNewHeader(MacPayrollHeader newHeader) {
		this.newHeader = newHeader;
	}

}
