package com.bsf.macug.payroll.service.thread;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.service.InterCustomerDetailsService;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.exception.DuplicateFileException;
import com.bsf.macug.exception.FileHandlerException;
import com.bsf.macug.exception.InvalidRequestDateTimeException;
import com.bsf.macug.exception.TagNotFoundException;
import com.bsf.macug.exception.ValidationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.payro.dto.xml.RequestMessage;
import com.bsf.macug.payro.dto.xml.RequestMessage.Body;
import com.bsf.macug.payro.dto.xml.RequestMessage.Body.PayrollMessage;
import com.bsf.macug.payro.dto.xml.RequestMessage.Body.PayrollMessage.PayrollTransaction;
import com.bsf.macug.payro.dto.xml.RequestMessage.Header;
import com.bsf.macug.payroll.entity.MacFileLog;
import com.bsf.macug.payroll.entity.MacPayrollHeader;
import com.bsf.macug.payroll.service.InterPayrollService;
import com.bsf.macug.payroll.service.InterPayrollUtil;
import com.bsf.macug.util.InterFileUtils;
import com.bsf.macug.util.InterUtils;

@Component
@Scope("prototype")
public class ProcessNewFile implements Runnable {

	private static final Logger logger = Logger.getLogger(ProcessNewFile.class.getName());
   
	@Autowired
	InterCustomerDetailsService customerDetailsService;
	
	@Autowired
	InterFileUtils fileUtils;

	@Autowired
	Environment environment;

	@Autowired
	InterUtils utils;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterPayrollService payrollService;

	@Autowired
	InterPayrollUtil payrollUtil;

	private String sourcePath;
	
	

	@Override
	public void run() {
		logger.info("Thread started for : " + sourcePath);
		boolean parsedSucessfully = false;
		String destinationPath = null;
		String errorPath = null;
		String fileName = null;
		boolean fileMovedToDestination = false;
		File destinationFile = null;
		MacFileLog fileLog = null;
		String sender="";
		String messageType="";
		String fileId="";
		String fileNameUpd="";
		try {
			Map<String, Map<String, SystemParameters>> allProperties = utils.loadSystemProperties();
			Map<String, SystemParameters> macPathProperties = allProperties.get("macPathMap");
			Map<String, SystemParameters> macPropertyMap = allProperties.get("macPropertyMap");
			
			List<MacPayrollHeader> processedHeaders  = payrollService.findAllForResponseFile();
			
			
			destinationPath = systemParameterService.getSystemParametersDescription2("PAYROLL_DEST", macPathProperties);
			errorPath = systemParameterService.getSystemParametersDescription2("PAYROLL_ERR", macPathProperties);

			byte[] requestData = fileUtils.readFile(sourcePath);
			UUID uuid = java.util.UUID.randomUUID();
			String uniqueId = uuid.toString();

			fileLog = payrollUtil.saveLog(uniqueId, requestData);
			
			File sourceFile = new File(sourcePath);
			fileName = sourceFile.getName();
			destinationFile = new File(destinationPath + fileName);
            
			fileNameUpd=fileName.substring(0,fileName.lastIndexOf('.'));
			
			fileUtils.moveFile(sourceFile, destinationFile);
			fileMovedToDestination = true;

			String data = new String(requestData, "UTF-8");
			data = utils.removeStealinkCharacter(data.getBytes("UTF-8"));			
			
			RequestMessage message = payrollUtil.parseXMLMessage(data);
			Header header = message.getHeader();
			if (header == null) {
				throw new TagNotFoundException("header");
			}
			Body body = message.getBody();
			if (body == null) {
				throw new TagNotFoundException("Body");
			}

			sender = header.getSender();
			String reciver = header.getReceiver();
			if (StringUtils.isEmpty(sender)) {
				throw new ValidationException("Invalid sender.");
			}

			if (StringUtils.isEmpty(reciver)) {
				throw new ValidationException("Invalid reciever.");
			}

			boolean validTimeStamp = payrollUtil.checkIfValidRequestDateTime(header.getTimeStamp(), macPropertyMap);
			if (!validTimeStamp) {
				throw new InvalidRequestDateTimeException(header.getTimeStamp() + " is invalid.");
			}

			PayrollMessage requestObj = body.getPayrollMessage();
			if (requestObj == null) {
				throw new TagNotFoundException("PayrollMessage");
			}
			///Field ID 
			fileId = requestObj.getPayrollMessageRef();
			if (StringUtils.isEmpty(fileId)) {
				throw new ValidationException("Invalid fileId.");
			}

			List<PayrollTransaction> payrollTransactionList = requestObj.getPayrollTransaction();
			if(payrollTransactionList == null) {
				throw new TagNotFoundException("PayrollTransaction.");
			}
			messageType = requestObj.getPayrollMessageType();

			String recivedAmount = requestObj.getPayrollTransactionAmount();
			String recivedCount = requestObj.getPayrollTransactionCount();
			BigDecimal bRecivedAmount = BigDecimal.ZERO;
			if (!StringUtils.isEmpty(recivedAmount)) {
				bRecivedAmount = new BigDecimal(recivedAmount.replace(",", "."));
			}
			BigDecimal bRecivedCount = BigDecimal.ZERO;
			if (!StringUtils.isEmpty(recivedCount)) {
				bRecivedCount = new BigDecimal(recivedCount.replace(",", "."));
			}

			if(payrollTransactionList.size() != bRecivedCount.intValue()) {
				throw new ValidationException("Count mismatch");
			}
			
			payrollUtil.checkIfFileIdExists(fileId, sender);
            
			CustomerDetails customerDetails = customerDetailsService.getCustomerDetails(header.getSender());
			if (customerDetails == null) {
				throw new CustomerNotFoundException("Customer not registred.");
			}
			
			
			
			//String fileNameUpd=fileName.replace(".dat","");
			MacPayrollHeader headerObj = new MacPayrollHeader();
			headerObj.setId(uniqueId);
			headerObj.setClientId(sender);
			headerObj.setFileId(fileId);
			headerObj.setRequestContent(requestData);
			headerObj.setTotalAmount(bRecivedAmount);
			headerObj.setTotalCount(bRecivedCount);
			headerObj.setMessageType(messageType);
			headerObj.setStatus("RECEIVED");
			headerObj.setDescription("Recieved successfully");
			headerObj.setResponseStatus("NOT_GENERATED");
			headerObj.setCustReqFile(fileNameUpd);
			headerObj.setResponseFileValue(customerDetails.getResponseFileValue());
			headerObj.setProcessingStatus(0);

			payrollService.saveHeader(headerObj);
			parsedSucessfully = true;
			
			fileLog.setStatus("OK");
			fileLog.setDescription("Saved in header. Check header for further details.");

		} catch (FileHandlerException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(sender,fileId,"FAILED", e.getMessage(), messageType, fileNameUpd,0);
		} catch (UnsupportedEncodingException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(sender,fileId,"FAILED", e.getMessage(), messageType, fileNameUpd,0);
		} catch (IOException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(sender,fileId,"FAILED", e.getMessage(), messageType, fileNameUpd,0);
		} catch (ValidationException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			String strErrorDesc = (StringUtils.isEmpty(e.getErrorCode()))?"Validation failed. Please check XML.":e.getErrorCode();
			fileLog.setStatus("FAILED");
			fileLog.setDescription(strErrorDesc);
			utils.logMT100Activity(sender,fileId,"FAILED", strErrorDesc, messageType, fileNameUpd,0);
		} catch (DuplicateFileException e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(sender,fileId,"FAILED", e.getMessage(), messageType, fileNameUpd,0);
		} catch (Exception e) {
			logger.error("(processFile)==> Error while reading the file contents..." + sourcePath);
			logger.error("Error : " + e.getMessage(), e);
			fileLog.setStatus("FAILED");
			fileLog.setDescription(e.getMessage());
			utils.logMT100Activity(sender,fileId,"FAILED", e.getMessage(), messageType, fileNameUpd,0);
		}
		if (!parsedSucessfully && fileMovedToDestination) {
			try {
				File errorFile = new File(errorPath + fileName);
				fileUtils.moveFile(destinationFile, errorFile);
			} catch (FileHandlerException e) {
				logger.error("Error : " + e.getMessage(), e);
			} catch (Exception e) {
				logger.error("Error : " + e.getMessage(), e);
			}

		}
		//payrollUtil.updateLog(fileLog);
		logger.info("Thread ended for : " + sourcePath);
	}

	public String getReuestFileName() {
		return sourcePath;
	}

	public void setReuestFileName(String sourcePath) {
		this.sourcePath = sourcePath;
	}
}