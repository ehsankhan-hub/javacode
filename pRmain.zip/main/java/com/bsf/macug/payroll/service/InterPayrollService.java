package com.bsf.macug.payroll.service;

import java.util.List;

import com.bsf.macug.payroll.entity.MacFileLog;
import com.bsf.macug.payroll.entity.MacPayrollActivityLog;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;

public interface InterPayrollService {
	boolean saveHeader(MacPayrollHeader header);

	boolean updateHeader(MacPayrollHeader header);

	List<MacPayrollHeader> findAllHeader(String status);

	MacPayrollHeader getHeader(String customerId, String fileId);

	boolean saveDetail(MacPayrollDetail Detail);

	boolean updateDetail(MacPayrollDetail Detail);

	List<MacPayrollDetail> findAllDetail(String customerId, String fileId, String status);

	MacPayrollDetail getDetail(String customerId, String fileId, String transactionId);

	Long getSequence(String sequenceName);

	boolean savePayrollLog(MacFileLog log);

	int updateDetail(String clientId, String fileId, String string, String string2);

	MacPayrollDetail getDetailWithSequence(String clientId, String fileId, String strRecord);

	List<MacPayrollHeader> findAllForResponseFile();
	
	public List<MacPayrollActivityLog> findAllFailedResponseFile();

	MacFileLog getFileLog(String id);
	
	public boolean updatePayrollActivLog(MacPayrollActivityLog activLog);

	boolean updateFileLog(MacFileLog log);
	
	public MacPayrollActivityLog getPaymentProcessLogByFileName(String fileName) ;
}
