package com.bsf.macug.payroll.service;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.exception.TCPConnectionException;
import com.bsf.macug.exception.TuxedoException;
import com.bsf.macug.exception.ValidationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.payroll.dto.AccountEnquiryResponseDTO;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;

@Service
public class PayrollValidationServiceImpl implements InterPayrollValidationService {

	private static final Logger logger = Logger.getLogger(PayrollValidationServiceImpl.class.getName());

	@Override
	public boolean isCommonValidationsPassed(MacPayrollHeader header, List<MacPayrollDetail> lstPayrollTransaction)
			throws ValidationException {

		logger.info("(checkSameDebitAccount)==> Check same debit");

		boolean blStatus = true;
		int i = 0;
		String dbAccount = null;
		String valueDate = null;
		DateFormat format = new SimpleDateFormat("yyMMdd");
		BigDecimal totlaAmount = new BigDecimal("0");
		for (MacPayrollDetail dtoTransaction : lstPayrollTransaction) {
			String dbAccountVal = dtoTransaction.getOrdCustAcc();
			String dbValueDate = format.format(dtoTransaction.getValueDate());
			if (i == 0) {
				dbAccount = dbAccountVal;
				valueDate = dbValueDate;
				logger.info("(checkSameDebitAccount)==> Debit account is " + dbAccountVal);
				logger.info("(checkSameDebitAccount)==> value date is " + valueDate);

			}
			if (!StringUtils.isEmpty(dbAccountVal) && !dbAccountVal.equals(dbAccount)) {
				logger.info("(checkSameDebitAccount)==> Debit account is not valid " + dbAccountVal);
				logger.error("Fail Debit account mismatch in message");
				throw new ValidationException("MACVER019");
			}

			if (valueDate != null && !valueDate.equals(dbValueDate)) {
				logger.info("(checkSameDebitAccount)==> value date is not valid " + dbAccountVal);
				logger.error("Fail value date mismatch in message");
				throw new ValidationException("MACVER020");
			}

			BigDecimal trnsactionAmount = dtoTransaction.getTransactionAmount();
			if (trnsactionAmount != null) {
				logger.info("trnsactionAmount : " + trnsactionAmount);
				totlaAmount = totlaAmount.add(trnsactionAmount);
			}

			i++;
		}

		if (totlaAmount.compareTo(header.getTotalAmount()) == 0) {
			logger.info("Total Amount validation successful");
		} else {
			logger.info("totlaAmount : " + totlaAmount + " ,bgTotalHeaderAmount : " + header.getTotalAmount());
			throw new ValidationException("MACVER021");
		}

		return blStatus;
	}

	@Override
	public void validateAccountAndBalance(AccountEnquiryResponseDTO enquiryResponseForDebitAccount,
			MacPayrollHeader newHeader, CustomerDetails customerDetails, CustomerAccounts customerAccount,
			Map<String, Map<String, SystemParameters>> allSystemProperties)
			throws TCPConnectionException, ValidationException, TuxedoException {
		Map<String, SystemParameters> accountStatusMap = allSystemProperties.get("accountStatusMap");
		Map<String, SystemParameters> accountTypeMap = allSystemProperties.get("accountTypeMap");

		if (enquiryResponseForDebitAccount == null) {
			logger.info("(validateAndProcessPayment)==> Enquiry returned null. May be network error.");
			throw new TCPConnectionException();
		}

		String camActCodeDbt = enquiryResponseForDebitAccount.getCammActionCode();
		String ftsActCodeDbt = enquiryResponseForDebitAccount.getFtsActionCode();
		String accStatusCodeDbt = enquiryResponseForDebitAccount.getAccountStatusCode();
		String accTypeDbt = enquiryResponseForDebitAccount.getAccountType();
		String freezeFlag = enquiryResponseForDebitAccount.getFreezeFlag();
		if (!isAccountStatusAllowedForDebit(accStatusCodeDbt, accountStatusMap, "D")) {
			logger.info("(validateAndProcessPayment)==> Checking for staus code is valid failed");
			throw new ValidationException("MACVER003");
		}

		if (!isAccountTypeAllowedForDebit(accTypeDbt, accountTypeMap, "D")) {
			logger.info("(validateAndProcessPayment)==> Checking for account type is valid failed");
			throw new ValidationException("MACVER004");
		}

		if (!("0000".equals(camActCodeDbt) && "0000".equals(ftsActCodeDbt))) {
			logger.info("(validateAndProcessPayment)==> Checking for camm and fts code failed");
			throw new TuxedoException(ftsActCodeDbt);
		}

		if("Y".equalsIgnoreCase(freezeFlag)) {
			logger.info("(validateAndProcessPayment)==> Checking freeze failed");
			throw new ValidationException("MACVER024");
		}
		
		if (!isBalanceAvailable(enquiryResponseForDebitAccount, newHeader,customerDetails)) {
			throw new ValidationException("MACVER022");
		}
	}

	private boolean isBalanceAvailable(AccountEnquiryResponseDTO enquiryResponseForDebitAccount, MacPayrollHeader newHeader, CustomerDetails customerDetails) {
		try {
			String strAvailableBalance = enquiryResponseForDebitAccount.getAvailableBalance();
			BigDecimal totalAmount = newHeader.getTotalAmount();
			
			String balanceCheckFlag = customerDetails.getPayrollBalanceCheckFlag();
			if(!StringUtils.isEmpty(balanceCheckFlag) && balanceCheckFlag.equalsIgnoreCase("N")) {
				return true;
			}
			if(StringUtils.isEmpty(strAvailableBalance)) {
				logger.info("(isBalanceAvailable)==> AvailableBalance is null.");
				return false;
			}
			
			BigDecimal avaliblaeBalance = new BigDecimal(strAvailableBalance.replace(",", "."));
			if(totalAmount.compareTo(avaliblaeBalance)==1){
				logger.info("(isBalanceAvailable)==> Account balance is less than payroll tranasaction Amount.");
				return false;
			}
			
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(),e);
		}
		return true;
	}

	public boolean isAccountTypeAllowedForDebit(String accTypeDbt, Map<String, SystemParameters> accountTypeMap,
			String debitOrCredit) {
		logger.info("Check type " + debitOrCredit + " " + accTypeDbt);
		if (StringUtils.isEmpty(accTypeDbt)) {
			return false;
		}
		SystemParameters systemProperty = accountTypeMap.get(accTypeDbt.trim());
		boolean allowed = false;

		if (debitOrCredit.equals("D")) {
			if (systemProperty != null) {
				String description = systemProperty.getItemDescription1();
				if (!StringUtils.isEmpty(description) && description.trim().equalsIgnoreCase("B")) {
					allowed = true;
				} else if (!StringUtils.isEmpty(description) && description.trim().equalsIgnoreCase("D")) {
					allowed = true;
				}
			}
		} else if (debitOrCredit.equals("C")) {
			if (systemProperty != null) {
				String description = systemProperty.getItemDescription1();
				if (!StringUtils.isEmpty(description) && description.trim().equalsIgnoreCase("B")) {
					allowed = true;
				} else if (!StringUtils.isEmpty(description) && description.trim().equalsIgnoreCase("C")) {
					allowed = true;
				}
			}
		}

		return allowed;
	}

	public boolean isAccountStatusAllowedForDebit(String accStatusCodeDbt,
			Map<String, SystemParameters> accountStatusMap, String debitOrCredit) {

		// logger.info("Check status " + debitOrCredit + " " +
		// accStatusCodeDbt);
		boolean allowed = false;
		if (StringUtils.isEmpty(accStatusCodeDbt)) {
			return false;
		}

		if (debitOrCredit.equals("D")) {
			SystemParameters systemProperty = accountStatusMap.get(accStatusCodeDbt.trim());
			if (systemProperty != null) {
				String descirption = systemProperty.getItemDescription1();
				if (!StringUtils.isEmpty(descirption) && descirption.trim().equalsIgnoreCase("B")) {
					allowed = true;
				} else if (!StringUtils.isEmpty(descirption) && descirption.trim().equalsIgnoreCase("D")) {
					allowed = true;
				}
			}
		} else if (debitOrCredit.equals("C")) {
			SystemParameters systemProperty = accountStatusMap.get(accStatusCodeDbt.trim());
			if (systemProperty != null) {
				String descirption = systemProperty.getItemDescription1();
				if (!StringUtils.isEmpty(descirption) && descirption.trim().equalsIgnoreCase("B")) {
					allowed = true;
				} else if (!StringUtils.isEmpty(descirption) && descirption.trim().equalsIgnoreCase("C")) {
					allowed = true;
				}
			}
		}

		return allowed;

	}
}
