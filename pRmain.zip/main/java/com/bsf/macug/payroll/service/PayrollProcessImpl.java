package com.bsf.macug.payroll.service;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.payroll.entity.MacPayrollActivityLog;
import com.bsf.macug.payroll.entity.MacPayrollHeader;
import com.bsf.macug.payroll.service.thread.FailedReportGenerator;
import com.bsf.macug.payroll.service.thread.FileDownloader;
import com.bsf.macug.payroll.service.thread.FileUploader;
import com.bsf.macug.payroll.service.thread.FileValidator;
import com.bsf.macug.payroll.service.thread.MessageParser;
import com.bsf.macug.payroll.service.thread.ProcessNewFile;
import com.bsf.macug.payroll.service.thread.ReportGenerator;
import com.bsf.macug.util.GenericExtFilter;
import com.bsf.macug.util.InterFileUtils;
import com.bsf.macug.util.InterUtils;

@Service
public class PayrollProcessImpl implements InterPayrollProcess {
	private static final Logger logger = Logger.getLogger(PayrollProcessImpl.class.getName());

	@Value("${payroll.src.ext}")
	private String FILE_EXT;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterFileUtils fileUtils;

	@Autowired
	TaskExecutor taskExecutor;

	@Autowired
	private ApplicationContext applicationContext;

	@Autowired
	InterUtils utils;

	@Autowired
	InterPayrollService payrollService;

	@Override
	public void processFile() {
		try {
			Map<String, Map<String, SystemParameters>> allProperties = utils.loadSystemProperties();

			Map<String, SystemParameters> macPathProperties = allProperties.get("macPathMap");
			String finSourcePath = systemParameterService.getSystemParametersDescription2("PAYROLL_SRC",
					macPathProperties);
			File folder = new File(finSourcePath);
			File[] listOfFiles = folder.listFiles(new GenericExtFilter(FILE_EXT));
			for (File file : listOfFiles) {
				if (fileUtils.isFileReadyToRead(file)) {
					logger.info("(processFile)==> Processing of file starts...." + file.getAbsolutePath());
					ProcessNewFile newFileThread = applicationContext.getBean(ProcessNewFile.class);
					newFileThread.setReuestFileName(file.getAbsolutePath());
					taskExecutor.execute(newFileThread);
				}
			}

			List<MacPayrollHeader> receivedHeaders = payrollService.findAllHeader("RECEIVED");
			for (MacPayrollHeader header : receivedHeaders) {
				header.setProcessingStatus(1);
				payrollService.updateHeader(header);
				MacPayrollHeader newHeader = payrollService.getHeader(header.getClientId(), header.getFileId());
				MessageParser parserThread = applicationContext.getBean(MessageParser.class);
				parserThread.setHeader(newHeader);
				taskExecutor.execute(parserThread);
			}

			List<MacPayrollHeader> pendingHeaders = payrollService.findAllHeader("PENDING");
			for (MacPayrollHeader header : pendingHeaders) {
				header.setProcessingStatus(1);
				payrollService.updateHeader(header);
				MacPayrollHeader newHeader = payrollService.getHeader(header.getClientId(), header.getFileId());
				FileValidator parserThread = applicationContext.getBean(FileValidator.class);
				parserThread.setHeader(newHeader);
				taskExecutor.execute(parserThread);
			}

			List<MacPayrollHeader> readyHeaders = payrollService.findAllHeader("READY");
			for (MacPayrollHeader header : readyHeaders) {
				header.setProcessingStatus(1);
				payrollService.updateHeader(header);
				MacPayrollHeader newHeader = payrollService.getHeader(header.getClientId(), header.getFileId());
				FileUploader parserThread = applicationContext.getBean(FileUploader.class);
				parserThread.setHeader(newHeader);
				taskExecutor.execute(parserThread);
			}

			List<MacPayrollHeader> uploadedHeaders = payrollService.findAllHeader("UPLOADED");
			for (MacPayrollHeader header : uploadedHeaders) {
				header.setProcessingStatus(1);
				payrollService.updateHeader(header);
				MacPayrollHeader newHeader = payrollService.getHeader(header.getClientId(), header.getFileId());
				FileDownloader parserThread = applicationContext.getBean(FileDownloader.class);
				parserThread.setNewHeader(newHeader);
				taskExecutor.execute(parserThread);
			}
			
			List<MacPayrollActivityLog> macPayrollActiLog=payrollService.findAllFailedResponseFile();
			for (MacPayrollActivityLog actigLog : macPayrollActiLog) {
				actigLog.setProcessStatus(1);
				payrollService.updatePayrollActivLog(actigLog);
				MacPayrollActivityLog payRollActLog = payrollService.getPaymentProcessLogByFileName(actigLog.getCustReqFile());
				FailedReportGenerator parserThread = applicationContext.getBean(FailedReportGenerator.class);
				parserThread.setNewHeader(payRollActLog);
				taskExecutor.execute(parserThread);
			}
			
			List<MacPayrollHeader> processedHeaders  = payrollService.findAllForResponseFile();
			
			for (MacPayrollHeader header : processedHeaders) {
				header.setProcessingStatus(1);
				payrollService.updateHeader(header);
				MacPayrollHeader newHeader = payrollService.getHeader(header.getClientId(), header.getFileId());
				ReportGenerator parserThread = applicationContext.getBean(ReportGenerator.class);
				parserThread.setNewHeader(newHeader);
				taskExecutor.execute(parserThread);
			}
			ThreadPoolTaskExecutor taskExecutorPool = (ThreadPoolTaskExecutor) taskExecutor;
			
			for (;;) {
				int count = taskExecutorPool.getActiveCount();
				logger.info("Active Threads : " + count);
				try {
					Thread.sleep(15000);
				} catch (InterruptedException e) {
					   
				}
				if (count == 0) {
					taskExecutorPool.shutdown();
					break;
				}
			}

		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}

	}

}
