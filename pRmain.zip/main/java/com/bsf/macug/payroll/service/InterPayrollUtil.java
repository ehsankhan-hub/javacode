package com.bsf.macug.payroll.service;

import java.util.List;
import java.util.Map;

import com.bsf.macug.exception.DuplicateFileException;
import com.bsf.macug.exception.XMLParsingException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.payro.dto.xml.AcknowledgementResponseXMLDTO;
import com.bsf.macug.payro.dto.xml.RequestMessage;
import com.bsf.macug.payroll.entity.MacFileLog;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;

public interface InterPayrollUtil {

	MacFileLog saveLog(String uniqueId, byte[] requestData);

	void checkIfFileIdExists(String customerId, String fileId) throws DuplicateFileException;

	RequestMessage parseXMLMessage(String data) throws XMLParsingException;

	boolean checkIfValidRequestDateTime(String timeStamp, Map<String, SystemParameters> macPropertyMap);

	boolean saveDetails(MacPayrollDetail details);

	MacPayrollHeader setStatusAndDescription(MacPayrollHeader header, String status, String errorCode,
			Map<String, SystemParameters> map);

	boolean updateDetails(MacPayrollHeader newHeader, List<MacPayrollDetail> lstPayrollTransaction, String status,
			String description);

	boolean updateHeader(MacPayrollHeader newHeader);

	String generateResponseFromXMLDTO(AcknowledgementResponseXMLDTO responseXMLDTO);

	public boolean updateLog(MacFileLog log);
}
