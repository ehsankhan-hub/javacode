package com.bsf.macug.payroll.service.tuxedo;

import java.util.Map;

import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.payroll.dto.AccountEnquiryResponseDTO;

public interface InterAccountEnquiryService {
	AccountEnquiryResponseDTO buildAccountEnquiryResponse(
			String accountNo, Map<String, SystemParameters> tuxPropertyMap);
}
