package com.bsf.macug.payroll.service;

public interface InterPayrollProcess {
	public void processFile();
}
