package com.bsf.macug.payroll.service.thread;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.service.InterCustomerDetailsService;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.exception.ProcessException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.payroll.dto.PayrollHeaderTransferDTO;
import com.bsf.macug.payroll.dto.PayrollReqestTransferDTO;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;
import com.bsf.macug.payroll.rest.InterRestClient;
import com.bsf.macug.payroll.service.InterPayrollService;
import com.bsf.macug.payroll.service.InterPayrollUtil;
import com.bsf.macug.util.InterUtils;

@Component
@Scope("prototype")
public class FileUploader implements Runnable {

	private static final Logger logger = Logger.getLogger(FileUploader.class.getName());

	private MacPayrollHeader newHeader;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterCustomerDetailsService customerDetailsService;

	@Autowired
	InterRestClient restClient;

	@Autowired
	InterUtils utils;

	@Autowired
	InterPayrollUtil payrollUtil;
	

	@Autowired
	InterPayrollService payrollService;

	@Override
	public void run() {
		Map<String, SystemParameters> errorCodeMap = null;
		try {
			Map<String, Map<String, SystemParameters>> allProperties = utils.loadSystemProperties();
			Map<String, SystemParameters> macPropertyMap = allProperties.get("macPropertyMap");
			Map<String, SystemParameters> payrollProperties = allProperties.get("payrollProperties");
			errorCodeMap = allProperties.get("errorCodeMap");
			String result = uploadToPayrollServer(allProperties);
			if (StringUtils.isEmpty(result)) {
				newHeader = payrollUtil.setStatusAndDescription(newHeader, "FAILED", "MACVER002", errorCodeMap);
			} else {
				JSONParser jsParser = new JSONParser();
				JSONObject jsObjResponse = (JSONObject) jsParser.parse(result);
				String strResponseStatus = (String) jsObjResponse.get("status");
				String strResponseMessage = (String) jsObjResponse.get("message");
				if (!StringUtils.isEmpty(strResponseStatus) && strResponseStatus.equalsIgnoreCase("OK")) {
					newHeader.setDescription("Payroll uploaded successfully.");
					newHeader.setStatus("UPLOADED");
					List<MacPayrollDetail> lstPayrollTransaction = payrollService.findAllDetail(newHeader.getClientId(), newHeader.getFileId(), null);
					payrollUtil.updateDetails(newHeader, lstPayrollTransaction, "PENDING", "Transactions uploaded successfully.");
				} else {
					newHeader.setDescription("Payroll uploading failed.");
					newHeader.setStatus("FAILED");
				}
			}
		} catch (Exception e) {
			newHeader = payrollUtil.setStatusAndDescription(newHeader, "FAILED", "MACVER002", errorCodeMap);
		}
		newHeader.setProcessingStatus(0);
		payrollUtil.updateHeader(newHeader);
	}

	public void setHeader(MacPayrollHeader newHeader) {
		this.newHeader = newHeader;
	}

	private String uploadToPayrollServer(Map<String, Map<String, SystemParameters>> allProperties) throws ProcessException {
		logger.info("(uploadToPayrollServer)==> Mapping payrol information for rest request");
		String strResponse = null;
		PayrollHeaderTransferDTO restTransferHeader = null;
		try {
			Map<String, SystemParameters> mpRestProperties = allProperties.get("payrollProperties");
			Map<String, SystemParameters> macPropertyMap = allProperties.get("macPropertyMap");
			String strDEStatus = "DE";// systemParameterService.getSystemParametersDescription1("PAYSTADE",
										// mpB2BProperties);
			String strFAILStatus = "FAILED";// systemParameterService.getSystemParametersDescription1("PAYSTAFL",
											// mpB2BProperties);
			String strReqDateFormat = systemParameterService.getSystemParametersDescription1("PYRRSTFRM",
					macPropertyMap);
			String strClientID = newHeader.getClientId();
			String strFileRefernce = newHeader.getFileId();
			CustomerDetails customerDetails = customerDetailsService.getCustomerDetails(strClientID);
			if (customerDetails == null) {
				logger.info("(acknowledgeMTPayroll)==> Customer not found. Error code UPSB2BE01");
				throw new CustomerNotFoundException("Customer not found in the system");
			}
			String strWPSFlag = customerDetails.getWpsFlag();
			String strMOLID = customerDetails.getCustomerMolId();
			boolean blWPSFlag = false;
			if (StringUtils.isEmpty(strWPSFlag)) {
				blWPSFlag = false;
				strWPSFlag = "N";
			} else {
				blWPSFlag = (strWPSFlag.equalsIgnoreCase("Y") ? true : false);
			}
			restTransferHeader = new PayrollHeaderTransferDTO();
			String strCustomerID = newHeader.getClientId();

			restTransferHeader.setClientId(strCustomerID);
			restTransferHeader.setFileId(strFileRefernce);
			restTransferHeader.setMessageType(newHeader.getMessageType());
			restTransferHeader.setTransactionCount(newHeader.getTotalCount().intValue());
			restTransferHeader.setTotalAmount(newHeader.getTotalAmount().toString());
			restTransferHeader.setWpsFlag(strWPSFlag);
			restTransferHeader.setMolId(strMOLID);
			restTransferHeader.setPayrollId(customerDetails.getPayrollId());
			restTransferHeader.setMessageDescription("");
			restTransferHeader.setOrderingCustomerAccount(newHeader.getOrdCustAcc());
			restTransferHeader.setRequestFileName(newHeader.getFileName());
			String strHeaderTimeStamp = null;
			try {
				DateFormat dfToday = new SimpleDateFormat(strReqDateFormat);
				strHeaderTimeStamp = dfToday.format(newHeader.getValueDate());
			} catch (Exception e) {
				logger.error("(uploadToPayrollServer)==> Error in parsing time stamp. Set to current date");
				DateFormat dfToday = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
				strHeaderTimeStamp = dfToday.format(new Date());
			}
			if (strHeaderTimeStamp == null) {
				DateFormat dfToday = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
				strHeaderTimeStamp = dfToday.format(new Date());
			}
			restTransferHeader.setTimeStamp(strHeaderTimeStamp);
			DecimalFormat formatAmount = new DecimalFormat("000000000000.00");
			BigDecimal totalAmount = newHeader.getTotalAmount();
			String strTotalAmount = formatAmount.format(totalAmount);

			PayrollReqestTransferDTO dtoTransfer = null;
			dtoTransfer = new PayrollReqestTransferDTO();
			dtoTransfer.setHeaderObj(restTransferHeader);
			String strUploadURI = systemParameterService.getSystemParametersDescription2("RSTFILUPL", mpRestProperties);

			logger.info("(acknowledgeMTPayroll)==> Uploading URI is " + strUploadURI);
			strResponse = restClient.transferPayrollToBulkSystem(dtoTransfer, strUploadURI);

		} catch (Exception e) {
			logger.info("(uploadToPayrollServer)==> Error occured " + e.getMessage(), e);
		}
		return strResponse;

	}
}
