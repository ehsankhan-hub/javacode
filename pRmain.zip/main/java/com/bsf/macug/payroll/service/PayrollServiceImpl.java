package com.bsf.macug.payroll.service;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.macug.payroll.dao.InterPayrollDAO;
import com.bsf.macug.payroll.entity.MacFileLog;
import com.bsf.macug.payroll.entity.MacPayrollActivityLog;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;
import com.bsf.macug.payroll.transaction.InterPayrollTransactionalService;

@Service
public class PayrollServiceImpl implements InterPayrollService {

	private static final Logger logger = Logger.getLogger(PayrollServiceImpl.class.getName());

	@Autowired
	InterPayrollTransactionalService transaction;

	@Override
	public boolean saveHeader(MacPayrollHeader header) {
		boolean status = false;
		try {
			header.setCreatedBy("SYSTEM");
			header.setCreatedDate(new Timestamp(new Date().getTime()));
			status = transaction.saveHeader(header);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public boolean updateHeader(MacPayrollHeader header) {
		boolean status = false;
		try {
			header.setModifiedBy("SYSTEM");
			header.setModifiedDate(new Timestamp(new Date().getTime()));
			header.setValidatedTime(new Timestamp(new Date().getTime()));
			status = transaction.updateHeader(header);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}
	
	@Override
	public boolean updatePayrollActivLog(MacPayrollActivityLog activLog) {
		boolean status = false;
		try {
			status = transaction.updatePayrollActivityLog(activLog);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public List<MacPayrollHeader> findAllHeader(String status) {
		List<MacPayrollHeader> headerList = null;
		try {
			headerList = transaction.findAllHeader(status);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return headerList;
	}

	@Override
	public MacPayrollHeader getHeader(String customerId, String fileId) {
		MacPayrollHeader header = null;
		try {
			header = transaction.getHeader(customerId, fileId);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return header;
	}

	@Override
	public boolean saveDetail(MacPayrollDetail detail) {
		boolean status = false;
		try {
			UUID guid = java.util.UUID.randomUUID();
			detail.setId(guid.toString());
			detail.setCreatedId("SYSTEM");
			detail.setCraetedDate(new Timestamp(new Date().getTime()));
			status = transaction.saveDetail(detail);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public boolean updateDetail(MacPayrollDetail detail) {
		boolean status = false;
		try {
			detail.setModifiedId("SYSTEM");
			detail.setModifiedDate(new Timestamp(new Date().getTime()));
			status = transaction.updateDetail(detail);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public List<MacPayrollDetail> findAllDetail(String customerId, String fileId, String status) {
		List<MacPayrollDetail> detailList = null;
		try {
			detailList = transaction.findAllDetail(customerId, fileId, status);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detailList;
	}

	@Override
	public MacPayrollDetail getDetail(String customerId, String fileId, String transactionId) {
		MacPayrollDetail detail = null;
		try {
			detail = transaction.getDetail(customerId, fileId, transactionId);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detail;
	}

	@Override
	public Long getSequence(String sequenceName) {
		Long value = null;
		try {
		value = transaction.getSequence(sequenceName);
			
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return value;
	}

	@Override
	public boolean savePayrollLog(MacFileLog log) {
		boolean status = false;
		try {			
			log.setType("Payroll");
			log.setCreatedBy("SYSTEM");
			log.setCreatedOn(new Timestamp(new Date().getTime()));
			status = transaction.savePayrollLog(log);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public int updateDetail(String clientId, String fileId, String status, String description) {
		int updatedCount = -1;
		try {
			 updatedCount = transaction.updateDetail(clientId, fileId, status, description);
			
		} catch (Exception e) {
			updatedCount = -1;
			logger.error("Error : " + e.getMessage(), e);
		}
		return updatedCount;
	}

	@Override
	public MacPayrollDetail getDetailWithSequence(String clientId, String fileId, String strRecord) {
		MacPayrollDetail detail = null;
		try {
			detail = transaction.getDetailWithRecordNumber(clientId, fileId, strRecord);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detail;
	}

	@Override
	public List<MacPayrollHeader> findAllForResponseFile() {
		List<MacPayrollHeader> headerList = null;
		try {
			headerList = transaction.findAllForResponseFile();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return headerList;
	}
	
	@Override
	public List<MacPayrollActivityLog> findAllFailedResponseFile() {
		List<MacPayrollActivityLog> headerList = null;
		try {
			headerList = transaction.findAllFailedResponseFile();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return headerList;
	}
	
	@Override
	public MacFileLog getFileLog(String id) {
		MacFileLog log = null;
		try {
			log = transaction.getFileLog(id);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return log;
	}

	@Override
	public boolean updateFileLog(MacFileLog log) {
		boolean status = false;
		try {			
			log.setModifiedBy("SYSTEM");
			log.setModifiedOn(new Timestamp(new Date().getTime()));
			status = transaction.updateFileLog(log);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}
	
	public MacPayrollActivityLog getPaymentProcessLogByFileName(String fileName) {
		MacPayrollActivityLog macPaymentActLog=null;
		try {
		macPaymentActLog=transaction.getPayrollProcessLogByFileName(fileName);
		}
		catch(Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return macPaymentActLog;
	}
	
}
