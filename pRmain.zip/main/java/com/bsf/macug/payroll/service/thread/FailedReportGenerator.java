package com.bsf.macug.payroll.service.thread;

import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.service.InterCustomerDetailsService;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.payro.dto.xml.AcknowledgementResponseXMLDTO;
import com.bsf.macug.payro.dto.xml.AcknowledgementResponseXMLDTO.Body.PayrollResponse.PayrollTransactionResponse;
import com.bsf.macug.payroll.entity.MacPayrollActivityLog;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;
import com.bsf.macug.payroll.service.InterPayrollService;
import com.bsf.macug.payroll.service.InterPayrollUtil;
import com.bsf.macug.util.InterFileUtils;
import com.bsf.macug.util.InterUtils;

@Component
@Scope("prototype")
public class FailedReportGenerator implements Runnable {

	private static final Logger logger = Logger.getLogger(FailedReportGenerator.class.getName());
    
	@Autowired
	InterCustomerDetailsService customerDetailsService;
	
	@Autowired
	InterFileUtils fileUtils;

	@Autowired
	Environment environment;

	@Autowired
	InterUtils utils;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterPayrollService payrollService;

	@Autowired
	InterPayrollUtil payrollUtil;

	private MacPayrollActivityLog macPayrollActiLog;

	@Override
	public void run() {
		try {
			
			
			
			Map<String, Map<String, SystemParameters>> allProperties = utils.loadSystemProperties();
			Map<String, SystemParameters> macPropertyMap = allProperties.get("macPropertyMap");
			String formatType = systemParameterService.getSystemParametersDescription1("MACREQDTF", macPropertyMap);
			String fileReference = macPayrollActiLog.getFileReference();
			String customerId = macPayrollActiLog.getCustomerId();
			String concenateFileValue=macPayrollActiLog.getResponseFileValue();
			CustomerDetails customerDetails=customerDetailsService.getCustomerDetails(customerId);
			if (customerDetails == null) {
				logger.info("Customer not registred. ");
				throw new CustomerNotFoundException("Customer not registred.");
			}
			
			String swNetServicName=customerDetails.getSwNetServicName();
			
			if(StringUtils.isEmpty(swNetServicName)) {
				logger.info("SWNET_SERVICE Field = "+swNetServicName);	
				throw new Exception("SWNET_SERVICE Field is null");
			}
			
			if(StringUtils.isEmpty(concenateFileValue) ) {
				logger.info("File response column value is = "+concenateFileValue);	
				throw new Exception("File response column value is null");
			}
			String custNameFull=customerDetails.getCustNameFull();
			
			if(StringUtils.isEmpty(custNameFull)) {
				logger.info("Customer Name Full = "+custNameFull);	
				throw new Exception("Customer Full name is null");
				
			}
			
			String mt199BulkFlag=customerDetails.getMt199BulkFlag();
			if(StringUtils.isEmpty(mt199BulkFlag)) {
				logger.info("MT199 Bulk Flag = "+mt199BulkFlag);	
				throw new Exception("MT199 Bulk Flag is null");
				
			}
			
			String compName=customerDetails.getCustomerName();
			
			if(StringUtils.isEmpty(compName)) {
				logger.info("Customer name = "+compName);	
				throw new Exception("Customer name is null");
				
			}
			List<MacPayrollDetail> list = payrollService.findAllDetail(customerId, fileReference, null);
			AcknowledgementResponseXMLDTO.Header responseHeader = new AcknowledgementResponseXMLDTO.Header();
			responseHeader.setSender("BSFK");
			responseHeader.setReceiver(customerId);
			responseHeader.setMessageType(macPayrollActiLog.getProcessType());
			responseHeader.setMessageDescription("Payroll Message Acknowledgement");
			DateFormat dfToday = new SimpleDateFormat(formatType);
			responseHeader.setTimeStamp(dfToday.format(new Date()));

			AcknowledgementResponseXMLDTO.Body.PayrollResponse response = new AcknowledgementResponseXMLDTO.Body.PayrollResponse();
			response.setPayrollMessageRef(fileReference);
			response.setPayrollMessageType("MT100-Payroll");
			response.setPayrollTransactionCount(0);
			response.setPayrollTransactionAmount(0);

			List<AcknowledgementResponseXMLDTO.Body.PayrollResponse.PayrollTransactionResponse> lstTransactions = generateTransactionsList(
					list);
			response.setPayrollTransactionResponse(lstTransactions);

			AcknowledgementResponseXMLDTO.Body body = new AcknowledgementResponseXMLDTO.Body();
			body.setPayrollResponse(response);

			AcknowledgementResponseXMLDTO.ResponseStatus status = new AcknowledgementResponseXMLDTO.ResponseStatus();
			status.setStatusCode(macPayrollActiLog.getProcessSubject());
			status.setStatusDetail(macPayrollActiLog.getProcessDescription());

			AcknowledgementResponseXMLDTO responseXMLDTO = new AcknowledgementResponseXMLDTO();
			responseXMLDTO.setHeader(responseHeader);
			responseXMLDTO.setBody(body);
			responseXMLDTO.setResponseStatus(status);
			
			/*MacPayrollHeader payrollHeader = payrollService.getHeader(customerId, fileReference);
			if (payrollHeader == null) {
			logger.info("No Record found for Customer ="+ customerId +"File Reference ="+ fileReference); 
			throw new Exception("No Record found for Customer ="+ customerId +"File Reference ="+ fileReference);
			}*/

			String strResponseMessage = payrollUtil.generateResponseFromXMLDTO(responseXMLDTO);
			//newHeader.setResponseContent(strResponseMessage.getBytes("UTF-8"));
			//String fileName = "RES_"+customerId + "_"+fileReference+".xml";
			String fileName = macPayrollActiLog.getCustReqFile()+"."+macPayrollActiLog.getResponseFileValue();
			
			fileUtils.createFile(strResponseMessage, customerId, fileName);
			macPayrollActiLog.setResStatus("GENERATED");
			
			writeEnvelopeFile(fileName,customerId,compName,swNetServicName,custNameFull,fileReference);
			logger.info("Envelope File generated successfully ");
			
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		macPayrollActiLog.setProcessStatus(2);
		payrollService.updatePayrollActivLog(macPayrollActiLog);

	}

	private List<PayrollTransactionResponse> generateTransactionsList(List<MacPayrollDetail> lstTransactiondetails) {
		List<PayrollTransactionResponse> lstPayrollTransactions = null;
		lstPayrollTransactions = new ArrayList<PayrollTransactionResponse>();
		logger.info("(generateTransactionsList)==> Framing transactions details");
		for (MacPayrollDetail payrollTransaction : lstTransactiondetails) {
			PayrollTransactionResponse responseTransaction = new PayrollTransactionResponse();
			String strTransactionStatus = payrollTransaction.getStatus();
			String strTransactionMessage = payrollTransaction.getStatusDesc();
			String strSequenceNum = payrollTransaction.getSequenceNum();
			String strTransactionRef = payrollTransaction.getTransRef();
			responseTransaction.setStatusCode(strTransactionStatus);
			responseTransaction.setStatusDetail(strTransactionMessage);
			responseTransaction.setSequenceNum(strSequenceNum);
			responseTransaction.setTransactionRef(strTransactionRef);
			lstPayrollTransactions.add(responseTransaction);
		}
		return lstPayrollTransactions;
	}
	
	 public boolean writeEnvelopeFile(String actualFileLocation,String customerId,String customerName,
			String swNetServicName,String custNameFull,String fileReference){
		Random r = new Random();
	    int count=r.nextInt(100000);
		String sourceEnvelopePath="D:\\macug\\sftp\\fileact_response\\source\\";
		StringBuffer fileContent=new StringBuffer();
        //fileContent.append("0000 APP_APPLI_CODE APP1 "+"FICOUT");
		fileContent.append("0000 APP_APPLI_CODE "+"FICOUT");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_FILE_NB 000001");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_FLOW IMPORT");
        fileContent.append(Character.toString ((char)23));
        fileContent.append(Character.toString ((char)3));
        fileContent.append("\n");
        fileContent.append("0101 APP_MSG_NB 001");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_COMPANY BSF");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_SERVICE FILEACT");
        fileContent.append(Character.toString ((char)23));
        
        fileContent.append("APP_TRANS_CODE ");
       // fileContent.append(Character.toString ((char)23));
        fileContent.append("FACT_MACUGRT");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_CORR_ID ");
        //it should be from database
        fileContent.append(custNameFull.trim());
        fileContent.append(Character.toString ((char)23));
        
        fileContent.append("APP_REQUESTOR_DN ");
        
        fileContent.append("o=bsfrsari,o=swift");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_FILE_DESC ");
        
        fileContent.append("PAYR");
        fileContent.append(Character.toString ((char)23));   
                 
        fileContent.append("APP_MSG_NAT FIC");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_MSG_TYPE FIC"); 
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_MSG_PRIO_CAT ");
       // fileContent.append("\n");
        fileContent.append("N"+Character.toString ((char)23));
        fileContent.append("APP_MSG_TXT_TYPE FIC");
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_RESPONDER_DN ");
        
        //fileContent.append("o="+actualFileLocation.substring(21,29)+","+"o=swift");
       // fileContent.append("o=naicsari,o=swift");
        fileContent.append(customerName+",o=swift");
        fileContent.append(Character.toString ((char)23));
        
        fileContent.append("APP_SWNET_SERVICE ");
        
       // fileContent.append("bsfrsa.macugst!p");
        fileContent.append(swNetServicName);
        fileContent.append(Character.toString ((char)23));
        
        fileContent.append("APP_REQ_TYPE ");
        fileContent.append("pacs.fin.mt9xx");
        fileContent.append(Character.toString ((char)23));
        
        fileContent.append("APP_MSG_TXT ");
       
        fileContent.append("/stelink/v2.2/fileact/out/"+actualFileLocation);
        
       // fileContent.append("N"+Character.toString ((char)23));
        fileContent.append(Character.toString ((char)23));
        fileContent.append("APP_ENDFCT EOM");
        fileContent.append(Character.toString ((char)23));
        fileContent.append(Character.toString ((char)3));
        fileContent.append("\n");
        fileContent.append("0000 APP_ENDFILE EOF");
        fileContent.append(Character.toString ((char)23));
        fileContent.append(Character.toString ((char)3));
        
        byte[] byRemoteContents = null;
       // FileUtils fielUtils=new FileUtils();
        //String todayPath=fielUtils.createTodayFolder(sourceEnvelopePath);
        //String pattern = "yyyyMMddHHmmss"; 
        String pattern = "yyyyMMddHHmmssSS";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        String date = simpleDateFormat.format(new Date());
       
        try {
        byRemoteContents=fileContent.toString().getBytes();
        String path= sourceEnvelopePath+"/envelop_"+date+"_"+count+".txt";
       
        FileOutputStream fout = new FileOutputStream(path);
		fout.write(byRemoteContents, 0, byRemoteContents.length);
		fout.close();
        }
        catch(Exception fn) {
       	return false; 	
        }
       
		return true;
	}

	public void setNewHeader(MacPayrollActivityLog macPayrollActiLog) {
		this.macPayrollActiLog = macPayrollActiLog;
	}

}
