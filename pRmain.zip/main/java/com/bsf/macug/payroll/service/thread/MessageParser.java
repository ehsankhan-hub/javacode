package com.bsf.macug.payroll.service.thread;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bsf.macug.exception.XMLParsingException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.payro.dto.xml.RequestMessage;
import com.bsf.macug.payro.dto.xml.RequestMessage.Body.PayrollMessage;
import com.bsf.macug.payro.dto.xml.RequestMessage.Body.PayrollMessage.PayrollTransaction;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;
import com.bsf.macug.payroll.service.InterPayrollService;
import com.bsf.macug.payroll.service.InterPayrollUtil;
import com.bsf.macug.util.InterFileUtils;
import com.bsf.macug.util.InterUtils;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field59;
import com.prowidesoftware.swift.model.field.Field70;
import com.prowidesoftware.swift.model.field.Field72;

@Component
@Scope("prototype")
public class MessageParser implements Runnable {

	private static final Logger logger = Logger.getLogger(MessageParser.class.getName());

	@Autowired
	InterFileUtils fileUtils;

	@Autowired
	Environment environment;

	@Autowired
	InterUtils utils;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterPayrollService payrollService;

	@Autowired
	InterPayrollUtil payrollUtil;

	MacPayrollHeader newHeader;

	@Override
	public void run() {
		Map<String, SystemParameters> errorCodeMap = null;
		try {
			Map<String, Map<String, SystemParameters>> allProperties = utils.loadSystemProperties();
			errorCodeMap = allProperties.get("errorCodeMap");
			byte[] requestContent = newHeader.getRequestContent();
			String data = new String(requestContent, "UTF-8");
			RequestMessage payrollMessageObj = payrollUtil.parseXMLMessage(data);
			PayrollMessage payrollMessageBody = payrollMessageObj.getBody().getPayrollMessage();
			List<PayrollTransaction> allTransaction = payrollMessageBody.getPayrollTransaction();
			long count = 0;
			for (PayrollTransaction transactionObj : allTransaction) {
				try {
					count++;
					String transactionData = transactionObj.getTransactionData();
					SwiftMessage sm = SwiftMessage.parse("{4:" + transactionData + "-}");
					SwiftBlock4 block4 = sm.getBlock4();
					List<Tag> tags = block4.getTags();
					MacPayrollDetail detailsObj = prepareDetails(tags);
					detailsObj.setClientId(newHeader.getClientId());
					detailsObj.setFileId(newHeader.getFileId());
					detailsObj.setRecordNo(count + "");
					detailsObj.setStatus("RECEIVED");
					detailsObj.setStatusDesc("Transaction received successfully.");
					payrollUtil.saveDetails(detailsObj);
					if(count == 1) {
						newHeader.setOrdCustAcc(detailsObj.getOrdCustAcc());
					}
				} catch (Exception e) {
					logger.error("Error : " + e.getMessage(), e);
				}

			}
			newHeader.setStatus("PENDING");
			newHeader.setDescription("Pending for validation.");
			newHeader.setProcessingStatus(0);
			payrollService.updateHeader(newHeader);
		} catch (XMLParsingException e) {
			logger.error("Error : " + e.getMessage(), e);
			newHeader = payrollUtil.setStatusAndDescription(newHeader, "FAILED", "MACVER023", errorCodeMap);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			newHeader = payrollUtil.setStatusAndDescription(newHeader, "FAILED", "MACVER002", errorCodeMap);
		}
		newHeader.setProcessingStatus(0);
		payrollService.updateHeader(newHeader);
	}

	private MacPayrollDetail prepareDetails(List<Tag> tags) {
		MacPayrollDetail details = new MacPayrollDetail();
		for (Tag tag : tags) {
			String tagName = tag.getName();
			switch (tagName) {
			case "20":
				details.setTransRef(tag.getValue());
				break;
			case "32A":
				details = parse32A(tag, details);
				break;
			case "52A":
				details.setInstructionParty(tag.getValue());
				break;
			case "53B":
				details = parseDebitAccount(tag, details);
				break;
			case "57A":
				details.setAccWithInst57a(tag.getValue());
				break;
			case "59":
				details = parseBenAccount(tag, details);
				break;
			case "70":
				details = parseTag70(tag, details);
				break;
			case "72":
				details = parseTag72(tag, details);
				break;
			default:
				break;
			}
		}
		return details;
	}

	private MacPayrollDetail parseTag72(Tag tag, MacPayrollDetail details) {
		try {
			Field72 field72 = (Field72) tag.getField();
			details.setEmployeeId(field72.getComponent1());

			String basicStr = field72.getComponent2();
			String housingStr = field72.getComponent3();
			String otherStr = field72.getComponent4();
			String deductionStr = field72.getComponent5();

			details.setEmployeeBasic(new BigDecimal(basicStr.replace(",", ".")));
			details.setEmployeeHousing(new BigDecimal(housingStr.replace(",", ".")));
			details.setEmployeeOther(new BigDecimal(otherStr.replace(",", ".")));
			details.setEmployeeDeduction(new BigDecimal(deductionStr.replace(",", ".")));
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return details;
	}

	private MacPayrollDetail parseTag70(Tag tag, MacPayrollDetail details) {
		try {
			Field70 field70 = (Field70) tag.getField();
			details.setRemDet1(field70.getComponent1());
			details.setRemDet2(field70.getComponent2());
			details.setRemDet3(field70.getComponent3());
			details.setRemDet4(field70.getComponent4());
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return details;
	}

	private MacPayrollDetail parseBenAccount(Tag tag, MacPayrollDetail details) {
		try {
			Field59 field59 = (Field59) tag.getField();
			String benAccount = field59.getAccount();
			if (benAccount.contains("/")) {
				benAccount = benAccount.substring(1);
			}
			details.setBenAccountNo(benAccount);
			details.setBenAccountDet1(field59.getComponent2());
			details.setBenAccountDet2(field59.getComponent3());
			details.setBenAccountDet3(field59.getComponent4());
			details.setBenAccountDet4(field59.getComponent5());
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return details;
	}

	private MacPayrollDetail parseDebitAccount(Tag tag, MacPayrollDetail details) {
		try {
			String debitAccount = tag.getValue();
			if (debitAccount.contains("/")) {
				debitAccount = debitAccount.substring(1);
			}
			details.setOrdCustAcc(debitAccount);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return details;
	}

	private MacPayrollDetail parse32A(Tag tag, MacPayrollDetail details) {
		Date valueDate = null;
		String valueDateStr = "";
		String curCode = "";
		BigDecimal amount = null;
		String strAmount = "";
		try {
			String line = tag.getValue();
			valueDateStr = line.substring(0, 6);
			curCode = line.substring(6, 9);
			strAmount = line.substring(9);

			DateFormat format = new SimpleDateFormat("yyMMdd");
			valueDate = format.parse(valueDateStr);

			amount = new BigDecimal(strAmount.replace(",", "."));
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		details.setValueDate(valueDate);
		details.setTransactionAmount(amount);
		details.setCurCode(curCode);
		return details;
	}

	public void setHeader(MacPayrollHeader newHeader) {
		this.newHeader = newHeader;
	}

}
