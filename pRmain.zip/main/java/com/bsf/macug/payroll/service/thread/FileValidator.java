package com.bsf.macug.payroll.service.thread;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.service.InterCustomerAccountsService;
import com.bsf.macug.customer.service.InterCustomerDetailsService;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.exception.SystemPropertyNotConfigurationException;
import com.bsf.macug.exception.TCPConnectionException;
import com.bsf.macug.exception.TuxedoException;
import com.bsf.macug.exception.ValidationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.payroll.dto.AccountEnquiryResponseDTO;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;
import com.bsf.macug.payroll.service.InterPayrollService;
import com.bsf.macug.payroll.service.InterPayrollUtil;
import com.bsf.macug.payroll.service.InterPayrollValidationService;
import com.bsf.macug.payroll.service.tuxedo.InterAccountEnquiryService;
import com.bsf.macug.util.InterUtils;

@Component
@Scope("prototype")
public class FileValidator implements Runnable {

	private static final Logger logger = Logger.getLogger(FileValidator.class.getName());

	MacPayrollHeader newHeader;

	@Autowired
	InterCustomerDetailsService customerDetailsService;

	@Autowired
	InterCustomerAccountsService customerAccountsService;

	@Autowired
	InterPayrollValidationService payrollValidationService;

	@Autowired
	InterPayrollService payrollService;

	@Autowired
	InterUtils utils;

	@Autowired
	InterPayrollUtil payrollUtil;

	@Autowired
	InterAccountEnquiryService accountEnquiryService;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Override
	public void run() {
		boolean processedSuccessfully = false;
		Map<String, SystemParameters> errorCodeMap = null;
		Map<String, SystemParameters> tuxErrorCodeMap = null;
		List<MacPayrollDetail> lstPayrollTransaction = null;
		boolean detailsUpdateStatus = false;
		try {
			Map<String, Map<String, SystemParameters>> allProperties = utils.loadSystemProperties();
			Map<String, SystemParameters> tuxDetailMap = allProperties.get("tuxDetailMap");
			Map<String, SystemParameters> macPropertyMap = allProperties.get("macPropertyMap");
			errorCodeMap = allProperties.get("errorCodeMap");
			tuxErrorCodeMap = allProperties.get("tuxErrorCodeMap");
			CustomerDetails customerDetails = customerDetailsService.getCustomerDetails(newHeader.getClientId());
			if (customerDetails == null) {
				throw new CustomerNotFoundException("Customer not registred.");
			}
			lstPayrollTransaction = payrollService.findAllDetail(newHeader.getClientId(), newHeader.getFileId(), null);

			payrollValidationService.isCommonValidationsPassed(newHeader, lstPayrollTransaction);

			String debitAccount = lstPayrollTransaction.get(0).getOrdCustAcc();

			CustomerAccounts customerAccount = customerAccountsService
					.getCustomerAccountDetails(newHeader.getClientId(), debitAccount, "PAYROLL");
			if (customerAccount == null) {
				throw new ValidationException("MACVER018");
			}

			AccountEnquiryResponseDTO enquiryResponseForDebitAccount = accountEnquiryService
					.buildAccountEnquiryResponse(debitAccount, tuxDetailMap);

			payrollValidationService.validateAccountAndBalance(enquiryResponseForDebitAccount, newHeader,
					customerDetails, customerAccount, allProperties);
			newHeader.setFileName(prepareFileName(customerDetails, macPropertyMap));
			newHeader.setStatus("READY");
			newHeader.setDescription("Ready to upload.");
			detailsUpdateStatus = payrollUtil.updateDetails(newHeader, lstPayrollTransaction,"PENDING","Pending for upload.");
			processedSuccessfully = true;
		} catch (CustomerNotFoundException e) {
			logger.error("Error : " + e.getMessage(), e);
			newHeader = payrollUtil.setStatusAndDescription(newHeader, "FAILED", "MACVER008", errorCodeMap);
		} catch (ValidationException e) {
			String errorCode = e.getErrorCode();
			logger.error("Error : " + e.getMessage(), e);
			newHeader = payrollUtil.setStatusAndDescription(newHeader, "FAILED", errorCode, errorCodeMap);
		} catch (SystemPropertyNotConfigurationException e) {
			logger.error("Error : " + e.getMessage(), e);
			newHeader = payrollUtil.setStatusAndDescription(newHeader, "FAILED", "MACVER002", errorCodeMap);
		} catch (TCPConnectionException e) {
			logger.error("Error : " + e.getMessage(), e);
			newHeader = payrollUtil.setStatusAndDescription(newHeader, "FAILED", "MACVER002", errorCodeMap);
		} catch (TuxedoException e) {
			String errorCode = e.getErrorCode();
			logger.error("Error : " + e.getMessage(), e);
			newHeader = payrollUtil.setStatusAndDescription(newHeader, "FAILED", errorCode, tuxErrorCodeMap);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			newHeader = payrollUtil.setStatusAndDescription(newHeader, "FAILED", "MACVER002", errorCodeMap);
		}

		newHeader.setProcessingStatus(0);

		if (!detailsUpdateStatus && processedSuccessfully) {
			newHeader = payrollUtil.setStatusAndDescription(newHeader, "FAILED", "MACVER002", errorCodeMap);
		}
		boolean status = payrollUtil.updateHeader(newHeader);
	}

	public void setHeader(MacPayrollHeader newHeader) {
		this.newHeader = newHeader;
	}

	private String prepareFileName(CustomerDetails customer, Map<String, SystemParameters> macPropertyMap) {
		String strPayrollFileName = null;
		try {
			String strFormat = systemParameterService.getSystemParametersDescription1("PYRRSTFRM", macPropertyMap);
			DateFormat dfRestFormat = new SimpleDateFormat(strFormat);
			strPayrollFileName = customer.getPayrollId() + "-" + newHeader.getFileId() + "-" + customer.getCustomerId()
					+ "-MAC-" + dfRestFormat.format(new Date());
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		logger.info("File name for uploading : " + strPayrollFileName);
		return strPayrollFileName;
	}
}
