package com.bsf.macug.payroll.service;

import java.io.StringReader;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bsf.macug.exception.DuplicateFileException;
import com.bsf.macug.exception.XMLParsingException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.payro.dto.xml.AcknowledgementResponseXMLDTO;
import com.bsf.macug.payro.dto.xml.RequestMessage;
import com.bsf.macug.payroll.entity.MacFileLog;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;

@Service
public class PayrollUtilImpl implements InterPayrollUtil {

	private static final Logger logger = Logger.getLogger(PayrollUtilImpl.class.getName());

	@Autowired
	InterPayrollService payrollService;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Override
	public MacFileLog saveLog(String uniqueId, byte[] requestData) {
		MacFileLog log = null;
		try {
			log = new MacFileLog();
			UUID guid = java.util.UUID.randomUUID();
			log.setId(guid.toString());
			log.setFileLinkId(uniqueId);
			log.setData(requestData);
			payrollService.savePayrollLog(log);
			log = payrollService.getFileLog(guid.toString());
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return log;
	}

	@Override
	public void checkIfFileIdExists(String customerId, String fileId) throws DuplicateFileException {
		try {
			MacPayrollHeader header = payrollService.getHeader(customerId, fileId);
			if (header != null) {
				throw new DuplicateFileException(
						"Header already exists. fileID : " + fileId + " , CustId : " + customerId);
			}
		} catch (DuplicateFileException e) {
			throw e;
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new DuplicateFileException();
		}
	}

	@Override
	public RequestMessage parseXMLMessage(String data) throws XMLParsingException {
		Unmarshaller unmarshaller;
		RequestMessage requestObj = null;
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(RequestMessage.class);
			unmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(data.trim());
			requestObj = (RequestMessage) unmarshaller.unmarshal(reader);
		} catch (JAXBException e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new XMLParsingException();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			throw new XMLParsingException();
		}
		if (requestObj == null) {
			logger.error("(parseClassicXMLToObject) ==> RequestObject is null");
			throw new XMLParsingException();
		}
		return requestObj;
	}

	@Override
	public boolean checkIfValidRequestDateTime(String requestDateTime, Map<String, SystemParameters> macPropertyMap) {

		if (StringUtils.isEmpty(requestDateTime)) {
			return false;
		}
		String formatType = systemParameterService.getSystemParametersDescription1("MACREQDTF", macPropertyMap);
		SimpleDateFormat format = new SimpleDateFormat(formatType);
		try {
			Date date = format.parse(requestDateTime);
			Date today = new Date();
			format = new SimpleDateFormat("yyyy-MM-dd");
			String strDate = format.format(today);
			String reqDateTime = format.format(date);
			if (strDate.equals(reqDateTime)) {
				return true;
			}
		} catch (Exception e) {
			logger.error("Error " + e.getMessage(), e);
		}
		return false;

	}

	@Override
	public boolean saveDetails(MacPayrollDetail details) {
		boolean status = false;
		try {
			payrollService.saveDetail(details);
			status = true;
		} catch (Exception e) {
			logger.error("Error " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public MacPayrollHeader setStatusAndDescription(MacPayrollHeader header, String status, String errorCode,
			Map<String, SystemParameters> map) {
		try {
			String description = systemParameterService.getSystemParametersDescription2(errorCode, map);
			header.setStatus(status);
			header.setDescription(description);
		} catch (Exception e) {
			header.setStatus(status);
			header.setDescription("Description not found.");
		}
		return header;
	}

	@Override
	public boolean updateDetails(MacPayrollHeader newHeader, List<MacPayrollDetail> lstPayrollTransaction,
			String mStatus, String description) {
		boolean status = false;
		try {
			int updateCount = payrollService.updateDetail(newHeader.getClientId(), newHeader.getFileId(), mStatus,
					description);
			if (updateCount == lstPayrollTransaction.size()) {
				status = true;
			} else {
				logger.error("Details update count mismatch.");
			}
		} catch (Exception e) {
			logger.error("Error " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public boolean updateHeader(MacPayrollHeader newHeader) {
		boolean status = false;
		try {
			payrollService.updateHeader(newHeader);
			status = true;
		} catch (Exception e) {
			logger.error("Error " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public String generateResponseFromXMLDTO(AcknowledgementResponseXMLDTO responseXMLDTO) {
		String strResponse = "";
		try {
			logger.info(
					"(generateResponseFromXMLDTO)==> Converting the AcknowledgementResponseXMLDTO to string message");
			JAXBContext jaxbContext = JAXBContext.newInstance(AcknowledgementResponseXMLDTO.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			StringWriter sw = new StringWriter();
			jaxbMarshaller.marshal(responseXMLDTO, sw);
			strResponse = sw.toString();
		} catch (JAXBException e) {
			logger.error("(generateResponseFromXMLDTO)==> Error : " + e.getMessage(), e);
		} catch (Exception e) {
			logger.error("(generateResponseFromXMLDTO)==> Error : " + e.getMessage(), e);
		}
		return strResponse;
	}

	@Override
	public boolean updateLog(MacFileLog log) {
		boolean status = false;
		try {
			if (log != null)
				status = payrollService.updateFileLog(log);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}
}
