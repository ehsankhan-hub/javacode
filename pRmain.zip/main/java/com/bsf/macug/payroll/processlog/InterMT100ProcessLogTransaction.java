package com.bsf.macug.payroll.processlog;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.payroll.entity.MacPayrollActivityLog;

public interface InterMT100ProcessLogTransaction {

	public boolean saveMT100ProcessLog(MacPayrollActivityLog activityLog) throws DataAccessException;

}
