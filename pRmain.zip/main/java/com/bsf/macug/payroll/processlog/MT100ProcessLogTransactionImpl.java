package com.bsf.macug.payroll.processlog;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.payroll.dao.InterPayrollDAO;
import com.bsf.macug.payroll.entity.MacPayrollActivityLog;

@Transactional
@Service
public class MT100ProcessLogTransactionImpl implements InterMT100ProcessLogTransaction {

	@Autowired
	InterPayrollDAO payrollDAO;

	@Override
	public boolean saveMT100ProcessLog(MacPayrollActivityLog activityLog) throws DataAccessException{
		try {
			return payrollDAO.savePayrollProcessLog(activityLog);
		} catch (Exception e) {
			return false;
		}
	}

}
