package com.bsf.macug.payroll.processlog;


import com.bsf.macug.payroll.dto.MacPayrollActivityLogDTO;

public interface InterMT100ProcessLogService {

	boolean saveMT100PaymentActivityLog(MacPayrollActivityLogDTO activityLogDTO);

}
