package com.bsf.macug.payroll.processlog;

import java.util.Date;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bsf.macug.payroll.dto.MacPayrollActivityLogDTO;
import com.bsf.macug.payroll.entity.MacPayrollActivityLog;


@Service
public class MT100ProcessLogServiceImpl implements InterMT100ProcessLogService {

	private static final Logger logger = Logger.getLogger(MT100ProcessLogServiceImpl.class);

	@Autowired
	InterMT100ProcessLogTransaction processLogTransaction;

	@Override
	public boolean saveMT100PaymentActivityLog(MacPayrollActivityLogDTO activityLogDTO) {
		boolean blStatus = false;
		try {
			MacPayrollActivityLog activityLog = null;
			activityLog = new MacPayrollActivityLog();
			BeanUtils.copyProperties(activityLogDTO, activityLog);
			activityLog.setProcessCreatedOn(new Date());
			String strDesc = activityLog.getProcessDescription();
			String strfileName = activityLog.getProcessFileName();
			if (!StringUtils.isEmpty(strDesc)) {
				if (strDesc.length() > 2499) {
					strDesc = strDesc.substring(0, 2495);
					activityLog.setProcessDescription(strDesc);
				}
			}
			if (!StringUtils.isEmpty(strfileName)) {
				if (strfileName.length() > 299) {
					strfileName = strfileName.substring(strfileName.length() - 295, strfileName.length());
					activityLog.setProcessFileName(strfileName);
				}
			}
			UUID uuid = UUID.randomUUID();
			String uniqueId = uuid.toString();
			activityLog.setProcessActivityID(uniqueId);
			blStatus = processLogTransaction.saveMT100ProcessLog(activityLog);
		} catch (Exception e) {
			logger.error("Error occured in saving the MT100 activity log " + e.getMessage(), e);
		}
		return blStatus;
	}

}
