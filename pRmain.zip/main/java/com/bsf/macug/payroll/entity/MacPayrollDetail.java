package com.bsf.macug.payroll.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;


/**
 * The persistent class for the MAC_PAYROLL_DETAIL database table.
 * 
 */
@Entity
@Table(name="MAC_PAYROLL_DETAIL")
public class MacPayrollDetail implements Serializable {
	private static final long serialVersionUID = 1L;


	@Id
	@Column(name="CLIENT_ID")
	private String clientId;

	@Id
	@Column(name="FILE_ID")
	private String fileId;

	@Id
	@Column(name="RECORD_NO")
	private String recordNo;
	
	@Column(name="ACC_SRV_BIC")
	private String accSrvBic;

	@Column(name="ACC_WITH_INST_57A")
	private String accWithInst57a;

	@Column(name="ACC_WITH_INST_57D")
	private String accWithInst57d;

	@Column(name="BEN_ACCOUNT_DET1")
	private String benAccountDet1;

	@Column(name="BEN_ACCOUNT_DET2")
	private String benAccountDet2;

	@Column(name="BEN_ACCOUNT_DET3")
	private String benAccountDet3;

	@Column(name="BEN_ACCOUNT_DET4")
	private String benAccountDet4;

	@Column(name="BEN_ACCOUNT_NO")
	private String benAccountNo;

	@Column(name="CREATED_DATE")
	private Timestamp craetedDate;

	@Column(name="CREATED_ID")
	private String createdId;

	@Column(name="CUR_CODE")
	private String curCode;

	@Column(name="DET_CHARGE")
	private String detCharge;

	@Column(name="EMPLOYEE_BASIC")
	private BigDecimal employeeBasic;

	@Column(name="EMPLOYEE_DEDUCTION")
	private BigDecimal employeeDeduction;

	@Column(name="EMPLOYEE_HOUSING")
	private BigDecimal employeeHousing;

	@Column(name="EMPLOYEE_ID")
	private String employeeId;

	@Column(name="EMPLOYEE_OTHER")
	private BigDecimal employeeOther;

	@Column(name="FX_DEAL_REF")
	private String fxDealRef;

	private String id;

	@Column(name="INSTRUCTION_PARTY")
	private String instructionParty;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_ID")
	private String modifiedId;

	@Column(name="ORD_CUST_ACC")
	private String ordCustAcc;

	@Column(name="ORD_CUST_DET1")
	private String ordCustDet1;

	@Column(name="ORD_CUST_DET2")
	private String ordCustDet2;

	@Column(name="ORD_CUST_DET3")
	private String ordCustDet3;

	@Column(name="ORD_CUST_DET4")
	private String ordCustDet4;

	@Column(name="PAY_RETURN_DATE")
	private Timestamp payReturnDate;

	@Column(name="REM_DET70_1")
	private String remDet1;

	@Column(name="REM_DET70_2")
	private String remDet2;

	@Column(name="REM_DET70_3")
	private String remDet3;

	@Column(name="REM_DET70_4")
	private String remDet4;

	@Column(name="SELL_CUR_AMOUNT")
	private BigDecimal sellCurAmount;

	@Column(name="SELL_CUR_CODE")
	private String sellCurCode;

	@Column(name="SEQUENCE_NUM")
	private String sequenceNum;

	private String status;

	@Column(name="STATUS_DESC")
	private String statusDesc;

	@Column(name="TRANS_REF")
	private String transRef;

	@Column(name="TRANSACTION_AMOUNT")
	private BigDecimal transactionAmount;

	@Temporal(TemporalType.DATE)
	@Column(name="VALUE_DATE")
	private Date valueDate;

	@Version
	@Column(name = "VERSION")
	private Integer version;
	
	public MacPayrollDetail() {
	}

	public String getAccSrvBic() {
		return this.accSrvBic;
	}

	public void setAccSrvBic(String accSrvBic) {
		this.accSrvBic = accSrvBic;
	}

	public String getAccWithInst57a() {
		return this.accWithInst57a;
	}

	public void setAccWithInst57a(String accWithInst57a) {
		this.accWithInst57a = accWithInst57a;
	}

	public String getAccWithInst57d() {
		return this.accWithInst57d;
	}

	public void setAccWithInst57d(String accWithInst57d) {
		this.accWithInst57d = accWithInst57d;
	}

	public String getBenAccountDet1() {
		return this.benAccountDet1;
	}

	public void setBenAccountDet1(String benAccountDet1) {
		this.benAccountDet1 = benAccountDet1;
	}

	public String getBenAccountDet2() {
		return this.benAccountDet2;
	}

	public void setBenAccountDet2(String benAccountDet2) {
		this.benAccountDet2 = benAccountDet2;
	}

	public String getBenAccountDet3() {
		return this.benAccountDet3;
	}

	public void setBenAccountDet3(String benAccountDet3) {
		this.benAccountDet3 = benAccountDet3;
	}

	public String getBenAccountDet4() {
		return this.benAccountDet4;
	}

	public void setBenAccountDet4(String benAccountDet4) {
		this.benAccountDet4 = benAccountDet4;
	}

	public String getBenAccountNo() {
		return this.benAccountNo;
	}

	public void setBenAccountNo(String benAccountNo) {
		this.benAccountNo = benAccountNo;
	}

	public Timestamp getCraetedDate() {
		return this.craetedDate;
	}

	public void setCraetedDate(Timestamp craetedDate) {
		this.craetedDate = craetedDate;
	}

	public String getCreatedId() {
		return this.createdId;
	}

	public void setCreatedId(String createdId) {
		this.createdId = createdId;
	}

	public String getCurCode() {
		return this.curCode;
	}

	public void setCurCode(String curCode) {
		this.curCode = curCode;
	}

	public String getDetCharge() {
		return this.detCharge;
	}

	public void setDetCharge(String detCharge) {
		this.detCharge = detCharge;
	}

	public BigDecimal getEmployeeBasic() {
		return this.employeeBasic;
	}

	public void setEmployeeBasic(BigDecimal employeeBasic) {
		this.employeeBasic = employeeBasic;
	}

	public BigDecimal getEmployeeDeduction() {
		return this.employeeDeduction;
	}

	public void setEmployeeDeduction(BigDecimal employeeDeduction) {
		this.employeeDeduction = employeeDeduction;
	}

	public BigDecimal getEmployeeHousing() {
		return this.employeeHousing;
	}

	public void setEmployeeHousing(BigDecimal employeeHousing) {
		this.employeeHousing = employeeHousing;
	}

	public String getEmployeeId() {
		return this.employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public BigDecimal getEmployeeOther() {
		return this.employeeOther;
	}

	public void setEmployeeOther(BigDecimal employeeOther) {
		this.employeeOther = employeeOther;
	}

	public String getFxDealRef() {
		return this.fxDealRef;
	}

	public void setFxDealRef(String fxDealRef) {
		this.fxDealRef = fxDealRef;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getInstructionParty() {
		return this.instructionParty;
	}

	public void setInstructionParty(String instructionParty) {
		this.instructionParty = instructionParty;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedId() {
		return this.modifiedId;
	}

	public void setModifiedId(String modifiedId) {
		this.modifiedId = modifiedId;
	}

	public String getOrdCustAcc() {
		return this.ordCustAcc;
	}

	public void setOrdCustAcc(String ordCustAcc) {
		this.ordCustAcc = ordCustAcc;
	}

	public String getOrdCustDet1() {
		return this.ordCustDet1;
	}

	public void setOrdCustDet1(String ordCustDet1) {
		this.ordCustDet1 = ordCustDet1;
	}

	public String getOrdCustDet2() {
		return this.ordCustDet2;
	}

	public void setOrdCustDet2(String ordCustDet2) {
		this.ordCustDet2 = ordCustDet2;
	}

	public String getOrdCustDet3() {
		return this.ordCustDet3;
	}

	public void setOrdCustDet3(String ordCustDet3) {
		this.ordCustDet3 = ordCustDet3;
	}

	public String getOrdCustDet4() {
		return this.ordCustDet4;
	}

	public void setOrdCustDet4(String ordCustDet4) {
		this.ordCustDet4 = ordCustDet4;
	}

	public Timestamp getPayReturnDate() {
		return this.payReturnDate;
	}

	public void setPayReturnDate(Timestamp payReturnDate) {
		this.payReturnDate = payReturnDate;
	}

	public String getRemDet1() {
		return this.remDet1;
	}

	public void setRemDet1(String remDet1) {
		this.remDet1 = remDet1;
	}

	public String getRemDet2() {
		return this.remDet2;
	}

	public void setRemDet2(String remDet2) {
		this.remDet2 = remDet2;
	}

	public String getRemDet3() {
		return this.remDet3;
	}

	public void setRemDet3(String remDet3) {
		this.remDet3 = remDet3;
	}

	public String getRemDet4() {
		return this.remDet4;
	}

	public void setRemDet4(String remDet4) {
		this.remDet4 = remDet4;
	}

	public BigDecimal getSellCurAmount() {
		return this.sellCurAmount;
	}

	public void setSellCurAmount(BigDecimal sellCurAmount) {
		this.sellCurAmount = sellCurAmount;
	}

	public String getSellCurCode() {
		return this.sellCurCode;
	}

	public void setSellCurCode(String sellCurCode) {
		this.sellCurCode = sellCurCode;
	}

	public String getSequenceNum() {
		return this.sequenceNum;
	}

	public void setSequenceNum(String sequenceNum) {
		this.sequenceNum = sequenceNum;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return this.statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getTransRef() {
		return this.transRef;
	}

	public void setTransRef(String transRef) {
		this.transRef = transRef;
	}

	public BigDecimal getTransactionAmount() {
		return this.transactionAmount;
	}

	public void setTransactionAmount(BigDecimal transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public Date getValueDate() {
		return this.valueDate;
	}

	public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}

	public Integer getVersion() {
		return this.version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getRecordNo() {
		return recordNo;
	}

	public void setRecordNo(String recordNo) {
		this.recordNo = recordNo;
	}

	
}