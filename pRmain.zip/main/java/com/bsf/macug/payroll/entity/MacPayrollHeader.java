package com.bsf.macug.payroll.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;


/**
 * The persistent class for the MAC_PAYROLL_HEADER database table.
 * 
 */
@Entity
@Table(name="MAC_PAYROLL_HEADER")
public class MacPayrollHeader implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="FILE_ID")
	private String fileId;

	@Id
	@Column(name="CLIENT_ID")
	private String clientId;
	
	@Column(name="ACAC_COUNT")
	private BigDecimal acacCount;

	@Column(name="ALERT_COUNT")
	private BigDecimal alertCount;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	private String description;

	@Column(name="FILE_NAME")
	private String fileName;

	private String id;

	@Column(name="LOAD_TIME")
	private Timestamp loadTime;

	@Column(name="MODIFIED_BY")
	private String modifiedBy;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="ORD_CUST_ACC")
	private String ordCustAcc;

	@Column(name="ORD_CUST_DET1")
	private String ordCustDet1;

	@Column(name="ORD_CUST_DET2")
	private String ordCustDet2;

	@Column(name="ORD_CUST_DET3")
	private String ordCustDet3;

	@Column(name="ORD_CUST_DET4")
	private String ordCustDet4;

	@Column(name="PROCESSED_COUNT")
	private BigDecimal processedCount;

	@Column(name="RECEIVED_AMOUNT")
	private BigDecimal receivedAmount;

	@Column(name="RECEIVED_COUNT")
	private BigDecimal receivedCount;

	@Column(name="REJECTED_COUNT")
	private BigDecimal rejectedCount;

	@Lob
	@Column(name="REQUEST_CONTENT")
	private byte[] requestContent;

	@Lob
	@Column(name="RESPONSE_CONTENT")
	private byte[] responseContent;

	@Column(name="SARIE_COUNT")
	private BigDecimal sarieCount;

	private String status;

	@Column(name="SWIFT_CONT")
	private BigDecimal swiftCont;

	@Column(name="TOTAL_COUNT")
	private BigDecimal totalCount;

	@Column(name="VALIDATED_TIME")
	private Timestamp validatedTime;

	@Temporal(TemporalType.DATE)
	@Column(name="VALUE_DATE")
	private Date valueDate;
	
	@Column(name="PROCESSING_STATUS")
	private Integer processingStatus;
	
	@Column(name="TOTAL_AMOUNT")
	private BigDecimal totalAmount;
	
	@Column(name="MESSAGE_TYPE")
	private String messageType;
	
	@Column(name="CUST_REQ_FILE")
	private String custReqFile;
	
	@Version
	@Column(name = "VERSION")
	private Integer version;

	@Column(name="RES_STATUS")
	private String responseStatus;
	
	@Column(name = "RESPONSE_FILE_VALUE")
	private String responseFileValue;
	
	public MacPayrollHeader() {
	}

	public BigDecimal getAcacCount() {
		return this.acacCount;
	}

	public void setAcacCount(BigDecimal acacCount) {
		this.acacCount = acacCount;
	}

	public BigDecimal getAlertCount() {
		return this.alertCount;
	}

	public void setAlertCount(BigDecimal alertCount) {
		this.alertCount = alertCount;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFileName() {
		return this.fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Timestamp getLoadTime() {
		return this.loadTime;
	}

	public void setLoadTime(Timestamp loadTime) {
		this.loadTime = loadTime;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getOrdCustAcc() {
		return this.ordCustAcc;
	}

	public void setOrdCustAcc(String ordCustAcc) {
		this.ordCustAcc = ordCustAcc;
	}

	public String getOrdCustDet1() {
		return this.ordCustDet1;
	}

	public void setOrdCustDet1(String ordCustDet1) {
		this.ordCustDet1 = ordCustDet1;
	}

	public String getOrdCustDet2() {
		return this.ordCustDet2;
	}

	public void setOrdCustDet2(String ordCustDet2) {
		this.ordCustDet2 = ordCustDet2;
	}

	public String getOrdCustDet3() {
		return this.ordCustDet3;
	}

	public void setOrdCustDet3(String ordCustDet3) {
		this.ordCustDet3 = ordCustDet3;
	}

	public String getOrdCustDet4() {
		return this.ordCustDet4;
	}

	public void setOrdCustDet4(String ordCustDet4) {
		this.ordCustDet4 = ordCustDet4;
	}

	public BigDecimal getProcessedCount() {
		return this.processedCount;
	}

	public void setProcessedCount(BigDecimal processedCount) {
		this.processedCount = processedCount;
	}

	public BigDecimal getReceivedAmount() {
		return this.receivedAmount;
	}

	public void setReceivedAmount(BigDecimal receivedAmount) {
		this.receivedAmount = receivedAmount;
	}

	public BigDecimal getReceivedCount() {
		return this.receivedCount;
	}

	public void setReceivedCount(BigDecimal receivedCount) {
		this.receivedCount = receivedCount;
	}

	public BigDecimal getRejectedCount() {
		return this.rejectedCount;
	}

	public void setRejectedCount(BigDecimal rejectedCount) {
		this.rejectedCount = rejectedCount;
	}

	public byte[] getRequestContent() {
		return this.requestContent;
	}

	public void setRequestContent(byte[] requestContent) {
		this.requestContent = requestContent;
	}

	public byte[] getResponseContent() {
		return this.responseContent;
	}

	public void setResponseContent(byte[] responseContent) {
		this.responseContent = responseContent;
	}

	public BigDecimal getSarieCount() {
		return this.sarieCount;
	}

	public void setSarieCount(BigDecimal sarieCount) {
		this.sarieCount = sarieCount;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public BigDecimal getSwiftCont() {
		return this.swiftCont;
	}

	public void setSwiftCont(BigDecimal swiftCont) {
		this.swiftCont = swiftCont;
	}

	public BigDecimal getTotalCount() {
		return this.totalCount;
	}

	public void setTotalCount(BigDecimal totalCount) {
		this.totalCount = totalCount;
	}

	public Timestamp getValidatedTime() {
		return this.validatedTime;
	}

	public void setValidatedTime(Timestamp validatedTime) {
		this.validatedTime = validatedTime;
	}

	public Date getValueDate() {
		return this.valueDate;
	}

	public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public Integer getProcessingStatus() {
		return processingStatus;
	}

	public void setProcessingStatus(Integer processingStatus) {
		this.processingStatus = processingStatus;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	
	public String getCustReqFile() {
		return custReqFile;
	}

	public void setCustReqFile(String custReqFile) {
		this.custReqFile = custReqFile;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	public String getResponseFileValue() {
		return responseFileValue;
	}

	public void setResponseFileValue(String responseFileValue) {
		this.responseFileValue = responseFileValue;
	}
		
}