package com.bsf.macug.payroll.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MAC_PAYROLL_PROCESSLOG")
public class MacPayrollActivityLog implements Serializable {

	@Id
	@Column(name = "PROCESS_LOGID")
	private String processActivityID;
	@Column(name = "PROCESS_LOGGEDON")
	private Date processCreatedOn;
	@Column(name = "PROCESS_ACTIVITY")
	private String processSubject;
	@Column(name = "PROCESS_DESCRIPTION")
	private String processDescription;
	@Column(name = "PROCESS_TYPE")
	private String processType;
	@Column(name = "PROCESS_FILENAME")
	private String processFileName;
		
	@Column(name = "CUST_REQ_FILE")
	private String custReqFile;
	  
	@Column(name = "RESPONSE_FILE_VALUE")  
	private String responseFileValue;
	  @Column(name = "PROCESSING_STATUS")
	private Integer processStatus;
	  @Column(name = "RES_STATUS")
	private String resStatus;
	 
	@Column(name = "CUSTOMER_ID")
	private String customerId;
	
	@Column(name = "FILE_REFERENCE")
	private String fileReference;
	

	public MacPayrollActivityLog() {
	}

	public MacPayrollActivityLog(String customerId,String processActivityID, Date processCreatedOn, String processSubject,
			String processDescription, String processType, String processFileName,String fileReference) {
		super();
		this.customerId=customerId;
		this.fileReference=fileReference;
		this.processActivityID = processActivityID;
		this.processCreatedOn = processCreatedOn;
		this.processSubject = processSubject;
		this.processDescription = processDescription;
		this.processType = processType;
		this.processFileName = processFileName;
	}

	public String getProcessActivityID() {
		return processActivityID;
	}

	public void setProcessActivityID(String processActivityID) {
		this.processActivityID = processActivityID;
	}

	public Date getProcessCreatedOn() {
		return processCreatedOn;
	}

	public void setProcessCreatedOn(Date processCreatedOn) {
		this.processCreatedOn = processCreatedOn;
	}

	public String getProcessSubject() {
		return processSubject;
	}

	public void setProcessSubject(String processSubject) {
		this.processSubject = processSubject;
	}

	public String getProcessDescription() {
		return processDescription;
	}

	public void setProcessDescription(String processDescription) {
		this.processDescription = processDescription;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getProcessFileName() {
		return processFileName;
	}

	public void setProcessFileName(String processFileName) {
		this.processFileName = processFileName;
	}

	public String getCustReqFile() {
		return custReqFile;
	}

	public void setCustReqFile(String custReqFile) {
		this.custReqFile = custReqFile;
	}

	public String getResponseFileValue() {
		return responseFileValue;
	}

	public void setResponseFileValue(String responseFileValue) {
		this.responseFileValue = responseFileValue;
	}

	public Integer getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(Integer processStatus) {
		this.processStatus = processStatus;
	}

	public String getResStatus() {
		return resStatus;
	}

	public void setResStatus(String resStatus) {
		this.resStatus = resStatus;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getFileReference() {
		return fileReference;
	}

	public void setFileReference(String fileReference) {
		this.fileReference = fileReference;
	}
	
	
	
	
	

}
