package com.bsf.macug.payroll.dto;

public class PayrollHeaderTransferDTO {
	private String clientId;
	private String molId;
	private String fileId;
	private String messageType;
	private String timeStamp;
	private String orderingCustomerAccount;
	private String messageDescription;
	private Integer transactionCount;
	private String totalAmount;
	private String status;
	private String message;
	private String wpsFlag;
	private String requestFileName;
	private String payrollId;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getMolId() {
		return molId;
	}
	public void setMolId(String molId) {
		this.molId = molId;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getOrderingCustomerAccount() {
		return orderingCustomerAccount;
	}
	public void setOrderingCustomerAccount(String orderingCustomerAccount) {
		this.orderingCustomerAccount = orderingCustomerAccount;
	}
	public String getMessageDescription() {
		return messageDescription;
	}
	public void setMessageDescription(String messageDescription) {
		this.messageDescription = messageDescription;
	}
	public Integer getTransactionCount() {
		return transactionCount;
	}
	public void setTransactionCount(Integer transactionCount) {
		this.transactionCount = transactionCount;
	}
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getWpsFlag() {
		return wpsFlag;
	}
	public void setWpsFlag(String wpsFlag) {
		this.wpsFlag = wpsFlag;
	}
	
	public String getRequestFileName() {
		return requestFileName;
	}
	public void setRequestFileName(String requestFileName) {
		this.requestFileName = requestFileName;
	}
	public String getPayrollId() {
		return payrollId;
	}
	public void setPayrollId(String payrollId) {
		this.payrollId = payrollId;
	}
	@Override
	public String toString() {
		return "PayrollHeaderTransferDTO [clientId=" + clientId + ", molId="
				+ molId + ", fileId=" + fileId + ", messageType=" + messageType
				+ ", timeStamp=" + timeStamp + ", orderingCustomerAccount="
				+ orderingCustomerAccount + ", messageDescription="
				+ messageDescription + ", transactionCount=" + transactionCount
				+ ", totalAmount=" + totalAmount + ", status=" + status
				+ ", message=" + message + ", wpsFlag=" + wpsFlag
				+ ", requestFileName=" + requestFileName + ", payrollId="
				+ payrollId + "]";
	}
	
}
