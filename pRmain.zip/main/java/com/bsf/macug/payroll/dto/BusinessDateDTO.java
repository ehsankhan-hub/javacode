package com.bsf.macug.payroll.dto;

import java.io.Serializable;
import java.util.Date;

public class BusinessDateDTO implements Serializable {

	private String statusCode;
	private String description;
	private Date businessDate;
	private Date systemDate;
	private String time;

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getBusinessDate() {
		return businessDate;
	}

	public void setBusinessDate(Date businessDate) {
		this.businessDate = businessDate;
	}

	public Date getSystemDate() {
		return systemDate;
	}

	public void setSystemDate(Date systemDate) {
		this.systemDate = systemDate;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "{\"statusCode\":\"" + statusCode + "\", \"description\":\""
				+ description + "\", \"businessDate\":\"" + businessDate
				+ "\", \"systemDate\":\"" + systemDate + "\", \"time\":\"" + time + "\"}";
	}

}
