package com.bsf.macug.payroll.dto;

public class PayrollBodyTransferDTO {
	private String transactionId;
	private String currencyCode;
	private String totalAmount;
	private String benBankCode;
	private String benAccountNumber;
	private String benBankDet1;
	private String benBankDet2;
	private String benBankDet3;
	private String benBankDet4;
	private String paymentDescription;
	private String basicSalary;
	private String housingAllowance;
	private String otherEarnings;
	private String deduction;
	private String employeeId;
	
	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	
	
	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getBenBankCode() {
		return benBankCode;
	}

	public void setBenBankCode(String benBankCode) {
		this.benBankCode = benBankCode;
	}

	public String getBenAccountNumber() {
		return benAccountNumber;
	}

	public void setBenAccountNumber(String benAccountNumber) {
		this.benAccountNumber = benAccountNumber;
	}

	public String getBenBankDet1() {
		return benBankDet1;
	}

	public void setBenBankDet1(String benBankDet1) {
		this.benBankDet1 = benBankDet1;
	}

	public String getBenBankDet2() {
		return benBankDet2;
	}

	public void setBenBankDet2(String benBankDet2) {
		this.benBankDet2 = benBankDet2;
	}

	public String getBenBankDet3() {
		return benBankDet3;
	}

	public void setBenBankDet3(String benBankDet3) {
		this.benBankDet3 = benBankDet3;
	}

	public String getBenBankDet4() {
		return benBankDet4;
	}

	public void setBenBankDet4(String benBankDet4) {
		this.benBankDet4 = benBankDet4;
	}

	public String getPaymentDescription() {
		return paymentDescription;
	}

	public void setPaymentDescription(String paymentDescription) {
		this.paymentDescription = paymentDescription;
	}

	public String getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(String basicSalary) {
		this.basicSalary = basicSalary;
	}

	public String getHousingAllowance() {
		return housingAllowance;
	}

	public void setHousingAllowance(String housingAllowance) {
		this.housingAllowance = housingAllowance;
	}

	public String getOtherEarnings() {
		return otherEarnings;
	}

	public void setOtherEarnings(String otherEarnings) {
		this.otherEarnings = otherEarnings;
	}

	public String getDeduction() {
		return deduction;
	}

	public void setDeduction(String deduction) {
		this.deduction = deduction;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	@Override
	public String toString() {
		return "PayrollBodyTransferDTO [transactionId=" + transactionId
				+ ", currencyCode=" + currencyCode + ", totalAmount="
				+ totalAmount + ", benBankCode=" + benBankCode
				+ ", benAccountNumber=" + benAccountNumber + ", benBankDet1="
				+ benBankDet1 + ", benBankDet2=" + benBankDet2
				+ ", benBankDet3=" + benBankDet3 + ", benBankDet4="
				+ benBankDet4 + ", paymentDescription=" + paymentDescription
				+ ", basicSalary=" + basicSalary + ", housingAllowance="
				+ housingAllowance + ", otherEarnings=" + otherEarnings
				+ ", deduction=" + deduction + ", employeeId=" + employeeId
				+ "]";
	}
}
