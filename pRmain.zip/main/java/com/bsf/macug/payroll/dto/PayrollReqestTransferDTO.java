package com.bsf.macug.payroll.dto;

import java.util.List;

public class PayrollReqestTransferDTO {
	PayrollHeaderTransferDTO headerObj;
	List<PayrollBodyTransferDTO> bodyList;
	public PayrollHeaderTransferDTO getHeaderObj() {
		return headerObj;
	}
	public void setHeaderObj(PayrollHeaderTransferDTO headerObj) {
		this.headerObj = headerObj;
	}
	public List<PayrollBodyTransferDTO> getBodyList() {
		return bodyList;
	}
	public void setBodyList(List<PayrollBodyTransferDTO> bodyList) {
		this.bodyList = bodyList;
	}
	@Override
	public String toString() {
		return "PayrollReqestDTO [headerObj=" + headerObj + ", bodyList="
				+ bodyList + "]";
	}
	
	
}
