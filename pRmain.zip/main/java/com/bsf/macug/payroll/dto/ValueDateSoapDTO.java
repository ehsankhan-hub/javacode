package com.bsf.macug.payroll.dto;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.util.StringUtils;

public class ValueDateSoapDTO {
	private String msgType;
	private String currency;
	private String countryCode;
	private String requestValueDate;
	private String applicableValueDate;
	private String expressFlag;
	private String expressValueDate;
	private String correspondentCharges;
	private String expressCharges;

	public String getMsgType() {
		return msgType;
	}

	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getRequestValueDate() {
		return requestValueDate;
	}

	public void setRequestValueDate(String requestValueDate) {
		this.requestValueDate = requestValueDate;
	}

	public String getApplicableValueDate() {
		return applicableValueDate;
	}

	public void setApplicableValueDate(String applicableValueDate) {
		this.applicableValueDate = applicableValueDate;
	}

	public String getExpressFlag() {
		return expressFlag;
	}

	public void setExpressFlag(String expressFlag) {
		this.expressFlag = expressFlag;
	}

	public String getExpressValueDate() {
		return expressValueDate;
	}

	public void setExpressValueDate(String expressValueDate) {
		this.expressValueDate = expressValueDate;
	}

	public String getCorrespondentCharges() {
		return correspondentCharges;
	}

	public void setCorrespondentCharges(String correspondentCharges) {
		this.correspondentCharges = correspondentCharges;
	}

	public String getExpressCharges() {
		return expressCharges;
	}

	public void setExpressCharges(String expressCharges) {
		this.expressCharges = expressCharges;
	}

	public Date getCalulatedExpressValueDate(){
		SimpleDateFormat dfFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		try {
			if(StringUtils.isEmpty(expressFlag)){
				return null;
			}
			if(expressFlag.equalsIgnoreCase("true")){
				if(!StringUtils.isEmpty(expressValueDate)){
					return dfFormat.parse(expressValueDate);
				}
			}
			if(expressFlag.equalsIgnoreCase("false")){
				if(!StringUtils.isEmpty(applicableValueDate)){
					return dfFormat.parse(applicableValueDate);
				}
			}
		} catch (Exception e) {
			return null;
		}
		return null;
	}

	@Override
	public String toString() {
		return "{\"msgType\":\"" + msgType + "\", \"currency\":\""
				+ currency + "\", \"countryCode\":\"" + countryCode
				+ "\", \"requestValueDate\":\"" + requestValueDate
				+ "\", \"applicableValueDate\":\"" + applicableValueDate
				+ "\", \"expressFlag\":\"" + expressFlag + "\", \"expressValueDate\":\""
				+ expressValueDate + "\", \"correspondentCharges\":\""
				+ correspondentCharges + "\", \"expressCharges\":\"" + expressCharges
				+ "\"}";
	}
	
	
}
