package com.bsf.macug.payroll.dto;

public class FxDealResponseDTO {
	private String replyStatus;
	private String profitCenter;
	private String currencySell;
	private String currencyBuy;
	private String exchangeRate;
	private String amountSell;
	private String amountBuy;
	private String tradeDate;
	private String soldDate;
	private String purchasedDate;
	private String status;
	private String transactionRef;
	private String transactionType;
	private String lastStatusModifiedDate;
	
	
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getReplyStatus() {
		return replyStatus;
	}
	public void setReplyStatus(String replyStatus) {
		this.replyStatus = replyStatus;
	}
	public String getProfitCenter() {
		return profitCenter;
	}
	public void setProfitCenter(String profitCenter) {
		this.profitCenter = profitCenter;
	}
	public String getCurrencySell() {
		return currencySell;
	}
	public void setCurrencySell(String currencySell) {
		this.currencySell = currencySell;
	}
	public String getCurrencyBuy() {
		return currencyBuy;
	}
	public void setCurrencyBuy(String currencyBuy) {
		this.currencyBuy = currencyBuy;
	}
	public String getExchangeRate() {
		return exchangeRate;
	}
	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}
	public String getAmountSell() {
		return amountSell;
	}
	public void setAmountSell(String amountSell) {
		this.amountSell = amountSell;
	}
	public String getAmountBuy() {
		return amountBuy;
	}
	public void setAmountBuy(String amountBuy) {
		this.amountBuy = amountBuy;
	}
	public String getTradeDate() {
		return tradeDate;
	}
	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}
	public String getSoldDate() {
		return soldDate;
	}
	public void setSoldDate(String soldDate) {
		this.soldDate = soldDate;
	}
	public String getPurchasedDate() {
		return purchasedDate;
	}
	public void setPurchasedDate(String purchasedDate) {
		this.purchasedDate = purchasedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTransactionRef() {
		return transactionRef;
	}
	public void setTransactionRef(String transactionRef) {
		this.transactionRef = transactionRef;
	}
	public String getLastStatusModifiedDate() {
		return lastStatusModifiedDate;
	}
	public void setLastStatusModifiedDate(String lastStatusModifiedDate) {
		this.lastStatusModifiedDate = lastStatusModifiedDate;
	}
	
	
}
