package com.bsf.macug.payroll.dto;

public class SarieSwiftTRansferRequestDTO {

	@Override
	public String toString() {
		return "TelexTransferRequest [srcSystem=" + srcSystem
				+ ", reqFunction=" + reqFunction + ", serverDate=" + serverDate
				+ ", serverTime=" + serverTime + ", ftsReference="
				+ ftsReference + ", ftsTransFunc=" + ftsTransFunc
				+ ", cammTranNum=" + cammTranNum + ", numOfBlocks="
				+ numOfBlocks + ", currBlockNum=" + currBlockNum
				+ ", numOfItems=" + numOfItems + ", customerCode="
				+ customerCode + ", accountNumber=" + accountNumber
				+ ", initBranch=" + initBranch + ", initOfficer=" + initOfficer
				+ ", cardNumber=" + cardNumber + ", cammActionCode="
				+ cammActionCode + ", lastUpdateDate=" + lastUpdateDate
				+ ", lastUpdateTime=" + lastUpdateTime + ", transactionStatus="
				+ transactionStatus + ", ftsActionCode=" + ftsActionCode
				+ ", processingSeq=" + processingSeq + ", detailLength="
				+ detailLength + ", transactionType=" + transactionType
				+ ", transactionDate=" + transactionDate + ", valueDate="
				+ valueDate + ", transactionCurrency=" + transactionCurrency
				+ ", transactionAmount=" + transactionAmount
				+ ", transactionAmountSAR=" + transactionAmountSAR
				+ ", generalNarrative=" + generalNarrative
				+ ", screenNarrative=" + screenNarrative + ", dbAccountNumber="
				+ dbAccountNumber + ", dbAccountCurrency=" + dbAccountCurrency
				+ ", dbAmount=" + dbAmount + ", dbCurrencyRate="
				+ dbCurrencyRate + ", dbValueDate=" + dbValueDate
				+ ", dbSrfFlag=" + dbSrfFlag + ", dbBranch=" + dbBranch
				+ ", crAccountNumber=" + crAccountNumber
				+ ", crAccountCurrency=" + crAccountCurrency + ", crAmount="
				+ crAmount + ", crCurrencyRate=" + crCurrencyRate
				+ ", crValueDate=" + crValueDate + ", crSrfFlag=" + crSrfFlag
				+ ", crBranch=" + crBranch + ", commissionCurrency="
				+ commissionCurrency + ", commissionAmount=" + commissionAmount
				+ ", commissionAccount=" + commissionAccount
				+ ", chargesCurrency=" + chargesCurrency + ", chargesAmount="
				+ chargesAmount + ", chargesAccount=" + chargesAccount
				+ ", gtdDealTicket=" + gtdDealTicket + ", initTime=" + initTime
				+ ", validationOfficer=" + validationOfficer
				+ ", validationTime=" + validationTime
				+ ", authorizationOfficer=" + authorizationOfficer
				+ ", authorizationTime=" + authorizationTime
				+ ", authorizationReason=" + authorizationReason
				+ ", authorizationStatus=" + authorizationStatus
				+ ", dynamicPartLength=" + dynamicPartLength
				+ ", staticPartChequeNumber=" + staticPartChequeNumber
				+ ", staticPartIdType=" + staticPartIdType
				+ ", staticPartIdNumber=" + staticPartIdNumber
				+ ", staticPartPrintDetail=" + staticPartPrintDetail
				+ ", staticPartMailAdvice=" + staticPartMailAdvice
				+ ", ttRefNumber=" + ttRefNumber + ", ttCorrespondant="
				+ ttCorrespondant + ", chargesDetails=" + chargesDetails
				+ ", paymentValueDate=" + paymentValueDate + ", remitterName="
				+ remitterName + ", remitterNationality=" + remitterNationality
				+ ", remitterPhoneNumber=" + remitterPhoneNumber
				+ ", remitterAddress=" + remitterAddress
				+ ", remittencePurpose=" + remittencePurpose + ", benName="
				+ benName + ", benCountry=" + benCountry + ", benAddress="
				+ benAddress + ", benAccount=" + benAccount + ", benBankName="
				+ benBankName + ", paymentDetails=" + paymentDetails
				+ ", paymentMsgType=" + paymentMsgType
				+ ", chargesCollectionMethod=" + chargesCollectionMethod
				+ ", benBankAddressLine1=" + benBankAddressLine1
				+ ", benBankAddressLine2=" + benBankAddressLine2
				+ ", benBankCode=" + benBankCode + ", benBankCountry="
				+ benBankCountry + ", remitterFullAddress="
				+ remitterFullAddress + ", isIbanFlag=" + isIbanFlag
				+ ", iBanBbanAccount=" + iBanBbanAccount + ", benBankFullName="
				+ benBankFullName + "]";
	}

	private String srcSystem;
	private String reqFunction;
	private String serverDate;
	private String serverTime;
	private String ftsReference;
	private String ftsTransFunc;
	private String cammTranNum;
	private String numOfBlocks;
	private String currBlockNum;
	private String numOfItems;
	private String customerCode;
	private String accountNumber;
	private String initBranch;
	private String initOfficer;
	private String cardNumber;
	// private String functionCode; TODO: Check
	private String cammActionCode;
	private String lastUpdateDate;
	private String lastUpdateTime;
	private String transactionStatus;
	private String ftsActionCode;
	private String processingSeq;
	private String detailLength;

	private String transactionType;
	private String transactionDate;
	private String valueDate;
	private String transactionCurrency;
	private String transactionAmount;
	private String transactionAmountSAR;
	private String generalNarrative;
	private String screenNarrative;
	private String dbAccountNumber;
	private String dbAccountCurrency;
	private String dbAmount;
	private String dbCurrencyRate;
	private String dbValueDate;
	private String dbSrfFlag;
	private String dbBranch;
	private String crAccountNumber;
	private String crAccountCurrency;
	private String crAmount;
	private String crCurrencyRate;
	private String crValueDate;
	private String crSrfFlag;
	private String crBranch;
	private String commissionCurrency;
	private String commissionAmount;
	private String commissionAccount;
	private String chargesCurrency;
	private String chargesAmount;
	private String chargesAccount;
	private String gtdDealTicket;
	private String initTime;
	private String validationOfficer;
	private String validationTime;
	private String authorizationOfficer;
	private String authorizationTime;
	private String authorizationReason;
	private String authorizationStatus;
	private String dynamicPartLength;
	private String staticPartChequeNumber;
	private String staticPartIdType;
	private String staticPartIdNumber;
	private String staticPartPrintDetail;
	private String staticPartMailAdvice;

	private String ttRefNumber;
	private String ttCorrespondant;
	private String chargesDetails;
	private String paymentValueDate;
	private String remitterName;
	private String remitterNationality;
	private String remitterPhoneNumber;
	private String remitterAddress;
	private String remittencePurpose;
	private String benName;
	private String benCountry;
	private String benAddress;
	private String benAccount;
	private String benBankName;
	private String paymentDetails;
	private String paymentMsgType;
	private String chargesCollectionMethod;
	private String benBankAddressLine1;
	private String benBankAddressLine2;
	private String benBankCode;
	private String benBankCountry;
	private String remitterFullAddress;
	private String isIbanFlag;
	private String iBanBbanAccount;
	private String benBankFullName;

	public String getBenBankCode() {
		return benBankCode;
	}

	public void setBenBankCode(String benBankCode) {
		this.benBankCode = benBankCode;
	}

	public String getSrcSystem() {
		return srcSystem;
	}

	public void setSrcSystem(String srcSystem) {
		this.srcSystem = srcSystem;
	}

	public String getReqFunction() {
		return reqFunction;
	}

	public void setReqFunction(String reqFunction) {
		this.reqFunction = reqFunction;
	}

	public String getServerDate() {
		return serverDate;
	}

	public void setServerDate(String serverDate) {
		this.serverDate = serverDate;
	}

	public String getServerTime() {
		return serverTime;
	}

	public void setServerTime(String serverTime) {
		this.serverTime = serverTime;
	}

	public String getFtsReference() {
		return ftsReference;
	}

	public void setFtsReference(String ftsReference) {
		this.ftsReference = ftsReference;
	}

	public String getFtsTransFunc() {
		return ftsTransFunc;
	}

	public void setFtsTransFunc(String ftsTransFunc) {
		this.ftsTransFunc = ftsTransFunc;
	}

	public String getCammTranNum() {
		return cammTranNum;
	}

	public void setCammTranNum(String cammTranNum) {
		this.cammTranNum = cammTranNum;
	}

	public String getNumOfBlocks() {
		return numOfBlocks;
	}

	public void setNumOfBlocks(String numOfBlocks) {
		this.numOfBlocks = numOfBlocks;
	}

	public String getCurrBlockNum() {
		return currBlockNum;
	}

	public void setCurrBlockNum(String currBlockNum) {
		this.currBlockNum = currBlockNum;
	}

	public String getNumOfItems() {
		return numOfItems;
	}

	public void setNumOfItems(String numOfItems) {
		this.numOfItems = numOfItems;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getInitBranch() {
		return initBranch;
	}

	public void setInitBranch(String initBranch) {
		this.initBranch = initBranch;
	}

	public String getInitOfficer() {
		return initOfficer;
	}

	public void setInitOfficer(String initOfficer) {
		this.initOfficer = initOfficer;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCammActionCode() {
		return cammActionCode;
	}

	public void setCammActionCode(String cammActionCode) {
		this.cammActionCode = cammActionCode;
	}

	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getLastUpdateTime() {
		return lastUpdateTime;
	}

	public void setLastUpdateTime(String lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public String getFtsActionCode() {
		return ftsActionCode;
	}

	public void setFtsActionCode(String ftsActionCode) {
		this.ftsActionCode = ftsActionCode;
	}

	public String getProcessingSeq() {
		return processingSeq;
	}

	public void setProcessingSeq(String processingSeq) {
		this.processingSeq = processingSeq;
	}

	public String getDetailLength() {
		return detailLength;
	}

	public void setDetailLength(String detailLength) {
		this.detailLength = detailLength;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getValueDate() {
		return valueDate;
	}

	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}

	public String getTransactionCurrency() {
		return transactionCurrency;
	}

	public void setTransactionCurrency(String transactionCurrency) {
		this.transactionCurrency = transactionCurrency;
	}

	public String getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getTransactionAmountSAR() {
		return transactionAmountSAR;
	}

	public void setTransactionAmountSAR(String transactionAmountSAR) {
		this.transactionAmountSAR = transactionAmountSAR;
	}

	public String getGeneralNarrative() {
		return generalNarrative;
	}

	public void setGeneralNarrative(String generalNarrative) {
		this.generalNarrative = generalNarrative;
	}

	public String getScreenNarrative() {
		return screenNarrative;
	}

	public void setScreenNarrative(String screenNarrative) {
		this.screenNarrative = screenNarrative;
	}

	public String getDbAccountNumber() {
		return dbAccountNumber;
	}

	public void setDbAccountNumber(String dbAccountNumber) {
		this.dbAccountNumber = dbAccountNumber;
	}

	public String getDbAccountCurrency() {
		return dbAccountCurrency;
	}

	public void setDbAccountCurrency(String dbAccountCurrency) {
		this.dbAccountCurrency = dbAccountCurrency;
	}

	public String getDbAmount() {
		return dbAmount;
	}

	public void setDbAmount(String dbAmount) {
		this.dbAmount = dbAmount;
	}

	public String getDbCurrencyRate() {
		return dbCurrencyRate;
	}

	public void setDbCurrencyRate(String dbCurrencyRate) {
		this.dbCurrencyRate = dbCurrencyRate;
	}

	public String getDbValueDate() {
		return dbValueDate;
	}

	public void setDbValueDate(String dbValueDate) {
		this.dbValueDate = dbValueDate;
	}

	public String getDbSrfFlag() {
		return dbSrfFlag;
	}

	public void setDbSrfFlag(String dbSrfFlag) {
		this.dbSrfFlag = dbSrfFlag;
	}

	public String getDbBranch() {
		return dbBranch;
	}

	public void setDbBranch(String dbBranch) {
		this.dbBranch = dbBranch;
	}

	public String getCrAccountNumber() {
		return crAccountNumber;
	}

	public void setCrAccountNumber(String crAccountNumber) {
		this.crAccountNumber = crAccountNumber;
	}

	public String getCrAccountCurrency() {
		return crAccountCurrency;
	}

	public void setCrAccountCurrency(String crAccountCurrency) {
		this.crAccountCurrency = crAccountCurrency;
	}

	public String getCrAmount() {
		return crAmount;
	}

	public void setCrAmount(String crAmount) {
		this.crAmount = crAmount;
	}

	public String getCrCurrencyRate() {
		return crCurrencyRate;
	}

	public void setCrCurrencyRate(String crCurrencyRate) {
		this.crCurrencyRate = crCurrencyRate;
	}

	public String getCrValueDate() {
		return crValueDate;
	}

	public void setCrValueDate(String crValueDate) {
		this.crValueDate = crValueDate;
	}

	public String getCrSrfFlag() {
		return crSrfFlag;
	}

	public void setCrSrfFlag(String crSrfFlag) {
		this.crSrfFlag = crSrfFlag;
	}

	public String getCrBranch() {
		return crBranch;
	}

	public void setCrBranch(String crBranch) {
		this.crBranch = crBranch;
	}

	public String getCommissionCurrency() {
		return commissionCurrency;
	}

	public void setCommissionCurrency(String commissionCurrency) {
		this.commissionCurrency = commissionCurrency;
	}

	public String getCommissionAmount() {
		return commissionAmount;
	}

	public void setCommissionAmount(String commissionAmount) {
		this.commissionAmount = commissionAmount;
	}

	public String getCommissionAccount() {
		return commissionAccount;
	}

	public void setCommissionAccount(String commissionAccount) {
		this.commissionAccount = commissionAccount;
	}

	public String getChargesCurrency() {
		return chargesCurrency;
	}

	public void setChargesCurrency(String chargesCurrency) {
		this.chargesCurrency = chargesCurrency;
	}

	public String getChargesAmount() {
		return chargesAmount;
	}

	public void setChargesAmount(String chargesAmount) {
		this.chargesAmount = chargesAmount;
	}

	public String getChargesAccount() {
		return chargesAccount;
	}

	public void setChargesAccount(String chargesAccount) {
		this.chargesAccount = chargesAccount;
	}

	public String getGtdDealTicket() {
		return gtdDealTicket;
	}

	public void setGtdDealTicket(String gtdDealTicket) {
		this.gtdDealTicket = gtdDealTicket;
	}

	public String getInitTime() {
		return initTime;
	}

	public void setInitTime(String initTime) {
		this.initTime = initTime;
	}

	public String getValidationOfficer() {
		return validationOfficer;
	}

	public void setValidationOfficer(String validationOfficer) {
		this.validationOfficer = validationOfficer;
	}

	public String getValidationTime() {
		return validationTime;
	}

	public void setValidationTime(String validationTime) {
		this.validationTime = validationTime;
	}

	public String getAuthorizationOfficer() {
		return authorizationOfficer;
	}

	public void setAuthorizationOfficer(String authorizationOfficer) {
		this.authorizationOfficer = authorizationOfficer;
	}

	public String getAuthorizationTime() {
		return authorizationTime;
	}

	public void setAuthorizationTime(String authorizationTime) {
		this.authorizationTime = authorizationTime;
	}

	public String getAuthorizationReason() {
		return authorizationReason;
	}

	public void setAuthorizationReason(String authorizationReason) {
		this.authorizationReason = authorizationReason;
	}

	public String getAuthorizationStatus() {
		return authorizationStatus;
	}

	public void setAuthorizationStatus(String authorizationStatus) {
		this.authorizationStatus = authorizationStatus;
	}

	public String getDynamicPartLength() {
		return dynamicPartLength;
	}

	public void setDynamicPartLength(String dynamicPartLength) {
		this.dynamicPartLength = dynamicPartLength;
	}

	public String getStaticPartChequeNumber() {
		return staticPartChequeNumber;
	}

	public void setStaticPartChequeNumber(String staticPartChequeNumber) {
		this.staticPartChequeNumber = staticPartChequeNumber;
	}

	public String getStaticPartIdType() {
		return staticPartIdType;
	}

	public void setStaticPartIdType(String staticPartIdType) {
		this.staticPartIdType = staticPartIdType;
	}

	public String getStaticPartIdNumber() {
		return staticPartIdNumber;
	}

	public void setStaticPartIdNumber(String staticPartIdNumber) {
		this.staticPartIdNumber = staticPartIdNumber;
	}

	public String getStaticPartPrintDetail() {
		return staticPartPrintDetail;
	}

	public void setStaticPartPrintDetail(String staticPartPrintDetail) {
		this.staticPartPrintDetail = staticPartPrintDetail;
	}

	public String getStaticPartMailAdvice() {
		return staticPartMailAdvice;
	}

	public void setStaticPartMailAdvice(String staticPartMailAdvice) {
		this.staticPartMailAdvice = staticPartMailAdvice;
	}

	public String getTtRefNumber() {
		return ttRefNumber;
	}

	public void setTtRefNumber(String ttRefNumber) {
		this.ttRefNumber = ttRefNumber;
	}

	public String getTtCorrespondant() {
		return ttCorrespondant;
	}

	public void setTtCorrespondant(String ttCorrespondant) {
		this.ttCorrespondant = ttCorrespondant;
	}

	public String getChargesDetails() {
		return chargesDetails;
	}

	public void setChargesDetails(String chargesDetails) {
		this.chargesDetails = chargesDetails;
	}

	public String getPaymentValueDate() {
		return paymentValueDate;
	}

	public void setPaymentValueDate(String paymentValueDate) {
		this.paymentValueDate = paymentValueDate;
	}

	public String getRemitterName() {
		return remitterName;
	}

	public void setRemitterName(String remitterName) {
		this.remitterName = remitterName;
	}

	public String getRemitterNationality() {
		return remitterNationality;
	}

	public void setRemitterNationality(String remitterNationality) {
		this.remitterNationality = remitterNationality;
	}

	public String getRemitterPhoneNumber() {
		return remitterPhoneNumber;
	}

	public void setRemitterPhoneNumber(String remitterPhoneNumber) {
		this.remitterPhoneNumber = remitterPhoneNumber;
	}

	public String getRemitterAddress() {
		return remitterAddress;
	}

	public void setRemitterAddress(String remitterAddress) {
		this.remitterAddress = remitterAddress;
	}

	public String getRemittencePurpose() {
		return remittencePurpose;
	}

	public void setRemittencePurpose(String remittencePurpose) {
		this.remittencePurpose = remittencePurpose;
	}

	public String getBenName() {
		return benName;
	}

	public void setBenName(String benName) {
		this.benName = benName;
	}

	public String getBenCountry() {
		return benCountry;
	}

	public void setBenCountry(String benCountry) {
		this.benCountry = benCountry;
	}

	public String getBenAddress() {
		return benAddress;
	}

	public void setBenAddress(String benAddress) {
		this.benAddress = benAddress;
	}

	public String getBenAccount() {
		return benAccount;
	}

	public void setBenAccount(String benAccount) {
		this.benAccount = benAccount;
	}

	public String getBenBankName() {
		return benBankName;
	}

	public void setBenBankName(String benBankName) {
		this.benBankName = benBankName;
	}

	public String getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentDetails(String paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	public String getPaymentMsgType() {
		return paymentMsgType;
	}

	public void setPaymentMsgType(String paymentMsgType) {
		this.paymentMsgType = paymentMsgType;
	}

	public String getChargesCollectionMethod() {
		return chargesCollectionMethod;
	}

	public void setChargesCollectionMethod(String chargesCollectionMethod) {
		this.chargesCollectionMethod = chargesCollectionMethod;
	}

	public String getBenBankAddressLine1() {
		return benBankAddressLine1;
	}

	public void setBenBankAddressLine1(String benBankAddressLine1) {
		this.benBankAddressLine1 = benBankAddressLine1;
	}

	public String getBenBankAddressLine2() {
		return benBankAddressLine2;
	}

	public void setBenBankAddressLine2(String benBankAddressLine2) {
		this.benBankAddressLine2 = benBankAddressLine2;
	}

	public String getBenBankCountry() {
		return benBankCountry;
	}

	public void setBenBankCountry(String benBankCountry) {
		this.benBankCountry = benBankCountry;
	}

	public String getRemitterFullAddress() {
		return remitterFullAddress;
	}

	public void setRemitterFullAddress(String remitterFullAddress) {
		this.remitterFullAddress = remitterFullAddress;
	}

	public String getIsIbanFlag() {
		return isIbanFlag;
	}

	public void setIsIbanFlag(String isIbanFlag) {
		this.isIbanFlag = isIbanFlag;
	}

	public String getiBanBbanAccount() {
		return iBanBbanAccount;
	}

	public void setiBanBbanAccount(String iBanBbanAccount) {
		this.iBanBbanAccount = iBanBbanAccount;
	}

	public String getBenBankFullName() {
		return benBankFullName;
	}

	public void setBenBankFullName(String benBankFullName) {
		this.benBankFullName = benBankFullName;
	}

}
