package com.bsf.macug.payroll.dto;

import java.io.Serializable;

public class MacPayrollActivityLogDTO implements Serializable {
    
	
	private String customerId;
	private String processSubject;
	private String processDescription;
	private String processType;
	private String processFileName;
	private String responseFileValue;
	private Integer processStatus;
	private String custReqFile;
	private String fileReference;

	public MacPayrollActivityLogDTO() {
		super();
	}

	public MacPayrollActivityLogDTO(String customerId,String processSubject, String processDescription, String processType,
			String processFileName, String responseFileValue,Integer processStatus,String custReqFile,String fileReference) {
		super();
		this.customerId=customerId;
		this.fileReference=fileReference;
		this.processSubject = processSubject;
		this.processDescription = processDescription;
		this.processType = processType;
		this.processFileName = processFileName;
		this.responseFileValue=responseFileValue;
		this.processStatus= processStatus;
		this.custReqFile=custReqFile;
	}

	public String getProcessSubject() {
		return processSubject;
	}

	public void setProcessSubject(String processSubject) {
		this.processSubject = processSubject;
	}

	public String getProcessDescription() {
		return processDescription;
	}

	public void setProcessDescription(String processDescription) {
		this.processDescription = processDescription;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getProcessFileName() {
		return processFileName;
	}

	public void setProcessFileName(String processFileName) {
		this.processFileName = processFileName;
	}
	
	
	public String getResponseFileValue() {
		return responseFileValue;
	}

	public void setResponseFileValue(String responseFileValue) {
		this.responseFileValue = responseFileValue;
	}
	
	public Integer getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(Integer processStatus) {
		this.processStatus = processStatus;
	}
	

	public String getCustReqFile() {
		return custReqFile;
	}

	public void setCustReqFile(String custReqFile) {
		this.custReqFile = custReqFile;
	}
	
	
	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	public String getFileReference() {
		return fileReference;
	}

	public void setFileReference(String fileReference) {
		this.fileReference = fileReference;
	}

	@Override
	public String toString() {
		return "MacPaymentActivityLogDTO [processSubject=" + processSubject + ", processDescription="
				+ processDescription + ", processType=" + processType + ", processFileName=" + processFileName + " ,responseFileValue="+responseFileValue+"]";
	}

}
