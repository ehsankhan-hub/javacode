package com.bsf.macug.payroll.rest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bsf.macug.exception.RestServiceException;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.payroll.dto.PayrollReqestTransferDTO;

@Service
@Scope("prototype")
public class RestClient implements InterRestClient {

	private static final Logger logger = Logger.getLogger(RestClient.class.getName());

	@Autowired
	InterSystemParameterService systemParameterService;

	@Override
	public String transferPayrollToBulkSystem(PayrollReqestTransferDTO dtoTransfer, String URI)
			throws RestServiceException {
		logger.info("(transferPayrollToBulkSystem)==> Starting to transfer to Bulk system");
		String strResponse = null;
		String strFileRefernce = null;
		if (dtoTransfer != null) {
			try {
				if (dtoTransfer.getHeaderObj() != null) {
					strFileRefernce = dtoTransfer.getHeaderObj().getFileId();
					logger.info("(transferPayrollToBulkSystem)==> File refernce is " + strFileRefernce + "\r\n");
				}
				logger.info("(transferPayrollToBulkSystem)==> request is " + dtoTransfer + "\r\n");
				RestTemplate restTemplate = new RestTemplate();
				restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
				restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
				strResponse = restTemplate.postForObject(URI, dtoTransfer, String.class);
				logger.info("(transferPayrollToBulkSystem)==> Response is " + strResponse + "\r\n");
			} catch (Exception e) {
				logger.error(
						"(transferPayrollToBulkSystem)==> Error occured in rest posting to connecting to client. Error "
								+ e.getMessage(),
						e);
			}
		} else {
			logger.info("(transferPayrollToBulkSystem)==> Transfer object is null or empty");
		}
		return strResponse;
	}

}
