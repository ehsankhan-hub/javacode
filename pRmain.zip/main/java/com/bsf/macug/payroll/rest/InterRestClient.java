package com.bsf.macug.payroll.rest;

import com.bsf.macug.exception.RestServiceException;
import com.bsf.macug.payroll.dto.PayrollReqestTransferDTO;

public interface InterRestClient {

	String transferPayrollToBulkSystem(PayrollReqestTransferDTO dtoTransfer, String URI) throws RestServiceException;

}
