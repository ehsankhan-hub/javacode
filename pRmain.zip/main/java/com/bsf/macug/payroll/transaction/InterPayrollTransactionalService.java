package com.bsf.macug.payroll.transaction;
import java.util.List;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.payroll.entity.MacFileLog;
import com.bsf.macug.payroll.entity.MacPayrollActivityLog;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;


public interface InterPayrollTransactionalService {

public List<MacPayrollHeader> findAllHeader(String status) throws DataAccessException;

public boolean saveHeader(MacPayrollHeader header) throws DataAccessException;
public boolean updateHeader(MacPayrollHeader header) throws DataAccessException;
public MacPayrollHeader getHeader(String customerId, String fileId) throws DataAccessException;
public boolean saveDetail(MacPayrollDetail detail) throws DataAccessException;
public boolean updateDetail(MacPayrollDetail detail) throws DataAccessException;
public List<MacPayrollDetail> findAllDetail(String customerId, String fileId, String status) throws DataAccessException;
public MacPayrollDetail getDetail(String customerId, String fileId, String transactionId) throws DataAccessException;
public Long getSequence(String sequenceName) throws DataAccessException;
public boolean savePayrollLog(MacFileLog log) throws DataAccessException;
public int updateDetail(String clientId, String fileId, String status, String description)throws DataAccessException;
//public MacPayrollDetail getDetailWithSequence(String clientId, String fileId, String strRecord)throws DataAccessException;
public List<MacPayrollHeader> findAllForResponseFile() throws DataAccessException;
public List<MacPayrollActivityLog> findAllFailedResponseFile() throws DataAccessException;
public MacFileLog getFileLog(String id)throws DataAccessException;
public boolean updateFileLog(MacFileLog log)throws DataAccessException ;
public MacPayrollDetail getDetailWithRecordNumber(String clientId, String fileId, String strRecord) throws DataAccessException;

public boolean updatePayrollActivityLog(MacPayrollActivityLog header) throws DataAccessException;

public MacPayrollActivityLog getPayrollProcessLogByFileName(String fileName)throws DataAccessException;

}
