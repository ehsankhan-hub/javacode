package com.bsf.macug.payroll.transaction;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.payroll.dao.InterPayrollDAO;
import com.bsf.macug.payroll.entity.MacFileLog;
import com.bsf.macug.payroll.entity.MacPayrollActivityLog;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;

@Service
@Transactional
public class PayrollTransactionalServiceImpl implements InterPayrollTransactionalService {

	@Autowired
	InterPayrollDAO payrollDao;

	@Override
	public List<MacPayrollHeader> findAllHeader(String status) throws DataAccessException{
		List<MacPayrollHeader> headerList = null;
		headerList = payrollDao.findAllHeader(status);
		return headerList;
	}
	
	@Override
	public boolean saveHeader(MacPayrollHeader header) throws DataAccessException{
		boolean status = false;
		try {
			header.setCreatedBy("SYSTEM");
			header.setCreatedDate(new Timestamp(new Date().getTime()));
			status = payrollDao.saveHeader(header);
		} catch (Exception e) {
			
		}
		return status;
	}

	@Override
	public boolean updateHeader(MacPayrollHeader header) throws DataAccessException{
		boolean status = false;
		try {
			header.setModifiedBy("SYSTEM");
			header.setModifiedDate(new Timestamp(new Date().getTime()));
			header.setValidatedTime(new Timestamp(new Date().getTime()));
			status = payrollDao.updateHeader(header);
		} catch (Exception e) {
			
		}
		return status;
	}
	
	@Override
	public boolean updatePayrollActivityLog(MacPayrollActivityLog macActivLog) throws DataAccessException{
		boolean status = false;
		try {
			
			status = payrollDao.updatePayrollActivity(macActivLog);
		} catch (Exception e) {
			
		}
		return status;
	}

	

	@Override
	public MacPayrollHeader getHeader(String customerId, String fileId) throws DataAccessException{
		MacPayrollHeader header = null;
		try {
			header = payrollDao.getHeader(customerId, fileId);
		} catch (Exception e) {
			//logger.error("Error : " + e.getMessage(), e);
		}
		return header;
	}

	@Override
	public boolean saveDetail(MacPayrollDetail detail) throws DataAccessException{
		boolean status = false;
		try {
			UUID guid = java.util.UUID.randomUUID();
			detail.setId(guid.toString());
			detail.setCreatedId("SYSTEM");
			detail.setCraetedDate(new Timestamp(new Date().getTime()));
			status = payrollDao.saveDetail(detail);
		} catch (Exception e) {
			//logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public boolean updateDetail(MacPayrollDetail detail) throws DataAccessException{
		boolean status = false;
		try {
			detail.setModifiedId("SYSTEM");
			detail.setModifiedDate(new Timestamp(new Date().getTime()));
			status = payrollDao.updateDetail(detail);
		} catch (Exception e) {
			//logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public List<MacPayrollDetail> findAllDetail(String customerId, String fileId, String status) throws DataAccessException{
		List<MacPayrollDetail> detailList = null;
		try {
			detailList = payrollDao.findAllDetail(customerId, fileId, status);
		} catch (Exception e) {
			//logger.error("Error : " + e.getMessage(), e);
		}
		return detailList;
	}

	@Override
	public MacPayrollDetail getDetail(String customerId, String fileId, String transactionId) throws DataAccessException{
		MacPayrollDetail detail = null;
		try {
			detail = payrollDao.getDetail(customerId, fileId, transactionId);
		} catch (Exception e) {
			//logger.error("Error : " + e.getMessage(), e);
		}
		return detail;
	}

	@Override
	public Long getSequence(String sequenceName) throws DataAccessException{
		Long value = null;
		try {
			BigDecimal valueBig = payrollDao.getSequence(sequenceName);
			if (valueBig != null) {
				value = valueBig.longValue();
			}
		} catch (Exception e) {
			//logger.error("Error : " + e.getMessage(), e);
		}
		return value;
	}

	@Override
	public boolean savePayrollLog(MacFileLog log) throws DataAccessException{
		boolean status = false;
		try {			
			log.setType("Payroll");
			log.setCreatedBy("SYSTEM");
			log.setCreatedOn(new Timestamp(new Date().getTime()));
			status = payrollDao.savePayrollLog(log);
		} catch (Exception e) {
			//logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}

	@Override
	public int updateDetail(String clientId, String fileId, String status, String description)throws DataAccessException {
		int updatedCount = -1;
		try {
			 updatedCount = payrollDao.updateDetail(clientId, fileId, status, description);
			
		} catch (Exception e) {
			updatedCount = -1;
			//logger.error("Error : " + e.getMessage(), e);
		}
		return updatedCount;
	}

	@Override
	public MacPayrollDetail getDetailWithRecordNumber(String clientId, String fileId, String strRecord)throws DataAccessException {
		MacPayrollDetail detail = null;
		try {
			detail = payrollDao.getDetailWithRecordNumber(clientId, fileId, strRecord);
		} catch (Exception e) {
			//logger.error("Error : " + e.getMessage(), e);
		}
		return detail;
	}

	@Override
	public List<MacPayrollHeader> findAllForResponseFile() throws DataAccessException{
		List<MacPayrollHeader> headerList = null;
		try {
			headerList = payrollDao.findAllForResponseFile();
		} catch (Exception e) {
			//logger.error("Error : " + e.getMessage(), e);
		}
		return headerList;
	}
	
	@Override
	public List<MacPayrollActivityLog> findAllFailedResponseFile() throws DataAccessException{
		List<MacPayrollActivityLog> headerList = null;
		try {
			headerList = payrollDao.findAllFailedResponseFile();
		} catch (Exception e) {
			//logger.error("Error : " + e.getMessage(), e);
		}
		return headerList;
	}
	
	@Override
	public MacFileLog getFileLog(String id)throws DataAccessException {
		MacFileLog log = null;
		try {
			log = payrollDao.getFileLog(id);
		} catch (Exception e) {
			//logger.error("Error : " + e.getMessage(), e);
		}
		return log;
	}

	@Override
	public boolean updateFileLog(MacFileLog log)throws DataAccessException {
		boolean status = false;
		try {			
			log.setModifiedBy("SYSTEM");
			log.setModifiedOn(new Timestamp(new Date().getTime()));
			status = payrollDao.updateFileLog(log);
		} catch (Exception e) {
			//logger.error("Error : " + e.getMessage(), e);
		}
		return status;
	}
	
	@Override
	public MacPayrollActivityLog getPayrollProcessLogByFileName(String fileName)throws DataAccessException {
		MacPayrollActivityLog macPaymentActLog=null;
		macPaymentActLog=payrollDao.getPayrollProcessLogByFileName(fileName);
		return macPaymentActLog;
	}
	
	
	
	

}
