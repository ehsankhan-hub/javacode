package com.bsf.macug.exception;

public class TuxedoException extends Exception {
	private String errorCode;

	public TuxedoException(String errorCode) {
		super();
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

}
