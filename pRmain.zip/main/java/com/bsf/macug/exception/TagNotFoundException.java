package com.bsf.macug.exception;

public class TagNotFoundException extends Exception{
	private String tag;

	public TagNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TagNotFoundException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public TagNotFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public TagNotFoundException(String tag) {
		this.tag = tag;
		// TODO Auto-generated constructor stub
	}

	public TagNotFoundException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
}
