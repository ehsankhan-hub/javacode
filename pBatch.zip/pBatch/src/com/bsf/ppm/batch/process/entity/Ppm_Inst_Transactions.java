package com.bsf.ppm.batch.process.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "PPM_INST_TRANSACTIONS")
@SuppressWarnings("serial")
public class Ppm_Inst_Transactions  implements Serializable{
private static final long serialVersionUID = 1L;
private String ppmTrnsRef;
private Long sequenceNum;
private String instRef;
private String trnsType;
private String status;
private Date trnsDate;
private Date valueDate;
private String trnsCrncy;
private BigDecimal trnsAmount;
private Double amountInSar;
private String genNarrative;
private String scnNarrative;
private Double drAmount;
private String debitAcc;
private String remitterName;
private String drActCrncy;
private String creditAcc;
private String crActCrncy;
private Double crAmount;
private String benBankAddress1;
private String benBankAddress2;
private String benName;
private String benBank;
private String benCountry;
private String benBankCode;
private String paymentDtls;
private Double amount;
private Date crValueDate;
private String commCrncy;
private String commAct;
private Double commAmount;
private String chrgCrncy;
private String chrgAct;
private Double chrgAmount;
private String sourceSystem;
private String ppmTrnsStatus;
private String cammActionCode;
private String ftsActionCode; 
private String cammErrorDes;
private String ppmStatusBy;
private Date ppmStatusDate;
private String blckReference;


@Id //@GeneratedValue
@Basic
@Column(name="PPM_TRAN_REF")
public String getPpmTrnsRef() {
	return ppmTrnsRef;
}

public void setPpmTrnsRef(String ppmTrnsRef) {
	this.ppmTrnsRef = ppmTrnsRef;
}

@Column(name ="PPM_INCMNG_SEQ")
public Long getSequenceNum() {
	return sequenceNum;
}

public void setSequenceNum(Long sequenceNum) {
	this.sequenceNum = sequenceNum;
}



@Column(name="PPM_TRAN_AMOUNT",insertable = false, updatable = false)
public Double getAmount() {
	return amount;
}

public void setAmount(Double amount) {
	this.amount = amount;
}

@Column(name="PPM_INST_REF")
public String getInstRef() {
	return instRef;
}



public void setInstRef(String instRef) {
	this.instRef = instRef;
}
@Column(name="PPM_TRAN_TYPE")
public String getTrnsType() {
	return trnsType;
}
public void setTrnsType(String trnsType) {
	this.trnsType = trnsType;
}


@Column(name="PPM_PROCESS_STATUS")
public String getStatus() {
	if(status!=null&&!"".equals(status)){
	if(status.equals("F")){
		status="FAIL";
	}
	else if(status.equals("E")){
		status="ERROR";	
	}
	else if(status.equals("P")){
		status="PROCESSED";	
	}
	else if(status.equals("N")){
		status="Pending";	
	}
	
	}
	return status;
	

}

public void setStatus(String status) {
	this.status = status;
}

@Column(name="PPM_TRANS_DATE")
public Date getTrnsDate() {
	return trnsDate;
}

public void setTrnsDate(Date trnsDate) {
	this.trnsDate = trnsDate;
}
@Column(name="PPM_VALUE_DATE")
public Date getValueDate() {
	return valueDate;
}
public void setValueDate(Date valueDate) {
	this.valueDate = valueDate;
}
@Column(name="PPM_TRAN_CURNCY")
public String getTrnsCrncy() {
	return trnsCrncy;
}
public void setTrnsCrncy(String trnsCrncy) {
	this.trnsCrncy = trnsCrncy;
}
@Column(name="PPM_TRAN_AMOUNT")
public BigDecimal getTrnsAmount() {
	return trnsAmount;
}
public void setTrnsAmount(BigDecimal trnsAmount) {
	this.trnsAmount = trnsAmount;
}
@Column(name="PPM_TRAN_SAR_AMOUNT")
public Double getAmountInSar() {
	return amountInSar;
}
public void setAmountInSar(Double amountInSar) {
	this.amountInSar = amountInSar;
}
@Column(name="PPM_GEN_NARRATIVES")
public String getGenNarrative() {
	return genNarrative;
}
public void setGenNarrative(String genNarrative) {
	this.genNarrative = genNarrative;
}
@Column(name="PPM_SCN_NARRATIVES")
public String getScnNarrative() {
	return scnNarrative;
}
public void setScnNarrative(String scnNarrative) {
	this.scnNarrative = scnNarrative;
}
@Column(name="PPM_REM_AMOUNT")
public Double getDrAmount() {
	return drAmount;
}
public void setDrAmount(Double drAmount) {
	this.drAmount = drAmount;
}
@Column(name="PPM_REM_ACCOUNT")
public String getDebitAcc() {
	return debitAcc;
}
public void setDebitAcc(String debitAcc) {
	this.debitAcc = debitAcc;
}
@Column(name="PPM_REM_NAME")
public String getRemitterName() {
	return remitterName;
}

public void setRemitterName(String remitterName) {
	this.remitterName = remitterName;
}

@Column(name="PPM_REM_CUR_CODE")
public String getDrActCrncy() {
	return drActCrncy;
}

public void setDrActCrncy(String drActCrncy) {
	this.drActCrncy = drActCrncy;
}

@Column(name="PPM_BEN_ACCOUNT")
public String getCreditAcc() {
return creditAcc;
}
public void setCreditAcc(String creditAcc) {
	this.creditAcc = creditAcc;
}

@Column(name="PPM_BEN_CUR_CODE")
public String getCrActCrncy() {
	return crActCrncy;
}

public void setCrActCrncy(String crActCrncy) {
	this.crActCrncy = crActCrncy;
}
@Column(name="PPM_BEN_AMOUNT")
public Double getCrAmount() {
	return crAmount;
}
public void setCrAmount(Double crAmount) {
	this.crAmount = crAmount;
}
@Column(name="PPM_BEN_BANK_ADD1")
public String getBenBankAddress1() {
	return benBankAddress1;
}
public void setBenBankAddress1(String benBankAddress1) {
	this.benBankAddress1 = benBankAddress1;
}

@Column(name="PPM_BEN_BANK_ADD2")
public String getBenBankAddress2() {
	return benBankAddress2;
}

public void setBenBankAddress2(String benBankAddress2) {
	this.benBankAddress2 = benBankAddress2;
}

@Column(name="PPM_BEN_NAME")
public String getBenName() {
	return benName;
}
public void setBenName(String benName) {
	this.benName = benName;
}
@Column(name="PPM_BEN_BANK")
public String getBenBank() {
	return benBank;
}

public void setBenBank(String benBank) {
	this.benBank = benBank;
}

@Column(name="PPM_BEN_BANK_CNTRY")
public String getBenCountry() {
	return benCountry;
}
public void setBenCountry(String benCountry) {
	this.benCountry = benCountry;
}
@Column(name="PPM_BEN_BANK_CODE")
public String getBenBankCode() {
	return benBankCode;
}
public void setBenBankCode(String benBankCode) {
	this.benBankCode = benBankCode;
}
@Column(name="PPM_PAY_DETAILS")
public String getPaymentDtls() {
	return paymentDtls;
}
public void setPaymentDtls(String paymentDtls) {
	this.paymentDtls = paymentDtls;
}
@Column(name="PPM_BEN_EXCH_RATE")
public Date getCrValueDate() {
	return crValueDate;
}
public void setCrValueDate(Date crValueDate) {
	this.crValueDate = crValueDate;
}
@Column(name="PPM_COMM_CRNCY")
public String getCommCrncy() {
	return commCrncy;
}
public void setCommCrncy(String commCrncy) {
	this.commCrncy = commCrncy;
}
@Column(name="PPM_COMM_ACCT_NO")
public String getCommAct() {
	return commAct;
}
public void setCommAct(String commAct) {
	this.commAct = commAct;
}
@Column(name="PPM_COMM_AMOUNT")
public Double getCommAmount() {
	return commAmount;
}
public void setCommAmount(Double commAmount) {
	this.commAmount = commAmount;
}
@Column(name="PPM_CHARGE_CRNCY")
public String getChrgCrncy() {
	return chrgCrncy;
}
public void setChrgCrncy(String chrgCrncy) {
	this.chrgCrncy = chrgCrncy;
}
@Column(name="PPM_CHARGE_ACCT_NO")
public String getChrgAct() {
	return chrgAct;
}
public void setChrgAct(String chrgAct) {
	this.chrgAct = chrgAct;
}
@Column(name="PPM_CHARGE_AMOUNT")
public Double getChrgAmount() {
	return chrgAmount;
}
public void setChrgAmount(Double chrgAmount) {
	this.chrgAmount = chrgAmount;
}
@Column(name="PPM_SOURCE_SYSTEM")
public String getSourceSystem() {
	return sourceSystem;
}
public void setSourceSystem(String sourceSystem) {
	this.sourceSystem = sourceSystem;
}
@Column(name="PPM_TRANS_STATUS")
public String getPpmTrnsStatus() {
	return ppmTrnsStatus;
}
public void setPpmTrnsStatus(String ppmTrnsStatus) {
	this.ppmTrnsStatus = ppmTrnsStatus;
}
@Column(name="PPM_CAMM_ACTION_CODE")
public String getCammActionCode() {
	return cammActionCode;
}
public void setCammActionCode(String cammActionCode) {
	this.cammActionCode = cammActionCode;
}
@Column(name="PPM_FTS_ACTION_CODE")
public String getFtsActionCode() {
	return ftsActionCode;
}
public void setFtsActionCode(String ftsActionCode) {
	this.ftsActionCode = ftsActionCode;
}

@Transient
public String getCammErrorDes() {
return cammErrorDes;
}

public void setCammErrorDes(String cammErrorDes) {
this.cammErrorDes = cammErrorDes;
}

@Column(name="PPM_STATUS_BY")
public String getPpmStatusBy() {
	return ppmStatusBy;
}

public void setPpmStatusBy(String ppmStatusBy) {
	this.ppmStatusBy = ppmStatusBy;
}
@Column(name="PPM_STATUS_DATE")
public Date getPpmStatusDate() {
	return ppmStatusDate;
}

public void setPpmStatusDate(Date ppmStatusDate) {
	this.ppmStatusDate = ppmStatusDate;
}



}
