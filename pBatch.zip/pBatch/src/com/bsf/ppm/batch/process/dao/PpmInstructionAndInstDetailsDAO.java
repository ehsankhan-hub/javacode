package com.bsf.ppm.batch.process.dao;

import java.util.List;

import org.hibernate.annotations.Entity;

import com.bsf.ppm.batch.process.entity.InstructionDetails;
import com.bsf.ppm.batch.process.entity.Ppm_Instructions;
import com.bsf.ppm.batch.process.exception.DAOException;

public interface PpmInstructionAndInstDetailsDAO {
	public boolean saveBulkInstandInstDetails(List<Ppm_Instructions> entities, int batchSize,List<InstructionDetails>entitiesDatails,int batchSizeDetails)
			throws DAOException;
	
}
