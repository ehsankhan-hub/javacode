package com.bsf.ppm.batch.process.dao;

import org.hibernate.Query;
import org.hibernate.Session;

import com.bsf.ppm.batch.process.dao.generic.GenericJPADAO;
import com.bsf.ppm.batch.process.dao.util.SessionFactoryManager;
import com.bsf.ppm.batch.process.entity.CBlockDBlock;
import com.bsf.ppm.batch.process.entity.PpmDebitBlockStaging;
import com.bsf.ppm.batch.process.exception.DAOException;

public class DebitBlockStagingJpaDAO extends
		GenericJPADAO<PpmDebitBlockStaging, String> implements
		DebitBlockStagingDAO {
	

}
