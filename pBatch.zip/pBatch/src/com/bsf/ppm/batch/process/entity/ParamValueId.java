package com.bsf.ppm.batch.process.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ParamValueId implements Serializable{
	private String parmtypecode;	
	private String value1;
	private String groupCode;
	private String value2;
	@Column(name="PARAM_TYPE_CODE")
	public String getParmtypecode() {
		return parmtypecode;
	}
	public void setParmtypecode(String parmtypecode) {
		this.parmtypecode = parmtypecode;
	}
	@Column(name="VALUE1")
	public String getValue1() {
		return value1;
	}
	public void setValue1(String value1) {
		this.value1 = value1;
	}
	@Column(name="GROUP_CODE")
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	

	@Column(name="VALUE2")
	public String getValue2() {
		return value2;
	}
	public void setValue2(String value2) {
		this.value2 = value2;
	}
	
	
	 public boolean equals(Object obj) {
	        if (obj == null) return false;
	        if (!this.getClass().equals(obj.getClass())) return false;
	         
	        ParamValueId obj2 = (ParamValueId)obj;
	 
	        if (this.parmtypecode.equals(obj2.getParmtypecode()) &&
	            this.groupCode.equals(obj2.getGroupCode()) && this.value1.equals(obj2.getValue1())) {
	            return true;
	        }
	        return false;
	    }
	 
	    public int hashCode() {      
	        int tmp = 0;
	        tmp = (parmtypecode + groupCode+value1).hashCode();
	        return tmp;
	    }
	}

	
	

