package com.bsf.ppm.batch.process.dao.generic;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.bsf.ppm.batch.process.dao.util.SessionFactoryCisprodManager;
import com.bsf.ppm.batch.process.dao.util.SessionFactoryManager;
import com.bsf.ppm.batch.process.entity.ParameterValue;
import com.bsf.ppm.batch.process.exception.DAOException;


public abstract class GenericJPADAO<E, K extends Serializable> implements
		GenericDAO<E, K> {

	private static final Logger logger = Logger.getLogger(GenericJPADAO.class);

	private Class<E> paramClass;

	public GenericJPADAO() {
		Type t = getClass().getGenericSuperclass();
		ParameterizedType pt = (ParameterizedType) t;
		paramClass = (Class<E>) pt.getActualTypeArguments()[0];
	}

	/*
	 * public GenericJPADAO() { this.paramClass = (Class<E>)
	 * ((ParameterizedType) getClass()
	 * .getGenericSuperclass()).getActualTypeArguments()[0]; }
	 */

	@Override
	public List fetchAllRecords() throws DAOException {
		List<E> lstReocords = null;
		Session session = null;
		try {
			session = SessionFactoryManager.getSession();
			Criteria ctrRecords = session.createCriteria(this.paramClass);
			return ctrRecords.list();
		} catch (Exception e) {
			logger.error("Error in fetching record. Error " + e.getMessage(), e);
			throw new DAOException("DAO list fetching error.", e);
		}
	}

	@Override
	public List<E> fetchAllRecords(String namedQuery) throws DAOException {
		List<E> lstReocords = null;
		Session session = null;
		try {
			session = SessionFactoryManager.getSession();
			Query query = session.createQuery(namedQuery);
			lstReocords = (List<E>) query.list();
		} catch (Exception e) {
			logger.error("Error in fetching record. Error " + e.getMessage(), e);
			throw new DAOException("DAO list fetching error.", e);
		} /*finally {
			if (session != null)
				session.close();
		}*/
		return lstReocords;
	}
	
	@Override
	public List findByName(String namedQuery) throws DAOException {
		Session session = null;
		try {
			session = SessionFactoryManager.getSession();
			Query query = session.createQuery(namedQuery);
			return query.list();
		} catch (Exception e) {
			logger.error("Error in fetching record. Error " + e.getMessage(), e);
			throw new DAOException("DAO list fetching error.", e);
		} /*finally {
			if (session != null)
				session.close();
		}*/
	}
	
	
	@Override
	public List fetchAllRecordList(String namedQuery) throws DAOException {
		Session session = null;
		try {
			session = SessionFactoryManager.getSession();
			//session=SessionFactoryCisprodManager.getSession();
			Query query = session.createQuery(namedQuery);
			return query.list();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error in fetching record. Error " + e.getMessage(), e);
			throw new DAOException("DAO list fetching error.", e);
		} /*finally {
			if (session != null)
				session.close();
		}*/
	}
	
	@Override
	public List fetchAllRecordListCISAccounts(String namedQuery) throws DAOException {
		Session session = null;
		try {
			//session = SessionFactoryManager.getSession();
			session=SessionFactoryCisprodManager.getSession();
			//Query query = session.createQuery(namedQuery);
			Query query = session.createSQLQuery(namedQuery);
			return query.list();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error in fetching record. Error " + e.getMessage(), e);
			throw new DAOException("DAO list fetching error.", e);
		} /*finally {
			if (session != null)
				session.close();
		}*/
	}
	
	


	@Override
	public boolean save(E entity) throws DAOException {
		Session session = null;
		Transaction trans = null;
		try {
			session = SessionFactoryManager.getSession();
			trans = session.beginTransaction();
			session.save(entity);
			trans.commit();
			return true;
		} catch (Exception e) {
			trans.rollback();
			throw new DAOException("Error in saving", e);
		}
	}

	@Override
	public boolean saveBulk(List<E> entities, int batchSize)
			throws DAOException {
		Session session = null;
		Transaction trans = null;
		try {
			session = SessionFactoryManager.getSession();
			trans = session.beginTransaction();
			int size = (entities != null && entities.size() > 0) ? entities
					.size() : 0;
			for (E entity : entities) {
				session.save(entity);
				if (size % batchSize == 0)
					session.flush();
			}
			trans.commit();
			return true;
		} catch (Exception e) {
			trans.rollback();
			throw new DAOException("Error in batch saving", e);
		}
	}
	

	@Override
	public boolean update(E entity) throws DAOException {
		Session session = null;
		Transaction trans = null;
		try {
			session = SessionFactoryManager.getSession();
			trans = session.beginTransaction();
			session.update(entity);
			trans.commit();
			return true;
		} catch (Exception e) {
			trans.rollback();
			throw new DAOException("Error in saving", e);
		}
	}

	@Override
	public boolean updateBulk(List<E> entities, int batchSize)
			throws DAOException {
		Session session = null;
		Transaction trans = null;
		try {
			session = SessionFactoryManager.getSession();
			trans = session.beginTransaction();
			int size = (entities != null && entities.size() > 0) ? entities.size() : 0;
			for (E entity : entities) {
				session.update(entity);
				if (size % batchSize == 0)
					session.flush();
			}
			trans.commit();
			return true;
		} catch (Exception e) {
			trans.rollback();
			throw new DAOException("Error in batch saving", e);
		}
	}

	@Override
	public E findByID(K key) throws DAOException {
		Session session = null;
		Transaction trans = null;
		try {
			session = SessionFactoryManager.getSession();
			
			//trans = session.beginTransaction();
			return (E) session.get(this.paramClass, key);
		} catch (Exception e) {
			throw new DAOException("Error in batch saving", e);
		}/*finally{
			if(trans!=null)
				trans.commit();
			if(session!=null)
				session.close();
		}*/
	}
	
	@Override
	public String getPPMReference() throws DAOException {
		String sql = "SELECT PPM_INS_REF.NEXTVAL FROM DUAL";
        Session session=null;
        BigDecimal ppmReferceneId;
		try {
			session = SessionFactoryManager.getSession();
			
			Query query = session.createSQLQuery(sql);
			ppmReferceneId= (BigDecimal) query.uniqueResult();
			
			return "P"+ppmReferceneId; 
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error in fetching record. Error " + e.getMessage(), e);
			throw new DAOException("DAO list fetching error.", e);
		} 
		}
   


@Override
public Long getInstDetaiSeqGen() throws DAOException {
	String sql = "SELECT PPM_INS_DTL_ID.NEXTVAL FROM DUAL";
	Session session=null;
	BigDecimal ppmReferceneId = null;
	try {
		session = SessionFactoryManager.getSession();
		//session=SessionFactoryCisprodManager.getSession();
		Query query = session.createSQLQuery(sql);
		ppmReferceneId= (BigDecimal) query.uniqueResult();
		
		return ppmReferceneId.longValue(); 
	} catch (Exception e) {
		e.printStackTrace();
		logger.error("Error in fetching record. Error " + e.getMessage(), e);
		throw new DAOException("DAO list fetching error.", e);
	} 

}

@Override
public ParameterValue getPercent() throws DAOException {
	ParameterValue list = null;
	Session session=null;
	String sql = "FROM com.bsf.ppm.batch.process.entity.ParameterValue PV WHERE PV.parmtypecode='EXEPRNCT' and PV.groupCode='SPP'";
	try {
		session = SessionFactoryManager.getSession();
		System.out.println("session==="+session);
		list = (ParameterValue) session.createQuery(sql).uniqueResult();
		System.out.println("list---"+list);
		return list;
	}catch (Exception ex) {
		System.out.println("Error in fetching percent"+ ex.getMessage());
		throw new DAOException("error.executeQuery", ex);
	}
}

}
