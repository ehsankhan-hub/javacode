package com.bsf.ppm.batch.process.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.bsf.ppm.batch.process.dao.CBlockDBlockDAO;
import com.bsf.ppm.batch.process.dao.CBlockDBlockJpaDAO;
import com.bsf.ppm.batch.process.dao.DebitBlockStagingDAO;
import com.bsf.ppm.batch.process.dao.DebitBlockStagingJpaDAO;
import com.bsf.ppm.batch.process.dao.ParameterValueDAO;
import com.bsf.ppm.batch.process.dao.ParameterValueJpaDAO;
import com.bsf.ppm.batch.process.dao.PpmDebitExemptDAO;
import com.bsf.ppm.batch.process.dao.PpmDebitExemptJpaDAO;
import com.bsf.ppm.batch.process.dao.PpmInstructionDAO;
import com.bsf.ppm.batch.process.dao.PpmInstructionJpaDAO;
import com.bsf.ppm.batch.process.entity.CBlockDBlock;
import com.bsf.ppm.batch.process.entity.ParameterValue;
import com.bsf.ppm.batch.process.entity.PpmDebitBlockStaging;
import com.bsf.ppm.batch.process.entity.PpmDebitExempt;
import com.bsf.ppm.batch.process.entity.Ppm_Instructions;
import com.bsf.ppm.batch.process.exception.DAOException;
import com.bsf.ppm.batch.process.exception.ProcessException;

public class PpmDebitExemptServiceImpl {

	private static final Logger logger = Logger
			.getLogger(PpmDebitExemptServiceImpl.class);
    private PpmDebitExempt ppmDebitExempEntity=null ;
    	
	 public PpmDebitExempt findByCustCode(String cust_Code)throws ProcessException{
		 
		 try {  
			    //String query="from PpmDebitExempt where custCode="+"'"+cust_Code+"'";
				PpmDebitExemptDAO ppmDebitExemptDAO = null;
				ppmDebitExemptDAO = new PpmDebitExemptJpaDAO();
				ppmDebitExempEntity =ppmDebitExemptDAO.findByID(cust_Code);
				//ppmDebitExemptDAO.fetchAllRecordList(query);
				
		 }
		 catch(Exception ex){
			 ex.printStackTrace();
		 }
		 
		 return ppmDebitExempEntity;
		 
	 }
	 
public List<String> findAllExmptList()throws ProcessException{
	List ppmDebitExempEntityList=null;
		 try {  
			    String query="select pex.custCode from  PpmDebitExempt pex";
				PpmDebitExemptDAO ppmDebitExemptDAO = null;
				ppmDebitExemptDAO = new PpmDebitExemptJpaDAO();
				//ppmDebitExempEntityList=ppmDebitExemptDAO.fetchAllRecords();
			    ppmDebitExempEntityList=ppmDebitExemptDAO.fetchAllRecordList(query);
				
		 }
		 catch(Exception ex){
			 ex.printStackTrace();
		 }
		 
		 return ppmDebitExempEntityList;
		 
	 }



}
