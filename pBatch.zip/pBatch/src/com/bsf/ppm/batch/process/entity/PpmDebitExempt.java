package com.bsf.ppm.batch.process.entity;
import java.io.Serializable;

import java.util.Date;


import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Table;



@Entity
/*@NamedQueries({
	@NamedQuery(name = "Ppm_DebitBlockStaging.selectA_AccountsfromCamm", query = "Select PpmDebitBlockStaging  "
		+ " where acctStatusCamm=:acctStatusCammDb or acctStatusCamm=:acctStatusCammXb  and  statuRsnCodeCamm=:statuRsnCodeCamm")
})*/

@Table(name = "PPM_DEBIT_EXEMPT")
@SuppressWarnings("serial")
public class PpmDebitExempt  implements Serializable {
    
	private String accNumber;
	
	private String custCode;
	
		
	private String status;
	
		
	private Date createdDate;
	
	private String createdBy;
	
	private Date updatedDate;
	
	private String updatedBy;
	
	private String deletedBy;
	
	private Date deletedDate;
	
	
	@Id 
	@Basic
	@Column(name = "CUST_CODE")
	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	
	@Column(name = "ACT_NO")
	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}
    

	
	@Column(name="STATUS")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	@Column(name="CREATED_DATE")
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@Column(name="CREATED_BY")
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	@Column(name="UPDATED_DATE")
	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	@Column(name="UPDATED_BY")
	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	@Column(name="DELETED_BY")
	public String getDeletedBy() {
		return deletedBy;
	}

	public void setDeletedBy(String deletedBy) {
		this.deletedBy = deletedBy;
	}
	
	
	@Column(name="DELETED_DATE")
	public Date getDeletedDate() {
		return deletedDate;
	}

	
	public void setDeletedDate(Date deletedDate) {
		this.deletedDate = deletedDate;
	}
	
		

	/*@Override
	@Transient
	public String getPk() {
		return String.valueOf(getCustCode());
	}
	@Override
	@Transient
	public String getKey() {
		// TODO Auto-generated method stub
		return getCustCode()+"";
	}
	*/
	
	
	
	
	
	

}
