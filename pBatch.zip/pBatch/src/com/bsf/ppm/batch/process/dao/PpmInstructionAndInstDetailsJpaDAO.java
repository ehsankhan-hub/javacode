package com.bsf.ppm.batch.process.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.annotations.Entity;

import com.bsf.ppm.batch.process.dao.util.SessionFactoryManager;
import com.bsf.ppm.batch.process.entity.InstructionDetails;
import com.bsf.ppm.batch.process.entity.Ppm_Instructions;
import com.bsf.ppm.batch.process.exception.DAOException;

public class PpmInstructionAndInstDetailsJpaDAO implements PpmInstructionAndInstDetailsDAO{

	@Override
	public boolean saveBulkInstandInstDetails(List<Ppm_Instructions> entities, int batchSize,List<InstructionDetails>entitiesDatails,int batchSizeDetails)
			throws DAOException {
		Session session = null;
		Transaction trans = null;
		
		try {
			session = SessionFactoryManager.getSession();
			trans = session.beginTransaction();
			int size = (entities != null && entities.size() > 0) ? entities.size() : 0;
			for (Ppm_Instructions entity: entities) {
				session.save(entity);
				if (size % batchSize == 0)
					session.flush();
				    
			}
			int sizeDetails = (entitiesDatails != null && entitiesDatails.size() > 0) ? entitiesDatails.size() : 0;
			for (InstructionDetails entity : entitiesDatails) {
				session.save(entity);
				if (sizeDetails % batchSizeDetails == 0)
					session.flush();
				   
			}
			
			trans.commit();
			//trans.commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			trans.rollback();
			//return false;
			throw new DAOException("Error in batch saving", e);
		}
	}
}
