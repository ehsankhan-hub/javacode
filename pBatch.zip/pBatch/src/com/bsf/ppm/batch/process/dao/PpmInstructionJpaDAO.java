package com.bsf.ppm.batch.process.dao;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.bsf.ppm.batch.process.dao.generic.GenericJPADAO;
import com.bsf.ppm.batch.process.dao.util.SessionFactoryManager;
import com.bsf.ppm.batch.process.entity.Ppm_Instructions;
import com.bsf.ppm.batch.process.exception.DAOException;




public class PpmInstructionJpaDAO extends
		GenericJPADAO<Ppm_Instructions, String> implements
		PpmInstructionDAO {
	
	public Ppm_Instructions findInstructionSalaryPercent(Ppm_Instructions ppmInstruction)throws DAOException{
		//String query="from Ppm_Instructions where custCode="+"'"+ppmInstruction.getCustCode()+"' AND instReference="+"'"+ppmInstruction.getInstReference()+"'";
		Session session = null;
		String query="from Ppm_Instructions where custCode="+"'"+ppmInstruction.getCustCode()+"'";
		//SessionFactory sessionFactory=new AnnotationConfiguration().configure().buildSessionFactory();
		//Session session=sessionFactory.openSession();
		Ppm_Instructions ppmInst= null;
		try {
			session = SessionFactoryManager.getSession();
			ppmInst=(Ppm_Instructions)session.createQuery(query).uniqueResult();
			
		//	session.close();			
		} catch (Exception e) {
			e.printStackTrace();
			throw new DAOException("Execption ==",e);
		}
		
		//Ppm_Instructions ppmInst=(Ppm_Instructions)session.get(Ppm_Instructions.class, ppmInstruction.getInstReference());
		return ppmInst;
	}
	
	public boolean updateInstruction(Ppm_Instructions ppmInstruction)throws DAOException{
		//SessionFactory sessionFactory=new AnnotationConfiguration().configure().buildSessionFactory();
		Session session = null;
		Transaction trans = null;
		try {
			session = SessionFactoryManager.getSession();
			trans = session.beginTransaction();
			session.update(ppmInstruction);
			trans.commit();
			return true;		
		} catch (Exception e) {
			//e.printStackTrace();
			trans.rollback();
			throw new DAOException("Execption ==",e);
		}
	
	}
	

}
