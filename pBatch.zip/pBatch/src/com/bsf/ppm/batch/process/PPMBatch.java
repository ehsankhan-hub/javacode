package com.bsf.ppm.batch.process;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import com.bsf.ppm.batch.process.entity.PpmDebitBlockStaging;
import com.bsf.ppm.batch.process.entity.Ppm_Instructions;
import com.bsf.ppm.batch.process.service.PpmInstructionServiceImpl;

public class PPMBatch {

	private final static Logger logger = Logger.getLogger(PPMBatch.class);
    
	private List<Ppm_Instructions> ppmInstructionsList=new ArrayList<Ppm_Instructions>();
	private List<PpmDebitBlockStaging> ppmDebitBlockStagingList=new ArrayList<PpmDebitBlockStaging>();
	
	public static void main(String[] args) {
	    int processStatus=0;
		PpmInstructionServiceImpl ppmInstructionServiceImpl=new PpmInstructionServiceImpl();
		//PPMBatch  ppmBatch=new PPMBatch();
		try{
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, 1);
			SimpleDateFormat format1 = new SimpleDateFormat("mm/dd/yyyy");
			String formatted = format1.format(cal.getTime());
			Date date=format1.parse(formatted);
			logger.info("PPM Instruction batch started at " + new Date());
			ppmInstructionServiceImpl.createInstruction();
			//logger.info("PPM Instruction batch end at " + new Date());
		}
	
		
		catch(Exception ex){
			ex.printStackTrace();
			logger.error("Job failed at "+new Date()+" Error "+ex.getMessage());
    		System.exit(1);
		}
		//logger.info("Job finished at  "+new Date()+"\r\n");
		logger.info("PPM Instruction batch end at " + new Date()+"\r\n");
    	System.exit(0);
	}	
	

		
	

}
