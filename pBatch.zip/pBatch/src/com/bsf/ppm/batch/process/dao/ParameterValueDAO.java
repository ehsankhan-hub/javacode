package com.bsf.ppm.batch.process.dao;

import com.bsf.ppm.batch.process.dao.generic.GenericDAO;
import com.bsf.ppm.batch.process.entity.ParameterValue;







public interface ParameterValueDAO extends GenericDAO<ParameterValue, String>{

	

}
