package com.bsf.ppm.batch.process.dao;

import com.bsf.ppm.batch.process.dao.generic.GenericDAO;
import com.bsf.ppm.batch.process.entity.CBlockDBlock;
import com.bsf.ppm.batch.process.entity.PpmDebitBlockStaging;
import com.bsf.ppm.batch.process.entity.Ppm_Instructions;
import com.bsf.ppm.batch.process.exception.DAOException;

public interface DebitBlockStagingDAO extends GenericDAO<PpmDebitBlockStaging, String> {
	
}
