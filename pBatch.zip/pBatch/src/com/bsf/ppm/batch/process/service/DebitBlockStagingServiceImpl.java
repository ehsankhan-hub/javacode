package com.bsf.ppm.batch.process.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.bsf.ppm.batch.process.dao.CBlockDBlockDAO;
import com.bsf.ppm.batch.process.dao.CBlockDBlockJpaDAO;
import com.bsf.ppm.batch.process.dao.DebitBlockStagingDAO;
import com.bsf.ppm.batch.process.dao.DebitBlockStagingJpaDAO;
import com.bsf.ppm.batch.process.dao.ParameterValueDAO;
import com.bsf.ppm.batch.process.dao.ParameterValueJpaDAO;
import com.bsf.ppm.batch.process.dao.PpmInstructionDAO;
import com.bsf.ppm.batch.process.dao.PpmInstructionJpaDAO;
import com.bsf.ppm.batch.process.entity.CBlockDBlock;
import com.bsf.ppm.batch.process.entity.ParameterValue;
import com.bsf.ppm.batch.process.entity.PpmDebitBlockStaging;
import com.bsf.ppm.batch.process.entity.Ppm_Instructions;
import com.bsf.ppm.batch.process.exception.DAOException;
import com.bsf.ppm.batch.process.exception.ProcessException;

public class DebitBlockStagingServiceImpl {

	private static final Logger logger = Logger
			.getLogger(DebitBlockStagingServiceImpl.class);

	public List<String> saveDebitBlockStaging() throws ProcessException {
		boolean blStatus = false;
		List<PpmDebitBlockStaging> lstStagingEntries = null;
		PpmDebitBlockStaging stagingEntry=null;
		List<String> lstCDBlockFromCAMM=null;
		try {
		     lstCDBlockFromCAMM = fetchAllCDBlocks();
			
			if (lstCDBlockFromCAMM != null) {
				DebitBlockStagingDAO stagingDAO = null;
				stagingDAO = new DebitBlockStagingJpaDAO();
				lstStagingEntries = new ArrayList<PpmDebitBlockStaging>();
				for (String custCode : lstCDBlockFromCAMM) {
					PpmDebitBlockStaging CDExisting = stagingDAO.findByID(custCode);
					
					if (CDExisting == null) {
						stagingEntry = new PpmDebitBlockStaging();
						stagingEntry.setCustCode(custCode);
						stagingEntry.setStatus("N");
						stagingEntry.setCreatedDate(new Date());
						stagingEntry.setCreatedBy("BatchJob");
						lstStagingEntries.add(stagingEntry);
					}

				}
				if (lstStagingEntries != null && lstStagingEntries.size() > 0) {
					blStatus = stagingDAO.saveBulk(lstStagingEntries, 50);
				}
				
				
				
				
				
				
				
			}
			
			
		} catch (Exception e) {
			logger.error(
					"Error in saving CBlock_DBlock records. Error "
							+ e.getMessage(), e);
			throw new ProcessException("Failed to fetch CBlock_DBlock records",
					e);
		}
		return lstCDBlockFromCAMM;
		
		
	}
	
    
	public CBlockDBlock fetchCDBlocksByCusCode(String custCode) throws ProcessException {
		CBlockDBlock cBlockDBlocks = null;
		CBlockDBlockDAO cdBlockDAO = null;
		try {
			cdBlockDAO = new CBlockDBlockJpaDAO();
			// and cbd.custCode<>'010824'
			String strQuery = "SELECT cbd.custCode from CBlockDBlock cbd where ((cbd.acctStatusCamm='DB' and cbd.statuRsnCodeCamm='20') OR (cbd.acctStatusCamm='FB' AND cbd.statuRsnCodeCamm='43')) AND cbd.deblkDate  is null and cbd.custCode="+"'"+custCode+"'" +"  group by cbd.custCode";
			cBlockDBlocks=cdBlockDAO.getCusCodeFromCblockDBlock(strQuery);
			
		} catch (Exception e) {
			logger.error(
					"Error in fetching CBlock_DBlock records. Error "
							+ e.getMessage(), e);
			throw new ProcessException("Failed to fetch CBlock_DBlock records",
					e);
		   }
		return cBlockDBlocks;

	}
	
	
	
	public Ppm_Instructions findByCustCode(Ppm_Instructions ppmInstructions)throws ProcessException{
		 
		 try {
				PpmInstructionDAO ppmInstruDAO = null;
				ppmInstruDAO = new PpmInstructionJpaDAO();
				ppmInstruDAO.findByID(ppmInstructions.getCustCode());
				
		 }
		 catch(Exception ex){
			 ex.printStackTrace();
		 }
		 
		 return ppmInstructions;
		 
	 }
    // fetching CPT's from CISPROD  
	public List<String> fetchAllCDBlocks() throws ProcessException {
		List lstCDBlocks = null;
		CBlockDBlockDAO cdBlockDAO = null;
		ParameterValueDAO paraValueDAO=null;
		ParameterValue parameterValue=null;
		try {
			cdBlockDAO = new CBlockDBlockJpaDAO();
			//paraValueDAO=new ParameterValueJpaDAO();
			//parameterValue=paraValueDAO.findByID("SELECT_QUERY");
			//parameterValue.getValue2();
			//and cbd.custCode='D06728'
			//String strQuery = "SELECT cbd.custCode from CBlockDBlock cbd where ((cbd.acctStatusCamm='DB' and cbd.statuRsnCodeCamm='20') OR (cbd.acctStatusCamm='FB' AND cbd.statuRsnCodeCamm='43')) AND cbd.deblkDate is null  group by cbd.custCode";
			
			String strQuery = "SELECT DISTINCT CUST_CODE "                                          
					+"FROM (SELECT DISTINCT T.CUST_CODE, "
					+"(SELECT NVL(COUNT(*), 0) "
					+"FROM CISBDSU.C_BLOCK_DEBLOCK X "
					+"WHERE X.CUST_CODE = T.CUST_CODE "
					+"AND (X.BLK_TYPE || X.BLK_RSN_CODE = 'DB20') "
					+"AND X.DEBLK_DATE IS NULL) DB20,"
					+"(SELECT NVL(COUNT(*), 0) "
					+"FROM CISBDSU.C_BLOCK_DEBLOCK X "
					+"WHERE X.CUST_CODE = T.CUST_CODE "
					+"AND (X.BLK_TYPE || X.BLK_RSN_CODE = 'FB43') "
					+"AND X.DEBLK_DATE IS NULL) FB43, "
					+"(SELECT NVL(COUNT(*), 0) "
					+"FROM CISBDSU.C_BLOCK_DEBLOCK X "
					+"WHERE X.CUST_CODE = T.CUST_CODE "
					+"AND (X.BLK_TYPE || X.BLK_RSN_CODE <> 'DB20' AND "
					+"X.BLK_TYPE || X.BLK_RSN_CODE <> 'FB43') "
					+"AND X.DEBLK_DATE IS NULL) FBDB_OTHERS "
					+"FROM CISBDSU.C_BLOCK_DEBLOCK T "
					+"WHERE (T.BLK_TYPE = 'DB' OR T.BLK_TYPE = 'FB') "
					+"AND T.DEBLK_DATE IS NULL) "
					+"WHERE FBDB_OTHERS = 0 "
					+"AND (DB20 + FB43 > 0) ";
			
			//production query to get the DB block CPT's
			/*String strQuery = "SELECT DISTINCT CUST_CODE "                                          
					+"FROM (SELECT DISTINCT T.CUST_CODE, "
					+"(SELECT NVL(COUNT(*), 0) "
					+"FROM CISPROD.C_BLOCK_DEBLOCK X "
					+"WHERE X.CUST_CODE = T.CUST_CODE "
					+"AND (X.BLK_TYPE || X.BLK_RSN_CODE = 'DB20') "
					+"AND X.DEBLK_DATE IS NULL) DB20,"
					+"(SELECT NVL(COUNT(*), 0) "
					+"FROM CISPROD.C_BLOCK_DEBLOCK X "
					+"WHERE X.CUST_CODE = T.CUST_CODE "
					+"AND (X.BLK_TYPE || X.BLK_RSN_CODE = 'FB43') "
					+"AND X.DEBLK_DATE IS NULL) FB43, "
					+"(SELECT NVL(COUNT(*), 0) "
					+"FROM CISPROD.C_BLOCK_DEBLOCK X "
					+"WHERE X.CUST_CODE = T.CUST_CODE "
					+"AND (X.BLK_TYPE || X.BLK_RSN_CODE <> 'DB20' AND "
					+"X.BLK_TYPE || X.BLK_RSN_CODE <> 'FB43') "
					+"AND X.DEBLK_DATE IS NULL) FBDB_OTHERS "
					+"FROM CISPROD.C_BLOCK_DEBLOCK T "
					+"WHERE (T.BLK_TYPE = 'DB' OR T.BLK_TYPE = 'FB') "
					+"AND T.DEBLK_DATE IS NULL) "
					+"WHERE FBDB_OTHERS = 0 "
					+"AND (DB20 + FB43 > 0) ";*/

			
			
			//lstCDBlocks = cdBlockDAO.fetchAllRecordList(strQuery);
			lstCDBlocks = cdBlockDAO.fetchAllRecordListCISAccounts(strQuery);
			logger.info("Total number of blocked CPT's "+lstCDBlocks.size());
		} catch (Exception e) {
			logger.error(
					"Error in fetching CBlock_DBlock records. Error "
							+ e.getMessage(), e);
			throw new ProcessException("Failed to fetch CBlock_DBlock records",
					e);
		}
		return lstCDBlocks;

	}

	public void fetcAllBlockStagingRecords() throws ProcessException {
		try {
			DebitBlockStagingDAO stagingDAO = null;
			stagingDAO = new DebitBlockStagingJpaDAO();
			List<PpmDebitBlockStaging> lstStagingBlocks = stagingDAO.fetchAllRecords();
			for (PpmDebitBlockStaging ppmDebitBlockStaging : lstStagingBlocks) {
					
				/* if(ppmDebitBlockStaging!=null){
					 List<String>  custCode=  fetchAllCDBlocks();
					 
					 
				 }*/
				System.out.println(ppmDebitBlockStaging.getCustCode());
		
				
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public List<PpmDebitBlockStaging>  fetcAllBlockStagingRecordList() throws ProcessException {
		List<PpmDebitBlockStaging> lstStagingBlocks=null;
		try {
			
			DebitBlockStagingDAO stagingDAO = null;
			stagingDAO = new DebitBlockStagingJpaDAO();
	        lstStagingBlocks = stagingDAO.fetchAllRecords();
	        
			for (PpmDebitBlockStaging ppmDebitBlockStaging : lstStagingBlocks) {
					
				/* if(ppmDebitBlockStaging!=null){
					 List<String>  custCode=  fetchAllCDBlocks();
					 
					 
				 }*/
				System.out.println(ppmDebitBlockStaging.getCustCode());
		
				
			}
		} 
		
		
		catch (Exception e) {
			// TODO: handle exception
		}
		return lstStagingBlocks;	
	}
	
	
	public PpmDebitBlockStaging  getByCustCode(String custCode) throws ProcessException {
		PpmDebitBlockStaging lstStagingBlocks=null;
		try {
			
			DebitBlockStagingDAO stagingDAO = null;
			stagingDAO = new DebitBlockStagingJpaDAO();
	        lstStagingBlocks = stagingDAO.findByID(custCode);
	        
	       
		} 
		
		
		catch (Exception e) {
			// TODO: handle exception
		}
		return lstStagingBlocks;	
	}
	
	public void updatePpmDebitBlockStaging(List<PpmDebitBlockStaging> ppmDebitBlockStaging) throws ProcessException{
		try {
		DebitBlockStagingDAO stagingDAO = null;
		stagingDAO = new DebitBlockStagingJpaDAO();
		if(ppmDebitBlockStaging!=null&&ppmDebitBlockStaging.size()>0){
		stagingDAO.updateBulk(ppmDebitBlockStaging, 50);
		}
		
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public boolean update(PpmDebitBlockStaging ppmDebitBlockStaging) throws ProcessException{
		boolean upddateFlag=false;
		try {
		DebitBlockStagingDAO stagingDAO = null;
		stagingDAO = new DebitBlockStagingJpaDAO();
		upddateFlag=stagingDAO.update(ppmDebitBlockStaging)	;	
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return upddateFlag;
		
	}
	
	public List<PpmDebitBlockStaging> getDebitBlockStagingLists() throws ProcessException{
		  List<PpmDebitBlockStaging>  ppmDebitBlockStaging=null;
		  try{
		  DebitBlockStagingDAO stagingDAO = null;
		  stagingDAO = new DebitBlockStagingJpaDAO();
		  
		 // ppmDebitBlockStaging=
				 // stagingDAO.findByID(status);
				 // ppmDebitBlockStaging= stagingDAO.fetchAllRecords("from PpmDebitBlockStaging where status=" + "'"	+ status + "'");
		  ppmDebitBlockStaging= stagingDAO.fetchAllRecords("from PpmDebitBlockStaging ");
		  }
		  catch (Exception e) {
			  e.printStackTrace();
				logger.error(
						"Error in fetching PpmDebitBlockStaging records. Error "
								+ e.getMessage(), e);
				throw new ProcessException("Failed to fetch PpmDebitBlockStaging records",
						e);
			   }
		  return ppmDebitBlockStaging;
	  }
	
  public PpmDebitBlockStaging getDebitBlockStagById(String cust_code) throws ProcessException{
	  PpmDebitBlockStaging  ppmDebitBlockStaging=null;
	  try{
	  DebitBlockStagingDAO stagingDAO = null;
	  stagingDAO = new DebitBlockStagingJpaDAO();
	  
	  ppmDebitBlockStaging=stagingDAO.findByID(cust_code);
	  }
	  catch (Exception e) {
			logger.error(
					"Error in fetching PpmDebitBlockStaging records. Error "
							+ e.getMessage(), e);
			throw new ProcessException("Failed to fetch PpmDebitBlockStaging records",
					e);
		   }
	  return ppmDebitBlockStaging;
  }

}
