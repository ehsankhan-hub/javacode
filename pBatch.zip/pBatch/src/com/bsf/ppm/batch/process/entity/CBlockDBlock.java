package com.bsf.ppm.batch.process.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "C_BLOCK_DEBLOCK")
/*@NamedQueries({ @NamedQuery(name = "selectCDBlockfromCamm", 
	query = "select obj from C_Block_Deblock where ((BLK_TYPE='DB' and BLK_RSN_CODE='20') OR (BLK_TYPE='FB' AND BLK_RSN_CODE='43')) AND DEBLK_DATE is null   group by CUST_CODE") })*/
@SuppressWarnings("serial")
public class CBlockDBlock implements Serializable {

	private String custCode;

	private String acctStatusCamm;

	private String statuRsnCodeCamm;

	private Date deblkDate;

	private String seqNo;

	public CBlockDBlock() {
	}

	@Id
	@Basic
	@Column(name = "CUST_CODE")
	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	@Column(name = "BLK_TYPE")
	public String getAcctStatusCamm() {
		return acctStatusCamm;
	}

	public void setAcctStatusCamm(String acctStatusCamm) {
		this.acctStatusCamm = acctStatusCamm;
	}

	@Column(name = "BLK_RSN_CODE")
	public String getStatuRsnCodeCamm() {
		return statuRsnCodeCamm;
	}

	public void setStatuRsnCodeCamm(String statuRsnCodeCamm) {
		this.statuRsnCodeCamm = statuRsnCodeCamm;
	}

	@Column(name = "DEBLK_DATE")
	public Date getDeblkDate() {
		return deblkDate;
	}

	public void setDeblkDate(Date deblkDate) {
		this.deblkDate = deblkDate;
	}

	@Column(name = "SEQ_NO")
	public String getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}

}
