package com.bsf.ppm.batch.process.dao;

import com.bsf.ppm.batch.process.dao.generic.GenericJPADAO;

import com.bsf.ppm.batch.process.entity.PpmDebitExempt;





public  class PpmDebitExemptJpaDAO extends  GenericJPADAO<PpmDebitExempt, String> implements
PpmDebitExemptDAO {
	

	
	
}