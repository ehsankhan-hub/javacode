package com.bsf.ppm.batch.process.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.bsf.ppm.batch.process.dao.DebitBlockStagingDAO;
import com.bsf.ppm.batch.process.dao.DebitBlockStagingJpaDAO;
import com.bsf.ppm.batch.process.dao.PpmInstructionAndInstDetailsDAO;
import com.bsf.ppm.batch.process.dao.PpmInstructionAndInstDetailsJpaDAO;
import com.bsf.ppm.batch.process.dao.PpmInstructionDAO;
import com.bsf.ppm.batch.process.dao.PpmInstructionJpaDAO;
import com.bsf.ppm.batch.process.entity.InstructionDetails;
import com.bsf.ppm.batch.process.entity.ParameterValue;
import com.bsf.ppm.batch.process.entity.PpmDebitBlockStaging;
import com.bsf.ppm.batch.process.entity.Ppm_Instructions;
import com.bsf.ppm.batch.process.exception.ProcessException;

public class PpmInstructionServiceImpl {

	private static final Logger logger = Logger
			.getLogger(PpmInstructionServiceImpl.class);
    
	private List<Ppm_Instructions> ppmInstructionsListadd=new ArrayList<Ppm_Instructions>();
	private List<InstructionDetails> instDetailListAdd =new ArrayList<InstructionDetails>();
	private List<PpmDebitBlockStaging> ppmDebitBlockStagingList=new ArrayList<PpmDebitBlockStaging>();
	boolean upddateFlag=false;
	public void savePpmInstruction(List<Ppm_Instructions> ppmInstructions) throws ProcessException{
		boolean blStatus = false;
		try {
			
		PpmInstructionDAO ppmInstruDAO = null;
		ppmInstruDAO = new PpmInstructionJpaDAO();
		
		if (ppmInstructions != null && ppmInstructions.size() > 0) {
			blStatus = ppmInstruDAO.saveBulk(ppmInstructions, 50);
		}
		
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public boolean savePpmInstructionAndInstDetails(List<Ppm_Instructions> ppmInstructionsList,List<InstructionDetails> instDetailsList) throws ProcessException{
		boolean blStatus = false;
		try {
			
		PpmInstructionAndInstDetailsDAO ppmInstruInstDetaisDAO = null;
		ppmInstruInstDetaisDAO = new PpmInstructionAndInstDetailsJpaDAO();
		
		if ((ppmInstructionsList != null && ppmInstructionsList.size() > 0)&&(instDetailsList!=null&&instDetailsList.size()>0)) {
		blStatus=ppmInstruInstDetaisDAO.saveBulkInstandInstDetails(ppmInstructionsList, 50,instDetailsList,50);
		}
		
		}
		catch(Exception e){
			e.printStackTrace();
			//blStatus=false;
		}
		return blStatus;
	}
	
	public boolean updaePpmInstruction(List<Ppm_Instructions> ppmInstructions) throws ProcessException{
		boolean blStatus = false;
		try {
			
		PpmInstructionDAO ppmInstruDAO = null;
		ppmInstruDAO = new PpmInstructionJpaDAO();
		
		if (ppmInstructions != null && ppmInstructions.size() > 0) {
			blStatus = ppmInstruDAO.saveBulk(ppmInstructions, 50);
		}
		
		}
		
		catch(Exception e){
			e.printStackTrace();
		return blStatus;
		}
		return blStatus;	
	}
    public  boolean update(Ppm_Instructions ppmInstructions)throws ProcessException{
    	boolean upddateFlag=false;
		try {
			PpmInstructionDAO ppmInstruDAO = null;
			ppmInstruDAO = new PpmInstructionJpaDAO();
			upddateFlag=ppmInstruDAO.updateInstruction(ppmInstructions);
			
	    }
		catch(Exception ex){
			ex.printStackTrace();
		}
       return upddateFlag;
    }
    
    public Ppm_Instructions findInstructionSalaryPercent(Ppm_Instructions ppmInstruction)throws ProcessException{
    	Ppm_Instructions instraction=null;
    	try {
			PpmInstructionDAO ppmInstruDAO = null;
			ppmInstruDAO = new PpmInstructionJpaDAO();
			instraction=ppmInstruDAO.findInstructionSalaryPercent(ppmInstruction);
			
	    }
		catch(Exception ex){
			ex.printStackTrace();
		}
    	return instraction;
    }
    
    public void updateInstruction(Ppm_Instructions ppmInstruction)throws ProcessException{
    	//Ppm_Instructions instraction=null;
    	try {
			PpmInstructionDAO ppmInstruDAO = null;
			ppmInstruDAO = new PpmInstructionJpaDAO();
			ppmInstruDAO.updateInstruction(ppmInstruction);
			
	    }
		catch(Exception ex){
			ex.printStackTrace();
		}
    	
    }
 
	
	public  void save(Ppm_Instructions ppmInstructions)throws ProcessException{
		
		try {
			PpmInstructionDAO ppmInstruDAO = null;
			ppmInstruDAO = new PpmInstructionJpaDAO();
			ppmInstruDAO.save(ppmInstructions);
			
	    }
		catch(Exception ex){
			ex.printStackTrace();
		}

}
	
	 public Ppm_Instructions findByCustCode(Ppm_Instructions ppmInstructions)throws ProcessException{
		 
		 try {  
			    String query=" from Ppm_Instructions where custCode="+"'"+ppmInstructions.getCustCode()+"'";
				PpmInstructionDAO ppmInstruDAO = null;
				ppmInstruDAO = new PpmInstructionJpaDAO();
				ppmInstruDAO.findByName(query);
				
		 }
		 catch(Exception ex){
			 ex.printStackTrace();
		 }
		 
		 return ppmInstructions;
		 
	 }
	 
	
	
		//Creating instruction in PPM_INSTRUCTIONS table 
	public void createInstruction() throws ProcessException {

		DebitBlockStagingServiceImpl debitBlockStagingService = new DebitBlockStagingServiceImpl();
		PpmInstructionServiceImpl ppmInsService = new PpmInstructionServiceImpl();
		PpmInstructionDetailsServiceImpl ppmInstDetailService = new PpmInstructionDetailsServiceImpl();
		PpmDebitExemptServiceImpl ppmDebitExemptService = new PpmDebitExemptServiceImpl();
		ParameterValueServiceImpl parameterValueService=new ParameterValueServiceImpl();
		List<PpmDebitBlockStaging> ppmDebBlcStagList = null;
		List<Ppm_Instructions> instructionListupdate = new ArrayList<Ppm_Instructions>();
		List<Ppm_Instructions> instructionListupdateDele = new ArrayList<Ppm_Instructions>();
		List<PpmDebitBlockStaging> debitStagListUpdat = new ArrayList<PpmDebitBlockStaging>();
		List<PpmDebitBlockStaging> lstStagingEntries = null;
		PpmDebitBlockStaging stagingEntry = null;
		String percentValue = "";
		String dayOfPayment = "";
		try {
			
			List<String> ppmDebitExemptList = ppmDebitExemptService
					.findAllExmptList();
			if(ppmDebitExemptList!=null)
			logger.info("Total number of records foud in Exempt table="
					+ ppmDebitExemptList.size());
			// GET the percentage from configuration table
			ParameterValue parameterValue = parameterValueService
					.getPercentDetails();

			if (parameterValue == null) {
				percentValue = "67";
			} else {
				percentValue = parameterValue.getValue1();
			}
			// GET the percentage from configuration table
			parameterValue = parameterValueService.getDayOfPayment();

			if (parameterValue == null) {
				dayOfPayment = "0";
				logger.info("Default Day of Paymnet=" + dayOfPayment);
			} else {
				dayOfPayment = parameterValue.getValue1();
				logger.info("Day of Paymnet from Configuration=" + dayOfPayment);
			}
			
			// fetching all the blocked CPT's with Status code (DB and 20) or
			// (FB and 43) from CIS
			List<String> cBlockDBlockList = debitBlockStagingService
					.fetchAllCDBlocks();
			logger.info("Total number of records found in C_BLOCK_DEBLOCK table="
					+ cBlockDBlockList.size());
			if (cBlockDBlockList != null) {
				DebitBlockStagingDAO stagingDAO = null;
				stagingDAO = new DebitBlockStagingJpaDAO();
				lstStagingEntries = new ArrayList<PpmDebitBlockStaging>();
				for (String custCode : cBlockDBlockList) {
					PpmDebitBlockStaging CDExisting = stagingDAO
							.findByID(custCode);
					if (CDExisting == null) {
						stagingEntry = new PpmDebitBlockStaging();
						stagingEntry.setCustCode(custCode);
						stagingEntry.setStatus("N");
						stagingEntry.setCreatedDate(new Date());
						stagingEntry.setCreatedBy("BatchJob");
						lstStagingEntries.add(stagingEntry);
					}

				}
				if (lstStagingEntries != null && lstStagingEntries.size() > 0) {
					stagingDAO.saveBulk(lstStagingEntries, 50);
				}
			}
				
			ppmDebBlcStagList = debitBlockStagingService
					.getDebitBlockStagingLists();
			logger.info("Total number of records found in PPM_DEBIT_BLOCK_STAGING table="
					+ ppmDebBlcStagList.size());

			for (PpmDebitBlockStaging cBlockDBlock : ppmDebBlcStagList) {
				// Activating CPT's in Staging table and activating Instructions
				// in PPM_INSTRUCTIONS table
				if (cBlockDBlockList.contains(cBlockDBlock.getCustCode())
						&& cBlockDBlock.getStatus().equals("D")) {
					PpmDebitBlockStaging ppmDebitBloSta = debitBlockStagingService
							.getByCustCode(cBlockDBlock.getCustCode());
					ppmDebitBloSta.setStatus("A");
					ppmDebitBloSta.setUpdatedBy("BatchJob");
					ppmDebitBloSta.setUpdatedDate(new Date());

					Ppm_Instructions ppmInstruction = new Ppm_Instructions();
					ppmInstruction.setCustCode(cBlockDBlock.getCustCode());
					Ppm_Instructions ppmInstruct = ppmInsService
							.findInstructionSalaryPercent(ppmInstruction);
					if (ppmInstruct != null) {
						ppmInstruct.setStatus("ACT");
						ppmInstruct.setUpdatedBy("BatchJob");
						ppmInstruct.setUpdatedDate(new Timestamp(System
								.currentTimeMillis()));
						instructionListupdate.add(ppmInstruct);
						debitStagListUpdat.add(ppmDebitBloSta);
						// debitBlockStagingService.update(ppmDebitBloSta);
						// ppmInsService.update(ppmInstruct);
					}

				}

			}
			if (instructionListupdate != null && instructionListupdate.size() > 0) {
				boolean insertFlag=ppmInsService.updaePpmInstruction(instructionListupdate);
				if(insertFlag){
				debitBlockStagingService.updatePpmDebitBlockStaging(debitStagListUpdat);
				logger.info("Total number of Instruction Status has been A/Activated "
						+ "in staging table and Status Active/ACT in PPM_INSTRUCTIONS "
						+ "table=" + instructionListupdate.size());     
				}
				else{
				logger.info("Error Occured at the time of PPM_Instructions update as A/Active, not updateing Staging table");	
				}
				
			}

			// deleting record from staging table mark the status D and closing
			// instructions in PPM_INSTRUCTIONS table marking status as CLS/Close.
			for (PpmDebitBlockStaging cBlockDBlock : ppmDebBlcStagList) {

				if (!cBlockDBlockList.contains(cBlockDBlock.getCustCode())
						&& cBlockDBlock.getStatus().equals("A")) {
					PpmDebitBlockStaging ppmDebitBloSta = debitBlockStagingService
							.getByCustCode(cBlockDBlock.getCustCode());

					ppmDebitBloSta.setStatus("D");
					ppmDebitBloSta.setUpdatedBy("BatchJob");
					ppmDebitBloSta.setUpdatedDate(new Date());
					ppmDebitBlockStagingList.add(ppmDebitBloSta);

					Ppm_Instructions ppmInstruction = new Ppm_Instructions();
					ppmInstruction.setCustCode(cBlockDBlock.getCustCode());
					// .findByCustCode(ppmInstruction);
					Ppm_Instructions ppmInstruct = ppmInsService
							.findInstructionSalaryPercent(ppmInstruction);
					if (ppmInstruct != null) {
						ppmInstruct.setStatus("CLS");
						ppmInstruct.setUpdatedBy("BatchJob");
						ppmInstruct.setUpdatedDate(new Timestamp(System
								.currentTimeMillis()));

						instructionListupdateDele.add(ppmInstruct);
						debitStagListUpdat.add(ppmDebitBloSta);
						// debitBlockStagingService.update(ppmDebitBloSta);
						// ppmInsService.update(ppmInstruct);
					}
				}

			}
			//Batch update in PPM_Instructions and staging table
			if (instructionListupdateDele != null
					&& instructionListupdateDele.size() > 0) {
				boolean updateFlat=ppmInsService.updaePpmInstruction(instructionListupdateDele);
				if(updateFlat){
				debitBlockStagingService.updatePpmDebitBlockStaging(debitStagListUpdat);
				logger.info("Total number of Instruction Status has been D/Deleted "
						+ "in staging table and Status closed/CLS in PPM_INSTRUCTIONS "
						+ "table" + instructionListupdateDele.size());
				}
				else{
				logger.info("Error Occured at the time of PPM_Instructions update as D/Delete not updateing Staging table");		
				}
				}
           
						
				   
			///  Pick the records from Staging table with status N and create the Instructions in Ppm_Instruction table
			///and update the status as A in Staging table.
			if (ppmDebBlcStagList != null) {
				PpmInstructionJpaDAO ppmInstructionDAO = new PpmInstructionJpaDAO();
				
				for (PpmDebitBlockStaging ppmDebitStaging : ppmDebBlcStagList) {
					Ppm_Instructions ppmInstructionCheck = new Ppm_Instructions();
					ppmInstructionCheck.setCustCode(ppmDebitStaging.getCustCode());
					Ppm_Instructions ppmInstCheck=ppmInstructionDAO.findInstructionSalaryPercent(ppmInstructionCheck);	
					if (ppmDebitStaging.getStatus().equals("N")) {
						if (!ppmDebitExemptList.contains(ppmDebitStaging.getCustCode())) {
														
							if(ppmInstCheck==null){
							Ppm_Instructions ppmInstruction = new Ppm_Instructions();
							InstructionDetails itemDetail = new InstructionDetails();
							String ppmReference = ppmInstructionDAO.getPPMReference().toString();
							Long ppmInstDtlRef = ppmInstructionDAO.getInstDetaiSeqGen();
							ppmInstruction.setInstReference(ppmReference);
							ppmInstruction.setInstgroupcode("SPP");
							ppmInstruction.setInstProrty(6);
							ppmInstruction.setExeType("EVENT_TRIGGER");
							ppmInstruction.setInstActionType("AATR");
							ppmInstruction.setCustCode(ppmDebitStaging.getCustCode());
							ppmInstruction.setAcctcurcode("SAR");
							ppmInstruction.setNoofBen(1);
							ppmInstruction.setInstBranch("004");
							ppmInstruction.setStartDateG(new Date());
							ppmInstruction.setEndDateG(new Date("2099/05/05"));
							ppmInstruction.setInstPercent(new Double(percentValue));
							ppmInstruction.setDayofPayment(new Integer(dayOfPayment));
							ppmInstruction.setEventTriggerOn("EVENTPAY");
							ppmInstruction.setStatus("ACT");
							ppmInstruction.setClandertype("G");
							ppmInstruction.setNoOfInst(10000);
     						ppmInstruction.setCreatedDate(new Timestamp(System.currentTimeMillis()));
							ppmInstruction.setCreatedBy("BatchJob");
                            itemDetail.setInstReference(ppmReference);
							itemDetail.setInstDtlId(ppmInstDtlRef.toString());
							itemDetail.setBenPftCtr("004");
							itemDetail.setBenAccCrncy("SAR");
							itemDetail.setiDType("ID");
							itemDetail.setCustIdNumber("2150");
							itemDetail.setAcctType("2150");
							itemDetail.setInstTrnsTyp("NT");
							itemDetail.setInstAccCrncy("SAR");
							ppmInstructionsListadd.add(ppmInstruction);
							instDetailListAdd.add(itemDetail);
							PpmDebitBlockStaging ppmDebitUpdatedBlock = debitBlockStagingService
									.getByCustCode(ppmDebitStaging
											.getCustCode());
							ppmDebitUpdatedBlock.setCustCode(ppmDebitStaging
									.getCustCode());
							ppmDebitUpdatedBlock.setStatus("A");
							ppmDebitUpdatedBlock.setUpdatedDate(new Date());
							ppmDebitUpdatedBlock.setUpdatedBy("BatchJob");
							ppmDebitBlockStagingList.add(ppmDebitUpdatedBlock);
  					    }
						// if record deleted from Exempt table if Instruction is Close Activating  	
                        else if (ppmInstCheck != null
									&& ppmInstCheck.getStatus().equals("CLS")) {
								PpmDebitBlockStaging ppmDebitBloSta = debitBlockStagingService
										.getByCustCode(ppmDebitStaging.getCustCode());
								ppmDebitBloSta.setStatus("A");
								ppmInstCheck.setStatus("ACT");
								//instructionListupdateDele.add(ppmInstCheck);
								upddateFlag=ppmInsService.update(ppmInstCheck);
								if(upddateFlag){
								debitBlockStagingService.update(ppmDebitBloSta);
								logger.info("Record deleted from Exempt table Activating the Instruction for CPT="+ppmDebitStaging.getCustCode());
								}
								else{
								logger.info("PPM_Instructions not updated successfully,due to that not updating staging table Close/CLS block");	
								}
								}

						}
						
					}
					
					//if new record inserted in Exempt table if Instruction is Active DeAactivateing 
					else if (ppmDebBlcStagList != null && ppmDebitStaging.getStatus().equals("A")
							&&ppmDebitExemptList.contains(ppmDebitStaging.getCustCode())) {

						if (ppmInstCheck != null
								&& ppmInstCheck.getStatus().equals("ACT")) {
							 PpmDebitBlockStaging ppmDebitBloSta =
							 debitBlockStagingService.getByCustCode(ppmDebitStaging.getCustCode());
							ppmDebitBloSta.setStatus("N");
							ppmInstCheck.setStatus("CLS");
							//instructionListupdateDele.add(ppmInstCheck);
							upddateFlag=ppmInsService.update(ppmInstCheck);
							if(upddateFlag){
						    debitBlockStagingService.update(ppmDebitBloSta);
							logger.info("New record inserted in Exempt table Closing the Instruction for CPT="+ppmDebitStaging.getCustCode());
							}
							else{
							logger.info("PPM_Instructions not updated successfully,due to that not updating staging table Active/ACT block");	
							}
							}  
					}

				}
				//Batch Insert in PPM_INSTRUCTIONS and PPM_INSTRUCTIONS_DTLS table
				if (ppmInstructionsListadd != null
						&& ppmInstructionsListadd.size() > 0) {
					//ppmInsService.savePpmInstruction(ppmInstructionsListadd);
					boolean insertFlag=false;
					insertFlag=ppmInsService.savePpmInstructionAndInstDetails(ppmInstructionsListadd,instDetailListAdd);
					//ppmInstDetailService.savePpmInstDetails(instDetailListAdd);
					if(insertFlag){
					debitBlockStagingService.updatePpmDebitBlockStaging(ppmDebitBlockStagingList);
					logger.info("Total number of records updating instructions status as A "
					  		+ "in staging table and createed Instructions in PPM_INSTRUCTIONS "
					  		+ "table="+ppmInstructionsListadd.size());
					}
					else{
					logger.info("Instructions not created successfully, due to that not updating staging table status as A/Active");	
					}
				}

			}

		} catch (Exception px) {
			px.printStackTrace();

			logger.error("System failed==" + px.getMessage());
			
		  throw new ProcessException("Job Failed",px);

		}
		
	}

}
