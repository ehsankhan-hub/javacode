package com.bsf.ppm.batch.process.dao;

import com.bsf.ppm.batch.process.dao.generic.GenericDAO;
import com.bsf.ppm.batch.process.entity.InstructionDetails;
import com.bsf.ppm.batch.process.exception.DAOException;

public interface PpmInstructionDetailsDAO extends GenericDAO<InstructionDetails, String> {

	
		
	
}
