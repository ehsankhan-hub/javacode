package com.bsf.ppm.batch.process.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.bsf.ppm.batch.process.dao.generic.GenericJPADAO;
import com.bsf.ppm.batch.process.dao.util.SessionFactoryManager;
import com.bsf.ppm.batch.process.entity.InstructionDetails;
import com.bsf.ppm.batch.process.entity.Ppm_Instructions;
import com.bsf.ppm.batch.process.exception.DAOException;


public class PpmInstructionDetailsJpaDAO extends
		GenericJPADAO<InstructionDetails, String> implements
		PpmInstructionDetailsDAO {
	
	
	
	
	


}
