package com.bsf.ppm.batch.process.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.bsf.ppm.batch.process.dao.CBlockDBlockDAO;
import com.bsf.ppm.batch.process.dao.CBlockDBlockJpaDAO;
import com.bsf.ppm.batch.process.dao.DebitBlockStagingDAO;
import com.bsf.ppm.batch.process.dao.DebitBlockStagingJpaDAO;
import com.bsf.ppm.batch.process.dao.PpmInstructionDAO;
import com.bsf.ppm.batch.process.dao.PpmInstructionDetailsDAO;
import com.bsf.ppm.batch.process.dao.PpmInstructionDetailsJpaDAO;
import com.bsf.ppm.batch.process.dao.PpmInstructionJpaDAO;
import com.bsf.ppm.batch.process.entity.CBlockDBlock;
import com.bsf.ppm.batch.process.entity.InstructionDetails;
import com.bsf.ppm.batch.process.entity.PpmDebitBlockStaging;
import com.bsf.ppm.batch.process.entity.Ppm_Instructions;
import com.bsf.ppm.batch.process.exception.DAOException;
import com.bsf.ppm.batch.process.exception.ProcessException;

public class PpmInstructionDetailsServiceImpl {

	private static final Logger logger = Logger
			.getLogger(PpmInstructionDetailsServiceImpl.class);

	public void savePpmInstDetails(List<InstructionDetails> ppmInstructionsDetails) throws ProcessException{
		boolean blStatus = false;
		try {
			
		PpmInstructionDetailsDAO ppmInstruDetailDAO = null;
		ppmInstruDetailDAO = new PpmInstructionDetailsJpaDAO();
		
		if (ppmInstructionsDetails != null && ppmInstructionsDetails.size() > 0) {
			blStatus = ppmInstruDetailDAO.saveBulk(ppmInstructionsDetails, 50);
		}
		
		//ppmInstruDAO.saveBulk(ppmInstructions, 50);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}

	
}
