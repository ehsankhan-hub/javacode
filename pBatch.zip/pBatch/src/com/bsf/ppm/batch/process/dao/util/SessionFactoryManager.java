package com.bsf.ppm.batch.process.dao.util;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import com.bsf.ppm.batch.process.exception.DAOException;

public class SessionFactoryManager {

	private static final Logger logger = Logger
			.getLogger(SessionFactoryManager.class);

	private static SessionFactory sessionFactory;

	private static Session session;

	@SuppressWarnings("deprecation")
	private static SessionFactory getSessionFactory() throws DAOException {
		if (sessionFactory == null) {
			try {
				return new AnnotationConfiguration().configure().buildSessionFactory();
			} catch (Exception e) {
				logger.error(
						"Error occured in creating session factory. Error "
								+ e.getMessage(), e);
				throw new DAOException("Session Factory creation failed", e);
			}

		}
		return sessionFactory;
	}

	public static Session getSession() throws DAOException {
		if (session != null) {
			return session;
		} else {
			try {
				session = getSessionFactory().openSession();
				return session;
			} catch (HibernateException e) {
				logger.error(
						"Failed to create session. Error " + e.getMessage(), e);
				throw new DAOException("Failed to create session. Error "
						+ e.getMessage(), e);
			} catch (DAOException e) {
				logger.error(
						"Failed to create session. Error " + e.getMessage(), e);
				throw new DAOException("Failed to create session. Error "
						+ e.getMessage(), e);
			}
		}
	}
	
	public static Session getCurrentSession() throws DAOException {
		if (session != null) {
			return session;
		} else {
			try {
				session = getSessionFactory().openSession();
				return session;
			} catch (HibernateException e) {
				logger.error(
						"Failed to create session. Error " + e.getMessage(), e);
				throw new DAOException("Failed to create session. Error "
						+ e.getMessage(), e);
			} catch (DAOException e) {
				logger.error(
						"Failed to create session. Error " + e.getMessage(), e);
				throw new DAOException("Failed to create session. Error "
						+ e.getMessage(), e);
			}
		}
	}
	
	

	public boolean closeSession() throws DAOException {
		if (session != null) {
			session.close();
			return true;
		}
		return false;
	}
	
	
	public static Connection getConnection()throws DAOException{
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		con =java.sql.DriverManager.getConnection("jdbc:oracle:thin:@EXAD-SCAN:1521:OLTPDEV","oepaysd","oepaysd");
		
		/*Class.forName("oracle.jdbc.driver.OracleDriver");
		con  =  java.sql.DriverManager.getConnection("jdbc:oracle:thin:@EXAH-SCAN:1521/BDSP","ppmappuser","ppm2017");*/
		}
		catch(ClassNotFoundException cnf){
			cnf.printStackTrace();
		}
		catch(SQLException sql){
		sql.printStackTrace();
		}
		return con;
	}

}
