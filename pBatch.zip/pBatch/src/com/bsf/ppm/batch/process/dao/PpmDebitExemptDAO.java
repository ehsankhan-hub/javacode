package com.bsf.ppm.batch.process.dao;

import com.bsf.ppm.batch.process.dao.generic.GenericDAO;
import com.bsf.ppm.batch.process.entity.PpmDebitExempt;






public interface PpmDebitExemptDAO extends GenericDAO<PpmDebitExempt, String>{

	

}
