package com.bsf.ppm.batch.process.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "PPM_INSTRUCTIONS_DETAILS")
@SuppressWarnings("serial")
public class InstructionDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String instDtlId;

	private String instReference;

	private String instAccNum;

	private String iDType;
	private String custIdNumber;
	private String acctType;

	private String instAccCrncy;

	private String benAcc;

	private String benAccCrncy;

	private String benName;

	private String benBank;

	private String banBankName;

	private String benBankCountry;

	private String benBankCode;

	private String benAddress;

	private String benBankAddress1;

	private String benBankAddress2;

	private String paymentDtls;

	private String instTrnsTyp;

	private String samaReference;

	private String accountstatus;

	private String benAccountStatus;

	private String benPftCtr;

	private String custName;

	private String relatedDoc;

	private String docDate;

	private String docRcvDate;

	private Ppm_Instructions ppmInstructions;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "INST_DTL_ID")
	public String getInstDtlId() {
		return instDtlId;
	}

	public void setInstDtlId(String instDtlId) {
		this.instDtlId = instDtlId;
	}
	
	
	@Column(name = "INST_REFERENCE")
	public String getInstReference() {
		return instReference;
	}

	public void setInstReference(String instReference) {
		this.instReference = instReference;
	}

	

	@Column(name = "INST_ACT_NO")
	public String getInstAccNum() {
		return instAccNum;
	}

	public void setInstAccNum(String instAccNum) {
		this.instAccNum = instAccNum;
	}

	@Column(name = "CUST_ID_TYPE")
	public String getiDType() {
		return iDType;
	}

	public void setiDType(String iDType) {
		this.iDType = iDType;
	}

	@Column(name = "CUST_ID_NO")
	public String getCustIdNumber() {
		return custIdNumber;
	}

	public void setCustIdNumber(String custIdNumber) {
		this.custIdNumber = custIdNumber;
	}

	@Column(name = "ACT_TYPE")
	public String getAcctType() {

		return acctType;
	}

	public void setAcctType(String acctType) {

		this.acctType = acctType;
	}

	@Column(name = "INST_ACT_CRNCY")
	public String getInstAccCrncy() {
		return instAccCrncy;
	}

	public void setInstAccCrncy(String instAccCrncy) {
		this.instAccCrncy = instAccCrncy;
	}

	@Column(name = "BEN_ACT")
	public String getBenAcc() {
		return benAcc;
	}

	public void setBenAcc(String benAcc) {
		this.benAcc = benAcc;
	}

	@Column(name = "BEN_ACT_CRNCY")
	public String getBenAccCrncy() {
		return benAccCrncy;
	}

	public void setBenAccCrncy(String benAccCrncy) {
		this.benAccCrncy = benAccCrncy;
	}

	@Column(name = "BEN_NAME")
	public String getBenName() {
		return benName;
	}

	public void setBenName(String benName) {
		this.benName = benName;
	}

	@Column(name = "BEN_BANK")
	public String getBenBank() {
		return benBank;
	}

	public void setBenBank(String benBank) {
		this.benBank = benBank;
	}

	@Column(name = "BEN_BANK_NAME")
	public String getBanBankName() {
		return banBankName;
	}

	public void setBanBankName(String banBankName) {
		this.banBankName = banBankName;
	}

	@Column(name = "BEN_BANK_CNTRY")
	public String getBenBankCountry() {
		return benBankCountry;
	}

	public void setBenBankCountry(String benBankCountry) {
		this.benBankCountry = benBankCountry;
	}

	@Column(name = "BEN_BANK_CODE")
	public String getBenBankCode() {
		return benBankCode;
	}

	public void setBenBankCode(String benBankCode) {
		this.benBankCode = benBankCode;
	}

	@Column(name = "BEN_ADDRESS")
	public String getBenAddress() {
		return benAddress;
	}

	public void setBenAddress(String benAddress) {
		this.benAddress = benAddress;
	}

	@Column(name = "BEN_BANK_ADD1")
	public String getBenBankAddress1() {
		return benBankAddress1;
	}

	public void setBenBankAddress1(String benBankAddress1) {
		this.benBankAddress1 = benBankAddress1;
	}

	@Column(name = "BEN_BANK_ADD2")
	public String getBenBankAddress2() {
		return benBankAddress2;
	}

	public void setBenBankAddress2(String benBankAddress2) {
		this.benBankAddress2 = benBankAddress2;
	}

	@Column(name = "PAY_DETAILS")
	public String getPaymentDtls() {
		return paymentDtls;
	}

	public void setPaymentDtls(String paymentDtls) {
		this.paymentDtls = paymentDtls;
	}

	@Column(name = "INST_TRANS_TYPE")
	public String getInstTrnsTyp() {
		return instTrnsTyp;
	}

	public void setInstTrnsTyp(String instTrnsTyp) {
		this.instTrnsTyp = instTrnsTyp;
	}

	@Column(name = "RELATED_REFERENCE")
	public String getSamaReference() {
		return samaReference;
	}

	public void setSamaReference(String samaReference) {
		this.samaReference = samaReference;
	}

	@Column(name = "ACT_STATUS")
	public String getAccountstatus() {
		return accountstatus;
	}

	public void setAccountstatus(String accountstatus) {
		this.accountstatus = accountstatus;
	}

	@Transient
	public String getBenAccountStatus() {
		return benAccountStatus;
	}

	public void setBenAccountStatus(String benAccountStatus) {
		this.benAccountStatus = benAccountStatus;
	}

	@Column(name = "BEN_PFTCTR")
	public String getBenPftCtr() {
		return benPftCtr;
	}

	public void setBenPftCtr(String benPftCtr) {
		this.benPftCtr = benPftCtr;
	}

	@Column(name = "CUST_NAME")
	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	@Column(name = "RELATED_DOC")
	public String getRelatedDoc() {
		return relatedDoc;
	}

	public void setRelatedDoc(String relatedDoc) {
		this.relatedDoc = relatedDoc;
	}

	@Column(name = "DOC_DATE")
	public String getDocDate() {
		return docDate;
	}

	public void setDocDate(String docDate) {
		this.docDate = docDate;
	}

	@Column(name = "DOC_RCV_DATE")
	public String getDocRcvDate() {
		return docRcvDate;
	}

	public void setDocRcvDate(String docRcvDate) {
		this.docRcvDate = docRcvDate;
	}

	/*@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "INST_REFERENCE")
	public Ppm_Instructions getPpmInstructions() {
		return ppmInstructions;
	}

	public void setPpmInstructions(Ppm_Instructions ppmInstructions) {
		this.ppmInstructions = ppmInstructions;
	}*/

}
