package com.bsf.ppm.batch.process.dao;

import com.bsf.ppm.batch.process.dao.generic.GenericJPADAO;
import com.bsf.ppm.batch.process.entity.ParameterValue;
import com.bsf.ppm.batch.process.entity.PpmDebitExempt;





public  class ParameterValueJpaDAO extends  GenericJPADAO<ParameterValue, String> implements
ParameterValueDAO {
	
}