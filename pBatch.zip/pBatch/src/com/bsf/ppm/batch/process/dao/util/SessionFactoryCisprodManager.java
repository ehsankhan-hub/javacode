package com.bsf.ppm.batch.process.dao.util;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import com.bsf.ppm.batch.process.exception.DAOException;

public class SessionFactoryCisprodManager {

	private static final Logger logger = Logger
			.getLogger(SessionFactoryCisprodManager.class);

	private static SessionFactory sessionFactory;

	private static Session session;

	@SuppressWarnings("deprecation")
	private static SessionFactory getSessionFactory() throws DAOException {
		if (sessionFactory == null) {
			try {
				return new AnnotationConfiguration().configure("/hibernateCisprod.cfg.xml").buildSessionFactory();
			} catch (Exception e) {
				logger.error(
						"Error occured in creating session factory. Error "
								+ e.getMessage(), e);
				throw new DAOException("Session Factory creation failed", e);
			}

		}
		return sessionFactory;
	}

	public static Session getSession() throws DAOException {
		if (session != null) {
			return session;
		} else {
			try {
				session = getSessionFactory().openSession();
				return session;
			} catch (HibernateException e) {
				logger.error(
						"Failed to create session. Error " + e.getMessage(), e);
				throw new DAOException("Failed to create session. Error "
						+ e.getMessage(), e);
			} catch (DAOException e) {
				logger.error(
						"Failed to create session. Error " + e.getMessage(), e);
				throw new DAOException("Failed to create session. Error "
						+ e.getMessage(), e);
			}
		}
	}
	
	public static Session getCurrentSession() throws DAOException {
		if (session != null) {
			return session;
		} else {
			try {
				session = getSessionFactory().openSession();
				return session;
			} catch (HibernateException e) {
				logger.error(
						"Failed to create session. Error " + e.getMessage(), e);
				throw new DAOException("Failed to create session. Error "
						+ e.getMessage(), e);
			} catch (DAOException e) {
				logger.error(
						"Failed to create session. Error " + e.getMessage(), e);
				throw new DAOException("Failed to create session. Error "
						+ e.getMessage(), e);
			}
		}
	}
	
	

	public boolean closeSession() throws DAOException {
		if (session != null) {
			session.close();
			return true;
		}
		return false;
	}
	
	

}
