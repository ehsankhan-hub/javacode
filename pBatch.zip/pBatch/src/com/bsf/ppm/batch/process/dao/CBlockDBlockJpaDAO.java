package com.bsf.ppm.batch.process.dao;

import org.hibernate.Query;
import org.hibernate.Session;

import com.bsf.ppm.batch.process.dao.generic.GenericJPADAO;
import com.bsf.ppm.batch.process.dao.util.SessionFactoryManager;
import com.bsf.ppm.batch.process.entity.CBlockDBlock;
import com.bsf.ppm.batch.process.exception.DAOException;

public class CBlockDBlockJpaDAO extends GenericJPADAO<CBlockDBlock, String>
		implements CBlockDBlockDAO {
	public CBlockDBlock  getCusCodeFromCblockDBlock(String namedQuery)throws DAOException {
		CBlockDBlock cblockDBlock=null;
		Session session = null;
		try {
			session = SessionFactoryManager.getSession();
			Query query = session.createQuery(namedQuery);
			String custCode=(String)query.uniqueResult();
			if(custCode!=null&&!custCode.equals("")){
				cblockDBlock=new CBlockDBlock();
				cblockDBlock.setCustCode(custCode);
			}
			else{
				return null;
			}
			return cblockDBlock;
		} catch (Exception e) {
			e.printStackTrace();
			//logger.error("Error in fetching record. Error " + e.getMessage(), e);
			throw new DAOException("DAO list fetching error.", e);
		}
		
	}
}
