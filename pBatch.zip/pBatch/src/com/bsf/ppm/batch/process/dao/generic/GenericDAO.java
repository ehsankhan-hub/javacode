package com.bsf.ppm.batch.process.dao.generic;

import java.io.Serializable;
import java.util.List;

import com.bsf.ppm.batch.process.entity.CBlockDBlock;
import com.bsf.ppm.batch.process.entity.ParameterValue;
import com.bsf.ppm.batch.process.exception.DAOException;



public interface GenericDAO<E, K extends Serializable> {

	List<E> fetchAllRecords() throws DAOException;
	public List fetchAllRecordListCISAccounts(String namedQuery) throws DAOException;

	List<E> fetchAllRecords(String namedQuery) throws DAOException;
	
	List fetchAllRecordList(String namedQuery) throws DAOException;
	
	public ParameterValue getPercent()throws DAOException;
	
	public List findByName(String namedQuery) throws DAOException;

	boolean save(E entity) throws DAOException;

	boolean saveBulk(List<E> entities, int batchSize) throws DAOException;
    
	
	boolean update(E entity) throws DAOException;

	boolean updateBulk(List<E> entities, int batchSize) throws DAOException;

	E findByID(K key) throws DAOException;
	
    public String getPPMReference() throws DAOException;
	
	public Long getInstDetaiSeqGen() throws DAOException;
		

}
