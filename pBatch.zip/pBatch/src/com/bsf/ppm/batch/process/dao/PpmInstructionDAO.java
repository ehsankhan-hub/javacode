package com.bsf.ppm.batch.process.dao;

import com.bsf.ppm.batch.process.dao.generic.GenericDAO;
import com.bsf.ppm.batch.process.entity.InstructionDetails;
import com.bsf.ppm.batch.process.entity.PpmDebitBlockStaging;
import com.bsf.ppm.batch.process.entity.Ppm_Instructions;
import com.bsf.ppm.batch.process.exception.DAOException;

public interface PpmInstructionDAO extends GenericDAO<Ppm_Instructions, String> {

	public Ppm_Instructions findInstructionSalaryPercent(Ppm_Instructions ppmInstruction)throws DAOException;			
	public boolean updateInstruction(Ppm_Instructions ppmInstruction)throws DAOException;
}
