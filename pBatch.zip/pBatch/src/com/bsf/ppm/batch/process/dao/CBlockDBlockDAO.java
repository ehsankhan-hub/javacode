package com.bsf.ppm.batch.process.dao;

import com.bsf.ppm.batch.process.dao.generic.GenericDAO;
import com.bsf.ppm.batch.process.entity.CBlockDBlock;
import com.bsf.ppm.batch.process.exception.DAOException;

public interface CBlockDBlockDAO extends GenericDAO<CBlockDBlock, String> {
	public CBlockDBlock  getCusCodeFromCblockDBlock(String namedQuery)throws DAOException;
}
