package com.bsf.macug.general.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;

@Controller
@RequestMapping("/systemParameter")
public class SystemParameterController {
	private static final Logger logger = Logger
			.getLogger(SystemParameterController.class.getName());

	@Autowired
	InterSystemParameterService systemParameterService;
	
	

	@RequestMapping(value = "/itemCodesByTableCode", method = RequestMethod.GET)
	public @ResponseBody String getItemCodesByTableCode(
			@RequestParam("tableCode") String tableCode) {
		JSONObject res = null;
		res = systemParameterService.getItemCodeList(tableCode);
		return res.toString();
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody String saveParameter(SystemParameters detailsObj,
			HttpServletRequest request) {
		Principal principal = request.getUserPrincipal();
		String userId = principal.getName();
		
		JSONObject res = null;
		try {
			res = systemParameterService
					.saveSystemParametersDetails(detailsObj,userId);
		} catch (Exception e) {
			logger.error("Error " + e.getMessage(), e);
			res = new JSONObject();
			res.put("message", "Property Creation Failed");
			res.put("status", "fail");
		}

		return res.toString();
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public @ResponseBody String updateParameter(SystemParameters detailsObj,
			HttpServletRequest request) {
		JSONObject res = null;
		Principal principal = request.getUserPrincipal();
		String userId = principal.getName();
		
		try {
			res = systemParameterService
					.updateSystemParametersDetails(detailsObj,userId);
		} catch (Exception e) {
			logger.error("Error " + e.getMessage(), e);
		}

		return res.toString();
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public @ResponseBody String customerDetailsList(HttpServletRequest request) {
		JSONObject res = null;
		int idisplaylength = Integer.parseInt(request
				.getParameter("iDisplayLength"));
		int displaystart = Integer.parseInt(request
				.getParameter("iDisplayStart"));
		String sSearch = request.getParameter("sSearch");
		String searchParam = request.getParameter("searchData");
		res = systemParameterService.getSystemParametersList(searchParam,
				sSearch, displaystart, idisplaylength);
		return res.toString();
	}

}
