package com.bsf.macug.general.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "MAC_SYSTEM_GEN_PARAMETERS")
public class SystemParameters implements Serializable {
	@Id
	@Column(name = "TABLE_CODE")
	private String tableCode;
	@Id
	@Column(name = "ITEM_CODE")
	private String itemCode;
	@Column(name = "ITEM_DESC_1")
	private String itemDescription1;
	@Column(name = "ITEM_DESC_2")
	private String itemDescription2;
	@Column(name = "ITEM_VAL_1")
	private BigDecimal itemValue1;
	@Column(name = "ITEM_VAL_2")
	private BigDecimal itemValue2;
	@Column(name = "CREATED_USER")
	private String createdUser;
	@Column(name = "CREATED_DATE")
	@Temporal(TemporalType.DATE)
	private Date createdDate;
	@Column(name = "MODIFIED_DATE")
	@Temporal(TemporalType.DATE)
	private Date modifiedDate;
	@Column(name = "MODIFIED_USER")
	private String modeifiedUser;

	public SystemParameters() {
	}

	public String getTableCode() {
		return tableCode;
	}

	public void setTableCode(String tableCode) {
		this.tableCode = tableCode;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemDescription1() {
		return itemDescription1;
	}

	public void setItemDescription1(String itemDescription1) {
		this.itemDescription1 = itemDescription1;
	}

	public String getItemDescription2() {
		return itemDescription2;
	}

	public void setItemDescription2(String itemDescription2) {
		this.itemDescription2 = itemDescription2;
	}

	public BigDecimal getItemValue1() {
		return itemValue1;
	}

	public void setItemValue1(BigDecimal itemValue1) {
		this.itemValue1 = itemValue1;
	}

	public BigDecimal getItemValue2() {
		return itemValue2;
	}

	public void setItemValue2(BigDecimal itemValue2) {
		this.itemValue2 = itemValue2;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModeifiedUser() {
		return modeifiedUser;
	}

	public void setModeifiedUser(String modeifiedUser) {
		this.modeifiedUser = modeifiedUser;
	}

}
