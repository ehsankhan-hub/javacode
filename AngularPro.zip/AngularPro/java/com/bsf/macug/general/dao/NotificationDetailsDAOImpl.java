package com.bsf.macug.general.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Restrictions;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.general.entity.NotificationDetails;

@Repository("notificationDetailsDAO")
public class NotificationDetailsDAOImpl implements InterNotificationDetailsDAO{

	private static final Logger logger = Logger
			.getLogger(NotificationDetailsDAOImpl.class.getName());

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public NotificationDetails getNotificationDetails(String notificationId)
			throws DataAccessException {
		NotificationDetails notification = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(NotificationDetails.class);
			criteria.add(Restrictions.eq("notificationId", notificationId));
			
			notification = (NotificationDetails) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
		}
		return notification;
	}

	@Override
	public List<NotificationDetails> getNotificationDetailsList(
			String searchParam, String sSearch, int displaystart,
			int idisplaylength) throws DataAccessException {
		List<NotificationDetails> notificationList = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = getSearchCriteria(searchParam, sSearch);
			
			criteria.setFirstResult(displaystart);
			criteria.setMaxResults(idisplaylength);
			
			notificationList = criteria.list();
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
		}
		
		return notificationList;
	}

	@Override
	public boolean saveNotificationDetails(NotificationDetails details)
			throws DataAccessException {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(details);
			status = true;
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
		}
		return status;
	}

	@Override
	public boolean updateNotificationDetails(NotificationDetails details)
			throws DataAccessException {
		boolean status = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			session.update(details);
			status = true;
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
		}
		return status;
	}

	private Criteria getSearchCriteria(String searchParam, String sSearch)
			throws DataAccessException {
		Criteria criteria = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			criteria = session.createCriteria(NotificationDetails.class);
			JSONParser parser = new JSONParser();
			String notificationId = null;
			String customerId = null;
			String fileId = null;
			if (!StringUtils.isEmpty(searchParam)) {
				JSONObject searchObject = (JSONObject) parser
						.parse(searchParam);
				notificationId = (String) searchObject.get("notificationId");
				customerId = (String) searchObject.get("customerId");
				fileId = (String) searchObject.get("fileId");
			}
			if (!StringUtils.isEmpty(notificationId)) {
				criteria.add(Restrictions.eq("notificationId", notificationId));
			}
			if (!StringUtils.isEmpty(customerId)) {
				criteria.add(Restrictions.eq("customerId", customerId));
			}
			
			if (!StringUtils.isEmpty(fileId)) {
				criteria.add(Restrictions.eq("fileId", fileId));
			}
			
			if (sSearch != null && !sSearch.isEmpty()) {
				Disjunction or = Restrictions.disjunction();
				or.add(Restrictions.like("fileId", sSearch + "%")
						.ignoreCase());
				criteria.add(or);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new DataAccessException("Error while creating criteria.");
		}
		return criteria;
	}

	@Override
	public List<NotificationDetails> getNotificationDetailsListByStatus(
			String status){
		List<NotificationDetails> notificationList = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(NotificationDetails.class);
			
			criteria.add(Restrictions.eq("status", status));
			notificationList = criteria.list();
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
		}
		
		return notificationList;
	}
}
