package com.bsf.macug.general.service;

import java.math.BigDecimal;
import java.util.Map;

import org.json.simple.JSONObject;

import com.bsf.macug.exception.SystemPropertyNotConfigurationException;
import com.bsf.macug.general.entity.SystemParameters;

public interface InterSystemParameterService {
	SystemParameters getSystemParameters(String tableCode, String itemCode);

	Map<String, SystemParameters> getSystemParametersByTableCode(String tableCode)
			throws SystemPropertyNotConfigurationException;

	String getSystemParametersDescription1(String itemCode, Map<String, SystemParameters> map);

	String getSystemParametersDescription2(String itemCode, Map<String, SystemParameters> map);

	JSONObject getItemCodeList(String tableCode);

	public JSONObject getSystemParametersList(String searchParam, String sSearch, int displaystart, int idisplaylength);

	BigDecimal getSystemParametersValue1(String strItemCode, Map<String, SystemParameters> map);

	BigDecimal getSystemParametersValue2(String strItemCode, Map<String, SystemParameters> map);

	JSONObject saveSystemParametersDetails(SystemParameters detailsObj, String userId);

	JSONObject updateSystemParametersDetails(SystemParameters detailsObj, String userId);

}
