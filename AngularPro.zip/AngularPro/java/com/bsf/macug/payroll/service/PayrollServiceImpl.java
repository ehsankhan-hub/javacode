package com.bsf.macug.payroll.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.macug.payroll.dao.InterPayrollDAO;
import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;

@Service
@Transactional
public class PayrollServiceImpl implements InterPayrollService {

	private static final Logger logger = Logger.getLogger(PayrollServiceImpl.class.getName());

	@Autowired
	InterPayrollDAO payrollDao;

	@Override
	public MacPayrollHeader getHeader(String customerId, String fileId) {
		MacPayrollHeader header = null;
		try {
			header = payrollDao.getHeader(customerId, fileId);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return header;
	}

	@Override
	public MacPayrollDetail getDetail(String customerId, String fileId, String transactionId) {
		MacPayrollDetail detail = null;
		try {
			detail = payrollDao.getDetail(customerId, fileId, transactionId);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detail;
	}
	
	@Override
	public JSONArray findAllHeader(String customerId, String fileId, String status, String pageNumber,
			String pageSize) {
		JSONArray result = new JSONArray();
		try {
			List<MacPayrollHeader> list = payrollDao.findAllHeader(customerId, fileId, status, pageNumber, pageSize);
			for (MacPayrollHeader payrollHeader : list) {
				JSONObject obj = new JSONObject();
				obj.put("customerId", payrollHeader.getClientId());
				obj.put("fileId", payrollHeader.getFileId());
				obj.put("status", payrollHeader.getStatus());
				obj.put("description", payrollHeader.getDescription());
				result.add(obj);
			}
		} catch (Exception e) {
			logger.error("Error "+e.getMessage(), e);
		}
		return result;
	}

	@Override
	public JSONArray findAllDetails(String customerId, String fileId, String transactionReference, String status,
			String pageNumber, String pageSize) {
		JSONArray result = new JSONArray();
		try {
			List<MacPayrollDetail> list = payrollDao.findAllDetail(customerId, fileId, transactionReference, status, pageNumber, pageSize);
			for (MacPayrollDetail payrollDetails : list) {
				JSONObject obj = new JSONObject();
				obj.put("customerId", payrollDetails.getClientId());
				obj.put("fileId", payrollDetails.getFileId());
				obj.put("transactionReference", payrollDetails.getTransRef());
				obj.put("status", payrollDetails.getStatus());
				obj.put("description", payrollDetails.getStatusDesc());
				result.add(obj);
			}
		} catch (Exception e) {
			logger.error("Error "+e.getMessage(), e);
		}
		return result;
	}

	@Override
	public JSONObject getDetails(String customerId, String fileId, String tranId) {
		JSONObject obj = new JSONObject();
		try {
			MacPayrollDetail detailObj = payrollDao.getDetail(customerId, fileId, tranId);
			obj.put("customerId", detailObj.getClientId());
			obj.put("fileId", detailObj.getFileId());
			obj.put("transactionReference", detailObj.getTransRef());
			obj.put("status", detailObj.getStatus());
			obj.put("description", detailObj.getStatusDesc());
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return obj;
	}

}
