package com.bsf.macug.payroll.service;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;

public interface InterPayrollService {

	MacPayrollHeader getHeader(String customerId, String fileId);

	MacPayrollDetail getDetail(String customerId, String fileId, String transactionId);

	public JSONArray findAllHeader(String customerId, String fileId, String status, String pageNumber, String pageSize);

	public JSONArray findAllDetails(String customerId, String fileId, String transactionReference, String status,
			String pageNumber, String pageSize);

	JSONObject getDetails(String customerId, String fileId, String tranId);

}
