package com.bsf.macug.payroll.dao;

import java.util.List;

import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;

public interface InterPayrollDAO {

	MacPayrollHeader getHeader(String customerId, String fileId);

	MacPayrollDetail getDetail(String customerId, String fileId, String transactionId);

	List<MacPayrollDetail> findAllDetail(String customerId, String fileId, String transactionRef, String status,
			String pageNumber, String pageSize);

	List<MacPayrollHeader> findAllHeader(String customerId, String fileId, String status, String pageNumber,
			String pageSize);

}
