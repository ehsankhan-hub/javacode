package com.bsf.macug.payroll.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.bsf.macug.payroll.entity.MacPayrollDetail;
import com.bsf.macug.payroll.entity.MacPayrollHeader;

@Repository
public class PayrollDAOImpl implements InterPayrollDAO {

	private static final Logger logger = Logger.getLogger(PayrollDAOImpl.class.getName());

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public MacPayrollHeader getHeader(String customerId, String fileId) {
		MacPayrollHeader header = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPayrollHeader.class);
			criteria.add(Restrictions.eq("clientId", customerId));
			criteria.add(Restrictions.eq("fileId", fileId));
			header = (MacPayrollHeader) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return header;
	}

	@Override
	public MacPayrollDetail getDetail(String customerId, String fileId, String transRef) {
		MacPayrollDetail detail = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPayrollDetail.class);
			criteria.add(Restrictions.eq("clientId", customerId));
			criteria.add(Restrictions.eq("fileId", fileId));
			criteria.add(Restrictions.eq("transRef", transRef));
			detail = (MacPayrollDetail) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detail;
	}

	@Override
	public List<MacPayrollHeader> findAllHeader(String customerId, String fileId, String status, String pageNumber, String pageSize) {
		List<MacPayrollHeader> headerList = null;
		try {
			logger.info("************findAllHeader STARTED");
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPayrollHeader.class);
			criteria.setFirstResult(Integer.parseInt(pageNumber) * Integer.parseInt(pageSize));
			criteria.setMaxResults(Integer.parseInt(pageSize));
			if (!StringUtils.isEmpty(customerId)) {
				criteria.add(Restrictions.like("clientId", customerId + "%").ignoreCase());
			}
			if (!StringUtils.isEmpty(status)) {
				criteria.add(Restrictions.eq("status", status));
			}
			if (!StringUtils.isEmpty(fileId)) {
				criteria.add(Restrictions.eq("fileId", fileId));
			}
			criteria.addOrder(Order.asc("clientId"));
			headerList = criteria.list();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		logger.info("******** findAllHeader STARTED END");
		return headerList;
	}

	@Override
	public List<MacPayrollDetail> findAllDetail(String customerId, String fileId,String transactionRef,  String status, String pageNumber,
			String pageSize) {
		List<MacPayrollDetail> headerList = null;
		try {
			logger.info("************findAllHeader STARTED");
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPayrollDetail.class);
			criteria.setFirstResult(Integer.parseInt(pageNumber) * Integer.parseInt(pageSize));
			criteria.setMaxResults(Integer.parseInt(pageSize));
			if (!StringUtils.isEmpty(customerId)) {
				criteria.add(Restrictions.like("clientId", customerId + "%").ignoreCase());
			}
			if (!StringUtils.isEmpty(status)) {
				criteria.add(Restrictions.eq("status", status));
			}
			if (!StringUtils.isEmpty(fileId)) {
				criteria.add(Restrictions.eq("fileId", fileId));
			}
			if (!StringUtils.isEmpty(transactionRef)) {
				criteria.add(Restrictions.eq("transactionReference", transactionRef));
			}
			criteria.addOrder(Order.asc("clientId"));
			headerList = criteria.list();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		logger.info("******** findAllHeader STARTED END");
		return headerList;
	}

}
