package com.bsf.macug.customer.dao;

import java.util.List;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.exception.DataAccessException;

public interface InterCustomerDetailsDAO {
	CustomerDetails getCustomerDetails(String clientId, String status)
			throws CustomerNotFoundException;

	boolean updateCustomerDetails(CustomerDetails details)
			throws DataAccessException;

	List<CustomerDetails> findAll(String customerId, String status,String pageNumber, String pageSize, String sortOrder);

	boolean saveCustomerDetails(CustomerDetails customerEntity); 
}
