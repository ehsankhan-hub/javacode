package com.bsf.macug.customer.dao;

import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.exception.DataAccessException;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

@Repository("customerAccountsDao")
public class CustomerAccountsDAOImpl implements InterCustomerAccountsDAO {
	private final Logger logger = Logger.getLogger(CustomerAccountsDAOImpl.class.getName());

	@Autowired
	private SessionFactory sessionFactory;

	public CustomerAccounts getCustomerAccountDetails(String customerId, String accountNumber, String accountService)
			throws DataAccessException {
		CustomerAccounts client = null;
		Session session = null;
		if ((!StringUtils.isEmpty(customerId)) || (!StringUtils.isEmpty(accountNumber))
				|| (!StringUtils.isEmpty(accountService))) {
			try {
				session = sessionFactory.getCurrentSession();
				Criteria criteria = session.createCriteria(CustomerAccounts.class);
				criteria.add(Restrictions.eq("customerId", customerId));
				criteria.add(Restrictions.eq("accountNumber", accountNumber));
				criteria.add(Restrictions.eq("accountService", accountService));
				criteria.add(Restrictions.eq("accountStatus", "ACTIVE"));
				client = (CustomerAccounts) criteria.uniqueResult();
			} catch (Exception e) {
				logger.error("(getCustomerAccountDetails)==> Error in getting customer " + e.getMessage(), e);
				throw new DataAccessException("Invalid customer");
			}
		} else {
			logger.info("(getCustomerAccountDetails)==> Search information is null or empty");
		}

		return client;
	}

	public List<CustomerAccounts> listAllAccounts(String strCustomer, String strStatus, String strAccount,
			String strType, Integer iStart, Integer iMax) throws DataAccessException {
		List<CustomerAccounts> lstAccount = null;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(CustomerAccounts.class);
			if (!StringUtils.isEmpty(strCustomer))
				criteria.add(Restrictions.like("customerId", strCustomer + "%").ignoreCase());
			if (!StringUtils.isEmpty(strStatus))
				criteria.add(Restrictions.eq("accountStatus", strStatus));
			if (!StringUtils.isEmpty(strAccount))
				criteria.add(Restrictions.eq("accountNumber", strAccount));
			if (!StringUtils.isEmpty(strType))
				criteria.add(Restrictions.eq("accountService", strType));
			criteria.addOrder(Order.asc("sequenceNumber"));
			criteria.setFirstResult(iStart * iMax);
			criteria.setMaxResults(iMax);
			lstAccount = criteria.list();
		} catch (Exception e) {
			logger.error("(getCustomerAccountDetails)==> Error in getting customer " + e.getMessage(), e);
			throw new DataAccessException("Invalid customer");
		}
		return lstAccount;
	}

	public Integer getSequenceByAccount(String companyCode, String strAccount) throws DataAccessException {
		Session session = null;
		Integer result = null;
		if ((!StringUtils.isEmpty(companyCode)) || (StringUtils.isEmpty(strAccount))) {
			try {
				session = sessionFactory.getCurrentSession();
				Criteria criteria = session.createCriteria(CustomerAccounts.class);
				criteria.add(Restrictions.eq("customerId", companyCode));
				criteria.add(Restrictions.eq("accountNumber", strAccount));
				criteria.add(Restrictions.eq("accountService", "STATEMENT"));

				CustomerAccounts cust = (CustomerAccounts) criteria.uniqueResult();
				result = cust.getSequenceNumber();
			} catch (Exception e) {
				logger.error("(getSequenceByAccount)==> Error in getting Sequence of account number :" + strAccount
						+ " companyCode : " + companyCode + " " + e.getMessage(), e);
				throw new DataAccessException("Invalid customer");
			}
		} else {
			logger.info("(getSequenceByAccount)==>  information is null or empty");
		}

		return result;
	}

	@Override
	public CustomerAccounts findCustomerAccount(String customer, String account, String accountType)
			throws DataAccessException {
		CustomerAccounts customerAccount = null;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(CustomerAccounts.class);
			criteria.add(Restrictions.eq("customerId", customer));
			criteria.add(Restrictions.eq("accountNumber", account));
			criteria.add(Restrictions.eq("accountService", accountType));
			customerAccount = (CustomerAccounts) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error in finding the account number. Error " + e.getMessage(), e);
			throw new DataAccessException("Error in finding the account. Error " + e.getMessage());
		}
		return customerAccount;
	}

	@Override
	public boolean updateCustomerAccount(CustomerAccounts customerAccount) throws DataAccessException {
		boolean blStatus = false;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			session.update(customerAccount);
			blStatus = true;
		} catch (Exception e) {
			logger.error("Error in finding the account number. Error " + e.getMessage(), e);
			throw new DataAccessException("Error in finding the account. Error " + e.getMessage());
		}
		return blStatus;
	}

	@Override
	public boolean deleteCustomerAccount(CustomerAccounts customerAccount) throws DataAccessException {
		boolean blStatus = false;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			session.delete(customerAccount);
			blStatus = true;
		} catch (Exception e) {
			logger.error("Error in finding the account number. Error " + e.getMessage(), e);
			throw new DataAccessException("Error in finding the account. Error " + e.getMessage());
		}
		return blStatus;
	}

	@Override
	public boolean saveCustomerAccount(CustomerAccounts customerAccount) throws DataAccessException {
		boolean blStatus = false;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			session.save(customerAccount);
			blStatus = true;
		} catch (Exception e) {
			logger.error("Error in finding the account number. Error " + e.getMessage(), e);
			throw new DataAccessException("Error in finding the account. Error " + e.getMessage());
		}
		return blStatus;
	}

}