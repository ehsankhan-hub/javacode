package com.bsf.macug.customer.dao;

import java.util.List;

import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.exception.DataAccessException;

public interface InterCustomerAccountsDAO {

	CustomerAccounts getCustomerAccountDetails(String clientId, String accountNumber, String accountService)
			throws DataAccessException;

	List<CustomerAccounts> listAllAccounts(String strCustomer, String strStatus, String strAccount, String strType,
			Integer iStart, Integer iMax) throws DataAccessException;

	Integer getSequenceByAccount(String companyCode, String strAccount) throws DataAccessException;

	CustomerAccounts findCustomerAccount(String customer, String account, String accountType) throws DataAccessException;

	boolean updateCustomerAccount(CustomerAccounts customerAccount) throws DataAccessException;

	boolean deleteCustomerAccount(CustomerAccounts customerAccount) throws DataAccessException;

	boolean saveCustomerAccount(CustomerAccounts customerAccount) throws DataAccessException;

}
