package com.bsf.macug.customer.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bsf.macug.customer.dto.AccountDTO;
import com.bsf.macug.customer.service.InterCustomerAccountsService;

@RestController
@RequestMapping("/accounts")
public class CustomerAccountsController {

	private static final Logger logger = Logger.getLogger(CustomerAccountsController.class);

	@Autowired
	InterCustomerAccountsService accountService;

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(@RequestParam("customerId") String customerId, @RequestParam("status") String status,
			@RequestParam("accountnumber") String account, @RequestParam("accounttype") String accountType,
			@RequestParam("pageNumber") String pageNumber, @RequestParam("pageSize") String pageSize,
			HttpServletRequest request) {
		JSONArray jsArrAccounts = null;
		Integer iPageStart = 0;
		Integer iPageMax = 0;
		try {
			iPageStart = Integer.parseInt(pageNumber);
			iPageMax = Integer.parseInt(pageSize);
			jsArrAccounts = accountService.listAllAccounts(customerId, status, account, accountType, iPageStart,
					iPageMax);
		} catch (Exception e) {
			jsArrAccounts = new JSONArray();
			logger.error("Error in fetching account list " + e.getMessage(), e);
		}
		return jsArrAccounts.toString();
	}

	@RequestMapping(value = "/totalCount", method = RequestMethod.GET)
	public String totalCount(@RequestParam("customerId") String customerId, @RequestParam("status") String status,
			@RequestParam("accountnumber") String account, @RequestParam("accounttype") String accountType,
			HttpServletRequest request) {
		JSONObject dto = null;
		try {
			Principal principal = request.getUserPrincipal();
			String userId = principal.getName();
			dto = accountService.fetchAccountCount(customerId, status, account, accountType);

		} catch (Exception e) {
			logger.error("Error in fetching total count of accounts: " + e.getMessage(), e);
			dto = new JSONObject();
			dto.put("count", 0);
		}
		return dto.toString();
	}

	@RequestMapping(value = "/findAccount/{customerId}/{accountNumber}/{accountType}", method = RequestMethod.GET)
	public String findAccountNumber(@PathVariable("customerId") String customerId,
			@PathVariable("accountNumber") String account, @PathVariable("accountType") String accountType,
			HttpServletRequest request) {
		JSONObject jsAccount = null;
		try {
			jsAccount = accountService.findAccount(customerId, account, accountType);
		} catch (Exception e) {
			logger.error("Error in fetching account number. Error " + e.getMessage(), e);
			jsAccount = new JSONObject();
			jsAccount.put("status", false);
		}
		return jsAccount.toString();
	}

	@RequestMapping(value = "/updateAccount", method = RequestMethod.POST)
	public String updateAccount(@RequestBody AccountDTO accountsDTO, HttpServletRequest request) {
		JSONObject jsResponse = null;
		try {
			Principal principal = request.getUserPrincipal();
			String userId = principal.getName();
			jsResponse = accountService.updateAccount(accountsDTO, userId);
		} catch (Exception e) {
			logger.error("Error in updating account number. Error " + e.getMessage(), e);
			jsResponse = new JSONObject();
			jsResponse.put("status", false);
		}
		return jsResponse.toString();
	}

	@RequestMapping(value = "/createAccount", method = RequestMethod.POST)
	public String addAccount(@RequestBody AccountDTO accountsDTO, HttpServletRequest request) {
		JSONObject jsResponse = null;
		try {
			Principal principal = request.getUserPrincipal();
			String userId = principal.getName();
			jsResponse = accountService.saveAccount(accountsDTO, userId);
		} catch (Exception e) {
			logger.error("Error in updating account number. Error " + e.getMessage(), e);
			jsResponse = new JSONObject();
			jsResponse.put("status", false);
		}
		return jsResponse.toString();
	}

	@RequestMapping(value = "/validateAccount", method = RequestMethod.GET)
	public String validateAccount(@RequestParam("accountNumber") String accountNumber) {
		return accountService.checkAccountBalance(accountNumber).toString();
	}
}
