package com.bsf.macug.customer.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bsf.macug.customer.dto.CustomerDetailsDTO;
import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.service.InterCustomerDetailsService;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	private static final Logger logger = Logger.getLogger(CustomerController.class.getName());
	
	@Autowired
	InterCustomerDetailsService customerDetailsService;
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(HttpServletRequest request,@RequestParam("pageNumber") String pageNumber,
			@RequestParam("status") String status,
			@RequestParam("customerId") String customerId,
			@RequestParam("pageSize") String pageSize) {
		JSONArray dto = null;
		try {
			Principal principal = request.getUserPrincipal();
			String userId = principal.getName();
			String sortOrder = request.getParameter("sortOrder");
			
			dto = customerDetailsService.findAll(customerId,status, pageNumber,pageSize,sortOrder);
			
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return dto.toString();
	}
	
	@RequestMapping(value = "/totalCount", method = RequestMethod.GET)
	public String totalCount(HttpServletRequest request) {
		JSONObject dto = null;
		try {
			Principal principal = request.getUserPrincipal();
			String userId = principal.getName();
			String sortOrder = request.getParameter("sortOrder");
			
			dto = customerDetailsService.countAll();
			
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return dto.toString();
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public String get(HttpServletRequest request,@PathVariable("id") String id) {
		JSONObject dto = null;
		try {
			Principal principal = request.getUserPrincipal();
			String userId = principal.getName();
			String sortOrder = request.getParameter("sortOrder");
			
			dto = customerDetailsService.get(id);
			
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return dto.toString();
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String HttpServletRequest(HttpServletRequest request,@RequestBody CustomerDetailsDTO customer) {
		JSONObject dto = null;
		try {
			Principal principal = request.getUserPrincipal();
			String userId = principal.getName();
			dto = customerDetailsService.updateCustomer(customer,userId);
			
			
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return dto.toString();
	}
	
	@RequestMapping(value = "save", method = RequestMethod.POST)
	public String save(HttpServletRequest request,@RequestBody CustomerDetailsDTO customer) {
		JSONObject dto = null;
		try {
			Principal principal = request.getUserPrincipal();
			String userId = principal.getName();
			dto = customerDetailsService.saveCustomer(customer,userId);
			
			
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return dto.toString();
	}
	
	@RequestMapping(value = "/statusUpdate", method = RequestMethod.GET)
	public String statusUpdate(HttpServletRequest request,@RequestParam("status") String status,
			@RequestParam("customerId") String customerId) {
		JSONObject dto = null;
		try {
			Principal principal = request.getUserPrincipal();
			String userId = principal.getName();
			
			dto = customerDetailsService.statusUpdate(customerId,status,userId);
			
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return dto.toString();
	}
	
	@RequestMapping(value = "/custemerIdNameList", method = RequestMethod.GET)
	public String getCustemerIdName(HttpServletRequest request) {
		JSONObject res = null;
		res = customerDetailsService.getClientIdNameList();
		return res.toString();
	}
}
