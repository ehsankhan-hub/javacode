package com.bsf.macug.customer.service;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.bsf.macug.customer.dto.CustomerDetailsDTO;
import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.exception.CustomerNotFoundException;

public interface InterCustomerDetailsService {
	CustomerDetails getCustomerDetails(String clientId) throws CustomerNotFoundException;

	JSONArray findAll( String customerId, String status,String pageNumber, String pageSize, String sortOrder);

	JSONObject countAll();

	JSONObject get(String id);

	JSONObject updateCustomer(CustomerDetailsDTO customerDetails, String userId);

	JSONObject statusUpdate(String customerId, String status, String userId);

	JSONObject saveCustomer(CustomerDetailsDTO customer, String userId);

	JSONObject getClientIdNameList();
}
