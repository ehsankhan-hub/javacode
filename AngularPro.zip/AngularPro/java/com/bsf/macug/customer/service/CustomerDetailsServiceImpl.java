package com.bsf.macug.customer.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.dao.InterCustomerDetailsDAO;
import com.bsf.macug.customer.dto.CustomerDetailsDTO;
import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.exception.CustomerNotFoundException;
import com.bsf.macug.exception.SystemPropertyNotConfigurationException;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;

@Service("customerDetailsService")
@Transactional
public class CustomerDetailsServiceImpl implements InterCustomerDetailsService {

	private static final Logger logger = Logger.getLogger(CustomerDetailsServiceImpl.class.getName());

	@Autowired
	InterCustomerDetailsDAO customerDetailsDao;

	@Autowired
	InterSystemParameterService systemParameterService;

	@Override
	public CustomerDetails getCustomerDetails(String clientId) throws CustomerNotFoundException {
		CustomerDetails customerDetails = null;
		if (!StringUtils.isEmpty(clientId)) {
			Map<String, SystemParameters> mpCustomerCode = null;
			String strCustStatus = "ACTIVE";
			try {
				try {
					mpCustomerCode = systemParameterService.getSystemParametersByTableCode("CUSSTSCOD");
				} catch (SystemPropertyNotConfigurationException e) {
					logger.error("(getCustomerDetails)==> CUSSTSCOD table is not configured");
					throw new CustomerNotFoundException("Customer is not registered or invalid");
				}
				if (mpCustomerCode != null) {
					strCustStatus = systemParameterService.getSystemParametersDescription1("ACTIVE", mpCustomerCode);
				}
				strCustStatus = (StringUtils.isEmpty(strCustStatus)) ? "ACTIVE" : strCustStatus;
				customerDetails = customerDetailsDao.getCustomerDetails(clientId, strCustStatus);
			} catch (CustomerNotFoundException e) {
				logger.error("(getCustomerDetails)==> Customer not found. Error occured " + e.getMessage(), e);
				throw new CustomerNotFoundException("Customer is not registered or invalid");
			}
		} else {
			logger.info("(getCustomerDetails)==> Customer details cannot be null or empty. Customer is " + clientId);
			throw new CustomerNotFoundException("Customer is not registered or invalid");
		}
		return customerDetails;
	}

	@Override
	public JSONObject updateCustomer(CustomerDetailsDTO customerDetails, String userId) {
		boolean status = false;
		String message = "Update failed.";
		try {
			String id = customerDetails.getCustomerId();
			CustomerDetails customerEntity = customerDetailsDao.getCustomerDetails(id, null);
			BeanUtils.copyProperties(customerDetails, customerEntity);
			customerEntity.setModifiedDate(new Date());
			customerEntity.setModifiedId(userId);
			status = customerDetailsDao.updateCustomerDetails(customerEntity);
			if (status)
				message = "Successfully updated.";
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		JSONObject result = new JSONObject();
		result.put("status", status);
		result.put("message", message);
		return result;
	}

	@Override
	public JSONArray findAll(String customerId, String status, String pageNumber, String pageSize, String sortOrder) {
		JSONArray result = new JSONArray();
		List<CustomerDetails> listDetails = customerDetailsDao.findAll(customerId, status, pageNumber, pageSize,
				sortOrder);
		for (CustomerDetails obj : listDetails) {
			JSONObject res = new JSONObject();
			res.put("id", obj.getCustomerId());
			res.put("payrollId", obj.getPayrollId());
			res.put("customerStatus", obj.getCustomerStatus());
			result.add(res);
		}
		return result;
	}

	@Override
	public JSONObject countAll() {
		List<CustomerDetails> listDetails = customerDetailsDao.findAll("", "", "0", "-1", null);
		JSONObject res = new JSONObject();
		res.put("count", listDetails.size());
		return res;
	}

	@Override
	public JSONObject get(String id) {
		JSONObject result = new JSONObject();
		if (!StringUtils.isEmpty(id)) {
			try {

				CustomerDetails customerDetails = null;
				customerDetails = customerDetailsDao.getCustomerDetails(id, null);

				if (customerDetails != null) {
					result.put("customerId", customerDetails.getCustomerId());
					result.put("customerName", customerDetails.getCustomerName());
					result.put("customerCategory", customerDetails.getCustomerCategory());
					result.put("customerValueDateFlag", customerDetails.getCustomerValueDateFlag());
					result.put("customerMolId", customerDetails.getCustomerMolId());
					result.put("customerPerson", customerDetails.getCustomerPerson());
					result.put("customerAddress", customerDetails.getCustomerAddress());
					result.put("customerCountryCode", customerDetails.getCustomerCountryCode());
					result.put("customerZipCode", customerDetails.getCustomerZipCode());
					result.put("customerEmail", customerDetails.getCustomerEmail());
					result.put("customerPhone", customerDetails.getCustomerPhone());
					result.put("customerMobile", customerDetails.getCustomerMobile());
					result.put("customerStatus", customerDetails.getCustomerStatus());
					result.put("wpsFlag", customerDetails.getWpsFlag());
					result.put("tag20ReplyFlag", customerDetails.getTag20ReplyFlag());
					result.put("payrollId", customerDetails.getPayrollId());
					result.put("mt940ArabicFlag", customerDetails.getMt940ArabicFlag());
					result.put("payrollBalanceCheckFlag", customerDetails.getPayrollBalanceCheckFlag());
					result.put("paymentSeries", customerDetails.getPaymentSeries());
				}

			} catch (CustomerNotFoundException e) {
				logger.error("(getCustomerDetails)==> Customer not found. Error occured " + e.getMessage(), e);
			}
		} else {
			logger.info("(getCustomerDetails)==> Customer details cannot be null or empty. Customer is " + id);
		}
		return result;
	}

	@Override
	public JSONObject statusUpdate(String customerId, String status, String userId) {
		JSONObject result = new JSONObject();
		String message = "Update failed.";
		try {
			CustomerDetails customerDet = customerDetailsDao.getCustomerDetails(customerId, null);
			customerDet.setCustomerStatus(status);
			customerDet.setModifiedId(userId);
			customerDet.setModifiedDate(new Date());
			boolean statusT = customerDetailsDao.updateCustomerDetails(customerDet);
			result.put("status", statusT);
			if (statusT) {
				message = "Customer successfuly updated.";
			}
		} catch (Exception e) {
			logger.error("Error occured " + e.getMessage(), e);
			message = "Update failed.";
		}
		result.put("message", message);
		return result;
	}

	@Override
	public JSONObject saveCustomer(CustomerDetailsDTO customer, String userId) {
		boolean status = false;
		String message = "Creaetion failed.";
		try {
			CustomerDetails customerEntity = new CustomerDetails();
			BeanUtils.copyProperties(customer, customerEntity);
			customerEntity.setModifiedDate(new Date());
			customerEntity.setModifiedId(userId);
			customerEntity.setCustomerCraetedDate(new Date());
			customerEntity.setCustomerCraetedId(userId);
			customerEntity.setCustomerStatus("ACTIVE");
			status = customerDetailsDao.saveCustomerDetails(customerEntity);
			if (status)
				message = "Successfully craeted.";
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		JSONObject result = new JSONObject();
		result.put("status", status);
		result.put("message", message);
		return result;
	}

	@Override
	public JSONObject getClientIdNameList() {
		JSONObject result = new JSONObject();
		List<CustomerDetails> resultList = null;
		JSONArray resultArray = new JSONArray();
		try {
			resultList = customerDetailsDao.findAll(null, null, "0", "-1", null);
			if (resultList != null) {
				for (CustomerDetails entity : resultList) {
					JSONObject resultObj = new JSONObject();
					resultObj.put("id", entity.getCustomerId());
					resultObj.put("name", entity.getCustomerName());
					resultArray.add(resultObj);
				}
			}
			result.put("data", resultArray);
			result.put("status", "success");
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			result.put("data", resultArray);
			result.put("status", "fail");
		}
		return result;
	}

}
