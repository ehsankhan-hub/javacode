package com.bsf.macug.customer.service;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.bsf.macug.customer.dto.AccountDTO;
import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.exception.AccountsNotFoundException;
import com.bsf.macug.exception.ProcessException;

public interface InterCustomerAccountsService {
	CustomerAccounts getCustomerAccountDetails(String clientId, String accountNumber, String accountService)
			throws ProcessException;

	JSONArray listAllAccounts(String strCustomer, String strStatus, String strAccount, String strType,
			Integer iPageStart, Integer iPageMax) throws AccountsNotFoundException;

	Integer getSequenceByAccount(String companyCode, String strAccount);

	JSONObject fetchAccountCount(String strCustomer, String strStatus, String strAccount, String strType);

	JSONObject findAccount(String strCustomer, String accountNumber, String accountType);

	JSONObject updateAccount(AccountDTO accountNumberDTO, String userID);

	JSONObject deleteAccount(String strCustomer, String accountNumber, String accountType, String userID);

	JSONObject saveAccount(AccountDTO accountNumberDTO, String userID);

	String checkAccountBalance(String accountNumber);
}
