package com.bsf.macug.customer.service;

import java.util.Date;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.customer.entity.CustomerLimits;

public interface InterCustomerLimitsService {
	boolean insertData(CustomerDetails customerDetails, Date valueDate);

	boolean updateData(CustomerLimits limits);

	CustomerLimits getData(String customerId, Date valueDate);

	CustomerLimits getData(String customerId, Date valueDate, String account);

	boolean insertData(CustomerDetails customerDetails, Date valueDate, String debitAccount);
}
