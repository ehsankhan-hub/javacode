package com.bsf.macug.customer.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.bsf.macug.customer.dao.InterCustomerAccountsDAO;
import com.bsf.macug.customer.dto.AccountDTO;
import com.bsf.macug.customer.entity.CustomerAccounts;
import com.bsf.macug.exception.AccountsNotFoundException;
import com.bsf.macug.exception.DataAccessException;
import com.bsf.macug.exception.ProcessException;
import com.bsf.macug.general.dao.InterSystemParametersDAO;
import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.util.IConstants.RATE_INDICATOR;

@Service("customerAccountsService")
@Transactional
public class CustomerAccountsServiceImpl implements InterCustomerAccountsService {

	private final Logger logger = Logger.getLogger(CustomerAccountsServiceImpl.class.getName());

	@Autowired
	InterCustomerAccountsDAO customerAccountsDao;
	
	@Autowired
	InterSystemParametersDAO systemParametersDAO;
	
	@Autowired
	InterSystemParameterService systemParameterService;

	@Override
	public CustomerAccounts getCustomerAccountDetails(String clientId, String accountNumber, String accountService)
			throws ProcessException {
		CustomerAccounts customerAccount = null;
		logger.info("(getCustomerAccountDetails)==> Trying to find customer account : " + clientId + " : "
				+ accountNumber + " : " + accountService);
		if (!(StringUtils.isEmpty(clientId) && StringUtils.isEmpty(accountNumber)
				&& StringUtils.isEmpty(accountService))) {
			try {
				customerAccount = customerAccountsDao.getCustomerAccountDetails(clientId, accountNumber,
						accountService);
			} catch (DataAccessException de) {
				logger.error("Error in fetching customer account details . Error " + de.getMessage(), de);
				throw new ProcessException("Cannot found account for service ");
			}
		} else {
			logger.info("(getCustomerAccountDetails)==> Account search information is null or empty");
		}
		return customerAccount;
	}

	@Override
	public JSONArray listAllAccounts(String strCustomer, String strStatus, String strAccount, String strType,
			Integer iPageStart, Integer iPageMax) throws AccountsNotFoundException {
		JSONArray jsArrAccounts = null;
		List<CustomerAccounts> lstAccounts = null;

		try {
			lstAccounts = customerAccountsDao.listAllAccounts(strCustomer, strStatus, strAccount, strType, iPageStart,
					iPageMax);
			jsArrAccounts = new JSONArray();
			for (CustomerAccounts customerAccounts : lstAccounts) {
				JSONObject jsAccount = new JSONObject();
				jsAccount.put("customerId", customerAccounts.getCustomerId());
				jsAccount.put("accountNumber", customerAccounts.getAccountNumber());
				jsAccount.put("currencyCode", customerAccounts.getCurrencyCode());
				jsAccount.put("accountStatus", customerAccounts.getAccountStatus());
				jsAccount.put("accountType", customerAccounts.getAccountService());
				jsAccount.put("transferLimit", customerAccounts.getAccountTransferLimit());
				jsAccount.put("mt940Flag", customerAccounts.getMt940generateFlag());
				jsAccount.put("rateIndicator", customerAccounts.getRateIndicator().ordinal());
				jsArrAccounts.add(jsAccount);
			}
		} catch (Exception e) {
			logger.error("Error in fetching customer account list. Error " + e.getMessage(), e);
			throw new AccountsNotFoundException("Cannot found accounts");
		}

		return jsArrAccounts;
	}

	@Override
	public Integer getSequenceByAccount(String companyCode, String strAccount) {
		Integer sequence = null;
		try {

			if (!(StringUtils.isEmpty(companyCode) && !(StringUtils.isEmpty(strAccount)))) {

				sequence = customerAccountsDao.getSequenceByAccount(companyCode, strAccount);

			}
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		if (sequence == null) {
			sequence = 1;
		}
		return sequence;

	}

	@Override
	public JSONObject fetchAccountCount(String strCustomer, String strStatus, String strAccount, String strType) {
		JSONObject res = new JSONObject();
		try {
			List<CustomerAccounts> lstAccounts = customerAccountsDao.listAllAccounts(strCustomer, strStatus, strAccount,
					strType, 0, -1);
			logger.info("Total count is " + lstAccounts.size());
			res.put("count", lstAccounts.size());
		} catch (Exception e) {
			res.put("count", 0);
		}
		return res;
	}

	@Override
	public JSONObject findAccount(String strCustomer, String accountNumber, String accountType) {
		JSONObject jsAccount = null;
		try {
			jsAccount = new JSONObject();
			CustomerAccounts custAccount = customerAccountsDao.findCustomerAccount(strCustomer, accountNumber,
					accountType);
			if (custAccount != null) {
				jsAccount.put("customerId", custAccount.getCustomerId());
				jsAccount.put("accountNumber", custAccount.getAccountNumber());
				jsAccount.put("currencyCode", custAccount.getCurrencyCode());
				jsAccount.put("accountStatus", custAccount.getAccountStatus());
				jsAccount.put("sequenceNumber", custAccount.getSequenceNumber());
				jsAccount.put("accountService", custAccount.getAccountService());
				jsAccount.put("bicCode", custAccount.getBicCode());
				jsAccount.put("transferLimit", custAccount.getAccountTransferLimit());
				jsAccount.put("mt940Flag", custAccount.getMt940generateFlag());
				jsAccount.put("rateIndicator", custAccount.getRateIndicator().ordinal());
				jsAccount.put("status", true);
			}
		} catch (Exception e) {
			logger.error("Error in finding the account. Error " + e.getMessage(), e);
			jsAccount = new JSONObject();
			jsAccount.put("status", false);
			jsAccount.put("message", "Cannot find the account number");
		}
		return jsAccount;
	}

	@Override
	public JSONObject updateAccount(AccountDTO accountNumberDTO, String userID) {
		JSONObject jsAccount = null;
		try {
			jsAccount = new JSONObject();
			String strAccountNumber = accountNumberDTO.getAccountNumber();
			String strCustomer = accountNumberDTO.getCustomerId();
			String accountType = accountNumberDTO.getAccountService();
			logger.info("Fetching account number for update is " + strAccountNumber);
			CustomerAccounts custAccount = customerAccountsDao.findCustomerAccount(strCustomer, strAccountNumber,
					accountType);
			if (custAccount != null) {
				BeanUtils.copyProperties(accountNumberDTO, custAccount);
				custAccount.setModifiedId(userID);
				custAccount.setModifiedDate(new Date());
				custAccount.setRateIndicator(RATE_INDICATOR.values()[accountNumberDTO.getRateIndicator()]);
				
				if (customerAccountsDao.updateCustomerAccount(custAccount)) {
					jsAccount.put("status", true);
					jsAccount.put("message", "Account updated successfully.");
				} else {
					jsAccount.put("status", false);
					jsAccount.put("message", "Failed to update account number");
				}
			} else {
				jsAccount.put("status", false);
				jsAccount.put("message", "Cannot find the account number");
			}
		} catch (Exception e) {
			jsAccount = new JSONObject();
			jsAccount.put("status", false);
			jsAccount.put("message", "Failed to update account number");
		}
		return jsAccount;
	}

	@Override
	public JSONObject deleteAccount(String strCustomer, String accountNumber, String accountType, String userID) {
		JSONObject jsAccount = null;
		try {
			logger.info("Fetching account number for update is " + accountNumber);
			jsAccount = new JSONObject();
			CustomerAccounts custAccount = customerAccountsDao.findCustomerAccount(strCustomer, accountNumber,
					accountType);
			if (custAccount != null) {
				if (customerAccountsDao.deleteCustomerAccount(custAccount)) {
					jsAccount.put("status", true);
					jsAccount.put("message", "Account deleted successfully.");
				} else {
					jsAccount.put("status", false);
					jsAccount.put("message", "Failed to delete account number.");
				}
			} else {
				jsAccount.put("status", false);
				jsAccount.put("message", "Cannot find the account number");
			}
		} catch (Exception e) {
			jsAccount = new JSONObject();
			jsAccount.put("status", false);
			jsAccount.put("message", "Cannot delete the account number");
		}
		return jsAccount;
	}

	@Override
	public JSONObject saveAccount(AccountDTO accountNumberDTO, String userID) {
		JSONObject jsAccount = null;
		try {
			jsAccount = new JSONObject();
			if (accountNumberDTO != null) {
				CustomerAccounts account = new CustomerAccounts();
				BeanUtils.copyProperties(accountNumberDTO, account);
				account.setCustomerCraetedId(userID);
				account.setAccountStatus("ACTIVE");
				account.setCustomerCraetedDate(new Date());
				if(StringUtils.isEmpty(accountNumberDTO.getAccountTransferLimit())) {
					account.setAccountTransferLimit("-1");
				}
				account.setRateIndicator(RATE_INDICATOR.values()[accountNumberDTO.getRateIndicator()]);
				if (customerAccountsDao.saveCustomerAccount(account)) {
					jsAccount.put("status", true);
					jsAccount.put("message", "Account saved successfully.");
				} else {
					jsAccount.put("status", false);
					jsAccount.put("message", "Failed to save account number.");
				}
			} else {
				jsAccount.put("status", false);
				jsAccount.put("message", "Cannot save the account number");
			}
		} catch (Exception e) {
			jsAccount = new JSONObject();
			jsAccount.put("status", false);
			jsAccount.put("message", "Cannot save the account number");
		}
		return jsAccount;
	}

	@Override
	public String checkAccountBalance(String accountNumber) {
		String result = "";
		try {
			RestTemplate restTemplate = new RestTemplate();
			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			List<SystemParameters> b2bProperties = systemParametersDAO.getSystemParametersByTableCode("MACSERPRO");
			HashMap<String, SystemParameters> map = new HashMap<String, SystemParameters>();
			for (SystemParameters param : b2bProperties) {
				SystemParameters obj = new SystemParameters();
				BeanUtils.copyProperties(param, obj);
				map.put(param.getItemCode().trim(), obj);
			}
			String b2bUrl = systemParameterService.getSystemParametersDescription1("B2B_URL", map);
			String URI = b2bUrl +"generalservices/enquiries/account/"+accountNumber;
			result = restTemplate.getForObject(URI, String.class);
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
			result = e.getMessage();
		}
		return result;
	}
}
