package com.bsf.macug.customer.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.bsf.macug.util.IConstants;


public class AccountDTO implements Serializable {

	private String customerId;
	private String accountNumber;
	private String accountService;
	private String currencyCode;
	private String bicCode;
	private String accountTransferLimit;
	private String accountStatus;
	private Integer sequenceNumber;
	private Integer rateIndicator;
	private Integer mt940generateFlag;
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountService() {
		return accountService;
	}
	public void setAccountService(String accountService) {
		this.accountService = accountService;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getBicCode() {
		return bicCode;
	}
	public void setBicCode(String bicCode) {
		this.bicCode = bicCode;
	}
	public String getAccountTransferLimit() {
		return accountTransferLimit;
	}
	public void setAccountTransferLimit(String accountTransferLimit) {
		this.accountTransferLimit = accountTransferLimit;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	public Integer getSequenceNumber() {
		return sequenceNumber;
	}
	public void setSequenceNumber(Integer sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	public Integer getRateIndicator() {
		return rateIndicator;
	}
	public void setRateIndicator(Integer rateIndicator) {
		this.rateIndicator = rateIndicator;
	}
	public Integer getMt940generateFlag() {
		return mt940generateFlag;
	}
	public void setMt940generateFlag(Integer mt940generateFlag) {
		this.mt940generateFlag = mt940generateFlag;
	}
	
	
}
