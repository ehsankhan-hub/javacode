package com.bsf.macug.customer.dto;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;

public class CustomerDetailsDTO {
	private String customerId;   	
    private String customerName;
    private String customerCategory; 
    private String customerCertificateSeriaNumber;
    private String customerValueDateFlag;
    private String customerMolId;
    private BigDecimal customerCorporateLimit;
    private BigDecimal customerBsfLimit;
    private BigDecimal customerSarieLimit;
    private BigDecimal customerSwiftLimit;
    private BigDecimal customerForeignCurrencyLimit;
    private String customerPerson;
    private String customerAddress;
    private String customerCountryCode;
    private String customerZipCode;
    private String customerEmail;
    private String customerPhone;
    private String customerMobile;
	private String wpsFlag;
	private String zipFlag; 
	private String tag20ReplyFlag; 
	private String payrollId;
	private String payrollAttachSignFlag;
	private String mt940ArabicFlag;	
	private String payrollBalanceCheckFlag;
	private Integer paymentSeries;
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerCategory() {
		return customerCategory;
	}
	public void setCustomerCategory(String customerCategory) {
		this.customerCategory = customerCategory;
	}
	public String getCustomerCertificateSeriaNumber() {
		return customerCertificateSeriaNumber;
	}
	public void setCustomerCertificateSeriaNumber(String customerCertificateSeriaNumber) {
		this.customerCertificateSeriaNumber = customerCertificateSeriaNumber;
	}
	public String getCustomerValueDateFlag() {
		return customerValueDateFlag;
	}
	public void setCustomerValueDateFlag(String customerValueDateFlag) {
		this.customerValueDateFlag = customerValueDateFlag;
	}
	public String getCustomerMolId() {
		return customerMolId;
	}
	public void setCustomerMolId(String customerMolId) {
		this.customerMolId = customerMolId;
	}
	public BigDecimal getCustomerCorporateLimit() {
		return customerCorporateLimit;
	}
	public void setCustomerCorporateLimit(BigDecimal customerCorporateLimit) {
		this.customerCorporateLimit = customerCorporateLimit;
	}
	public BigDecimal getCustomerBsfLimit() {
		return customerBsfLimit;
	}
	public void setCustomerBsfLimit(BigDecimal customerBsfLimit) {
		this.customerBsfLimit = customerBsfLimit;
	}
	public BigDecimal getCustomerSarieLimit() {
		return customerSarieLimit;
	}
	public void setCustomerSarieLimit(BigDecimal customerSarieLimit) {
		this.customerSarieLimit = customerSarieLimit;
	}
	public BigDecimal getCustomerSwiftLimit() {
		return customerSwiftLimit;
	}
	public void setCustomerSwiftLimit(BigDecimal customerSwiftLimit) {
		this.customerSwiftLimit = customerSwiftLimit;
	}
	public BigDecimal getCustomerForeignCurrencyLimit() {
		return customerForeignCurrencyLimit;
	}
	public void setCustomerForeignCurrencyLimit(BigDecimal customerForeignCurrencyLimit) {
		this.customerForeignCurrencyLimit = customerForeignCurrencyLimit;
	}
	public String getCustomerPerson() {
		return customerPerson;
	}
	public void setCustomerPerson(String customerPerson) {
		this.customerPerson = customerPerson;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getCustomerCountryCode() {
		return customerCountryCode;
	}
	public void setCustomerCountryCode(String customerCountryCode) {
		this.customerCountryCode = customerCountryCode;
	}
	public String getCustomerZipCode() {
		return customerZipCode;
	}
	public void setCustomerZipCode(String customerZipCode) {
		this.customerZipCode = customerZipCode;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerPhone() {
		return customerPhone;
	}
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}
	public String getCustomerMobile() {
		return customerMobile;
	}
	public void setCustomerMobile(String customerMobile) {
		this.customerMobile = customerMobile;
	}
	public String getWpsFlag() {
		return wpsFlag;
	}
	public void setWpsFlag(String wpsFlag) {
		this.wpsFlag = wpsFlag;
	}
	public String getZipFlag() {
		return zipFlag;
	}
	public void setZipFlag(String zipFlag) {
		this.zipFlag = zipFlag;
	}
	public String getTag20ReplyFlag() {
		return tag20ReplyFlag;
	}
	public void setTag20ReplyFlag(String tag20ReplyFlag) {
		this.tag20ReplyFlag = tag20ReplyFlag;
	}
	public String getPayrollId() {
		return payrollId;
	}
	public void setPayrollId(String payrollId) {
		this.payrollId = payrollId;
	}
	public String getPayrollAttachSignFlag() {
		return payrollAttachSignFlag;
	}
	public void setPayrollAttachSignFlag(String payrollAttachSignFlag) {
		this.payrollAttachSignFlag = payrollAttachSignFlag;
	}
	public String getMt940ArabicFlag() {
		return mt940ArabicFlag;
	}
	public void setMt940ArabicFlag(String mt940ArabicFlag) {
		this.mt940ArabicFlag = mt940ArabicFlag;
	}
	public String getPayrollBalanceCheckFlag() {
		return payrollBalanceCheckFlag;
	}
	public void setPayrollBalanceCheckFlag(String payrollBalanceCheckFlag) {
		this.payrollBalanceCheckFlag = payrollBalanceCheckFlag;
	}
	public Integer getPaymentSeries() {
		return paymentSeries;
	}
	public void setPaymentSeries(Integer paymentSeries) {
		this.paymentSeries = paymentSeries;
	}
	
	
}
