package com.bsf.macug.user.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.bsf.macug.user.entity.UserDetailsDTO;
import com.bsf.macug.user.service.InterUserService;
import com.bsf.macug.user.service.InterUserUtil;

@RestController
@RequestMapping("/users")
public class UserController {
	private static final Logger logger = Logger.getLogger(UserController.class.getName());

	@Autowired
	private TokenStore tokenStore;

	@Autowired
	InterUserUtil userUtil;

	@RequestMapping(value = "/logout", method = RequestMethod.POST)
	public String logout(HttpServletRequest request) {
		JSONObject res = new JSONObject();
		String authHeader = request.getHeader("Authorization");
		try {
			res.put("status", false);
			if (authHeader != null) {
				String tokenValue = authHeader.replace("Bearer", "").trim();
				OAuth2AccessToken accessToken = tokenStore.readAccessToken(tokenValue);
				tokenStore.removeAccessToken(accessToken);
				res.put("status", true);
			}
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			res.put("status", false);
		}
		return res.toString();
	}
	
	@RequestMapping(value = "/navList", method = RequestMethod.GET)
	public String navigationList(HttpServletRequest request) {
		JSONObject res = new JSONObject();
		try {
			Principal principal = request.getUserPrincipal();
			String userId = principal.getName();
			JSONArray dto = userUtil.getAllScreenList(userId);
			res.put("status", true);
			res.put("data", dto);
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			res.put("status", false);
		}
		return res.toString();
	}

	@RequestMapping(value = "/test", method = RequestMethod.GET)
	public String test(HttpServletRequest request) {
		JSONObject res = new JSONObject();
		try {
			res.put("status", true);

		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
			res.put("status", true);
		}
		return res.toString();
	}
}
