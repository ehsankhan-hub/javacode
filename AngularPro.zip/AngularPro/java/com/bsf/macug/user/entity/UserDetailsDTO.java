package com.bsf.macug.user.entity;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class UserDetailsDTO implements Serializable {

	private String userID;
	private String userPassword;
	private String ldapURL;
	private String userEmail;
	private String userRole;
	private String landingPage;
	private String status;
	private String message;
	private String ipAddress;
	private boolean ldapContext;
	private String accessType;
	private Map<String, List<UserScreenDTO>> mapUserMenu;

	public UserDetailsDTO() {
	}

	public UserDetailsDTO(String userID, String userPassword) {
		super();
		this.userID = userID;
		this.userPassword = userPassword;
	}

	public UserDetailsDTO(String userID, String userPassword, String ldapURL) {
		super();
		this.userID = userID;
		this.userPassword = userPassword;
		this.ldapURL = ldapURL;
	}

	public UserDetailsDTO(String userID, String userPassword, String userEmail,
			String userRole, String landingPage) {
		super();
		this.userID = userID;
		this.userPassword = userPassword;
		this.userEmail = userEmail;
		this.userRole = userRole;
		this.landingPage = landingPage;
	}

	public UserDetailsDTO(String userID, String userPassword, String userEmail,
			String userRole, String status, String message) {
		super();
		this.userID = userID;
		this.userPassword = userPassword;
		this.userEmail = userEmail;
		this.userRole = userRole;
		this.status = status;
		this.message = message;
	}

	public UserDetailsDTO(String userID, String userPassword, String ldapURL,
			String userEmail, String userRole, String landingPage,
			String status, String message, String ipAddress,
			boolean ldapContext, Map<String, List<UserScreenDTO>> mapUserMenu) {
		super();
		this.userID = userID;
		this.userPassword = userPassword;
		this.ldapURL = ldapURL;
		this.userEmail = userEmail;
		this.userRole = userRole;
		this.landingPage = landingPage;
		this.status = status;
		this.message = message;
		this.ipAddress = ipAddress;
		this.ldapContext = ldapContext;
		this.mapUserMenu = mapUserMenu;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getLdapURL() {
		return ldapURL;
	}

	public void setLdapURL(String ldapURL) {
		this.ldapURL = ldapURL;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getLandingPage() {
		return landingPage;
	}

	public void setLandingPage(String landingPage) {
		this.landingPage = landingPage;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public boolean isLdapContext() {
		return ldapContext;
	}

	public void setLdapContext(boolean ldapContext) {
		this.ldapContext = ldapContext;
	}

	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	public Map<String, List<UserScreenDTO>> getMapUserMenu() {
		return mapUserMenu;
	}

	public void setMapUserMenu(Map<String, List<UserScreenDTO>> mapUserMenu) {
		this.mapUserMenu = mapUserMenu;
	}

	@Override
	public String toString() {
		return "UserDetailsDTO [userID=" + userID + ", userPassword="
				+ userPassword + ", userEmail=" + userEmail + ", userRole="
				+ userRole + ", landingPage=" + landingPage + "]";
	}

}
