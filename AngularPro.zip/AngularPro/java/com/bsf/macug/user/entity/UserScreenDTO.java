package com.bsf.macug.user.entity;


import java.io.Serializable;

public class UserScreenDTO implements Serializable {

	private String screenID;
	private String screenName;
	private String screenURL;
	private String screenIcon;
	private boolean creatorAccess;
	private boolean verifierAccess;

	public UserScreenDTO() {
	}

	public UserScreenDTO(String screenID, String screenName, String screenURL,
			String screenIcon) {
		super();
		this.screenID = screenID;
		this.screenName = screenName;
		this.screenURL = screenURL;
		this.screenIcon = screenIcon;
	}

	public String getScreenID() {
		return screenID;
	}

	public void setScreenID(String screenID) {
		this.screenID = screenID;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public String getScreenURL() {
		return screenURL;
	}

	public void setScreenURL(String screenURL) {
		this.screenURL = screenURL;
	}

	public String getScreenIcon() {
		return screenIcon;
	}

	public void setScreenIcon(String screenIcon) {
		this.screenIcon = screenIcon;
	}

	public boolean isCreatorAccess() {
		return creatorAccess;
	}

	public void setCreatorAccess(boolean creatorAccess) {
		this.creatorAccess = creatorAccess;
	}

	public boolean isVerifierAccess() {
		return verifierAccess;
	}

	public void setVerifierAccess(boolean verifierAccess) {
		this.verifierAccess = verifierAccess;
	}

	@Override
	public String toString() {
		return "{\"screenID\":\"" + screenID + "\",\"screenName\":\"" + screenName + "\",\"screenURL\":\"" + screenURL
				+ "\",\"screenIcon\":\"" + screenIcon + "\",\"creatorAccess\":\"" + creatorAccess + "\",\"verifierAccess\":\""
				+ verifierAccess + "\"}";
	}
	
	
}
