package com.bsf.macug.user.dao;

import java.util.List;

import com.bsf.macug.user.entity.ProfileMap;

public interface InterGroupDAO {
	List<Object[]> getProfileAccess(String appId, String userId);

	List<ProfileMap> getAllProfileMaps();
}
