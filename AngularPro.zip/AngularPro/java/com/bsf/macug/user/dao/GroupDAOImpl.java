package com.bsf.macug.user.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.bsf.macug.user.entity.ProfileMap;

@Repository
public class GroupDAOImpl implements InterGroupDAO{
	private static final Logger logger = Logger.getLogger(GroupDAOImpl.class
			.getName());
	
	@Autowired
	SessionFactory sessionFactory;
	
	@Autowired
	@Qualifier("sessionFactoryPAC")
	private SessionFactory sessionFactoryPAC;
	
	@Override
	public List<Object[]> getProfileAccess(String appId, String userId) {
		List<Object[]> result = null;
		try {
			Session session = sessionFactoryPAC.getCurrentSession();
			String query = "SELECT U.User_Code , S.App_Code , F.Function_Code ,"
					+ "F.URL,F.function_type funtion_type, U.id User_Id, s.id App_Id,P.id profileId,"
					+ "P.Profile_Desc profile_description, f.id  Access_id, F.Function_Desc, P.Profile_Code "
					+ "FROM Portal_Access_Control C , Users U , Portal_Profile_List P ,"
					+ " Portal_Access_Profile  A , Portal_Access_List F , Portal_Applications S "
					+ "WHERE U.ID = C.USER_ID AND P.ID = C.PROFILE_ID AND A.PROFILE_ID = P.ID "
					+ "AND F.ID = A.ACCESS_ID AND S.ID = F.APP_ID "
					+ "AND U.User_Code='"
					+ userId
					+ "'"
					+ " AND S.App_Code='"
					+ appId + "' ";
			System.out.println(query);
			SQLQuery sqlQuery = session.createSQLQuery(query);
			result = sqlQuery.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return result;
	}

	@Override
	public List<ProfileMap> getAllProfileMaps(){
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(ProfileMap.class);
		List<ProfileMap> result = null;
		try {
			 result = criteria.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return result;
	}

}
