package com.bsf.macug.user.service;

import java.util.List;

import org.json.simple.JSONObject;

import com.bsf.macug.user.entity.ProfileMap;

public interface InterUserService {
	List<ProfileMap> getAllProfileMaps();
}
