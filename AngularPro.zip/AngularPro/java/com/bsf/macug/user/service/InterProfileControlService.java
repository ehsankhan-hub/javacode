package com.bsf.macug.user.service;

import java.util.List;

public interface InterProfileControlService {
	public List<Object[]> getProfileAccess(String appId, String userId);
}

