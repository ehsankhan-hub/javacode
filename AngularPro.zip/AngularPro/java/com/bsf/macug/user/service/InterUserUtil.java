package com.bsf.macug.user.service;

import org.json.simple.JSONArray;

import com.bsf.macug.user.entity.UserDetailsDTO;

public interface InterUserUtil {
	JSONArray getAllScreenList(String userId);
}
