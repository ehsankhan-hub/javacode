package com.bsf.macug.user.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.user.dao.InterGroupDAO;
import com.bsf.macug.user.entity.ProfileMap;

@Service
@Transactional
public class UserServiceImpl implements InterUserService {
	private static final Logger logger = Logger.getLogger(UserServiceImpl.class.getName());

	@Autowired
	InterSystemParameterService systemParameterService;

	@Autowired
	InterGroupDAO groupDao;
	
	@Override
	public List<ProfileMap> getAllProfileMaps() {
		return groupDao.getAllProfileMaps();
	}

}
