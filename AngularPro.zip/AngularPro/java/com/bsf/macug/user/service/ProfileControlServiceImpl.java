package com.bsf.macug.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.macug.user.dao.InterGroupDAO;

@Service("profileControlService")
@Transactional
public class ProfileControlServiceImpl implements InterProfileControlService{

	@Autowired
	InterGroupDAO groupDao;
	
	@Override
	public List<Object[]> getProfileAccess(String appId, String userId) {
		// TODO Auto-generated method stub
		return groupDao.getProfileAccess(appId, userId);
	}

	
}