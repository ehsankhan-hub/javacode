package com.bsf.macug.user.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bsf.macug.general.entity.SystemParameters;
import com.bsf.macug.general.service.InterSystemParameterService;
import com.bsf.macug.user.entity.ProfileMap;
import com.bsf.macug.user.entity.UserDetailsDTO;
import com.bsf.macug.user.entity.UserScreenDTO;

@Service
public class UserUtilImpl implements InterUserUtil{

	private static final Logger logger = Logger.getLogger(UserServiceImpl.class.getName());

	
	@Autowired
	InterProfileControlService profileControlService;
	
	@Autowired
	InterUserService userService;
	
	@Autowired
	InterSystemParameterService systemParameterService;
	
	@Override
	public JSONArray getAllScreenList(String userId) {
		
		Map<String, List<UserScreenDTO>> mapUserMenu = null;
		Map<String, SystemParameters> onlineProperties = null;
		Map<String, SystemParameters> creatorGroups = null;
		Map<String, SystemParameters> verifierGroups = null;
		UserDetailsDTO dtoUserDetails = new  UserDetailsDTO();
		JSONArray resultArray = new JSONArray();
		try {
			
			onlineProperties = systemParameterService
					.getSystemParametersByTableCode("ONBNKPROP");
			creatorGroups = systemParameterService
					.getSystemParametersByTableCode("BBOCRTGRP");
			verifierGroups = systemParameterService
					.getSystemParametersByTableCode("BBOVERGRP");
			String applicationName = systemParameterService
					.getSystemParametersDescription1("B2BGUI", onlineProperties);
			
			List<Object[]> profileAccessList = profileControlService
					.getProfileAccess(applicationName, userId);

			List<ProfileMap> profiles = userService.getAllProfileMaps();
			Map<String, List<String>> functionMenuMap = getFuctionMap(profiles);
			
						
			System.out.println("functionMenuMap--"+functionMenuMap.get(0));
			
			Map<String, UserScreenDTO> allScreenList = new HashMap<String, UserScreenDTO>();
			for (Object[] profileAccess : profileAccessList) {
				String functionCode = (String) profileAccess[2];
				String functionUrl = (String) profileAccess[3];
				String functionDescription = (String) profileAccess[10];
				String profileCode = (String) profileAccess[11];
				boolean creatorAccess = false;
				boolean verifierAccess = false;
				if (creatorGroups != null && creatorGroups.containsKey(profileCode)) {
					creatorAccess = true;
				}

				if (verifierGroups != null
						&& verifierGroups.containsKey(profileCode)) {
					verifierAccess = true;
				}

				String category = getCategory(functionCode, functionMenuMap,
						onlineProperties);
				if (StringUtils.isEmpty(category)) {
					category = "Others";
				}
				String icon = getIcon(functionCode.trim(), profiles);
				if (StringUtils.isEmpty(icon)) {
					category = "fa-user";
				}
				if (dtoUserDetails.getMapUserMenu() != null) {

					try {
						Map<String, List<UserScreenDTO>> mapUserAddedMenus = null;
						mapUserAddedMenus = dtoUserDetails.getMapUserMenu();
						
						//Map<String, List<UserScreenDTO>> map = new HashMap<>();
						
						for (Map.Entry<String, List<UserScreenDTO>> entry : mapUserAddedMenus.entrySet()) {
							System.out.println("[Key] : " + entry.getKey() + " [Value] : " + entry.getValue());
						}
						
						if (mapUserAddedMenus != null) {
							List<UserScreenDTO> lstScreenDTOS = mapUserAddedMenus
									.get(category.trim());
							UserScreenDTO dtoUserScreen = null;
							if (lstScreenDTOS != null) {
								dtoUserScreen = new UserScreenDTO();
								dtoUserScreen.setScreenID(functionCode);
								dtoUserScreen.setScreenName(functionDescription
										.trim());
								String url = getURL(functionCode.trim(), profiles);
								//dtoUserScreen.setScreenURL(functionUrl.trim());
								dtoUserScreen.setScreenURL(url.trim());
								dtoUserScreen.setScreenIcon(icon.trim());
								lstScreenDTOS.add(dtoUserScreen);
								allScreenList.put(functionCode, dtoUserScreen);
							} else {
								dtoUserScreen = new UserScreenDTO();
								dtoUserScreen.setScreenID(functionCode);
								dtoUserScreen.setScreenName(functionDescription
										.trim());
								String url = getURL(functionCode.trim(), profiles);
								//dtoUserScreen.setScreenURL(functionUrl.trim());
								dtoUserScreen.setScreenURL(url.trim());
								dtoUserScreen.setScreenIcon(icon.trim());
								lstScreenDTOS = new ArrayList<UserScreenDTO>();
								lstScreenDTOS.add(dtoUserScreen);
								mapUserMenu.put(category.trim(), lstScreenDTOS);
								dtoUserDetails.setMapUserMenu(mapUserMenu);
								allScreenList.put(functionCode, dtoUserScreen);
							}
							dtoUserScreen.setCreatorAccess(creatorAccess);
							dtoUserScreen.setVerifierAccess(verifierAccess);
						} else {
							logger.info("Added menu list is null/empty. Skipping from menu item");
						}
					} catch (Exception e) {
						logger.error("Error : "+e.getMessage(), e);
						logger.debug(
								"Error occured while processing user sub menubar",
								e);
					}

				} else {
					mapUserMenu = new HashMap<String, List<UserScreenDTO>>();
					List<UserScreenDTO> lstUserScreen = null;
					lstUserScreen = new ArrayList<UserScreenDTO>();
					UserScreenDTO dtoUserScreen = new UserScreenDTO();
					dtoUserScreen.setScreenID(functionCode.trim());
					dtoUserScreen.setScreenName(functionDescription.trim());
					String url = getURL(functionCode.trim(), profiles);
					//dtoUserScreen.setScreenURL(functionUrl.trim());
					dtoUserScreen.setScreenURL(url.trim());
					dtoUserScreen.setScreenIcon(icon.trim());
					dtoUserScreen.setCreatorAccess(creatorAccess);
					dtoUserScreen.setVerifierAccess(verifierAccess);
					lstUserScreen.add(dtoUserScreen);
					mapUserMenu.put(category.trim(), lstUserScreen);
					dtoUserDetails.setMapUserMenu(mapUserMenu);
					allScreenList.put(functionCode, dtoUserScreen);
				}

			}
			Map<String, List<UserScreenDTO>> userMap = dtoUserDetails.getMapUserMenu();
			Set<String> keySet = userMap.keySet();
			
			for(String key : keySet) {
				JSONObject result = new JSONObject();
				List<UserScreenDTO> dataList = mapUserMenu.get(key);				
				JSONArray childArray = new JSONArray();
				for(UserScreenDTO data: dataList) {
					JSONObject childData = new JSONObject();
					childData.put("screenName", data.getScreenName());
					childData.put("url", data.getScreenURL());
					childArray.add(childData);
				}
				result.put("parent", key);
				result.put("children", childArray);
				resultArray.add(result);
			}
		} catch (Exception e) {
			logger.error("Error : "+e.getMessage(), e);
		}
		return resultArray;
	}
	
	private Map<String, List<String>> getFuctionMap(List<ProfileMap> profiles) {
		Map<String, List<String>> result = new HashMap<String, List<String>>();
		for (ProfileMap profile : profiles) {
			String menuId = profile.getMenuId();
			String functionCode = profile.getFunctionCode();

			if (result.containsKey(menuId)) {
				List<String> functionList = result.get(menuId);
				functionList.add(functionCode);
				result.put(menuId, functionList);
			} else {
				List<String> functionList = new ArrayList<String>();
				functionList.add(functionCode);
				result.put(menuId, functionList);
			}
		}

		return result;
	}

	private String getIcon(String functionCode, List<ProfileMap> profiles) {
		for (ProfileMap profile : profiles) {
			String fnCode = profile.getFunctionCode();
			if (fnCode.equals(functionCode)) {
				return profile.getIcon();
			}
		}
		return null;
	}

	private String getURL(String functionCode, List<ProfileMap> profiles) {
		for (ProfileMap profile : profiles) {
			String fnCode = profile.getFunctionCode();
			if (fnCode.equals(functionCode)) {
				return profile.getUrl();
			}
		}
		return null;
	}

	private String getCategory(String functionCode,
			Map<String, List<String>> functionMenuMap,
			Map<String, SystemParameters> onlineProperties) {
		Set<String> keyset = functionMenuMap.keySet();
		for (String key : keyset) {
			List<String> functionCodeList = functionMenuMap.get(key);
			if (functionCodeList.contains(functionCode)) {
				SystemParameters prop = onlineProperties.get(key);
				return prop.getItemDescription1();
			}
		}
		return null;
	}
}
