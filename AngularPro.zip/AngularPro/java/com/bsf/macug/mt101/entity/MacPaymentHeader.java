package com.bsf.macug.mt101.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Version;

/**
 * The persistent class for the MAC_PAYMENT_HEADER database table.
 * 
 */
@Entity
@Table(name = "MAC_PAYMENT_HEADER")
public class MacPaymentHeader implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CUSTOMER_ID")
	private String customerId;

	@Id
	@Column(name = "FILE_REFERENCE")
	private String fileReference;

	private String id;
	
	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_ON")
	private Timestamp createdOn;

	private String description;

	@Column(name = "MESSAGE_TYPE")
	private String messageType;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "MODIFIED_ON")
	private Timestamp modifiedOn;

	@Column(name = "PROCESSED_TIME")
	private Timestamp processedTime;

	private String status;

	@Column(name = "TOTAL_AC_AC")
	private BigDecimal totalAcAc;

	@Column(name = "TOTAL_FAILED")
	private BigDecimal totalFailed;

	@Column(name = "TOTAL_PROCESSED")
	private BigDecimal totalProcessed;

	@Column(name = "TOTAL_SARIE")
	private BigDecimal totalSarie;

	@Column(name = "TOTAL_SWIFT")
	private BigDecimal totalSwift;

	@Column(name = "TOTAL_TRANSACTION")
	private BigDecimal totalTransaction;

	@Column(name = "PROCESSING_STATUS")
	private Integer processingStatus; // 1 means processing 0 means stoped

	@Column(name="MT199_STATUS")
	private String mt199Status;
	
	@Version
	@Column(name = "VERSION")
	private Integer version;

	public MacPaymentHeader() {
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getFileReference() {
		return fileReference;
	}

	public void setFileReference(String fileReference) {
		this.fileReference = fileReference;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public Timestamp getProcessedTime() {
		return processedTime;
	}

	public void setProcessedTime(Timestamp processedTime) {
		this.processedTime = processedTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public BigDecimal getTotalAcAc() {
		return totalAcAc;
	}

	public void setTotalAcAc(BigDecimal totalAcAc) {
		this.totalAcAc = totalAcAc;
	}

	public BigDecimal getTotalFailed() {
		return totalFailed;
	}

	public void setTotalFailed(BigDecimal totalFailed) {
		this.totalFailed = totalFailed;
	}

	public BigDecimal getTotalProcessed() {
		return totalProcessed;
	}

	public void setTotalProcessed(BigDecimal totalProcessed) {
		this.totalProcessed = totalProcessed;
	}

	public BigDecimal getTotalSarie() {
		return totalSarie;
	}

	public void setTotalSarie(BigDecimal totalSarie) {
		this.totalSarie = totalSarie;
	}

	public BigDecimal getTotalSwift() {
		return totalSwift;
	}

	public void setTotalSwift(BigDecimal totalSwift) {
		this.totalSwift = totalSwift;
	}

	public BigDecimal getTotalTransaction() {
		return totalTransaction;
	}

	public void setTotalTransaction(BigDecimal totalTransaction) {
		this.totalTransaction = totalTransaction;
	}

	public Integer getProcessingStatus() {
		return processingStatus;
	}

	public void setProcessingStatus(Integer processingStatus) {
		this.processingStatus = processingStatus;
	}

	public String getMt199Status() {
		return mt199Status;
	}

	public void setMt199Status(String mt199Status) {
		this.mt199Status = mt199Status;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	
}