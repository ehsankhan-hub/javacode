package com.bsf.macug.mt101.dao;

import java.util.List;

import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.entity.MacPaymentHeader;

public interface InterPaymentDAO {
	List<MacPaymentHeader> findAllHeader(String status);
	
	List<MacPaymentHeader> findAllHeader(String customerId, String fileId,String status, String pageNumber, String pageSize);

	MacPaymentHeader getHeader(String customerId, String fileId);

	List<MacPaymentDetail> findAllDetail(String customerId, String fileId, String status);
	
	List<MacPaymentDetail> findAllDetail(String customerId, String fileId,String transactionRef,  String status, String pageNumber, String pageSize);

	MacPaymentDetail getDetail(String customerId, String fileId, String transactionId);
}
