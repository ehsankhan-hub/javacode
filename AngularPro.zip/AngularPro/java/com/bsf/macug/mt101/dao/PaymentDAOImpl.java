package com.bsf.macug.mt101.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.bsf.macug.customer.entity.CustomerDetails;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.entity.MacPaymentHeader;

@Repository
public class PaymentDAOImpl implements InterPaymentDAO {

	private static final Logger logger = Logger.getLogger(PaymentDAOImpl.class.getName());

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<MacPaymentHeader> findAllHeader(String status) {
		List<MacPaymentHeader> headerList = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentHeader.class);
			if (!StringUtils.isEmpty(status)) {
				criteria.add(Restrictions.eq("status", status));
			}
			criteria.add(Restrictions.ne("processingStatus", 1));

			headerList = criteria.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return headerList;
	}

	@Override
	public MacPaymentHeader getHeader(String customerId, String fileId) {
		MacPaymentHeader header = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentHeader.class);
			criteria.add(Restrictions.eq("customerId", customerId));
			criteria.add(Restrictions.eq("fileReference", fileId));
			header = (MacPaymentHeader) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return header;
	}

	@Override
	public List<MacPaymentDetail> findAllDetail(String customerId, String fileId, String status) {
		List<MacPaymentDetail> detailList = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentDetail.class);

			if (!StringUtils.isEmpty(customerId)) {
				criteria.add(Restrictions.eq("customerId", customerId));
			}
			if (!StringUtils.isEmpty(fileId)) {
				criteria.add(Restrictions.eq("fileReference", fileId));
			}
			if (!StringUtils.isEmpty(status)) {
				criteria.add(Restrictions.eq("status", status));
			}

			if ("HOLD".equalsIgnoreCase(status)) {
				Date today = new Date();
				DateFormat sdf = new SimpleDateFormat("ddMMyyyy");
				String strToday = sdf.format(today);
				today = sdf.parse(strToday);
				criteria.add(Restrictions.eq("tradeDate", today));
			}

			detailList = criteria.list();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detailList;
	}

	@Override
	public MacPaymentDetail getDetail(String customerId, String fileId, String transactionId) {
		MacPaymentDetail detail = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentDetail.class);
			criteria.add(Restrictions.eq("customerId", customerId));
			criteria.add(Restrictions.eq("fileReference", fileId));
			criteria.add(Restrictions.eq("transactionReference", transactionId));
			detail = (MacPaymentDetail) criteria.uniqueResult();
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return detail;
	}

	@Override
	public List<MacPaymentHeader> findAllHeader(String customerId, String fileId, String status, String pageNumber, String pageSize) {
		List<MacPaymentHeader> headerList = null;
		try {
			logger.info("************findAllHeader STARTED");
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentHeader.class);
			criteria.setFirstResult(Integer.parseInt(pageNumber) * Integer.parseInt(pageSize));
			criteria.setMaxResults(Integer.parseInt(pageSize));
			if (!StringUtils.isEmpty(customerId)) {
				criteria.add(Restrictions.like("customerId", customerId + "%").ignoreCase());
			}
			if (!StringUtils.isEmpty(status)) {
				criteria.add(Restrictions.eq("status", status));
			}
			if (!StringUtils.isEmpty(fileId)) {
				criteria.add(Restrictions.eq("fileReference", fileId));
			}
			criteria.addOrder(Order.desc("createdOn"));
			headerList = criteria.list();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		logger.info("******** findAllHeader STARTED END");
		return headerList;
	}

	@Override
	public List<MacPaymentDetail> findAllDetail(String customerId, String fileId,String transactionRef,  String status, String pageNumber,
			String pageSize) {
		List<MacPaymentDetail> headerList = null;
		try {
			logger.info("************findAllHeader STARTED");
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(MacPaymentDetail.class);
			criteria.setFirstResult(Integer.parseInt(pageNumber) * Integer.parseInt(pageSize));
			criteria.setMaxResults(Integer.parseInt(pageSize));
			if (!StringUtils.isEmpty(customerId)) {
				criteria.add(Restrictions.like("customerId", customerId + "%").ignoreCase());
			}
			if (!StringUtils.isEmpty(status)) {
				criteria.add(Restrictions.eq("status", status));
			}
			if (!StringUtils.isEmpty(fileId)) {
				criteria.add(Restrictions.eq("fileReference", fileId));
			}
			if (!StringUtils.isEmpty(transactionRef)) {
				criteria.add(Restrictions.eq("transactionReference", transactionRef));
			}
			criteria.addOrder(Order.desc("customerId"));
			headerList = criteria.list();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		logger.info("******** findAllHeader STARTED END");
		return headerList;
	}

}
