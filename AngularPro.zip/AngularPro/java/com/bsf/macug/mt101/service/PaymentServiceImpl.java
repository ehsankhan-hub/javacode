package com.bsf.macug.mt101.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.macug.customer.service.CustomerDetailsServiceImpl;
import com.bsf.macug.mt101.dao.InterPaymentDAO;
import com.bsf.macug.mt101.entity.MacPaymentDetail;
import com.bsf.macug.mt101.entity.MacPaymentHeader;

@Service
@Transactional
public class PaymentServiceImpl implements InterPaymentService{
	private static final Logger logger = Logger.getLogger(PaymentServiceImpl.class.getName());

	@Autowired
	InterPaymentDAO paymentDao;
	
	@Override
	public JSONArray findAllHeader(String customerId, String fileId, String status, String pageNumber,
			String pageSize) {
		JSONArray result = new JSONArray();
		try {
			List<MacPaymentHeader> list = paymentDao.findAllHeader(customerId, fileId, status, pageNumber, pageSize);
			for (MacPaymentHeader macPaymentHeader : list) {
				JSONObject obj = new JSONObject();
				
				String pattern = "dd-MM-yyyy";
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
				String receivedDate = simpleDateFormat.format(macPaymentHeader.getCreatedOn());
				
				
				obj.put("customerId", macPaymentHeader.getCustomerId());
				obj.put("fileId", macPaymentHeader.getFileReference());
				obj.put("receivedDate", receivedDate);
				obj.put("status", macPaymentHeader.getStatus());
				obj.put("description", macPaymentHeader.getDescription());
				result.add(obj);
			}
		} catch (Exception e) {
			logger.error("Error "+e.getMessage(), e);
		}
		return result;
	}

	@Override
	public JSONArray findAllDetails(String customerId, String fileId, String transactionReference, String status,
			String pageNumber, String pageSize) {
		JSONArray result = new JSONArray();
		try {
			List<MacPaymentDetail> list = paymentDao.findAllDetail(customerId, fileId, transactionReference, status, pageNumber, pageSize);
			for (MacPaymentDetail macPaymentHeader : list) {
				JSONObject obj = new JSONObject();
				String pattern = "dd-MM-yyyy";
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
				String valueDate = simpleDateFormat.format(macPaymentHeader.getValueDate());
				obj.put("customerId", macPaymentHeader.getCustomerId());
				obj.put("fileId", macPaymentHeader.getFileReference());
				System.out.println("macPaymentHeader.getTransactionReference()"+macPaymentHeader.getTransactionReference());
				obj.put("transactionReference", macPaymentHeader.getTransactionReference());
				obj.put("valueDate", valueDate);
				obj.put("status", macPaymentHeader.getStatus());
				obj.put("description", macPaymentHeader.getDescription());
				result.add(obj);
			}
		} catch (Exception e) {
			logger.error("Error "+e.getMessage(), e);
		}
		return result;
	}

	@Override
	public JSONObject getDetails(String customerId, String fileId, String transactionRef) {
		JSONObject obj = new JSONObject();
		try {
			MacPaymentDetail detailsObj = paymentDao.getDetail(customerId, fileId, transactionRef);
			if(detailsObj != null) {
				obj.put("customerId", detailsObj.getCustomerId());
				obj.put("fileId", detailsObj.getFileReference());
				obj.put("transactionReference", detailsObj.getTransactionReference());
				obj.put("status", detailsObj.getStatus());
				obj.put("description", detailsObj.getDescription());
			}
		} catch (Exception e) {
			logger.error("Error "+e.getMessage(), e);
		}
		return obj;
	}

}
