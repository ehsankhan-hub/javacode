package com.bsf.macug.mt101.service;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public interface InterPaymentService {
	public JSONArray findAllHeader(String customerId, String fileId, String status, String pageNumber, String pageSize) ;
	public JSONArray findAllDetails(String customerId, String fileId, String transactionReference,String status, String pageNumber, String pageSize) ;
	JSONObject getDetails(String customerId, String fileId, String transactionRef);
}
