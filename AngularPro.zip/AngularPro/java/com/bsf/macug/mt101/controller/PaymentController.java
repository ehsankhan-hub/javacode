package com.bsf.macug.mt101.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bsf.macug.customer.controller.CustomerController;
import com.bsf.macug.mt101.service.InterPaymentService;

@RestController
@RequestMapping("/payment")
public class PaymentController {

	private static final Logger logger = Logger.getLogger(CustomerController.class.getName());

	@Autowired
	InterPaymentService paymentService;

	@RequestMapping(value = "/header/list", method = RequestMethod.GET)
	public String list(HttpServletRequest request, @RequestParam("pageNumber") String pageNumber,
			@RequestParam("status") String status, @RequestParam("customerId") String customerId,
			@RequestParam("fileId") String fileId, @RequestParam("pageSize") String pageSize) {
		JSONArray dto = null;
		try {
			Principal principal = request.getUserPrincipal();
			String userId = principal.getName();

			dto = paymentService.findAllHeader(customerId, fileId, status, pageNumber, pageSize);

		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return dto.toString();
	}

	@RequestMapping(value = "/header/count", method = RequestMethod.GET)
	public String totalCount(HttpServletRequest request, @RequestParam("status") String status,
			@RequestParam("customerId") String customerId, @RequestParam("fileId") String fileId) {
		JSONObject dto = new JSONObject();
		try {
			Principal principal = request.getUserPrincipal();
			String userId = principal.getName();
			String sortOrder = request.getParameter("sortOrder");

			JSONArray list = paymentService.findAllHeader(customerId, fileId, status, "0", "-1");
			dto.put("count", list.size());
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return dto.toString();
	}

	@RequestMapping(value = "/details/list", method = RequestMethod.GET)
	public String dlist(HttpServletRequest request, @RequestParam("pageNumber") String pageNumber,
			@RequestParam("status") String status, @RequestParam("customerId") String customerId,
			@RequestParam("fileId") String fileId, @RequestParam("transactionRef") String transactionRef,
			@RequestParam("pageSize") String pageSize) {
		JSONArray dto = null;
		try {
			Principal principal = request.getUserPrincipal();
			String userId = principal.getName();

			dto = paymentService.findAllDetails(customerId, fileId, transactionRef, status, pageNumber, pageSize);

		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return dto.toString();
	}

	@RequestMapping(value = "/details/count", method = RequestMethod.GET)
	public String dtotalCount(HttpServletRequest request, @RequestParam("status") String status,
			@RequestParam("customerId") String customerId, @RequestParam("fileId") String fileId,
			@RequestParam("transactionRef") String transactionRef) {
		JSONObject dto = new JSONObject();
		try {
			Principal principal = request.getUserPrincipal();
			String userId = principal.getName();
			String sortOrder = request.getParameter("sortOrder");

			JSONArray list = paymentService.findAllDetails(customerId, fileId, transactionRef, status, "0", "-1");
			dto.put("count", list.size());
		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return dto.toString();
	}

	@RequestMapping(value = "/details/{customerId}/{fileId}/{tranId}", method = RequestMethod.GET)
	public String get(HttpServletRequest request, @PathVariable("customerId") String customerId,
			@PathVariable("fileId") String fileId, @PathVariable("tranId") String tranId) {
		JSONObject dto = null;
		try {
			Principal principal = request.getUserPrincipal();
			String userId = principal.getName();
			String sortOrder = request.getParameter("sortOrder");

			dto = paymentService.getDetails(customerId, fileId, tranId);

		} catch (Exception e) {
			logger.error("Error : " + e.getMessage(), e);
		}
		return dto.toString();
	}
}
