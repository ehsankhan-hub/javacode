package com.bsf.macug.config;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;

import com.bsf.macug.config.security.CustomUserDetailsService;

/**
 * Created by Prosant.
 */
@ServletComponentScan
@SpringBootApplication
@ComponentScan("com.bsf.macug")
public class SpringBootConfig extends SpringBootServletInitializer{
		
	private static final Logger logger = Logger.getLogger(SpringBootConfig.class.getName());

    
    @Autowired
    CustomUserDetailsService userDetailsService;
	
    public static void main(String[] args) throws Exception {
        SpringApplication.run(SpringBootConfig.class, args);           
    }

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return builder.sources(SpringBootConfig.class);
	}

    
}