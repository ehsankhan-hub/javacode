package com.bsf.macug.config.security;

import java.util.ArrayList;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		ArrayList<GrantedAuthority> lis = new ArrayList<>();
		//lis.add(new SimpleGrantedAuthority("ROLE_CLIENT"));
		//lis.add(new SimpleGrantedAuthority("ROLE_ANDROID_CLIENT"));
		return new User("bsf21200", "Bsf@2033", lis);
	}
}