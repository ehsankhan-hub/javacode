package com.bsf.macug.config.security;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class Test {

	public static void main(String[] args) throws NamingException {
		// TODO Auto-generated method stub
		Hashtable<String, String> ldapEnv = new Hashtable<String, String>();
		//ldapEnv.put(Context.SECURITY_PRINCIPAL, "BSF\\" + "bsf21200");  uid={0},ou=BSF
		ldapEnv.put(Context.SECURITY_PRINCIPAL, "cn=BSF20799,ou=GS280,ou=ITD,dc=BSF,dc=COM");//"uid=bsf21200,OU=isg.bsf,DC=bsf,DC=com"
		ldapEnv.put(Context.SECURITY_CREDENTIALS, "Bsf@2044");
		ldapEnv.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		ldapEnv.put(Context.PROVIDER_URL, "ldap://bsf.com:389/dc=BSF,dc=COM");
		ldapEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
		DirContext ldapContext = new InitialDirContext(ldapEnv);
		ldapContext.close();
		System.out.println("done");
	}
	
	

}
