
public class DoWhileLoop {
	 

	public static void main(String args[]){
		int count=0;
		String fINUpdateResponse=" ";
		boolean processFlag=false;
		do{
		count++;
		
		
		System.out.println("fINUpdateResponse-------"+fINUpdateResponse);
		if(count==3)
		
		break ;
		System.out.println("IF Count is 3 "+processFlag);	
		if(!fINUpdateResponse.equals(" ")){
		processFlag=true;
		System.out.println("Trying to post tuxedo 3 times "+processFlag);
		}
		
		}
		while(!processFlag);
		
		if(!fINUpdateResponse.equals(" ")){
			System.out.println("if condition");
		}
		else{
			System.out.println("else condition");
		}
		
}
}

