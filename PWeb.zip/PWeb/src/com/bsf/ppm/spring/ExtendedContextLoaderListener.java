package com.bsf.ppm.spring;

import java.util.Date;

import javax.servlet.ServletContextEvent;
import org.apache.log4j.Logger;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.ContextLoaderListener;

import com.bsf.ppm.batch.BatchExecutionManager;
import com.bsf.ppm.cache.CacheManager;
import com.bsf.ppm.service.application.ApplicationManagement;
import com.bsf.ppm.spring.SpringAppContext;

/**
 * @author Zakir
 * <p>Web Context Loader Listener Class. 
 * Startup Application and Jobs setup is performed.</p>
 */
public class ExtendedContextLoaderListener extends ContextLoaderListener {
	private static final Logger log = Logger
	.getLogger(ExtendedContextLoaderListener.class);
	/* (non-Javadoc)
	 * @see org.springframework.web.context.ContextLoaderListener#contextDestroyed(javax.servlet.ServletContextEvent)
	 */
	@Override
	public void contextDestroyed(ServletContextEvent event) {
		super.contextDestroyed(event);
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.context.ContextLoaderListener#contextInitialized(javax.servlet.ServletContextEvent)
	 */
	@Override
	public void contextInitialized(ServletContextEvent event) {
		System.out.println("event---"+event);
		System.out.println("event---"+event.getServletContext());
		
		//Call contextInitialized of the super class
		super.contextInitialized(event);
		
		getContextLoader();
		//getContextLoader();
		//custom initialization
		SpringAppContext.setApplicationContext(ContextLoader.getCurrentWebApplicationContext());
		
		//Fetch ApplicaitonManagement Bean from Spring Context
		ApplicationManagement  appManagement = (ApplicationManagement) getContextLoader().getCurrentWebApplicationContext().getBean("applicationManagement");
		//Start all the Applications
		log.info("system try to start applications at:"+new Date());
		appManagement.startAllApplications();
		
		//Register all the Active Jobs
		BatchExecutionManager  batchExecutionManagement = (BatchExecutionManager) getContextLoader().getCurrentWebApplicationContext().getBean("batchExecutionManager");
		//Start all the Applications
		log.info("system try to register jobs at:"+new Date());

		batchExecutionManagement.registerAllJobs();
		
		//Register all the Active Jobs
		CacheManager  staticDataCacheManager = (CacheManager) getContextLoader().getCurrentWebApplicationContext().getBean("staticDataCacheManager");
		log.info("system try to load cache at:"+new Date());


		staticDataCacheManager.refreshAll();

	}

}
