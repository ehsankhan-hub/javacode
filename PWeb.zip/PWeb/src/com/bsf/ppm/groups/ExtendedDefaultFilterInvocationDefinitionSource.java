package com.bsf.ppm.groups;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedHashMap;

import org.springframework.security.ConfigAttributeDefinition;
import org.springframework.security.intercept.web.DefaultFilterInvocationDefinitionSource;
import org.springframework.security.intercept.web.RequestKey;
import org.springframework.security.util.AntUrlPathMatcher;
import org.springframework.security.util.UrlMatcher;

import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.util.JNDIUtil;

public class ExtendedDefaultFilterInvocationDefinitionSource extends
		DefaultFilterInvocationDefinitionSource {


	private ExtendedDefaultFilterInvocationDefinitionSource(UrlMatcher urlMatcher,
			LinkedHashMap<RequestKey, ConfigAttributeDefinition> map) {
		super(urlMatcher, map);
	}
	
	public static ExtendedDefaultFilterInvocationDefinitionSource getInstance()	throws DAOException,Exception{
		
		LinkedHashMap<RequestKey, ConfigAttributeDefinition> urls = new LinkedHashMap<RequestKey, ConfigAttributeDefinition>();
		Connection conn = JNDIUtil.getSimpleDBConnection();
		if(conn !=null)	{
			
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select url,objectname from business_object where objectstatus='1' order by objectlevel desc");
			String url = null;
			String objectName = null;
			if(rs!= null){
				
				while(rs.next())	{
					
					url = rs.getString("url");
					objectName = rs.getString("objectname");
					urls.put(new RequestKey(url!=null?url:""), new ConfigAttributeDefinition("ROLE_"+objectName.toUpperCase()));
				}
			}
		}
		return new ExtendedDefaultFilterInvocationDefinitionSource(new AntUrlPathMatcher(),urls);
	}

}
