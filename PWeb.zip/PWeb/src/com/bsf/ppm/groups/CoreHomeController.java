package com.bsf.ppm.groups;

import com.bsf.ppm.constants.IConstants;

public class CoreHomeController {
	
	public String logOut()	{
		
		return IConstants.LOGOUT_URL;
	}

}
