package com.bsf.ppm.groups;

import java.util.List;

/**
 * 
 * @author bsaleem
 *
 */
public class UserADGroupsBean {
	
	private List<String> userADGroups;

	public UserADGroupsBean() {
		
	}
	
	public List<String> getUserADGroups() {
		return userADGroups;
	}

	public void setUserADGroups(List<String> userADGroups) {
		this.userADGroups = userADGroups;
	}
}
