package com.bsf.ppm.groups;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.richfaces.model.TreeNodeImpl;

import com.bsf.ppm.BusinessObject;

@SuppressWarnings("hiding")
public class ExtendedTreeNodeImpl<ExtendedTreeNodeImpl> extends TreeNodeImpl<ExtendedTreeNodeImpl> {
	
	private int childrenSize;
	
	public List<ExtendedTreeNodeImpl> getChildrenList() {
		
		Iterator itr = getChildren();
		List<ExtendedTreeNodeImpl> children = new ArrayList<ExtendedTreeNodeImpl>();
		while(itr.hasNext()){
			
			Map.Entry treeEntry = (Map.Entry)itr.next();
			children.add((ExtendedTreeNodeImpl)treeEntry.getValue());
		}
		return children;
	}

	public int getChildrenSize() {
		
		Iterator itr = getChildren();
		List<ExtendedTreeNodeImpl> children = new ArrayList<ExtendedTreeNodeImpl>();
		while(itr.hasNext()){
			
			Map.Entry treeEntry = (Map.Entry)itr.next();
			children.add((ExtendedTreeNodeImpl)treeEntry.getValue());
		}
		
		return children.size();
	
	}

	public void setChildrenSize(int childrenSize) {
		this.childrenSize = childrenSize;
	}






	public String toString(){
		if(getData() !=null)
		return ((BusinessObject)getData()).getId()+"";
		return "";
	}
	
}
