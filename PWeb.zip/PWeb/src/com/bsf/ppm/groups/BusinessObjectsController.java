package com.bsf.ppm.groups;

public class BusinessObjectsController {

	private ExtendedTreeNodeImpl<ExtendedTreeNodeImpl> busObjTree;

	public ExtendedTreeNodeImpl<ExtendedTreeNodeImpl> getBusObjTree() {
		return busObjTree;
	}

	public void setBusObjTree(ExtendedTreeNodeImpl<ExtendedTreeNodeImpl> busObjTree) {
		this.busObjTree = busObjTree;
	}
	
}
