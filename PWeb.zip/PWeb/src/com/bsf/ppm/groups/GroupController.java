package com.bsf.ppm.groups;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.richfaces.component.html.HtmlDataTable;
import org.richfaces.model.TreeNode;

import com.bsf.ipp.IPPUTIL;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ipp.dao.jpa.SearchCondition;
import com.bsf.ppm.Application;
import com.bsf.ppm.BackendSystem;
import com.bsf.ppm.BusinessObject;
import com.bsf.ppm.UserGroup;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.ApplicationDAO;
import com.bsf.ppm.dao.BackendSystemDAO;
import com.bsf.ppm.dao.BusinessObjectDAO;
import com.bsf.ppm.dao.GroupDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.jpa.util.BackendUtil;
import com.bsf.web.core.ActiveDirectoryUtil;
import com.sun.faces.util.MessageFactory;

/**
 * @author bsaleem
 * 
 *         This class is for Group Maintenance. Following operations on groups
 *         are served by this class:<br>
 *         1. Add Group<br>
 *         2. View Group Details<br>
 *         3. Edit Group<br>
 *         4. Enable Group<br>
 *         5. Disable Group<br>
 * 
 */

public class GroupController extends AbstractCrudController<UserGroup, Long> {

	private ExtendedTreeNodeImpl businessObjects;
	private GroupDAO groupDAO;

	private List<SelectItem> applicationList;

	private ApplicationDAO appDAO;

	private String applicationId;

	private BusinessObjectDAO busObjectDAO;

	private List<String> adGroupsList;

	private List<String> selectedBusObjects;

	private String adSearchCriteria = "";

	private BackendSystemDAO backendSystemDAO;

	private int adItems;

	private String selectedADMapping;

	/** itemSize (number of items in the list) */
	private int itemsSize;

	/*
	 * return int (itemSize)
	 */
	public int getItemsSize() {
		return getItems().size();
	}

	/**
	 * @return itemSize
	 */
	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}

	public String getAdSearchCriteria() {
		return adSearchCriteria;
	}

	public void setAdSearchCriteria(String adSearchCriteria) {
		this.adSearchCriteria = adSearchCriteria;
	}

	public int getAdItems() {

		if (adGroupsList != null)
			return adGroupsList.size();
		return adItems;
	}

	public BackendSystemDAO getBackendSystemDAO() {
		return backendSystemDAO;
	}

	public void setBackendSystemDAO(BackendSystemDAO backendSystemDAO) {
		this.backendSystemDAO = backendSystemDAO;
	}

	public String getSelectedADMapping() {
		return selectedADMapping;
	}

	public void setSelectedADMapping(String selectedADMapping) {
		this.selectedADMapping = selectedADMapping;
	}

	public List<String> getAdGroupsList() {
		return adGroupsList;
	}

	public void setAdGroupsList(List<String> adGroupsList) {
		this.adGroupsList = adGroupsList;
	}

	public List<String> getSelectedBusObjects() {
		return selectedBusObjects;
	}

	public void setSelectedBusObjects(List<String> selectedBusObjects) {
		this.selectedBusObjects = selectedBusObjects;
	}

	public BusinessObjectDAO getBusObjectDAO() {
		return busObjectDAO;
	}

	public void setBusObjectDAO(BusinessObjectDAO busObjectDAO) {
		this.busObjectDAO = busObjectDAO;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	private ApplicationDAO getAppDAO() {
		return appDAO;
	}

	public void setAppDAO(ApplicationDAO appDAO) {
		this.appDAO = appDAO;
	}

	public GroupDAO getGroupDAO() {
		return groupDAO;
	}

	public void setGroupDAO(GroupDAO groupDAO) {
		this.groupDAO = groupDAO;
	}

	/**
	 * 
	 */
	private UserGroup item;
	/**
	 * 
	 */
	private List<UserGroup> items;

	/**
	 * 
	 */
	public GroupController() {

		item = new UserGroup();
		this.getSearchCriteria().put(getStatusFieldName(),
				Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItems()
	 */
	public List<UserGroup> getItems() {
		if (items == null) {
			reloadItems();
		}
		return items;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getDAO()
	 */
	public PaginatedDAO<UserGroup, Long> getDAO() {
		return groupDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItem(java.lang.Object
	 * )
	 */
	public void setItem(UserGroup item) {
		this.item = item;

	}

	public String showDirectoryGroups() {

		return getClass().getSimpleName() + "_displayEditGroups";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItems(java.util.
	 * List)
	 */
	public void setItems(List<UserGroup> items) {
		this.items = items;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItem()
	 */
	public UserGroup getItem() {
		return item;
	}

	/**
	 * @return ApplicationDAO
	 */
	public GroupDAO getApplicationDAO() {
		return groupDAO;
	}

	public String displayBusinessObjects() {

		return getClass().getSimpleName() + "_showBusiness_objects";
	}

	public String displayEditBusinessObjects() {
		FacesMessage facesMessage = null;
		try {
			String busObjQuery = "select obj from BusinessObject obj where obj.application.applicationName in ('ROOT','"
					+ item.getApplication().getApplicationName()
					+ "') order by obj.id asc";
			List<BusinessObject> busObjects = getBusObjectDAO()
					.executeSimpleQuery(busObjQuery);
			setBusinessObjects(convertBusinessObjectsToTree(busObjects));
			updateBusinessObjectsHierarchies((ExtendedTreeNodeImpl) getBusinessObjects()
					.getParent());
			Set<BusinessObject> temp= getItem().getBusinessObject();
			List<BusinessObject> temp1=new ArrayList<BusinessObject>();
			for(BusinessObject bo:temp)	{
				
				temp1.add(bo);
			}
			updateChildrenCheckBoxes(
					(ExtendedTreeNodeImpl) getBusinessObjects().getParent(),
					temp1);

		} catch (DAOException dao) {

			dao.printStackTrace();
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(),
					"bundles.BusinessErrorMessages",
					"error.displayBusinessObjects", FacesMessage.SEVERITY_ERROR);
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			return "";
		} catch (Exception ge) {

			ge.printStackTrace();
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(),
					"bundles.BusinessErrorMessages",
					"error.displayBusinessObjects", FacesMessage.SEVERITY_ERROR);
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			return "";
		}
			
		return getClass().getSimpleName() + "_showEditBusiness_objects";

	}

	public String searchDirectoryForEdit() {

		searchDirectory();
		return getClass().getSimpleName() + "_displayEditGroups";
	}

	public String searchDirectoryForAdd() {

		searchDirectory();
		return getClass().getSimpleName() + "_displayGroups";
	}

	public void searchDirectory() {

		HttpServletRequest req = (HttpServletRequest) (FacesContext
				.getCurrentInstance().getExternalContext().getRequest());
		HttpSession session = req.getSession(false);
		String userDomain = (String) session.getAttribute("currentUserDomain");
		FacesMessage facesMessage = null;
		if (userDomain == null) {

			// get more information how to set the following message............
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.add.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());

		}
		BackendSystem directorySystem = null;
		try {
			directorySystem = getBackendSystemDAO()
					.getBackendByName(userDomain);
		} catch (DAOException e) {

			// get more information how to set the following message............
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.add.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem(),IPPUTIL.buildExceptionMessage(e));

		}
		if (directorySystem == null) {

			// get more information how to set the following message............
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.add.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());

		}

		String ldapRoot = BackendUtil.getParameterValue(directorySystem,"ldap.root");
		String ldapURL = BackendUtil.getParameterValue(directorySystem,"ldap.url");
		System.out.println("ldapRoot---"+ldapRoot);
		System.out.println("ldapURL---"+ldapURL);
		try {
			setAdGroupsList(new ActiveDirectoryUtil().retrieveLDAPGroups(
					ldapURL, ldapRoot, getAdSearchCriteria()));
		} catch (Exception e) {

			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.add.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem(),IPPUTIL.buildExceptionMessage(e));

		}

	}

	public List<UserGroup> getSelectedItems() {
		List<UserGroup> selectedList = new ArrayList<UserGroup>();
		for (UserGroup item : getItems()) {
			if (item.isSelected())
				selectedList.add(item);
		}
		return selectedList;

	}

	public String saveGroup() {

		List<BusinessObject> busObjects = new ArrayList<BusinessObject>();
		busObjects.add(new BusinessObject(1L));
		getSelectedBusinessObject(businessObjects.getParent(), busObjects);
		FacesMessage facesMessage = null;
		try {
			Set<BusinessObject> temp=new HashSet<BusinessObject>();
			for(BusinessObject bo:busObjects)	{
				
				temp.add(bo);
			}
			item.setBusinessObject(temp);
			getGroupDAO().update(item);
			setApplicationId("CORE");
			reloadItems();

		} catch (DAOException e) {
			e.printStackTrace();
		}
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/**
	 * 
	 * @return
	 */
	public HtmlDataTable getGroupsTable() {
		return (HtmlDataTable) JSFUtil.findComponentInRoot("groupsTable");
	}

	/**
	 * This method used to
	 */
	public String detailSetup() {
		item = (UserGroup) this.getGroupsTable().getRowData();
		return getClass().getSimpleName() + "_detail";
	}

	public HtmlDataTable getUserGroupsTable() {

		return (HtmlDataTable) JSFUtil.findComponentInRoot("userGroupsTable");
	}

	public String editSetup() {

		item = (UserGroup) this.getUserGroupsTable().getRowData();
		setAdSearchCriteria("");
		setAdGroupsList(new ArrayList<String>());
		return getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
	}

	private void updateChildrenCheckBoxes(ExtendedTreeNodeImpl parent,
			List<BusinessObject> busObjects) {

		if (busObjects != null) {

			Iterator itr = parent.getChildren();
			while (itr.hasNext()) {

				Map.Entry treeEntry = (Map.Entry) itr.next();
				ExtendedTreeNodeImpl node = (ExtendedTreeNodeImpl) treeEntry
						.getValue();
				for (BusinessObject busObj : busObjects) {

					if (busObj.getId().equals(
							((BusinessObject) node.getData()).getId())) {

						((BusinessObject) node.getData()).setSelected(true);
					}
				}
				updateChildrenCheckBoxes(node, busObjects);
			}
		}
	}

	/**
	 * 
	 */
	public String createSetup() {

		Map<String, String> filterCriteria = new TreeMap<String, String>();
		filterCriteria.put("objectstatus", IConstants.STATUS_TYPE.ACTIVE
				.ordinal()
				+ "");
		// setApplicationId(1l);
		setAdSearchCriteria("");
		setAdGroupsList(new ArrayList());
		item = new UserGroup();
		return getClass().getSimpleName() + "_create";
	}

	/**
	 * @param context
	 * @param componant
	 * @param value
	 */
	public void validateForm(FacesContext context, UIComponent component,
			Object value) {
		if (value == null)
			return;
		FacesMessage message = null;
		String componentId = component.getId();
		int valueLength = value.toString().length();
		if (value instanceof String) {
			value=vaildateChars((String) value,context,componentId);
		}
		if (componentId.equalsIgnoreCase("name")) {
			if (valueLength < 1 || valueLength > 60) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context, "bic.chars",
						FacesMessage.SEVERITY_ERROR, componentId, 12);
				throw new ValidatorException(message);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#isUnique()
	 */
	public boolean isUnique() {
		boolean isUnique = false;
		try {
			isUnique = getDAO().isUnique(getItem());
		} catch (DAOException e) {
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.BusinessErrorMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);

		}
		return isUnique;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#create()
	 */
	public String create() {
		FacesMessage facesMessage = null;
		try {

			String busObjQuery = "select obj from BusinessObject obj where obj.application.applicationName in ('ROOT','"
					+ getApplicationId() + "') order by obj.id asc";
			List<BusinessObject> busObjects = getBusObjectDAO()
					.executeSimpleQuery(busObjQuery);
			setBusinessObjects(convertBusinessObjectsToTree(busObjects));
			updateBusinessObjectsHierarchies((ExtendedTreeNodeImpl) getBusinessObjects()
					.getParent());
			Application app = getAppDAO().getById(getApplicationId());
			item.setApplication(app);
			item.setCreatedBy(JSFUtil.getLoggedInUserInfo());
			getItem().setCreatedDate(
					new Timestamp(Calendar.getInstance().getTimeInMillis()));
			item.setStatus(Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
			getDAO().save(item);

		} catch (Exception e) {

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.add.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem(),IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);
			e.printStackTrace();
			// Return Navigation case of the create page
			return "";
		}
		return getClass().getSimpleName() + "_displayGroups";
	}

	private void updateBusinessObjectsHierarchies(
			ExtendedTreeNodeImpl parentNode) {

		Iterator itr = parentNode.getChildren();
		BusinessObject busObject = null;

		while (itr.hasNext()) {

			Map.Entry treeEntry = (Map.Entry) itr.next();
			ExtendedTreeNodeImpl node = (ExtendedTreeNodeImpl) treeEntry
					.getValue();
			StringBuffer childList = new StringBuffer("");
			buildChildrenList(node, childList);
			busObject = (BusinessObject) node.getData();
			busObject.setChildList(childList.toString());
			updateBusinessObjectsHierarchies(node);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.util
	 * .List)
	 */
	public String[] getIDsArray(List<UserGroup> items) {
		if (items == null || items.size() == 0)
			return null;
		String[] ids = new String[items.size()];
		int i = 0;
		for (UserGroup entity : items) {
			ids[i] = entity.getPk();
			i++;
		}
		return ids;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.lang
	 * .Object)
	 */
	/*public String[] getIDsArray(Bic item) {
		if (item == null)
			return null;
		String[] ids = { item.getId().toString() };
		return ids;
	}*/

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getEntityName()
	 */
	public String getEntityName() {
		return "UserGroup";
	}
	
	/*public List<SelectItem> getApplicationList() throws DAOException {

		List<Application> applications = getAppDAO().findAll("id",true);
		List<SelectItem> selectedItems = new ArrayList<SelectItem>();
		if (applications != null && applications.size() > 1)
			// i start from 1 because 0 is root
			for (int i = 1; i < applications.size(); i++) {

				selectedItems.add(new SelectItem(Long.valueOf(applications.get(i)
						.getId()), applications.get(i).getApplicationName()));
			}
		return selectedItems;
	}
*/
	public static ExtendedTreeNodeImpl<ExtendedTreeNodeImpl> convertBusinessObjectsToTree(
			List<BusinessObject> busObjects) {

		ExtendedTreeNodeImpl<ExtendedTreeNodeImpl> menuTree = new ExtendedTreeNodeImpl<ExtendedTreeNodeImpl>();

		ExtendedTreeNodeImpl rootElement = new ExtendedTreeNodeImpl();

		menuTree.setParent(rootElement);

		ExtendedTreeNodeImpl child = null;

		BusinessObject menuItem = null;

		Map<String, ExtendedTreeNodeImpl> tempNodes = new HashMap<String, ExtendedTreeNodeImpl>();

		int count = 0;

		for (BusinessObject busObj : busObjects) {

			// Expecting root as first element in the bus
			if (count == 0) {

				child = rootElement;
			} else {

				child = new ExtendedTreeNodeImpl();
			}
			child.setData(busObj);
			tempNodes.put("" + busObj.getId(), child);
			if (count != 0) {

				ExtendedTreeNodeImpl currentNodesParent = (ExtendedTreeNodeImpl) tempNodes
						.get("" + busObj.getObjectparent());
				currentNodesParent.addChild(child.toString(), child);
			}
			count++;
		}
		tempNodes.clear();
		return menuTree;
	}

	public ExtendedTreeNodeImpl getBusinessObjects() {
		return businessObjects;
	}

	public void setBusinessObjects(ExtendedTreeNodeImpl businessObjects) {
		this.businessObjects = businessObjects;
	}

	public void getSelectedBusinessObject(TreeNode treeNode,
			List<BusinessObject> bos) {
		if (treeNode != null) {
			Iterator itr = treeNode.getChildren();
			while (itr.hasNext()) {
				Map.Entry treeEntry = (Map.Entry) itr.next();
				ExtendedTreeNodeImpl node = (ExtendedTreeNodeImpl) treeEntry
						.getValue();
				// if(node.getSelected())
				if (((BusinessObject) node.getData()).getSelected())
					bos.add((BusinessObject) node.getData());
				getSelectedBusinessObject(node, bos);

			}
		}

	}

	private void buildChildrenList(ExtendedTreeNodeImpl itemNode,
			StringBuffer childList) {
		if (itemNode != null) {
			Iterator itr = itemNode.getChildren();
			while (itr.hasNext()) {

				Map.Entry treeEntry = (Map.Entry) itr.next();
				ExtendedTreeNodeImpl node = (ExtendedTreeNodeImpl) treeEntry
						.getValue();

				childList.append(
						(((BusinessObject) node.getData())
								.getObjecthierarchyId())).append(",");
				buildChildrenList(node, childList);
			}
		}
	}
	
	public String listSetup() {
		
		// Initialize default values for SearchCriteria and PageInfo
		if (getSearchCriteria() != null) {
			setSearchCriteria(new HashMap<String, Object>());
			getSearchCriteria().put(getStatusFieldName(),
					Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
			//getSearchCriteria().put("name",	"CL%");
		}
		// Set 0 as the first page
		if (getPageInfo() != null){
			getPageInfo().setCurrentPage(0);
			/*getPageInfo().setNumOfPages(0);
			getPageInfo().setNumOfRecords(0);*/
		}
		setSearchCriteria(getSearchCriteria());
		
		// Load the items in the list
		reloadItems();
		// returns the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setSearchCriteria(java
	 * .util.Map)
	 */
	public void setSearchCriteria(Map<String, Object> searchCriteria) {
		setSearchCondition(buildSearchCondtionsObjectsFormCriteriaMap(searchCriteria));
		super.setSearchCriteria(searchCriteria);
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @seecom.bsf.ipp.otms.paymentqueues.OtmsAbstractQueueController#
	 * buildSearchCondtionsObjectsFormCriteriaMap(java.util.Map)
	 */
	public List<SearchCondition> buildSearchCondtionsObjectsFormCriteriaMap(
			Map<String, Object> searchCriteria) {
		List<SearchCondition> searchCondition = new ArrayList<SearchCondition>();
		
		convertStringLikeBasedSearchCriteria(new String[] { "name", "adMapping"}, searchCondition, searchCriteria);
		convertNumberBasedSearchCriteria(new String[] { "status" },	searchCondition, searchCriteria);
		convertStringBasedSearchCriteria(new String[] {"application"}, searchCondition,	searchCriteria);
		
		return searchCondition;		
	}
	
	public void reloadItems() {
		reloadItemsBySearchCondition(getSearchCondition(), null);
	}

}
