package com.bsf.ppm.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.bsf.ppm.service.application.ApplicationManagement;

/**
 * Servlet implementation class ModuleMgmtServlet
 */
public class ModuleMgmtServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger
	.getLogger(ModuleMgmtServlet.class);
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ModuleMgmtServlet() {
		super();       
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String appName = request.getParameter("appId");
		String action = request.getParameter("action");		
		ApplicationManagement applicationManagement = (ApplicationManagement) getServletContext().getAttribute("applicationManagement");
		String hostName = request.getRemoteHost();
		String remoteIPAddr = request.getRemoteAddr();
		String privHost = applicationManagement.getPrivilgedHost();
		if(privHost != null && (privHost.equals(remoteIPAddr) || privHost.equals(hostName)))	{

			if (appName != null){

				if ("stop".equalsIgnoreCase(action)){	
					applicationManagement.stopApplicationByName(appName);
					applicationManagement.deactivateApplicationByName(appName);
				}
				else if ("start".equalsIgnoreCase(action)) {
					applicationManagement.activateApplicationByName(appName);
					applicationManagement.startApplicationByName(appName);
				}				
			}
		}else	{

			log.warn("Ignoring  Illegal Application Control request from IP Adress"+remoteIPAddr);
		}
	}
	
	
}
