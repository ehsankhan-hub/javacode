package com.bsf.ppm.salarypercent;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.richfaces.component.html.HtmlDataTable;

import com.bsf.ipp.GeneralConfiguration;
import com.bsf.ipp.IPPUTIL;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.PpmGroup;
import com.bsf.ppm.Ppm_Instructions;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.InstructionDAO;
import com.bsf.ppm.dao.ParameterValueDAO;
import com.bsf.ppm.dao.PpmGroupDAO;
import com.bsf.ppm.dao.jpa.ParameterValueJpaDAO;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.spring.SpringAppContext;
import com.sun.faces.util.MessageFactory;

/**
 * CRUD Controller Class for the Ppm_Instructions CRUD Operations.
 */
public class SalaryPercentController extends
		AbstractCrudController<Ppm_Instructions, String> {

	/** Attribute ppmGroupDAO DAO object for Ppm_Instructions */
	private PpmGroupDAO ppmGroupDAO;
	
		
	/** Attribute item Ppm_Instructions Entity */
	private Ppm_Instructions item;

	/** Attribute items for Ppm_Instructions Entity List */
	private List<Ppm_Instructions> items;
	
	private ParameterValueDAO parameterValueDAO;
	
	private InstructionDAO instructionDAO;
	
	private String selectedApplication;
	
	/** itemSize (number of items in the list)*/
	private int itemsSize;
	/*
	 * return int (itemSize)
	 */
	public int getItemsSize() {
		return getItems().size();
	}

	/**
	 * @return itemSize
	 */
	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}

	
	/**
	 * Constructor for BatchJobController
	 */
	public SalaryPercentController() {
		//Initialize item object 
		item = new Ppm_Instructions();
		// Initialize default Search criteria
		this.getSearchCriteria().put(getStatusFieldName(), "A");
		
		// Initialize default sort field
		sortField = "instReference";
		sortAscending=true;
	}

	/**
	 * @return the ppmGroupDAO
	 */
	public PpmGroupDAO getPpmGroupDAO() {
		return ppmGroupDAO;
	}

	/**
	 * @param ppmGroupDAO the ppmGroupDAO to set
	 */
	public void setPpmGroupDAO(PpmGroupDAO ppmGroupDAO) {
		this.ppmGroupDAO = ppmGroupDAO;
	}
	
	

	/**
	 * @return the selectedApplication
	 */
	public String getSelectedApplication() {
		return selectedApplication;
	}

	/**
	 * @param selectedApplication the selectedApplication to set
	 */
	public void setSelectedApplication(String selectedApplication) {
		this.selectedApplication = selectedApplication;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItems()
	 */
	public List<Ppm_Instructions> getItems() {
		if (items == null) {
			reloadItems();
		}
		return items;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getDAO()
	 */
	public PaginatedDAO<Ppm_Instructions, String> getDAO() {
		return instructionDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItem(java.lang.Object
	 * )
	 */
	public void setItem(Ppm_Instructions item) {
		this.item = item;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItems(java.util.
	 * List)
	 */
	public void setItems(List<Ppm_Instructions> items) {
		this.items = items;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItem()
	 */
	public Ppm_Instructions getItem() {
		return item;
	}
	
	
	public ParameterValueDAO getParameterValueDAO() {
		return parameterValueDAO;
	}

	public void setParameterValueDAO(ParameterValueDAO parameterValueDAO) {
		this.parameterValueDAO = parameterValueDAO;
	}

	public void setInstructionDAO(InstructionDAO instructionDAO) {
		this.instructionDAO = instructionDAO;
	}

	public InstructionDAO getInstructionDAO() {
		return instructionDAO;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getSelectedItems()
	 */
	public List<Ppm_Instructions> getSelectedItems() {
		List<Ppm_Instructions> selectedList = new ArrayList<Ppm_Instructions>();
		//Get the List of selected items from the dataTable
		for (Ppm_Instructions item : getItems()) {
			
			// Add item to the selectedList if the item is selected
			if (item.isSelected()){
				System.out.println("Selected Item groupcode="+item.getInstReference());
				selectedList.add(item);
			}
		}
		return selectedList;

	}
	
	public String[] getIDsArray(Ppm_Instructions item) {
		// return null if item is null 
		if (item == null) {
			return null;
		}
		//Build the idsArray
		System.out.println("item.InstReference() "+item.getInstReference() );
		String[] ids = { item.getInstReference() };
		return ids;
	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItem()
	 */
	public String disableItem() {
		FacesMessage facesMessage = null;
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getItem());
		
		for(int i=0;i<idArrays.length;i++){
			System.out.println("disableItem idArrays="+idArrays[i]);
		}

		if (idArrays != null && idArrays.length > 0) {
			try {
				
			int update=	getInstructionDAO().updateEntityStatusByIds(idArrays,getIdFieldName(),
						getStatusFieldName(),  "CLS", JSFUtil.getLoggedInUserInfo());
			if(update==1){	
				getInstructionDAO().updateStagingTable(getItem().getCustCode() , "D");
			}
				
			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil
				.getMessage(FacesContext.getCurrentInstance(),
						"bundles.UIMessages",
						"entity.deActivateItem.error",
						FacesMessage.SEVERITY_ERROR, getItem(),
						getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"entity.deleteItem", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.deActivateItem.success",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage("successDeleteItem",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItem()
	 */
	public String enableItem() {
		FacesMessage facesMessage = null;
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getItem());
		System.out.println("=====AbstractCrudController. enableItem ");
		for(int i=0;i<idArrays.length;i++){
			System.out.println("disableItem idArrays="+idArrays[i]);
		}

		if (idArrays != null && idArrays.length > 0) {
			try {
				// Activate the items from the Instructions  Table
				// getStatusFieldName should be implemented in subclass
				int update=getInstructionDAO().updateEntityStatusByIds(idArrays, getIdFieldName(),
						getStatusFieldName(), "ACT", JSFUtil.getLoggedInUserInfo());
				if(update==1){
				getInstructionDAO().updateStagingTable(getItem().getCustCode() , "A");
		        }

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil
				.getMessage(FacesContext.getCurrentInstance(),
						"bundles.UIMessages",
						"entity.activateItem.error",
						FacesMessage.SEVERITY_ERROR, getItem(),
						getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"activateItem.error", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.activateItem.success",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage(
				"itemActivatedSuccessfully", facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	
	
	
	
	
	
	
	/**
	 * 
	 * @return HtmlDataTable representing ppmGroupTable
	 */
	public HtmlDataTable getPpmGroupTable() {
		return (HtmlDataTable) JSFUtil.findComponentInRoot("ppmGroupTable");
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String listSetupString() {

		// Initialize default values for SearchCriteria and PageInfo
		if (getSearchCriteria() != null) {
			setSearchCriteria(new HashMap<String, Object>());
			
			getSearchCriteria().put(getStatusFieldName(),"ACT");
			//StringBuffer sb=new StringBuffer();
			//sb.append("is not null");
			//getSearchCriteria().put("custCode", sb);
		}
		// Set 0 as the first page
		if (getPageInfo() != null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		reloadItems();
		// returns the Navigation case for list page
		System.out.println(getClass().getSimpleName());
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	@Override
	public String editSetup() {
	
		return getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String detailSetup() {
		//Get the Item to be passed to Detail page
		item = (Ppm_Instructions) this.getPpmGroupTable().getRowData();
		//Forward to detail Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#createSetup()
	 */
	public String createSetup() {
		// create a new instance of item
		item = new Ppm_Instructions();
		//Forward to create Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_CREATE_NAVIGATION;
	}

	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#isUnique()
	 */
	public boolean isUnique() {
		boolean isUnique = false;
		try {
			//Check if the item is Unique in the Table
			isUnique = getDAO().isUnique(getItem());
		} catch (DAOException e) {
			
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.BusinessErrorMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUnique;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#create()
	 */
	/*public String create() {
		FacesMessage facesMessage = null;
		String nav = "";
		try {
			//Set userInfo for CurrencyCode
			item.setCreatedBy(JSFUtil.getLoggedInUserInfo().getUserId());
			//Set create Date
			item.setCreateDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						
			//set Status as Active
			item.setStatus("A");
			//Set navigation case from super.create
			nav = super.create();
		
		} catch (Exception e) {

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.add.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);
			//Print StackTrace
			e.printStackTrace();
			// Return Navigation case of the create page
			return "";
		}

		return nav;
	}*/

	/**
	 * Update the entity in the database. Serves user update action on Edit page.
	 * @return List page Navigation case defined in faces-config.xml
	 */
	@Override
	public String update() {
		//FacesMessage facesMessage = null;
		// set update information
		getItem().setUpdatedBy(JSFUtil.getLoggedInUserInfo().getUserId());
		//getItem().setUpdateDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				
		//call super.update
		String navigationCase = super.update();
		
		
		
		return navigationCase;
	}
	
	

	



	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getEntityName()
	 */
	public String getEntityName() {
		return "Ppm Instructions";
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getStatusFieldName()
	 */
	public String getStatusFieldName() {
		return "status";

	}	
	
	public String getIdFieldName() {
		return "instReference";
	}
	
	
	public void reloadItems() {
		reloadItemsBySearchCriteria(getSearchCriteria());
	}
	
	
	protected  void reloadItemsBySearchCriteria(Map<String, Object> searchCriteria) {
		FacesMessage facesMessage = null;
		try {
              System.out.println("searchCriteria=="+searchCriteria );
			/*** if search criteria is set. Filter data by search criteria ***/
			if (searchCriteria != null && searchCriteria.size() > 0) {
				// Set total number of Items fetched after the search criteria
				// is applied
				//searchCriteria.put("custCode", "");
				
				
				getPageInfo().setNumOfRecords((int) getDAO().getResultSizeforSalaryPercent(searchCriteria));

				// Add one to the number of pages, if (total records) %
				// batchSize >0
				if (getPageInfo().getNumOfRecords()
						% getPageInfo().getBatchSize() > 0) {
					getPageInfo().setNumOfPages(
							(getPageInfo().getNumOfRecords() / getPageInfo()
									.getBatchSize()) + 1);
				} else {
					// Number of pages = (total records)/batchSize.
					// getBatchSize() returns 1 even if batch size is set to
					// Zero
					getPageInfo().setNumOfPages(
							getPageInfo().getNumOfRecords()/ getPageInfo().getBatchSize());
				}
				// Set the List of Items fetched after the search
				setItems(getDAO().searchByPagesSalaryPercen(searchCriteria,(getPageInfo().getCurrentPage() * getPageInfo().getBatchSize()), getPageInfo().getBatchSize(),sortField, sortAscending));

			} else {
				/*** No search Criteria is specified ***/
				// Set total number of Items fetched after the search criteria
				// is applied
				getPageInfo().setNumOfRecords((int) getDAO().getResultSize());

				// Add one to the number of pages, if (total records) %
				// batchSize >0
				if (getPageInfo().getNumOfRecords()
						% getPageInfo().getBatchSize() > 0) {
					getPageInfo().setNumOfPages(getPageInfo().getNumOfRecords()/ getPageInfo().getBatchSize() + 1);
				} else {
					// Number of pages = (total records)/batchSize.
					// getBatchSize() returns 1 even if batch size is set to
					// Zero
					getPageInfo().setNumOfPages(getPageInfo().getNumOfRecords()/ getPageInfo().getBatchSize());
				}
				// Set the List of Items fetched
				setItems(getDAO().searchByPages((getPageInfo().getCurrentPage() * getPageInfo().getBatchSize()), getPageInfo().getBatchSize(),sortField, sortAscending));
			}
		} catch (ApplicationException e) {
			e.printStackTrace();

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.retrieve", FacesMessage.SEVERITY_ERROR, getItem());
			FacesContext.getCurrentInstance().addMessage("retrieveError",
					facesMessage);
		} catch (Exception e) {
			e.printStackTrace();
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"controller.generalException", FacesMessage.SEVERITY_ERROR,
					getEntityName(), IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);

		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#searchSetup()
	 */
	public String searchSetup() {

		// Set PageInfo with current Page 0
		getPageInfo().setCurrentPage(0);

		// Set the search criteria
		setSearchCriteria(prepareSearchCriteria());

		// Reload the items in the list
		reloadItems();
		
		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
	
    
	
	

	
	
	
	
}
