package com.bsf.ppm.reports.trnsaction;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;
import javax.servlet.http.HttpServletRequest;

import org.richfaces.component.html.HtmlDataTable;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.GErrorList;
import com.bsf.ppm.PpmParameterValuesSetup;
import com.bsf.ppm.Ppm_Inst_Transactions;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.GErrorListDAO;
import com.bsf.ppm.dao.InstTransactionsDAO;
import com.bsf.ppm.dao.ParameterValueDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.exceptions.InvalidDataException;
import com.bsf.ppm.util.DateUtils;
import com.sun.faces.util.MessageFactory;

/**
 * CRUD Controller Class for the PpmGroup CRUD Operations.
 */
public class TransactionReportController extends
		AbstractCrudController<Ppm_Inst_Transactions, String> {

	/** Attribute InstTransactionsDAO DAO object for instTransactionsDAO */
	private InstTransactionsDAO instTransactionsDAO;
	
	
	
	/** Attribute item Ppm_Inst_Transactions Entity */
	private Ppm_Inst_Transactions item;
	
	
	/** Attribute items for Ppm_Inst_Transactions Entity List */
	private List<Ppm_Inst_Transactions> items;
	
	private String tansRefer;
	private String status;
	
	private ParameterValueDAO parameterValueDAO;
	
    private GErrorListDAO gErrorListDAO;
		
	private String selectedApplication;
		
	private String validateForm;
	private String reportFormat;
	private Date firstInstDate;
	private Date lastInstDate;
	private int rulesSize=0;
	private UserInfo user;
	//private Ppm_Inst_Transactions ppmInstTransaction=new Ppm_Inst_Transactions();
	private GErrorList gErrorList=null;
	private ArrayList<SelectItem> list =null;
	
	private List<Ppm_Inst_Transactions>transReportResults=null;

	public String getValidateForm() {
		return validateForm;
	}

	public void setValidateForm(String validateForm) {
		this.validateForm = validateForm;
	}
 
	public Date getFirstInstDate() {
		return firstInstDate;
	}

	public void setFirstInstDate(Date firstInstDate) {
		this.firstInstDate = firstInstDate;
	}

	public Date getLastInstDate() {
		return lastInstDate;
	}

	public void setLastInstDate(Date lastInstDate) {
		this.lastInstDate = lastInstDate;
	}

	
	public void setTransReportResults(List<Ppm_Inst_Transactions> transReportResults) {
		this.transReportResults = transReportResults;
	}
    
	public int getRulesSize() {
		return rulesSize;
	}

	public void setRulesSize(int rulesSize) {
		this.rulesSize = rulesSize;
	}
	
	/**
	 * Constructor for BatchJobController
	 */
	public TransactionReportController() {
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		String fromDateFormated = null;
		firstInstDate=new Date();	
		if (firstInstDate != null) {
			fromDateFormated = formatter.format(firstInstDate);
			System.out.println("firstInstDate=="+fromDateFormated);
			//toDateFormated = formatter.format(lastInstDate);
		}
		//Initialize item object 
		item = new Ppm_Inst_Transactions();
		// Initialize default Search criteria
		System.out.println("getStatusFieldName="+getStatusFieldName());
		this.getSearchCriteria().put(getStatusFieldName(), "A");
		user = JSFUtil.getLoggedInUserInfo();
		// Initialize default sort field
		sortField = "instRef";
		sortAscending=true;
	}
   
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String listSetupString() {
		// Initialize default values for SearchCriteria and PageInfo
		if (getSearchCriteria() != null) {
			setSearchCriteria(new HashMap<String, Object>());
			getSearchCriteria().put(getStatusFieldName()," ");
		}
		// Set 0 as the first page
		if (getPageInfo() != null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		reloadInstTrans();
		firstInstDate=null;
		lastInstDate=null;
		item=new Ppm_Inst_Transactions();
		
		return getClass().getSimpleName() +IConstants.CRUD_INQUERY_TRNS_LIST_NAVIGATION;
		
	}

	public UserInfo getUser() {
		return user;
	}

	public void setUser(UserInfo user) {
		this.user = user;
	}
    	
	public String getReportFormat() {
		return reportFormat;
	}

	public void setReportFormat(String reportFormat) {
		this.reportFormat = reportFormat;
	}

	public String searchSetup() {
		FacesMessage facesMessage = null;
		// fromDate todate validation for (To Date should be greater or equal to From Date)
		
		if (firstInstDate != null && lastInstDate != null) {
			if (DateUtils.computeDateDifference(firstInstDate, lastInstDate) < 0) {
				facesMessage = JSFUtil
						.getMessage(FacesContext.getCurrentInstance(),
								"bundles.UIMessages",
								"entity.date.dataNotValid",
								FacesMessage.SEVERITY_ERROR, getEntityName(),
								getItem());
				FacesContext.getCurrentInstance().addMessage(
						"searchMessageError", facesMessage);
				reloadItemsDateRange("trnsDate", null, null);
				return getClass().getSimpleName()+ IConstants.CRUD_LIST_NAVIGATION;
			}
		}
		// toDate null validation
		if (firstInstDate != null && lastInstDate == null){	
			facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
								"bundles.UIMessages",
								"entity.date.toDateNull",
								FacesMessage.SEVERITY_ERROR, getEntityName(),
								getItem());
				FacesContext.getCurrentInstance().addMessage(
						"searchMessageError", facesMessage);
				reloadItemsDateRange("trnsDate", null, null);
				return getClass().getSimpleName()+ IConstants.CRUD_LIST_NAVIGATION;
		}
		// fromDate null validation
		if (lastInstDate != null && firstInstDate == null){	
			facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
								"bundles.UIMessages",
								"entity.date.fromDateNull",
								FacesMessage.SEVERITY_ERROR, getEntityName(),
								getItem());
				FacesContext.getCurrentInstance().addMessage(
						"searchMessageError", facesMessage);
				reloadItemsDateRange("trnsDate", null, null);
				return getClass().getSimpleName()+ IConstants.CRUD_LIST_NAVIGATION;

		}

		// Set PageInfo with current Page 0
		getPageInfo().setCurrentPage(0);
		// Set the search criteria
		setSearchCriteria(prepareSearchCriteria());
		// reload reloadInstTrans
		reloadInstTrans();
		// return the Navigation case for list page
		return getClass().getSimpleName()+ IConstants.CRUD_LIST_NAVIGATION;
	}
	
	private void reloadInstTrans()
	{
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		String fromDateFormated = null;
		String toDateFormated = null;
		
		if (firstInstDate != null && lastInstDate != null) {
			fromDateFormated = formatter.format(firstInstDate);
			System.out.println("firstInstDate=="+fromDateFormated);
			toDateFormated = formatter.format(lastInstDate);
		}
		System.out.println("--fromDateFormated="+fromDateFormated+" -- toDateFormated"+toDateFormated);
		
		reloadItemsCurrentAndFutureDateRange("trnsDate", fromDateFormated, toDateFormated);
		
	}

    


	/** itemSize (number of items in the list)*/
	private int itemsSize;
	/*
	 * return int (itemSize)
	 */
	public int getItemsSize() {
		return getItems().size();
	}

	/**
	 * @return itemSize
	 */
	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}
    public ArrayList<SelectItem> getList() {
		return list;
	}

	public void setList(ArrayList<SelectItem> list) {
		this.list = list;
	}
    
		
	public JRDataSource  getDataSource() {
		    GErrorList trnsStatus=null;
			String cammCode;
			String status;
			List<Ppm_Inst_Transactions> itemsUpdate=new ArrayList<Ppm_Inst_Transactions>();
			try{
			if(items!=null){
			System.out.println("items=="+items.size());
			
			Iterator<Ppm_Inst_Transactions> itr=items.iterator();
			while(itr.hasNext()){
			 Ppm_Inst_Transactions	ppmInstTrns= itr.next(); 
			 cammCode=ppmInstTrns.getCammActionCode(); 
			 status=ppmInstTrns.getStatus();
			 if(status.equals("FAIL")){
					status="F";
			 }
			 else if(status.equals("PROCESSED")){
					status="P";	
			 }
			 else if(status.equals("N")){
				 status="Pending";		 
			 }
			 System.out.println("cammCode=="+cammCode);
			 //cammCode="0110";
			 if(cammCode!=null){
			  if(!cammCode.equalsIgnoreCase("0000")){	 
			  Map<String, Object> map=new HashMap<String, Object>();
		      map.put("errorCode", cammCode);
		      trnsStatus=getgErrorListDAO().getByCriteria(map);
		      System.out.println("trnsStatus="+trnsStatus.getErrorMsg());
		      ppmInstTrns.setCammErrorDes(trnsStatus.getErrorMsg());
		      itemsUpdate.add(ppmInstTrns);
			  }
			  else if("P".equalsIgnoreCase(status.trim())){
			  ppmInstTrns.setCammErrorDes("Successfully Processesd");
			  itemsUpdate.add(ppmInstTrns);
			  }
			 
			  }
			 else if("Pending".equalsIgnoreCase(status.trim())){
			 ppmInstTrns.setCammErrorDes("Transaction pending for process");
		     itemsUpdate.add(ppmInstTrns);
			 }
			  }
			 reloadItems();
			 }
			 }
		     	 catch(DAOException de){
		         de.printStackTrace();
		         }
		         catch(InvalidDataException ine){
		         ine.printStackTrace();
		         }
	return  new JRBeanCollectionDataSource(itemsUpdate);
	}
	
	/**
	 * @return the selectedApplication
	 */
	public String getSelectedApplication() {
		return selectedApplication;
	}

	/**
	 * @param selectedApplication the selectedApplication to set
	 */
	public void setSelectedApplication(String selectedApplication) {
		this.selectedApplication = selectedApplication;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItems()
	 */
	public List<Ppm_Inst_Transactions> getItems() {
		
		if (items == null) {
			
		reloadInstTrans();
					
		}
		return items;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getDAO()
	 */
	public PaginatedDAO<Ppm_Inst_Transactions, String> getDAO() {
		
		return instTransactionsDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItem(java.lang.Object
	 * )
	 */
	public void setItem(Ppm_Inst_Transactions item) {
		this.item = item;

	}
   

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItems(java.util.
	 * List)
	 */
	public void setItems(List<Ppm_Inst_Transactions> items) {
		this.items = items;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItem()
	 */
	public Ppm_Inst_Transactions getItem() {
		return item;
	}
	
	
	
	public ParameterValueDAO getParameterValueDAO() {
		return parameterValueDAO;
	}

	public void setParameterValueDAO(ParameterValueDAO parameterValueDAO) {
		this.parameterValueDAO = parameterValueDAO;
	}
    	
	public GErrorListDAO getgErrorListDAO() {
		return gErrorListDAO;
	}

	public void setgErrorListDAO(GErrorListDAO gErrorListDAO) {
		this.gErrorListDAO = gErrorListDAO;
	}

	public InstTransactionsDAO getInstTransactionsDAO() {
		return instTransactionsDAO;
	}

	public void setInstTransactionsDAO(InstTransactionsDAO instTransactionsDAO) {
		this.instTransactionsDAO = instTransactionsDAO;
	}
    
	@Override
	public String update() {
		
	    try{
		getInstTransactionsDAO().updateInstTransactionsStatus(tansRefer,"N");	
		//String navigationCase = super.update();
	    }
	    catch(DAOException dae){
	    	dae.printStackTrace();
	    }
		
		// Reload the items in the list
		reloadInstTrans();

				// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
	   
    
    /* Edit page of Transaction Details 
	 */
	public String editSetup() {
		
		
		//Get the Item to be passed to Edit page
		 item = (Ppm_Inst_Transactions) this.getTransactionReportTable().getRowData();
		 tansRefer=item.getPpmTrnsRef();
         String cammCode=item.getCammActionCode(); 
         
         status=item.getStatus();
        /* if(status.equals("Pending")){
        	 status="N";
         }
         else if(status.equals("PROCESSED")){
        	 status="P";
         }
         else if(status.equals("FAIL")){
        	 status="F";
         }
         else if(status.equals("ERROR")){
        	 status="E";
         }*/
         System.out.println("status---"+status);
         
         if(cammCode!=null&&!cammCode.equalsIgnoreCase("0000")){
         System.out.println("camm Action Code="+cammCode);
         try{
         Map<String, Object> map=new HashMap<String, Object>();
     	 map.put("errorCode", cammCode);
     	gErrorList=getgErrorListDAO().getByCriteria(map);
     	FacesContext.getCurrentInstance().addMessage("beneficiaryacc", new FacesMessage("CAMM Error Code:  "+cammCode));
     	FacesContext.getCurrentInstance().addMessage("beneficiaryname", new FacesMessage("CAMM Error Description:  "+gErrorList.getErrorMsg()));
     	}
        catch(DAOException de){
        de.printStackTrace();
        if(cammCode!=null){
        FacesContext.getCurrentInstance().addMessage("beneficiaryacc", new FacesMessage("CAMM Error Code:  "+cammCode));
     	FacesContext.getCurrentInstance().addMessage("beneficiaryname", new FacesMessage("CAMM Error Description:  "+gErrorList.getErrorMsg()));
        }
     	return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
        }
        catch(InvalidDataException ine){
        ine.printStackTrace();
        if(cammCode!=null){
        FacesContext.getCurrentInstance().addMessage("beneficiaryacc", new FacesMessage("CAMM Error Code:  "+cammCode));
      	FacesContext.getCurrentInstance().addMessage("beneficiaryname", new FacesMessage("CAMM Error Description:  "+gErrorList.getErrorMsg()));
        }
      	return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;	
        }
        }
        //If Transaction is successful tuxedo returns 0000 
        else if(cammCode!=null&&cammCode.equalsIgnoreCase("0000")){
        FacesContext.getCurrentInstance().addMessage("beneficiaryacc", new FacesMessage("Transction Processesd Successfully for referecne number :  "+item.getInstRef()));
        }
        else if("Pending".equalsIgnoreCase(status)){
        FacesContext.getCurrentInstance().addMessage("beneficiaryacc", new FacesMessage("Transction Pending for Process referecne number:  "+item.getInstRef()));
        }
        else if("ERROR".equalsIgnoreCase(status)){
        FacesContext.getCurrentInstance().addMessage("beneficiaryacc", new FacesMessage("Transction processed with error for referecne number:  "+item.getInstRef()));
        }
       /* else if("FAIL".equalsIgnoreCase(status)){
        FacesContext.getCurrentInstance().addMessage("beneficiaryacc", new FacesMessage("Transction Failed for referecne number:  "+ppmInstTransaction.getInstRef()));
        } */
         
     	//Forward to edit Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
	}
	
	/**
	 * 
	 * @return HtmlDataTable representing backendSystem Table
	 */
	public HtmlDataTable getTransactionReportTable() {
		return (HtmlDataTable) JSFUtil.findComponentInRoot("transReportTable");
	}
       
  
		
	/**
	 * @param context FacesContext reference 
	 * @param component component that fired the event
	 * @param value Value of the UI Component
	 */
	
	public void validateForm(FacesContext context, UIComponent component,
			Object value) {
		
		FacesMessage message = null;
		String componentId = component.getId();
		int valueLength;
		
		// Do not process if the value is null
		if (value == null) {
			return;
		}
		else {
			valueLength=value.toString().length();
		}
		
		//Validate for miscellaneous characters 
		if ((componentId.equalsIgnoreCase("groupCode") || componentId.equalsIgnoreCase("groupDesc")
				|| componentId.equalsIgnoreCase("groupName"))
				&& (value instanceof String)) {
			value=vaildateChars((String) value,context,componentId);
		}
		
		//Validation for groupCode component
		if (componentId.equalsIgnoreCase("groupCode")) {
			//Check length
			if (valueLength >5 ) {
				
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupCode.chars",FacesMessage.SEVERITY_ERROR, componentId,5);
				throw new ValidatorException(message);
			}
		}//Validation for groupDesc component 
		else if (componentId.equalsIgnoreCase("groupDesc")) {
			//Check length
			if (valueLength >50 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupDesc.chars",FacesMessage.SEVERITY_ERROR, componentId, 50);
				throw new ValidatorException(message);
			}
		}//Validation for groupName component
		else if (componentId.equalsIgnoreCase("groupName")) {
			//Check length
			if (valueLength >30 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.jobDescription.chars",FacesMessage.SEVERITY_ERROR, componentId, 30);
				throw new ValidatorException(message);
			}
		}
	}
	
	public String getEntityName() {
		return "Ppm_Inst_Transactions";
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getStatusFieldName()
	 */
	public String getStatusFieldName() {
		return "status";

	}	
	
	public String getIdFieldName() {
		return "instRef";
	}
	
	public String cancel() {
		// Set the page number in PaginationInfo to Zero
		// getPageInfo().setCurrentPage(0);

		// Reload the items in the list
		reloadInstTrans();

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
	
	

	@Override
	public List<Ppm_Inst_Transactions> getSelectedItems() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String createSetup() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String detailSetup() {
		// TODO Auto-generated method stub
		item = (Ppm_Inst_Transactions) this.getTransactionReportTable().getRowData();
		//item.setUpdatedBy(JSFUtil.getLoggedInUserInfo().getUserId());
		//item.setUpdateDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
	
		//Forward to detail Navigation case
		
		
		 FacesContext context = FacesContext.getCurrentInstance();
		    HttpServletRequest origRequest = (HttpServletRequest)context.getExternalContext().getRequest();
		String  contextPath = origRequest.getContextPath();
		try {
		        FacesContext.getCurrentInstance().getExternalContext()
		                .redirect(contextPath  + "/ppm/blockUnblock/editEmpCategorySetup.jsf");
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		
		
		
		
		//not being used
		return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
		
	}
	
	public String displayPage() {
		reloadInstTrans();
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;

	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#next()
	 */
	public String next() {

		// Set the page number in PaginationInfo
		getPageInfo().setCurrentPage(getPageInfo().getCurrentPage() + 1);

		// Reload the items in the list
		reloadInstTrans();

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#prev()
	 */
	public String prev() {

		// Set the page number in PaginationInfo
		if (getPageInfo().getCurrentPage() > 0) {
			getPageInfo().setCurrentPage(getPageInfo().getCurrentPage() - 1);
		}
		// Reload the items in the list
		reloadInstTrans();

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}


	
	
	
	
		
	
	    
		
	
}
