package com.bsf.ppm.reports.trnsaction;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import java.util.HashMap;

import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;
import org.richfaces.component.html.HtmlDataTable;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.GErrorList;
import com.bsf.ppm.IncomingSalaries;
import com.bsf.ppm.Ppm_Inst_Transactions;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.GErrorListDAO;
import com.bsf.ppm.dao.IncomingSalaryDAO;
import com.bsf.ppm.dao.InstTransactionsDAO;
import com.bsf.ppm.dao.ParameterValueDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.exceptions.InvalidDataException;
import com.bsf.ppm.util.DateUtils;
import com.sun.faces.util.MessageFactory;

/**
 * CRUD Controller Class for the PpmGroup CRUD Operations.
 */
public class IncomingSalaryReportController extends
		AbstractCrudController<IncomingSalaries, String> {

	/** Attribute InstTransactionsDAO DAO object for instTransactionsDAO */
	private InstTransactionsDAO instTransactionsDAO;
	
	
	
	/** Attribute item IncomingSalaries Entity */
	private IncomingSalaries item;
	
	private Ppm_Inst_Transactions ppmTrans=new Ppm_Inst_Transactions();
	
	
	/** Attribute items for IncomingSalaries Entity List */
	private List<IncomingSalaries> items;
	
	
	
	private IncomingSalaryDAO incomingSalaryDAO;
	
    private GErrorListDAO gErrorListDAO;
	
	private String validateForm;
	private String reportFormat;
	private Date firstInstDate;
	private Date lastInstDate;
	private int rulesSize=0;
	private UserInfo user;
	private GErrorList gErrorList=null;
	private ArrayList<SelectItem> list =null;
	
	public String getValidateForm() {
		return validateForm;
	}

	public void setValidateForm(String validateForm) {
		this.validateForm = validateForm;
	}
 
	public Date getFirstInstDate() {
		return firstInstDate;
	}

	public void setFirstInstDate(Date firstInstDate) {
		this.firstInstDate = firstInstDate;
	}

	public Date getLastInstDate() {
		return lastInstDate;
	}

	public void setLastInstDate(Date lastInstDate) {
		this.lastInstDate = lastInstDate;
	}

	public int getRulesSize() {
		return rulesSize;
	}

	public void setRulesSize(int rulesSize) {
		this.rulesSize = rulesSize;
	}
	
	/**
	 * Constructor for BatchJobController
	 */
	public IncomingSalaryReportController() {
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		String fromDateFormated = null;
		//firstInstDate=new Date();	
		if (firstInstDate != null) {
			fromDateFormated = formatter.format(firstInstDate);
			System.out.println("firstInstDate=="+fromDateFormated);
			//toDateFormated = formatter.format(lastInstDate);
		}
		//Initialize item object 
		item = new IncomingSalaries();
		// Initialize default Search criteria
		System.out.println("getStatusFieldName="+getStatusFieldName());
		this.getSearchCriteria().put(getStatusFieldName(), "ppp");
		user = JSFUtil.getLoggedInUserInfo();
		// Initialize default sort field
		sortField = "sequenceNum";
		sortAscending=true;
	}
   
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String listSetupString() {
		// Initialize default values for SearchCriteria and PageInfo
		
		if (getSearchCriteria() != null) {
			setSearchCriteria(new HashMap<String, Object>());
			getSearchCriteria().put(getStatusFieldName()," ");
		}
		// Set 0 as the first page
		if (getPageInfo() != null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		reloadInstTrans();
		firstInstDate=null;
		lastInstDate=null;
		item=new IncomingSalaries();
		
		return getClass().getSimpleName() +IConstants.CRUD_INQUERY_TRNS_LIST_NAVIGATION;
		
	}

	public UserInfo getUser() {
		return user;
	}

	public void setUser(UserInfo user) {
		this.user = user;
	}
    	
	public String getReportFormat() {
		return reportFormat;
	}

	public void setReportFormat(String reportFormat) {
		this.reportFormat = reportFormat;
	}

	public String searchSetup() {
		FacesMessage facesMessage = null;
		// fromDate todate validation for (To Date should be greater or equal to From Date)
		
		if (firstInstDate != null && lastInstDate != null) {
			if (DateUtils.computeDateDifference(firstInstDate, lastInstDate) < 0) {
				facesMessage = JSFUtil
						.getMessage(FacesContext.getCurrentInstance(),
								"bundles.UIMessages",
								"entity.date.dataNotValid",
								FacesMessage.SEVERITY_ERROR, getEntityName(),
								getItem());
				FacesContext.getCurrentInstance().addMessage(
						"searchMessageError", facesMessage);
				reloadItemsDateRange("logSystemDate", null, null);
				return getClass().getSimpleName()+ IConstants.CRUD_LIST_NAVIGATION;
			}
		}
		// toDate null validation
		if (firstInstDate != null && lastInstDate == null){	
			facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
								"bundles.UIMessages",
								"entity.date.toDateNull",
								FacesMessage.SEVERITY_ERROR, getEntityName(),
								getItem());
				FacesContext.getCurrentInstance().addMessage(
						"searchMessageError", facesMessage);
				reloadItemsDateRange("logSystemDate", null, null);
				return getClass().getSimpleName()+ IConstants.CRUD_LIST_NAVIGATION;
		}
		// fromDate null validation
		if (lastInstDate != null && firstInstDate == null){	
			facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
								"bundles.UIMessages",
								"entity.date.fromDateNull",
								FacesMessage.SEVERITY_ERROR, getEntityName(),
								getItem());
				FacesContext.getCurrentInstance().addMessage(
						"searchMessageError", facesMessage);
				reloadItemsDateRange("logSystemDate", null, null);
				return getClass().getSimpleName()+ IConstants.CRUD_LIST_NAVIGATION;

		}
       
		// Set PageInfo with current Page 0
		getPageInfo().setCurrentPage(0);
		// Set the search criteria
		setSearchCriteria(prepareSearchCriteria());
		// reload reloadInstTrans
		reloadInstTrans();
       
		// return the Navigation case for list page
		return getClass().getSimpleName()+ IConstants.CRUD_LIST_NAVIGATION;
	}
	
	private void reloadInstTrans()
	{
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		String fromDateFormated = null;
		String toDateFormated = null;
		
		if (firstInstDate != null && lastInstDate != null) {
			fromDateFormated = formatter.format(firstInstDate);
			System.out.println("firstInstDate=="+fromDateFormated);
			toDateFormated = formatter.format(lastInstDate);
		}
		System.out.println("--fromDateFormated="+fromDateFormated+" -- toDateFormated"+toDateFormated);
		
		reloadItemsCurrentAndFutureDateRange("logSystemDate", fromDateFormated, toDateFormated);
		
	}

    


	/** itemSize (number of items in the list)*/
	private int itemsSize;
	/*
	 * return int (itemSize)
	 */
	public int getItemsSize() {
		return getItems().size();
	}

	/**
	 * @return itemSize
	 */
	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}
    public ArrayList<SelectItem> getList() {
		return list;
	}

	public void setList(ArrayList<SelectItem> list) {
		this.list = list;
	}
 
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItems()
	 */
	public List<IncomingSalaries> getItems() {
		
		if (items == null) {
		
	
		reloadInstTrans();
					
		}
	return items;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getDAO()
	 */
	

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItem(java.lang.Object
	 * )
	 */
	public void setItem(IncomingSalaries item) {
		this.item = item;

	}
   

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItems(java.util.
	 * List)
	 */
	public void setItems(List<IncomingSalaries> items) {
		this.items = items;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItem()
	 */
	public IncomingSalaries getItem() {
		return item;
	}
		
	public Ppm_Inst_Transactions getPpmTrans() {
		return ppmTrans;
	}

	public void setPpmTrans(Ppm_Inst_Transactions ppmTrans) {
		this.ppmTrans = ppmTrans;
	}

	public IncomingSalaryDAO getIncomingSalaryDAO() {
		return incomingSalaryDAO;
	}

	public void setIncomingSalaryDAO(IncomingSalaryDAO incomingSalaryDAO) {
		this.incomingSalaryDAO = incomingSalaryDAO;
	}

	public GErrorListDAO getgErrorListDAO() {
		return gErrorListDAO;
	}

	public void setgErrorListDAO(GErrorListDAO gErrorListDAO) {
		this.gErrorListDAO = gErrorListDAO;
	}

	public InstTransactionsDAO getInstTransactionsDAO() {
		return instTransactionsDAO;
	}

	public void setInstTransactionsDAO(InstTransactionsDAO instTransactionsDAO) {
		this.instTransactionsDAO = instTransactionsDAO;
	}

	   
    
    /* Edit page of Transaction Details 
	 */
	public String editSetup() {
		System.out.println("editSetup==");
		FacesMessage message = null;
		//Get the Item to be passed to Edit page
		item = (IncomingSalaries) this.getTransactionReportTable().getRowData();
		try{
			
			
			
			
		ppmTrans= getInstTransactionsDAO().getInstTransaction(item.getLongRef());
		System.out.println("ppmTrans=SATAUS="+ppmTrans.getStatus());
		
		
		
		
		
		}
		catch(DAOException de){
		if(ppmTrans==null){
		FacesContext.getCurrentInstance().getApplication()
			.setMessageBundle("bundles.ValidatorMessages");
	    message = MessageFactory.getMessage(FacesContext
			.getCurrentInstance(), "noRecordFoundInInstTrnsTable",
			FacesMessage.SEVERITY_ERROR);
	    throw new ValidatorException(message);
		}
		de.printStackTrace();
		}
		/* 
		for(int i=0;i<items.size();i++){
				Long seq= items.get(i).getSequenceNum(); 
				System.out.println("Seq="+seq);
			 }*/
		
		/*for(int i=0;i<items.size();i++){
        System.out.println("Item form Ppm_Inst_Trns="+item.getPpm_Inst_Transactions().get(i).getSequenceNum());
		}*/
     	//Forward to edit Navigation case
		
		
		return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
	}
	
	/**
	 * 
	 * @return HtmlDataTable representing backendSystem Table
	 */
	public HtmlDataTable getTransactionReportTable() {
		return (HtmlDataTable) JSFUtil.findComponentInRoot("incomingSalaryTable");
	}
       
  
		
	/**
	 * @param context FacesContext reference 
	 * @param component component that fired the event
	 * @param value Value of the UI Component
	 */
	
	public void validateForm(FacesContext context, UIComponent component,
			Object value) {
		
		FacesMessage message = null;
		String componentId = component.getId();
		String valueStr = "";
		// Do not process if the value is null
		if (value == null) {
			return;
		}
		if (value instanceof String) {
			valueStr = vaildateChars((String) value, context, componentId);
		}
		
		//Validation for groupCode component
		if (componentId.equalsIgnoreCase("creditAcc")) {
			//Check length
			if (valueStr.length() >11 ) {
				
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupCode.chars",FacesMessage.SEVERITY_ERROR, componentId,5);
				throw new ValidatorException(message);
			}
		}//Validation for groupDesc component 
		else if (componentId.equalsIgnoreCase("firstInstDate")) {
			//Check length
			if (valueStr.length() >11 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupDesc.chars",FacesMessage.SEVERITY_ERROR, componentId, 50);
				throw new ValidatorException(message);
			}
		}//Validation for groupName component
		else if (componentId.equalsIgnoreCase("lastInstDate")) {
			//Check length
			if (valueStr.length() >11 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.jobDescription.chars",FacesMessage.SEVERITY_ERROR, componentId, 30);
				throw new ValidatorException(message);
			}
		}
	}
	
	public String getEntityName() {
		return "IncomingSalary";
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getStatusFieldName()
	 */
	public String getStatusFieldName() {
		return "processStatus";

	}	
	
	public String getIdFieldName() {
		return "sequenceNum";
	}
	
	@Override
	public List<IncomingSalaries> getSelectedItems() {
	
		return null;
	}

	@Override
	public String createSetup() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String detailSetup() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public PaginatedDAO<IncomingSalaries, String> getDAO() {
		// TODO Auto-generated method stub
		return incomingSalaryDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#cancel()
	 */
	public String cancel() {

		// Set the page number in PaginationInfo to Zero
		// getPageInfo().setCurrentPage(0);

		// Reload the items in the list
		reloadInstTrans();
       System.out.println("getClass().getSimpleName()="+getClass().getSimpleName());
		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
	
	
	
		
	
	    
		
	
}
