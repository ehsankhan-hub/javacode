package com.bsf.ppm.maintenance;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;

import org.richfaces.component.html.HtmlDataTable;

import com.bsf.ppm.Application;
import com.bsf.ppm.BackendSystem;
import com.bsf.ppm.BatchJob;
import com.bsf.ppm.batch.BatchExecutionManager;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.ApplicationDAO;
import com.bsf.ppm.dao.BackendSystemDAO;
import com.bsf.ppm.dao.BatchJobDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ipp.dao.PaginatedDAO;
import com.sun.faces.util.MessageFactory;

/**
 * CRUD Controller Class for the BatchJob CRUD Operations.
 */
public class BatchJobController extends
		AbstractCrudController<BatchJob, Long> {

	/** Attribute batchJobDAO DAO object for BatchJob */
	private BatchJobDAO batchJobDAO;
	
	/** Attribute applicationDAO DAO object for Application */
	private ApplicationDAO applicationDAO;
	
	/** Attribute backendSystemDAO DAO object for Application */
	private BackendSystemDAO backendSystemDAO;	
	
	/** Attribute applicationManagement */
	private BatchExecutionManager batchExecutionManager;

	/** Attribute item BatchJob Entity */
	private BatchJob item;

	/** Attribute items for CurrencyCode Entity List */
	private List<BatchJob> items;
	
	private String selectedApplication;
	
	private Long selectedBackend;
	
	/** itemSize (number of items in the list)*/
	private int itemsSize;
	/*
	 * return int (itemSize)
	 */
	public int getItemsSize() {
		return getItems().size();
	}

	/**
	 * @return itemSize
	 */
	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}

	
	/**
	 * Constructor for BatchJobController
	 */
	public BatchJobController() {
		//Initialize item object 
		item = new BatchJob();
		// Initialize default Search criteria
		this.getSearchCriteria().put(getStatusFieldName(), Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
		
		// Initialize default sort field
		sortField = "jobName";
		sortAscending=true;
	}

	/**
	 * @return the batchJobDAO
	 */
	public BatchJobDAO getBatchJobDAO() {
		return batchJobDAO;
	}

	/**
	 * @param batchJobDAO the batchJobDAO to set
	 */
	public void setBatchJobDAO(BatchJobDAO batchJobDAO) {
		this.batchJobDAO = batchJobDAO;
	}

	/**
	 * @param batchJobDAO the batchJobDAO to set
	 */
	public void setApplicationDAO(ApplicationDAO applicationDAO) {
		this.applicationDAO = applicationDAO;
	}
	
	/**
	 * @param batchJobDAO the batchJobDAO to set
	 */
	public void setBackendSystemDAO(BackendSystemDAO backendSystemDAO) {
		this.backendSystemDAO = backendSystemDAO;
	}	
	/**
	 * @return the batchExecutionManager
	 */
	public BatchExecutionManager getBatchExecutionManager() {
		return batchExecutionManager;
	}

	/**
	 * @param batchExecutionManagerImpl the batchExecutionManager to set
	 */
	public void setBatchExecutionManager(BatchExecutionManager batchExecutionManager) {
		this.batchExecutionManager = batchExecutionManager;
	}

	/**
	 * @return the selectedApplication
	 */
	public String getSelectedApplication() {
		return selectedApplication;
	}

	/**
	 * @param selectedApplication the selectedApplication to set
	 */
	public void setSelectedApplication(String selectedApplication) {
		this.selectedApplication = selectedApplication;
	}

	/**
	 * @return the selectedBackend
	 */
	public Long getSelectedBackend() {
		return selectedBackend;
	}

	/**
	 * @param selectedBackend the selectedBackend to set
	 */
	public void setSelectedBackend(Long selectedBackend) {
		this.selectedBackend = selectedBackend;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItems()
	 */
	public List<BatchJob> getItems() {
		if (items == null) {
			reloadItems();
		}
		return items;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#reloadItems()
	 */
	@Override
	public void reloadItems() {
		
		List<BatchJob> batchJobList = new ArrayList<BatchJob>();
		//Call relaodItems from super class
		super.reloadItems();
		
		// Set running attribute for BatchJob looking up in Job Registry.
		// If found in registry job is treated as running
		if (items !=null && items.size()>0) {
			
			//Fetch Job Registry
			Map jobRegistry = getBatchExecutionManager().getJobRegistry();
			
			for(BatchJob batchJob: items) {

				// Check if job is registered and set the running attribute for batch
				if ( jobRegistry.containsKey(batchJob.getJobName())) {
					batchJob.setRunning(true);
				}
				else {
					batchJob.setRunning(false);
				}
				batchJobList.add(batchJob);
			}
		}
		items = batchJobList;
		//retun new items list :batchJobList		
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getDAO()
	 */
	public PaginatedDAO<BatchJob, Long> getDAO() {
		return batchJobDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItem(java.lang.Object
	 * )
	 */
	public void setItem(BatchJob item) {
		this.item = item;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItems(java.util.
	 * List)
	 */
	public void setItems(List<BatchJob> items) {
		this.items = items;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItem()
	 */
	public BatchJob getItem() {
		return item;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getSelectedItems()
	 */
	public List<BatchJob> getSelectedItems() {
		List<BatchJob> selectedList = new ArrayList<BatchJob>();
		//Get the List of selected items from the dataTable
		for (BatchJob item : getItems()) {
			// Add item to the selectedList if the item is selected
			if (item.isSelected())
				selectedList.add(item);
		}
		return selectedList;

	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#prepareSearchCriteria()
	 */
	public Map<String, Object>  prepareSearchCriteria(){
		Map<String, Object> newSearchMap = super.prepareSearchCriteria();
		
		//Remove the messageType from Search Criteria if value=0 (ALL option selected)
		if(newSearchMap.get("jobType") !=null && 
				(new Integer(newSearchMap.get("jobType").toString()).intValue()==IConstants.JOB_TYPE.ALL.ordinal())) {
			newSearchMap.remove("jobType");
		}
		/*if(newSearchMap.get("application") !=null && 
				(new Integer(newSearchMap.get("application").toString()).intValue()== -1)) {
			newSearchMap.remove("application");
		}	*/	
		return newSearchMap;
	}
	
	/**
	 * 
	 * @return HtmlDataTable representing batchJobTable
	 */
	public HtmlDataTable getBatchJobsTable() {
		return (HtmlDataTable) JSFUtil.findComponentInRoot("batchJobTable");
	}

	/**
	 * Forward to monitor page. This list displays internal jobs that are active 
	 * @return String navigation case to monitor page
	 */
	public String monitorSetup() {

		// Initialize default values for SearchCriteria and PageInfo
		if (getSearchCriteria() != null){
			setSearchCriteria(new HashMap<String, Object>());
			//Set the status to active 
			getSearchCriteria().put(getStatusFieldName(),
					Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
			//Set the job type to Internal
			getSearchCriteria().put("jobType",
					Long.valueOf(IConstants.JOB_TYPE.INTERNAL.ordinal()));
		}
		
		//Set 0 as the first page
		if (getPageInfo() != null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		reloadItems();
		// returns the Navigation case for  monitor list page
		return getClass().getSimpleName() +"_monitor";
	}

	@Override
	public String editSetup() {
	
		setSelectedApplication(getItem().getApplication().getApplicationName());
		setSelectedBackend(getItem().getBackendSystem().getId());
		return getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
	}
	/**
	 * Forward to monitor page. This list displays internal jobs that are active 
	 * @return String navigation case to monitor page
	 */
	public String monitorPageSearchSetup() {

		// Set PageInfo with current Page 0
		getPageInfo().setCurrentPage(0);
		
		// Set the search criteria
		setSearchCriteria(super.prepareSearchCriteria());
		
		// Initialize default values for SearchCriteria and PageInfo
		if (getSearchCriteria() != null){
			//Set the status to active 
			getSearchCriteria().put(getStatusFieldName(),
					Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
			//Set the job type to Internal
			getSearchCriteria().put("jobType",
					Long.valueOf(IConstants.JOB_TYPE.INTERNAL.ordinal()));
		}
		sortField = "jobName";
		// Load the items in the list
		reloadItems();
		// returns the Navigation case for  monitor list page
		return getClass().getSimpleName() +"_monitor";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#next()
	 */
	public String monitorPageNext() {

		// Set the page number in PaginationInfo
		getPageInfo().setCurrentPage(getPageInfo().getCurrentPage() + 1);

		// Reload the items in the list
		reloadItems();

		// returns the Navigation case for  monitor list page
		return getClass().getSimpleName() +"_monitor";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#prev()
	 */
	public String monitorPagePrev() {

		// Set the page number in PaginationInfo
		if (getPageInfo().getCurrentPage() > 0) {
			getPageInfo().setCurrentPage(getPageInfo().getCurrentPage() - 1);
		}
		// Reload the items in the list
		reloadItems();

		// returns the Navigation case for  monitor list page
		return getClass().getSimpleName() +"_monitor";
	}

	/**
	 * Loads the ITems and returns the navigation case to list page
	 * 
	 * @return
	 */
	public String monitorDisplayPage() {
		reloadItems();
		// returns the Navigation case for  monitor list page
		return getClass().getSimpleName() +"_monitor";

	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String detailSetup() {
		//Get the Item to be passed to Detail page
		item = (BatchJob) this.getBatchJobsTable().getRowData();
		//Forward to detail Navigation case
		return getClass().getSimpleName() + "_detail";
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#createSetup()
	 */
	public String createSetup() {
		// create a new instance of item
		item = new BatchJob();
		//Forward to create Navigation case
		return getClass().getSimpleName() + "_create";
	}

	/**
	 * @param context FacesContext reference 
	 * @param component component that fired the event
	 * @param value Value of the UI Component
	 */
	public void validateForm(FacesContext context, UIComponent component,
			Object value) {
		
		FacesMessage message = null;
		String componentId = component.getId();
		int valueLength;
		
		// Do not process if the value is null
		if (value == null) {
			return;
		}
		else {
			valueLength=value.toString().length();
		}
		
		//Validate for miscellaneous characters 
		if ((componentId.equalsIgnoreCase("jobName") || componentId.equalsIgnoreCase("jobDescription"))
				&& (value instanceof String)) {
			value=vaildateChars((String) value,context,componentId);
		}
		
		//Validation for jobName component
		if (componentId.equalsIgnoreCase("jobName")) {
			//Check length
			if (valueLength >50 ) {
				
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.jobName.chars",FacesMessage.SEVERITY_ERROR, componentId,50);
				throw new ValidatorException(message);
			}
		}//Validation for jobDescription component 
		else if (componentId.equalsIgnoreCase("jobDescription")) {
			//Check length
			if (valueLength >250 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.jobDescription.chars",FacesMessage.SEVERITY_ERROR, componentId, 250);
				throw new ValidatorException(message);
			}
		}//Validation for processorClass component 
		else if (componentId.equalsIgnoreCase("batchProcessorClass")) {
			//Check length
			if (valueLength >250 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.processorClass.chars",FacesMessage.SEVERITY_ERROR, componentId, 250);
				throw new ValidatorException(message);
			}
			if (value != null) {
				//Check Processor class exists in Classpath
				try {
					System.out.println("== Validating Processor class"+value.toString());
					Class processorClass = Class.forName(value.toString());
					System.out.println("processorClass.getClass()"+processorClass.getClass());
				} catch (ClassNotFoundException e) {
					context.getApplication().setMessageBundle(
					"bundles.ValidatorMessages");
					message = MessageFactory.getMessage(context,
					"batchJob.processorClass.exists",FacesMessage.SEVERITY_ERROR, componentId, 250);
					throw new ValidatorException(message);
				}
			}			
		}//Validation for handlerClass component 
		else if (componentId.equalsIgnoreCase("batchHandlerClass")) {
			//Check length
			if (valueLength > 250) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.handlerClass.chars",FacesMessage.SEVERITY_ERROR, componentId, 250);
				throw new ValidatorException(message);
			}
			if (value != null) {
				System.out.println("== Validating Handler class");
				//Check Handler class exists in Class path
				try {
					Class handlerClass = Class.forName(value.toString());
					System.out.println("handlerClass=="+handlerClass);
				} catch (ClassNotFoundException e) {
					context.getApplication().setMessageBundle(
					"bundles.ValidatorMessages");
					message = MessageFactory.getMessage(context,
					"batchJob.handlerClass.exists",FacesMessage.SEVERITY_ERROR, componentId, 250);
					throw new ValidatorException(message);
				}
			}
				
		}//Validation for longDescription component 
		else if (componentId.equalsIgnoreCase("batchCronSchedule")) {
			//Check length
			if (valueLength > 50) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.cronSchedule.chars",FacesMessage.SEVERITY_ERROR, componentId, 50);
				throw new ValidatorException(message);
			}
		}
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#isUnique()
	 */
	public boolean isUnique() {
		boolean isUnique = false;
		try {
			//Check if the item is Unique in the Table
			isUnique = getDAO().isUnique(getItem());
		} catch (DAOException e) {
			
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.BusinessErrorMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUnique;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#create()
	 */
	public String create() {
		FacesMessage facesMessage = null;
		String nav = "";
		try {
			//Set userInfo for CurrencyCode
			item.setCreatedBy(JSFUtil.getLoggedInUserInfo());
			//Set create Date
			item.setCreatedDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			//Set the selected application
			Application application = applicationDAO.getByApplicationName(getSelectedApplication());
			item.setApplication(application);
			
			//Set the selected application
			BackendSystem backendSystem = backendSystemDAO.getById(getSelectedBackend());
			item.setBackendSystem(backendSystem);
			
			//set Status as Active
			item.setJobStatus(Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
			//Set navigation case from super.create
			nav = super.create();
		
		} catch (Exception e) {

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.add.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);
			//Print StackTrace
			e.printStackTrace();
			// Return Navigation case of the create page
			return "";
		}

		return nav;
	}

	/**
	 * Update the entity in the database. Serves user update action on Edit page.
	 * Updated internal job is rescheduled with the scheduler.
	 * @return List page Navigation case defined in faces-config.xml
	 */
	@Override
	public String update() {
		
		// set update information
		getItem().setModifiedBy(JSFUtil.getLoggedInUserInfo());
		getItem().setModifiedDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
		Application app=  new Application();
		app.setApplicationName(selectedApplication);
		getItem().setApplication(app);
		BackendSystem backendSys = new BackendSystem();
		backendSys.setId(selectedBackend);
		getItem().setBackendSystem(backendSys);
		
		//call super.update
		String navigationCase = super.update();
		
		//Reschedule the Job if the Job is internal
		String jobName = getItem().getJobName();
		if ( getItem().getJobType() == IConstants.JOB_TYPE.INTERNAL.ordinal()) {
			//Remove the job from scheduler
			getBatchExecutionManager().removeJobByName(jobName);
			//Schedule the job
			getBatchExecutionManager().registerJobByName(jobName);
		}
		return navigationCase;
	}
	/**
	 * Starts the individual job 
	 * @return String navigation to list setup
	 */
	public String startJob() {
		// Schedule the job and Register the job in registry
		item = (BatchJob) this.getBatchJobsTable().getRowData();
		System.out.println("-inside startJob jname="+item.getJobName());
		getBatchExecutionManager().registerJobByName(item.getJobName());
		//Return navigation to List page
		return monitorSetup();
	}
	
	/**
	 * Stops the individual job 
	 * @return String navigation to list setup
	 */
	public String stopJob() {
		//Remove the job from scheduler and registry
		item = (BatchJob) this.getBatchJobsTable().getRowData();
		getBatchExecutionManager().removeJobByName(item.getJobName());
		//Return navigation to List page
		return monitorSetup();
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#enableItem()
	 */
	@Override
	public String enableItem() {

		//Get the item selected
		//item = (BatchJob) this.getBatchJobsTable().getRowData();
		
		//call super.enableItem
		String navigationCase = super.enableItem();
		
		// Schedule the job and Register the job in registry
		getBatchExecutionManager().registerJobByName(getItem().getJobName());
		//Display Job starting message
		FacesMessage facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "job.activateMessage",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage("itemDeactivatedSuccessfully",
				facesMessage);
		
		return navigationCase;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#disableItem()
	 */
	@Override
	public String disableItem() {
		
		//Get selected job
		//item = (BatchJob) this.getBatchJobsTable().getRowData();
		//call super.disableItem
		String navigationCase = super.disableItem();
		
		//Remove the job from scheduler and registry
		getBatchExecutionManager().removeJobByName(getItem().getJobName());
		//Display Job stoping message
		FacesMessage facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "job.deactivateMessage",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage("itemDeactivatedSuccessfully",
				facesMessage);
		
		return navigationCase;
	}
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#enableItems()
	 */
	@Override
	public String enableItems() {
	
		// Fetch the jobs to be stopped
		String[] idArrays = getIDsArray(getSelectedItems());
		
		//call super.enableItems
		String navigationCase = super.enableItems();
		
		// Schedule the jobs and Register the job in registry
		if (idArrays != null && idArrays.length > 0) {
			getBatchExecutionManager().registerJobByIds(idArrays);
		}
		//Display Job starting message
		FacesMessage facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "jobs.activateMessage",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage("itemDeactivatedSuccessfully",
				facesMessage);		
		return navigationCase;
	}
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#disableItems()
	 */
	@Override
	public String disableItems() {
		
		// Fetch the jobs to be stopped
		String[] idArrays = getIDsArray(getSelectedItems());
		//call super.disableItems
		String navigationCase = super.disableItems();

		//Remove the jobs from scheduler and registry
		if (idArrays != null && idArrays.length > 0) {
			getBatchExecutionManager().removeJobByIds(idArrays);
		}
		//Display Job stoping message
		FacesMessage facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "jobs.deactivateMessage",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage("itemDeactivatedSuccessfully",
				facesMessage);		
		return navigationCase;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.util.List)
	 */
	public String[] getIDsArray(List<BatchJob> items) {
		// return null if List is null or empty
		if (items == null || items.size() == 0) {
			return null;
		}
		// Build the array of the ids
		String[] ids = new String[items.size()];
		//add the ids of the items to the array
		int i = 0;
		for (BatchJob entity : items) {
			ids[i] = entity.getPk();
			i++;
		}
		return ids;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.lang.Object)
	 */
	public String[] getIDsArray(BatchJob item) {
		// return null if item is null 
		if (item == null) {
			return null;
		}
		//Build the idsArray
		String[] ids = { item.getId().toString() };
		return ids;
	}


	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getEntityName()
	 */
	public String getEntityName() {
		return "Batch Job";
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getStatusFieldName()
	 */
	public String getStatusFieldName() {
		return "jobStatus";

	}	
	/**
	 * Fetch Job Types to be displayed in search criteria
	 * @return List of Job Type Items for the Select Options
	 */
	public List<SelectItem> getSearchJobTypeList() {
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		// Get the array of Job types Types from IConstants.JOB_TYPE
		IConstants.JOB_TYPE[] itemsArray = IConstants.JOB_TYPE.values();
		//Build the List of SelectItems
		for (int i = 0; i < itemsArray.length; i++) {
			list.add(new SelectItem(Long.valueOf(itemsArray[i].ordinal()),
					itemsArray[i].name()));
		}
		return list;
	}
	
	/**
	 * Fetch Job Types to be displayed in Edit/Create page 
	 * @return List of Job Type Items for the Select Options
	 */
	public List<SelectItem> getJobTypeList() {
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		// Get the array of Job Types from IConstants.JOB_TYPE
		IConstants.JOB_TYPE[] itemsArray = IConstants.JOB_TYPE.values();
		//Build the List of SelectItems
		for (int i = 0; i < itemsArray.length; i++) {
			
			// Add other options and remove the all option on create/Edit page
			if( itemsArray[i].ordinal() != IConstants.JOB_TYPE.ALL.ordinal()) { 
				list.add(new SelectItem(Long.valueOf(itemsArray[i].ordinal()),
						itemsArray[i].name()));
			}
		}
		return list;
	}	
	/**
	 * Name of the message Type corresponding to item.messageType in IConstants.MESSAGE_TYPE
	 * @return MessageType Name for the given messageType
	 */
	public String getJobTypeName() {

		String messageTypeName = "";
		// Get the array of Job Types from IConstants.JOB_TYPE
		IConstants.JOB_TYPE[] jobTypesArray = IConstants.JOB_TYPE.values();
		
		//Fetch the name of the Job type
		for (int i = 0; i < jobTypesArray.length; i++) {
			
			if( jobTypesArray[i].ordinal() == getItem().getJobType().intValue()) { 
				messageTypeName=jobTypesArray[i].name();
			}
		}
		return messageTypeName;
	}
	
	/**
	 * List of Application Items
	 * @return List the list of Application Items for the Select Options in Search
	 */
	public List<SelectItem> getApplicationSearchList() {

		List<Application> applicationList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			applicationList = applicationDAO.findAll();
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		list.add(new SelectItem("",IConstants.SELECT_ALL_OPTION));
		//Add the Application List to the Select Item List
		for (Application application: applicationList) {
			list.add(new SelectItem(application.getApplicationName(),application.getApplicationName()));		
		}
		return list;
	}
	
	/**
	 * List of Application Items
	 * @return List the list of Application Items for the Select Options 
	 */
	public List<SelectItem> getApplicationList() {

		List<Application> applicationList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			applicationList = applicationDAO.findAll();
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (Application application: applicationList) {
			list.add(new SelectItem(application.getApplicationName(),application.getApplicationName()));		
		}
		return list;
	}	

	/**
	 * List of Application Items
	 * @return List the list of Application Items for the Select Options 
	 */
	public List<SelectItem> getBackendSystemList() {

		List<BackendSystem> backendSystemList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of BackendSystem objects
			backendSystemList = backendSystemDAO.findAll();
		} catch (DAOException e) {
			e.printStackTrace();
		}
		//Add the BackendSystem List to the Select Item List
		for (BackendSystem backendSystem: backendSystemList) {
			if (backendSystem.getId() != 0)
				list.add(new SelectItem(backendSystem.getId(),backendSystem.getSystemName()));		
		}
		return list;
	}
	
	public String releaseJob(){
		//Remove the job from scheduler and registry
		item = (BatchJob) this.getBatchJobsTable().getRowData();
		getBatchExecutionManager().releaseJobByName(item.getJobName());
		//Return navigation to List page
		return monitorSetup();
	}
	
}
