package com.bsf.ppm.maintenance;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.GErrorList;
import com.bsf.ppm.LoanBlockDets;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.Ppm_Inst_Transactions;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.GErrorListDAO;
import com.bsf.ppm.dao.InstTransactionsDAO;
import com.bsf.ppm.dao.InstructionDAO;
import com.bsf.ppm.dao.LoanBlockDetsDAO;
import com.bsf.ppm.dao.ParameterValueDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.fts.FTSRequestPostingEntityMRKM;
import com.bsf.ppm.fts.FTSResponsePostingEntity;
import com.bsf.ppm.service.posting.FTSPostingService;
import com.bsf.ppm.service.posting.FTSPostingServiceImpl;
import com.bsf.ppm.util.StringUtils;
import com.sun.faces.util.MessageFactory;

/**
 * CRUD Controller Class for the PpmGroup CRUD Operations.
 */
public class BlockUnblockController extends
		AbstractCrudController<LoanBlockDets, String> {

	/** Attribute LoanBlockDetsDAO DAO object for loanBlockDetsDAO */
	private LoanBlockDetsDAO loanBlockDetsDAO;
	
	private ParameterValueDAO parameterValueDAO;
	
	/** Attribute item PpmGroup Entity */
	private LoanBlockDets item;

	/** Attribute items for LoanBlockDets Entity List */
	private List<LoanBlockDets> items;
	
	private InstTransactionsDAO instTransactionsDAO;
	
	private InstructionDAO instructionDAO;
	
	private GErrorListDAO gErrorListDAO;
	
	private String selectedApplication;
	
	private Ppm_Inst_Transactions ppm_Inst_Transactions=null;
	
	private List<ParameterValue> parameterValue=null;
	
	private GErrorList gErrorList=null;
	
	private String blockUnblokFlag="";
	
	private int updtCount=0;
	/** 
	 * logger
	 */
	
	private static final Logger logger = Logger.getLogger("com.bsf.ppm.blockUnblock");
	
		
	private FTSPostingService ftsService = new FTSPostingServiceImpl();
	/** itemSize (number of items in the list)*/
	private int itemsSize;
	/*
	 * return int (itemSize)
	 */
	public int getItemsSize() {
		if(itemsSize!=0){
		return getItems().size();
		}
		return 0;
	}

	/**
	 * @return itemSize
	 */
	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}
  	
	/**
	 * Constructor for BlockUnblockController
	 */
	public BlockUnblockController() {
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
		String fromDateFormated = null;
		Date cuttentDate=new Date();
		//if (getItem().getInstDate() != null ) {
			fromDateFormated = formatter.format(cuttentDate);
		item = new LoanBlockDets();
		
		// Initialize default Search criteria
		//this.getSearchCriteria().put(getStatusFieldName(), fromDateFormated);
		
		// Initialize default sort field
		sortField = "loanBlockDetsCompPk.createdDate";
		sortAscending=true;
	}

	
	
	/**
	 * @return the LoanBlockDetsDAO
	 */
	public LoanBlockDetsDAO getLoanBlockDetsDAO() {
		return loanBlockDetsDAO;
	}

	public void setLoanBlockDetsDAO(LoanBlockDetsDAO loanBlockDetsDAO) {
		this.loanBlockDetsDAO = loanBlockDetsDAO;
	}
	
	public ParameterValueDAO getParameterValueDAO() {
		return parameterValueDAO;
	}

	public void setParameterValueDAO(ParameterValueDAO parameterValueDAO) {
		this.parameterValueDAO = parameterValueDAO;
	}

	/**
	 * @return the selectedApplication
	 */
	public String getSelectedApplication() {
		return selectedApplication;
	}

	

	/**
	 * @param selectedApplication the selectedApplication to set
	 */
	public void setSelectedApplication(String selectedApplication) {
		this.selectedApplication = selectedApplication;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItems()
	 */
	public List<LoanBlockDets> getItems() {
		if (items == null) {
			//reloadItems();
			reloadItemsForBlockUnblock();
			items=null;
		}
		return items;
	}

	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItem(java.lang.Object
	 * )
	 */
	public void setItem(LoanBlockDets item) {
		this.item = item;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItems(java.util.
	 * List)
	 */
	public void setItems(List<LoanBlockDets> items) {
		this.items = items;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItem()
	 */
	public LoanBlockDets getItem() {
		return item;
	}
	public InstTransactionsDAO getInstTransactionsDAO() {
		return instTransactionsDAO;
	}

	public void setInstTransactionsDAO(InstTransactionsDAO instTransactionsDAO) {
		this.instTransactionsDAO = instTransactionsDAO;
	}

	public void setInstructionDAO(InstructionDAO instructionDAO) {
		this.instructionDAO = instructionDAO;
	}

	public InstructionDAO getInstructionDAO() {
		return instructionDAO;
	}
    
	

	public GErrorListDAO getgErrorListDAO() {
		return gErrorListDAO;
	}

	public void setgErrorListDAO(GErrorListDAO gErrorListDAO) {
		this.gErrorListDAO = gErrorListDAO;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getSelectedItems()
	 */
	public List<LoanBlockDets> getSelectedItems() {
		List<LoanBlockDets> selectedList = new ArrayList<LoanBlockDets>();
		//Get the List of selected items from the dataTable
		for (LoanBlockDets item : getItems()) {
			
			// Add item to the selectedList if the item is selected
			if (item.isSelected()){
				logger.info("Selected Item groupcode="+item.getLoanBlockDetsCompPk().getReference());
				selectedList.add(item);
			}
		}
		return selectedList;

	}
	
	/**
	 * 
	 * @return HtmlDataTable representing LoanBlockDetsTable
	 */
	public HtmlDataTable getPpmGroupTable() {
		return (HtmlDataTable) JSFUtil.findComponentInRoot("ppmGroupTable");
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String listSetupString() {
        
		// Initialize default values for SearchCriteria and PageInfo
		if (getSearchCriteria() != null) {
			setSearchCriteria(new HashMap<String, Object>());
			//getSearchCriteria().put(getStatusFieldName(),"  ");
		}
		// Set 0 as the first page
		if (getPageInfo() == null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		//reloadItems();
		reloadItemsForBlockUnblock();
		// returns the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	@Override
	public String editSetup() {
	
		return getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String detailSetup() {
		//Get the Item to be passed to Detail page
		item = (LoanBlockDets) this.getPpmGroupTable().getRowData();
		
		//Forward to detail Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#createSetup()
	 */
	public String createSetup() {
		// create a new instance of item
		item = new LoanBlockDets();
		//Forward to create Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_CREATE_NAVIGATION;
	}

	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#isUnique()
	 */
	public boolean isUnique() {
		boolean isUnique = false;
		try {
			//Check if the item is Unique in the Table
			isUnique = getDAO().isUnique(getItem());
		} catch (DAOException e) {
			
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.BusinessErrorMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUnique;
	}

	
	
	public String create() {
		FacesMessage facesMessage = null;
		String trnsTypeCrncy="";
		String branch="";
		  //FTSRequestPostingEntityMRKM trnsMsg=null;
		try {
			Long reference=getInstTransactionsDAO().getReferenceSeqGen();
			String refePading="LLS"+StringUtils.padLeft(reference.toString(), 7, "0");
			logger.info("refePading=="+refePading);
			FTSRequestPostingEntityMRKM fTSRequestPostingEntityMRKM=new FTSRequestPostingEntityMRKM();
			FTSResponsePostingEntity inquiryResponse=null;
			// get the new instance of FTSRequestPostingEntityMRKI
			FTSRequestPostingEntityMRKM trnsMsg=null;
			String blckReference="";
			//Set userInfo for CurrencyCode
			item.setCreatedBy("PPMBATCH");
			trnsMsg=fTSRequestPostingEntityMRKM.getInstance();			
			//MRKM message preparation 
			trnsMsg.setTransType("MRKM");
			trnsMsg.setFTSReference(refePading);
			trnsMsg.setDebitAcctNo(getItem().getLoanBlockDetsCompPk().getAcctNumber());
			//if(getItem().getBankBlckRef()!=null&&!"".equals(getItem().getBankBlckRef())){
			blckReference=getItem().getBankBlckRef();
					
			//}
						
			trnsTypeCrncy="SAR";	
			
			logger.info("trnsTypeCrncy Length=="+trnsTypeCrncy.length());
			logger.info("trnsTypeCrncy==="+trnsTypeCrncy);
			String trnsAmt=StringUtils.getFormattedAmount(getItem().getAmount(), 2);	
			logger.info("trnsAmt==="+trnsAmt);
			trnsMsg.setTransAmount(trnsAmt);
	    	trnsMsg.setTransCrncy(trnsTypeCrncy);
	    	trnsMsg.setValueDate(new Date());
	    	trnsMsg.setTransactionStatus("NOR");
	    	trnsMsg.setGenNarrative("Loan unblocking for salary "+getItem().getLoanBlockDetsCompPk().getReference());
	    	trnsMsg.setDebitAcctCrncy(trnsTypeCrncy);
	    	trnsMsg.setDebitValueDate(new Date());
	    	trnsMsg.setCreditValueDate(new Date());
	    	trnsMsg.setChargesCrncy(trnsTypeCrncy);
	    	trnsMsg.setRsstReference(getItem().getLoanBlockDetsCompPk().getReference());
	    	trnsMsg.setRsstReasonCode("5");
	    	trnsMsg.setRsstReasonDes("LLS unblocking for salary"+getItem().getLoanBlockDetsCompPk().getReference());
	    	trnsMsg.setRsstExpDate(new Date());
	    	
	    
	    	logger.info("blckReference=="+blckReference);
	    	trnsMsg.setBlckReference(blckReference);
	    	inquiryResponse = ftsService.sendTransferRequest(trnsMsg,"LLS");
	    	
	    	if(inquiryResponse!=null){
	    	logger.info("CAMM Action code="+inquiryResponse.getCAMMActionCode());
	    	logger.info("FTS Action code=="+inquiryResponse.getFTSActionCode());
	    	logger.info("TUXEDO LOG FOR BLOCK/UNBLOCK");
	       	if((inquiryResponse.getCAMMActionCode().equals("0000"))&&(inquiryResponse.getFTSActionCode().equals("0000"))){
	    	facesMessage = JSFUtil.getMessage(
	    	FacesContext.getCurrentInstance(), "bundles.UIMessages", "MRKMSuccess", getItem().getLoanBlockDetsCompPk().getAcctNumber(),getItem().getLoanBlockDetsCompPk().getReference(),JSFUtil.getLoggedInUserInfo().getUserId(),  FacesMessage.SEVERITY_INFO);
	    	FacesContext.getCurrentInstance().addMessage("reference",facesMessage);	
	    	logger.info("UnBlocking succesfully done for account "+getItem().getLoanBlockDetsCompPk().getAcctNumber()+" and loan Ref: "+getItem().getLoanBlockDetsCompPk().getReference()+" by user id "+JSFUtil.getLoggedInUserInfo().getUserId());
	    	item.setCnfrmButton(inquiryResponse.getCAMMActionCode().equals("0000"));
	    		
	    	parameterValue=getParameterValueDAO().getBlockUnblockFlag();
	    	if (parameterValue != null&&parameterValue.size()>0) {
	    	blockUnblokFlag=parameterValue.get(0).getValue1();
	    	logger.info("parameterValue size:"+parameterValue.size());
	    	if(blockUnblokFlag.equalsIgnoreCase("Y")){
	    	updtCount=getLoanBlockDetsDAO().updateLoanInstDets(getItem().getLoanBlockDetsCompPk().getReference(),getItem().getLoanBlockDetsCompPk().getAcctNumber());	
	    	logger.info("Table loan_instalments_dets successfully updated "+updtCount);
	    	}
	    	}
	    	else{
	    	updtCount=getLoanBlockDetsDAO().updateLoanInstDets(getItem().getLoanBlockDetsCompPk().getReference(),getItem().getLoanBlockDetsCompPk().getAcctNumber());	
	    	logger.info("Table loan_instalments_dets successfully updated "+updtCount);
	    	}
	    	
			//return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
	    	}
	    	else if((inquiryResponse.getFTSActionCode().equals("0000"))&&(inquiryResponse.getCAMMActionCode().equals("0242"))){
	    		Map<String, Object> map=new HashMap<String, Object>();
				map.put("errorCode", inquiryResponse.getCAMMActionCode());
				gErrorList=getgErrorListDAO().getByCriteria(map);	
	    	    facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(), "bundles.UIMessages",
	    		"MRKMFailureNotExist", getItem().getLoanBlockDetsCompPk().getAcctNumber(),getItem().getLoanBlockDetsCompPk().getReference(),JSFUtil.getLoggedInUserInfo().getUserId(), FacesMessage.SEVERITY_ERROR);
	    		FacesContext.getCurrentInstance().addMessage("reference", facesMessage);
	    		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Error Description:  "+gErrorList.getErrorMsg()));
	    		
	    		logger.info("LLS UnBlocking failed  for account "+ getItem().getLoanBlockDetsCompPk().getAcctNumber()+" and Loan Reference"+getItem().getLoanBlockDetsCompPk().getReference()+" by userID "+JSFUtil.getLoggedInUserInfo().getUserId());
	    		logger.info("TUXEDO ERROR CODE of CAMM="+inquiryResponse.getCAMMActionCode());
	    		logger.info("TUXEDO ERROR DESCRIPTION of CAMM="+gErrorList.getErrorMsg());
	    		//return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;	
	    	
	    	}
	    	else{
	    	Map<String, Object> map=new HashMap<String, Object>();
			map.put("errorCode", inquiryResponse.getCAMMActionCode());
			gErrorList=getgErrorListDAO().getByCriteria(map);		
	    	facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(), "bundles.UIMessages",
	    	"MRKMFailure", getItem().getLoanBlockDetsCompPk().getAcctNumber(),getItem().getLoanBlockDetsCompPk().getReference(),JSFUtil.getLoggedInUserInfo().getUserId(), FacesMessage.SEVERITY_ERROR);
	    	 FacesContext.getCurrentInstance().addMessage("reference", facesMessage);
	    	 FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Error Description:  "+gErrorList.getErrorMsg()));
	    	 logger.info("LLS UnBlocking failed  for account "+ getItem().getLoanBlockDetsCompPk().getAcctNumber()+" and Loan Reference"+getItem().getLoanBlockDetsCompPk().getReference()+" by userID "+JSFUtil.getLoggedInUserInfo().getUserId());
	    	 logger.info("TUXEDO ERROR CODE of CAMM="+inquiryResponse.getCAMMActionCode());
	    	 logger.info("TUXEDO ERROR DESCRIPTION of CAMM="+gErrorList.getErrorMsg());
	    	 //return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;		
	    	}
	    	
			
	       //	return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
		} 
	    	else{
	    		logger.info("Trying to call TUXEDO getting network problem Block/UnBlock="+inquiryResponse);
	    		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Trying to call TUXEDO getting network problem :  "+inquiryResponse));
	    		//return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
	    	}
		
		}
		
	    	catch (Exception e) {
			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
			FacesContext.getCurrentInstance(), "bundles.UIMessages",
			"entity.blk.error", FacesMessage.SEVERITY_ERROR,e.getMessage());
			FacesContext.getCurrentInstance().addMessage("createError",facesMessage);
			//Print StackTrace
			e.printStackTrace();
		   	logger.warn("Trying to post TUXEDO , Exception Occurred ="+e.getMessage());
			// Return Navigation case of the create page
			//return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
		}
		return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
		}
	
 public String searchSetup() {
		FacesMessage facesMessage = null;
	
		// Set PageInfo with current Page 0
		getPageInfo().setCurrentPage(0);
		// Set the search criteria
		setSearchCriteria(prepareSearchCriteria());
		// reload reloadInstTrans
		//reloadBlockUnblockList();
		reloadItemsForBlockUnblock();
		// return the Navigation case for list page
		return getClass().getSimpleName()+ IConstants.CRUD_LIST_NAVIGATION;
	}
	
	/*private void reloadBlockUnblockList()
	{
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String fromDateFormated = null;
		Date cuttentDate=new Date();
		logger.info("getItem().getInstDate() "+getItem().getInstDate());
		//if (getItem().getInstDate() != null ) {
			fromDateFormated = formatter.format(cuttentDate);
			//toDateFormated = formatter.format(lastInstDate);
		//}
		logger.info("--fromDateFormated="+fromDateFormated);
		//reloadItemsCurrentAndFutureDateRange("reference", " ");
		reloadItemsBySearchCriteriaforBlockUnblock(getSearchCriteria());
	}*/

	
	
	/**
	 * @param context FacesContext reference 
	 * @param component component that fired the event
	 * @param value Value of the UI Component
	 */
	public void validateForm(FacesContext context, UIComponent component,
			Object value) {
		
		FacesMessage message = null;
		String componentId = component.getId();
		int valueLength;
		
		// Do not process if the value is null
		if (value == null) {
			return;
		}
		else {
			valueLength=value.toString().length();
		}
		
		//Validate for miscellaneous characters 
		if ((componentId.equalsIgnoreCase("groupCode") || componentId.equalsIgnoreCase("groupDesc")
				|| componentId.equalsIgnoreCase("groupName"))
				&& (value instanceof String)) {
			value=vaildateChars((String) value,context,componentId);
		}
		
		//Validation for groupCode component
		if (componentId.equalsIgnoreCase("groupCode")) {
			//Check length
			if (valueLength >5 ) {
				
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupCode.chars",FacesMessage.SEVERITY_ERROR, componentId,5);
				throw new ValidatorException(message);
			}
		}//Validation for groupDesc component 
		else if (componentId.equalsIgnoreCase("groupDesc")) {
			//Check length
			if (valueLength >50 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupDesc.chars",FacesMessage.SEVERITY_ERROR, componentId, 50);
				throw new ValidatorException(message);
			}
		}//Validation for groupName component
		else if (componentId.equalsIgnoreCase("groupName")) {
			//Check length
			if (valueLength >30 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.jobDescription.chars",FacesMessage.SEVERITY_ERROR, componentId, 30);
				throw new ValidatorException(message);
			}
		}
	}
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getEntityName()
	 */
	public String getEntityName() {
		return "Ppm BlockUnblock";
	}
	
	public String cancel() {

		// Set the page number in PaginationInfo to Zero
		// getPageInfo().setCurrentPage(0);

		// Reload the items in the list
		reloadItemsForBlockUnblock();

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getStatusFieldName()
	 */
	public String getStatusFieldName() {
		return "amount";

	}	

	@Override
	public PaginatedDAO<LoanBlockDets, String> getDAO() {
		// TODO Auto-generated method stub
		return loanBlockDetsDAO;
	}
	
}
