package com.bsf.ppm.maintenance;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

import com.bsf.ipp.IPPUTIL;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.Application;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.ApplicationDAO;
import com.bsf.ppm.exceptions.BusinessException;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.service.application.ApplicationManagement;
import com.bsf.ppm.service.notification.NotificationService;
import com.bsf.ppm.spring.SpringAppContext;

/**
 * @author Zakir
 * CRUD Controller Class for the Application CRUD Operations.
 */
public class ApplicationController extends
AbstractCrudController<Application, String> {

	private static final Logger log = Logger
	.getLogger(ApplicationController.class);
	/** Attribute applicationDAO  */
	private ApplicationDAO applicationDAO;



	/** Attribute applicationManagement */
	private ApplicationManagement applicationManagement;

	/** Attribute item of type Application*/
	private Application item;

	/** Attribute items. List of Application entities */
	private List<Application> items;

	/** itemSize (number of items in the list)*/
	private int itemsSize;

	private NotificationService notificationService;


	public NotificationService getNotificationService() {
		return notificationService;
	}

	public void setNotificationService(NotificationService notificationService) {
		this.notificationService = notificationService;
	}

	/*
	 * return int (itemSize)
	 */
	public int getItemsSize() {
		return getItems().size();
	}

	/**
	 * @return itemSize
	 */
	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}


	/**
	 * Constructor for ApplicationController.
	 */
	public ApplicationController() {
		//initialize item entity
		item = new Application();
		//Initialize the default search Criteria
		this.getSearchCriteria().put(getStatusFieldName(), Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
	}
	@Override
	public Map<String, Object> prepareSearchCriteria() {
		Map<String, Object> newSearchMap = super.prepareSearchCriteria();
		return newSearchMap;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItems()
	 */
	public List<Application> getItems() {
		if (items == null) {
			reloadItems();
		}
		return items;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getDAO()
	 */
	public PaginatedDAO<Application, String> getDAO() {
		return applicationDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItem(java.lang.Object
	 * )
	 */
	public void setItem(Application item) {
		this.item = item;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItems(java.util.
	 * List)
	 */
	public void setItems(List<Application> items) {
		this.items = items;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItem()
	 */
	public Application getItem() {
		return item;
	}

	/**
	 * @return the applicationDAO
	 */
	public ApplicationDAO getApplicationDAO() {
		return applicationDAO;
	}

	/**
	 * @param applicationDAO the applicationDAO to be set
	 */
	public void setApplicationDAO(ApplicationDAO applicationDAO) {
		this.applicationDAO = applicationDAO;
	}



	/**
	 * @return the applicationManagement
	 */
	public ApplicationManagement getApplicationManagement() {
		return applicationManagement;
	}

	/**
	 * @param applicationManagement the applicationManagement to set
	 */
	public void setApplicationManagement(ApplicationManagement applicationManagement) {
		this.applicationManagement = applicationManagement;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getSelectedItems()
	 */
	public List<Application> getSelectedItems() {

		List<Application> selectedList = new ArrayList<Application>();
		//Get the List of selected items from the dataTable
		for (Application item : getItems()) {
			// Add item to the selectedList
			if (item.isSelected()) {
				selectedList.add(item);
			}
		}
		return selectedList;

	}


	/**
	 * @return HtmlDataTable representing application Table
	 */
	public HtmlDataTable getApplicationsTable() {
		return (HtmlDataTable) JSFUtil.findComponentInRoot("applicationTable");
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String detailSetup() {
		//Get the Item to be passed to Detail page
		item = (Application) this.getApplicationsTable().getRowData();
		//Forward to detail Navigation case
		return getClass().getSimpleName() + "_detail";
	}


	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#createSetup()
	 */
	public String createSetup() {
		// create a new instance of item
		item = new Application();
		//Forward to create Navigation case
		return getClass().getSimpleName() + "_create";
	}

	/**
	 * @param context FacesContext reference 
	 * @param component component that fired the event
	 * @param value Value of the UI Component
	 */
	public void validateForm(FacesContext context, UIComponent component,
			Object value) {
		//Do Nothing
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#isUnique()
	 */
	public boolean isUnique() {
		boolean isUnique = false;
		try {
			//Check if the item is Unique from the DAO
			isUnique = getDAO().isUnique(getItem());
		} catch (DAOException e) {

			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.BusinessErrorMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUnique;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.util
	 * .List)
	 */
	public String[] getIDsArray(List<Application> items) {

		// return null if List is null or empty
		if (items == null || items.size() == 0) {
			return null;
		}
		// Build the array of the ids
		String[] idsArray = new String[items.size()];
		//add the ids of the items to the array
		int i = 0;
		for (Application entity : items) {
			idsArray[i] = entity.getPk();
			i++;
		}
		return idsArray;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.lang
	 * .Object)
	 */
	/*public String[] getIDsArray(Application item) {
		// return null if List is null 
		if (item == null) {
			return null;
		}
		//Build the idsArray
		String[] idsArray = { item.getId().toString() };
		return idsArray;
	}*/

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getEntityName()
	 */
	public String getEntityName() {
		return "Application";
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#enableItems()
	 */
	public String enableItems() {

		FacesMessage facesMessage = null;
		//Set Error message if no rows selected
		List<Application> selectedItems = getSelectedItems();
		if (selectedItems == null || selectedItems.size() < 1) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		// Fetch the items to be enable.
		//String[] idArrays = getIDsArray(selectedItems);

		//	if (idArrays != null && idArrays.length > 0) {
		try {


			//Deactivate the application services and related processes
			for (int i = 0; i < selectedItems.size(); i++) {

				getApplicationManagement().activateApplicationByName(selectedItems.get(i).getApplicationName());
			}	
			for (int i = 0; i < selectedItems.size(); i++) {
				//Start the applications					
				getApplicationManagement().startApplicationById(selectedItems.get(i).getApplicationName());
				
				// getStatusFieldName should be implemented in subclass
				getApplicationDAO().updateStatus(selectedItems.get(i).getApplicationName(),Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
			}

		} catch (DAOException e) {

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"entity.activateItems.error",
					FacesMessage.SEVERITY_ERROR, getEntityName());
			FacesContext.getCurrentInstance().addMessage("activatItems",
					facesMessage);
			return "";
		}catch (Exception e) {

			facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"controller.generalException",
					FacesMessage.SEVERITY_ERROR, getEntityName(),IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance()
			.addMessage(null, facesMessage);
			return "";
		}

		getPageInfo().setCurrentPage(0);
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.activateItems.success",
				selectedItems.size(), getEntityName());
		FacesContext.getCurrentInstance().addMessage("successActivateItems",
				facesMessage);
		sendNotification(" Activated ",selectedItems);
		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#disableItems()
	 */
	public String disableItems() {

		FacesMessage facesMessage = null;
		//Set Error message if no rows selected
		List<Application> selectedItems = getSelectedItems();
		if (selectedItems == null || selectedItems.size() < 1) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		// Fetch the items to be disable.
		//String[] idArrays = getIDsArray(selectedItems);

		//if (idArrays != null && idArrays.length > 0) {
		try {

			for (int i = 0; i < selectedItems.size(); i++) {
				//Stop the application
				getApplicationManagement().stopApplicationById(selectedItems.get(i).getApplicationName());
				// getStatusFieldName should be implemented in subclass
				getApplicationDAO().updateStatus(selectedItems.get(i).getApplicationName(),Long.valueOf(IConstants.STATUS_TYPE.INACTIVE.ordinal()));

			}

			String appNames[]=new String[selectedItems.size()];
			//Deactivate the application services and related processes
			for (int i = 0; i < selectedItems.size(); i++) {

				getApplicationManagement().deactivateApplicationByName(selectedItems.get(i).getApplicationName());
				appNames[i]=selectedItems.get(i).getApplicationName();
			}

			getApplicationManagement().logOutApplicationUsers(appNames);
			sendNotification(" DeActivated ",selectedItems);

		} catch (DAOException e) {

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"entity.activateItems.error",
					FacesMessage.SEVERITY_ERROR, getEntityName());
			FacesContext.getCurrentInstance().addMessage("activatItems",
					facesMessage);
			return "";
		}catch (Exception e) {

			facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"controller.generalException",
					FacesMessage.SEVERITY_ERROR, getEntityName(),IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance()
			.addMessage(null, facesMessage);
			return "";
		}
		//}
		getPageInfo().setCurrentPage(0);
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.activateItems.success",
				selectedItems.size(), getEntityName());
		FacesContext.getCurrentInstance().addMessage("successActivateItems",
				facesMessage);
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/**
	 * List of Application Items 
	 * @return List of Application Items for the Select Options 
	 */
	public List<SelectItem> getApplications() {
		List<Application> applicationList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		Map<String, Object> searchCriteria=new HashMap<String, Object>();
		searchCriteria.put(getStatusFieldName(), Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
		try {
			// Fetch the List of CurrencyCode objects
			applicationList = getDAO().searchByCriteria(searchCriteria);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the CurrencyCode List to the Select Item List
		for (Application application: applicationList) {

			if ( !application.getApplicationName().equals("ROOT") && !application.getApplicationName().equals("CORE"))
				list.add(new SelectItem(application.getApplicationName(),application.getApplicationName()));		
		}

		return list;
	}

	private void sendNotification(String status,List<Application> selApps) {

		if (notificationService == null)
			notificationService = (NotificationService) SpringAppContext
			.getBean("notificationService");

		for(Application app:selApps)	{

			Map<String, Object> valuesMap = new HashMap<String, Object>();
			valuesMap.put("status", status);
			valuesMap.put("appName", app.getApplicationName());
			try {

				notificationService
				.notifyByMailTemplate(Long.valueOf(17), valuesMap);
			} catch (BusinessException e) {
				log
				.warn("System failed to send mail notification for Activation/Deactivation Application Name="+app.getApplicationName()+" with status"
						+ status);

			}catch(Exception e)		{
				log
				.warn("System failed to send mail notification for Activation/Deactivation Application Name="+app.getApplicationName()+" with status"
						+ status);

			}
		}
	}
}
