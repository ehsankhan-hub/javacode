package com.bsf.ppm.maintenance;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import net.sf.ehcache.Element;

import org.richfaces.component.html.HtmlDataTable;

import com.bsf.ipp.GeneralConfigParameter;
import com.bsf.ipp.GeneralConfiguration;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.cache.CacheManager;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.GeneralConfigurationDAO;
import com.bsf.ppm.spring.SpringAppContext;

import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

public class GeneralConfigurationController extends
		AbstractCrudController<GeneralConfiguration, Long> {
	private GeneralConfigurationDAO generalConfigurationDAO;

	private GeneralConfiguration item;

	public CacheManager getStaticDataCacheManager() {
		return staticDataCacheManager;
	}

	public void setStaticDataCacheManager(CacheManager staticDataCacheManager) {
		this.staticDataCacheManager = staticDataCacheManager;
	}

	private CacheManager staticDataCacheManager;

	public GeneralConfigurationDAO getGeneralConfigurationDAO() {
		return generalConfigurationDAO;
	}

	public void setGeneralConfigurationDAO(
			GeneralConfigurationDAO generalConfigurationDAO) {
		this.generalConfigurationDAO = generalConfigurationDAO;
	}

	private List<GeneralConfiguration> items;

	public PaginatedDAO<GeneralConfiguration, Long> getDAO() {
		// TODO Auto-generated method stub
		return generalConfigurationDAO;
	}

	@Override
	public GeneralConfiguration getItem() {
		// TODO Auto-generated method stub
		return item;
	}

	@Override
	public List<GeneralConfiguration> getItems() {
		if (items == null) {
			reloadItems();
		}

		return items;
	}

	@Override
	public List<GeneralConfiguration> getSelectedItems() {
		List<GeneralConfiguration> selectedList = new ArrayList<GeneralConfiguration>();
		// Get the List of selected items from the dataTable
		for (GeneralConfiguration item : getItems()) {
			// Add item to the selectedList
			if (item.isSelected()) {
				selectedList.add(item);
			}
		}
		return selectedList;
	}

	@Override
	public void setItem(GeneralConfiguration item) {
		this.item = item;
	}

	@Override
	public void setItems(List<GeneralConfiguration> items) {
		this.items = items;
	}

	//@Override
	public String createSetup() {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public String detailSetup() {
		// TODO Auto-generated method stub
		return null;
	}

	/** itemSize (number of items in the list) */
	private int itemsSize;

	/*
	 * return int (itemSize)
	 */
	public int getItemsSize() {
		return getItems().size();
	}

	/**
	 * @return itemSize
	 */
	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#editSetup()
	 */
	public String editSetup() {
		// Get the Item to be passed to Edit page
		item = (GeneralConfiguration) this.getGeneralConfigurationTable()
				.getRowData();
		// Forward to edit Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
	}

	/**
	 * 
	 * @return HtmlDataTable representing backendSystem Table
	 */
	private HtmlDataTable getGeneralConfigurationTable() {
		return (HtmlDataTable) JSFUtil
				.findComponentInRoot("generalConfigurationTable");
	}

	public List<GeneralConfigParameter> getItemParamList() {
		return new ArrayList<GeneralConfigParameter>(getItem()
				.getGeneralConfigParameters().values());

	}

	/**
	 * @param context
	 *            FacesContext reference
	 * @param component
	 *            component that fired the event
	 * @param value
	 *            Value of the UI Component
	 */
	public void validateForm(FacesContext context, UIComponent component,
			Object value) {

		FacesMessage message = null;
		String componentId = component.getId();
		int valueLength = value.toString().length();

		// Do not process if the value is null
		if (value == null) {
			return;
		}

		// Validate for miscellaneous characters
		if (value instanceof String) {
			value=vaildateChars((String) value,context,componentId);

		}

	}

	public String update() {
		getItem().setModifiedBy(JSFUtil.getLoggedInUserInfo());
		getItem().setModifiedDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
		String nev = super.update();
		try {
			staticDataCacheManager.refreshCache("generalConfigurationCache");
		} catch (Exception e) {
			e.printStackTrace();
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"cache.refresherror", FacesMessage.SEVERITY_ERROR,
					getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			return "";

		}
		return nev;

	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.util
	 * .List)
	 */
	public String[] getIDsArray(List<GeneralConfiguration> items) {
		// return null if List is null or empty
		if (items == null || items.size() == 0) {
			return null;
		}
		// Build the array of the ids
		String[] ids = new String[items.size()];
		//add the ids of the items to the array
		int i = 0;
		for (GeneralConfiguration entity : items) {
			ids[i] = entity.getPk();
			i++;
		}
		return ids;
	}
	
	public String refreshThreadPool(){
		// Fetch BusinessDate General Configuration
		Element elem = generalConfigurationCache.get("threadPoolConfig");
		if (elem != null) {
			GeneralConfiguration generalConfig = (GeneralConfiguration) elem.getObjectValue();
			Map<String, GeneralConfigParameter> map = generalConfig.getGeneralConfigParameters();
			Iterator<Map.Entry<String, GeneralConfigParameter>>  it =map.entrySet().iterator();
			String[] threadConfString=null;
			int[] threadConf=null;
		    while (it.hasNext()) {
		        Map.Entry<String, GeneralConfigParameter> pairs =it.next();
		        GeneralConfigParameter confparm=pairs.getValue();
		        threadConfString = confparm.getParamValue().split(",");
		        threadConf=parseStringConfiguration(threadConfString);
		        if (threadConf !=null && threadConf.length==3){
		        	  ((ThreadPoolTaskExecutor)SpringAppContext.getBean( pairs.getKey())).setCorePoolSize(threadConf[0]);
		        	  ((ThreadPoolTaskExecutor)SpringAppContext.getBean( pairs.getKey())).setMaxPoolSize(threadConf[1]);
		        	  ((ThreadPoolTaskExecutor)SpringAppContext.getBean( pairs.getKey())).setQueueCapacity(threadConf[2]);
		        }
		    }
		}	
		return "";
	}

	private int[] parseStringConfiguration(String[] threadConfString) {
		int[] threadConf=null;
		try{
		if (threadConfString !=null && threadConfString.length==3){
			threadConf=new int[3];
			for(int i=0;i<3;i++){
				threadConf[i]=Integer.parseInt(threadConfString[i]);
			}
          if(threadConf[0]>threadConf[1]){
        	  return null;
          }
          if(threadConf[1]>threadConf[2]){
        	  return null;
          }
		}
		}
		catch (Exception e){
			return null;
		}
		return threadConf;
	}

}
