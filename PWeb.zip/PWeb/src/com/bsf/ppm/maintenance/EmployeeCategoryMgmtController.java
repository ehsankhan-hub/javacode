package com.bsf.ppm.maintenance;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import org.apache.log4j.Logger;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;
import javax.servlet.http.HttpServletRequest;


import org.richfaces.component.html.HtmlDataTable;

import com.bsf.ipp.GeneralConfiguration;
import com.bsf.ipp.IPPUTIL;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.AccountClass;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.PpmGroup;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.InstructionDAO;
import com.bsf.ppm.dao.ParameterValueDAO;
import com.bsf.ppm.dao.PpmEmpCategoryMgmtDAO;
import com.bsf.ppm.dao.PpmGroupDAO;
import com.bsf.ppm.dao.jpa.ParameterValueJpaDAO;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.spring.SpringAppContext;
import com.sun.faces.util.MessageFactory;

/**
 * CRUD Controller Class for the PpmGroup CRUD Operations.
 */

public class EmployeeCategoryMgmtController extends
		AbstractCrudController<AccountClass, String> {
	
	//private static org.apache.log4j.Logger log = Logger.getLogger(EmployeeCategoryMgmtController.class);
	
	private AccountClass item;
	


	/** Attribute ppmGroupDAO DAO object for ppmGroup */
	private PpmEmpCategoryMgmtDAO ppmEmpCategoryMgmtDAO;
	
	/** Attribute item PpmGroup Entity */
	

	/** Attribute items for PpmGroup Entity List */
	private List<AccountClass> items;
	
	private ParameterValueDAO parameterValueDAO;
	
	private InstructionDAO instructionDAO;
	
	private String selectedApplication;
	
	/** itemSize (number of items in the list)*/
	private long itemsSize = 0;
	/*
	 * return int (itemSize)
	 */
	public long getItemsSize() {
		 
		return itemsSize;
	}

	/**
	 * @return itemSize
	 */
	public void setItemsSize(long itemsSize) {
		this.itemsSize = itemsSize;
	}

	
	/**
	 * Constructor for BatchJobController
	 */
	public EmployeeCategoryMgmtController() {

		//Initialize item object 
		item = new AccountClass();
		
		
	}

	
	
	
	public PpmEmpCategoryMgmtDAO getPpmEmpCategoryMgmtDAO() {
		return ppmEmpCategoryMgmtDAO;
	}

	public void setPpmEmpCategoryMgmtDAO(PpmEmpCategoryMgmtDAO ppmEmpCategoryMgmtDAO) {
		this.ppmEmpCategoryMgmtDAO = ppmEmpCategoryMgmtDAO;
	}

	/**
	 * @return the selectedApplication
	 */
	public String getSelectedApplication() {
		return selectedApplication;
	}

	/**
	 * @param selectedApplication the selectedApplication to set
	 */
	public void setSelectedApplication(String selectedApplication) {
		this.selectedApplication = selectedApplication;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItems()
	 */
	public List<AccountClass> getItems() {
		
		return items;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getDAO()
	 */
	public PaginatedDAO<AccountClass, String> getDAO() {
		return ppmEmpCategoryMgmtDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItem(java.lang.Object
	 * )
	 */
	public void setItem(AccountClass item) {
		this.item = item;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItems(java.util.
	 * List)
	 */
	public void setItems(List<AccountClass> items) {
		this.items = items;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItem()
	 */
	public AccountClass getItem() {
		return item;
	}
	
	
	public ParameterValueDAO getParameterValueDAO() {
		return parameterValueDAO;
	}

	public void setParameterValueDAO(ParameterValueDAO parameterValueDAO) {
		this.parameterValueDAO = parameterValueDAO;
	}

	public void setInstructionDAO(InstructionDAO instructionDAO) {
		this.instructionDAO = instructionDAO;
	}

	public InstructionDAO getInstructionDAO() {
		return instructionDAO;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getSelectedItems()
	 */
	public List<AccountClass> getSelectedItems() {
		List<AccountClass> selectedList = new ArrayList<AccountClass>();
		//Get the List of selected items from the dataTable
		for (AccountClass item : getItems()) {
			
			// Add item to the selectedList if the item is selected
			if (item.isSelected()){
				System.out.println("Selected Item ="+item.getAccountNo());
				selectedList.add(item);
			}
		}
		return selectedList;

	}
	
	/**
	 * 
	 * @return HtmlDataTable representing ppmGroupTable
	 */
	public HtmlDataTable getPpmGroupTable() {
		return (HtmlDataTable) JSFUtil.findComponentInRoot("ppmEmpCtgMgmtTable");
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String listSetupString() {

		
		
		
		// Set 0 as the first page
		
		if (getPageInfo() != null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		//reloadItems();
		// returns the Navigation case for list page
		System.out.println(getClass().getSimpleName());
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	@Override
	public String editSetup() {
	
		return getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String detailSetup() {
		//Get the Item to be passed to Detail page
		item = (AccountClass) this.getPpmGroupTable().getRowData();
		//Forward to detail Navigation case
		
		
		 FacesContext context = FacesContext.getCurrentInstance();
		    HttpServletRequest origRequest = (HttpServletRequest)context.getExternalContext().getRequest();
		String  contextPath = origRequest.getContextPath();
		try {
		        FacesContext.getCurrentInstance().getExternalContext()
		                .redirect(contextPath  + "/ppm/blockUnblock/editEmpCategoryMgmt.jsf");
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		
		
		
		
		//not being used
		return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
		
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#createSetup()
	 */
	public String createSetup() {
		// create a new instance of item
		item = new AccountClass();
		//Forward to create Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_CREATE_NAVIGATION;
	}

	/**
	 * @param context FacesContext reference 
	 * @param component component that fired the event
	 * @param value Value of the UI Component
	 */
	
	public void validateForm(FacesContext context, UIComponent component,
			Object value) {
		
		FacesMessage message = null;
		String componentId = component.getId();
		int valueLength;
		
		// Do not process if the value is null
		if (value == null) {
			return;
		}
		else {
			valueLength=value.toString().length();
		}
		
		//Validate for miscellaneous characters 
		if ((componentId.equalsIgnoreCase("accountNo") && (value instanceof String))) {
			value=vaildateChars((String) value,context,componentId);
		}
		
		//Validation for groupCode component
		if (componentId.equalsIgnoreCase("accountNo")) {
			//Check length
			if (valueLength < 11 ) {
				
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupCode.chars",FacesMessage.SEVERITY_ERROR, componentId,5);
				throw new ValidatorException(message);
			}
		}
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#isUnique()
	 */
	public boolean isUnique() {
		boolean isUnique = false;
		try {
			//Check if the item is Unique in the Table
			isUnique = getDAO().isUnique(getItem());
		} catch (DAOException e) {
			
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.BusinessErrorMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUnique;
	}

	public void createView() {
		
		item.setAccountNo("");
		item.setEmpCategory("");
		
		 FacesContext context = FacesContext.getCurrentInstance();
		    HttpServletRequest origRequest = (HttpServletRequest)context.getExternalContext().getRequest();
		String  contextPath = origRequest.getContextPath();
		try {
		        FacesContext.getCurrentInstance().getExternalContext()
		                .redirect(contextPath  + "/ppm/blockUnblock/createEmpCategoryMgmt.jsf");
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		
}
	
	public void cancelView() {
		
		 FacesContext context = FacesContext.getCurrentInstance();
		    HttpServletRequest origRequest = (HttpServletRequest)context.getExternalContext().getRequest();
		String  contextPath = origRequest.getContextPath();
		try {
		        FacesContext.getCurrentInstance().getExternalContext()
		                .redirect(contextPath  + "/ppm/blockUnblock/listEmployeeCategoryMgmt.jsf");
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		
		//reloadItems();
		
}

	@Override
	public String create() {
		
		AccountClass obj = null;
		FacesMessage facesMessage = null;

		try {
			// Create the Item in the Database
			if (isUnique()) {
			obj = 	getDAO().save(getItem());
				// getDAO().refresh(getItem());

			} else {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"entity.duplicate", FacesMessage.SEVERITY_ERROR,
						getEntityName());
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return null; 

			}

		} catch (ApplicationException e) {
			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.add.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);

			// Return Navigation case of the create page
			return null;
		} catch (Exception e) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"controller.generalException", FacesMessage.SEVERITY_ERROR,
					getEntityName(), IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			return null;

		}
		
		
		
		if (obj != null) {

			try {
				getParameterValueDAO().updateEmpCategorySetupList(item);
				getParameterValueDAO().insertLogHistory(item,"ADD");

			} catch (DAOException e) {

				e.printStackTrace();
			}

		}
		
		
		
		
		// Initialize the Search Criteria

		// searchCriteria = new HashMap<String, Object>();

		// Reload the items in the list displayed to the user
		//reloadItems();
		getPageInfo().setCurrentPage(0);

		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.add.success", getEntityName(),
				getItem());
		FacesContext.getCurrentInstance()
		.addMessage("successAdd", facesMessage);
		// Return navigation case of the list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	
	
	
	
	}
	
	@Override
	public String update() {
		
		
		AccountClass obj = null;
		FacesMessage facesMessage = null;
		try {
			// update the Item in the Database Table
			if (isUniqueForUpdate()) {
				obj =	getDAO().saveOrUpdate(getItem());

			} else {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"entity.duplicate", FacesMessage.SEVERITY_ERROR,
						getItem());
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";
			}
		} catch (ApplicationException e) {
			log.warn("System failed to update ",e);

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.update.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);

			// Return the navigation case for edit page
			return "";
		} catch (Exception e) {
			log.warn("System failed to update ",e);

			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"controller.generalException", FacesMessage.SEVERITY_ERROR,
					getEntityName(), IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			return "";

		}
		
		
		
		if (obj != null) {

			try {
				getParameterValueDAO().updateEmpCategorySetupList(item);
				
				getParameterValueDAO().insertLogHistory(item,"UPD");
		
			} catch (DAOException e) {

				e.printStackTrace();
			}

		}
		
		// Set the page number to Zero
		getPageInfo().setCurrentPage(0);

		// Set the search criteria
		// searchCriteria = new HashMap<String, Object>();

		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.update.success", getEntityName(),
				getItem());
		FacesContext.getCurrentInstance()
		.addMessage("successAdd", facesMessage);
	
			
			
	
			// return the Navigation case for list page
			return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
			
	}

	@Override
	public String deleteItem() {
		 
		String navigationCase = super.deleteItem();
		
		try {
			getParameterValueDAO().insertLogHistory(item,"DEL");
		} catch (DAOException e) {
			
			e.printStackTrace();
		}

		return navigationCase;
	}
	
	

	
	@Override
	public String deleteItems() {
		FacesMessage facesMessage = null;
		if (items != null && !items.isEmpty()) {

			
			if (getSelectedItems() == null || getSelectedItems().size() < 1) {
				facesMessage = JSFUtil.getMessage(
						FacesContext.getCurrentInstance(),
						"bundles.UIMessages", "entity.noRowSelected",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance().addMessage("noRow",
						facesMessage);
				return "";
			}
			// Fetch the items to be deleted.
			List<AccountClass> itemsFordelete = getSelectedItems();

			if (itemsFordelete != null && itemsFordelete.size() > 0) {
				try {
					// Delete the items from the Database Table
					getDAO().delete(itemsFordelete);

					// log table entry

					for (int i = 0; i < itemsFordelete.size(); i++) {

						try {

							getParameterValueDAO().insertLogHistory(
									itemsFordelete.get(i), "DEL");
							Thread.sleep(500);

						} catch (Exception e) {
							e.printStackTrace();
						}

					}

				} catch (DAOException e) {

					// Set the error Message from the ResourceBundle
					facesMessage = JSFUtil.getMessage(
							FacesContext.getCurrentInstance(),
							"bundles.UIMessages", "entity.deleteItems.error",
							FacesMessage.SEVERITY_ERROR, getEntityName());
					FacesContext.getCurrentInstance().addMessage("deleteItems",
							facesMessage);
					return "";

				} catch (Exception e) {
					facesMessage = JSFUtil.getMessage(
							FacesContext.getCurrentInstance(),
							"bundles.UIMessages",
							"controller.generalException",
							FacesMessage.SEVERITY_ERROR, getEntityName(),
							IPPUTIL.buildExceptionMessage(e));
					FacesContext.getCurrentInstance().addMessage(null,
							facesMessage);
					return "";

				}
			}
			// Reload the items in the list
			reloadItems();
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.deleteItems.success", itemsFordelete.size(),
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("successDeleteItems",
					facesMessage);

		}else{

			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(),
					"bundles.UIMessages", "entity.noRowSelected",
					FacesMessage.SEVERITY_ERROR, getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow",
					facesMessage);
			return "";
		
			
		}

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
	
	
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.util.List)
	 */
	public String[] getIDsArray(List<AccountClass> items) {
		// return null if List is null or empty
		if (items == null || items.size() == 0) {
			return null;
		}
		// Build the array of the ids
		String[] ids = new String[items.size()];
		System.out.println("ids---"+ids.length);
		int i = 0;
		for (AccountClass entity : items) {
			ids[i] = entity.getPk();
			i++;
		}
		
		return ids;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.lang.Object)
	 */
	public String[] getIDsArray(AccountClass item) {
		// return null if item is null 
		if (item == null) {
			return null;
		}
		//Build the idsArray
		System.out.println("item.getAccountNo()() "+item.getAccountNo());
		String[] ids = { item.getAccountNo() };
		return ids;
	}


	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getEntityName()
	 */
	public String getEntityName() {
		return "Account";
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getStatusFieldName()
	 */
	public String getStatusFieldName() {
		return "empCategory";

	}	
	
	public String getIdFieldName() {
		return "accountNo";
	}
	
	
	public List<SelectItem> empCategoryList;
	public List<SelectItem> empCategoryDescList;
	
		
	
	public List<SelectItem> getEmpCategoryList() {

		List<ParameterValue> empCategoryList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			empCategoryList = getParameterValueDAO().getEmpCategoryList();
			
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: empCategoryList) {
			
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	}
	
	
	
	
	
	public ArrayList<SelectItem> getEmpCategoryDescList() {

	
		
		
		
		
		List<ParameterValue> empCategoryDescList = null;
		ArrayList<SelectItem>	list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			empCategoryDescList = getParameterValueDAO().getEmpCategoryDescList();
			
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: empCategoryDescList) {
			
			list.add(new SelectItem(parameterValue.getValue1().substring(0, 2).trim(),parameterValue.getValue1()));		
		}
		
		
		return list;
		
	}

	

	
	
	
	
	
	
	
	
	
	
	
	
}
