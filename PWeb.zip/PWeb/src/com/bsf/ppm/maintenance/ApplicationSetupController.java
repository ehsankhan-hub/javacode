package com.bsf.ppm.maintenance;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;

import org.richfaces.component.html.HtmlDataTable;

import com.bsf.ipp.GeneralConfiguration;
import com.bsf.ipp.IPPUTIL;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.PpmGroup;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.InstructionDAO;
import com.bsf.ppm.dao.ParameterValueDAO;
import com.bsf.ppm.dao.PpmGroupDAO;

import com.bsf.ppm.exceptions.DAOException;

import com.sun.faces.util.MessageFactory;

/**
 * CRUD Controller Class for the PpmGroup CRUD Operations.
 */
public class ApplicationSetupController extends
		AbstractCrudController<PpmGroup, String> {

	/** Attribute ppmGroupDAO DAO object for ppmGroup */
	private PpmGroupDAO ppmGroupDAO;
	
	/** Attribute item PpmGroup Entity */
	private PpmGroup item;

	/** Attribute items for PpmGroup Entity List */
	private List<PpmGroup> items;
	
	private ParameterValueDAO parameterValueDAO;
	
	private InstructionDAO instructionDAO;
	
	private String selectedApplication;
	
	/** itemSize (number of items in the list)*/
	private int itemsSize;
	/*
	 * return int (itemSize)
	 */
	public int getItemsSize() {
		if(getItems()!=null){
		
		return getItems().size();
		}
		else{
		return 0;	
		}
	}

	/**
	 * @return itemSize
	 */
	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}

	
	/**
	 * Constructor for BatchJobController
	 */
	public ApplicationSetupController() {
		//Initialize item object 
		item = new PpmGroup();
		// Initialize default Search criteria
		this.getSearchCriteria().put(getStatusFieldName(), "A");
		
		// Initialize default sort field
		sortField = "groupCode";
		sortAscending=true;
	}

	/**
	 * @return the ppmGroupDAO
	 */
	public PpmGroupDAO getPpmGroupDAO() {
		return ppmGroupDAO;
	}

	/**
	 * @param ppmGroupDAO the ppmGroupDAO to set
	 */
	public void setPpmGroupDAO(PpmGroupDAO ppmGroupDAO) {
		this.ppmGroupDAO = ppmGroupDAO;
	}

	/**
	 * @return the selectedApplication
	 */
	public String getSelectedApplication() {
		return selectedApplication;
	}

	/**
	 * @param selectedApplication the selectedApplication to set
	 */
	public void setSelectedApplication(String selectedApplication) {
		this.selectedApplication = selectedApplication;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItems()
	 */
	public List<PpmGroup> getItems() {
		if (items == null) {
			reloadItems();
		}
		return items;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getDAO()
	 */
	public PaginatedDAO<PpmGroup, String> getDAO() {
		return ppmGroupDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItem(java.lang.Object
	 * )
	 */
	public void setItem(PpmGroup item) {
		this.item = item;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItems(java.util.
	 * List)
	 */
	public void setItems(List<PpmGroup> items) {
		this.items = items;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItem()
	 */
	public PpmGroup getItem() {
		return item;
	}
	
	
	public ParameterValueDAO getParameterValueDAO() {
		return parameterValueDAO;
	}

	public void setParameterValueDAO(ParameterValueDAO parameterValueDAO) {
		this.parameterValueDAO = parameterValueDAO;
	}

	public void setInstructionDAO(InstructionDAO instructionDAO) {
		this.instructionDAO = instructionDAO;
	}

	public InstructionDAO getInstructionDAO() {
		return instructionDAO;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getSelectedItems()
	 */
	public List<PpmGroup> getSelectedItems() {
		List<PpmGroup> selectedList = new ArrayList<PpmGroup>();
		//Get the List of selected items from the dataTable
		for (PpmGroup item : getItems()) {
			
			// Add item to the selectedList if the item is selected
			if (item.isSelected()){
				System.out.println("Selected Item groupcode="+item.getGroupCode());
				selectedList.add(item);
			}
		}
		return selectedList;

	}
	
	/**
	 * 
	 * @return HtmlDataTable representing ppmGroupTable
	 */
	public HtmlDataTable getPpmGroupTable() {
		return (HtmlDataTable) JSFUtil.findComponentInRoot("ppmGroupTable");
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String listSetupString() {

		// Initialize default values for SearchCriteria and PageInfo
		if (getSearchCriteria() != null) {
			setSearchCriteria(new HashMap<String, Object>());
			getSearchCriteria().put(getStatusFieldName(),"A");
		}
		// Set 0 as the first page
		if (getPageInfo() != null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		reloadItems();
		// returns the Navigation case for list page
		System.out.println(getClass().getSimpleName());
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	@Override
	public String editSetup() {
	
		return getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String detailSetup() {
		//Get the Item to be passed to Detail page
		item = (PpmGroup) this.getPpmGroupTable().getRowData();
		//Forward to detail Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#createSetup()
	 */
	public String createSetup() {
		// create a new instance of item
		item = new PpmGroup();
		//Forward to create Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_CREATE_NAVIGATION;
	}

	/**
	 * @param context FacesContext reference 
	 * @param component component that fired the event
	 * @param value Value of the UI Component
	 */
	public void validateForm(FacesContext context, UIComponent component,
			Object value) {
		
		FacesMessage message = null;
		String componentId = component.getId();
		int valueLength;
		
		// Do not process if the value is null
		if (value == null) {
			return;
		}
		else {
			valueLength=value.toString().length();
		}
		
		//Validate for miscellaneous characters 
		if ((componentId.equalsIgnoreCase("groupCode") || componentId.equalsIgnoreCase("groupDesc")
				|| componentId.equalsIgnoreCase("groupName"))
				&& (value instanceof String)) {
			value=vaildateChars((String) value,context,componentId);
		}
		
		//Validation for groupCode component
		if (componentId.equalsIgnoreCase("groupCode")) {
			//Check length
			if (valueLength >5 ) {
				
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupCode.chars",FacesMessage.SEVERITY_ERROR, componentId,5);
				throw new ValidatorException(message);
			}
		}//Validation for groupDesc component 
		else if (componentId.equalsIgnoreCase("groupDesc")) {
			//Check length
			if (valueLength >50 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupDesc.chars",FacesMessage.SEVERITY_ERROR, componentId, 50);
				throw new ValidatorException(message);
			}
		}//Validation for groupName component
		else if (componentId.equalsIgnoreCase("groupName")) {
			//Check length
			if (valueLength >30 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.jobDescription.chars",FacesMessage.SEVERITY_ERROR, componentId, 30);
				throw new ValidatorException(message);
			}
		}
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#isUnique()
	 */
	public boolean isUnique() {
		boolean isUnique = false;
		try {
			//Check if the item is Unique in the Table
			isUnique = getDAO().isUnique(getItem());
		} catch (DAOException e) {
			
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.BusinessErrorMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUnique;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#create()
	 */
	public String create() {
		FacesMessage facesMessage = null;
		String nav = "";
		try {
			//Set userInfo for CurrencyCode
			item.setCreatedBy(JSFUtil.getLoggedInUserInfo());
			//Set create Date
			item.setCreateDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						
			//set Status as Active
			item.setStatus("A");
			//Set navigation case from super.create
			nav = super.create();
		
		} catch (Exception e) {

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.add.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);
			//Print StackTrace
			e.printStackTrace();
			// Return Navigation case of the create page
			return "";
		}

		return nav;
	}

	/**
	 * Update the entity in the database. Serves user update action on Edit page.
	 * @return List page Navigation case defined in faces-config.xml
	 */
	@Override
	public String update() {
		FacesMessage facesMessage = null;
		// set update information
		getItem().setUpdatedBy(JSFUtil.getLoggedInUserInfo());
		getItem().setUpdateDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				
		//call super.update
		String navigationCase = super.update();
		
		try{
			getInstructionDAO().updateInstructionPriority(getItem().getGroupCode(), getItem().getGroupPriority());
		}catch (Exception e){

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.update.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);
			e.printStackTrace();

			// Return Navigation case of the create page
			return "";
		
		}
		
		return navigationCase;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItem()
	 */
	public String disableItem() {
		FacesMessage facesMessage = null;
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getItem());
		
		for(int i=0;i<idArrays.length;i++){
			System.out.println("disableItem idArrays="+idArrays[i]);
		}

		if (idArrays != null && idArrays.length > 0) {
			try {
				
				getPpmGroupDAO().updateEntityStatusByIds(idArrays,getIdFieldName(),
						getStatusFieldName(),  "I", JSFUtil.getLoggedInUserInfo());

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil
				.getMessage(FacesContext.getCurrentInstance(),
						"bundles.UIMessages",
						"entity.deActivateItem.error",
						FacesMessage.SEVERITY_ERROR, getItem(),
						getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"entity.deleteItem", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.deActivateItem.success",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage("successDeleteItem",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItem()
	 */
	public String enableItem() {
		FacesMessage facesMessage = null;
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getItem());
		System.out.println("=====AbstractCrudController. enableItem ");
		for(int i=0;i<idArrays.length;i++){
			System.out.println("disableItem idArrays="+idArrays[i]);
		}

		if (idArrays != null && idArrays.length > 0) {
			try {
				// Delete the items from the Database Table
				// getStatusFieldName should be implemented in subclass
				getPpmGroupDAO().updateEntityStatusByIds(idArrays, getIdFieldName(),
						getStatusFieldName(), "A", JSFUtil.getLoggedInUserInfo());

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil
				.getMessage(FacesContext.getCurrentInstance(),
						"bundles.UIMessages",
						"entity.activateItem.error",
						FacesMessage.SEVERITY_ERROR, getItem(),
						getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"activateItem.error", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.activateItem.success",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage(
				"itemActivatedSuccessfully", facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItems()
	 */
	public String disableItems() {
		FacesMessage facesMessage = null;
		if (getSelectedItems() == null || getSelectedItems().size() < 1) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getSelectedItems());
		System.out.println("=====AbstractCrudController. disableItems ");
		for(int i=0;i<idArrays.length;i++){
			System.out.println("disableItem idArrays="+idArrays[i]);
		}

		if (idArrays != null && idArrays.length > 0) {
			try {
				// Delete the items from the Database Table
				// getStatusFieldName should be implemented in subclass
				getPpmGroupDAO().updateEntityStatusByIds(idArrays,getIdFieldName(),
						getStatusFieldName(), "I", JSFUtil.getLoggedInUserInfo());
			} catch (DAOException e) {
				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"entity.deActivateItems.error",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"deActivateItemsError", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		getPageInfo().setCurrentPage(0);
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.deActivateItems.success",
				idArrays.length, getEntityName());
		FacesContext.getCurrentInstance().addMessage("successDeleteItems",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItems()
	 */
	public String enableItems() {
		FacesMessage facesMessage = null;
		System.out.println("getSelectedItems().size()=="+getSelectedItems().size());
		if (getSelectedItems() == null || getSelectedItems().size() < 1) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		// Fetch the items to be deleted.
	 
		String[] idArrays = getIDsArray(getSelectedItems());
		System.out.println("idArrays=="+getIDsArray(getSelectedItems()));
		System.out.println("idArrays==="+idArrays.length);
		for(int i=0;i<idArrays.length;i++){
			System.out.println("disableItem idArrays="+idArrays[i]);
		}

		System.out.println("=====AbstractCrudController. enableItems ");
		if (idArrays != null && idArrays.length > 0) {
			try {
				// Delete the items from the Database Table
				// getStatusFieldName should be implemented in subclass
				getPpmGroupDAO().updateEntityStatusByIds(idArrays, getIdFieldName(),
						getStatusFieldName(), "A", JSFUtil.getLoggedInUserInfo());

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"entity.activateItems.error",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance().addMessage("activatItems",
						facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		getPageInfo().setCurrentPage(0);
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.activateItems.success",
				idArrays.length, getEntityName());
		FacesContext.getCurrentInstance().addMessage("successActivateItems",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.util.List)
	 */
	public String[] getIDsArray(List<PpmGroup> items) {
		// return null if List is null or empty
		if (items == null || items.size() == 0) {
			return null;
		}
		// Build the array of the ids
		String[] ids = new String[items.size()];
		System.out.println("ids---"+ids.length);
		int i = 0;
		for (PpmGroup entity : items) {
			ids[i] = entity.getPk();
			i++;
		}
		
		return ids;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.lang.Object)
	 */
	public String[] getIDsArray(PpmGroup item) {
		// return null if item is null 
		if (item == null) {
			return null;
		}
		//Build the idsArray
		System.out.println("item.getGroupCode() "+item.getGroupCode() );
		String[] ids = { item.getGroupCode() };
		return ids;
	}


	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getEntityName()
	 */
	public String getEntityName() {
		return "Ppm Group";
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getStatusFieldName()
	 */
	public String getStatusFieldName() {
		return "status";

	}	
	
	public String getIdFieldName() {
		return "groupCode";
	}
	/**
	 * Fetch Group Priority to be displayed in search criteria
	 * @return List of Group Priority Items for the Select Options
	 */
	public List<SelectItem> getGroupPriorityList() {

		List<ParameterValue> groupPriorityList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			groupPriorityList = getParameterValueDAO().getPriorityList();
			System.out.println("groupPriorityList=="+groupPriorityList);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: groupPriorityList) {
			
			System.out.println("parameterValue=="+parameterValue.getValue1());
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	} 
	
	

	
	
	
	/**
	 * Fetch Group Status to be displayed in search criteria
	 * @return List of Group Status Items for the Select Options
	 */
	public List<SelectItem> getGroupStatusList() {

		List<ParameterValue> groupStatusList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			groupStatusList = getParameterValueDAO().getStatus();
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: groupStatusList) {
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	}
	
	/**
	 * Fetch Group Status to be displayed in search criteria
	 * @return List of Group Status Items for the Select Options
	 */
	public List<SelectItem> getGroupPercentList() {

		List<ParameterValue> groupPercentList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			groupPercentList = getParameterValueDAO().getPercent();
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		list.add(new SelectItem("0","-Select-"));	
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: groupPercentList) {
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	}
	
}
