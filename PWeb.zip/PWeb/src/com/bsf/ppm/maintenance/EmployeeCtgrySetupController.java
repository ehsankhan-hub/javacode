package com.bsf.ppm.maintenance;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;
import javax.servlet.http.HttpServletRequest;

import org.richfaces.component.html.HtmlDataTable;

import com.bsf.ipp.IPPUTIL;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.AccountClass;
import com.bsf.ppm.PpmParameterValuesSetup;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.InstructionDAO;
import com.bsf.ppm.dao.ParameterValueDAO;
import com.bsf.ppm.dao.PpmEmpCategorySetupDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.sun.faces.util.MessageFactory;

/**
 * CRUD Controller Class for the PpmGroup CRUD Operations.
 */
public class EmployeeCtgrySetupController extends
		AbstractCrudController<PpmParameterValuesSetup, String> {

	/** Attribute ppmGroupDAO DAO object for ppmGroup */
	private PpmEmpCategorySetupDAO ppmEmpCategorySetupDAO;
	
	/** Attribute item PpmGroup Entity */
	private PpmParameterValuesSetup item;

	/** Attribute items for PpmGroup Entity List */
	private List<PpmParameterValuesSetup> items;
	
	private ParameterValueDAO parameterValueDAO;
	
	private InstructionDAO instructionDAO;
	
	private String selectedApplication;
	
	/** itemSize (number of items in the list)*/
	private int itemsSize;
	/*
	 * return int (itemSize)
	 */
	public int getItemsSize() {
		return getItems().size();
	}

	/**
	 * @return itemSize
	 */
	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}

	
	/**
	 * Constructor for BatchJobController
	 */
	public EmployeeCtgrySetupController() {
		//Initialize item object 
		item = new PpmParameterValuesSetup();
		
		// Initialize default Search criteria
		this.getSearchCriteria().put(getStatusFieldName(), "EMPCTRY");
		this.getSearchCriteria().put("groupCode", "LLS");
		
		// Initialize default sort field
		sortField = "groupCode";
		sortAscending=true;
	}

	
	
	
	

	public PpmEmpCategorySetupDAO getPpmEmpCategorySetupDAO() {
		return ppmEmpCategorySetupDAO;
	}

	public void setPpmEmpCategorySetupDAO(
			PpmEmpCategorySetupDAO ppmEmpCategorySetupDAO) {
		this.ppmEmpCategorySetupDAO = ppmEmpCategorySetupDAO;
	}

	/**
	 * @return the selectedApplication
	 */
	public String getSelectedApplication() {
		return selectedApplication;
	}

	/**
	 * @param selectedApplication the selectedApplication to set
	 */
	public void setSelectedApplication(String selectedApplication) {
		this.selectedApplication = selectedApplication;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItems()
	 */
	public List<PpmParameterValuesSetup> getItems() {
		if (items == null) {
			reloadItems();
		}
		return items;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getDAO()
	 */
	public PaginatedDAO<PpmParameterValuesSetup, String> getDAO() {
		return ppmEmpCategorySetupDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItem(java.lang.Object
	 * )
	 */
	public void setItem(PpmParameterValuesSetup item) {
		this.item = item;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItems(java.util.
	 * List)
	 */
	public void setItems(List<PpmParameterValuesSetup> items) {
		this.items = items;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItem()
	 */
	public PpmParameterValuesSetup getItem() {
		return item;
	}
	
	
	public ParameterValueDAO getParameterValueDAO() {
		return parameterValueDAO;
	}

	public void setParameterValueDAO(ParameterValueDAO parameterValueDAO) {
		this.parameterValueDAO = parameterValueDAO;
	}

	public void setInstructionDAO(InstructionDAO instructionDAO) {
		this.instructionDAO = instructionDAO;
	}

	public InstructionDAO getInstructionDAO() {
		return instructionDAO;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getSelectedItems()
	 */
	public List<PpmParameterValuesSetup> getSelectedItems() {
		List<PpmParameterValuesSetup> selectedList = new ArrayList<PpmParameterValuesSetup>();
		//Get the List of selected items from the dataTable
		for (PpmParameterValuesSetup item : getItems()) {
			
			// Add item to the selectedList if the item is selected
			if (item.isSelected()){
				
				selectedList.add(item);
			}
		}
		return selectedList;

	}
	
	/**
	 * 
	 * @return HtmlDataTable representing ppmGroupTable
	 */
	public HtmlDataTable getPpmGroupTable() {
		return (HtmlDataTable) JSFUtil.findComponentInRoot("ppmEmpCtgSetupTable");
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String pageSetupString() {

		// Initialize default values for SearchCriteria and PageInfo
		if (getSearchCriteria() != null) {
			setSearchCriteria(new HashMap<String, Object>());
			getSearchCriteria().put(getStatusFieldName(),"EMPCTRY");
			this.getSearchCriteria().put("groupCode", "LLS");
		}
		
		
		
		// Set 0 as the first page
		
		if (getPageInfo() != null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		reloadItems();
		// returns the Navigation case for list page
		System.out.println(getClass().getSimpleName());
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	@Override
	public String editSetup() {
	
		return getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String detailSetup() {
		//Get the Item to be passed to Detail page
		item = (PpmParameterValuesSetup) this.getPpmGroupTable().getRowData();
		item.setUpdatedBy(JSFUtil.getLoggedInUserInfo().getUserId());
		item.setUpdateDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
	
		//Forward to detail Navigation case
		
		
		 FacesContext context = FacesContext.getCurrentInstance();
		    HttpServletRequest origRequest = (HttpServletRequest)context.getExternalContext().getRequest();
		String  contextPath = origRequest.getContextPath();
		try {
		        FacesContext.getCurrentInstance().getExternalContext()
		                .redirect(contextPath  + "/ppm/blockUnblock/editEmpCategorySetup.jsf");
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		
		
		
		
		//not being used
		return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
		
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#createSetup()
	 */
	public String createSetup() {
		// create a new instance of item
		item = new PpmParameterValuesSetup();
		
		//Forward to create Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_CREATE_NAVIGATION;
	}

	/**
	 * @param context FacesContext reference 
	 * @param component component that fired the event
	 * @param value Value of the UI Component
	 */
	/*public void validateForm(FacesContext context, UIComponent component,
			Object value) {
		
		FacesMessage message = null;
		String componentId = component.getId();
		int valueLength;
		
		// Do not process if the value is null
		if (value == null) {
			return;
		}
		else {
			valueLength=value.toString().length();
		}
		
		
		
		//Validation for groupCode component
		if ((componentId.equalsIgnoreCase("value1") && ("value1" instanceof String))) {
			
				
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupCode.chars",FacesMessage.SEVERITY_ERROR, componentId,5);
				throw new ValidatorException(message);
			
		}
	}*/
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#isUnique()
	 */
	public boolean isUnique() {
		boolean isUnique = false;
		try {
			//Check if the item is Unique in the Table
			isUnique = getDAO().isUnique(getItem());
		} catch (DAOException e) {
			
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.BusinessErrorMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUnique;
	}

	public void createView() {
		
		item = new PpmParameterValuesSetup();
		item.setParamTypeCode("EMPCTRY");
		item.setGroupCode("LLS");
		item.setCreatedBy(JSFUtil.getLoggedInUserInfo().getUserId());
		item.setCreateDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
		
		 FacesContext context = FacesContext.getCurrentInstance();
		    HttpServletRequest origRequest = (HttpServletRequest)context.getExternalContext().getRequest();
		String  contextPath = origRequest.getContextPath();
		try {
		        FacesContext.getCurrentInstance().getExternalContext()
		                .redirect(contextPath  + "/ppm/blockUnblock/createEmpCategorySetup.jsf");
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		
}
	
	public void cancelView() {
		
		 FacesContext context = FacesContext.getCurrentInstance();
		    HttpServletRequest origRequest = (HttpServletRequest)context.getExternalContext().getRequest();
		String  contextPath = origRequest.getContextPath();
		try {
		        FacesContext.getCurrentInstance().getExternalContext()
		                .redirect(contextPath  + "/ppm/blockUnblock/listEmployeeCategorySetup.jsf");
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		
		reloadItems();
		
}

	@Override
	public String create() {
		String navigationCase  = super.create();
		
		return navigationCase;
	}
	
	@Override
	public String update() {
		
		
		
		String navigationCase = super.update();
		
		
		
		
		return navigationCase;
	}

	@Override
	public String deleteItem() {
		 
		String navigationCase = super.deleteItem();

		return navigationCase;
	}
	
	@Override
	public String deleteItems() {

		FacesMessage facesMessage = null;
		
		
	
		if (getSelectedItems() == null || getSelectedItems().size() < 1) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		
		// Fetch the items to be deleted.
		List<PpmParameterValuesSetup> itemsFordelete = getSelectedItems();
		List<PpmParameterValuesSetup> newDeleteList = new ArrayList<PpmParameterValuesSetup>();

		List<AccountClass> list = new ArrayList<AccountClass>();

		String strCategory = "";

		boolean flag = false;

		for (int i = 0; i < itemsFordelete.size(); i++) {

			list = checkCategoryExists(itemsFordelete.get(i).getValue1());

			if (list != null && !list.isEmpty()) {

				flag = true;

				strCategory += "Category " + itemsFordelete.get(i).getValue1()+ " - ";
			} else {

				newDeleteList.add(itemsFordelete.get(i));
			}
		}

		if (flag) {

			String msg = " Cannot Delete. " + strCategory
					+ "Assigned to Accounts.";
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, "."));

		}
		
		itemsFordelete = newDeleteList;

		if (itemsFordelete != null && itemsFordelete.size() > 0) {
			try {
				// Delete the items from the Database Table
				getDAO().delete(itemsFordelete);
				
				

				facesMessage = JSFUtil.getMessage(
						FacesContext.getCurrentInstance(),
						"bundles.UIMessages", "entity.deleteItems.success",
						itemsFordelete.size(), getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"successDeleteItems", facesMessage);
				
				
				
				
				
				
				
				
				// Logs - Log History table Insert.
				
		
					for (int i = 0; i < itemsFordelete.size(); i++) {

						// Enter in log table
						try {

							getParameterValueDAO().insertLogHistoryEmpSetupDel(
									itemsFordelete.get(i).getValue1());

							Thread.sleep(500);

						} catch (Exception e) {

							e.printStackTrace();
						}

					}

				
				

				

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil.getMessage(
						FacesContext.getCurrentInstance(),
						"bundles.UIMessages", "entity.deleteItems.error",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance().addMessage("deleteItems",
						facesMessage);
				return "";

			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(
						FacesContext.getCurrentInstance(),
						"bundles.UIMessages", "controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(),
						IPPUTIL.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
						.addMessage(null, facesMessage);
				return "";

			}
		}
		
		
		
		
		
		
		
		
		
		// Reload the items in the list
		reloadItems();

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;

	}
	
	
	
	public List<AccountClass> checkCategoryExists(String category){
		
		List<AccountClass> list = null;
		
		try {
			// Fetch the List of Application objects
			list = getParameterValueDAO().checkCategoryExists(category);
			
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	
	
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.util.List)
	 */
	public String[] getIDsArray(List<PpmParameterValuesSetup> items) {
		// return null if List is null or empty
		if (items == null || items.size() == 0) {
			return null;
		}
		// Build the array of the ids
		String[] ids = new String[items.size()];
		System.out.println("ids---"+ids.length);
		int i = 0;
		for (PpmParameterValuesSetup entity : items) {
			ids[i] = entity.getPk();
			i++;
		}
		
		return ids;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.lang.Object)
	 */
	public String[] getIDsArray(PpmParameterValuesSetup item) {
		// return null if item is null 
		if (item == null) {
			return null;
		}
		//Build the idsArray
		
		String[] ids = { item.getValue1() };
		return ids;
	}


	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getEntityName()
	 */
	public String getEntityName() {
		return "Category";
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getStatusFieldName()
	 */
	public String getStatusFieldName() {
		return "paramTypeCode";

	}	
	
	public String getIdFieldName() {
		return "getValue1()";
	}
	
	
	
	
	
	
	
	
	

	

	
	
	
	
	
	
	
	
	
	
	
	
}
