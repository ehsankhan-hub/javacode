package com.bsf.ppm.maintenance;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;
import org.richfaces.component.html.HtmlDataTable;
import com.bsf.ipp.IPPUTIL;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.PpmExeRules;
import com.bsf.ppm.PpmExeRulesCriteria;
import com.bsf.ppm.PpmParameterValue;
import com.bsf.ppm.PpmExeRulesCriteria.PpmExeRulesCriteriaPK;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.InstructionDAO;
import com.bsf.ppm.dao.ParameterValueDAO;
import com.bsf.ppm.dao.PpmExecuteRuleDAO;
import com.bsf.ppm.dao.PpmExecutionRuleCritDAO;
import com.bsf.ppm.dao.jpa.ParameterValueJpaDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.spring.SpringAppContext;
import com.sun.faces.util.MessageFactory;

/**
 * CRUD Controller Class for the PpmGroup CRUD Operations.
 */
public class ExecutionRulesController extends
		AbstractCrudController<PpmExeRules, String> {

	/** Attribute PpmExecuteRuleDAO DAO object for PpmExecuteRuleDAO */
	private PpmExecuteRuleDAO ppmExeRulesDAO;
	
	/** Attribute PpmExecutionRuleCritDAO DAO object for PpmExecutionRuleCritDAO */
	private PpmExecutionRuleCritDAO ppmExeRulesCritDAO;
	
	/** Attribute item PpmExeRules Entity */
	private PpmExeRules item;
	
	private PpmExeRulesCriteria itemCriteria;

	/** Attribute items for PpmExeRules Entity List */
	private List<PpmExeRules> items;
	
	private ParameterValueDAO parameterValueDAO;
	
	private InstructionDAO instructionDAO;
	
	private String selectedApplication;
	
	private String deleteBen;
	
	private String validateForm;
	
	private List<PpmExeRulesCriteria> benList=new ArrayList<PpmExeRulesCriteria>();   
	
	private String fieldName;
	
	private String value1;
	
	private String exeRuleName;
	
	private String value2;
	
	private String optrSign;
	
	private String fName="";
    
	private int sequence=0;
	
	private String btnType="";
	
	private String deleteRuleFromList;
	
	private ArrayList<SelectItem> list =null;
	
	private ArrayList<SelectItem>listSource=null;
	
	private ArrayList<SelectItem>listGenNar=null; 
	
	private List<PpmExeRulesCriteria> ruleDtlList=new ArrayList<PpmExeRulesCriteria>();
	
	private List<ParameterValue> editValuList = null;

	public String getFieldName() {
		return fieldName;
		
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	
	public String getValue1() {
		return value1;
	}

	public void setValue1(String value1) {
		this.value1 = value1;
	}
    
	
	
	public String getExeRuleName() {
		return exeRuleName;
	}

	public void setExeRuleName(String exeRuleName) {
		this.exeRuleName = exeRuleName;
	}

	public String getValue2() {
		return value2;
	}

	public void setValue2(String value2) {
		this.value2 = value2;
	}

	public String getOptrSign() {
		return optrSign;
	}

	public void setOptrSign(String optrSign) {
		this.optrSign = optrSign;
	}

	public String getValidateForm() {
		return validateForm;
	}

	public void setValidateForm(String validateForm) {
		this.validateForm = validateForm;
	}

	public String getDeleteBen() {
		return deleteBen;
	}

	public void setDeleteBen(String deleteBen) {
		this.deleteBen = deleteBen;
	}

	/** itemSize (number of items in the list)*/
	private int itemsSize;
	/*
	 * return int (itemSize)
	 */
	public int getItemsSize() {
		return getItems().size();
	}

	/**
	 * @return itemSize
	 */
	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}
    public ArrayList<SelectItem> getList() {
		return list;
	}

	public void setList(ArrayList<SelectItem> list) {
		this.list = list;
	}
    
	public ArrayList<SelectItem> getListSource() {
		return listSource;
	}

	public void setListSource(ArrayList<SelectItem> listSource) {
		this.listSource = listSource;
	}
	
	public ArrayList<SelectItem> getListGenNar() {
		return listGenNar;
	}

	public void setListGenNar(ArrayList<SelectItem> listGenNar) {
		this.listGenNar = listGenNar;
	}

	/**
	 * Constructor for BatchJobController
	 */
	public ExecutionRulesController() {
		//Initialize item object 
		item = new PpmExeRules();
		// Initialize default Search criteria
		this.getSearchCriteria().put(getStatusFieldName(), "A");
		
		// Initialize default sort field
		sortField = "exeRuleName";
		sortAscending=true;
	}
	
	public List<ParameterValue> getEditValuList() {
		return editValuList;
	}

	public void setEditValuList(List<ParameterValue> editValuList) {
		this.editValuList = editValuList;
	}

	/**
	 * @return the selectedApplication
	 */
	public String getSelectedApplication() {
		return selectedApplication;
	}

	/**
	 * @param selectedApplication the selectedApplication to set
	 */
	public void setSelectedApplication(String selectedApplication) {
		this.selectedApplication = selectedApplication;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItems()
	 */
	public List<PpmExeRules> getItems() {
		if (items == null) {
			reloadItems();
		}
		return items;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getDAO()
	 */
	public PaginatedDAO<PpmExeRules, String> getDAO() {
		return ppmExeRulesDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItem(java.lang.Object
	 * )
	 */
	public void setItem(PpmExeRules item) {
		this.item = item;

	}
    
	
	
	public PpmExeRulesCriteria getItemCriteria() {
		return itemCriteria;
	}

	public void setItemCriteria(PpmExeRulesCriteria itemCriteria) {
		this.itemCriteria = itemCriteria;
	}
    
	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
    
	
	public String getBtnType() {
		return btnType;
	}

	public void setBtnType(String btnType) {
		this.btnType = btnType;
	}
   
	
	public String getDeleteRuleFromList() {
		return deleteRuleFromList;
	}

	public void setDeleteRuleFromList(String deleteRuleFromList) {
		this.deleteRuleFromList = deleteRuleFromList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItems(java.util.
	 * List)
	 */
	public void setItems(List<PpmExeRules> items) {
		this.items = items;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItem()
	 */
	public PpmExeRules getItem() {
		return item;
	}
	
	public ParameterValueDAO getParameterValueDAO() {
		return parameterValueDAO;
	}

	public void setParameterValueDAO(ParameterValueDAO parameterValueDAO) {
		this.parameterValueDAO = parameterValueDAO;
	}
	
	public PpmExecuteRuleDAO getPpmExeRulesDAO() {
		return ppmExeRulesDAO;
	}

	public void setPpmExeRulesDAO(PpmExecuteRuleDAO ppmExeRulesDAO) {
		this.ppmExeRulesDAO = ppmExeRulesDAO;
	}
    
	public PpmExecutionRuleCritDAO getPpmExeRulesCritDAO() {
		return ppmExeRulesCritDAO;
	}

	public void setPpmExeRulesCritDAO(PpmExecutionRuleCritDAO ppmExeRulesCritDAO) {
		this.ppmExeRulesCritDAO = ppmExeRulesCritDAO;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getSelectedItems()
	 */
	public List<PpmExeRules> getSelectedItems() {
		List<PpmExeRules> selectedList = new ArrayList<PpmExeRules>();
		//Get the List of selected items from the dataTable
		for (PpmExeRules item : getItems()) {
			
			// Add item to the selectedList if the item is selected
			if (item.isSelected()){
				System.out.println("Selected Item exeRuleName="+item.getExeRuleName());
				selectedList.add(item);
		}
		}
		return selectedList;

	}
	
	/**
	 * 
	 * @return HtmlDataTable representing ppmGroupTable
	 */
	public HtmlDataTable getPpmGroupTable() {
		return (HtmlDataTable) JSFUtil.findComponentInRoot("ppmExeRuleTable");
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String listSetupString() {
          
		// Initialize default values for SearchCriteria and PageInfo
		if (getSearchCriteria() != null) {
			setSearchCriteria(new HashMap<String, Object>());
			getSearchCriteria().put(getStatusFieldName(),"A");
		}
		// Set 0 as the first page
		if (getPageInfo() != null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		reloadItems();
		// returns the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
    
	
	PpmExeRulesCriteria itrPpmRuCrt=new PpmExeRulesCriteria() ;
	
	@Override
	public String editSetup() {
		ruleDtlList.size();
		System.out.println("benList Edit value===="+benList);
		benList=new ArrayList<PpmExeRulesCriteria>();
		System.out.println("ruleDtlList.size() from Edit me="+ruleDtlList.size());
		int i;
		Iterator<PpmExeRulesCriteria> itr=ruleDtlList.iterator();
		
		while(itr.hasNext()){
			itrPpmRuCrt=(PpmExeRulesCriteria)itr.next();
			fName=itrPpmRuCrt.getPpmExeRulesCriteriaPK().getFieldName();
			System.out.println("fName=="+fName);
			getEditDataValueList(fName);
			getEditSourceSytValueList(fName);
			getEditGenNarrativeValueList(fName);
		}
		
		return getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
	}
	
	String fValue="";
	public List<SelectItem> getRuleEditValue() {
		listSource = new ArrayList<SelectItem>();
         Iterator<PpmExeRulesCriteria> itr=ruleDtlList.iterator();
         PpmExeRulesCriteria itrPpmRuCrt=null;
		while(itr.hasNext()){
			itrPpmRuCrt=(PpmExeRulesCriteria)itr.next();
			fName=itrPpmRuCrt.getPpmExeRulesCriteriaPK().getFieldName();
			fValue=itrPpmRuCrt.getPpmExeRulesCriteriaPK().getValue1();
			System.out.println("fName=="+fName);
			listSource.add(new SelectItem(itrPpmRuCrt.getPpmExeRulesCriteriaPK().getValue1(),itrPpmRuCrt.getPpmExeRulesCriteriaPK().getValue1()));		
		}
		
		return listSource;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String detailSetup() {
		System.out.println("detailSetup");
		//Get the Item to be passed to Detail page
		item = (PpmExeRules) this.getPpmGroupTable().getRowData();
		System.out.println("detailSetup item "+item);
		//Forward to detail Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#createSetup()
	 */
	public String createSetup() {
		// create a new instance of item
		//exeRuleName="";
		benList=new ArrayList<PpmExeRulesCriteria>();
		item = new PpmExeRules();
		itemCriteria=new PpmExeRulesCriteria();
		//Forward to create Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_CREATE_NAVIGATION;
	}

	/**
	 * @param context FacesContext reference 
	 * @param component component that fired the event
	 * @param value Value of the UI Component
	 */
	
	public void validateForm(FacesContext context, UIComponent component,
			Object value) {
		
		FacesMessage message = null;
		String componentId = component.getId();
		int valueLength;
		
		// Do not process if the value is null
		if (value == null) {
			return;
		}
		else {
			valueLength=value.toString().length();
		}
		
		//Validate for miscellaneous characters 
		if ((componentId.equalsIgnoreCase("groupCode") || componentId.equalsIgnoreCase("groupDesc")
				|| componentId.equalsIgnoreCase("groupName"))
				&& (value instanceof String)) {
			value=vaildateChars((String) value,context,componentId);
		}
		
		//Validation for groupCode component
		if (componentId.equalsIgnoreCase("groupCode")) {
			//Check length
			if (valueLength >5 ) {
				
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupCode.chars",FacesMessage.SEVERITY_ERROR, componentId,5);
				throw new ValidatorException(message);
			}
		}//Validation for groupDesc component 
		else if (componentId.equalsIgnoreCase("groupDesc")) {
			//Check length
			if (valueLength >50 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupDesc.chars",FacesMessage.SEVERITY_ERROR, componentId, 50);
				throw new ValidatorException(message);
			}
		}//Validation for groupName component
		else if (componentId.equalsIgnoreCase("groupName")) {
			//Check length
			if (valueLength >30 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.jobDescription.chars",FacesMessage.SEVERITY_ERROR, componentId, 30);
				throw new ValidatorException(message);
			}
		}
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#isUnique()
	 */
	public boolean isUnique() {
		boolean isUnique = false;
		try {
			//Check if the item is Unique in the Table
			isUnique =getPpmExeRulesDAO().isUnique(getItem());
			if(!isUnique){
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Rule Name already exists"));	
			}
		} catch (DAOException e) {
			
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUnique;
	}
	/*Check if the item is unique in PPM_EXE_RULES_CRITERIA table*/
    public boolean isUniqueJoinTable(List<PpmExeRulesCriteria> benList){
    	boolean isUniqueJoinTable = false;
		try {
			//Check if the item is Unique in the Table
			System.out.println("getItemCriteria()=="+getItemCriteria());
			System.out.println("ExeRuleCrit=="+itrPpmRuCrt);
			isUniqueJoinTable =getPpmExeRulesDAO().isUniqueJoinTable(benList);
			if(!isUniqueJoinTable){
			//FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Rule Name already exists"));	
			}
		} catch (DAOException e) {
			
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUniqueJoinTable;	
    }
	
    public boolean isUniqueFromListObject(List<PpmExeRulesCriteria> benList){
		boolean isUniqueFromListObject = false;
		try {
			//Check if the item is Unique in the Table
			isUniqueFromListObject =getPpmExeRulesDAO().isUniqueFromListObject(benList);
			System.out.println("isUniqueFromListObject===="+isUniqueFromListObject);
			if(!isUniqueFromListObject){
				
			
			}
			
		} catch (DAOException e) {
			
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUniqueFromListObject;		
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#create()
	 */
	public String create(){
		String nav = "";
		
		FacesMessage facesMessage = null;
		
		try {
			//Set userInfo 
			item.setCreatedBy(JSFUtil.getLoggedInUserInfo());
			
			//Set create Date
			item.setCreateDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			//item.setExeRuleName(exeRuleName);			
			//set Status as Active
			item.setStatus("A");
			if(benList!=null){
			System.out.println("benList=="+benList.size());
			item.setPpmExeRulesCriteria(benList);
			
			//System.out.println("item.getExeRuleName()"+item.getExeRuleName());
			}
			
			  //Set navigation case from super.create
			if(isUnique()){ 
			nav = super.create();
			
			}
			// if(isUnique()){
			 //getPpmExeRulesDAO().saveOrUpdate(item);
			 //getPpmExeRulesDAO().update(item);
			// }
			 //else{
			// return getClass().getSimpleName() + IConstants.CRUD_CREATE_NAVIGATION;	 	 
			// }
		
		} catch (Exception e) {

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.add.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);
			//Print StackTrace
			e.printStackTrace();
			// Return Navigation case of the create page
			return "";
		}
		benList=null;
		//return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
		
		return nav;
		}
	
	
	/**
	 * Update the entity in the database. Serves user update action on Edit page.
	 * @return List page Navigation case defined in faces-config.xml
	 */
	@Override
	public String update() {
		String navigationCase="";
		FacesMessage facesMessage = null;
		// set update information
		getItem().setUpdatedBy(JSFUtil.getLoggedInUserInfo());
		getItem().setUpdateDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				
		//call super.update
		
		
		try{
			//List <PpmExeRulesCriteria> benList=new ArrayList<PpmExeRulesCriteria>();   
			System.out.println("getItemCriteria().getExeRuleName()="+getItem().getExeRuleName());
			//List<PpmExeRulesCriteria> updPpmRCri=getPpmExeRulesDAO().getRuleDtlCrtList(getItem().getExeRuleName());
			PpmExeRules ppmExeRuName=getPpmExeRulesDAO().getPpmExeRulesList(getItem().getExeRuleName());
	        ppmExeRuName.setExeType(getItem().getExeType());
	        ppmExeRuName.setGroupCode(getItem().getGroupCode());
	        ppmExeRuName.setExeRuleDesc(getItem().getExeRuleDesc());
	        ppmExeRuName.setComments(getItem().getComments());
	        ppmExeRuName.setStatus(getItem().getStatus());
	       	      
	        ppmExeRuName.setPpmExeRulesCriteria(benList);
	       // for(int i=0;i<benList.size();i++){
	        	
	        if(isUniqueJoinTable(benList)&&isUniqueFromListObject(benList)){
	        //navigationCase=super.update();
	        getPpmExeRulesDAO().update(ppmExeRuName);
	        }
	        else{
		    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Rule name already exists"));		
		   
		    return "";
		    }
	       // }
		    }
		     catch (Exception e){
		    	 
		    //return navigationCase;
                         
			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(),"bundles.UIMessages",
					"entity.update.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);
			e.printStackTrace();
            return "";
			// Return Navigation case of the create page
		}
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Rule name updated successfully"));	
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
		
	}
	
	
	/*public String deletePpmExeRulesCriteria() {
		FacesMessage facesMessage = null;
		if (getSelectedItemsofPpmExeRulesCriteria() == null || getSelectedItemsofPpmExeRulesCriteria().size() < 1) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		// Fetch the items to be deleted.
		lstIds = getIDsArrayofPpmExeRulesCriteria(getSelectedItemsofPpmExeRulesCriteria());
		System.out.println("Object=="+lstIds.toString());
		Collections.sort(benList);
		Iterator it=lstIds.iterator();
		//while(it.hasNext()){
		//for(PpmExeRulesCriteriaPK ppmExeRulCrtPk:lstIds){
		for(Iterator<PpmExeRulesCriteriaPK> ppmExeRulCrtPk = lstIds.iterator(); ppmExeRulCrtPk.hasNext();) {
			//PpmExeRulesCriteriaPK	ppmExeRulesCriteriaPK=(PpmExeRulesCriteriaPK)it.next();
		System.out.println("getExeRuleName---"+ppmExeRulCrtPk.next());
		//System.out.println("getFieldName---"+ppmExeRulCrtPk.getFieldName());
		//System.out.println("getValue1---"+ppmExeRulCrtPk.getValue1());
		//PpmExeRulesCriteriaPK PpmExeRulesCriteriaPK1=new PpmExeRulesCriteriaPK(ppmExeRulCrtPk.getExeRuleName(),ppmExeRulCrtPk.getFieldName(),ppmExeRulCrtPk.getValue1());
		//for(PpmExeRulesCriteria  ppmExeCrt :benList){
		//if(ppmExeRulCrtPk.getExeRuleName().equals(ppmExeCrt.getPpmExeRulesCriteriaPK().getExeRuleName())){	
		ppmExeRulCrtPk.remove();
		//}
		}
		
		//for(int i=0;i<benList.size();i++){
	
		if (lstIds != null && lstIds.size() > 0) {
		
		//}
			System.out.println("idArrays==Length if condition="+lstIds.size());
			
		
			
		
			
			}
		
	getPageInfo().setCurrentPage(0);
	// Reload the items in the list
	reloadItems();
	facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
			"bundles.UIMessages", "entity.deleted.success",
			lstIds.size(), getEntityName());
	FacesContext.getCurrentInstance().addMessage("successDeleteItems",
			facesMessage);

	// return the Navigation case for list page
	return getClass().getSimpleName() + IConstants.CRUD_CREATE_NAVIGATION;
}*/
	List<PpmExeRulesCriteria> selectedList=new ArrayList<PpmExeRulesCriteria>();
	public List<PpmExeRulesCriteria> getSelectedItemsofPpmExeRulesCriteria() {
		 selectedList = new ArrayList<PpmExeRulesCriteria>();
		//Get the List of selected items from the dataTable
		
		for (PpmExeRulesCriteria item : benList) {
			
			// Add item to the selectedList if the item is selected
			if (item.isSelected()){
				System.out.println("Selected item.getParamType()="+item.isSelected());
				selectedList.add(item);
			}
		}
		return selectedList;

	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItem()
	 */
	public String disableItem() {
		FacesMessage facesMessage = null;
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getItem());
		
		for(int i=0;i<idArrays.length;i++){
			System.out.println("disableItem idArrays="+idArrays[i]);
		}

		if (idArrays != null && idArrays.length > 0) {
			try {
				
				getPpmExeRulesDAO().updateEntityStatusByIds(idArrays,getIdFieldName(),
						getStatusFieldName(),  "I", JSFUtil.getLoggedInUserInfo());

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil
				.getMessage(FacesContext.getCurrentInstance(),
						"bundles.UIMessages",
						"entity.deActivateItem.error",
						FacesMessage.SEVERITY_ERROR, getItem(),
						getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"entity.deleteItem", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.deActivateItem.success",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage("successDeleteItem",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItem()
	 */
	public String enableItem() {
		FacesMessage facesMessage = null;
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getItem());
		System.out.println("=====AbstractCrudController. enableItem ");
		for(int i=0;i<idArrays.length;i++){
			System.out.println("disableItem idArrays="+idArrays[i]);
		}

		if (idArrays != null && idArrays.length > 0) {
			try {
				// Delete the items from the Database Table
				// getStatusFieldName should be implemented in subclass
				getPpmExeRulesDAO().updateEntityStatusByIds(idArrays, getIdFieldName(),
						getStatusFieldName(), "A", JSFUtil.getLoggedInUserInfo());

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil
				.getMessage(FacesContext.getCurrentInstance(),
						"bundles.UIMessages",
						"entity.activateItem.error",
						FacesMessage.SEVERITY_ERROR, getItem(),
						getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"activateItem.error", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.activateItem.success",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage(
				"itemActivatedSuccessfully", facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
    
	public String deleteRule(){
		  FacesMessage facesMessage = null;
			try {
				 System.out.println("delete method start=="+getItem().getExeRuleName());
				getPpmExeRulesDAO().deletRule(getItem().getExeRuleName());
				System.out.println("delete method end");
			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil
				.getMessage(FacesContext.getCurrentInstance(),
						"bundles.UIMessages",
						"entity.deActivateItem.error",
						FacesMessage.SEVERITY_ERROR, getItem(),
						getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"entity.deleteItem", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.deleteItem.success",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage("successDeleteItem",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	
	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItems()
	 */
	public String disableItems() {
		FacesMessage facesMessage = null;
		if (getSelectedItems() == null || getSelectedItems().size() < 1){
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getSelectedItems());
		System.out.println("=====AbstractCrudController. disableItems ");
		for(int i=0;i<idArrays.length;i++){
			System.out.println("disableItem idArrays="+idArrays[i]);
		}

		if (idArrays != null && idArrays.length > 0) {
			try {
				// Delete the items from the Database Table
				// getStatusFieldName should be implemented in subclass
				getPpmExeRulesDAO().updateEntityStatusByIds(idArrays,getIdFieldName(),
						getStatusFieldName(), "I", JSFUtil.getLoggedInUserInfo());
			} catch (DAOException e) {
				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"entity.deActivateItems.error",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"deActivateItemsError", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		getPageInfo().setCurrentPage(0);
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.deActivateItems.success",
				idArrays.length, getEntityName());
		FacesContext.getCurrentInstance().addMessage("successDeleteItems",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItems()
	 */
	public String enableItems() {
		FacesMessage facesMessage = null;
		System.out.println("getSelectedItems().size()=="+getSelectedItems().size());
		if (getSelectedItems() == null || getSelectedItems().size() < 1) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		// Fetch the items to be deleted.
	 
		String[] idArrays = getIDsArray(getSelectedItems());
		System.out.println("idArrays=="+getIDsArray(getSelectedItems()));
		System.out.println("idArrays==="+idArrays.length);
		for(int i=0;i<idArrays.length;i++){
			System.out.println("disableItem idArrays="+idArrays[i]);
		}

		System.out.println("=====AbstractCrudController. enableItems ");
		if (idArrays != null && idArrays.length > 0) {
			try {
				// Delete the items from the Database Table
				// getStatusFieldName should be implemented in subclass
				getPpmExeRulesDAO().updateEntityStatusByIds(idArrays, getIdFieldName(),
						getStatusFieldName(), "A", JSFUtil.getLoggedInUserInfo());

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"entity.activateItems.error",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance().addMessage("activatItems",
						facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		getPageInfo().setCurrentPage(0);
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.activateItems.success",
				idArrays.length, getEntityName());
		FacesContext.getCurrentInstance().addMessage("successActivateItems",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
	
	public String[] getIDsArrayofPpmExeRulesCriteria(List<PpmExeRulesCriteria> items) {
		// return null if List is null or empty
		if (items == null || items.size() == 0) {
			return null;
		}
		// Build the array of the ids
		String[] ids = new String[items.size()];
		System.out.println("ids---"+ids.length);
		int i = 0;
		for (PpmExeRulesCriteria entity : items) {
			ids[i] = entity.getPk();
			//lstIds=entity.getListPk();
			i++;
		}
	return ids;
	}
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.util.List)
	 */
	public String[] getIDsArray(List<PpmExeRules> items) {
		// return null if List is null or empty
		if (items == null || items.size() == 0) {
			return null;
		}
		// Build the array of the ids
		String[] ids = new String[items.size()];
		System.out.println("ids---"+ids.length);
		int i = 0;
		for (PpmExeRules entity : items) {
			ids[i] = entity.getPk();
			i++;
		}
		
		return ids;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.lang.Object)
	 */
	public String[] getIDsArray(PpmExeRules item) {
		// return null if item is null 
		if (item == null) {
			return null;
		}
		//Build the idsArray
		System.out.println("item.getGroupCode() "+item.getExeRuleName());
		String[] ids = {(item.getExeRuleName()) };
		return ids;
	}


	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getEntityName()
	 */
	public String getEntityName() {
		return "Execution Rules";
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getStatusFieldName()
	 */
	public String getStatusFieldName() {
		return "status";

	}	
	
	public String getIdFieldName() {
		return "exeRuleName";
	}
	/**
	 * Fetch Group Priority to be displayed in search criteria
	 * @return List of Group Priority Items for the Select Options
	 */
	public List<SelectItem> getExecutionRuleList() {

		List<ParameterValue> executionRuleList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			executionRuleList = getParameterValueDAO().getExecutionTypeList();
			System.out.println("executionRuleList=="+executionRuleList);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: executionRuleList) {
			
			System.out.println("parameterValue=="+parameterValue.getValue1());
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	}
	
	/**
	 * Fetch Group Status to be displayed in search criteria
	 * @return List of Group Status Items for the Select Options
	 */
	public List<SelectItem> getGroupStatusList() {

		List<ParameterValue> groupStatusList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			groupStatusList = getParameterValueDAO().getStatus();
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: groupStatusList) {
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	}
	
	
	/**
	 * Fetch Group Code to be displayed in search criteria
	 * @return List of Group Status Items for the Select Options
	 */
	public List<SelectItem> getGroupCodeList() {

		List<ParameterValue> groupCodeList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			groupCodeList = getParameterValueDAO().getGroupCode();
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: groupCodeList) {
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	}
	
	
	/**
	 * Fetch Group Status to be displayed in search criteria
	 * @return List of Group Status Items for the Select Options
	 */
	public List<SelectItem> getGroupPercentList() {

		List<ParameterValue> groupPercentList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			groupPercentList = getParameterValueDAO().getPercent();
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		list.add(new SelectItem("0","-Select-"));	
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: groupPercentList) {
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	}
	
	
	/**
	 * Fetch Group Priority to be displayed in search criteria
	 * @return List of Group Priority Items for the Select Options
	 */
	public List<SelectItem> getFieldNameList() {

		List<ParameterValue> fieldNameList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of ParameterValue objects
			fieldNameList = getParameterValueDAO().getFieldNameList();
			System.out.println("fieldNameList=="+fieldNameList);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the ParameterValue List to the Select Item List
		for (ParameterValue parameterValue: fieldNameList) {
			
			System.out.println("parameterValue=="+parameterValue.getValue1());
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	}
	
	public List<SelectItem> getValueList() {

		List<ParameterValue> valueList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			valueList = getParameterValueDAO().getValueList(fieldName);
			System.out.println("valueList=="+valueList);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: valueList) {
			
			System.out.println("parameterValue=="+parameterValue.getValue1());
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	}
	
	public List<SelectItem> getEditDataValueList(String fName) {
		 Iterator<PpmExeRulesCriteria> itr=ruleDtlList.iterator();
         PpmExeRulesCriteria itrPpmRuCrt=null;
		 list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			editValuList = getParameterValueDAO().getValueList("TRANS_TYPE");
			System.out.println("getEditDataValueList size=="+editValuList.size());
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: editValuList) {
			
			System.out.println("parameterValue=="+parameterValue.getValue1());
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		//editValuList=null;
		return list;
	}
	
	
	public List<SelectItem> getEditSourceSytValueList(String fName) {
		 Iterator<PpmExeRulesCriteria> itr=ruleDtlList.iterator();
        PpmExeRulesCriteria itrPpmRuCrt=null;
        listSource = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			editValuList = getParameterValueDAO().getValueList("SOURCE_SYSTEM");
			System.out.println("getEditDataValueList size=="+editValuList.size());
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: editValuList) {
			
			System.out.println("parameterValue=="+parameterValue.getValue1());
			listSource.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		//editValuList=null;
		return listSource;
	}
	
	public List<SelectItem> getEditGenNarrativeValueList(String fName) {
		 Iterator<PpmExeRulesCriteria> itr=ruleDtlList.iterator();
       PpmExeRulesCriteria itrPpmRuCrt=null;
       listGenNar = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			editValuList = getParameterValueDAO().getValueList("GEN_NARRATIVE");
			System.out.println("getEditDataValueList size=="+editValuList.size());
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: editValuList) {
			
			System.out.println("parameterValue=="+parameterValue.getValue1());
			listGenNar.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		//editValuList=null;
		return listGenNar;
	}
	
	
	
	private List<PpmExeRulesCriteria> ppm=new ArrayList<PpmExeRulesCriteria>();
	private PpmExeRules ppmExe=null;
	private PpmExeRulesCriteria ppmExeCrit=null;
	private List<PpmExeRulesCriteria> ppmList=new ArrayList<PpmExeRulesCriteria>();
	public List<PpmExeRulesCriteria> addRules(){
	if((!"--Select--".equals(fieldName))&&(value1!=null&&!"".equals(value1))){
	ppmExe=new PpmExeRules();	
	ppmExeCrit=new PpmExeRulesCriteria();
	System.out.println("setExeRuleName="+exeRuleName);
	ppmExeCrit.getPpmExeRulesCriteriaPK().setExeRuleName(item.getExeRuleName());	
	//ppmExeCrit.setRuleId(item.getRuleId());
	System.out.println("btnType==="+btnType);
	System.out.println("item.getExeRuleName()="+item.getExeRuleName());
	
	if("update".equals(btnType)){
	ppmExeCrit.setSeqNum(sequence++);
	}
	else{
	ppmExeCrit.setSeqNum(sequence++);
	}
		
	ppmExeCrit.getPpmExeRulesCriteriaPK().setFieldName(fieldName);
	ppmExeCrit.getPpmExeRulesCriteriaPK().setValue1(value1);
	//Set userInfo for CurrencyCode
	ppmExeCrit.setCreatedBy(JSFUtil.getLoggedInUserInfo());
	//Set create Date
	ppmExeCrit.setCreateDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
	
	ppmList.add(ppmExeCrit);
	ppmExe.setPpmExeRulesCriteria(ppmList);
	System.out.println("PpmExeRules ppmExeCrit=="+ppmExeCrit.getSeqNum());
	ppm=addBenToBenList(ppmExeCrit);
	
	ppmExe.setPpmExeRulesCriteria(ppm);
	
	System.out.println("fieldName Add Rules:"+fieldName);	
	}
	else{
	FacesMessage facesMessage = null;
	facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(), "bundles.UIMessages",
	"fieldNameNotSelected", FacesMessage.SEVERITY_ERROR);
	FacesContext.getCurrentInstance().addMessage("value1", facesMessage);
		//return "";			
	}
	value1="";
	return ppm;
	
	}
	
	   
	private int rulesSize=0;
		
	public int getRulesSize() {
		return rulesSize;
	}

	public void setRulesSize(int rulesSize) {
		this.rulesSize = rulesSize;
	}

	private List<PpmExeRulesCriteria> addBenToBenList(PpmExeRulesCriteria benInfoDO) {
		 if(benList!=null)
		    {
		    Collections.sort(benList);
		    benList.add(benInfoDO); 
		    rulesSize=benList.size();
		    System.out.println("rulesSize==="+rulesSize);
		    }
		 
		/*Iterator itr=benList.iterator();
		while(itr.hasNext()){
		PpmExeRulesCriteria count=(PpmExeRulesCriteria)itr.next();
		System.out.println("While Count=="+count.getSeqNum());
		}
		System.out.println("benInfoDO=getRulesCount="+benList.size());*/
		return ( List<PpmExeRulesCriteria> ) benList;
	}
	
	public void deleteSelectedRule() {
		ruleDtlList=null;
        ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			System.out.println("sequence number form delete method"+sequence);
			ruleDtlList = getPpmExeRulesDAO().getRuleDtlCrtList(item.getExeRuleName());
			System.out.println("RuleList=="+ruleDtlList.size());
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		int seqNumber=0;
		for (PpmExeRulesCriteria ppmExeRuleCrt: ruleDtlList) {
			seqNumber=ppmExeRuleCrt.getSeqNum();
			
		}
			
		
		System.out.println("benList.iterator()="+ruleDtlList.size());
		Iterator itr=ruleDtlList.iterator();
		PpmExeRulesCriteria count=null;
		while(itr.hasNext()){
		count=(PpmExeRulesCriteria)itr.next();
		System.out.println("While Count=="+count.getSeqNum());
		}
		System.out.println("count.getValue1()   ="+count.getPpmExeRulesCriteriaPK().getValue1());
		try{
		getPpmExeRulesDAO().deleteDtlCrtList(getExeRuleName(),getFieldName(),getValue1());
		}
		catch(DAOException daoe){
			daoe.printStackTrace();
		}
		//ruleDtlList.remove(--sequence);
		System.out.println("benInfoDO=getRulesCount="+ruleDtlList.size());
		
	}
	
	
		/*// Add Rules
		public String getAddRulesList() {
		
			//benList.add(new Item("Default"));
		    Iterator<PpmExeRules> iterator = benList.iterator();
		    while(iterator.hasNext())
		    {
		        PpmExeRules item = (PpmExeRules)iterator.next();
		        System.out.println(item.getValue());
		    }
		    return "";
		    
		    }*/
		/**
		 * @return the list
		 */
		public List<PpmExeRulesCriteria> getBenList() {
		    if(benList!=null)
		    {
		   // Collections.sort(benList);
		        //loadList();
		    }
		    return benList;
		}
		
		/*Delete rule from database*/
		public void deleteSelectedRules() {
			System.out.println("benList.iterator()="+ruleDtlList.size());
			Iterator<PpmExeRulesCriteria> ppmExeRulesCriteriaItr=ruleDtlList.iterator();
			String exeRuleName="";
			String fieldName="" ;
			String value1="";
			while(ppmExeRulesCriteriaItr.hasNext()){
				System.out.println("benList.iterator()=="+benList.size());
				PpmExeRulesCriteria ppmExeRulesCriteria=ppmExeRulesCriteriaItr.next();
				
				exeRuleName=ppmExeRulesCriteria.getPpmExeRulesCriteriaPK().getExeRuleName();
				fieldName=ppmExeRulesCriteria.getPpmExeRulesCriteriaPK().getFieldName();
				value1=ppmExeRulesCriteria.getPpmExeRulesCriteriaPK().getValue1();
				System.out.println("exeRuleName===----"+exeRuleName);
				System.out.println("fieldName===----"+fieldName);
				System.out.println("value1===----"+value1);
			try{
				//ruleDtlList
				System.out.println("Tying to delete ParamValue");
				getPpmExeRulesDAO().deleteDtlCrtList(getExeRuleName(),getFieldName(),getValue1());
				System.out.println("Successfully deleted ParamValue");
			}
			catch(DAOException daoe){
				daoe.printStackTrace();
			}
			//ruleDtlList.remove(--sequence);
			System.out.println("benInfoDO=getRulesCount="+ruleDtlList.size());
			
		}
		}
		
		/*Delete rule from List*/
		public String deleteRuleFromList(){
			FacesMessage facesMessage = null;
			/*if (getSelectedItemsofPpmExeRulesCriteria() == null || getSelectedItemsofPpmExeRulesCriteria().size() < 1) {
				facesMessage = JSFUtil.getMessage(
						FacesContext.getCurrentInstance(), "bundles.UIMessages",
						"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
						getEntityName());
				FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
				return "";
			}*/
			// Fetch the items to be deleted.
			//String[] idArrays = getIDsArrayofPpmExeRulesCriteria(getSelectedItemsofPpmExeRulesCriteria());
			//if (idArrays != null && idArrays.length > 0) {
			Iterator<PpmExeRulesCriteria> ppmExeRulesCriteriaItr=benList.iterator();
			String exeRuleName="";
			String fieldName="" ;
			String value1="";
			
			while(ppmExeRulesCriteriaItr.hasNext()){
				System.out.println("benList.iterator()=="+benList.size());
				PpmExeRulesCriteria ppmExeRulesCriteria=ppmExeRulesCriteriaItr.next();
				
				exeRuleName=ppmExeRulesCriteria.getPpmExeRulesCriteriaPK().getExeRuleName();
				fieldName=ppmExeRulesCriteria.getPpmExeRulesCriteriaPK().getFieldName();
				value1=ppmExeRulesCriteria.getPpmExeRulesCriteriaPK().getValue1();
				System.out.println("exeRuleName===----"+exeRuleName);
				System.out.println("fieldName===----"+fieldName);
				System.out.println("value1===----"+value1);
				PpmExeRulesCriteria ppmExeRulesCriteria1=new PpmExeRulesCriteria();
				PpmExeRulesCriteriaPK ppmExeRulesCriteriaPK=ppmExeRulesCriteria1.getPpmExeRulesCriteriaPK();
				PpmExeRulesCriteriaPK ppmExeRulesCriteriaPK1=new PpmExeRulesCriteriaPK(exeRuleName,fieldName,value1);
				ppmExeRulesCriteriaPK.setExeRuleName(item.getExeRuleName());
				ppmExeRulesCriteriaPK.setFieldName(getFieldName());
				ppmExeRulesCriteriaPK.setValue1(getValue1());
				System.out.println("getExeRuleName==="+item.getExeRuleName());
				System.out.println("getFieldName==="+getFieldName());
				System.out.println("getValue1==="+getValue1());
				
				System.out.println("ppmParameterValuePK==="+ppmExeRulesCriteriaPK.toString());
				System.out.println("ppmExeRulesCriteriaPK1==="+ppmExeRulesCriteriaPK1.toString());
				//if(selectedList.get(i).isSelected()){
				if(ppmExeRulesCriteriaPK.equals(ppmExeRulesCriteriaPK1)){
					System.out.println("Parma value is equeal");
					ppmExeRulesCriteriaItr.remove();
				}
				//}
				//benList.remove(ppmParmVale);
				
				
				else{
					System.out.println("Parma value not equal");
				}
				Set<PpmExeRulesCriteria> ppmExeCrit=new HashSet<PpmExeRulesCriteria>(benList);
			    System.out.println("ppmParameterValue===="+ppmExeCrit.size());
			
			}
			//}
			/*getPageInfo().setCurrentPage(0);
			// Reload the items in the list
			reloadItems();
			facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
					"bundles.UIMessages", "entity.deleted.success",
					idArrays.length, getEntityName());
			FacesContext.getCurrentInstance().addMessage("successDeleteItems",
					facesMessage);
*/
			// return the Navigation case for list page
			return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
		}
		
		
		public List<PpmExeRulesCriteria>getRuleDtlList(){
		ruleDtlList=null;
         ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			ruleDtlList = getPpmExeRulesDAO().getRuleDtlCrtList(item.getExeRuleName());
			System.out.println("RuleList=="+ruleDtlList);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (PpmExeRulesCriteria ppmExeRuleCrt: ruleDtlList) {
			
			System.out.println("parameterValue=="+ppmExeRuleCrt.getPpmExeRulesCriteriaPK().getValue1());
			list.add(new SelectItem(ppmExeRuleCrt.getPpmExeRulesCriteriaPK().getFieldName(),ppmExeRuleCrt.getPpmExeRulesCriteriaPK().getValue1()));		
		}
		
		return ruleDtlList;
		}
	    
		
	
}
