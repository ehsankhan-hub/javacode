package com.bsf.ppm.maintenance;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;

import org.richfaces.component.html.HtmlDataTable;

import com.bsf.ipp.IPPUTIL;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.BackendSystem;
import com.bsf.ppm.SystemConfiguration;
import com.bsf.ppm.SystemType;
import com.bsf.ppm.SystemTypeParameter;
import com.bsf.ppm.cache.CacheManager;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.BackendSystemDAO;
import com.bsf.ppm.dao.SystemTypeDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.sun.faces.util.MessageFactory;

/**
 * @author Zakir
 * CRUD Controller Class for the BackendSystem CRUD Operations.
 */
public class BackendSystemController extends
		AbstractCrudController<BackendSystem, Long> {
	private CacheManager staticDataCacheManager;

	/** Attribute backendSystemDAO*/
	private BackendSystemDAO backendSystemDAO;

	/** Attribute systemTypeDAO */
	private SystemTypeDAO systemTypeDAO;
	
	public CacheManager getStaticDataCacheManager() {
		return staticDataCacheManager;
	}

	public void setStaticDataCacheManager(CacheManager staticDataCacheManager) {
		this.staticDataCacheManager = staticDataCacheManager;
	}

	/** Attribute item of type BackendSystem */
	private BackendSystem item;
	
	/** Attribute items for the list of BackendSystem items */
	private List<BackendSystem> items;

	/**
	 * <p>Attribute selectedSystemType used in Create Backend system.
	 * Holds the System Type selected by the user and set to the Backend System.</p>
	 */
	private Long selectedSystemType;
	
	/** itemSize (number of items in the list)*/
	private int itemsSize;
	/*
	 * return int (itemSize)
	 */
	public int getItemsSize() {
		return getItems().size();
	}

	/**
	 * @return itemSize
	 */
	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}

	/**
	 * Constructor for BackendSystemController
	 */
	public BackendSystemController() {
		//initialize item entity
		item = new BackendSystem();
		//Initialize the default search Criteria
		this.getSearchCriteria().put(getStatusFieldName(), Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
	}
	
	/**
	 * @return the backendSystemDAO
	 */
	public BackendSystemDAO getBackendSystemDAO() {
		return backendSystemDAO;
	}

	/**
	 * @param backendSystemDAO the backendSystemDAO to set
	 */
	public void setBackendSystemDAO(BackendSystemDAO backendSystemDAO) {
		this.backendSystemDAO = backendSystemDAO;
	}

	/**
	 * @return the systemTypeDAO
	 */
	public SystemTypeDAO getSystemTypeDAO() {
		return systemTypeDAO;
	}

	/**
	 * @param systemTypeDAO the systemTypeDAO to set
	 */
	public void setSystemTypeDAO(SystemTypeDAO systemTypeDAO) {
		this.systemTypeDAO = systemTypeDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getDAO()
	 */
	public PaginatedDAO<BackendSystem, Long> getDAO() {
		return backendSystemDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItem()
	 */
	public BackendSystem getItem() {
		return item;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItem(java.lang.Object
	 * )
	 */
	public void setItem(BackendSystem item) {
		this.item = item;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItems()
	 */
	public List<BackendSystem> getItems() {
		if (items == null) {
			reloadItems();
		}

		return items;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItems(java.util.
	 * List)
	 */
	public void setItems(List<BackendSystem> items) {
		this.items = items;

	}


	/**
	 * Get System type user has selected
	 * @return selectedSystemType 
	 */
	public Long getSelectedSystemType() {
		return selectedSystemType;
	}


	/**
	 * Set System type user selected
	 * @param selectedSystemType
	 */
	public void setSelectedSystemType(Long selectedSystemType) {
		this.selectedSystemType = selectedSystemType;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getSelectedItems()
	 */
	public List<BackendSystem> getSelectedItems() {
		List<BackendSystem> selectedList = new ArrayList<BackendSystem>();
		//Get the List of selected items from the dataTable
		for (BackendSystem item : getItems()) {
			// Add item to the selectedList
			if (item.isSelected()) {
				selectedList.add(item);
			}
		}
		return selectedList;
	}

	/**
	 * 
	 * @return HtmlDataTable representing backendSystem Table
	 */
	public HtmlDataTable getBackendSystemsTable() {
		return (HtmlDataTable) JSFUtil.findComponentInRoot("backendSystemTable");
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#prepareSearchCriteria()
	 */
	public Map<String, Object>  prepareSearchCriteria(){
		Map<String, Object> newSearchMap = super.prepareSearchCriteria();
		
		//Remove the messageType from Search Criteria if value=0 (ALL option selected)
		if(newSearchMap.get("systemType") !=null && newSearchMap.get("systemType").toString().equals("0")) {
			newSearchMap.remove("systemType");
			//IConstants.MESSAGE_TYPE.values()[]
		}
		return newSearchMap;
	}

	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String detailSetup() {
		//Get the Item to be passed to Detail page
		item = (BackendSystem) this.getBackendSystemsTable().getRowData();
		if(item.getSystemType().getId().equals(new Long(8)))	{
			
			return getClass().getSimpleName() + "_black_list_query";
		}
		//Forward to detail Navigation case
		return getClass().getSimpleName() + "_detail";
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#listSetup()
	 */
	public String listSetup() {

		// Initialize default values for SearchCriteria and PageInfo
		setSearchCriteria(new HashMap<String, Object>());
		if (getSearchCriteria() != null)
			getSearchCriteria().put(getStatusFieldName(),
					Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
		if (getPageInfo() != null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		reloadItems();

		// returns the Navigation case for list page
		return getClass().getSimpleName() +IConstants.CRUD_LIST_NAVIGATION;
	}
	

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#editSetup()
	 */
	public String editSetup() {
		//Get the Item to be passed to Edit page
		item = (BackendSystem) this.getBackendSystemsTable().getRowData();
		if(item.getSystemType().getId().equals(new Long(8)))	{
			
			return getClass().getSimpleName() + "_black_list_query";
		}
		//Forward to edit Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#createSetup()
	 */
	public String createSetup() {
		// create a new instance of item
		item = new BackendSystem();
		//Forward to create Navigation case
		return getClass().getSimpleName() + "_create";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#create()
	 */
	public String create() {
		FacesMessage facesMessage = null;
		String nav = "";
		SystemConfiguration sysConfig = null;
		ArrayList<SystemConfiguration> sysConfigList = new ArrayList<SystemConfiguration>();
		try {
			
			//Set SystemType for the the Backend System
			SystemType systemType = getSystemTypeDAO().getById(getSelectedSystemType());
			item.setSystemType(systemType);
			
			item.setCreatedBy(JSFUtil.getLoggedInUserInfo());			
			
			//Set create Date for Backend System
			item.setCreatedDate(new Timestamp(System.currentTimeMillis()));
			item.setStatus(Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
			
			//Set Configuration List for Backend
			List<SystemTypeParameter> parametersList = systemType.getSystemTypeParameterList();
			for (Iterator<SystemTypeParameter> iterator = parametersList.iterator(); iterator.hasNext();) {

				SystemTypeParameter systemTypeParameter = (SystemTypeParameter) iterator.next();
				sysConfig = new SystemConfiguration();
				sysConfig.setSystemTypeParameter(systemTypeParameter);
				sysConfig.setBackendSystem(item);
				sysConfigList.add(sysConfig);
			}
			item.setSystemConfigurations(sysConfigList);
			//Save the Backend System
			getBackendSystemDAO().save(item);
			staticDataCacheManager.refreshCache("backendSystemCache");
			
		} catch (Exception e) {

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.add.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem(),IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);
		
			// Return Navigation case of the create page
			return "";
		}
		nav=getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
		return nav;
	}

	/**
	 * @param context FacesContext reference 
	 * @param component component that fired the event
	 * @param value Value of the UI Component
	 */
	public void validateForm(FacesContext context, UIComponent component,
			Object value) {

		FacesMessage message = null;
		String componentId = component.getId();
	
		
		// Do not process if the value is null
		if (value == null) {
			return;
		}
		
		//Validate for miscellaneous characters 
		if (value instanceof String) {
			value=vaildateChars((String) value,context,componentId);
		}
		
		int valueLength = value.toString().length();
		//Validation for systemName component
		if (componentId.equalsIgnoreCase("systemName")) {
			//validate for length
			if (valueLength >12) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"backendSystemName.chars",FacesMessage.SEVERITY_ERROR, componentId, 12);
				throw new ValidatorException(message);
			}
		} //Validation for sytemDescription component 
		else if (componentId.equalsIgnoreCase("sytemDescription")) {
			//validate for length
			if (valueLength > 30) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"backendSystemDescription.chars",FacesMessage.SEVERITY_ERROR, componentId, 30);
				throw new ValidatorException(message);
			}
		} 

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#isUnique()
	 */
	public boolean isUnique() {
		boolean isUnique = false;
		try {
			//Check if the item is Unique in the Table
			isUnique = getDAO().isUnique(getItem());
		} catch (DAOException e) {
			
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.BusinessErrorMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUnique;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.util
	 * .List)
	 */
	public String[] getIDsArray(List<BackendSystem> items) {
		// return null if List is null or empty
		if (items == null || items.size() == 0) {
			return null;
		}
		// Build the array of the ids
		String[] ids = new String[items.size()];
		//add the ids of the items to the array
		int i = 0;
		for (BackendSystem entity : items) {
			ids[i] = entity.getPk();
			i++;
		}
		return ids;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.lang
	 * .Object)
	 */
	public String[] getIDsArray(BackendSystem item) {
		// return null if List is null 
		if (item == null) {
			return null;
		}
		//Build the idsArray
		String[] ids = { item.getId().toString() };
		return ids;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getEntityName()
	 */
	public String getEntityName() {
		return "Backend System";
	}
	
	/**
	 * List of SystemType Items used in Create/Edit Page
	 * @return List of SystemType Items for the Select Options 
	 */
	public List<SelectItem> getSystemTypeList() {

		List<SystemType> systemTypeList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of SystemType objects
			systemTypeList = getSystemTypeDAO().findAll();
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Add "ALL" option to the Select Item List
		list.add(new SelectItem("0",IConstants.SELECT_ALL_OPTION));
		
		//Add the System Type List to the Select Item List
		for (SystemType systemType: systemTypeList) {
			list.add(new SelectItem(systemType.getId(),systemType.getTypeName()));		
		}
		return list;
	}
	
	public String update() {
		getItem().setModifiedBy(JSFUtil.getLoggedInUserInfo());
		getItem().setModifiedDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
		String nev = super.update();
		try {
			staticDataCacheManager.refreshCache("backendSystemCache");
		} catch (Exception e) {
			e.printStackTrace();
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"cache.refresherror", FacesMessage.SEVERITY_ERROR,
					getItem(),IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			return "";

		}
		return nev;

	}
}
