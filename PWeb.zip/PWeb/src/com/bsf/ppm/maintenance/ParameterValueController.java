package com.bsf.ppm.maintenance;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;
import org.richfaces.component.html.HtmlDataTable;
import com.bsf.ipp.IPPUTIL;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.PpmParameterType;
import com.bsf.ppm.PpmParameterValue;
import com.bsf.ppm.PpmParameterValue.PpmParameterValuePK;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.ParameterValueDAO;
import com.bsf.ppm.dao.PpmParameterTypeDAO;
import com.bsf.ppm.dao.jpa.ParameterValueJpaDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.sun.faces.util.MessageFactory;

/**
 * CRUD Controller Class for the PpmGroup CRUD Operations.
 */
public class ParameterValueController extends AbstractCrudController<PpmParameterType, String> {

	/** Attribute PpmExecuteRuleDAO DAO object for PpmExecuteRuleDAO */
	private PpmParameterTypeDAO ppmParmTypeDAO;
	
	/** Attribute item PpmExeRules Entity */
	private PpmParameterType item;
	
	private PpmParameterValue ppmParameterValue;

	/** Attribute items for PpmParameterType Entity List */
	private List<PpmParameterType> items;
	
	private ParameterValueDAO parameterValueDAO;
		
	private String selectedApplication;
	
	private String deleteBen;
	
	private String validateForm;
	
	private List<PpmParameterValue> benList=new ArrayList<PpmParameterValue>();   
	
	private String paramType;
	
	private String value1;
	
	private String groupCode;
	
	private String value2;
	
	private String value3;
	
	private String value4;
	
	private String value5;
	
	private String isMultiValue;
	
	private String fieldName;
	
	private String fName="";
    
	private PpmParameterValuePK ppmParameterValuePK=null;
	
	private PpmParameterType ppmParamType=null;
	
	private PpmParameterValue ppmParamValue=null;
	
    
	private String  paramTypeCode="";
		
	private List<PpmParameterValue> ruleDtlList=new ArrayList<PpmParameterValue>();
	
	
	public String getParamType() {
		return paramType;
	}

	public void setParamType(String paramType) {
		this.paramType = paramType;
	}

	public String getValue1() {
		return value1;
	}

	public void setValue1(String value1) {
		this.value1 = value1;
	}
    	
	public String getValue2() {
		return value2;
	}

	public void setValue2(String value2) {
		this.value2 = value2;
	}


	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public String getValue3() {
		return value3;
	}

	public void setValue3(String value3) {
		this.value3 = value3;
	}

	public String getValue4() {
		return value4;
	}

	public void setValue4(String value4) {
		this.value4 = value4;
	}

	public String getValue5() {
		return value5;
	}

	public void setValue5(String value5) {
		this.value5 = value5;
	}
    	
	public String getIsMultiValue() {
		return isMultiValue;
	}

	public void setIsMultiValue(String isMultiValue) {
		this.isMultiValue = isMultiValue;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getValidateForm() {
		return validateForm;
	}

	public void setValidateForm(String validateForm) {
		this.validateForm = validateForm;
	}

	public String getDeleteBen() {
		return deleteBen;
	}

	public void setDeleteBen(String deleteBen) {
		this.deleteBen = deleteBen;
	}
    
	private int resultSize=0;
	
	private int editResultSize=0;
	
	/** itemSize (number of items in the list)*/
	private int itemsSize;
	/*
	 * return int (itemSize)
	 */
	public int getItemsSize() {
		return getItems().size();
	}

	/**
	 * @return itemSize
	 */
	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}
		
   	public int getResultSize() {
		return resultSize;
	}

	public void setResultSize(int resultSize) {
		this.resultSize = resultSize;
	}

	public int getEditResultSize() {
		return editResultSize;
	}

	public void setEditResultSize(int editResultSize) {
		this.editResultSize = editResultSize;
	}
   
	/**
	 * Constructor for BatchJobController
	 */
	public ParameterValueController() {
		//Initialize item object 
		item = new PpmParameterType();
		// Initialize default Search criteria
		//this.getSearchCriteria().put(getStatusFieldName(), "N");
		
		// Initialize default sort field
		sortField = "parmtypecode";
		sortAscending=true;
	}
	
	/**
	 * @return the selectedApplication
	 */
	public String getSelectedApplication() {
		return selectedApplication;
	}

	/**
	 * @param selectedApplication the selectedApplication to set
	 */
	public void setSelectedApplication(String selectedApplication) {
		this.selectedApplication = selectedApplication;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItems()
	 */
	public List<PpmParameterType> getItems() {
		if (items == null) {
			reloadItems();
		}
		return items;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getDAO()
	 */
	public PaginatedDAO<PpmParameterType, String> getDAO() {
		//ppmParmTypeDAO=new PpmParameterTypeJpaDAO();
		System.out.println("ppmParmTypeDAO=="+ppmParmTypeDAO);
		return ppmParmTypeDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItem(java.lang.Object
	 * )
	 */
	public void setItem(PpmParameterType item) {
		this.item = item;

	}
     

	public PpmParameterValue getPpmParamValue() {
		return ppmParamValue;
	}

	public void setPpmParamValue(PpmParameterValue ppmParamValue) {
		this.ppmParamValue = ppmParamValue;
	}

	public String getParamTypeCode() {
		return paramTypeCode;
	}

	public void setParamTypeCode(String paramTypeCode) {
		this.paramTypeCode = paramTypeCode;
	}
    
	public List<PpmParameterValue> getBenList() {
		return benList;
	}

	public void setBenList(List<PpmParameterValue> benList) {
		this.benList = benList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItems(java.util.
	 * List)
	 */
	public void setItems(List<PpmParameterType> items) {
		this.items = items;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItem()
	 */
	public PpmParameterType getItem() {
		return item;
	}
		
	public ParameterValueDAO getParameterValueDAO() {
		return parameterValueDAO;
	}

	public void setParameterValueDAO(ParameterValueDAO parameterValueDAO) {
		this.parameterValueDAO = parameterValueDAO;
	}

	public PpmParameterTypeDAO getPpmParmTypeDAO() {
		//ppmParmTypeDAO=new PpmParameterTypeJpaDAO();
		return ppmParmTypeDAO;
	}

	public void setPpmParmTypeDAO(PpmParameterTypeDAO ppmParmTypeDAO) {
		this.ppmParmTypeDAO = ppmParmTypeDAO;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getSelectedItems()
	 */
	public List<PpmParameterType> getSelectedItems() {
		List<PpmParameterType> selectedList = new ArrayList<PpmParameterType>();
		//Get the List of selected items from the dataTable
		for (PpmParameterType item : getItems()) {
			
			// Add item to the selectedList if the item is selected
			if (item.isSelected()){
				System.out.println("Selected item.getParamType()="+item.getParmtypecode());
				selectedList.add(item);
			}
		}
		return selectedList;

	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getSelectedItems()
	 */
	public List<PpmParameterValue> getSelectedItemsofParamValue() {
		List<PpmParameterValue> selectedList = new ArrayList<PpmParameterValue>();
		//Get the List of selected items from the dataTable
		
		for (PpmParameterValue item : benList) {
			
			// Add item to the selectedList if the item is selected
			if (item.isSelected()){
				System.out.println("Selected item.getParamType()="+item.isSelected());
				selectedList.add(item);
			}
		}
		return selectedList;

	}
	
	
	/**
	 * 
	 * @return HtmlDataTable representing ppmParamValueTable
	 */
	public HtmlDataTable getPpmParamValueTable() {
	return (HtmlDataTable) JSFUtil.findComponentInRoot("ppmParamValueTable");
	}
	
	/**
	 * 
	 * @return HtmlDataTable representing ppmParamValueTable
	 */
	public HtmlDataTable getPpmParamValueCreateTable() {
	return (HtmlDataTable) JSFUtil.findComponentInRoot("inputDataTable");
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String listSetupString() {
          
		// Initialize default values for SearchCriteria and PageInfo
		if (getSearchCriteria() != null) {
			setSearchCriteria(new HashMap<String, Object>());
			getSearchCriteria().put(getStatusFieldName(),"");
		}
		// Set 0 as the first page
		if (getPageInfo() != null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		reloadItems();
		item=new PpmParameterType();
		// returns the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
    /*Disable and Enable Add Value and Remove Value Button*/
	public void getisMultiValue(){
	if("Y".equals(isMultiValue)){
	isMultiValue="Y";
	System.out.println("isMultiValue--"+isMultiValue);
	}
	else
	{
	isMultiValue="N";
	}
	}
	
	@Override
	public String editSetup() {
		//
		if(benList!=null){
		resultSize=benList.size();
		}
		//if(resultSize==0){
		benList=new ArrayList<PpmParameterValue>();	
		//}
		editResultSize=ruleDtlList.size();
		if(editResultSize==0){
			ruleDtlList=new ArrayList<PpmParameterValue>();	
		}
		
		System.out.println("resultSize from editSetup="+resultSize);
		value1="";
		value2="";
		value3="";
		value4="";
		value5="";
		//benList=new ArrayList<PpmParameterValue>();
		System.out.println("ruleDtlList.size() from Edit me="+ruleDtlList.size());
		int i;
		isMultiValue="Y";
		Iterator<PpmParameterValue> itr=ruleDtlList.iterator();
				
		return getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String detailSetup() {
		
		//Get the Item to be passed to Detail page
		item = (PpmParameterType) this.getPpmParamValueTable().getRowData();
		//Forward to detail Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#createSetup()
	 */
	public String createSetup() {
		// create a new instance of item
		//resultSize=0;
	    benList=new ArrayList<PpmParameterValue>();
	    resultSize=benList.size();
	    System.out.println("resultSize from createSetup method"+resultSize);
		item=new PpmParameterType();
		value1="";
		value2="";
		value3="";
		value4="";
		value5="";
		isMultiValue="Y";
		//Forward to create Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_CREATE_NAVIGATION;
	}

	/**
	 * @param context FacesContext reference 
	 * @param component component that fired the event
	 * @param value Value of the UI Component
	 */
	
	public void validateForm(FacesContext context, UIComponent component,
			Object value) {
		
		FacesMessage message = null;
		String componentId = component.getId();
		int valueLength;
		
		// Do not process if the value is null
		if (value == null) {
			return;
		}
		else {
			valueLength=value.toString().length();
		}
		
		//Validate for miscellaneous characters 
		if ((componentId.equalsIgnoreCase("groupCode") || componentId.equalsIgnoreCase("groupDesc")
				|| componentId.equalsIgnoreCase("groupName"))
				&& (value instanceof String)) {
			value=vaildateChars((String) value,context,componentId);
		}
		
		//Validation for groupCode component
		if (componentId.equalsIgnoreCase("groupCode")) {
			//Check length
			if (valueLength >5 ) {
				
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupCode.chars",FacesMessage.SEVERITY_ERROR, componentId,5);
				throw new ValidatorException(message);
			}
		}//Validation for groupDesc component 
		else if (componentId.equalsIgnoreCase("groupDesc")) {
			//Check length
			if (valueLength >50 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupDesc.chars",FacesMessage.SEVERITY_ERROR, componentId, 50);
				throw new ValidatorException(message);
			}
		}//Validation for groupName component
		else if (componentId.equalsIgnoreCase("groupName")) {
			//Check length
			if (valueLength >30 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.jobDescription.chars",FacesMessage.SEVERITY_ERROR, componentId, 30);
				throw new ValidatorException(message);
			}
		}
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#isUnique()
	 */
	public boolean isUnique(List<PpmParameterValue> ruleDtlList) {
		boolean isUnique = false;
		try {
			//Check if the item is Unique in the Table
			isUnique =getPpmParmTypeDAO().isUnique(ruleDtlList);
			if(!isUnique){
						
			}
		} catch (DAOException e) {
			
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.BusinessErrorMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUnique;
	}
    
	
	/*Check if the item is unique in PPM_EXE_RULES_CRITERIA table*/
    public boolean isUniqueJoinTable(List<PpmParameterValue> benList){
    	boolean isUniqueJoinTable = false;
		try {
			//Check if the item is Unique in the Table
			isUniqueJoinTable =getPpmParmTypeDAO().isUniqueJoinTable(benList);
			if(!isUniqueJoinTable){
						
			}
			
		} catch (DAOException e) {
			
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUniqueJoinTable;	
    }
	public boolean isUniqueFromListObject(List<PpmParameterValue> benList){
		boolean isUniqueFromListObject = false;
		try {
			//Check if the item is Unique in the Table
			isUniqueFromListObject =getPpmParmTypeDAO().isUniqueFromListObject(benList);
			System.out.println("isUniqueFromListObject===="+isUniqueFromListObject);
			if(!isUniqueFromListObject){
				
			
			}
			
		} catch (DAOException e) {
			
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUniqueFromListObject;		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#create()
	 */
	public String create() {
		if("Y".equals(isMultiValue)){
		isMultiValue="Y";
		}
		else{
		isMultiValue="N";	
		}
		FacesMessage facesMessage = null;
		String nav = "";
		
		try {
			//Set userInfo for CurrencyCode
			item.setCreatedBy(JSFUtil.getLoggedInUserInfo());
			//Set create Date
			item.setCreateDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			item.setIsMultiValue(isMultiValue);
			System.out.println("benList=="+benList.size());
			for (PpmParameterValue item : benList) {
			//String gcode=item.getGroupCode();	
			//String value1=item.getValue1();
			//System.out.println("gcode=="+gcode);
			//System.out.println("Value1="+value1);
			}
			if(benList.size()>0){
			item.setPpmParameterValue(benList);
			}
			
			if(isUnique()&&isUniqueFromListObject(benList)){
			 getPpmParmTypeDAO().save(item);
			}
			 else{
			  FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Criteria already exists"));		
			 //benList=new ArrayList<PpmParameterValue>();  
			  if("Y".equals(isMultiValue)){
					 isMultiValue="Y";
					 }
					 else{
					 isMultiValue="N";	
					 }	 
			 return "";	 
			 }
		} catch (Exception e) {
			  benList=new ArrayList<PpmParameterValue>();  
			 if("Y".equals(isMultiValue)){
				 isMultiValue="Y";
				 }
				 else{
				 isMultiValue="N";	
				 }
			 System.out.println("isMultiValue---end"+isMultiValue);
			  // Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.add.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);
			//Print StackTrace
			e.printStackTrace();
			// Return Navigation case of the create page
			return "";
		}
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Criteria created successfully"));		
		
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
		
	
	}

	/**
	 * Update the entity in the database. Serves user update action on Edit page.
	 * @return List page Navigation case defined in faces-config.xml
	 */
	
	@Override
	public String update() {
		
		String navigationCase ="";
		PpmParameterType ppmParameterType=null;
		FacesMessage facesMessage = null;
		// set update information
		getItem().setUpdatedBy(JSFUtil.getLoggedInUserInfo());
		getItem().setUpdateDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				
		//call super.update
		
		
		try{
			
			//List <PpmExeRulesCriteria> benList=new ArrayList<PpmExeRulesCriteria>();   
			System.out.println("getParmtypecode().getParmtypecode()="+getItem().getParmtypecode());
			//List<PpmExeRulesCriteria> updPpmRCri=getPpmExeRulesDAO().getRuleDtlCrtList(getItem().getExeRuleName());
			PpmParameterType ppmParamType=getPpmParmTypeDAO().getPpmParamTypeList(getItem().getParmtypecode());
			ppmParamType.setParamDesc(getItem().getParamDesc());
			ppmParamType.setValueType(getItem().getValueType());
			ppmParamType.setIsMultiValue(getItem().getIsMultiValue());
			ppmParamType.setIsRange(getItem().getIsRange());
			ppmParamType.setIsUserMaint(getItem().getIsUserMaint());
	        ppmParamType.setPpmParameterValue(benList);
	      //call super.update
			//navigationCase = super.update();
	     
	        System.out.println("benList size in for loop="+benList.size());
	        if(isUniqueJoinTable(benList)&&isUniqueFromListObject(benList)){
		    ppmParameterType= getPpmParmTypeDAO().update(ppmParamType);
	        
	        }
	        else{
	        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Criteria already exists"));		
	         
	        return "";
	        }
	      
		    
		    }
		
		catch (Exception e){
			
			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(),"bundles.UIMessages",
					"entity.update.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);
			e.printStackTrace();
			//return "";
			// Return Navigation case of the create page
		   }
		   //return navigationCase;
		   
		   benList=new ArrayList<PpmParameterValue>();  
		   FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Criteria updated successfully"));
		   return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;   
	   }

	/*
	 * (non-Javadoc)
	 * 
	 * @#deleteValues() delete param values from list benList
	 */ 
	public String deleteValues() {
		FacesMessage facesMessage = null;
		if (getSelectedItemsofParamValue() == null || getSelectedItemsofParamValue().size() < 1) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArrayofParamValue(getSelectedItemsofParamValue());
		System.out.println("=====AbstractCrudController. disableItems ");
		for(int i=0;i<benList.size();i++){
			
			benList.remove(i);
			
		}

		getPageInfo().setCurrentPage(0);
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.deleted.success",
				idArrays.length, getEntityName());
		FacesContext.getCurrentInstance().addMessage("successDeleteItems",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_CREATE_NAVIGATION;
	}

	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @deleteItem()
	 */
	public String deleteItem() {
		FacesMessage facesMessage = null;
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getItem());
		
		for(int i=0;i<idArrays.length;i++){
			System.out.println("disableItem idArrays="+idArrays[i]);
		}

		if (idArrays != null && idArrays.length > 0) {
			try {
				
				getPpmParmTypeDAO().updateEntityStatusByIds(idArrays,getIdFieldName(),
						  JSFUtil.getLoggedInUserInfo());

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil
				.getMessage(FacesContext.getCurrentInstance(),
						"bundles.UIMessages",
						"entity.deActivateItem.error",
						FacesMessage.SEVERITY_ERROR, getItem(),
						getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"entity.deleteItem", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.deleted.success",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage("successDeleteItem",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	  

	
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItems()
	 */
	public String deleteItems() {
		FacesMessage facesMessage = null;
		if (getSelectedItems() == null || getSelectedItems().size() < 1) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getSelectedItems());
		System.out.println("=====AbstractCrudController. disableItems "+idArrays.length);
		for(int i=0;i<idArrays.length;i++){
			System.out.println("disableItem idArrays="+idArrays[i]);
		}

		if (idArrays != null && idArrays.length > 0) {
			try {
				// Delete the items from the Database Table
				// getStatusFieldName should be implemented in subclass
				getPpmParmTypeDAO().updateEntityStatusByIds(idArrays,getIdFieldName(),
						 JSFUtil.getLoggedInUserInfo());
			} catch (DAOException e) {
				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"entity.deActivateItems.error",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"deActivateItemsError", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		getPageInfo().setCurrentPage(0);
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.deleted.success",
				idArrays.length, getEntityName());
		FacesContext.getCurrentInstance().addMessage("successDeleteItems",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItems()
	 */
	public String enableItems() {
		FacesMessage facesMessage = null;
		System.out.println("getSelectedItems().size()=="+getSelectedItems().size());
		if (getSelectedItems() == null || getSelectedItems().size() < 1) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		// Fetch the items to be deleted.
	 
		String[] idArrays = getIDsArray(getSelectedItems());
		System.out.println("idArrays=="+getIDsArray(getSelectedItems()));
		System.out.println("idArrays==="+idArrays.length);
		for(int i=0;i<idArrays.length;i++){
			System.out.println("disableItem idArrays="+idArrays[i]);
		}

		System.out.println("=====AbstractCrudController. enableItems ");
		if (idArrays != null && idArrays.length > 0) {
			try {
				// Delete the items from the Database Table
				// getStatusFieldName should be implemented in subclass
				getPpmParmTypeDAO().updateEntityStatusByIds(idArrays, getIdFieldName(),JSFUtil.getLoggedInUserInfo());

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"entity.activateItems.error",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance().addMessage("activatItems",
						facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		getPageInfo().setCurrentPage(0);
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.activateItems.success",
				idArrays.length, getEntityName());
		FacesContext.getCurrentInstance().addMessage("successActivateItems",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @#getIDsArray(java.util.List)
	 */
	public String[] getIDsArrayofParamValue(List<PpmParameterValue> items) {
		// return null if List is null or empty
		if (items == null || items.size() == 0) {
			return null;
		}
		// Build the array of the ids
		String[] ids = new String[items.size()];
		System.out.println("ids---"+ids.length);
		int i = 0;
		for (PpmParameterValue entity : items) {
			ids[i] = entity.getPk();
			i++;
		}
		
		return ids;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.util.List)
	 */
	public String[] getIDsArray(List<PpmParameterType> items) {
		// return null if List is null or empty
		if (items == null || items.size() == 0) {
			return null;
		}
		// Build the array of the ids
		String[] ids = new String[items.size()];
		System.out.println("ids---"+ids.length);
		int i = 0;
		for (PpmParameterType entity : items) {
			ids[i] = entity.getPk();
			i++;
		}
		
		return ids;
	}
    
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.lang.Object)
	 */
	public String[] getIDsArray(PpmParameterType item) {
		// return null if item is null 
		if (item == null) {
			return null;
		}
		//Build the idsArray
		System.out.println("getParamType() "+item.getParmtypecode());
		String[] ids = {(item.getParmtypecode()) };
		return ids;
	}


	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getEntityName()
	 */
	public String getEntityName() {
		return "Parameter Value";
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getStatusFieldName()
	 */
	public String getStatusFieldName() {
		return "parmtypecode";

	}	
	
	public String getIdFieldName() {
		return "parmtypecode";
	}
	/**
	 * Fetch Group Priority to be displayed in search criteria
	 * @return List of Group Priority Items for the Select Options
	 */
	public List<SelectItem> getExecutionRuleList() {

		List<ParameterValue> executionRuleList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			executionRuleList = getParameterValueDAO().getExecutionTypeList();
			System.out.println("executionRuleList=="+executionRuleList);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: executionRuleList) {
			
			System.out.println("parameterValue=="+parameterValue.getValue1());
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	}
	
	/**
	 * Fetch Group Status to be displayed in search criteria
	 * @return List of Group Status Items for the Select Options
	 */
	public List<SelectItem> getGroupStatusList() {

		List<ParameterValue> groupStatusList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			groupStatusList = getParameterValueDAO().getStatus();
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: groupStatusList) {
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	}
	
	
	/**
	 * Fetch Group Code to be displayed in search criteria
	 * @return List of Group Status Items for the Select Options
	 */
	public List<SelectItem> getGroupCodeList() {

		List<ParameterValue> groupCodeList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			groupCodeList = getParameterValueDAO().getGroupCode();
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: groupCodeList) {
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	}
	
	
	/**
	 * Fetch Group Status to be displayed in search criteria
	 * @return List of Group Status Items for the Select Options
	 */
	public List<SelectItem> getGroupPercentList() {

		List<ParameterValue> groupPercentList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			groupPercentList = getParameterValueDAO().getPercent();
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		list.add(new SelectItem("0","-Select-"));	
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: groupPercentList) {
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	}
	
	
	/**
	 * Fetch Group Priority to be displayed in search criteria
	 * @return List of Group Priority Items for the Select Options
	 */
	public List<SelectItem> getFieldNameList() {

		List<ParameterValue> fieldNameList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			fieldNameList = getParameterValueDAO().getFieldNameList();
			System.out.println("fieldNameList=="+fieldNameList);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: fieldNameList) {
			
			System.out.println("parameterValue=="+parameterValue.getValue1());
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	}
	
	public List<SelectItem> getValueList() {

		List<ParameterValue> valueList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			// Fetch the List of Application objects
			valueList = getParameterValueDAO().getValueList(fieldName);
			System.out.println("valueList=="+valueList);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (ParameterValue parameterValue: valueList) {
			
			System.out.println("parameterValue=="+parameterValue.getValue1());
			list.add(new SelectItem(parameterValue.getValue1(),parameterValue.getValue1()));		
		}
		return list;
	}
	
		
	
	/*Add rules to benList*/
	public void addRules(){
	isMultiValue="Y";
	ppmParamType=new PpmParameterType();	
	resultSize=0;
	ppmParamValue=new PpmParameterValue();
	ppmParameterValuePK=ppmParamValue.getPpmParameterValue();
	System.out.println("getItem().getParmtypecode()=="+getItem().getParmtypecode());
	ppmParameterValuePK.setParmtypecode(getItem().getParmtypecode());
	System.out.println("getGroupCode()=="+getGroupCode());
	//System.out.println("getGroupCode()-----"+itemCriteria.get);
	ppmParameterValuePK.setGroupCode(getGroupCode());
	ppmParameterValuePK.setValue1(getValue1());
	System.out.println("paramType=="+paramType);
	ppmParamType.setParmtypecode(getItem().getParmtypecode());
	//ppmParamValue.setParamTypeId(getItem().getParamTypeId());
	System.out.println("getGroupCode()="+getGroupCode());
	
	ppmParamValue.setGroupCode(getGroupCode());
	System.out.println("itemCriteria.getValue1()="+value1);
	ppmParamValue.setFieldName(fieldName);
	ppmParamValue.setValue1(value1);
	ppmParamValue.setValue2(value2);
	ppmParamValue.setValue3(value3);
	ppmParamValue.setValue4(value4);
	ppmParamValue.setValue5(value5);
	//Set userInfo for CurrencyCode
	ppmParamValue.setCreatedBy(JSFUtil.getLoggedInUserInfo());
	//Set create Date
	ppmParamValue.setCreateDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
	//benList.add(ppmParamValue);
	
	//ppmParamType.setPpmParmValue(benList);
	
	benList=addBenToBenList(ppmParamValue);
	if(benList!=null){
	resultSize=benList.size();
	System.out.println("benList--"+resultSize);
	}
	}
	
	/*public int removeRules(){
	removeRulesList(ppmExe);    
	return 0;
	}
	   */
	

	private List<PpmParameterValue> addBenToBenList(PpmParameterValue benInfoDO) {
		resultSize=0; 
		
		if(benList!=null)
		    {
		    //Collections.sort(benList);
			String parmTypeCode=benInfoDO.getPpmParameterValue().getParmtypecode();
			System.out.println("parmTypeCode"+parmTypeCode);
			Set set=new HashSet<PpmParameterValue>();
			set.add(parmTypeCode);
			System.out.println("set==="+set.size());
			
			benList.add(benInfoDO); 
			
		    resultSize=benList.size();
		    System.out.println("resultSize==="+resultSize);
		    
		    }
		
	
		return ( List<PpmParameterValue> ) benList;
	}
	/*Delete rule from database*/
	public void deleteSelectedParamValue() {
		System.out.println("benList.iterator()="+ruleDtlList.size());
		Iterator itr=ruleDtlList.iterator();
		PpmParameterValue ppmParameterValue=null;
		String paramTypeCode="";
		String groupCode="";
		String value1="";
		while(itr.hasNext()){
		ppmParameterValue=(PpmParameterValue)itr.next();
		paramTypeCode=ppmParameterValue.getPpmParameterValue().getParmtypecode();
		groupCode=ppmParameterValue.getPpmParameterValue().getGroupCode();
		value1=ppmParameterValue.getPpmParameterValue().getValue1();
		}
		System.out.println("getParamTypeCode="+getParamTypeCode());
		
		try{
			//ruleDtlList
			System.out.println("Tying to delete ParamValue");
			getPpmParmTypeDAO().deleteParamValueList(getParamTypeCode(),getGroupCode(),getValue1());
			System.out.println("Successfully deleted ParamValue");
		}
		catch(DAOException daoe){
			daoe.printStackTrace();
		}
		//ruleDtlList.remove(--sequence);
		System.out.println("benInfoDO=getRulesCount="+ruleDtlList.size());
		
	}
	/*Delete rule from List*/
	public void deleteParamValueFromList(){
		Iterator<PpmParameterValue> itrppmparamValue=benList.iterator();
		String parmtypecode="";
		String groupCode="" ;
		String value1="";
		while(itrppmparamValue.hasNext()){
			System.out.println("benList.iterator()=="+benList.size());
			PpmParameterValue ppmParmVale=itrppmparamValue.next();
			
			parmtypecode=ppmParmVale.getPpmParameterValue().getParmtypecode();
			groupCode=ppmParmVale.getPpmParameterValue().getGroupCode();
			value1=ppmParmVale.getPpmParameterValue().getValue1();
			System.out.println("parmtypecode===----"+parmtypecode);
			System.out.println("groupCode===----"+groupCode);
			System.out.println("value1===----"+value1);
			PpmParameterValue ppmParameterValue=new PpmParameterValue();
			PpmParameterValuePK ppmParameterValuePK=ppmParameterValue.getPpmParameterValue();
			PpmParameterValuePK ppmParameterValuePK1=new PpmParameterValuePK(parmtypecode,groupCode,value1);
			ppmParameterValuePK.setParmtypecode(getParamTypeCode());
			ppmParameterValuePK.setGroupCode(getGroupCode());
			ppmParameterValuePK.setValue1(getValue1());
			System.out.println("ppmParameterValuePK==="+ppmParameterValuePK.getGroupCode());
			if(ppmParameterValuePK.equals(ppmParameterValuePK1)){
				System.out.println("Parma value is equeal");
				itrppmparamValue.remove();
			}
			
			//benList.remove(ppmParmVale);
			
			
			else{
				System.out.println("Parma value not equal");
			}
			Set<PpmParameterValue> ppmParameterValue1=new HashSet<PpmParameterValue>(benList);
		    System.out.println("ppmParameterValue===="+ppmParameterValue1.size());
		}
	}
		
		
	    /*Get Rule detail value for edit page*/
		public List<PpmParameterValue>getRuleDtlList(){
		
         ArrayList<SelectItem> list = new ArrayList<SelectItem>();
         ruleDtlList=new ArrayList<PpmParameterValue>();
		try {
			// Fetch the List of Application objects
			ruleDtlList =getPpmParmTypeDAO().getParamValueList(getItem().getParmtypecode());
			/*if(ruleDtlList.size()==0){
			resultSize=0;	
			}*/
			
			System.out.println("resultSize from getRuleDtlList"+resultSize);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Add the Application List to the Select Item List
		for (PpmParameterValue ppmParamValue: ruleDtlList) {
			
			//System.out.println("parameterValue=="+ppmParamValue.getValue1());
			list.add(new SelectItem(ppmParamValue.getPpmParameterValue().getValue1(),ppmParamValue.getPpmParameterValue().getValue1()));		
		}
		
		return ruleDtlList;
		}
	    
		
	
}
