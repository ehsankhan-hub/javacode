package com.bsf.ppm.fransiLeasing;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import javax.faces.validator.ValidatorException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.richfaces.component.html.HtmlDataTable;

import com.bsf.ipp.IPPUTIL;
import com.bsf.ipp.dao.PaginatedDAO;

import com.bsf.ppm.Ppm_Instructions;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.InstructionDAO;
import com.bsf.ppm.dao.ParameterValueDAO;


import com.bsf.ppm.exceptions.DAOException;

import com.sun.faces.util.MessageFactory;

/**
 * CRUD Controller Class for the Ppm_Instructions CRUD Operations.
 */
public class SFLController extends
		AbstractCrudController<Ppm_Instructions, String> {

	private boolean rangeFlag=false;
	
	private FacesMessage facesMessage;
	
	/** Attribute item Ppm_Instructions Entity */
	private Ppm_Instructions item;

	/** Attribute items for Ppm_Instructions Entity List */
	private List<Ppm_Instructions> items;
	
	private ParameterValueDAO parameterValueDAO;
	
	private InstructionDAO instructionDAO;
	
	private String selectedApplication;
	
    private boolean activateAllowed = false;
	
	private boolean deActivateAllowed = false;
	
	/** itemSize (number of items in the list)*/
	private int itemsSize;
	/*
	 * return int (itemSize)
	 */
	public int getItemsSize() {
		if(getItems()!=null){
		
		return getItems().size();
		}
		else{
		return 0;	
		}
	}

	/**
	 * @return itemSize
	 */
	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}

	
	
	public boolean isActivateAllowed() {
		return activateAllowed;
	}

	public void setActivateAllowed(boolean activateAllowed) {
		this.activateAllowed = activateAllowed;
	}

	public boolean isDeActivateAllowed() {
		return deActivateAllowed;
	}

	public void setDeActivateAllowed(boolean deActivateAllowed) {
		this.deActivateAllowed = deActivateAllowed;
	}

	/**
	 * Constructor for SFLController
	 */
	public SFLController() {
		//Initialize item object 
		item = new Ppm_Instructions();
		// Initialize default Search criteria
		this.getSearchCriteria().put(getStatusFieldName(), "ACT");
		//this.getSearchCriteria().put("createdBy", JSFUtil.getLoggedInUserInfo().getUserId());
		this.getSearchCriteria().put("instProrty", 8);
		
		// Initialize default sort field
		sortField = "instReference";
		sortAscending=true;
	}

	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#searchSetup()
	 */
	public String searchSetup() {

		// Set PageInfo with current Page 0
		getPageInfo().setCurrentPage(0);

		// Set the search criteria
		setSearchCriteria(prepareSearchCriteria());

		// Reload the items in the list
		reloadItems();
        String status = (String) JSFUtil.findComponentValueInRoot("searchStatus");
		
		if((status != null && status !="" && status.equals("SUS"))&&(status != null && status !="" && status.equals("CLS"))){
			setActivateAllowed(false);
		}
		else if(status != null && status !="" && status.equals("ACT")){
			setActivateAllowed(true);
		}
		else {
			setActivateAllowed(false);
		}
		
		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
	/**
	 * @return the selectedApplication
	 */
	public String getSelectedApplication() {
		return selectedApplication;
	}

	/**
	 * @param selectedApplication the selectedApplication to set
	 */
	public void setSelectedApplication(String selectedApplication) {
		this.selectedApplication = selectedApplication;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItems()
	 */
	public List<Ppm_Instructions> getItems() {
		if (items == null) {
			reloadItems();
		}
		return items;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getDAO()
	 */
	public PaginatedDAO<Ppm_Instructions, String> getDAO() {
		return instructionDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItem(java.lang.Object
	 * )
	 */
	public void setItem(Ppm_Instructions item) {
		this.item = item;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.controller.jsf.AbstractCrudController#setItems(java.util.
	 * List)
	 */
	public void setItems(List<Ppm_Instructions> items) {
		this.items = items;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getItem()
	 */
	public Ppm_Instructions getItem() {
		return item;
	}
	
	
	public ParameterValueDAO getParameterValueDAO() {
		return parameterValueDAO;
	}

	public void setParameterValueDAO(ParameterValueDAO parameterValueDAO) {
		this.parameterValueDAO = parameterValueDAO;
	}

	public void setInstructionDAO(InstructionDAO instructionDAO) {
		this.instructionDAO = instructionDAO;
	}

	public InstructionDAO getInstructionDAO() {
		return instructionDAO;
	}

	public List<Ppm_Instructions> getSelectedItems() {
		List<Ppm_Instructions> selectedList = new ArrayList<Ppm_Instructions>();
		//Get the List of selected items from the dataTable
		for (Ppm_Instructions item : getItems()) {
			
			// Add item to the selectedList if the item is selected
			if (item.isSelected()){
				System.out.println("Selected Item Status="+item.getStatus());
				selectedList.add(item);
			}
		}
		return selectedList;

	}
	
	/**
	 * 
	 * @return HtmlDataTable representing ppmGroupTable
	 */
	public HtmlDataTable getSFLTable() {
		return (HtmlDataTable) JSFUtil.findComponentInRoot("PpmSflInstructionsTable");
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String listSetupString() {

		// Initialize default values for SearchCriteria and PageInfo
		if (getSearchCriteria() != null) {
			setSearchCriteria(new HashMap<String, Object>());
			getSearchCriteria().put(getStatusFieldName(),"ACT");
			getSearchCriteria().put("instProrty", 8);
		}
		// Set 0 as the first page
		if (getPageInfo() != null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		reloadItems();
		setActivateAllowed(false);
		setDeActivateAllowed(false);
		// returns the Navigation case for list page
		System.out.println(getClass().getSimpleName());
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	@Override
	public String editSetup() {
	
		return getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String detailSetup() {
		//Get the Item to be passed to Detail page
		item = (Ppm_Instructions) this.getSFLTable().getRowData();
		//Forward to detail Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_DETAIL_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.CRUDController#createSetup()
	 */
	public String createSetup() {
		// create a new instance of item
		item = new Ppm_Instructions();
		//Forward to create Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_CREATE_NAVIGATION;
	}

	/**
	 * @param context FacesContext reference 
	 * @param component component that fired the event
	 * @param value Value of the UI Component
	 */
	public void validateForm(FacesContext context, UIComponent component,
			Object value) {
		
		FacesMessage message = null;
		String componentId = component.getId();
		int valueLength;
		
		// Do not process if the value is null
		if (value == null) {
			return;
		}
		else {
			valueLength=value.toString().length();
		}
		
		//Validate for miscellaneous characters 
		if ((componentId.equalsIgnoreCase("groupCode") || componentId.equalsIgnoreCase("groupDesc")
				|| componentId.equalsIgnoreCase("groupName"))
				&& (value instanceof String)) {
			value=vaildateChars((String) value,context,componentId);
		}
		
		//Validation for groupCode component
		if (componentId.equalsIgnoreCase("groupCode")) {
			//Check length
			if (valueLength >5 ) {
				
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupCode.chars",FacesMessage.SEVERITY_ERROR, componentId,5);
				throw new ValidatorException(message);
			}
		}//Validation for groupDesc component 
		else if (componentId.equalsIgnoreCase("groupDesc")) {
			//Check length
			if (valueLength >50 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.groupDesc.chars",FacesMessage.SEVERITY_ERROR, componentId, 50);
				throw new ValidatorException(message);
			}
		}//Validation for groupName component
		else if (componentId.equalsIgnoreCase("groupName")) {
			//Check length
			if (valueLength >30 ) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"batchJob.jobDescription.chars",FacesMessage.SEVERITY_ERROR, componentId, 30);
				throw new ValidatorException(message);
			}
		}
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#isUnique()
	 */
	public boolean isUnique() {
		boolean isUnique = false;
		try {
			//Check if the item is Unique in the Table
			isUnique = getDAO().isUnique(getItem());
		} catch (DAOException e) {
			
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.BusinessErrorMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUnique;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#create()
	 */
	public String create() {
		FacesMessage facesMessage = null;
		String nav = "";
		try {
			//Set userInfo for CurrencyCode
			item.setCreatedBy(JSFUtil.getLoggedInUserInfo().getUserId());
			//Set create Date
			item.setCreatedDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						
			//set Status as Active
			item.setStatus("A");
			//Set navigation case from super.create
			nav = super.create();
		
		} catch (Exception e) {

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.add.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);
			//Print StackTrace
			e.printStackTrace();
			// Return Navigation case of the create page
			return "";
		}

		return nav;
	}

	/**
	 * Update the entity in the database. Serves user update action on Edit page.
	 * @return List page Navigation case defined in faces-config.xml
	 */
	@Override
	public String update() {
		FacesMessage facesMessage = null;
		// set update information
		getItem().setUpdatedBy(JSFUtil.getLoggedInUserInfo().getUserId());
		//getItem().setUpdateDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				
		//call super.update
		String navigationCase = super.update();
		
		try{
			getInstructionDAO().updateInstructionPriority(getItem().getInstReference(), 12);
		}catch (Exception e){

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.update.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);
			e.printStackTrace();

			// Return Navigation case of the create page
			return "";
		
		}
		
		return navigationCase;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItem()
	 */
	public String disableItem() {
		FacesMessage facesMessage = null;
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getItem());
		
		for(int i=0;i<idArrays.length;i++){
			System.out.println("disableItem idArrays="+idArrays[i]);
		}

		if (idArrays != null && idArrays.length > 0) {
			try {
				
				getInstructionDAO().updateEntityStatusByIds(idArrays,getIdFieldName(),
						getStatusFieldName(),  "I", JSFUtil.getLoggedInUserInfo());

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil
				.getMessage(FacesContext.getCurrentInstance(),
						"bundles.UIMessages",
						"entity.deActivateItem.error",
						FacesMessage.SEVERITY_ERROR, getItem(),
						getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"entity.deleteItem", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.deActivateItem.success",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage("successDeleteItem",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItem()
	 */
	public String enableItem() {
		FacesMessage facesMessage = null;
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getItem());
		System.out.println("=====AbstractCrudController. enableItem ");
		for(int i=0;i<idArrays.length;i++){
			System.out.println("disableItem idArrays="+idArrays[i]);
		}

		if (idArrays != null && idArrays.length > 0) {
			try {
				// Delete the items from the Database Table
				// getStatusFieldName should be implemented in subclass
				getInstructionDAO().updateEntityStatusByIds(idArrays, getIdFieldName(),
						getStatusFieldName(), "ACT", JSFUtil.getLoggedInUserInfo());

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil
				.getMessage(FacesContext.getCurrentInstance(),
						"bundles.UIMessages",
						"entity.activateItem.error",
						FacesMessage.SEVERITY_ERROR, getItem(),
						getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"activateItem.error", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.activateItem.success",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage(
				"itemActivatedSuccessfully", facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItems()
	 */
	public String disableItems() {
		FacesMessage facesMessage = null;
		if (getSelectedItems() == null || getSelectedItems().size() < 1) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getSelectedItems());
		
		for(int i=0;i<idArrays.length;i++){
			
		}

		if (idArrays != null && idArrays.length > 0) {
			try {
				// Delete the items from the Database Table
				// getStatusFieldName should be implemented in subclass
				getInstructionDAO().updateEntityStatusByIds(idArrays,getIdFieldName(),
						getStatusFieldName(), "SUS", JSFUtil.getLoggedInUserInfo());
			} catch (DAOException e) {
				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"entity.deActivateItems.error",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"deActivateItemsError", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		getPageInfo().setCurrentPage(0);
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.suspended.success",
				idArrays.length, getEntityName());
		FacesContext.getCurrentInstance().addMessage("successDeleteItems",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItems()
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItems()
	 */
	public String closeItems() {
		FacesMessage facesMessage = null;
		if (getSelectedItems() == null || getSelectedItems().size() < 1) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getSelectedItems());
		
		for(int i=0;i<idArrays.length;i++){
			
		}

		if (idArrays != null && idArrays.length > 0) {
			try {
				// Delete the items from the Database Table
				// getStatusFieldName should be implemented in subclass
				getInstructionDAO().updateEntityStatusByIds(idArrays,getIdFieldName(),
						getStatusFieldName(), "CLS", JSFUtil.getLoggedInUserInfo());
			} catch (DAOException e) {
				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"entity.deActivateItems.error",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"deActivateItemsError", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		getPageInfo().setCurrentPage(0);
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.suspended.success",
				idArrays.length, getEntityName());
		FacesContext.getCurrentInstance().addMessage("successDeleteItems",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.util.List)
	 */
	public String[] getIDsArray(List<Ppm_Instructions> items) {
		// return null if List is null or empty
		if (items == null || items.size() == 0) {
			return null;
		}
		// Build the array of the ids
		String[] ids = new String[items.size()];
		System.out.println("ids---"+ids.length);
		int i = 0;
		for (Ppm_Instructions entity : items) {
			ids[i] = entity.getPk();
			i++;
		}
		
		return ids;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getIDsArray(java.lang.Object)
	 */
	public String[] getIDsArray(Ppm_Instructions item) {
		// return null if item is null 
		if (item == null) {
			return null;
		}
		//Build the idsArray
		System.out.println("instReference "+item.getInstReference() );
		String[] ids = { item.getInstReference() };
		return ids;
	}


	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getEntityName()
	 */
	public String getEntityName() {
		return "SFL Instruction";
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getStatusFieldName()
	 */
	public String getStatusFieldName() {
		return "status";

	}	
	
	public String getIdFieldName() {
		return "instReference";
	}
	
	
	public String exportToExcel(){
		
		
		
		 ServletOutputStream out=null;
		 FacesContext context=null;
		 org.apache.poi.ss.usermodel.Row row=null;
		 try {	 
		 HSSFWorkbook hssfWorkbook = new HSSFWorkbook();
		 
		 Sheet sheet = hssfWorkbook.createSheet("SFL CustomerList");
		 int rowIndex = 1;
		 
		 reloadCustomersForExport();
		 if(rangeFlag){
		 facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
		"bundles.UIMessages", "excelExport",FacesMessage.SEVERITY_ERROR);
		 FacesContext.getCurrentInstance().addMessage("compCode", facesMessage);
			return	getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
		 }
		// reloadItems();
		 System.out.println("Items of size "+items.size());
		 rangeFlag=false;
		 HSSFCellStyle my_style = hssfWorkbook.createCellStyle();
		 HSSFFont my_font=hssfWorkbook.createFont();
		 my_font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		 my_style.setFont(my_font);
		 
		 Row header = sheet.createRow(0);
		    
		    Cell cell0 = header.createCell(0);
		    cell0.setCellValue("Debit Account");
		    cell0.setCellStyle(my_style);
		    Cell cell1 = header.createCell(1);
		    cell1.setCellValue("Inst Start Date");
		    cell1.setCellStyle(my_style);
		    Cell cell2 = header.createCell(2);
		    cell2.setCellValue("Inst End Date");
		    cell2.setCellStyle(my_style);
		    Cell cell3 = header.createCell(3);
		    cell3.setCellValue("Number Of Inst");
		    cell3.setCellStyle(my_style);
		    
		    Cell cell4 = header.createCell(4);
		    cell4.setCellValue("Installment Amount");
		    cell4.setCellStyle(my_style);
		    
		    
		    Cell cell5 = header.createCell(5);
		    cell5.setCellValue("Total Amount");
		    cell5.setCellStyle(my_style);
		    
		    Cell cell6 = header.createCell(6);
		    cell6.setCellValue("Day Of Payment");
		    cell6.setCellStyle(my_style);
		    
		    Cell cell7 = header.createCell(7);
		    cell7.setCellValue("Inst Created Date");
		    cell7.setCellStyle(my_style);
		    
		    Cell cell8 = header.createCell(8);
		    cell8.setCellValue("Status");
		    cell8.setCellStyle(my_style);
		    
		    SimpleDateFormat sm = new SimpleDateFormat("dd-MM-yyyy");
		    		 
		 for (Ppm_Instructions item : items) { 
			    row = sheet.createRow(rowIndex++);
			    int columnIndex = 0;
			    String strDate = sm.format(item.getStartDateG());
			    String endDate = sm.format(item.getEndDateG());
			    String createdDate=sm.format(item.getCreatedDate());
			    row.createCell(columnIndex++).setCellValue(item.getAccNumber());
			    row.createCell(columnIndex++).setCellValue(strDate);
			    row.createCell(columnIndex++).setCellValue(endDate);
			    row.createCell(columnIndex++).setCellValue(item.getNoOfInst());
			    row.createCell(columnIndex++).setCellValue(item.getMonthlyAmoun().doubleValue());
			    row.createCell(columnIndex++).setCellValue(item.getTotalAmount().doubleValue());
			    row.createCell(columnIndex++).setCellValue(item.getDayofPayment());
			    row.createCell(columnIndex++).setCellValue(createdDate);
			    
			 
			    if(item.getStatus().equals("ACT")){
			    row.createCell(columnIndex++).setCellValue("Active");	
			    }
			    else if(item.getStatus().equals("SUS")){
			    row.createCell(columnIndex++).setCellValue("Suspended");
			    }
			    else{
			   	row.createCell(columnIndex++).setCellValue("Closed");	
			    }

			}

		    context = FacesContext.getCurrentInstance();
	        HttpServletResponse res = (HttpServletResponse) context.getExternalContext().getResponse();
	        res.setContentType("application/vnd.ms-excel");
	        res.setHeader("Content-disposition", "attachment;filename=CustomerList.xls");

	        
	        out = res.getOutputStream();
	        hssfWorkbook.write(out);
	        
	        FacesContext.getCurrentInstance().responseComplete();
		 } catch (Exception e) {
			 log.info("Error Occurs while exporting customers::"+e.getMessage());
		        e.printStackTrace();
		    }
		 finally{
		 try{
		 if(out!=null){	 
		 out.flush();
		 out.close();
		 }
		 else{
			 System.out.println("Out Object---"+out);
		 }
		 }
		 catch(Exception e){
			 e.printStackTrace();
		 }
		 }
		 return "";
	 }
	
	
	private void reloadCustomersForExport() throws DAOException
	{
		int startRange=getPageInfo().getRecordRangeStart();
		System.out.println("Record Range==="+getPageInfo().getRecordRange().substring(0, 2));
		System.out.println("Number of Pages=="+getPageInfo().getNumOfPages());
		System.out.println("Number of Batch size=="+getPageInfo().getBatchSize());
		System.out.println("getCurrentPage=="+getPageInfo().getCurrentPage());
		if(startRange==1){
			startRange=0;
		}
		int noOfRecords=getPageInfo().getNumOfRecords();
		
		//if((noOfRecords-startRange)<=50000){
			setItems(getDAO().searchByPages(
					getSearchCriteria(),(startRange), noOfRecords,sortField, sortAscending));	
		//}
		
		
		/*if((noOfRecords-startRange)<=50000){
		setItems(getDAO().searchByPages(
				getSearchCriteria(),(startRange), noOfRecords,sortField, sortAscending));
		rangeFlag=false;
		//setItems(getDAO().searchByPages(getSearchCriteria(),(getPageInfo().getCurrentPage() * getPageInfo().getNumOfRecords()), getPageInfo().getNumOfRecords(),sortField, sortAscending));
		}
		else{
		rangeFlag=true;
		}*/
		
	  
	}
	

	
	

}
