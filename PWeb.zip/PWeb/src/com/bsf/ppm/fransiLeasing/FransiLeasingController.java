package com.bsf.ppm.fransiLeasing;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.faces.application.FacesMessage;
import javax.faces.application.ViewHandler;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.apache.myfaces.custom.fileupload.UploadedFile;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.tomcat.util.http.fileupload.FileUpload;
import org.richfaces.component.html.HtmlDataTable;
import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.bsf.ipp.IPPUTIL;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.dao.GErrorListDAO;
import com.bsf.ppm.dao.InstructionDAO;
import com.bsf.ppm.dao.ParameterValueDAO;
import com.bsf.ppm.dao.PpmSflInstructionsDAO;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.formatting.format.impl.DateFormatter;
import com.bsf.ppm.fts.AccountInquiryRequest;
import com.bsf.ppm.fts.AccountInquiryResponse;
import com.bsf.ppm.service.posting.FTSPostingService;
import com.bsf.ppm.service.posting.FTSPostingServiceImpl;
import com.bsf.ppm.spring.SpringAppContext;
import com.bsf.ppm.util.DateUtils;

import com.bsf.ppm.Application;
import com.bsf.ppm.GErrorList;
import com.bsf.ppm.InstructionDetails;
import com.bsf.ppm.PpmSflInstructions;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.PpmSflInstructions;
import com.bsf.ppm.Ppm_Inst_Transactions;
import com.bsf.ppm.Ppm_Instructions;

public class FransiLeasingController extends AbstractCrudController<PpmSflInstructions, Long> {
	
	private static final Logger log = Logger.getLogger(FransiLeasingController.class);
	private PpmSflInstructions item;
	private List<PpmSflInstructions> items;
	private List<PpmSflInstructions> invaliditems;
	private int itemsSize;
	private int invalidItemSize;
	
	private boolean fileUploadFlag;
	private int numberofInst;
	private boolean senderCodeMissing=true;
	private UploadedFile uploadedFile;
	private String fname;
	private String errorMsg;
	private boolean fileTrnsTypeFlag=false;
	private String update="";
	
	private PpmSflInstructionsDAO ppmSflInstructionsDAO;
	private InstructionDAO instructionDAO;
	private List<ParameterValue> parameterValue = null;
	private ParameterValueDAO parameterValueDAO;
	private boolean fileValidationFlag=false;
	private FacesMessage facesMessage = null;
	private Date fromDate;
	private String senderCompCode ="";
	private String compCodeValidation="";
	private String msgTypeStr="";
	private String ppminstref="";
	private GErrorListDAO gErrorListDAO; 
	private NodeList senderCodeNodeList=null;
	private NodeList compCodeNodeList=null;
	private NodeList msgTypeNodeList=null;
	private FacesContext fctx=null;
	
	private Date toDate;
	
	public int getItemsSize() {
		if(getItems()!=null)
		return getItems().size();
		else 
			return 0;
	}
	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}
	
	
	public int getInvalidItemSize() {
		if(getInvaliditems()!=null)
		return getInvaliditems().size();
		else
		return 0;
		
	}
	public void setInvalidItemSize(int invalidItemSize) {
		this.invalidItemSize = invalidItemSize;
	}
	
		
	public int getNumberofInst() {
		return numberofInst;
	}
	public void setNumberofInst(int numberofInst) {
		this.numberofInst = numberofInst;
	}
	public UploadedFile getUploadedFile() {
		return uploadedFile;
	}
	public void setUploadedFile(UploadedFile uploadedFile) {
		this.uploadedFile = uploadedFile;
	}
	
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	
	
	
	
	public FransiLeasingController(){
		
		item = new PpmSflInstructions();
		//Initialize the default search Criteria
		//JSFUtil.getLoggedInUserInfo();
		System.out.println("User ID---"+JSFUtil.getLoggedInUserInfo().getUserId());
		this.getSearchCriteria().put(getStatusFieldName(), JSFUtil.getLoggedInUserInfo().getUserId());
	}
	
	public String getIdFieldName() {
		return "instReference";
	}

	/**
	 * Override this method if indent to use the disable() method and the status
	 * field is not default status (status)
	 * 
	 * @return
	 */
	public String getStatusFieldName() {
		return "createdBy";

	}
	public ParameterValueDAO getParameterValueDAO() {
		return parameterValueDAO;
	}
	public void setParameterValueDAO(ParameterValueDAO parameterValueDAO) {
		this.parameterValueDAO = parameterValueDAO;
	}
			
	public String getUpdate() {
		return update;
	}
	public void setUpdate(String update) {
		this.update = update;
	}
	public PpmSflInstructions getItem() {
		return item;
	}
	public void setItem(PpmSflInstructions item) {
		this.item = item;
	}
		
	public List<PpmSflInstructions> getInvaliditems() {
		
		return invaliditems;
	}
	public void setInvaliditems(List<PpmSflInstructions> invaliditems) {
		this.invaliditems = invaliditems;
	}
	
	public List<PpmSflInstructions> getItems() {

		if (items == null) {
			reloadItems();
		}

		return items;
	
	}
	
	public void setItems(List<PpmSflInstructions> items) {
		this.items = items;
		
	}
	
	public GErrorListDAO getgErrorListDAO() {
		return gErrorListDAO;
	}

	public void setgErrorListDAO(GErrorListDAO gErrorListDAO) {
		this.gErrorListDAO = gErrorListDAO;
	}

		
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getDAO()
	 */
	public PaginatedDAO<PpmSflInstructions, Long> getDAO() {
		return ppmSflInstructionsDAO;
	}
	

	public List<PpmSflInstructions> getSelectedItems() {
		List<PpmSflInstructions> selectedList = new ArrayList<PpmSflInstructions>();
		//Get the List of selected items from the dataTable
		for (PpmSflInstructions item : getItems()) {
			// Add item to the selectedList
			if (item.isSelected()) { 
				selectedList.add(item);
			}
		}
		return selectedList;
	}
			
	
	public PpmSflInstructionsDAO getPpmSflInstructionsDAO() {
		return ppmSflInstructionsDAO;
	}
	public void setPpmSflInstructionsDAO(PpmSflInstructionsDAO ppmSflInstructionsDAO) {
		this.ppmSflInstructionsDAO = ppmSflInstructionsDAO;
	}
		
	public InstructionDAO getInstructionDAO() {
		return instructionDAO;
	}
	public void setInstructionDAO(InstructionDAO instructionDAO) {
		this.instructionDAO = instructionDAO;
	}
	/**
	 * 
	 * @return HtmlDataTable representing backendSystem Table
	 */
	public HtmlDataTable getPpmSflInstructionsTable() {
		return (HtmlDataTable) JSFUtil.findComponentInRoot("PpmSflInstructionsTable");
	}
	
	
	public String listSetupUsingString() {
     System.out.println("listSetupUsingString");
		// Initialize default values for SearchCriteria and PageInfo
		setSearchCriteria(new HashMap<String, Object>());
		if (getSearchCriteria() != null)
			getSearchCriteria().put(getStatusFieldName(), JSFUtil.getLoggedInUserInfo().getUserId());
		if (getPageInfo() != null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		reloadItems();

		// returns the Navigation case for list page
		return getClass().getSimpleName() +IConstants.CRUD_LIST_NAVIGATION;
	}
	
	public String cancelCreateEInvoice() {
		String nav = "";
		listSetupUsingString();
		nav=getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
		return nav;
	}
	

	
	
	private void reloadPpmSflInstructions()
	{
		List<PpmSflInstructions> PpmSflInstructionsList = new ArrayList<PpmSflInstructions>();
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		String fromDateFormated = null;
		String toDateFormated = null;
		if (fromDate != null && toDate != null) {
			fromDateFormated = formatter.format(fromDate);
			toDateFormated = formatter.format(toDate);
		}
		System.out.println("--fromDateFormated="+fromDateFormated+" -- toDateFormated"+toDateFormated);
		reloadItemsDateRange("eInvoicesEmbedded.invoiceDate", fromDateFormated, toDateFormated);
		
		if (items !=null && items.size()>0) {
			
			for(PpmSflInstructions ppmSflInstructions: items) {

			
			}
		}
		
	}
	
	
	public String editSetup() {
		//Get the Item to be passed to Edit page
		item = (PpmSflInstructions) this.getPpmSflInstructionsTable().getRowData();

		return getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
	}
	
	
	public String createSetup() {
		// create a new instance of item
		item = new PpmSflInstructions();
		//Forward to create Navigation case
		return getClass().getSimpleName() + "_create";
	}
	
	public String uploadSetup() {

		return getClass().getSimpleName() + "_upload";
	}
	

	public String createInstructions() {
		invaliditems=null;
		String nav = "";
		String debitAccount="";
		String creditAccount="";
		String instReferenc="";
		Long instDtlId = null;
		Ppm_Instructions ppmInst=null;
		InstructionDetails instDetails=null;
		boolean addFlag=false;
		String maxDayRang = "";
		String trgrNexCycleDay = "";
		try {
			
			
			Map map=new HashMap();
			map.put(getStatusFieldName(), JSFUtil.getLoggedInUserInfo().getUserId());
			
			Map mapInst=new HashMap();
			mapInst.put("status", "ACT");
			
			List<Ppm_Instructions> ppmInstructionsList=getInstructionDAO().findByCriteria(mapInst);
			
			int count=0;
			List<PpmSflInstructions> ppmSflInstructionsList=getPpmSflInstructionsDAO().findByCriteria(map);
			
			List<String> debitAccountList=null;
			
			if(ppmInstructionsList!=null)	
			debitAccountList=new ArrayList<String>();	
			for(Ppm_Instructions ppmInstruction:ppmInstructionsList){
			debitAccountList.add(ppmInstruction.getAccNumber())	;
			debitAccountList.add(ppmInstruction.getStatus());
			}	
				
			
				
			for(PpmSflInstructions ppmSflInstructions:ppmSflInstructionsList)	{
			
				if((debitAccountList.contains(ppmSflInstructions.getDebitAccount().trim()))&&(debitAccountList.get(1).contains("ACT"))){
					System.out.println("ppmInstructions=="+ppmSflInstructions.getDebitAccount());
					String debitAcct=ppmSflInstructions.getDebitAccount();
					facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
							"bundles.UIMessages", "entity.exe.fail", 
							 debitAcct);
					FacesContext.getCurrentInstance()
					.addMessage("successAdd", facesMessage);
					
					nav=getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
				}
				
				else{
					
					//
					
					//Max day rang from Database
					parameterValue=getParameterValueDAO().getMaxDayRangAndTrgrNextCyclDay("EXEPERIOD");
					if (parameterValue != null&&parameterValue.size()>0) {
					maxDayRang=parameterValue.get(0).getValue1();	
					}
					else{
					maxDayRang="10";	
					}
					//Trigger next cycle day from Database
					parameterValue=getParameterValueDAO().getMaxDayRangAndTrgrNextCyclDay("EXECYCLE");
					if (parameterValue != null&&parameterValue.size()>0) {
					trgrNexCycleDay=parameterValue.get(0).getValue1();	
					}
					else{
					trgrNexCycleDay="20";	
					}
					///
					addFlag=true;
					debitAccount=ppmSflInstructions.getDebitAccount();
					creditAccount=ppmSflInstructions.getCreditAccount();
					instReferenc=ppmSflInstructions.getInstReference();
					ppmInst=new Ppm_Instructions();
					instDetails=new InstructionDetails();
					ppmInst.setInstReference(instReferenc);
					ppmInst.setInstgroupcode("SPP");
					ppmInst.setClandertype("G");
					ppmInst.setInstProrty(8);
					ppmInst.setDayofPayment(0);
					ppmInst.setAccNumber(debitAccount);
					ppmInst.setInstActionType("CPTR");
					ppmInst.setStatus("ACT");
					ppmInst.setStartDateG(ppmSflInstructions.getInstStartDate());
					ppmInst.setEndDateG(ppmSflInstructions.getInstEndDate());
					ppmInst.setNoOfInst(ppmSflInstructions.getNoOfInst()); 
					ppmInst.setMaxDayRange(maxDayRang);
					ppmInst.setTrgrNextCycleDay(trgrNexCycleDay);
					ppmInst.setExeType("EVENT_TRIGGER");
					ppmInst.setAcctcurcode("SAR");
					ppmInst.setNoofBen(1);
					ppmInst.setFrequency("M");
					ppmInst.setInstBranch("004");
					ppmInst.setTotalAmount(ppmSflInstructions.getInstTotalAmount());
					ppmInst.setMonthlyAmoun(new BigDecimal(ppmSflInstructions.getInstAmount()));
					ppmInst.setEventTriggerOn("EVENTPAY");
					
					
					ppmInst.setCreatedBy(JSFUtil.getLoggedInUserInfo().getUserId());
					ppmInst.setCreatedDate(new Timestamp(System.currentTimeMillis()));
					
					//instDetails
					instDetails.setInstReference(instReferenc);
					instDtlId = getInstructionDAO().getInstDetaiSeqGen();
					instDetails.setInstDtlId(instDtlId.toString());
					instDetails.setInstTrnsTyp("NT");
					instDetails.setInstAccNum(debitAccount);
					instDetails.setBenAcc(creditAccount);
					
					instDetails.setInstAccCrncy("SAR");
					instDetails.setBenAccCrncy("SAR");
					
					ppmInst.setInstdetails(instDetails);
					
					System.out.println("debitAccount---"+debitAccount);
					getInstructionDAO().save(ppmInst);
					getPpmSflInstructionsDAO().delete(ppmSflInstructions);	
					
					
				}
				
						
			}
			
			if(addFlag){
				invaliditems=null;
				facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
						"bundles.UIMessages", "entity.add.success", getEntityName(),
						getItem());
				FacesContext.getCurrentInstance()
				.addMessage("successAdd", facesMessage);
				
				nav=getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
				}

			
		} catch (Exception e) {
			e.printStackTrace();

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.add.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem(),IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);
		
			// Return Navigation case of the create page
			return "";
		}
		
		listSetupUsingString();
		
		
		return nav;
	}
	
	
		


	
	
	
	
	
	public boolean isUnique() {
		boolean isUnique = false;
		try {
			//Check if the item is Unique in the Table
			isUnique = getDAO().isUnique(getItem());
		} catch (DAOException e) {
			
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.BusinessErrorMessages",
					"entity.callIsUnique", getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			//Print StackTrace
			e.printStackTrace();

		}
		return isUnique;
	}

	public String[] getIDsArray(List<PpmSflInstructions> items) {
		// return null if List is null or empty
		if (items == null || items.size() == 0) {
			return null;
		}
		// Build the array of the ids
		String[] ids = new String[items.size()];
		//add the ids of the items to the array
		int i = 0;
		for (PpmSflInstructions entity : items) {
			ids[i] = entity.getPk();
			i++;
		}
		return ids;
	}

	

	public String getEntityName() {
		return "PpmSflInstructions";
	}
	
	
	private void reloadPpmSflInstructionsForExport() throws DAOException
	{
		setItems(getDAO().searchByPages(
				getSearchCriteria(),
				(getPageInfo().getCurrentPage() * getPageInfo().getNumOfRecords()), getPageInfo().getNumOfRecords(),sortField, sortAscending));

	}
	

		
	
	
	@Override
	public String detailSetup() {
		// TODO Auto-generated method stub
		return null;
	}
public String update() {
	setSearchCriteria(new HashMap<String, Object>());
	if (getSearchCriteria() != null)
		getSearchCriteria().put(getStatusFieldName(), JSFUtil.getLoggedInUserInfo().getUserId());
	if (getPageInfo() != null)
		getPageInfo().setCurrentPage(0);
	// Load the items in the list
	reloadItems();
	return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
		

	}
    
/*
 * (non-Javadoc)
 * 
 * @see com.bsf.ppm.controller.CRUDController#disableItems()
 */
public String deleteItems() {
	invaliditems=null;
	FacesMessage facesMessage = null;
	if (getSelectedItems() == null || getSelectedItems().size() < 1) {
		facesMessage = JSFUtil.getMessage(
				FacesContext.getCurrentInstance(), "bundles.UIMessages",
				"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
				getEntityName());
		FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
		return "";
	}
	// Fetch the items to be deleted.
	String[] idArrays = getIDsArray(getSelectedItems());
	System.out.println("=====AbstractCrudController. disableItems ");
	if (idArrays != null && idArrays.length > 0) {
		try {
			// Delete the items from the Database Table
			// getStatusFieldName should be implemented in subclass
			getPpmSflInstructionsDAO().deleteByIds(idArrays);
			/*getDAO().updateEntityStatusByIds(
					idArrays,
					getIdFieldName(),
					getStatusFieldName(),
					Long.valueOf(IConstants.STATUS_TYPE.INACTIVE
							.ordinal()),
							JSFUtil.getLoggedInUserInfo());*/
			
		} catch (DAOException e) {
			e.printStackTrace();
			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"entity.deActivateItems.error",
					FacesMessage.SEVERITY_ERROR, getEntityName());
			FacesContext.getCurrentInstance().addMessage(
					"deActivateItemsError", facesMessage);
			return "";
		} catch (Exception e) {
			facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"controller.generalException",
					FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
					.buildExceptionMessage(e));
			FacesContext.getCurrentInstance()
			.addMessage(null, facesMessage);
			return "";

		}
	}
	getPageInfo().setCurrentPage(0);
	// Reload the items in the list
	this.getSearchCriteria().put(getStatusFieldName(), JSFUtil.getLoggedInUserInfo().getUserId());
	reloadItems();
	facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
			"bundles.UIMessages", "entity.deleteItem.success",
			idArrays.length, getEntityName());
	FacesContext.getCurrentInstance().addMessage("successDeleteItems",
			facesMessage);

	// return the Navigation case for list page
	return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
}

	 public String uploadFile(UploadEvent event) throws Exception{
	// FileInputStream fileIs	=null; 
	   InputStream fileIs = null;	 
	 invaliditems=new ArrayList<PpmSflInstructions>();
		  try{
	
		 UploadItem fileItem=event.getUploadItem();
		 
		 byte bData[]=fileItem.getData();
		
		        int rowNumber=1;
		        List<List<XSSFCell>> sheetData = new ArrayList();
			    List<String> list=new ArrayList<String>();
			    //fileIs = new FileInputStream(file);
			    fileIs = new ByteArrayInputStream(bData);
		        XSSFWorkbook workbook = new XSSFWorkbook(fileIs);
		        XSSFSheet sheet = workbook.getSheetAt(0);
		        Iterator<Row> rowIterator = sheet.iterator();
		       //Skip the Header Row 
		        rowIterator.next();
		        
		        if(sheet.getLastRowNum()<=1){
		           	FacesContext
					.getCurrentInstance()
					.addMessage("upload",new FacesMessage("Excel File is blank "));	
		        }
		      
		        while(rowIterator.hasNext())
		        {
		            Row row = rowIterator.next();
		            System.out.println("Row Number ="+row.getRowNum());
		            
		           
		            
		            
		            //For each row, iterate through each columns
		            Iterator<Cell> cellIterator = row.cellIterator();
                 
		                if (row.getCell(0) != null && row.getCell(0).getCellType() != Cell.CELL_TYPE_BLANK)
		                {
		                      String  debitAccount=(new DataFormatter().formatCellValue(row.getCell(0)));
		     		          String  creditAccount=(new DataFormatter().formatCellValue(row.getCell(1)));
		     		          String  instStartDate=(new DataFormatter().formatCellValue(row.getCell(2)));
		     		          String  instEndDate=(new DataFormatter().formatCellValue(row.getCell(3)));
		     		          String  instAmount=(new DataFormatter().formatCellValue(row.getCell(4)));
		     		          String  dayOfPayment="0";
		     		
		     		          System.out.println("instStartDate=="+instStartDate);
		     		          System.out.println("instEndDate==="+instEndDate);
		     		          
		     		           Date  isntStartDateFormat=new Date(instStartDate);
		     		           Date  instEndDateFormat=new Date(instEndDate); 
		     		    
		     		     boolean debitFlag= debitAccountValidation(debitAccount,row);
		     		     boolean saveFlag=false;
		     		     //boolean creditFlag=getcustCreditAccountStatus(creditAccount,row);
		     		     
		     		     if(!debitFlag){
		     		     //if(!getcustAccountDetails(debitAccount,row)||!getcustCreditAccountStatus(creditAccount,row)){
		     		        saveFlag	=false; 
			     		       boolean startDateFlag= startDateValidation(isntStartDateFormat,instEndDateFormat,row);
			     		       boolean endDateFlag= endDateValidation(isntStartDateFormat,instEndDateFormat,row);
			     		       if((!startDateFlag)&&(!endDateFlag)){
			     		       int noOfDays=getNumberOfDayCalcu(isntStartDateFormat,instEndDateFormat);
			     		       int instToalAmount=0;
			     		       int instAmoInt=0;
			     		       if(instAmount!=null&&!instAmount.equals("")){
			     		       instAmoInt=Integer.valueOf(instAmount);
			     		       System.out.println("instAmoInt--"+instAmoInt);
			     		       instToalAmount=(noOfDays*instAmoInt);
			     		       }
			     		      
			     		       
			     		        if((!getcustAccountDetails(debitAccount,row)&&getcustCreditAccountStatus(creditAccount,row))&&!(startDateFlag)&&!(endDateFlag))
			     		        saveData(debitAccount,creditAccount,dayOfPayment,isntStartDateFormat,instEndDateFormat,noOfDays,new BigDecimal(instToalAmount),instAmoInt);	 
			     		      
			             }
		     	         }
		     		    
		        }
		        }
		    } catch (FileNotFoundException e) {
		        e.printStackTrace();
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		  catch(Exception dax){
		  throw new Exception("Data parsing exception wrong data in excel file "+dax.getMessage());
			//  dax.printStackTrace();
		  }
		  finally{
		  try{	
		  if(fileIs!=null)	  
		  fileIs.close(); 
		  }
		  catch(Exception io){
		  io.printStackTrace();
		  }
		  }
     return getClass().getSimpleName() +IConstants.CRUD_LIST_NAVIGATION;
	 }
	 
		 
	 public boolean startDateValidation(Date instStartDate,Date instEndDate,Row row){
		 PpmSflInstructions ppmSflInstructions=new PpmSflInstructions();
         String errorValue="";
                
         if(getStartDateCalculation(instStartDate, instEndDate)){
        	 ppmSflInstructions.setRowNumber(row.getRowNum());
    		 ppmSflInstructions.setColumnName("Start Date");
    		 ppmSflInstructions.setColumnValue(instStartDate.toString());
             ppmSflInstructions.setErrorValue("Start Date should not be before current date");
             invaliditems.add(ppmSflInstructions);	
             return true;
         }
         return false;        
    	 
	 }
	 
	 public boolean endDateValidation(Date instStartDate,Date instEndDate,Row row){
		 PpmSflInstructions ppmSflInstructions=new PpmSflInstructions();
         String errorValue="";
                
         if(getEndDateCalculation(instStartDate, instEndDate)){
        	 ppmSflInstructions.setRowNumber(row.getRowNum());
    		 ppmSflInstructions.setColumnName("End Date");
    		 ppmSflInstructions.setColumnValue(instStartDate.toString());
             ppmSflInstructions.setErrorValue("End Date Should not be before Start date");
             invaliditems.add(ppmSflInstructions);	
             return true;
         }
         return false;
                 
    	 
	 }
	 
	 public boolean debitAccountValidation(String debitAccount,Row row){
		 PpmSflInstructions ppmSflInstructions=new PpmSflInstructions();
         String errorValue="";
         if(debitAccount.length()<11){
         ppmSflInstructions.setRowNumber(row.getRowNum());
		 ppmSflInstructions.setColumnName("Debit Account");
		 ppmSflInstructions.setColumnValue(debitAccount);
         ppmSflInstructions.setErrorValue("Debit Account is Invalid");
         invaliditems.add(ppmSflInstructions);
         return true;
         }
         return false;
          	 
	 }
	 
	 public void saveData(String debitAccount,String creditAccount,String dayOfPayment,Date instStartDate,Date instEndDate,int noOfDays,BigDecimal instToatlAmount,int instAmount)throws DAOException{
		  PpmSflInstructions ppmSflInstructions=new PpmSflInstructions();
		  try{
		  ppminstref = getInstructionDAO().getSFLReference();
          ppmSflInstructions.setInstReference(ppminstref);
          ppmSflInstructions.setDebitAccount(debitAccount);
          ppmSflInstructions.setCreditAccount(creditAccount);
          ppmSflInstructions.setDayOfPayment(Integer.parseInt(dayOfPayment));
          ppmSflInstructions.setInstStartDate(instStartDate);
          ppmSflInstructions.setInstEndDate(instEndDate);
          ppmSflInstructions.setNoOfInst(noOfDays); 
          ppmSflInstructions.setInstAmount(instAmount);
          ppmSflInstructions.setInstTotalAmount(instToatlAmount);
          ppmSflInstructions.setCreatedBy(JSFUtil.getLoggedInUserInfo().getUserId());
          ppmSflInstructions.setCreatedDate(new Timestamp(System.currentTimeMillis()));
          
          getPpmSflInstructionsDAO().save(ppmSflInstructions);  
          }
          catch(DAOException dx){
        	  dx.printStackTrace();
          }
		 
	 }
	 
	 public boolean getStartDateCalculation(Date firstDate,Date lastDate){
		    Date currentDate = new Date();
		    boolean flag=false;
			try {

				Calendar cal = Calendar.getInstance();
				cal.setTime(currentDate);

				// Set time fields to zero
				cal.set(Calendar.HOUR_OF_DAY, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				cal.set(Calendar.MILLISECOND, 0);
				// Put it back in the Date object
				currentDate = cal.getTime();
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("firstDate" + firstDate);
			System.out.println("lastDate" + lastDate);
           
			System.out.println("currentDate" + currentDate);
			
			if (firstDate.before(currentDate)) {
					FacesContext
							.getCurrentInstance()
							.addMessage(
									null,
									new FacesMessage("Start Date Should not be before current date"));
			flag=true;					
			return flag;
		
			}
		
		
       return flag;
	 }
	 
	 
	 public int getNumberOfDayCalcu(Date firstDate,Date lastDate){
		    Date currentDate = new Date();
		    boolean flag=false;
			try {

				Calendar cal = Calendar.getInstance();
				cal.setTime(currentDate);

				// Set time fields to zero
				cal.set(Calendar.HOUR_OF_DAY, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				cal.set(Calendar.MILLISECOND, 0);
				// Put it back in the Date object
				currentDate = cal.getTime();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
						
			Long noOfDays = lastDate.getTime() - firstDate.getTime();
			Long days = TimeUnit.DAYS.convert(noOfDays, TimeUnit.MILLISECONDS);
			System.out.println("Fisrt Installment Date:="
					+ TimeUnit.DAYS.convert(noOfDays, TimeUnit.MILLISECONDS));
			Integer noInst = 0;
			
			noInst = (days.intValue() / 30);
			

			//Long noofinst = noInst.longValue();
			System.out.println("numberofInst==" + noInst);
			if (noInst >= 1) {
				setNumberofInst(noInst);
			}
			if (noInst == 0) {
				setNumberofInst(0);
			}
			
			
    return getNumberofInst();
	 }
	 
	 
	 public boolean getEndDateCalculation(Date firstDate,Date lastDate){
		    Date currentDate = new Date();
		    boolean flag=false;
			try {

				Calendar cal = Calendar.getInstance();
				cal.setTime(currentDate);

				// Set time fields to zero
				cal.set(Calendar.HOUR_OF_DAY, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				cal.set(Calendar.MILLISECOND, 0);
				// Put it back in the Date object
				currentDate = cal.getTime();
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("firstDate" + firstDate);
			System.out.println("lastDate" + lastDate);
        
			System.out.println("currentDate" + currentDate);
			
			if (lastDate.before(firstDate)) {
				FacesContext
				.getCurrentInstance()
				.addMessage(
						null,
						new FacesMessage("End Date Should not be before Start date"));
								
			flag=true;					
			return flag;
			}
	    return flag;
	 }
	
		/* Debit Account inquiry Tuxedo service */
		public boolean getcustAccountDetails(String debitAccount,Row row) {
			log.info("Entering in getcustAccountDetails method");
			AccountInquiryResponse accountInqRes = null;
			String acctTypeFromDB = "";
			boolean customerAcctFlag = false;
			refresh();
			
			String accountNo = debitAccount.toUpperCase();

			log.info("Customer accountNo" + debitAccount);
			try {
				if (accountNo.length() == 11) {
					log.info("Success...");
				String	customerName = "";
				String	actstatus = "";
				String	accountstatusdesc = "";
				String	profitCenter = "";
					FTSPostingService FTSPS = new FTSPostingServiceImpl();
					AccountInquiryRequest accountInquiryRequest = new AccountInquiryRequest();
					accountInquiryRequest = AccountInquiryRequest.getInstance();
					accountInquiryRequest.setAccountNo(accountNo);
					accountInqRes = FTSPS.sendAccountInquiry(accountInquiryRequest,"BDS");
					
					if(accountInqRes==null){
					 log.info("Tring to call Tuxedo getting network eroor ="+accountInqRes);	
					 PpmSflInstructions ppmSflInstructions=new PpmSflInstructions();
	     	         ppmSflInstructions.setRowNumber(row.getRowNum());
	     			 ppmSflInstructions.setColumnName("Tuxedo Error");
	     			 ppmSflInstructions.setColumnValue(debitAccount);
	     	         ppmSflInstructions.setErrorValue("Tuxedo Problem ");
	     	         invaliditems.add(ppmSflInstructions);	
					}
					String ftsActionCode = accountInqRes.getFtsActionCode();
					if (ftsActionCode.equals("0000")) {
					
						profitCenter = accountInqRes.getProfitCenter();
						customerName = accountInqRes.getCustFullName();
						actstatus = accountInqRes.getAcctStatusCode();
						accountstatusdesc = accountInqRes.getAcctStatusDesc();

						customerAcctFlag = false;
						
					 if (actstatus!=null&&!actstatus.trim().equals("OP")) {
						     customerAcctFlag=true;
							 PpmSflInstructions ppmSflInstructions=new PpmSflInstructions();
			     	         ppmSflInstructions.setRowNumber(row.getRowNum());
			     			 ppmSflInstructions.setColumnName("Debit Account");
			     			 ppmSflInstructions.setColumnValue(debitAccount);
			     	         ppmSflInstructions.setErrorValue("Debit Account status="+accountstatusdesc);
			     	         invaliditems.add(ppmSflInstructions);
						}
						 

					} else {
						
						Map<String, Object> map = new HashMap<String, Object>();
						map.put("errorCode", ftsActionCode);
						GErrorList gErrorList = getgErrorListDAO().getByCriteria(
								map);
						
						 accountstatusdesc = accountInqRes.getAcctStatusDesc();
						 customerAcctFlag = true;
						 PpmSflInstructions ppmSflInstructions=new PpmSflInstructions();
		     	         ppmSflInstructions.setRowNumber(row.getRowNum());
		     			 ppmSflInstructions.setColumnName("Debit Account");
		     			 ppmSflInstructions.setColumnValue(debitAccount);
		     	         ppmSflInstructions.setErrorValue(gErrorList.getErrorMsg());
		     	         invaliditems.add(ppmSflInstructions);
						
					}
				}
				else{
					 PpmSflInstructions ppmSflInstructions=new PpmSflInstructions();
	     	         ppmSflInstructions.setRowNumber(row.getRowNum());
	     			 ppmSflInstructions.setColumnName("Debit Account");
	     			 ppmSflInstructions.setColumnValue(debitAccount);
	     	         ppmSflInstructions.setErrorValue("Account Number should be 11 digits ");
	     	         invaliditems.add(ppmSflInstructions);	
				}
				
			} catch (ApplicationException ae) {
				ae.printStackTrace();
			}
			return customerAcctFlag;
		}
		
		
		// Tuxedo inquiry before posting to Tuxedo to check the Account Status and
		// balance;
		public boolean getcustCreditAccountStatus(
				String creditAccount,Row row)
				throws ApplicationException {
			AccountInquiryResponse accountInqRes = null;
			String accountNo = null;
			String	accountstatusdesc = "";
			boolean acctStatusFlag = false;
			if (creditAccount != null)
				accountNo = creditAccount.toUpperCase();

			try {

				FTSPostingService FTSPS = new FTSPostingServiceImpl();
				AccountInquiryRequest accountInquiryRequest = new AccountInquiryRequest();
				accountInquiryRequest = AccountInquiryRequest.getInstance();
				//if(inqType.equals("CMPINQ01"))
				accountInquiryRequest.setRequestFunction("CMPINQ01");	
				accountInquiryRequest.setAccountNo(accountNo);
				accountInqRes = FTSPS.sendAccountInquiry(accountInquiryRequest,
						"SPP");

				if (accountInqRes != null) {
					String ftsActionCode = accountInqRes.getFtsActionCode();
					String cammActionCode = accountInqRes.getCammActionCode();
					String actStatusTux = accountInqRes.getAcctStatusCode();

					if (ftsActionCode.equals("0000")
							&& cammActionCode.equals("0000")) {

						if ("OP".equalsIgnoreCase(actStatusTux.trim())){
							 acctStatusFlag =true;
							 

						} else {
							 PpmSflInstructions ppmSflInstructions=new PpmSflInstructions();
			     	         ppmSflInstructions.setRowNumber(row.getRowNum());
			     			 ppmSflInstructions.setColumnName("Credit Account");
			     			 ppmSflInstructions.setColumnValue(creditAccount);
			     	         ppmSflInstructions.setErrorValue("Credit Account status="+actStatusTux);
			     	         invaliditems.add(ppmSflInstructions); 
							 acctStatusFlag = false;
							log.info("(getcustCreditAccountStatus)===> CAMM Action code ="
									+ acctStatusFlag);
						}

					} else {
						acctStatusFlag = false;
						Map<String, Object> map = new HashMap<String, Object>();
						map.put("errorCode", ftsActionCode);
						GErrorList gErrorList = getgErrorListDAO().getByCriteria(
								map);
						
						 accountstatusdesc = accountInqRes.getAcctStatusDesc();
						 acctStatusFlag = false;
						 PpmSflInstructions ppmSflInstructions=new PpmSflInstructions();
		     	         ppmSflInstructions.setRowNumber(row.getRowNum());
		     	         ppmSflInstructions.setColumnName("Credit Account");
		     			 ppmSflInstructions.setColumnValue(creditAccount);
		     	         ppmSflInstructions.setErrorValue(gErrorList.getErrorMsg());
		     	         invaliditems.add(ppmSflInstructions);
					}

				} else {
					PpmSflInstructions ppmSflInstructions=new PpmSflInstructions();
	     	         ppmSflInstructions.setRowNumber(row.getRowNum());
	     			 ppmSflInstructions.setColumnName("Credit Account");
	     			 ppmSflInstructions.setColumnValue(creditAccount);
	     	         ppmSflInstructions.setErrorValue("Tuxedo Error at the time of Inquiry");
	     	         invaliditems.add(ppmSflInstructions);
					acctStatusFlag = false;
					log.info("(getcustCreditAccountStatus)===> Account Inquiry failed");
				}

			} catch (ApplicationException ae) {

				log.error(
						"(getcustCreditAccountStatus)===> Error occured while checking Credit account status. Error= "
								+ ae.getMessage(), ae);
				throw ae;
			}

			return acctStatusFlag;
		}
		
		
		public void refresh() {
		    FacesContext context = FacesContext.getCurrentInstance();
		    javax.faces.application.Application application = context.getApplication();
		    ViewHandler viewHandler = application.getViewHandler();
		    UIViewRoot viewRoot = viewHandler.createView(context, context.getViewRoot().getViewId());
		    context.setViewRoot(viewRoot);
		  }

}
