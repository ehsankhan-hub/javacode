package com.bsf.ppm.paymentqueues;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.application.ViewHandler;
import javax.faces.component.EditableValueHolder;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import org.richfaces.model.UploadItem;
import org.richfaces.event.UploadEvent;
import org.apache.log4j.Logger;
import org.apache.myfaces.custom.fileupload.UploadedFile;
import org.richfaces.component.html.HtmlDataTable;
import org.richfaces.component.html.HtmlPanel;
import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.DomesticBank;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.GErrorListDAO;
import com.bsf.ppm.dao.InstructionDAO;
import com.bsf.ppm.dao.InstructionDetailDAO;
import com.bsf.ppm.dao.InstructionModifyDAO;
import com.bsf.ppm.dao.ParameterValueDAO;
import com.bsf.ppm.dao.StatusHistoryDAO;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.fts.AccountInquiryRequest;
import com.bsf.ppm.fts.AccountInquiryResponse;
import com.bsf.ppm.GErrorList;
import com.bsf.ppm.InstructionDetails;
import com.bsf.ppm.InstructionListValues;
import com.bsf.ppm.InstructionsModify;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.Ppm_Instructions;
import com.bsf.ppm.StatusHistory;
import com.bsf.ppm.service.posting.FTSPostingService;
import com.bsf.ppm.service.posting.FTSPostingServiceImpl;
import com.bsf.ppm.util.DateUtils;
import com.sun.faces.util.MessageFactory;

public class PaymentsQueueController extends
		AbstractCrudController<Ppm_Instructions, String> {

	protected static Logger log = Logger.getLogger("com.bsf.ppm.controller");
	/** Attribute instructionDAO */
	private InstructionDAO instructionDAO;

	private InstructionDetailDAO instDtlDAO;
	/** Attribute applicationManagement */

	private ParameterValueDAO parameterVDAO;

	private StatusHistoryDAO statusHistoryDAO;

	private InstructionModifyDAO instModifyDAO;

	private GErrorListDAO gErrorListDAO;

	private InstructionsModify instModfy = new InstructionsModify();

	private AccountInquiryResponse accountInqRes = null;

	private AccountInquiryResponse benaccountInqRes;

	private UserInfo user;

	ArrayList<SelectItem> list;

	/** Attribute items. List of Application entities */
	private String accountNo = "";

	private Long instReferenc;

	private File file = null;

	/** Decide the customer type on the basis of panel */
	private String panelId;
	/**
	 * <p>
	 * Attribute selectedBeneficiaryBankType used in Create Instruction. Holds
	 * the Bank Name selected by the user and set to the Instruction.
	 * </p>
	 */
	private String selectedBankName;

	private String instStatus;

	private String customerName;

	private String iDType = "";

	private String custIdNumber = "";

	private String debitAcctType = "";

	private String creditAcctType = "";

	private String productType = "";

	private String custProfitCenter = "";

	private String iDExpiryDate = "";

	private String btnType;

	private String actstatus;

	private String actStatusTux;

	private String accountstatusdesc;

	private String profitCenter;

	private String samaReference;

	private String modifyRefe;

	private Ppm_Instructions item;

	private InstructionListValues itemItemDtl;

	private InstructionDetails itemDetail;

	private List<StatusHistory> statusHis;

	private Date firstInstDate;

	private Date lastInstDate;

	private String frequencey;

	private String selectCalendarTypRadio = "G";

	private Date docDateH;

	private Date docReceivingDateH;

	private String docDateHStrFrmt = "";
	private String docReceivingDateHStrFrmt = "";

	private String docDateHStr;

	private String docReceivingDateHStr;

	private Long noofinst;

	private Long numberofInst;

	private boolean accDetails;

	boolean acctype = false;

	boolean bsfradioButton = true;

	boolean nobbsfradioButton = false;

	boolean selectoneRadioValue = true;

	private String beneficiaryacc;

	private String beneficiaryname;

	private String nonBsfbeneficiaryacc;

	private String nonBsfbeneficiaryname = "";

	private String beneficiaryaddress;

	private String beneficiaryBankaddress;

	private String beneficiaryPaymentDtls;

	private String beneficiaryprofitcent;

	private String beneficiaryactstuts;

	private String beneficiaryactstutsTux;

	private boolean radionButtonValue;

	private String selectedTab = "";

	private BigDecimal monthlyAmount;

	private BigDecimal totalAmount = null;

	private Integer dayofPayment;

	private String radioButtonCalendarG;

	private String status = "";

	private String instReferencqueue;

	private String accountCpt;
	/* Transtion Report variable start */
	private String debitAccount;

	private String sourceSystem;

	private String transType;

	private String acctTypeFromDB = "";

	private String maxDayRang = "";

	private String trgrNexCycleDay = "";

	boolean flagStatus = false;

	private List<ParameterValue> parameterValue = null;

	private String creditAccount;

	private boolean nonBsfBenefAcctFlag = false;

	private boolean customerAcctFlag = false;

	private boolean bsfBeneFiciAcctFlag = false;

	private boolean debitActDBFlag = false;

	private boolean creditActDBFlag = false;

	Date currentDate = new Date();

	private String validatorComment;

	private String initComment;

	private String changeBy = "";
	private String statusfromItst = "";

	/* Search Results of Instruction screen */
	private int itemSize = 0;
	/* Search Results of maintenance screen */
	private int itemSizeMain = 0;
	/* Search Results of Inquiry screen */
	private int itemSizeInq = 0;
	/* Search Results of Maintain Validate screen */
	private int itemSizeMVali = 0;
	private FacesMessage facesMessage = null;

	private String fname;
	private String errorMsg;
	private UploadedFile uploadedFile;
	private List<InstructionListValues> instResults;

	private List<InstructionListValues> instInquryResults = new ArrayList<InstructionListValues>();

	private List<InstructionListValues> listMaintenence;

	private List<InstructionListValues> listMaintVali;

	List<StatusHistory> statusHistory = null;

	public String getInstReferencqueue() {
		return instReferencqueue;
	}

	public void setInstReferencqueue(String instReferencqueue) {
		this.instReferencqueue = instReferencqueue;
	}

	public String getDebitAccount() {
		return debitAccount;
	}

	public void setDebitAccount(String debitAccount) {
		this.debitAccount = debitAccount;
	}

	public String getCreditAccount() {
		return creditAccount;
	}

	public void setCreditAccount(String creditAccount) {
		this.creditAccount = creditAccount;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getFirstInstDate() {
		return firstInstDate;
	}

	public void setFirstInstDate(Date firstInstDate) {
		this.firstInstDate = firstInstDate;
	}

	public Date getLastInstDate() {
		return lastInstDate;
	}

	public void setLastInstDate(Date lastInstDate) {
		this.lastInstDate = lastInstDate;
	}

	public UserInfo getUser() {
		return user;
	}

	public void setUser(UserInfo user) {
		this.user = user;
	}

	public Ppm_Instructions getItem() {
		return item;
	}

	public void setItem(Ppm_Instructions item) {
		this.item = item;
	}

	public InstructionListValues getItemItemDtl() {
		return itemItemDtl;
	}

	public void setItemItemDtl(InstructionListValues itemItemDtl) {
		this.itemItemDtl = itemItemDtl;
	}

	public StatusHistoryDAO getStatusHistoryDAO() {
		return statusHistoryDAO;
	}

	public void setStatusHistoryDAO(StatusHistoryDAO statusHistoryDAO) {
		this.statusHistoryDAO = statusHistoryDAO;
	}

	public GErrorListDAO getgErrorListDAO() {
		return gErrorListDAO;
	}

	public void setgErrorListDAO(GErrorListDAO gErrorListDAO) {
		this.gErrorListDAO = gErrorListDAO;
	}

	public InstructionsModify getInstModfy() {
		return instModfy;
	}

	public void setInstModfy(InstructionsModify instModfy) {
		this.instModfy = instModfy;
	}

	public InstructionModifyDAO getInstModifyDAO() {
		return instModifyDAO;
	}

	public void setInstModifyDAO(InstructionModifyDAO instModifyDAO) {
		this.instModifyDAO = instModifyDAO;
	}

	public List<InstructionListValues> getInstInquryResults() {
		return instInquryResults;
	}

	public void setInstInquryResults(
			List<InstructionListValues> instInquryResults) {
		this.instInquryResults = instInquryResults;
	}

	/** Attribute items for the list of PaymentInstructions items */
	private List<Ppm_Instructions> items;

	public List<StatusHistory> getStatusHistory() {
		return statusHistory;
	}

	public void setStatusHistory(List<StatusHistory> statusHistory) {
		this.statusHistory = statusHistory;
	}

	public void setInstResults(List<InstructionListValues> instResults) {
		this.instResults = instResults;
	}

	public JRDataSource getDataSource() {
		return new JRBeanCollectionDataSource(instInquryResults);
	}

	public List<InstructionListValues> getListMaintenence() {
		return listMaintenence;
	}

	public void setListMaintenence(List<InstructionListValues> listMaintenence) {
		this.listMaintenence = listMaintenence;
	}

	public List<InstructionListValues> getListMaintVali() {
		return listMaintVali;
	}

	public void setListMaintVali(List<InstructionListValues> listMaintVali) {
		this.listMaintVali = listMaintVali;
	}

	public int getItemSize() {
		return itemSize;
	}

	public void setItemSize(int itemSize) {
		this.itemSize = itemSize;
	}

	public int getItemSizeMain() {
		return itemSizeMain;
	}

	public void setItemSizeMain(int itemSizeMain) {
		this.itemSizeMain = itemSizeMain;
	}

	public int getItemSizeInq() {
		return itemSizeInq;
	}

	public void setItemSizeInq(int itemSizeInq) {
		this.itemSizeInq = itemSizeInq;
	}

	public int getItemSizeMVali() {
		return itemSizeMVali;
	}

	public void setItemSizeMVali(int itemSizeMVali) {
		this.itemSizeMVali = itemSizeMVali;
	}

	public Long getNoofinst() {
		return noofinst;
	}

	public String getValidatorComment() {
		return validatorComment;
	}

	public void setValidatorComment(String validatorComment) {
		this.validatorComment = validatorComment;
	}

	public String getInitComment() {
		return initComment;
	}

	public void setInitComment(String initComment) {
		this.initComment = initComment;
	}

	public void setNoofinst(Long noofinst) {
		this.noofinst = noofinst;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public List<InstructionListValues> getInstResults() {
		try {

			instResults = (List<InstructionListValues>) getInstructionDAO()
					.getAllInstruction(instReferencqueue, samaReference);
			itemSize = instResults.size();
			System.out.println("itemSize===" + itemSize);
		} catch (DAOException daoe) {
			daoe.printStackTrace();
		}
		return instResults;
	}

	public List<InstructionListValues> getinstInquryResults() {
		itemItemDtl = new InstructionListValues();
		/*
		 * if(status.equalsIgnoreCase("Select")){ facesMessage =
		 * JSFUtil.getMessage(FacesContext.getCurrentInstance(),
		 * "bundles.UIMessages","status", FacesMessage.SEVERITY_ERROR);
		 * FacesContext
		 * .getCurrentInstance().addMessage("createError",facesMessage); }
		 */

		FacesMessage facesMessage = null;
		// fromDate todate validation for (To Date should be greater or equal to
		// From Date)

		if (firstInstDate != null && lastInstDate != null) {
			if (DateUtils.computeDateDifference(firstInstDate, lastInstDate) < 0) {
				facesMessage = JSFUtil
						.getMessage(FacesContext.getCurrentInstance(),
								"bundles.UIMessages",
								"entity.date.dataNotValid",
								FacesMessage.SEVERITY_ERROR, getEntityName(),
								getItem());
				FacesContext.getCurrentInstance().addMessage(
						"searchMessageError", facesMessage);

			}
		}
		// toDate null validation
		if (firstInstDate != null && lastInstDate == null) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.date.toDateNull", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("searchMessageError",
					facesMessage);

		}
		// fromDate null validation
		if (lastInstDate != null && firstInstDate == null) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.date.fromDateNull", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("searchMessageError",
					facesMessage);

		}

		try {
			instInquryResults = (List<InstructionListValues>) getInstructionDAO()
					.getAllInquiryInstruction(instReferencqueue, samaReference,
							totalAmount, accountCpt.trim(), firstInstDate,
							lastInstDate, status);
			itemSizeInq = instInquryResults.size();
			Iterator iter = instInquryResults.iterator();
			while (iter.hasNext()) {
				itemItemDtl = (InstructionListValues) iter.next();
			}

		} catch (DAOException daoe) {
			daoe.printStackTrace();
		}
		return instInquryResults;
	}

	public List<InstructionListValues> getListMaintanence() {
		String cptNumbmer = "";
		listMaintenence = null;
		itemSizeMain = 0;
		try {

			if ((accountCpt.trim() != null) && (!accountCpt.trim().equals(""))
					&& accountCpt.trim().length() == 6) {
				cptNumbmer = accountCpt.substring(0, 6);

				listMaintenence = (List<InstructionListValues>) getInstructionDAO()
						.getListMaintenence(cptNumbmer);
				itemSizeMain = listMaintenence.size();
			}
			if ((accountCpt.trim() != null) && (!accountCpt.trim().equals(""))
					&& accountCpt.trim().length() == 11) {
				cptNumbmer = accountCpt.substring(0, 11);
				listMaintenence = (List<InstructionListValues>) getInstructionDAO()
						.getListMaintenence(cptNumbmer);
				itemSizeMain = listMaintenence.size();
			}
		} catch (DAOException e) {
			e.printStackTrace();
		}
		return listMaintenence;
	}

	public List<InstructionListValues> getListMintValidate() {
		try {
			listMaintVali = null;
			itemSizeMVali = 0;
			listMaintVali = (List<InstructionListValues>) getInstModifyDAO()
					.getModifyValidateResults(instReferencqueue, modifyRefe);
			itemSizeMVali = listMaintVali.size();
			System.out.println("Size of List==" + itemSizeMVali);

		} catch (DAOException daoe) {
			daoe.printStackTrace();
		}
		return listMaintVali;
	}

	public List<StatusHistory> getStatusList(InstructionListValues instListValu) {
		String instReference = instListValu.getInstReference();
		try {
			statusHistory = getStatusHistoryDAO().getStatusHistoryRecords(
					instReference);
			for (StatusHistory sh : statusHistory) {

			}
		} catch (DAOException daoe) {
			daoe.printStackTrace();
		}
		return statusHistory;
	}

	/* List related fields end */

	public String getBtnType() {
		return btnType;
	}

	public void setBtnType(String btnType) {
		this.btnType = btnType;
	}

	public Long getInstReferenc() {
		return instReferenc;
	}

	public void setInstReferenc(Long instReferenc) {
		this.instReferenc = instReferenc;
	}

	public boolean isSelectoneRadioValue() {
		return selectoneRadioValue;
	}

	public void setSelectoneRadioValue(boolean selectoneRadioValue) {
		this.selectoneRadioValue = selectoneRadioValue;
	}

	public boolean isBsfradioButton() {
		return bsfradioButton;
	}

	public void setBsfradioButton(boolean bsfradioButton) {
		this.bsfradioButton = bsfradioButton;
	}

	public boolean isNobbsfradioButton() {
		return nobbsfradioButton;
	}

	public void setNobbsfradioButton(boolean nobbsfradioButton) {
		this.nobbsfradioButton = nobbsfradioButton;
	}

	public boolean isRadionButtonValue() {
		return radionButtonValue;
	}

	public void setRadionButtonValue(boolean radionButtonValue) {
		this.radionButtonValue = radionButtonValue;
	}

	public String getSelectedTab() {
		System.out.println("selected tab");
		return selectedTab;
	}

	public void setSelectedTab(String selectedTab) {
		this.selectedTab = selectedTab;
	}

	public String getBeneficiaryacc() {
		return beneficiaryacc;
	}

	public void setBeneficiaryacc(String beneficiaryacc) {
		this.beneficiaryacc = beneficiaryacc;
	}

	public String getBeneficiaryname() {
		return beneficiaryname;
	}

	public String getBeneficiaryaddress() {
		return beneficiaryaddress;
	}

	public String getNonBsfbeneficiaryacc() {
		return nonBsfbeneficiaryacc;
	}

	public void setNonBsfbeneficiaryacc(String nonBsfbeneficiaryacc) {
		this.nonBsfbeneficiaryacc = nonBsfbeneficiaryacc;
	}

	public String getNonBsfbeneficiaryname() {
		return nonBsfbeneficiaryname;
	}

	public void setNonBsfbeneficiaryname(String nonBsfbeneficiaryname) {
		this.nonBsfbeneficiaryname = nonBsfbeneficiaryname;
	}

	public void setBeneficiaryaddress(String beneficiaryaddress) {
		this.beneficiaryaddress = beneficiaryaddress;
	}

	public String getBeneficiaryBankaddress() {
		return beneficiaryBankaddress;
	}

	public void setBeneficiaryBankaddress(String beneficiaryBankaddress) {
		this.beneficiaryBankaddress = beneficiaryBankaddress;
	}

	public String getBeneficiaryPaymentDtls() {
		return beneficiaryPaymentDtls;
	}

	public void setBeneficiaryPaymentDtls(String beneficiaryPaymentDtls) {
		this.beneficiaryPaymentDtls = beneficiaryPaymentDtls;
	}

	public void setBeneficiaryname(String beneficiaryname) {
		this.beneficiaryname = beneficiaryname;
	}

	public String getBeneficiaryprofitcent() {
		return beneficiaryprofitcent;
	}

	public void setBeneficiaryprofitcent(String beneficiaryprofitcent) {
		this.beneficiaryprofitcent = beneficiaryprofitcent;
	}

	public String getBeneficiaryactstuts() {
		return beneficiaryactstuts;
	}

	public void setBeneficiaryactstuts(String beneficiaryactstuts) {
		this.beneficiaryactstuts = beneficiaryactstuts;
	}

	public InstructionDAO getInstructionDAO() {
		return instructionDAO;
	}

	public void setInstructionDAO(InstructionDAO instructionDAO) {
		this.instructionDAO = instructionDAO;
	}

	public InstructionDetailDAO getInstDtlDAO() {
		return instDtlDAO;
	}

	public void setInstDtlDAO(InstructionDetailDAO instDtlDAO) {
		this.instDtlDAO = instDtlDAO;
	}

	public UploadedFile getUploadedFile() {
		return uploadedFile;
	}

	public void setUploadedFile(UploadedFile uploadedFile) {
		this.uploadedFile = uploadedFile;
	}

	public String getAccountCpt() {
		return accountCpt;
	}

	public void setAccountCpt(String accountCpt) {
		this.accountCpt = accountCpt;
	}

	public ParameterValueDAO getParameterVDAO() {
		return parameterVDAO;
	}

	public void setParameterVDAO(ParameterValueDAO parameterVDAO) {
		this.parameterVDAO = parameterVDAO;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * @param errorMsg
	 *            the errorMsg to set
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getActstatus() {
		return actstatus;
	}

	public void setActstatus(String actstatus) {
		this.actstatus = actstatus;
	}

	public String getAccountstatusdesc() {
		return accountstatusdesc;
	}

	public void setAccountstatusdesc(String accountstatusdesc) {
		this.accountstatusdesc = accountstatusdesc;
	}

	public String getProfitCenter() {
		return profitCenter;
	}

	public void setProfitCenter(String profitCenter) {
		this.profitCenter = profitCenter;
	}

	public String getSamaReference() {
		return samaReference;
	}

	public void setSamaReference(String samaReference) {
		this.samaReference = samaReference;
	}

	public String getModifyRefe() {
		return modifyRefe;
	}

	public void setModifyRefe(String modifyRefe) {
		this.modifyRefe = modifyRefe;
	}

	public String getSelectCalendarTypRadio() {
		return selectCalendarTypRadio;
	}

	public void setSelectCalendarTypRadio(String selectCalendarTypRadio) {
		this.selectCalendarTypRadio = selectCalendarTypRadio;
	}

	public String getFrequencey() {
		return frequencey;
	}

	public void setFrequencey(String frequencey) {
		this.frequencey = frequencey;
	}

	public Date getDocDateH() {
		return docDateH;
	}

	public void setDocDateH(Date docDateH) {
		this.docDateH = docDateH;
	}

	public Date getDocReceivingDateH() {
		return docReceivingDateH;
	}

	public void setDocReceivingDateH(Date docReceivingDateH) {
		this.docReceivingDateH = docReceivingDateH;
	}

	public String getDocDateHStr() {
		return docDateHStr;
	}

	public void setDocDateHStr(String docDateHStr) {
		this.docDateHStr = docDateHStr;
	}

	public String getDocReceivingDateHStr() {
		return docReceivingDateHStr;
	}

	public void setDocReceivingDateHStr(String docReceivingDateHStr) {
		this.docReceivingDateHStr = docReceivingDateHStr;
	}

	public Long getNumberofInst() {
		return numberofInst;
	}

	public void setNumberofInst(Long numberofInst) {
		this.numberofInst = numberofInst;
	}

	public boolean isAccDetails() {
		return accDetails;
	}

	public void setAccDetails(boolean accDetails) {
		this.accDetails = accDetails;
	}

	/**
	 * Get Bank Name user has selected
	 * 
	 * @return selectedSystemType
	 */
	public String getSelectedBankName() {
		return selectedBankName;
	}

	/**
	 * Set Bank Name user selected
	 * 
	 * @param selectedSystemType
	 */

	public void setSelectedBankName(String selectedBankName) {
		this.selectedBankName = selectedBankName;
	}

	public String getInstStatus() {
		return instStatus;
	}

	public void setInstStatus(String instStatus) {
		this.instStatus = instStatus;
	}

	public BigDecimal getMonthlyAmount() {
		return monthlyAmount;
	}

	public void setMonthlyAmount(BigDecimal monthlyAmount) {
		this.monthlyAmount = monthlyAmount;
	}

	public Integer getDayofPayment() {
		return dayofPayment;
	}

	public void setDayofPayment(Integer dayofPayment) {
		this.dayofPayment = dayofPayment;
	}

	public String getRadioButtonCalendarG() {
		return radioButtonCalendarG;
	}

	public void setRadioButtonCalendarG(String radioButtonCalendarG) {
		this.radioButtonCalendarG = radioButtonCalendarG;
	}

	public InstructionDetails getItemDetail() {
		return itemDetail;
	}

	public void setItemDetail(InstructionDetails itemDetail) {
		this.itemDetail = itemDetail;
	}

	/**
	 * 
	 * @return HtmlDataTable representing backendSystem Table
	 */
	public HtmlDataTable getPaymentInstructionTable() {
		return (HtmlDataTable) JSFUtil.findComponentInRoot("paymentInstructionTable");
	}

	/**
	 * 
	 * @return HtmlDataTable representing backendSystem Table
	 */
	public HtmlDataTable getPaymentStatusHistoryTable() {
		return (HtmlDataTable) JSFUtil
				.findComponentInRoot("paymentStatusHistoryTable");
	}

	private HtmlPanel getNonbSFCustomer() {
		HtmlPanel htmlp = (HtmlPanel) JSFUtil.findComponentInRoot("firstPanel");
		JSFUtil.findComponentValueInRoot("custRadio");
		UIComponent uic = htmlp.findComponent("samaReference");
		FacesContext context = FacesContext.getCurrentInstance();
		List lst = uic.getChildren();
		Iterator itr = lst.iterator();
		while (itr.hasNext()) {
			System.out.println("Components calue" + itr.next());
		}
		// UIInput uii=(UIInput)
		// UIViewRoot root = context.getViewRoot();
		// String cid=root.getClientId(context);
		final String componentId = "firstInstDate";
		UIComponent c = htmlp.findComponent(componentId);
		// String date= (String) c.getAttributes().get(cid);
		// System.out.println("Componetn ID==="+uii.getSubmittedValue().toString());
		return htmlp;
	}

	/**
	 * Constructor for ApplicationController.
	 */
	public PaymentsQueueController() {
		// initialize item entity
		user = JSFUtil.getLoggedInUserInfo();
		item = new Ppm_Instructions();
		itemDetail = new InstructionDetails();
		// Initialize the default search Criteria
		// this.getSearchCriteria().put(getStatusFieldName(), "");
		sortField = "instReference";
		sortAscending = true;
	}

	public void uploadFile(UploadEvent event) {
		try {
			String filePath = getParameterVDAO().getFilePath();
			UploadItem fileItem = event.getUploadItem();
			System.out.println("fileItem----" + fileItem);
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
			String timestamp = new String(dateFormat
					.format(new java.util.Date()));
			// fname = fileLoc+"ardico_"+user.getUserId()+"_"+timestamp+".dat";
			fname = filePath + File.separator
					+ JSFUtil.getLoggedInUserInfo().getUserId() + timestamp
					+ ".pdf";

			System.out.println("fname===" + fname);

			byte data[] = fileItem.getData();
			File file = new File(fname);
			FileOutputStream outStream = new FileOutputStream(file);
			outStream.write(data);
			outStream.close();
			System.out.println("File name" + fname);
		} catch (DAOException dao) {
			log.warn("The target file path does not exist or is invalid ", dao);
			dao.printStackTrace();
		} catch (FileNotFoundException fnf) {
			log.warn("The target file path does not exist or is invalid ", fnf);
			setErrorMsg("ERROR :: The target file path does not exist or is invalid.");
			fnf.printStackTrace();
			return;
		} catch (IOException ie) {
			log.warn(" Read / Write Exception occurred while uploading file. ",
					ie);
			setErrorMsg("ERROR :: Read / Write Exception occurred while uploading file.");
			ie.printStackTrace();
			return;
		}
		// fname="";

	}

	/* read the SAMA letters */
	public void downloadFile() {
		try {
			String filePath = "";
			String instReference = "";
			List<InstructionDetails> lstInstDtl = getParameterVDAO()
					.getSamaDocFilePath(
							itemItemDtl.getInstReference().toString());
			for (InstructionDetails instD : lstInstDtl) {
				instReference = instD.getInstReference();
				filePath = instD.getRelatedDoc();
			}

			if (filePath != null) {
				// String fileName=filePath.substring(16, 42);
				// System.out.println(fileName);
				file = new File(filePath);
				// File file = new File("D:/PPMDocuments/test.txt");
				System.out.println("file==" + file);
				HttpServletResponse response = (HttpServletResponse) FacesContext
						.getCurrentInstance().getExternalContext()
						.getResponse();
				System.out.println("response===" + response);
				response.setContentLength((int) file.length());
				ServletOutputStream out = null;
				try {
					FileInputStream input = new FileInputStream(file);
					byte[] buffer = new byte[1024];
					out = response.getOutputStream();
					int i = 0;
					while ((i = input.read(buffer)) != -1) {
						out.write(buffer);
						out.flush();
						response.getOutputStream().flush();
						FacesContext.getCurrentInstance().responseComplete();
					}
					FacesContext.getCurrentInstance().getResponseComplete();
				} catch (IOException err) {
					err.printStackTrace();
				} finally {
					try {
						if (out != null) {
							out.close();
						}
					} catch (IOException err) {
						err.printStackTrace();
					}
				}
				response.reset();
				response.setHeader("Content-Type", "application/pdf");
				response.setHeader("Content-Length", String.valueOf(file
						.length()));
				response.setHeader("Content-Disposition", "inline; filename=\""
						+ "Sama Letter" + "\"");
				System.out.println(file.toString());
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/* read the SAMA Updated letters */
	public void downloadUpdatedFile() {
		try {
			String oldFile = "";
			String newFile = "";
			String instReference = "";

			List<InstructionListValues> listInstValu = getInstModifyDAO()
					.getModifyValidateResults(
							itemItemDtl.getInstReference().toString(),
							itemItemDtl.getModifyRef().toString());
			for (InstructionListValues instructionListValues : listInstValu) {
				oldFile = instructionListValues.getRelatedDocOld();
				newFile = instructionListValues.getRelatedDocNew();
			}

			if (newFile != null) {
				// String fileName=filePath.substring(16, 42);
				// System.out.println(fileName);
				file = new File(newFile);
				// File file = new File("D:/PPMDocuments/test.txt");
				System.out.println("file==" + file);
				HttpServletResponse response = (HttpServletResponse) FacesContext
						.getCurrentInstance().getExternalContext()
						.getResponse();
				System.out.println("response===" + response);
				response.setContentLength((int) file.length());
				ServletOutputStream out = null;
				try {
					FileInputStream input = new FileInputStream(file);
					byte[] buffer = new byte[1024];
					out = response.getOutputStream();
					int i = 0;
					while ((i = input.read(buffer)) != -1) {
						out.write(buffer);
						out.flush();
						response.getOutputStream().flush();
						FacesContext.getCurrentInstance().responseComplete();
					}
					FacesContext.getCurrentInstance().getResponseComplete();
				} catch (IOException err) {
					err.printStackTrace();
				} finally {
					try {
						if (out != null) {
							out.close();
						}
					} catch (IOException err) {
						err.printStackTrace();
					}
				}
				response.reset();
				response.setHeader("Content-Type", "application/pdf");
				response.setHeader("Content-Length", String.valueOf(file
						.length()));
				response.setHeader("Content-Disposition", "inline; filename=\""
						+ "Sama Letter" + "\"");
				System.out.println(file.toString());
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
    public void activateTab(ActionEvent aEven){
    	beneficiaryacc = "";
    }
	public String getCalendarType(ValueChangeEvent event) {
		String eventValue = event.getNewValue().toString();
		System.out.println("eventValue" + eventValue);

		if (eventValue.equals("G")) {
			docDateHStr = "";
			docDateH = null;
			docReceivingDateH = null;
			docReceivingDateHStr = "";
			selectCalendarTypRadio = "G";
		} else {
			docDateH = null;
			docReceivingDateH = null;
			docReceivingDateHStr = "";
			selectCalendarTypRadio = "G";

			selectCalendarTypRadio = "H";
		}
		return eventValue;
	}

	public void validateForm(FacesContext context, UIComponent component,
			Object value) {
		FacesMessage message = null;
		String componentId = component.getId();
		// Do not process if the value is null
		if (value == null) {
			return;
		}
		String valueStr = "";
		// Validate for miscellaneous characters
		if (value instanceof String) {
			valueStr = vaildateChars((String) value, context, componentId);
		}

		if (componentId.equalsIgnoreCase("dayofPayment")) {
			System.out.println("dayofPayment==" + valueStr.length());
			// validate for length
			if (valueStr.length() > 0) {
				System.out.println("dayofPayment==" + dayofPayment);
				int dOfp = dayofPayment.intValue();
				System.out.println("dOfp==" + dOfp);
				if (dOfp > 31) {
					context.getApplication().setMessageBundle(
							"bundles.ValidatorMessages");
					message = MessageFactory.getMessage(context,
							"dayOfPay.chars", FacesMessage.SEVERITY_ERROR,
							componentId, 31);
					throw new ValidatorException(message);
				}
			}
		}

		else if (componentId.equalsIgnoreCase("accNumber")) {
			// validate for length
			if (valueStr.length() > 11) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context, "accNumber.chars",
						FacesMessage.SEVERITY_ERROR, componentId, 11);
				throw new ValidatorException(message);
			}
		}

		else if (componentId.equalsIgnoreCase("startingDateH")) {
			// validate for length
			if (valueStr.length() == 10) {
				String mm = valueStr.substring(5, 7);
				String dd = valueStr.substring(8, 10);
				System.out.println("Months---" + valueStr);
				System.out.println("mm---" + mm);
				System.out.println("dd---" + dd);
				try {
					if (new Integer(mm) > 12) {
						context.getApplication().setMessageBundle(
								"bundles.ValidatorMessages");
						message = MessageFactory.getMessage(context,
								"vMonth.chars", FacesMessage.SEVERITY_ERROR);
						throw new ValidatorException(message);
					}
				} catch (NumberFormatException nfe) {
					context.getApplication().setMessageBundle(
							"bundles.ValidatorMessages");
					message = MessageFactory.getMessage(context,
							"vDate.chars.number", FacesMessage.SEVERITY_ERROR);
					throw new ValidatorException(message);
				}
				try {
					if (new Integer(dd) > 31) {
						context.getApplication().setMessageBundle(
								"bundles.ValidatorMessages");
						message = MessageFactory.getMessage(context,
								"vDate.chars", FacesMessage.SEVERITY_ERROR);
						throw new ValidatorException(message);
					}
				} catch (NumberFormatException nfe) {
					context.getApplication().setMessageBundle(
							"bundles.ValidatorMessages");
					message = MessageFactory.getMessage(context,
							"vDate.chars.number", FacesMessage.SEVERITY_ERROR);
					throw new ValidatorException(message);
				}
			} else {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context, "vDate.chars",
						FacesMessage.SEVERITY_ERROR);
				throw new ValidatorException(message);
			}
		}

		else if (componentId.equalsIgnoreCase("receivingDateH")) {
			// validate for length
			if (valueStr.length() == 10) {
				String mm = valueStr.substring(5, 7);
				String dd = valueStr.substring(8, 10);
				System.out.println("Months---" + valueStr);
				System.out.println("mm---" + mm);
				System.out.println("dd---" + dd);
				try {
					if (new Integer(mm) > 12) {
						context.getApplication().setMessageBundle(
								"bundles.ValidatorMessages");
						message = MessageFactory.getMessage(context,
								"vReceivingMonth.chars",
								FacesMessage.SEVERITY_ERROR);
						throw new ValidatorException(message);
					}
				} catch (NumberFormatException nfe) {
					context.getApplication().setMessageBundle(
							"bundles.ValidatorMessages");
					message = MessageFactory.getMessage(context,
							"vReceivingMonth.chars.number",
							FacesMessage.SEVERITY_ERROR);
					throw new ValidatorException(message);
				}
				try {
					if (new Integer(dd) > 31) {
						context.getApplication().setMessageBundle(
								"bundles.ValidatorMessages");
						message = MessageFactory.getMessage(context,
								"vReceivingDate.chars",
								FacesMessage.SEVERITY_ERROR);
						throw new ValidatorException(message);
					}
				} catch (NumberFormatException nfe) {
					context.getApplication().setMessageBundle(
							"bundles.ValidatorMessages");
					message = MessageFactory.getMessage(context,
							"vReceivingMonth.chars.number",
							FacesMessage.SEVERITY_ERROR);
					throw new ValidatorException(message);
				}
			} else {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"vReceivingDate.chars", FacesMessage.SEVERITY_ERROR);
				throw new ValidatorException(message);
			}
		}

		else if (componentId.equalsIgnoreCase("upload")) {
			// validate for length
			if ("upload".equals(valueStr)) {
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context, "uploadFileError",
						FacesMessage.SEVERITY_ERROR);
				throw new ValidatorException(message);
			}

		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.controller.jsf.AbstractCrudController#create()
	 */
	protected String vaildateChars(String value, FacesContext context,
			String componentId) {
		if (value != null) {
			FacesMessage message = null;
			value = value.trim();
			if (value == null) {
				message = MessageFactory.getMessage(context,
						"entity.add.error.invalidChar",
						FacesMessage.SEVERITY_ERROR, componentId, value
								+ "......");
				throw new ValidatorException(message);
			}
			Pattern p = Pattern.compile(IConstants.INVALIDCHAR);
			Matcher m = p.matcher(value.toString());
			if (m.find()) {
				if (value.toString().length() > 30)
					value = value.toString().substring(0, 25);
				context.getApplication().setMessageBundle(
						"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"entity.add.error.invalidChar",
						FacesMessage.SEVERITY_ERROR, componentId, value
								+ "......");
				throw new ValidatorException(message);
			}
		}
		return value;
	}

	/* Edit/Detail page customer account details form Tuxedo service */
	public void getcustAccountDetailsEdit(InstructionListValues instLstValu) {
		System.out.println("Entering in getcustAccountDetails method");
		accountInqRes = null;
		customerName = "";
		actstatus = "";
		profitCenter = "";
		accountstatusdesc = "";
		if(!"P".equals(instLstValu.getInstReference().substring(0, 1))){
		String accountNo = instLstValu.getAccNumber();
		try {
			if (accountNo.length() == 11) {
				System.out.println("Success...");
				// System.out.println("Customer Tuxedo call"+event.getNewValue());
				String s = "BDSFININQ012016051008023200007010            000000001001001000000000000000000001382200142022   AUTO     00000000000000000000000555500000000000000NOR66660000";
				
				FTSPostingService FTSPS = new FTSPostingServiceImpl();
				
				AccountInquiryRequest accountInquiryRequest = new AccountInquiryRequest();

				accountInquiryRequest = AccountInquiryRequest.getInstance();
				accountInquiryRequest.setAccountNo(accountNo);
				
				accountInqRes = FTSPS.sendAccountInquiry(accountInquiryRequest,
						"BDS");

				customerName = accountInqRes.getCustFullName();
				actstatus = accountInqRes.getAcctStatusCode();
				profitCenter = accountInqRes.getProfitCenter();
				accountstatusdesc = accountInqRes.getAcctStatusDesc();

				if (customerName != null && !"".contains(customerName)) {
					setAccountNo(accountNo);
				}
				
			} else {
				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage("Account Number Should be 11 digits"));
				log.info("Please enter 11 digit of account number"
						+ accountNo.length());
			}
		} catch (ApplicationException ae) {
			ae.printStackTrace();
		}
		}
	}

	/*public void clearComponent(UIComponent pComponent) {
		if (pComponent instanceof EditableValueHolder) {
			EditableValueHolder editableValueHolder = (EditableValueHolder) pComponent;
			editableValueHolder.setSubmittedValue(null);
			editableValueHolder.setValue(null);
			editableValueHolder.setValid(true);
		}
		for (UIComponent child : pComponent.getChildren()) {
			clearComponent(child);
		}
	}*/
	public void refresh() {
	    FacesContext context = FacesContext.getCurrentInstance();
	    Application application = context.getApplication();
	    ViewHandler viewHandler = application.getViewHandler();
	    UIViewRoot viewRoot = viewHandler.createView(context, context.getViewRoot().getViewId());
	    context.setViewRoot(viewRoot);
	  }

	
	/* create Instruction page account details form Tuxedo service */
	public boolean getcustAccountDetails() {
		log.info("Entering in getcustAccountDetails method");
		refresh();
		accountInqRes = null;
		String accountNo = getAccountNo().toUpperCase();

		log.info("Customer accountNo" + accountNo);
		try {
			if (accountNo.length() == 11) {
				log.info("Success...");
				customerName = "";
				actstatus = "";
				accountstatusdesc = "";
				profitCenter = "";
				FTSPostingService FTSPS = new FTSPostingServiceImpl();
				AccountInquiryRequest accountInquiryRequest = new AccountInquiryRequest();
				accountInquiryRequest = AccountInquiryRequest.getInstance();
				accountInquiryRequest.setAccountNo(accountNo);
				accountInqRes = FTSPS.sendAccountInquiry(accountInquiryRequest,"BDS");
				
				if(accountInqRes==null){
				log.info("Tring to call Tuxedo getting network eroor ="+accountInqRes);	
				}
				String ftsActionCode = accountInqRes.getFtsActionCode();
                String cammActionCode= accountInqRes.getCammActionCode(); 
				//
				if (ftsActionCode.equals("0000")&&cammActionCode.equals("0000")) {
					// customerName = "";
					// actstatus = "";
					accountstatusdesc = "";
					// profitCenter = "";
					setCustomerName(null);
					setActstatus(null);
					setProfitCenter(null);
					System.out.println("Account Number:"+ accountInquiryRequest.getAccountNo());
					System.out.println("AvailableBalance:"+ accountInqRes.getAvailableBalance());
					debitAcctType = accountInqRes.getAccountType();
					productType = accountInqRes.getProductTypeCode();
					System.out.println("productType====" + productType);

					setAccountNo(accountNo);
					profitCenter = accountInqRes.getProfitCenter();
					customerName = accountInqRes.getCustFullName();
					actstatus = accountInqRes.getAcctStatusCode();
					actStatusTux = actstatus;
					accountstatusdesc = accountInqRes.getAcctStatusDesc();

					iDType = accountInqRes.getIdType();
					custIdNumber = accountInqRes.getIdNumber();
					System.out.println("custIdNumber==" + custIdNumber);
					System.out.println("CustType=" + debitAcctType);
					System.out.println("CustType Des="
							+ accountInqRes.getCustTypeDescription());
					iDExpiryDate = accountInqRes.getIdExpiryDate();
					custProfitCenter = accountInqRes.getProfitCenter();
					System.out.println("accountInqRes Account Status Des"
							+ accountstatusdesc);
					System.out.println("Account Status" + actstatus);
					System.out.println("Customer Name==" + customerName);
					customerAcctFlag = true;

					// Allowed Account Status For debit account
					parameterValue = getParameterVDAO().getAccountType("DRACTSTUS");
					debitActDBFlag = false;
					if (parameterValue.size() > 0) {
						for (ParameterValue parmaValue : parameterValue) {
							acctTypeFromDB = parmaValue.getValue1();
				            if (customerAcctFlag&&(acctTypeFromDB.trim().equalsIgnoreCase(actStatusTux.trim()))) {
						    debitActDBFlag = true;
						    break;
					       }
					   }
					}
					else{
					debitActDBFlag = true;	
					}
					// if (!actStatusTux.trim().equals("OP")) {
					if (!debitActDBFlag) {
					accountstatusdesc = accountInqRes.getAcctStatusDesc();
					FacesContext.getCurrentInstance().addMessage("actstatus",new FacesMessage("Account Status :"+accountstatusdesc));
					}

				} else {
					setCustomerName(null);
					setActstatus(null);
					setProfitCenter(null);
					// customerName = "";
					// actstatus = "";
					// accountstatusdesc = "";
					profitCenter = "";
					customerAcctFlag = false;
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("errorCode", cammActionCode);
					GErrorList gErrorList = getgErrorListDAO().getByCriteria(
							map);
					FacesContext.getCurrentInstance().addMessage(
							"accNumber",
							new FacesMessage("Account Inquiry Error Code:  "
									+ cammActionCode));
					FacesContext.getCurrentInstance().addMessage(
							"customerName",
							new FacesMessage(
									"Account Inquiry Error Description:  "
											+ gErrorList.getErrorMsg()));
				}
			} else {
				customerName = "";
				actstatus = "";
				accountstatusdesc = "";
				profitCenter = "";
				FacesContext.getCurrentInstance().addMessage("accNumber",
						new FacesMessage("Account Number Should be 11 digits"));
			 }
		} catch (ApplicationException ae) {
			ae.printStackTrace();
		}
		return customerAcctFlag;
	}

	/* create Instruction page beneficiary account details form Tuxedo service */
	public boolean getBeneficiarycustAccountDetails() {
		refresh();
		benaccountInqRes = null;
		String benAcc = getBeneficiaryacc().toUpperCase();
		try {
			if (benAcc.length() == 11) {
				beneficiaryname = "";
				beneficiaryactstuts = "";
				String beneficiaryactstutsDesc = "";
				beneficiaryprofitcent = "";
				System.out.println("Beneficiary beneficiaryname:"
						+ beneficiaryname);
				FTSPostingService FTSPS = new FTSPostingServiceImpl();
				System.out.println("FTSPS==================" + FTSPS);
				AccountInquiryRequest accountInquiryRequest = new AccountInquiryRequest();
				System.out.println("beneficiaryacc---" + benAcc);

				accountInquiryRequest = AccountInquiryRequest.getInstance();
				accountInquiryRequest.setAccountNo(benAcc);
				System.out.println("accountInquiryRequest===="
						+ accountInquiryRequest);
				System.out.println("accountInquiryRequest Account nUmber===="
						+ accountInquiryRequest.getAccountNo());
				benaccountInqRes = FTSPS.sendAccountInquiry(
						accountInquiryRequest, "BDS");
				String ftsActionCode = benaccountInqRes.getFtsActionCode();
				if (ftsActionCode.equals("0000")) {

					System.out.println("beneficiaryactstuts===="
							+ beneficiaryactstuts);
					beneficiaryname = benaccountInqRes.getCustFullName();
					System.out.println("beneficiaryname from Tuxedo=" + benAcc);
					beneficiaryactstuts = benaccountInqRes.getAcctStatusCode();
					beneficiaryactstutsTux = beneficiaryactstuts;
					beneficiaryprofitcent = benaccountInqRes.getProfitCenter();
					creditAcctType = benaccountInqRes.getAccountType();
					
					
					// itemDetail.setBenPftCtr(beneficiaryprofitcent);
					// itemDetail.setBenAccountStatus(beneficiaryactstuts);
					benAcc = "";
					System.out.println("accountInqRes Account Status Des"
							+ benaccountInqRes.getAcctStatusDesc());
					System.out.println("Account Status"
							+ benaccountInqRes.getProfitCenter());
					System.out.println("Customer Name=="
							+ benaccountInqRes.getCustFullName());
					System.out.println("creditAcctType acctType"
							+ creditAcctType);
					bsfBeneFiciAcctFlag = true;
					// if ("FB".equals(beneficiaryactstutsTux.trim()) ||
					// "CL".equalsIgnoreCase(beneficiaryactstutsTux.trim()) ) {
					// Allowed Account Status For credit account (Only if it is
					// BSF account - AATR case only)
					parameterValue = getParameterVDAO().getAccountType("CRACTSTUS");
					creditActDBFlag = false;
					if (parameterValue.size() > 0) {
						for (ParameterValue parmaValue : parameterValue) {
							acctTypeFromDB = parmaValue.getValue1();

					// Beneficiary Account Status and Account Type
					// checking
					     if (bsfBeneFiciAcctFlag	&& (acctTypeFromDB.trim().equalsIgnoreCase(beneficiaryactstutsTux.trim()))){
					     creditActDBFlag = true;
					     break;
					     }
                  	    }
					}
					else{
					creditActDBFlag=true;	
					}
					if (!creditActDBFlag) {
						beneficiaryactstutsDesc = benaccountInqRes.getAcctStatusDesc();
						FacesContext.getCurrentInstance().addMessage("beneficiaryactstuts",new FacesMessage("Beneficiary Account Status :"+ beneficiaryactstutsDesc));
     				}

				 } 
				  else {
					bsfBeneFiciAcctFlag = false;
					beneficiaryname = "";
					beneficiaryactstuts = "";
					beneficiaryprofitcent = "";
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("errorCode", ftsActionCode);
					GErrorList gErrorList = getgErrorListDAO().getByCriteria(
							map);
					FacesContext.getCurrentInstance().addMessage(
							"beneficiaryacc",
							new FacesMessage("Account Inquiry Error Code:  "
									+ ftsActionCode));
					FacesContext.getCurrentInstance().addMessage(
							"beneficiaryname",
							new FacesMessage(
									"Account Inquiry Error Description:  "
											+ gErrorList.getErrorMsg()));
				}
			} else {
				beneficiaryname = "";
				beneficiaryactstuts = "";
				beneficiaryprofitcent = "";
				System.out.println("FacesContext.getCurrentInstance()."
						+ FacesContext.getCurrentInstance());
				FacesContext.getCurrentInstance().addMessage(
						"beneficiaryacc",
						new FacesMessage(
								"Beneficiary Account Should be 11 digits"));
				System.out.println("Please enter 11 digit of account number"
						+ benAcc.length());
			}
		} catch (ApplicationException ae) {
			ae.printStackTrace();
		}
		return bsfBeneFiciAcctFlag;
	}

	/* Edit/Detail page beneficiary account details form Tuxedo service */
	public void getBeneficiarycustAccountDetailsEdit(
			InstructionListValues instLstValu) {
		benaccountInqRes = null;
		String benAcc = instLstValu.getBenAcc();
		System.out.println("benAcc===" + benAcc);
		if(!"P".equals(instLstValu.getInstReference().substring(0, 1))){
		if (benAcc.length() == 11) {
			System.out
					.println("Beneficiary Account Number form Tuxedo Service:"
							+ benAcc);
			// String
			// s="BDSFININQ012016051008023200007010            000000001001001000000000000000000001382200142022   AUTO     00000000000000000000000555500000000000000NOR66660000";
			// System.out.println(s.substring(74, 94));

			FTSPostingService FTSPS = new FTSPostingServiceImpl();
			System.out.println("FTSPS==================" + FTSPS);
			AccountInquiryRequest accountInquiryRequest = new AccountInquiryRequest();

			System.out.println("beneficiaryacc---" + beneficiaryacc);
			accountInquiryRequest = AccountInquiryRequest.getInstance();
			accountInquiryRequest.setAccountNo(benAcc);
			System.out.println("accountInquiryRequest===="
					+ accountInquiryRequest);

			System.out.println("accountInquiryRequest Account nUmber===="
					+ accountInquiryRequest.getAccountNo());
			try {
				benaccountInqRes = FTSPS.sendAccountInquiry(
						accountInquiryRequest, "BDS");
				String ftsActionCode = benaccountInqRes.getFtsActionCode();

				if (ftsActionCode.equals("0000")) {
					beneficiaryname = benaccountInqRes.getCustFullName();
					beneficiaryactstuts = benaccountInqRes.getAcctStatusDesc();
					beneficiaryprofitcent = benaccountInqRes.getProfitCenter();
					setBeneficiaryacc(benAcc);
					System.out.println("accountInqRes Account Status Des"
							+ benaccountInqRes.getAcctStatusDesc());
					System.out.println("Account Status"
							+ benaccountInqRes.getProfitCenter());
					System.out.println("Customer Name=="
							+ benaccountInqRes.getCustFullName());
				} else {
					System.out.println("Error from Tuxedo error code="
							+ ftsActionCode);
				}

			} catch (ApplicationException ae) {
				ae.printStackTrace();
			}
		}
		}
		/*
		 * else{
		 * System.out.println("FacesContext.getCurrentInstance()."+FacesContext
		 * .getCurrentInstance());
		 * FacesContext.getCurrentInstance().addMessage("accNumber", new
		 * FacesMessage("Account Number Should be 11 digits"));
		 * System.out.println
		 * ("Please enter 11 digit of account number"+benAcc.length()); }
		 */

	}

	/* validate IBAN format Account number for NON BSF Customers */
	public boolean getNonBSFBeneficiarycustAccountDetails() {
		String benAcc = getNonBsfbeneficiaryacc();
		System.out.println("NON BSF Beneficiary Acc=" + benAcc);
		com.bsf.ppm.util.IbanUtils ibanU = new com.bsf.ppm.util.IbanUtils();
		nonBsfBenefAcctFlag = ibanU.isValidSaudiIBAN(benAcc);
		nonBsfbeneficiaryname = getNonBsfbeneficiaryname();
		beneficiaryaddress = getBeneficiaryaddress();
		beneficiaryBankaddress = getBeneficiaryBankaddress();
		beneficiaryPaymentDtls = getBeneficiaryPaymentDtls();
		if (nonBsfBenefAcctFlag) {
			return nonBsfBenefAcctFlag;
		} else {
			FacesContext.getCurrentInstance().addMessage("nonbsfbeneficiaryacc",new FacesMessage("Invalid IBAN Number"));
			nonBsfBenefAcctFlag = false;
		}
		beneficiaryacc = "";
		nonBsfbeneficiaryacc = "";
		return nonBsfBenefAcctFlag;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.jsf.AbstractCrudController#getDAO()
	 */
	public PaginatedDAO<Ppm_Instructions, String> getDAO() {
		return instructionDAO;
	}

	public String getNumberOfInstruction() {

		frequencey = "M";
		Integer count = new Integer(0);
		if (frequencey.equals("M")) {
			count = null;
			count = new Integer(30);
		}
		if (frequencey.equals("Y")) {
			count = null;
			count = new Integer(365);
		}

		if (frequencey.equals("H")) {
			count = null;
			count = new Integer(180);
		}
		if (frequencey.equals("Q")) {
			count = null;
			count = new Integer(90);
		}
		if (frequencey.equals("S")) {
			count = null;
			count = new Integer(15);
		}
		if (frequencey.equals("select")) {
			count = null;
			count = new Integer(0);
		}

		try {

			Calendar cal = Calendar.getInstance();
			cal.setTime(currentDate);

			// Set time fields to zero
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			// Put it back in the Date object
			currentDate = cal.getTime();
		} catch (Exception e) {
			e.printStackTrace();
		}

		if ((getFirstInstDate() != null && getLastInstDate() != null)) {
			Date firstDate = getFirstInstDate();
			Date lastDate = getLastInstDate();
			System.out.println("firstDate" + firstDate);
			System.out.println("lastDate" + lastDate);

			System.out.println("currentDate" + currentDate);
			if (firstDate.before(currentDate) || lastDate.before(firstDate)) {
				if (firstDate.before(currentDate)) {
					FacesContext
							.getCurrentInstance()
							.addMessage(
									null,
									new FacesMessage(
											"First Date Should not be before current date"));
				}
				if (lastDate.before(firstDate)) {
					FacesContext
							.getCurrentInstance()
							.addMessage(
									null,
									new FacesMessage(
											"Last Date Should not be before First date"));
				}

			}

			Long noOfDays = lastDate.getTime() - firstDate.getTime();
			Long days = TimeUnit.DAYS.convert(noOfDays, TimeUnit.MILLISECONDS);
			System.out.println("Fisrt Installment Date:="
					+ TimeUnit.DAYS.convert(noOfDays, TimeUnit.MILLISECONDS));
			Integer noInst = 0;
			System.out.println("count====" + count);
			if (count != 0) {
				noInst = (days.intValue() / count);
			}

			noofinst = noInst.longValue();
			System.out.println("numberofInst==" + noofinst);
			if (noofinst >= 1) {
				setNumberofInst(noofinst);
			}
			if (noofinst == 0) {
				setNumberofInst(new Long(0));
			}
			System.out.println("getNumberofInst" + getNumberofInst());
		}

		if ((getDocDateH() != null && getDocReceivingDateH() != null)) {
			if (docDateH.after(currentDate)
					|| docReceivingDateH.after(currentDate)) {
				if (docDateH.after(currentDate)) {
					FacesContext
							.getCurrentInstance()
							.addMessage(
									null,
									new FacesMessage(
											"Date Should be current date or past date"));

				}
				if (docReceivingDateH.after(currentDate)) {
					FacesContext
							.getCurrentInstance()
							.addMessage(
									null,
									new FacesMessage(
											"Receiving Date Should be current date or past date"));

				}
			}

		}

		if (monthlyAmount != null) {
			getTotalAmountCal();
		}
		if (getNumberofInst() != null) {
			return getNumberofInst().toString();
		} else {
			return "";
		}

	}

	public void getTotalAmountCal() {
		//refresh();
		BigDecimal totalAmt = new BigDecimal(0.00);
		System.out.println("getTotalAmountCal==method totalAmt==" + totalAmt);
		if ((monthlyAmount != null) && (noofinst != 0)) {
			totalAmt = monthlyAmount.multiply(new BigDecimal(noofinst));
			System.out.println("totalAmt=====" + totalAmt);
			setTotalAmount(totalAmt);
		} else {
			setTotalAmount(totalAmt);
		}
	}

	public String getDayOfPayment(ValueChangeEvent event) {
		if (event != null) {
			String valueofint = event.getNewValue().toString();
			Integer dayofPayment = new Integer(valueofint);
			if (dayofPayment >= 32) {
			FacesContext.getCurrentInstance().addMessage(null,new FacesMessage("Day of payment should not be more than 31"));
			return "";
			}
		}
		return "";
	}

	/**
	 * List of ParameterValue Items
	 * 
	 * @return List of ParameterValue Items for the Select Options
	 */
	public List<SelectItem> getFrequencyValue() {
		// beneficiaryname="";
		nonBsfbeneficiaryacc = "";
		// nonBsfbeneficiaryname="";
		List<ParameterValue> frequencyValue = null;
		List<SelectItem> list = new ArrayList<SelectItem>();
		try {
			frequencyValue = getParameterVDAO().getFrequencyList();

		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		for (ParameterValue parm : frequencyValue) {
			list.add(new SelectItem(parm.getValue1(), parm.getValue2()));
		}

		return list;
	}

	/**
	 * List of DomesticBank Items
	 * 
	 * @return List of DomesticBank Items for the Select Options
	 */
	public List<SelectItem> getBeneficiaryBankList() {
		bsfBeneFiciAcctFlag = false;
		List<DomesticBank> beneficiaryBankList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();

		try {
			// Fetch the List of Bank
			beneficiaryBankList = getParameterVDAO().getDomesticBankList();

		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		for (DomesticBank parm : beneficiaryBankList) {
			// ParameterValue parm=(ParameterValue)paramValues;
			System.out.println("SelectItem=========" + parm.getBankName());
			list.add(new SelectItem(parm.getIbanClearingCode()
					+ parm.getBankCode() + parm.getBankBic()
					+ parm.getBankName(), parm.getBankName()));
		}
		return list;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.controller.CRUDController#detailSetup()
	 */
	public String detailSetup() {
		beneficiaryname = "";
		beneficiaryprofitcent = "";
		beneficiaryactstuts = "";
		// Get the Item to be passed to Detail page
		item = (Ppm_Instructions) this.getPaymentInstructionTable()
				.getRowData();
		if (item.getInstReference().equals(new BigDecimal(8))) {

			return getClass().getSimpleName() + "_black_list_query";
		}
		// Forward to detail Navigation case
		return getClass().getSimpleName() + "_detail";
	}

	public String listSetup() {
		System.out.println("itemSize-----" + itemSize);
		System.out.println("btnType" + btnType);
		if (btnType != null && btnType.equalsIgnoreCase("CNL")) {
			instStatus = "Cancelled";
			System.out.println("instStatus==" + instStatus);
		}
		// getInstResults();
		samaReference = "";
		instReferencqueue = "";
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/** List of Inquiry */
	public String listInquerySetup() {
		System.out.println("listInquerySetup====");
		instReferencqueue = "";
		samaReference = "";
		totalAmount = null;
		accountCpt = "";
		firstInstDate = null;
		lastInstDate = null;
		status = "";
		return getClass().getSimpleName()
				+ IConstants.CRUD_INQUERY_LIST_NAVIGATION;
	}

	/** List of Inquiry jasper report */
	public String listJasperReport() {
		System.out.println("listInquerySetup====");
		instReferencqueue = "";
		samaReference = "";
		totalAmount = null;
		accountCpt = "";
		firstInstDate = null;
		lastInstDate = null;
		status = "";
		return getClass().getSimpleName()
				+ IConstants.CRUD_TRNS_LIST_NAVIGATION;
	}

	/** List of Maintanence */
	public String listMaintanenceSetup() {
		listMaintenence = null;
		itemSizeMain = 0;
		accountCpt = "";
		btnType = "";
		return getClass().getSimpleName()
				+ IConstants.CRUD_MAINTENENCE_LIST_NAVIGATION;
	}

	/** List of MaintValidate */
	public String listMaintValidateSetup() {
		listMaintVali = null;
		itemSizeMain = 0;
		instReferencqueue = "";
		modifyRefe = "";
		return getClass().getSimpleName()
				+ IConstants.CRUD_MAINTVALIDATE_LIST_NAVIGATION;
	}

	/*
	 * Edit page of Instruction Inquiry
	 */
	public String editSetup() {
		System.out.println("editSetup==");
		// Get the Item to be passed to Edit page
		itemItemDtl = (InstructionListValues) this.getPaymentInstructionTable().getRowData();
		if(!"P".equals(itemItemDtl.getInstReference().substring(0, 1))){
		getcustAccountDetailsEdit(itemItemDtl);
		getBeneficiarycustAccountDetailsEdit(itemItemDtl);
		getStatusList(itemItemDtl);
		// readSamaDocFile();
		if (itemItemDtl.getInstReference().equals(new BigDecimal(8))) {

			return getClass().getSimpleName() + "_black_list_query";
		}
		}
		// Forward to edit Navigation case
		return getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
	}

	/*
	 * Edit page of Instruction Validation
	 */
	public String editValidationSetup() {
		// Get the Item to be passed to Edit page
		itemItemDtl = (InstructionListValues) this.getPaymentInstructionTable()
				.getRowData();
		validatorComment = "";
		getcustAccountDetailsEdit(itemItemDtl);
		getBeneficiarycustAccountDetailsEdit(itemItemDtl);
		getStatusList(itemItemDtl);
		// readSamaDocFile();
		if (itemItemDtl.getInstReference().equals(new BigDecimal(8))) {

			return getClass().getSimpleName() + "_black_list_query";
		}
		// Forward to edit Navigation case
		return getClass().getSimpleName()
				+ IConstants.CRUD_EDIT_VALIDATION_NAVIGATION;
	}

	/*
	 * Edit page of Instruction Modify
	 */
	public String editModifySetup() {

		// Get the Item to be passed to Edit page
		initComment = "";
		samaReference = "";
		docDateH = null;
		docDateHStrFrmt = "";
		docReceivingDateHStrFrmt = "";
		docReceivingDateH = null;
		docDateHStr = "";
		docReceivingDateHStr = "";
		item = new Ppm_Instructions();
		itemItemDtl = (InstructionListValues) this.getPaymentInstructionTable()
				.getRowData();
		getcustAccountDetailsEdit(itemItemDtl);
		getBeneficiarycustAccountDetailsEdit(itemItemDtl);
		getStatusList(itemItemDtl);

		if (itemItemDtl.getInstReference().equals(new BigDecimal(8))) {

			return getClass().getSimpleName() + "_black_list_query";
		}
		// Forward to edit Navigation case
		return getClass().getSimpleName()
				+ IConstants.CRUD_EDIT_MODIFY_NAVIGATION;
	}

	/*
	 * Edit page of Instruction
	 */
	public String editMaintValidateSetup() {
		validatorComment = "";
		// Get the Item to be passed to Edit page
		itemItemDtl = (InstructionListValues) this.getPaymentInstructionTable()
				.getRowData();
		getcustAccountDetailsEdit(itemItemDtl);
		getBeneficiarycustAccountDetailsEdit(itemItemDtl);
		getStatusList(itemItemDtl);
		// readSamaDocFile();
		if (itemItemDtl.getInstReference().equals(new BigDecimal(8))) {
			return getClass().getSimpleName() + "_black_list_query";
		}
		// Forward to edit Navigation case
		return getClass().getSimpleName()
				+ IConstants.CRUD_EDIT_MAINT_VALIDATE_NAVIGATION;
	}

	/* Maintenance Modify button action */
	public String updateModifyInst() {
		try {
			String instReference = itemItemDtl.getInstReference();
			item = getInstructionDAO().getById(instReference.toString());
			statusfromItst = item.getStatus();
			changeBy = JSFUtil.getLoggedInUserInfo().getUserId();
			item.setInitComment(initComment);
			item.setUpdatedBy(JSFUtil.getLoggedInUserInfo().getUserId());
			item.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
			item.setStatus("SUI");
			itemDetail = getInstructionDAO().getInstructionDetails(
					instReference);
			Long instDtlId = itemItemDtl.getInstDtlId();
			String oldSamaRef = itemItemDtl.getSamaReference();
			String oldStartDate = itemItemDtl.getStartDateH();
			String oldRecDate = itemItemDtl.getEndDateH();
			String oldsamaDocFile = itemItemDtl.getRelatedDoc();
			Long id = getInstModifyDAO().getInstModifyIdSeqGen();
			if (samaReference != null && !samaReference.equals("")) {

				instModfy.setId(id);
				instModfy.setInstDtlId(instDtlId);
				instModfy.setInstRefer(instReference);
				instModfy.setModifiedBy(JSFUtil.getLoggedInUserInfo()
						.getUserId());
				instModfy.setModifiedDate(new Timestamp(System
						.currentTimeMillis()));
				instModfy.setIsApplied("N");
				instModfy.setOldValue(oldSamaRef);
				instModfy.setNewVlaue(samaReference);
				instModfy.setFieldName("RELATED_REFERENCE");
				getInstModifyDAO().saveInstModify(instModfy);
			}
			if (docDateHStrFrmt != null && !docDateHStrFrmt.equals("")) {
				instModfy = new InstructionsModify();
				// Long id=getInstModifyDAO().getInstModifyIdSeqGen();
				instModfy.setId(id);
				instModfy.setInstDtlId(instDtlId);
				instModfy.setInstRefer(instReference);
				instModfy.setModifiedBy(JSFUtil.getLoggedInUserInfo()
						.getUserId());
				instModfy.setModifiedDate(new Timestamp(System
						.currentTimeMillis()));
				instModfy.setIsApplied("N");
				instModfy.setOldValue(oldStartDate);
				instModfy.setNewVlaue(docDateHStrFrmt);
				instModfy.setFieldName("DOC_DATE");
				getInstModifyDAO().saveInstModify(instModfy);
			}
			if (docReceivingDateHStrFrmt != null
					&& !docReceivingDateHStrFrmt.equals("")) {
				instModfy = new InstructionsModify();
				// Long id=getInstModifyDAO().getInstModifyIdSeqGen();
				instModfy.setId(id);
				instModfy.setInstDtlId(instDtlId);
				instModfy.setInstRefer(instReference);
				instModfy.setModifiedBy(JSFUtil.getLoggedInUserInfo()
						.getUserId());
				instModfy.setModifiedDate(new Timestamp(System
						.currentTimeMillis()));
				instModfy.setIsApplied("N");
				instModfy.setOldValue(oldRecDate);
				instModfy.setNewVlaue(docReceivingDateHStrFrmt);
				instModfy.setFieldName("DOC_RCV_DATE");
				getInstModifyDAO().saveInstModify(instModfy);
			}
			if (fname != null && !fname.equals(oldsamaDocFile)) {
				instModfy = new InstructionsModify();
				// Long id=getInstModifyDAO().getInstModifyIdSeqGen();
				instModfy.setId(id);
				instModfy.setInstDtlId(instDtlId);
				instModfy.setInstRefer(instReference);
				instModfy.setModifiedBy(JSFUtil.getLoggedInUserInfo()
						.getUserId());
				instModfy.setModifiedDate(new Timestamp(System
						.currentTimeMillis()));
				instModfy.setIsApplied("N");
				if (oldsamaDocFile != null) {
					instModfy.setOldValue(oldsamaDocFile);
				}
				instModfy.setNewVlaue(fname);
				instModfy.setFieldName("RELATED_DOC");
				getInstModifyDAO().saveInstModify(instModfy);
			}

			getInstructionDAO().save(item);
			// getStatusHistoryDAO().insertStatusHisttory(itemItemDtl,changeBy,statusfromItst,"MOD");
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		btnType = "";
		fname = "";
		selectCalendarTypRadio = "G";
		// FacesContext.getCurrentInstance().addMessage("calanderType", new
		// FacesMessage("Success: Instruction Modified, sent for Approval"));
		// return getClass().getSimpleName()
		// +IConstants.CRUD_MAINTENENCE_LIST_NAVIGATION;
		return getClass().getSimpleName() + "_reportModify";
	}

	/* Maintenance Suspend button action */
	public String updateSuspendInst() {
		FacesMessage message = null;
		if (samaReference != null && !samaReference.equals("")) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			if ((docDateH != null && !"".equals(docDateH))
					|| docDateHStr != null && !"".equals(docDateHStr)) {
				if ((docDateH != null && !"".equals(docDateH))) {
					docDateHStrFrmt = dateFormat.format(docDateH);
					if (docDateH.after(currentDate)) {
						message = JSFUtil.getMessage(FacesContext
								.getCurrentInstance(),
								"bundles.ValidatorMessages", "startingDateG",
								FacesMessage.SEVERITY_ERROR);
						FacesContext.getCurrentInstance().addMessage(
								"startingDateG", message);
						return "";
					}
				}
			} else {
				message = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
						"bundles.ValidatorMessages", "vDate.chars.number",
						FacesMessage.SEVERITY_ERROR);
				FacesContext.getCurrentInstance().addMessage("startingDateG",
						message);
				return "";

			}
			if ((docReceivingDateH != null && !"".equals(docReceivingDateH))
					|| docReceivingDateHStr != null
					&& !"".equals(docReceivingDateHStr)) {
				if ((docReceivingDateH != null && !"".equals(docReceivingDateH))) {
					docReceivingDateHStrFrmt = dateFormat
							.format(docReceivingDateH);
					if (docReceivingDateH.after(currentDate)) {
						message = JSFUtil.getMessage(FacesContext
								.getCurrentInstance(),
								"bundles.ValidatorMessages", "receivingDateG",
								FacesMessage.SEVERITY_ERROR);
						FacesContext.getCurrentInstance().addMessage(
								"startingDateG", message);
						return "";
					}
				}
			} else {
				message = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
						"bundles.ValidatorMessages",
						"vReceivingMonth.chars.number",
						FacesMessage.SEVERITY_ERROR);
				FacesContext.getCurrentInstance().addMessage("receivingDateG",
						message);
				return "";
			}
			if (fname == null || "".equals(fname)) {
				message = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
						"bundles.ValidatorMessages", "fileNotUploded",
						FacesMessage.SEVERITY_ERROR);
				FacesContext.getCurrentInstance().addMessage("receivingDateG",
						message);
				return "";
			}
			if (docDateHStr != null && !"".equals(docDateHStr)
					&& docDateHStr.length() > 0) {
				docDateHStrFrmt = docDateHStr.replace("/", "");
			}

			if (docReceivingDateHStr != null
					&& !"".equals(docReceivingDateHStr)
					&& docReceivingDateHStr.length() > 0) {
				docReceivingDateHStrFrmt = docReceivingDateHStr
						.replace("/", "");
			}
			System.out.println("docDateHStrFrmt==" + docDateHStrFrmt);
			if (!"".equals(docDateHStrFrmt)
					&& new Integer(docDateHStrFrmt) >= 8) {
				String mm = docDateHStrFrmt.substring(4, 6);
				String dd = docDateHStrFrmt.substring(7, 8);
				System.out.println("Months---" + docDateHStr);
				System.out.println("mm---" + mm);
				System.out.println("dd---" + dd);
				try {
					if (new Integer(mm) > 12) {
						message = JSFUtil.getMessage(FacesContext
								.getCurrentInstance(),
								"bundles.ValidatorMessages", "vMonth.chars",
								FacesMessage.SEVERITY_ERROR);
						FacesContext.getCurrentInstance().addMessage(
								"startingDateH", message);
						return "";
					}
				} catch (NumberFormatException nfe) {
					FacesContext.getCurrentInstance().getApplication()
							.setMessageBundle("bundles.ValidatorMessages");
					message = MessageFactory.getMessage(FacesContext
							.getCurrentInstance(), "vMonth.chars.number",
							FacesMessage.SEVERITY_ERROR);
					throw new ValidatorException(message);
				}
				try {
					if (new Integer(dd) > 31) {
						message = JSFUtil.getMessage(FacesContext
								.getCurrentInstance(),
								"bundles.ValidatorMessages", "vDate.chars",
								FacesMessage.SEVERITY_ERROR);
						FacesContext.getCurrentInstance().addMessage(
								"startingDateH", message);
						return "";
					}
				} catch (NumberFormatException nfe) {
					FacesContext.getCurrentInstance().getApplication()
							.setMessageBundle("bundles.ValidatorMessages");
					message = MessageFactory.getMessage(FacesContext
							.getCurrentInstance(), "vMonth.chars.number",
							FacesMessage.SEVERITY_ERROR);
					throw new ValidatorException(message);
				}
			} else {
				message = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
						"bundles.ValidatorMessages", "docDateHStr.chars",
						FacesMessage.SEVERITY_ERROR);
				FacesContext.getCurrentInstance().addMessage("startingDateH",
						message);
				return "";
			}
			if (!"".equals(docReceivingDateHStrFrmt)
					&& new Integer(docReceivingDateHStrFrmt) >= 8) {
				String mm = docReceivingDateHStrFrmt.substring(4, 6);
				String dd = docReceivingDateHStrFrmt.substring(7, 8);
				System.out.println("Months---" + docReceivingDateHStr);
				System.out.println("mm---" + mm);
				System.out.println("dd---" + dd);
				try {
					if (new Integer(mm) > 12) {
						message = JSFUtil.getMessage(FacesContext
								.getCurrentInstance(),
								"bundles.ValidatorMessages",
								"vReceivingMonth.chars",
								FacesMessage.SEVERITY_ERROR);
						FacesContext.getCurrentInstance().addMessage(
								"docReceivingDateHStr", message);
						return "";
					}
				} catch (NumberFormatException nfe) {
					FacesContext.getCurrentInstance().getApplication()
							.setMessageBundle("bundles.ValidatorMessages");
					message = MessageFactory.getMessage(FacesContext
							.getCurrentInstance(),
							"vReceivingMonth.chars.number",
							FacesMessage.SEVERITY_ERROR);
					throw new ValidatorException(message);
				}
				try {
					if (new Integer(dd) > 31) {
						message = JSFUtil.getMessage(FacesContext
								.getCurrentInstance(),
								"bundles.ValidatorMessages",
								"vReceivingDate.chars",
								FacesMessage.SEVERITY_ERROR);
						FacesContext.getCurrentInstance().addMessage(
								"docReceivingDateHStr", message);
						return "";
					}
				} catch (NumberFormatException nfe) {
					FacesContext.getCurrentInstance().getApplication()
							.setMessageBundle("bundles.ValidatorMessages");
					message = MessageFactory.getMessage(FacesContext
							.getCurrentInstance(),
							"vReceivingMonth.chars.number",
							FacesMessage.SEVERITY_ERROR);
					throw new ValidatorException(message);
				}
			} else {
				message = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
						"bundles.ValidatorMessages",
						"docReceivingDateHStr.chars",
						FacesMessage.SEVERITY_ERROR);
				FacesContext.getCurrentInstance().addMessage(
						"docReceivingDateHStr", message);
				return "";
			}

		} else if (((docDateH != null && !"".equals(docDateH)) || (docDateHStr != null && !""
				.equals(docDateHStr)))
				|| ((docReceivingDateH != null && !"".equals(docReceivingDateH)) || (docReceivingDateHStr != null && !""
						.equals(docReceivingDateHStr)))
				|| (fname != null && !"".equals(fname))) {
			message = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
					"bundles.ValidatorMessages", "modifyFieldsRequired",
					FacesMessage.SEVERITY_ERROR);
			FacesContext.getCurrentInstance().addMessage("startingDateG",
					message);
			return "";
		} else if (((docDateH == null || "".equals(docDateH)) && (docDateHStr == null || ""
				.equals(docDateHStr)))
				&& ((docReceivingDateH == null || "".equals(docReceivingDateH)) && (docReceivingDateHStr == null || ""
						.equals(docReceivingDateHStr)))
				&& (fname == null || "".equals(fname))) {
			message = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
					"bundles.ValidatorMessages", "modifyFieldsRequired",
					FacesMessage.SEVERITY_ERROR);
			FacesContext.getCurrentInstance().addMessage("startingDateG",
					message);
			return "";
		}
		String instReference = itemItemDtl.getInstReference();
		System.out.println("btnType==" + btnType);
		try {
			item = getInstructionDAO().getById(instReference.toString());
			itemDetail = getInstructionDAO().getInstructionDetails(
					instReference);
			Long instDtlId = itemItemDtl.getInstDtlId();
			Long id = getInstModifyDAO().getInstModifyIdSeqGen();
			instModfy = new InstructionsModify();
			updateModifyInst();
			getStatusHistoryDAO().insertStatusHisttory(itemItemDtl, changeBy,
					statusfromItst, "SUI");

		} catch (DAOException daoe) {
			daoe.printStackTrace();
		}
		FacesContext.getCurrentInstance().addMessage(
				"calanderType",
				new FacesMessage(
						"Success :Instruction Suspended, sent for Approval"));
		btnType = "";
		return getClass().getSimpleName() + "_reportSuspended";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.controller.CRUDController#createSetup()
	 */
	public String createSetup() {
		String benAccCrncy = "";
		String accAccCrncy = "";
		if (accountInqRes != null && benaccountInqRes != null) {
			if (accountInqRes.getFtsActionCode().equals("0000")
					&& benaccountInqRes.getFtsActionCode().equals("0000")) {
				accAccCrncy = accountInqRes.getAccountCurrency();
				benAccCrncy = benaccountInqRes.getAccountCurrency();
			}
		}
		if ((beneficiaryacc != null && !"".equals(beneficiaryacc))
				&& !accAccCrncy.equals(benAccCrncy)) {
			System.out.println("Cross Currency");
		} else {
			accountNo = "";
			customerName = "";
			actstatus = "";
			profitCenter = "";
			accountstatusdesc = "";
			beneficiaryacc = "";
			beneficiaryname = "";
			nonBsfbeneficiaryname = "";
			beneficiaryactstuts = "";
			beneficiaryprofitcent = "";
			samaReference = "";
			docDateH = null;
			docReceivingDateH = null;
			docDateHStrFrmt = "";
			docReceivingDateHStrFrmt = "";
			frequencey = "";
			selectedBankName = "";
			firstInstDate = null;
			lastInstDate = null;
			monthlyAmount = null;
			numberofInst = null;
			totalAmount = null;
			dayofPayment = null;
			// selectoneRadioValue=new Boolean(false);
			beneficiaryaddress = "";
			beneficiaryBankaddress = "";
			beneficiaryPaymentDtls = "";
			initComment = "";
			fname = "";
			selectCalendarTypRadio = "G";
			item = new Ppm_Instructions();
			itemDetail = new InstructionDetails();
			// Forward to create Navigation case

		}
		return getClass().getSimpleName() + "_create";
	}

	/* Edit validation Instruction update */
	public String update() {

		try {

			// List<StatusHistory> ShList
			// =getInstructionDAO().getStatusHistoryRecords(itemItemDtl.getInstReference());
			item = getInstructionDAO().getById(
					itemItemDtl.getInstReference().toString());
			System.out.println("itemDetail---"+itemItemDtl.getInstReference());
			itemDetail = getInstructionDAO().getInstructionDetails(
					itemItemDtl.getInstReference());
			statusfromItst = item.getStatus();
			changeBy = JSFUtil.getLoggedInUserInfo().getUserId();
			item.setValidatedDate(new Timestamp(System.currentTimeMillis()));
			item.setValidatdBy(JSFUtil.getLoggedInUserInfo().getUserId());
			item.setValidatorComment(validatorComment);
			item.setValidatdBy(JSFUtil.getLoggedInUserInfo().getUserId());
			item.setValidatedDate(new Timestamp(System.currentTimeMillis()));
			item.setStatus(btnType);
			log.info("Calling update method");
			getInstructionDAO().saveOrUpdate(item);
			log.info("Ppm_Instructions table updated successfully..");
			getStatusHistoryDAO().insertStatusHisttory(itemItemDtl, changeBy,
					statusfromItst, btnType);
			log.info("Ppm_Status_History table updated successfully..");
			if (btnType.equalsIgnoreCase("ACT")) {
				instStatus = "Accepted";
			}
			if (btnType.equalsIgnoreCase("RJT")) {
				instStatus = "Rejected";
			}
		} catch (Exception daoe) {
			log
					.warn(
							"Trying to update Ppm_Instructions and Ppm_Status_History table getting error ",
							daoe);
			daoe.printStackTrace();
		}
		log.info("Outside update method");
		FacesContext.getCurrentInstance().addMessage("calanderType",
				new FacesMessage("Success :Validation report generated"));
		btnType = "";

		return getClass().getSimpleName() + "_reportValidAcpt";
	}

	/*
	 * Maintain Validate in case of accept update old values with new values of
	 * InstructionDetails table and Instruction Modify table
	 */
	public String updateMaintValidate() {
		String fieldName = "";
		try {
			// InstructionListValues instructionListValues=new
			// InstructionListValues();
			item = getInstructionDAO().getById(
					itemItemDtl.getInstReference().toString());
			statusfromItst = item.getStatus();
			item.setValidatedDate(new Timestamp(System.currentTimeMillis()));
			item.setValidatdBy(JSFUtil.getLoggedInUserInfo().getUserId());
			item.setValidatorComment(validatorComment);
			item.setValidatdBy(JSFUtil.getLoggedInUserInfo().getUserId());
			item.setValidatedDate(new Timestamp(System.currentTimeMillis()));
			log.info("Calling update method");
			getInstructionDAO().saveOrUpdate(item);
			log.info("Ppm_Instructions table updated successfully..");
			log.info("Outside update method");
			changeBy = JSFUtil.getLoggedInUserInfo().getUserId();
			fieldName = itemItemDtl.getFieldName();
			System.out.println("itemItemDtl.getFilePath()===="
					+ itemItemDtl.getFilePath());
			itemDetail = getInstructionDAO().getInstructionDetails(
					itemItemDtl.getInstReference());
			instModfy = getInstModifyDAO().updateInstModify(itemItemDtl,
					btnType);
			instModfy
					.setApprovedDate(new Timestamp(System.currentTimeMillis()));
			// itemItemDtl
			String docDate = itemDetail.getDocDate();
			System.out.println("docDate===" + docDate);
			String year = "";
			String month = "";
			String days = "";
			if (docDate != null && !"".equals(docDate)) {
				year = docDate.substring(0, 4);
				month = docDate.substring(4, 6);
				days = docDate.substring(6, 8);
			}
			docDate = year + "/" + month + "/" + days;
			itemDetail.setDocDate(docDate);
			instStatus = "Accepted";
			FacesContext
					.getCurrentInstance()
					.addMessage(
							"calanderType",
							new FacesMessage(
									"Success :Instruction Suspend request has been Accepted successfully"));
			getStatusHistoryDAO().insertStatusHisttory(itemItemDtl, changeBy,
					statusfromItst, "SUS");
		} catch (DAOException de) {
			de.printStackTrace();
		}
		return getClass().getSimpleName() + "_reportMaintValidate";
	}

	/*
	 * Maintain Validate in case of reject, update Instruction Modify isApplied
	 * field with R
	 */
	public String rejectInstModify() {
		String fieldName = "";
		try {
			fieldName = itemItemDtl.getFieldName();
			item = getInstructionDAO().getById(
					itemItemDtl.getInstReference().toString());
			statusfromItst = item.getStatus();
			changeBy = JSFUtil.getLoggedInUserInfo().getUserId();
			itemDetail = getInstructionDAO().getInstructionDetails(
					itemItemDtl.getInstReference());
			getInstModifyDAO().rejectInstModify(itemItemDtl);
			instModfy.setApprovedDate(new Timestamp(System.currentTimeMillis()));
			item.setValidatorComment(validatorComment);
			item.setValidatdBy(JSFUtil.getLoggedInUserInfo().getUserId());
			item.setValidatedDate(new Timestamp(System.currentTimeMillis()));
			item.setStatus("ACT");
			log.info("Calling update method");
			getInstructionDAO().saveOrUpdate(item);
			getStatusHistoryDAO().insertStatusHisttory(itemItemDtl, changeBy,
					statusfromItst, "RJT");
			log
					.info("Ppm_Instructions and Ppm_Status_History table updated successfully..");
			log.info("Outside update method");
		} catch (DAOException de) {
			log
					.warn(
							"Tring to update Ppm_Instructions update isApplied field as R getting error ",
							de);
			de.printStackTrace();
		}
		instStatus = "Rejected";
		// if(fieldName!=null&&fieldName.equals("SUS")){
		FacesContext
				.getCurrentInstance()
				.addMessage(
						"calanderType",
						new FacesMessage(
								"Success :Instruction Suspend request has been Rejected successfully"));
		return getClass().getSimpleName() + "_reportMaintValidate";
	}

	/* Instructions capture method */
	public String create() {
		String instActionTyp = "";
		String accAccCrncy = "";
		String accBranch = "";
		String benAccCrncy = "";
		Long ppminstref = null;
		Long instDtlId = null;
		FacesMessage message = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		if ((docDateH != null && !"".equals(docDateH))
				&& (docReceivingDateH != null && !"".equals(docReceivingDateH))) {
			docDateHStrFrmt = dateFormat.format(docDateH);
			docReceivingDateHStrFrmt = dateFormat.format(docReceivingDateH);
			if (docDateH.after(currentDate)) {
				message = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
						"bundles.ValidatorMessages", "startingDateG",
						FacesMessage.SEVERITY_ERROR);
				FacesContext.getCurrentInstance().addMessage("startingDateG",
						message);
				return "";
			}
			if (docReceivingDateH.after(currentDate)) {
				message = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
						"bundles.ValidatorMessages", "receivingDateG",
						FacesMessage.SEVERITY_ERROR);
				FacesContext.getCurrentInstance().addMessage("startingDateG",
						message);
				return "";
			}
		}
		if ((docDateHStr != null && !"".equals(docDateHStr))
				&& (docReceivingDateHStr != null && !""
						.equals(docReceivingDateHStr))) {
			docDateHStrFrmt = docDateHStr.replace("/", "");
			docReceivingDateHStrFrmt = docReceivingDateHStr.replace("/", "");
			System.out.println("docDateHStrFrmt==" + docDateHStrFrmt);

		}
		String timestamp = new String(dateFormat.format(new java.util.Date()));
		itemDetail = new InstructionDetails();
		statusHis = new ArrayList<StatusHistory>();

		if (dayofPayment != null && dayofPayment != 0) {
			Integer dayOfPayInt = dayofPayment.intValue();
			System.out.println("dayOfPayInt==" + dayOfPayInt);
			if (dayOfPayInt > 31) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"dayOfPaymentMoreThanError",
						FacesMessage.SEVERITY_ERROR);
				FacesContext.getCurrentInstance().addMessage("dayofPayment",
						facesMessage);
				return "";
			} else {
				item.setDayofPayment(dayofPayment);
			}
		} else {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"dayOfPaymentError", FacesMessage.SEVERITY_ERROR);
			FacesContext.getCurrentInstance().addMessage("dayofPayment",
					facesMessage);
			return "";
		}
		System.out.println("beneficiaryacc==++===" + beneficiaryacc);
		System.out.println("beneficiaryname===++==" + beneficiaryname);
		System.out
				.println("nonBsfbeneficiaryacc===++==" + nonBsfbeneficiaryacc);
		System.out.println("nonBsfbeneficiaryname==++==="
				+ nonBsfbeneficiaryname);

		// for BSF Beneficiary Account
		if (beneficiaryacc != null && !"".equals(beneficiaryacc)) {
			instActionTyp = "AATR";
			itemDetail.setBenAcc(getBeneficiaryacc().toUpperCase());
			itemDetail.setBenName(beneficiaryname);
			itemDetail.setBenPftCtr(beneficiaryprofitcent);
			itemDetail.setAccountstatus(beneficiaryactstuts);
			itemDetail.setBenAccCrncy(benAccCrncy);
			// beneficiaryacc="";
		}
		// for non BSF Beneficiary Account
		if ((nonBsfbeneficiaryacc != null && !"".equals(nonBsfbeneficiaryacc))
				&& getNonBSFBeneficiarycustAccountDetails()) {
			instActionTyp = "TTAC";
			itemDetail.setBenAcc(nonBsfbeneficiaryacc);
			itemDetail.setBenName(nonBsfbeneficiaryname);
			String bankCodeIban = nonBsfbeneficiaryacc.substring(4, 6);
			String benBankCountry = nonBsfbeneficiaryacc.substring(0, 2);
			System.out.println("benBankCountry==" + benBankCountry);
			System.out.println("bankCodeIban=" + bankCodeIban);
			String seleBank = selectedBankName.substring(0, 2);
			String benBankCode = selectedBankName.substring(2, 6);
			String banBankName = selectedBankName.substring(6, 17);
			String banBanFullName = selectedBankName.substring(17);
			System.out.println("seleBank==" + seleBank);
			System.out.println("benBankCode==" + benBankCode);
			System.out.println("banBankName==" + banBankName);

			// Beneficiary Bank field validation
			if ("select".equals(seleBank)) {

				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"benBankNotSelected", FacesMessage.SEVERITY_ERROR);
				FacesContext.getCurrentInstance().addMessage(
						"selectedBankName", facesMessage);
				return "";

			} else {
				if (bankCodeIban.equals(seleBank)) {
					itemDetail.setBenBankCode(seleBank);
				} else {

					facesMessage = JSFUtil.getMessage(FacesContext
							.getCurrentInstance(), "bundles.UIMessages",
							"benIbanbenBakMissMatch",
							FacesMessage.SEVERITY_ERROR);
					FacesContext.getCurrentInstance().addMessage(
							"selectedBankName", facesMessage);
					return getClass().getSimpleName() + "_create";
				}
			}
			System.out.println("banBanFullName==" + banBanFullName);
			itemDetail.setBanBankName(banBankName);
			itemDetail.setBenBankCountry(benBankCountry);
			itemDetail.setBenBank(benBankCode);
			itemDetail.setBenAddress(beneficiaryaddress);
			itemDetail.setBenBankAddress1(beneficiaryBankaddress);
			itemDetail.setBenBankAddress2(banBanFullName);
			itemDetail.setPaymentDtls(beneficiaryPaymentDtls);

		}
		try {
			//Allowed Account Status For debit account
			parameterValue = getParameterVDAO().getAccountType("DRACTSTUS");
			debitActDBFlag=false;
			System.out.println("debitActDBFlag=="+debitActDBFlag);
			if (parameterValue.size()>0) {
				for (ParameterValue parmaValue : parameterValue) {
					acctTypeFromDB = parmaValue.getValue1();
					if (customerAcctFlag && (acctTypeFromDB.trim().equalsIgnoreCase(actStatusTux.trim()))) {
						debitActDBFlag = true;
						System.out.println("eQUALS");
						break;
					}
				}
				
			}
			else{
			debitActDBFlag=true;	
			}
			
			
			// Customer Account Status checking
			if ((!"".equals(actStatusTux))&& !debitActDBFlag && customerAcctFlag) {
					FacesContext.getCurrentInstance().addMessage(
							"actstatus",
							new FacesMessage("Customer Account Status:"	+actstatus));
					debitActDBFlag=false;
					return "";
			}
			
			//Allowed Account Status For credit account (Only if it is BSF account - AATR case only)
			parameterValue = getParameterVDAO().getAccountType("CRACTSTUS");
			creditActDBFlag=false;
			if (parameterValue.size()>0) {
				for (ParameterValue parmaValue : parameterValue) {
					acctTypeFromDB = parmaValue.getValue1();

					// Beneficiary Account Status and Account Type checking
					if (bsfBeneFiciAcctFlag	&& (acctTypeFromDB.trim().equalsIgnoreCase(beneficiaryactstutsTux.trim()))) {
						creditActDBFlag= true;
						System.out.println("creditActDBFlag=="+creditActDBFlag);
						break;
					}
								
				}
				
			}
			else{
			creditActDBFlag=true;	
			}
			// Beneficiary Account Status checking
			 if (!"".equals(beneficiaryactstutsTux)&& !creditActDBFlag && bsfBeneFiciAcctFlag) {
				FacesContext.getCurrentInstance().addMessage("beneficiaryactstuts",new FacesMessage("Beneficiary Account Status:"+ beneficiaryactstutsTux));
				creditActDBFlag=false;
				return "";
			}
			
			//Allowed account type For debit account
			parameterValue = getParameterVDAO().getAccountType("DBACTTYP");
			flagStatus=false;
			if (parameterValue.size()>0) {
			       for (ParameterValue parmaValue : parameterValue) {
					acctTypeFromDB = parmaValue.getValue1();
					
					if (customerAcctFlag&& (acctTypeFromDB.trim().equalsIgnoreCase(debitAcctType.trim()))) {
						flagStatus = true;
						System.out.println("eQUALS");
						break;
					}
		   }
				if (!flagStatus) {
					FacesContext.getCurrentInstance().addMessage(
							"calanderType",
							new FacesMessage("Debit Account type not supported"));
					return "";
				}
			}
			
			
		//Allowed account type For credit account
		if(bsfBeneFiciAcctFlag){	
		parameterValue = getParameterVDAO().getAccountType("CRACTTYP");
		flagStatus=false;
		if (parameterValue != null&&parameterValue.size()>0) {
		    	for (ParameterValue parmaValue : parameterValue) {
				acctTypeFromDB = parmaValue.getValue1();
			
				if (creditAcctType!=null&&bsfBeneFiciAcctFlag&&(acctTypeFromDB.trim().equalsIgnoreCase(creditAcctType.trim()))){
					flagStatus = true;
					System.out.println("eQUALS");
					break;
				}
			}
			if (!flagStatus) {
				FacesContext.getCurrentInstance().addMessage(
						"calanderType",
						new FacesMessage("Credit Account type not supported"));
				return "";
			}
		}
		}
		
		//Allowed Product type For debit account
		parameterValue = getParameterVDAO().getAccountType("DBACTPRDT");	
		if (parameterValue != null&&parameterValue.size()>0) {
			for (ParameterValue parmaValue : parameterValue) {
				acctTypeFromDB = parmaValue.getValue1();
				if (customerAcctFlag
						&& (acctTypeFromDB.trim().equalsIgnoreCase(productType
								.trim()))) {
					flagStatus = true;
					System.out.println("eQUALS");
					break;
				}
			}
			if (!flagStatus) {
				FacesContext.getCurrentInstance().addMessage(
						"calanderType",
						new FacesMessage("Product Type not supported"));
				return "";
			}
		}
		//Allowed Product type For credit account
		
		parameterValue = getParameterVDAO().getAccountType("CRACTPRDT");	
		if (parameterValue != null&&parameterValue.size()>0) {
			for (ParameterValue parmaValue : parameterValue) {
				acctTypeFromDB = parmaValue.getValue1();
				if (bsfBeneFiciAcctFlag
						&& (acctTypeFromDB.trim().equalsIgnoreCase(productType
								.trim()))) {
					flagStatus = true;
					System.out.println("eQUALS");
					break;
				}
			}
			if (!flagStatus) {
				FacesContext.getCurrentInstance().addMessage(
						"calanderType",
						new FacesMessage("Product Type not supported"));
				return "";
			}
		}
		
		
		//Max day rang from Database
		parameterValue=getParameterVDAO().getMaxDayRangAndTrgrNextCyclDay("EXEPERIOD");
		if (parameterValue != null&&parameterValue.size()>0) {
		maxDayRang=parameterValue.get(0).getValue1();	
		}
		else{
		maxDayRang="10";	
		}
		//Trigger next cycle day from Database
		parameterValue=getParameterVDAO().getMaxDayRangAndTrgrNextCyclDay("EXECYCLE");
		if (parameterValue != null&&parameterValue.size()>0) {
		trgrNexCycleDay=parameterValue.get(0).getValue1();	
		}
		else{
		trgrNexCycleDay="20";	
		}
		
		} catch (DAOException dox) {
			dox.printStackTrace();
		}
		if ((accountNo == null || "".equals(accountNo))
				&& (getItemDetail().getCustName() == null || ""
						.equals(getItemDetail().getCustName()))) {
			FacesContext.getCurrentInstance().addMessage("calanderType",
					new FacesMessage("Customer Details not Found"));
			return "";
		}

		// Cross-Currency validation for AATR
		if (accountInqRes != null && customerAcctFlag) {
			if (accountInqRes.getFtsActionCode().equals("0000")) {
				accAccCrncy = accountInqRes.getAccountCurrency();
				accBranch = accountInqRes.getAcctBranch();
			}

			if (benaccountInqRes != null && bsfBeneFiciAcctFlag) {

				if (benaccountInqRes.getFtsActionCode().equals("0000")) {
					benAccCrncy = benaccountInqRes.getAccountCurrency();
					if (!accAccCrncy.equals(benAccCrncy)) {

						facesMessage = JSFUtil.getMessage(FacesContext
								.getCurrentInstance(), "bundles.UIMessages",
								"crossCurrencyTrns",
								FacesMessage.SEVERITY_ERROR);
						FacesContext.getCurrentInstance().addMessage(
								"beneficiaryacc", facesMessage);
						return "";
					}
				}
			}
		}
		itemDetail.setBenAccCrncy(accAccCrncy);
		System.out.println("accAccCrncy=====" + accAccCrncy);
		System.out.println("benAccCrncy=====" + benAccCrncy);

		try {
			ppminstref = getInstructionDAO().getPPMReference();
			instDtlId = getInstructionDAO().getInstDetaiSeqGen();
			System.out.println("ppminstref" + ppminstref);
			item.setInstReference(ppminstref.toString());
			itemDetail.setInstDtlId(instDtlId.toString());
		} catch (DAOException dax) {
			dax.printStackTrace();
		}

		// item.setInstId(instId);
		item.setAccNumber(getAccountNo().toUpperCase());
		itemDetail.setCustName(customerName);
		item.setStartDateH(docDateHStrFrmt.toString());
		item.setEndDateH(docReceivingDateHStrFrmt.toString());
		item.setClandertype(selectCalendarTypRadio);

		item.setStartDateG(firstInstDate);
		item.setEndDateG(lastInstDate);
		item.setNoOfInst(getNumberofInst().intValue());
		item.setMonthlyAmoun(monthlyAmount);
		if (totalAmount.compareTo(BigDecimal.ZERO) > 0) {
			item.setTotalAmount(totalAmount);
		} else {

			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"totalAmntZero", FacesMessage.SEVERITY_ERROR);
			FacesContext.getCurrentInstance().addMessage("totalAmount",
					facesMessage);
			return "";
		}

		item.setInstgroupcode("SPP");
		// Frequency field validation
		if ("select".equals(frequencey)) {

			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"frequencyNotSelected", FacesMessage.SEVERITY_ERROR);
			FacesContext.getCurrentInstance().addMessage("frequency",
					facesMessage);
			return "";
		} else {
			item.setFrequency(frequencey);
		}
		// SAMA Letter validation
		if (fname == null || "".equals(fname)) {

			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"fileNotUploded", FacesMessage.SEVERITY_ERROR);
			FacesContext.getCurrentInstance()
					.addMessage("upload", facesMessage);
			return "";
		} else {
			itemDetail.setRelatedDoc(fname);
		}
		item.setStatus("NEW");
		item.setInstActionType(instActionTyp);
		item.setInitComment(initComment);
		item.setCreatedDate(new Timestamp(System.currentTimeMillis()));
		item.setCreatedBy(JSFUtil.getLoggedInUserInfo().getUserId());
		item.setInstProrty(2);
		item.setInstBranch(accBranch);
		item.setExeType("EVENT_TRIGGER");
		item.setNoofBen(1);
		item.setMaxDayRange(maxDayRang);
		item.setEventTriggerOn("EVENTPAY");
		item.setTrgrNextCycleDay(trgrNexCycleDay);
		item.setBalCheck("N");
		item.setBalSweep("N");
		item.setAcctcurcode(accAccCrncy);
		itemDetail.setInstAccNum(getAccountNo().toUpperCase());
		itemDetail.setiDType(iDType);
		itemDetail.setCustIdNumber(custIdNumber);
		itemDetail.setAcctType(debitAcctType);
		itemDetail.setSamaReference(samaReference);
		itemDetail.setDocDate(docDateHStrFrmt.toString());
		itemDetail.setDocRcvDate(docReceivingDateHStrFrmt.toString());
		itemDetail.setInstTrnsTyp("NT");
		itemDetail.setInstAccCrncy(accAccCrncy);
		itemDetail.setInstReference(ppminstref.toString());
		itemDetail.setAccountstatus(getItemDetail().getAccountstatus());
		item.setInstdetails(itemDetail);
		StatusHistory statusHist = new StatusHistory();
		statusHist.setInstReference(ppminstref.toString());
		statusHist.setChangedBy(JSFUtil.getLoggedInUserInfo().getUserId());
		statusHist.setCreatedDate(new Timestamp(System.currentTimeMillis()));
		statusHist.setNewStatus("NEW");
		statusHist.setOldStatus("NEW");
		statusHis.add(statusHist);
		item.setStatusHistory(statusHis);
		
		try {
			/* for AATR /Acct2Acct */
			if (((customerAcctFlag)
					&& (creditActDBFlag)
					&& (debitActDBFlag) && (((beneficiaryacc != null
					&& !"".equals(beneficiaryacc) && beneficiaryacc.length() == 11))
					&& ((beneficiaryname != null && !"".equals(beneficiaryname)))
					&& ((beneficiaryprofitcent != null && !""
							.equals(beneficiaryprofitcent))) && ((beneficiaryactstuts != null && !""
					.equals(beneficiaryactstuts)))))
					|| ((customerAcctFlag)
							&& (nonBsfBenefAcctFlag)
							&& (debitActDBFlag)
							&& ((nonBsfbeneficiaryacc != null && !""
									.equals(nonBsfbeneficiaryacc))) && ((nonBsfbeneficiaryname != null && !""
							.equals(nonBsfbeneficiaryname))))) {
				// if((!"FB".equals(beneficiaryactstuts.trim()))&&("OP".equals(actstatus.trim()))){
				log.info("Trying to call Hibernate saveOrUpdate method for Refrence "+ppminstref);
				getInstructionDAO().saveOrUpdate(item);
				getInstructionDAO().refresh(item);
				log.info("Record saved successfully to Ppm_Instructions and PPM_INSTRUCTIONS_DETAILS table ");
				log.info("outside Hibernate Save method");
				FacesContext.getCurrentInstance().addMessage("calanderType",new FacesMessage("Success :Instruction Report generated"));
				fname = "";
				selectCalendarTypRadio = "G";
				return getClass().getSimpleName() + "_report";
			}
		}

		catch (DAOException dao) {
		log.warn("Trying to save recorde to Ppm_Instructions and PPM_INSTRUCTIONS_DETAILS getting error "+dao);	
		dao.printStackTrace();
		}
		item = new Ppm_Instructions();
		itemDetail = new InstructionDetails();
		//bsfBeneFiciAcctFlag=false;
		// fname="";
		selectCalendarTypRadio = "G";
		return "";
	}

	public boolean isUnique(StatusHistory entity) throws DAOException {
		return true;
	}

	public void getSourSystemList() {
		System.out.println("getSourceSystemList method called");
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		List<ParameterValue> sourSystemList = null;
		try {
			sourSystemList = getParameterVDAO().getSourceSystemList();
			System.out.println("getParameterVDAO()=======");
		} catch (DAOException dex) {
			dex.printStackTrace();
		}
		for (ParameterValue parameterValue : sourSystemList) {

			System.out.println("parameterValue==" + parameterValue.getValue1());
			list.add(new SelectItem(parameterValue.getValue1(), parameterValue
					.getValue1()));
		}
	}

	public void getTransTypeList() {
		System.out.println("getTransTypeList method called");
		List<ParameterValue> transTypeList = null;
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		try {
			System.out
					.println("getParameterVDAO()=======" + getParameterVDAO());
			transTypeList = getParameterVDAO().getFrequencyList();// getTransTypeList();
		}

		catch (DAOException dex) {
			dex.printStackTrace();
		}
		for (ParameterValue parameterValue : transTypeList) {

			System.out.println("parameterValue==" + parameterValue.getValue1());
			list.add(new SelectItem(parameterValue.getValue1(), parameterValue
					.getValue1()));
		}
	}

	@Override
	public List<Ppm_Instructions> getItems() {
		if (items == null) {
			reloadItems();
		}
		return items;
	}

	@Override
	public void setItems(List<Ppm_Instructions> items) {
		this.items = items;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#detailSetup()
	 */
	public String listSetupString() {

		// Initialize default values for SearchCriteria and PageInfo
		/*
		 * if (getSearchCriteria() != null) { setSearchCriteria(new
		 * HashMap<String, Object>());
		 * getSearchCriteria().put(getStatusFieldName(),""); }
		 */
		// Set 0 as the first page
		if (getPageInfo() != null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		reloadItems();
		// returns the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	@Override
	public List<Ppm_Instructions> getSelectedItems() {
		// TODO Auto-generated method stub
		return null;
	}

}
