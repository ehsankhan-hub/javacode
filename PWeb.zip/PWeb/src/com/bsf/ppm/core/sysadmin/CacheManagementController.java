package com.bsf.ppm.core.sysadmin;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.format.Alignment;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Colour;
import jxl.format.UnderlineStyle;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

import com.bsf.ppm.cache.CacheManager;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.spring.SpringAppContext;

public class CacheManagementController {
	private String cacheName;
	private CacheManager staticDataCacheManager;


	public String getCacheName() {
		return cacheName;
	}

	public void setCacheName(String cacheName) {
		this.cacheName = cacheName;
	}


	public CacheManager getStaticDataCacheManager() {
		return staticDataCacheManager;
	}

	public void setStaticDataCacheManager(CacheManager staticDataCacheManager) {
		this.staticDataCacheManager = staticDataCacheManager;
	}

	public String refreshCache() {
		FacesMessage facesMessage=null;
		try {
			if (cacheName != null) {
				staticDataCacheManager.refreshCache(cacheName);
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"cache.refreshsuccess",
						cacheName);
			}
		} catch (Exception e) {
			facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"cache.refresherror", FacesMessage.SEVERITY_ERROR,
					cacheName);


		}
		FacesContext.getCurrentInstance().addMessage(null, facesMessage);
		return "";

	}

	@SuppressWarnings("unchecked")
	public void exportCache(){
		FileInputStream inputStream = null; 
		File file =  null;
		try {
			if (cacheName != null) {
				Cache cache  = (Cache) SpringAppContext.getBean(cacheName);

				List<Object> keys = cache.getKeys();

				WorkbookSettings ws = new WorkbookSettings();
				ws.setLocale(new Locale("en", "EN"));

				FacesContext context = FacesContext.getCurrentInstance(); 
				HttpServletRequest request = (HttpServletRequest)context.getExternalContext().getRequest(); 

				//Need the base URL for the webapp, so 
				String location = request.getRequestURL().toString(); 
				//if your webapp name is bob 
				location = location.substring(0, location.indexOf("/PPM-Web")); 
				location = location + "/PPM-Web";
				//build your filename 
				String filename = "/"+cacheName+".xls"; 
				//Get the real path to the webapp 
				String realPath = ((ServletContext)context.getExternalContext().getContext()).getRealPath("/"); 
				//Create the workbook 
				System.out.println("Fiel path=="+new File(realPath + filename));
				WritableWorkbook workbook = Workbook.createWorkbook(new File(realPath + filename));		
				WritableSheet s = workbook.createSheet("Sheet1", 0);

				/* Format the Font */
				WritableFont wf = new WritableFont(WritableFont.ARIAL, 10, WritableFont.BOLD);
				WritableCellFormat cf = new WritableCellFormat(wf);
				WritableFont times14ptBoldUnderline = new WritableFont
				(WritableFont.TIMES, 12, WritableFont.BOLD, false, UnderlineStyle.SINGLE);
				WritableCellFormat timesBoldUnderline = new WritableCellFormat(times14ptBoldUnderline);
				timesBoldUnderline.setAlignment(Alignment.CENTRE);
				timesBoldUnderline.setBackground(Colour.IVORY);
				timesBoldUnderline.setBorder(Border.ALL, BorderLineStyle.THIN);
				Label l = new Label(0,0,cacheName.toUpperCase(),timesBoldUnderline);
				s.mergeCells(0, 0, 3, 0);
				s.addCell(l);		

				cf.setBackground(Colour.IVORY);
				cf.setBorder(Border.ALL, BorderLineStyle.THIN);

				/* Creates Label and writes date to one cell of sheet*/

				int i = 1;
				for (Object key : keys) {
					Element element = cache.get(key);
					i++;
					Label label = new Label(0,i,key.toString());
					s.addCell(label);

					label = new Label(1,i,element.getObjectValue().toString());
					s.addCell(label);
				}	

				// write, close and redirect 
				workbook.write(); 			
				workbook.close();

				HttpServletResponse resp = (HttpServletResponse)context.getExternalContext().getResponse(); 		
				resp.setContentType("application/xls"); 

				file = new File(realPath + filename);
				resp.setHeader("Content-length", "" + file.length()); 
				resp.setContentType("application/vnd.ms-excel"); 
				resp.setHeader("Content-Disposition","attachment; filename=\""+cacheName+".xls\""); 

				inputStream = new FileInputStream(realPath + filename); 

				int bytesRead = 0; 
				// ByteArrayOutputStream baos = new ByteArrayOutputStream(inputStream.available());

				// inputStream.read(baos.toByteArray(), 0, inputStream.available());
				byte[] buffer = new byte[1024];
				do 
				{ 
					bytesRead = inputStream.read(buffer, 0, buffer.length); 
					if (bytesRead!=-1)
						resp.getOutputStream().write(buffer, 0, bytesRead); 
				} 
				while (bytesRead == buffer.length); 

				resp.getOutputStream().flush(); 
				context.responseComplete();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		finally{

			try {
				if (inputStream!=null)
					inputStream.close();

				if (file !=null)
					file.delete();

			} catch (IOException e) {
			}
		}
	}



	public List<SelectItem> getCacheDefinitionList() {
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		if (staticDataCacheManager.getCacheDefinitions() != null)
			for (String cacheDefinition : staticDataCacheManager
					.getCacheDefinitions()) {
				list.add(new SelectItem(cacheDefinition, cacheDefinition));
			}
		return list;
	}

	public String listSetup(){
		return "CacheManagementController_list";
	}

}
