package com.bsf.web.core;

import org.springframework.security.AuthenticationException;

public class NoAuthoritiesException extends AuthenticationException {

	public NoAuthoritiesException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
