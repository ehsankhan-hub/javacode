package com.bsf.web.core;

import java.io.IOException;

import javax.jms.Session;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.security.ui.logout.LogoutFilter;
import org.springframework.security.ui.logout.LogoutHandler;
/*ahye imports*/
import com.bsf.ipp.UserInfo;
import com.bsf.ppm.AccessHistory;
import com.bsf.ppm.dao.AccessHistoryDAO;
import com.bsf.ppm.exceptions.DAOException;

public class PPMLogoutFilter extends LogoutFilter 
{
	private AccessHistoryDAO accessHistoryDAO;

	public PPMLogoutFilter(String logoutSuccessUrl, LogoutHandler[] handlers) {
		super(logoutSuccessUrl, handlers);
	}

	@SuppressWarnings("unused")
	@Override
	public void doFilterHttp(HttpServletRequest request,
			HttpServletResponse response, FilterChain filterChain)
			throws IOException, ServletException {
		
		if (super.requiresLogout(request, response)) {
			
					HttpSession session = request.getSession(false);
			
		
				AccessHistory loginHist = new AccessHistory();
				loginHist = (AccessHistory) session.getAttribute("accessHistory");
				if(loginHist!=null)
				{
				try
				{	
					if(loginHist.getLogoutDate()==null)
					getAccessHistoryDAO().maintHistory(loginHist, false);					
				} 
				catch (DAOException e) 
				{
					e.printStackTrace();
				}
				
			}
			
		}	
		super.doFilterHttp(request, response, filterChain);
	}

	public void setAccessHistoryDAO(AccessHistoryDAO accessHistoryDAO) {
		this.accessHistoryDAO = accessHistoryDAO;
	}

	public AccessHistoryDAO getAccessHistoryDAO() {
		return accessHistoryDAO;
	}

	

}
