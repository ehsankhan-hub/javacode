package com.bsf.web.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.authentication.DefaultValuesAuthenticationSourceDecorator;
import org.springframework.security.ldap.DefaultSpringSecurityContextSource;
import org.springframework.security.ldap.populator.DefaultLdapAuthoritiesPopulator;
import org.springframework.security.ldap.search.FilterBasedLdapUserSearch;
import org.springframework.security.providers.ProviderManager;
import org.springframework.security.providers.ldap.LdapAuthenticationProvider;
import org.springframework.security.providers.ldap.authenticator.BindAuthenticator;

import com.bsf.ppm.BackendSystem;
import com.bsf.ppm.dao.BackendSystemDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.jpa.util.BackendUtil;

public class CustomAuthenticationManager {
	
	
	
	private Map<String,DefaultSpringSecurityContextSource> contextSourceMap = new HashMap<String,DefaultSpringSecurityContextSource>();
	
	private BackendSystemDAO  backendSystemDAO;
	
	public BackendSystemDAO getBackendSystemDAO() {
		return backendSystemDAO;
	}

	@Autowired
	public void setBackendSystemDAO(BackendSystemDAO backendSystemDAO) {
		this.backendSystemDAO = backendSystemDAO;
	}


	public Map<String, DefaultSpringSecurityContextSource> getContextSourceMap() {
		return contextSourceMap;
	}


	public void setContextSourceMap(
			Map<String, DefaultSpringSecurityContextSource> contextSourceMap) {
		this.contextSourceMap = contextSourceMap;
	}




	public ProviderManager createInstance()	{
		
		ProviderManager pm = new ProviderManager();
		Map <String,Object>criterias = new HashMap<String,Object>();
		criterias.put("systemType.id", new Long(5));
		try {
			
			List<BackendSystem> ldapTypes = getBackendSystemDAO().searchByCriteria(criterias);

			LdapAuthenticationProvider ldapAuthenticationProvider = null;
			BindAuthenticator bindAuthenticator = null;
			FilterBasedLdapUserSearch filterBasedLdapUserSearch = null;
			DefaultLdapAuthoritiesPopulator defaultLdapAuthoritiesPopulator = null;
			List<LdapAuthenticationProvider> ldapAuthProviders = new ArrayList<LdapAuthenticationProvider>();
			Map<String,String> baseEnvironmentProperties = new HashMap<String,String>();
			baseEnvironmentProperties.put("java.naming.referral", "follow");
			
			for(BackendSystem ldapType:ldapTypes)	{
				
				DefaultSpringSecurityContextSource s = new DefaultSpringSecurityContextSource(BackendUtil.getParameterValue(ldapType, "ldap.url"));
				System.out.println("Ldap Root+--------------------------------"+BackendUtil.getParameterValue(ldapType, "ldap.root"));
				System.out.println(ActiveDirectoryUtil.getDomain(BackendUtil.getParameterValue(ldapType, "ldap.root")));
				s.setBase(ActiveDirectoryUtil.getDomain(BackendUtil.getParameterValue(ldapType, "ldap.root")));
				s.setAuthenticationSource(new DefaultValuesAuthenticationSourceDecorator(new DefaultValuesAuthenticationSourceDecorator(),"",""));
				s.setBaseEnvironmentProperties(baseEnvironmentProperties);
				
				filterBasedLdapUserSearch = new FilterBasedLdapUserSearch("","(&(objectcategory=user)(|(sAMAccountName={0})))",s);
				filterBasedLdapUserSearch.setSearchSubtree(true);
				
				bindAuthenticator  = new BindAuthenticator(s);
				bindAuthenticator.setUserSearch(filterBasedLdapUserSearch);
				
				defaultLdapAuthoritiesPopulator = new DefaultLdapAuthoritiesPopulator(s,"");
				defaultLdapAuthoritiesPopulator.setSearchSubtree(true);
				defaultLdapAuthoritiesPopulator.setRolePrefix("");
				
				ldapAuthenticationProvider  =  new LdapAuthenticationProvider(bindAuthenticator,defaultLdapAuthoritiesPopulator);
				ldapAuthProviders.add(ldapAuthenticationProvider);
				System.out.println(ldapType.getSystemName()+"==:=="+s);
				contextSourceMap.put(ldapType.getSystemName(), s);
			}
			pm.setProviders(ldapAuthProviders);
		} catch (DAOException e) {

			e.printStackTrace();
		}
		return pm;
	}
}
