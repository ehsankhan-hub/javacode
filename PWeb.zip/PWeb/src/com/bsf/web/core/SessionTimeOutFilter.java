package com.bsf.web.core;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.bsf.ppm.batch.service.CustomSessionRegistryImpl;
import com.bsf.ppm.spring.SpringAppContext;


public class SessionTimeOutFilter implements Filter {

	private static final Logger log = Logger.getLogger(SessionTimeOutFilter.class);
	//@Override
	public void destroy() {

	}

	//@Override
	public void init(FilterConfig arg0) throws ServletException {

	}

	public void doFilter(ServletRequest servletrequest,
			ServletResponse servletresponse, FilterChain filterchain)
			throws IOException, ServletException {
		HttpServletRequest httpservletrequest = (HttpServletRequest) servletrequest;
		HttpServletResponse httpservletresponse = (HttpServletResponse) servletresponse;
		HttpSession session = httpservletrequest.getSession(false);
		String s = httpservletrequest.getRequestURI();
		String contextPath = httpservletrequest.getContextPath();

		//Case when session is expired and the request is not for timeOut.jsp
		if (session == null && !s.equals(contextPath + "/timeOut.jsp")
				&& !s.startsWith(contextPath+"/services")
				&& !s.equals(contextPath + "/j_spring_security_check")
				&& !s.equals(contextPath + "/logOn.jsp")
				&& !s.equals(httpservletrequest.getContextPath() + "/")
				&& !s.startsWith(contextPath+"/ModuleMgmtServlet"))
		{
			((HttpServletResponse) servletresponse)
					.sendRedirect(httpservletresponse.encodeURL(contextPath
							+ "/timeOut.jsp"));
			return;
		}

		CustomSessionRegistryImpl sessionReg = (CustomSessionRegistryImpl) SpringAppContext
				.getBean("sessionReg");
		if (session != null
				
				&& !s.startsWith(contextPath+"/ModuleMgmtServlet")
				&& !s.startsWith(contextPath+"/services")
				&& !s.startsWith(contextPath+"/images")
				&& !s.startsWith(contextPath+"/banner1/")
				&& !s.equals(contextPath + "/j_spring_security_check")
				&& !s.equals(contextPath + "/logOn.jsp")				
				&& !s.equals(contextPath + "/flash.htm")
				&& sessionReg.getSessionInformation(session.getId()) == null) {

			((HttpServletResponse) servletresponse)
			.sendRedirect(httpservletresponse.encodeURL(contextPath
					+ "/logOn.jsp"));
			return;
		}
		filterchain.doFilter(servletrequest, servletresponse);

	}

}
