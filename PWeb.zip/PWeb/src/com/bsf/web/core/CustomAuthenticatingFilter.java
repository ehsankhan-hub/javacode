package com.bsf.web.core;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.richfaces.model.TreeNode;
import org.springframework.beans.BeanUtils;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.security.Authentication;
import org.springframework.security.AuthenticationException;
import org.springframework.security.BadCredentialsException;
import org.springframework.security.GrantedAuthority;
import org.springframework.security.GrantedAuthorityImpl;
import org.springframework.security.concurrent.ConcurrentLoginException;
import org.springframework.security.concurrent.SessionIdentifierAware;
import org.springframework.security.concurrent.SessionInformation;
import org.springframework.security.providers.UsernamePasswordAuthenticationToken;
import org.springframework.security.ui.webapp.AuthenticationProcessingFilter;
import org.springframework.security.util.AuthorityUtils;

import com.bsf.ipp.IPPUTIL;
import com.bsf.ipp.UserInfo;
import com.bsf.ppm.AccessGroups;
import com.bsf.ppm.AccessHistory;
import com.bsf.ppm.BackendSystem;
import com.bsf.ppm.BusinessObject;
import com.bsf.ppm.batch.service.CustomSessionRegistryImpl;
import com.bsf.ppm.dao.AccessHistoryDAO;
import com.bsf.ppm.dao.BackendSystemDAO;
import com.bsf.ppm.dao.BusinessObjectDAO;
import com.bsf.ppm.dao.UserDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.groups.ExtendedTreeNodeImpl;
import com.bsf.ppm.groups.GroupController;
import com.bsf.ppm.groups.UserADGroupsBean;
import com.bsf.ppm.jpa.util.BackendUtil;
import com.bsf.ppm.spring.SpringAppContext;


public class CustomAuthenticatingFilter extends AuthenticationProcessingFilter {

	private LdapContextSource contextSource;
	private BusinessObjectDAO busObjectDAO;
	private BackendSystemDAO backendSystemDAO;
	private UserDAO userInfoDAO;
	private AccessHistoryDAO accessHistoryDAO;
	private String username = null;
	@Override
	public Authentication attemptAuthentication(HttpServletRequest request)
			throws AuthenticationException {

		Authentication authentication = null;
		String password = null;
		String domain = null;
		username = obtainUsername(request);
		password = obtainPassword(request);
		domain = request.getParameter("domain");
		if (username == null || username.length() <= 0) {
			request.setAttribute("message", "User Name cannot be empty");
			throw new org.springframework.security.BadCredentialsException(
					"User Name cannot be empty");
		}
		if (password == null || password.length() <= 0) {
			request.setAttribute("message", "Password cannot be empty");
			throw new org.springframework.security.BadCredentialsException(
					"Password cannot be empty");
		}
		username = username.trim().toLowerCase();
		password = password.trim();
		BackendSystem directorySystem = null;
		try {
			directorySystem = getBackendSystemDAO().getBackendByName(domain);
		} catch (DAOException e) {
			logger.warn(IPPUTIL.buildExceptionMessage(e));
		}
		if (directorySystem == null) {
			request.setAttribute("message", "System Error");
			logger
					.warn("Unable to retrieve backend information for..............."
							+ domain);
			throw new BadCredentialsException(
					"System Error. Unable to retrieve backend information.");
		}
		if(domain.equals("bsf")){
			logger.info("domain--"+domain);
			contextSource = (LdapContextSource)SpringAppContext.getBean("bsfcontextSource");
		}else	{
			
			contextSource = (LdapContextSource)SpringAppContext.getBean("contextSource");
		}
		logger.info("domain--"+domain);
		logger.info("directorySystem ldap.root=="+BackendUtil.getParameterValue(directorySystem, "ldap.root"));
		logger.info("username--"+username);
		
		contextSource.setUserDn(username + "@"
				+ BackendUtil.getParameterValue(directorySystem, "ldap.root"));
		contextSource.setPassword(password);
		contextSource.setBase(getDomain(BackendUtil.getParameterValue(
				directorySystem, "ldap.root")));
		UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(
				username, password);
		logger.info("UsernamePasswordAuthenticationToken --"+authRequest);
		// Place the last username attempted into HttpSession for views
		HttpSession session = request.getSession(false);
		/*
		 * if (session != null || getAllowSessionCreation()) {
		 * request.getSession().setAttribute(SPRING_SECURITY_LAST_USERNAME_KEY,
		 * TextUtils.escapeEntities(username)); }
		 */
		// Allow subclasses to set the "details" property
		setDetails(request, authRequest);
		try {
			authentication = this.getAuthenticationManager().authenticate(
					authRequest);
		logger.info("authentication --"+authentication);
		} catch (ConcurrentLoginException cle) {

			killUserSessions(username);
			authentication = this.getAuthenticationManager().authenticate(
					authRequest);
			// throw cle;

		} catch (AuthenticationException ae) {
			request.setAttribute("message",
					"Authentication Failed.Invalid User Name or password."+ae.getMessage());
			ae.printStackTrace();
			throw ae;
		}

		if (authentication != null && authentication.isAuthenticated()) {
       
			logger.info("authentication.getAuthorities().length --"+authentication.getAuthorities().length);
			logger.info("authentication.getAuthorities() --"+authentication.getAuthorities().length);
			try {
				if (authentication.getAuthorities() != null && authentication.getAuthorities().length > 0) {
				
				try {
						authentication = loadUserGroupsPrivileges(authentication, request);
						if (session != null) {
							session.setAttribute("currentUserDomain", domain);
						}
						logger
								.info("User Session after authentication................."
										+ request.getSession().isNew());
					} catch (DAOException daoe) {
						request
								.setAttribute("message",
										"Unable to process Login, Reason: System Error");
						daoe.printStackTrace();
					}
				} else {

					request
							.setAttribute("message",
									"You are not assigned to any Application group. Contact SSD.");
					throw new NoAuthoritiesException(
							"You are not assigned to any Application group. Contact SSD.");
				}
			} catch (NoAuthoritiesException nae) {

				killUserSessions(username);
				throw nae;
			}
		}
	
		return authentication;
	}

	private void killUserSessions(String username) {

		CustomSessionRegistryImpl sessionReg = (CustomSessionRegistryImpl) SpringAppContext
				.getBean("sessionReg");
		SessionInformation[] sessionInfo = sessionReg.getAllSessions(username,
				true);

		for (int i = 0; i < sessionInfo.length; i++) {
			logger.info("System  expireNow for  session id="
					+ sessionInfo[i].getSessionId());
			sessionInfo[i].expireNow();

		}

	}

	private Authentication loadUserGroupsPrivileges(
			Authentication authentication, HttpServletRequest request)
			throws DAOException {
		HttpSession session = request.getSession(false);
		logger.debug("updating user privileges.....");
		StringBuffer loadPrivQry = new StringBuffer(
				"select distinct (bo) FROM BusinessObject bo,UserGroup  ug, GroupPrivileges gp,Application app ")
				.append("where bo.id=gp.businessObject.id and  gp.userGroup.id= ug.id and app.applicationName=bo.application.applicationName and app.status=1 and ug.adMapping in (");
		StringBuffer adGroups = new StringBuffer("");
		   
		List<String> userADGroups = new ArrayList<String>();
		logger.debug("Existing user privileges::");
		
		AccessGroups access = (AccessGroups) SpringAppContext.getBean("tmrsec");
		String[] result=null;
		System.out.println("username is usergruop : "+username);
		
		result = access.getUserGroups(username);
		logger.info("result"+result);
		GrantedAuthority[] auths = null;
		if(result[0].trim().equals("") && result[1].trim().equals("")){
			auths = authentication.getAuthorities();   // Active Directory Groups
			
			if(auths[1].toString().contains("PPM_")){
				session.setAttribute("clearingCenter",new String(auths[0].toString()));
				for (int i = 1; i < auths.length; i++) {

					adGroups.append("'" + new String(auths[i].toString()) + "',");
					userADGroups.add(new String(auths[i].toString()));
					logger.debug(auths[i] + "\n");
				}
			}
			
		}else{
			auths = AuthorityUtils.stringArrayToAuthorityArray(result);  
			session.setAttribute("clearingCenter",new String(auths[1].toString()));
			
			adGroups.append("'" + new String(auths[0].toString()) + "',");
			userADGroups.add(new String(auths[0].toString()));
			logger.debug(auths[0] + "\n");
		}
		
		if (adGroups.length() > 0) {
			adGroups.deleteCharAt(adGroups.length() - 1);
		}
		loadPrivQry.append(adGroups + ") order by bo.id asc");
		System.out.println("Query::" + loadPrivQry);
		List<BusinessObject> userBusObjects = getBusObjectDAO()
				.executeSimpleQuery(loadPrivQry.toString());
		if (userBusObjects == null || userBusObjects.size() == 0
				|| userBusObjects.size() == 1) {
			request
					.setAttribute(
							"message",
							"You don't have any privlages in the system or the application you are using is disabled. please contact system administrator");
			throw new NoAuthoritiesException("There are no Authorities for");
		}

		GrantedAuthority[] updatedAuths = new GrantedAuthority[userBusObjects.size() + 1];
		int i = 0;
		// Used to maintain the applications the user has access to.
		// Useful to stop access to the application when the application is
		// deactivated.
		Set<String> userApps = new TreeSet<String>();
		List<String> sadQueues = new ArrayList<String>();
		for (BusinessObject busObj : userBusObjects) {
			
			if(busObj.getObjectparent().equals(602010000l) && !busObj.getId().equals(602010100l) && !busObj.getId().equals(602010200l))	{
				
				sadQueues.add(busObj.getDisplaytag());
			}
			updatedAuths[i] = new GrantedAuthorityImpl("ROLE_"
					+ busObj.getObjectname().toUpperCase());
			userApps.add(busObj.getApplication().getApplicationName());
			i++;
		}
		
		session.setAttribute("usrSWADQueues" ,sadQueues);
		CustomSessionRegistryImpl sessionReg = (CustomSessionRegistryImpl) SpringAppContext
				.getBean("sessionReg");
		SessionInformation sessInfo = sessionReg.getSessionInformation(session
				.getId());
		if (sessInfo != null) {

			sessionReg.setAppIds(session.getId(), userApps);
		} else {

		}
		// following privilege is added to assume that the user is authenticated
		// successfully.
		// useful in cases where the user belongs to a group, but does not have
		// any privilege.
		updatedAuths[userBusObjects.size()] = new GrantedAuthorityImpl("ROLE_USER");
		// UsernamePasswordAuthenticationToken is the modified authentication
		// object loaded with the database business object privileges.
		UsernamePasswordAuthenticationToken modifedUserInfo = new UsernamePasswordAuthenticationToken(
				authentication.getPrincipal(), authentication.getCredentials(),
				updatedAuths);
		// Stores additional details about the authentication request
		modifedUserInfo.setDetails(authentication.getDetails());
		System.out.println("Current user Session id.........."
				+ ((SessionIdentifierAware) modifedUserInfo.getDetails())
						.getSessionId());
		if (session != null) {

			UserADGroupsBean userADGroupsBean = (UserADGroupsBean) SpringAppContext.getBean("userADGroupsBean");
			if(userADGroupsBean !=null)	{
				
				userADGroupsBean.setUserADGroups(userADGroups);
			}
			Timestamp currTime = new Timestamp(Calendar.getInstance()
					.getTimeInMillis());
			session.setAttribute("privileges", GroupController
					.convertBusinessObjectsToTree(userBusObjects));

			/**
			 * 1. Set default values for currentTabID, currentTabName,
			 * tabChanged 2. tabChanged attribute is used in coreTab.xhtml,
			 * ispatab.xhtml and helpContent.xhtml . Value of this attribute is
			 * same as tab Id from currentTabID. 3. currentTabID is used in
			 * coreTab.xhtml, ispatab.xhtml 4. currentTabName is used in
			 * GlobalAction 5. By default. User is shown Core Tab
			 */

			// Fetch the First Level Business Object from User Privilages
			ExtendedTreeNodeImpl<ExtendedTreeNodeImpl> etni = GroupController
					.convertBusinessObjectsToTree(userBusObjects);
			Iterator<Entry<Object, TreeNode<ExtendedTreeNodeImpl>>> childList = etni
					.getParent().getChildren();
			Map.Entry treeEntry = null;
			if (childList.hasNext()) {

				treeEntry = (Map.Entry) childList.next();
				ExtendedTreeNodeImpl node = (ExtendedTreeNodeImpl) treeEntry
						.getValue();
				BusinessObject busObj = (BusinessObject) node.getData();
				String tabName = busObj.getDisplaytag();
				System.out
						.println(" ======== FIRST TAB accessed == " + tabName);
				session.setAttribute("currentTabID", "id_" + tabName);
				session.setAttribute("tabChanged", "id_" + tabName);
				session.setAttribute("currentTabName", tabName);
			}

			/** Set UserInfo Properties in Session */
			UserInfo userInfo = getUserInfoDAO().getById(authentication.getName());
		
			
			if (userInfo == null) {

				userInfo = new UserInfo();
				userInfo.setUserId(authentication.getName());
				userInfo.setCreatedDate(currTime);
				userInfo.setLastLoginDate(currTime);
				userInfo.setCredential((String) authentication.getCredentials());
				getUserInfoDAO().save(userInfo);
				session.setAttribute("userInfo", userInfo);
				
			} else {
				

				userInfo.setCredential((String) authentication.getCredentials());
				UserInfo sessionInfo = new UserInfo();
				BeanUtils.copyProperties(userInfo, sessionInfo);
				session.setAttribute("userInfo", sessionInfo);
				userInfo.setLastLoginDate(currTime);
				getUserInfoDAO().update(userInfo);
				
				
			}
			/**Adding Login information to User_Access_history table**/
			AccessHistory loginHist=new AccessHistory();
			loginHist.setIp(request.getRemoteAddr());
			loginHist.setLoginDate(currTime);
			loginHist.setLogoutDate(null);
			loginHist.setUserId(authentication.getName());
			getAccessHistoryDAO().maintHistory(loginHist, true);
			session.setAttribute("accessHistory",loginHist);
		
		}
		return modifedUserInfo;
	};

	public LdapContextSource getContextSource() {
		return contextSource;
	}

	public void setContextSource(LdapContextSource contextSource) {
		this.contextSource = contextSource;
	}

	public BusinessObjectDAO getBusObjectDAO() {
		return busObjectDAO;
	}

	public void setBusObjectDAO(BusinessObjectDAO busObjectDAO) {
		this.busObjectDAO = busObjectDAO;
	}

	public BackendSystemDAO getBackendSystemDAO() {
		return backendSystemDAO;
	}

	public void setBackendSystemDAO(BackendSystemDAO backendSystemDAO) {
		this.backendSystemDAO = backendSystemDAO;
	}

	public UserDAO getUserInfoDAO() {
		return userInfoDAO;
	}

	public void setUserInfoDAO(UserDAO userInfoDAO) {
		this.userInfoDAO = userInfoDAO;
	}

	private String getDomain(String domainName) {

		StringTokenizer st = new StringTokenizer(domainName, ".");
		StringBuilder buf = new StringBuilder();
		while (st.hasMoreTokens()) {
			if (buf.length() > 0)
				buf.append(",");
			buf.append("DC=").append(st.nextToken());
		}
		return buf.toString();
	}

	public void setAccessHistoryDAO(AccessHistoryDAO accessHistoryDAO) {
		this.accessHistoryDAO = accessHistoryDAO;
	}

	public AccessHistoryDAO getAccessHistoryDAO() {
		return accessHistoryDAO;
	}
}
