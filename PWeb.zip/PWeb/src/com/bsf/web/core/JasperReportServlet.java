package com.bsf.web.core;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.faces.FactoryFinder;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.context.FacesContextFactory;
import javax.faces.lifecycle.Lifecycle;
import javax.faces.lifecycle.LifecycleFactory;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRPdfExporterParameter;

//import com.bsf.ipp.sad.admin.queues.SADDynamicQueuesController;
import com.lowagie.text.pdf.PdfWriter;

public class JasperReportServlet extends HttpServlet {
	public static final String REPORT_DIRECTORY = "/jasperReports";

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		try {

			if (request.getSession() != null) {

				HttpSession session =  request.getSession();

				if ("SAD".equals((String)session.getAttribute("currentTabName"))){
					//= (SADDynamicQueuesController)JSFUtil.getBeanByName("sADDynamicQueuesController");
					FacesContext context = getFacesContext(request,response);
				//	SADDynamicQueuesController controller= (SADDynamicQueuesController) context.getELContext().getELResolver().getValue(context.getELContext(), null, "sADDynamicQueuesController");
					try {

					//	controller.generateVerifiedReport(request, response, context);
						//ServletOutputStream out1 = response.getOutputStream();
						//out1.flush();

					} catch (Exception e) {

						ServletOutputStream out1 = response.getOutputStream();
						out1.print("An Internal Error Occcured. Please contact System administrator.");
						out1.flush();
						return;
					}
				}
				else {
					JasperPrint jasperPrint = (JasperPrint) request.getSession().getAttribute("report");
					if (jasperPrint != null) {

						response.setContentType("application/pdf");
						ByteArrayOutputStream baos = new ByteArrayOutputStream();

						//Jasper to PDF 
						JRPdfExporter exporter = new JRPdfExporter();
						exporter.setParameter(JRExporterParameter.JASPER_PRINT,
								jasperPrint);
						// exporter.setParameter(JRExporterParameter.OUTPUT_STREAM,
						// response.getOutputStream());
						exporter.setParameter(JRExporterParameter.OUTPUT_STREAM,
								baos);

						exporter.setParameter(JRExporterParameter.CHARACTER_ENCODING,
						"UTF-8");

						exporter
						.setParameter(
								JRPdfExporterParameter.IS_CREATING_BATCH_MODE_BOOKMARKS,
								Boolean.FALSE);
						exporter.setParameter(
								JRPdfExporterParameter.IGNORE_PAGE_MARGINS,
								Boolean.TRUE);
						exporter.setParameter(JRPdfExporterParameter.PERMISSIONS,
								new Integer(PdfWriter.HideMenubar
										| PdfWriter.HideToolbar
										| PdfWriter.AllowPrinting));

						// this.print({bUI: true,bSilent: false,bShrinkToFit:
						// true});this.closeDoc();
						// exporter.setParameter(
						// JRPdfExporterParameter.PDF_JAVASCRIPT,"this.print(true, 0, this.numPages-1, true);");

						// Js to open Print Dialog from PDF. Remove this when using
						// PDF output as Object.
						// <object ID="jasperPDF" type="application/pdf"
						// data="${request.contextPath}/JasperReport.rpt" width="0"
						// height="0" />
						exporter
						.setParameter(
								JRPdfExporterParameter.PDF_JAVASCRIPT,
						"this.print({bUI: true,	bSilent: false, bShrinkToFit: true})");

						exporter.exportReport();

						ServletOutputStream out1 = response.getOutputStream();
						baos.writeTo(out1);
						out1.flush();
						baos.close();
						// response.getOutputStream().flush();
					}else	{

						ServletOutputStream out1 = response.getOutputStream();
						out1.print("Sorry, This is an invalid request. Please <a href="+request.getContextPath()+"/home/home.jsf"+"> Click here</a> to return to the home page.");
						out1.flush();
						return;
					}
				}
			}else	{

				response.sendRedirect(request.getContextPath()+"/logOn.jsp");
			}
		}
		catch (JRException e) {
			e.printStackTrace();
		}
	}

	protected FacesContext getFacesContext(HttpServletRequest request, HttpServletResponse response) {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		if (facesContext == null) {

			FacesContextFactory contextFactory  = (FacesContextFactory)FactoryFinder.getFactory(FactoryFinder.FACES_CONTEXT_FACTORY);
			LifecycleFactory lifecycleFactory = (LifecycleFactory)FactoryFinder.getFactory(FactoryFinder.LIFECYCLE_FACTORY); 
			Lifecycle lifecycle = lifecycleFactory.getLifecycle(LifecycleFactory.DEFAULT_LIFECYCLE);

			facesContext = contextFactory.getFacesContext(request.getSession().getServletContext(), request, response, lifecycle);

			// Set using our inner class
			InnerFacesContext.setFacesContextAsCurrentInstance(facesContext);

			// set a new viewRoot, otherwise context.getViewRoot returns null
			UIViewRoot view = facesContext.getApplication().getViewHandler().createView(facesContext, "");
			facesContext.setViewRoot(view);                
		}
		return facesContext;
	}
	//You need an inner class to be able to call FacesContext.setCurrentInstance
	// since it's a protected method
	private abstract static class InnerFacesContext extends FacesContext {
		protected static void setFacesContextAsCurrentInstance(FacesContext facesContext) {
			FacesContext.setCurrentInstance(facesContext);
		}
	}


}

