package com.bsf.web.core;

import java.io.Serializable;

public class RowCounter implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	private transient int row = 0;
	
		public int getRow() {
	    	return ++row;
	    }
}
