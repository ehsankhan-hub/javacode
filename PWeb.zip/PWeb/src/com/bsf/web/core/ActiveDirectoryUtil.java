package com.bsf.web.core;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.StringTokenizer;

import javax.naming.AuthenticationException;
import javax.naming.CommunicationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.apache.log4j.Logger;
import org.springframework.security.context.SecurityContextHolder;

/**
 ** 
 * @author bsaleem
 * 
 * Utility class for retrieving all the groups from the Directory Server.
 * Used when defining a new Group in the System.
 **
 */

public class ActiveDirectoryUtil {
	private static final Logger log = Logger.getLogger(ActiveDirectoryUtil.class);
	/**
	 * This method returns the LDAP context using the supplied parameters.
	 * @param ldapURL - Should be in ldap://hostname or ip address:port format.
	 * @param ldapRoot - Root domain name e.g. sample.com
	 * @return LdapContext.
	 */
	private  LdapContext getLdapContext(String ldapURL, String ldapRoot, String userName, String password) throws Exception {
		
		Hashtable<String,String> env = new Hashtable<String,String>();
		String adminName = userName +"@"+ ldapRoot;		
		env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, adminName);
		env.put(Context.SECURITY_CREDENTIALS, password);
		env.put(Context.PROVIDER_URL, ldapURL);
		env.put(Context.REFERRAL,"follow");
		LdapContext ctx = null;
		try {
			ctx = new InitialLdapContext(env, null);

		}catch(CommunicationException ce){			
			throw ce;
		}
		catch(AuthenticationException ae){			
			throw ae;
		}catch(NamingException ne){
			throw ne;
		}	
		return ctx;
	}	
	/** This method takes a domain name and returns it in the LDAP required format.
	 * e.g sample.com is returned as DC=sample,DC=com
	 * @param domainName - Required domain to be parsed.
	 * @return
	 */
	public static String getDomain(String domainName){		

		StringTokenizer st = new StringTokenizer(domainName,".");
		StringBuilder buf = new StringBuilder();
		while( st.hasMoreTokens()){			
			if ( buf.length()>0) buf.append(",");
			buf.append("DC=").append(st.nextToken());
		}		
		return buf.toString();		
	}
	
	/** Used to retrieve all the groups in the LDAP.
	 * This method binds to the LDAP server using the supplied ldapURL,ldapRoot.
	 * The username and password to bind are retrieved from the currently logged in user's session.
	 * This method retrieves all the entries in the LDAP and uses only those attributes which has distinguishedName as attribute ID.
	 * @param ldapURL - Should be in ldap://hostname or ip address:port format.
	 * @param ldapRoot - Root domain name e.g. sample.com
	 * @return
	 */
	public  List<String> retrieveLDAPGroups(String ldapURL,
			String ldapRoot, String searchGroupName) throws Exception {

		List <String> groups = new ArrayList<String>();
		LdapContext ctx = null;
		try {
			
			String userName = SecurityContextHolder.getContext().getAuthentication().getName();
			String passWord = (String)SecurityContextHolder.getContext().getAuthentication().getCredentials();
			 ctx = getLdapContext(ldapURL,ldapRoot,userName, passWord);

			if (ctx != null) {
				SearchControls searchCtls = new SearchControls();
				searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
				String searchFilter = "(&(objectcategory=group)(cn="+searchGroupName+"*))";
				String searchBase = getDomain(ldapRoot);
				NamingEnumeration<SearchResult> enums = ctx.search(searchBase, searchFilter, searchCtls);
				if (enums == null)
					log.info("Unauthorized User...:" + userName);
				String ou = null;
				if (enums != null) {
					while (enums.hasMoreElements()) {
						SearchResult sr = enums.next();
						Attributes allAttrs = sr.getAttributes();
						for (NamingEnumeration ne = allAttrs.getAll(); ne.hasMoreElements();) {
							Attribute natt = (Attribute) ne.next();
							String sid = natt.getID();
							if(sid.equalsIgnoreCase("distinguishedName"))	{
							for (Enumeration vals = natt.getAll(); vals.hasMoreElements();) {
								ou = (String)vals.nextElement();
								String uniqueName = retrieveUniqueName(ou,searchGroupName);
								if(uniqueName!=null )	{
									groups.add(uniqueName);
								}
							}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			throw e;
		}finally	{
			if(ctx != null)
				ctx.close();
		}
		return groups;
	}
	
	/**
	 * Used to retrieve the CN i.e unique name for the group. 
	 * basically it takes a string of the form CN=GROUP NAME,CN=USERS,DC=SAMPLE,DC=COM.
	 * and returns GROUP NAME.
	 * * @param ou - Attributes values.
	 * @return
	 */
	private   String retrieveUniqueName(String ou,String searchGroupName) {

		String groupName = ou;
		if(searchGroupName != null && searchGroupName.length() >0)	{
			
			groupName = groupName.substring(3,groupName.indexOf(","));
			if(groupName.equalsIgnoreCase(searchGroupName) || groupName.contains(searchGroupName))	{

				return groupName;
			}else {
				
				return null;
			}
		}
		groupName = groupName.substring(3,groupName.indexOf(","));
		return groupName;
	}
}
