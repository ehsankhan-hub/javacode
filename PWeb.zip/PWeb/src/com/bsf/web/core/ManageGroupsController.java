package com.bsf.web.core;
import java.util.List;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.controller.jsf.AbstractCrudController;

public class ManageGroupsController extends AbstractCrudController<UserInfo, Long> {

	@Override
	public PaginatedDAO<UserInfo, Long> getDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserInfo getItem() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserInfo> getItems() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserInfo> getSelectedItems() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setItem(UserInfo item) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setItems(List<UserInfo> items) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String createSetup() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String detailSetup() {
		// TODO Auto-generated method stub
		return null;
	}
     @Override
    public String listSetup() {
    	
    	 return getClass().getSimpleName() +IConstants.CRUD_LIST_NAVIGATION;
    }
	
}
