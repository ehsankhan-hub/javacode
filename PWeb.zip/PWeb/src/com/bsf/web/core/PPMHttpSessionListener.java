/**
 * 
 */
package com.bsf.web.core;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import javax.servlet.http.HttpSession;
import java.util.Date;

import com.bsf.ipp.UserInfo;
import com.bsf.ppm.AccessHistory;
import com.bsf.ppm.dao.AccessHistoryDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.spring.SpringAppContext;

/**
 * @author Ahaye
 * 
 */
public class PPMHttpSessionListener implements HttpSessionListener {
	private AccessHistoryDAO accessHistoryDAO;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpSessionListener#sessionCreated(javax.servlet.http
	 * .HttpSessionEvent)
	 */
	@Override
	public void sessionCreated(HttpSessionEvent se) {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpSessionListener#sessionDestroyed(javax.servlet
	 * .http.HttpSessionEvent)
	 */
	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
	
		AccessHistory loginHist = new AccessHistory();
		HttpSession session = se.getSession();

		if (session != null) {
			if (session.getAttribute("accessHistory") != null) {
				
				loginHist = (AccessHistory) session.getAttribute("accessHistory");
				
				if (loginHist != null) 
				{
				if (loginHist.getLogoutDate() == null) 
				{					
						try
						{
							accessHistoryDAO = (AccessHistoryDAO) SpringAppContext
									.getBean("accessHistoryDAO");
							accessHistoryDAO.maintHistory(loginHist, false);
						} catch (DAOException e) {
							e.printStackTrace();
						}
					
				}
				}
				
			}

		}

	}

}
