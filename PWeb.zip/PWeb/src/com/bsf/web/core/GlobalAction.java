package com.bsf.web.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.el.MethodExpression;
import javax.faces.application.Application;
import javax.faces.component.html.HtmlCommandLink;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpSession;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

import org.richfaces.component.html.HtmlMenuItem;
import org.richfaces.component.html.HtmlTab;

import com.bsf.ipp.UserInfo;
import com.bsf.ppm.BusinessObject;
import com.bsf.ppm.controller.jsf.JSFUtil;

public class GlobalAction {

	private final String logOutUrl = "../userLogout";
	private String currTopMenuId = "sub21";
	private String leftMenuAction = null;
	private String bodyTitle = null;
	private String busObjName = "";
	private String objecthierarchy = "";
	private Cache businessObjectCache;
	private BusinessObject currentObject = new BusinessObject();
	private String loggedInUserId = null;
	private String lastLoginTime = null;
	private String userRole=null;
	private List<BusinessObject> bos=null;
	private int breadCrumsSize;
	private String coreHome;
	private  String skinName;
	private Object skinChooserState;
	
	public void setCoreHome(String coreHome) {
		this.coreHome = coreHome;
	}

	public String getLastLoginTime() {
		
		UserInfo ui = JSFUtil.getLoggedInUserInfo();
		if(ui !=null && ui.getLastLoginDate() !=null)
			return ui.getLastLoginDate().toLocaleString();
		else	
			return "";
	}

	public void setLastLoginTime(String lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public String getLoggedInUserId() {
		
		UserInfo ui = JSFUtil.getLoggedInUserInfo();
		if(ui !=null)
			return ui.getUserId().toUpperCase();
		else	
			return "";
	}
	public String getClearingCenter(){
		return JSFUtil.getClearingCenter();
	}
	
	public String getBusinessDate(){
		return JSFUtil.getBusinessDate();
	}
	
	public String getCollectionCenter(){
		return JSFUtil.getCollectionCenter();
	}
	
	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}

	public BusinessObject getCurrentObject() {
		return currentObject;
	}

	public void setCurrentObject(BusinessObject currentObject) {
		this.currentObject = currentObject;
	}

	public Cache getBusinessObjectCache() {
		return businessObjectCache;
	}

	public void setBusinessObjectCache(Cache businessObjectCache) {
		this.businessObjectCache = businessObjectCache;
	}

	public String getObjecthierarchy() {
		return objecthierarchy;
	}

	public void setObjecthierarchy(String objecthierarchy) {
		this.objecthierarchy = objecthierarchy;
	}

	public String getBusObjName() {
		return busObjName;
	}

	public void setBusObjName(String busObjName) {
		this.busObjName = busObjName;
	}

	public String getBodyTitle() {
		return bodyTitle;
	}

	public void setBodyTitle(String bodyTitle) {
		this.bodyTitle = bodyTitle;
	}

	public void leftPageController(ActionEvent e) {

		/**
		 * To-Do: Replace the Deprecated MethodBinding method with
		 * MethodExpression class.
		 */
		HtmlCommandLink cl = (HtmlCommandLink) e.getComponent();
		leftMenuAction = "#{" + cl.getTitle() + "}";
		FacesContext ctx = FacesContext.getCurrentInstance();
		Application a = ctx.getApplication();
		//remove  deprecated function
		//MethodBinding mb = a.createMethodBinding(leftMenuAction, null);
		//cl.setAction(mb);
		
		MethodExpression methodExpression = FacesContext.getCurrentInstance().getApplication().getExpressionFactory().
		createMethodExpression(FacesContext.getCurrentInstance().getELContext(), leftMenuAction, null, new Class<?>[0]);
		cl.setActionExpression(methodExpression);
		/**
		 * tabChanged attribute that was set in setCurrentTab() method is
		 * changed to "Dummy" To avoid body content to be hidden
		 */
		HttpSession session = (HttpSession) ctx.getExternalContext()
				.getSession(false);
		session.setAttribute("tabChanged", "Dummy");

		Map attributes = cl.getAttributes();
		if (attributes != null) {

			String busObjName = (String) attributes.get("busObjName");
			if (busObjName != null) {

				setBusObjName(busObjName);
			}
			String busObjHer = (String) attributes.get("busObjHer");
			if (busObjHer != null) {
				setObjecthierarchy(busObjHer);
			} else {
				setObjecthierarchy("");
				setCurrentObject(new BusinessObject());
			}
		}
	}

	public void topMenuPageController(ActionEvent e) {

		currTopMenuId = e.getComponent().getId();

		HtmlMenuItem cl = (HtmlMenuItem) e.getComponent();

		String leftMenuAction = "#{" + cl.getIconClass() + "}";
		FacesContext ctx = FacesContext.getCurrentInstance();
		Application a = ctx.getApplication();
		//MethodBinding mb = a.createMethodBinding(leftMenuAction, null);
		//cl.setAction(mb);
		
		MethodExpression methodExpression = FacesContext.getCurrentInstance().getApplication().getExpressionFactory().
		createMethodExpression(FacesContext.getCurrentInstance().getELContext(), leftMenuAction, null, new Class<?>[0]);
		cl.setActionExpression(methodExpression);

		/**
		 * tabChanged attribute that was set in setCurrentTab() method is
		 * changed to "Dummy" To avoid body content to be hidden
		 */
		HttpSession session = (HttpSession) ctx.getExternalContext()
				.getSession(false);
		session.setAttribute("tabChanged", "Dummy");

		Map attributes = cl.getAttributes();
		if (attributes != null) {

			String busObjName = (String) attributes.get("busObjName");
			if (busObjName != null) {

				setBusObjName(busObjName);
			}

			String busObjHer = (String) attributes.get("busObjHer");
			if (busObjHer != null) {
				setObjecthierarchy(busObjHer);
			} else {
				setObjecthierarchy("");
				setCurrentObject(new BusinessObject());
			}
		}
	}

	public void setCurrentTab(ActionEvent e) {

		HtmlTab htmlTab = (HtmlTab) e.getComponent();

		String currentTabID = htmlTab.getId();
		String currentTabName = htmlTab.getLabel();
		FacesContext ctx = FacesContext.getCurrentInstance();
		/*
		 * String tabAction= htmlTab.getStyleClass(); tabAction =
		 * "#{"+tabAction+"}"; Application a = ctx.getApplication();
		 * MethodBinding mb = a.createMethodBinding(tabAction,null);
		 * //htmlTab.setAction(mb);
		 */

		// Set the currentTabID and currentTabName attribute values in session
		HttpSession session = (HttpSession) ctx.getExternalContext()
				.getSession(false);
		session.setAttribute("currentTabID", currentTabID);
		session.setAttribute("currentTabName", currentTabName);
		setBusObjName(""); //Set Empty String to the the BusObjectName for help 
		/**
		 * 1. Track the TabChanged Event. 2. tabChanged attribute is used in
		 * coreTab.xhtml, ispatab.xhtml and helpContent.xhtml . Value of this
		 * attribute is same as tab Id from currentTabID. 3. tabChanged
		 * attribute is changed to "Dummy" in topMenuPageController and
		 * leftPageController methods. To avoid body content to be hidden
		 */
		session.setAttribute("tabChanged", currentTabID);
		setObjecthierarchy("");
		setCurrentObject(new BusinessObject());

	}

	public String pageNavigator() {

		return currTopMenuId;
	}

	public String maintainBICC() {

		return "maintainBICC";
	}

	public String maintainBC() {

		return "com.bsf.ipp.maintenance.BranchCodeController_list";
	}

	public String maintainBA() {

		return "maintainBA";
	}

	public String maintainCC() {

		return "maintainCC";
	}

	public String maintainCurC() {

		return "maintainCurC";
	}

	public String addBICC() {

		return "addBICC";
	}

	public String getLogOutUrl() {
		return logOutUrl;
	}

	public String getCurrTopMenuId() {
		return currTopMenuId;
	}

	public void setCurrTopMenuId(String currTopMenuId) {
		this.currTopMenuId = currTopMenuId;
	}

	public String getLeftMenuAction() {
		return leftMenuAction;
	}

	public void setLeftMenuAction(String leftMenuAction) {
		this.leftMenuAction = leftMenuAction;
	}

	public List<BusinessObject> getBreadCrumbs() {
		bos = new ArrayList<BusinessObject>();
		Element elem = null;
		if (businessObjectCache != null) {
			if (objecthierarchy != null) {
				String boArray[] = objecthierarchy.split("/");
				if (boArray.length > 2) {
					for (int i = 2; i < boArray.length; i++) {
						elem = businessObjectCache.get(boArray[i]);
						if (elem != null) {
							bos.add((BusinessObject) elem.getValue());
						}
					}
					elem = businessObjectCache.get(boArray[boArray.length - 1]);
					if (elem != null)
						setCurrentObject((BusinessObject) elem.getValue());
				}
			}
		}

		return bos;
	}
	
	public String getCoreHome()	{

		setCurrTopMenuId("");
		return "corehome";
	}
	
	public String getIspaHome()	{
		
		setCurrTopMenuId("");
		return "ispahome";
	}
	
	public String getItmsHome()	{
		
		setCurrTopMenuId("");
		return "itmshome";
	}
	
	public String getSadHome()	{
		
		setCurrTopMenuId("");
		return "sadhome";
	}
	
	public String getItmsMsgListsHome()	{
		
		//setCurrTopMenuId("");
		return "itmsMsgListsHome";
	}
	public String getDdmsHome()	{
		setCurrTopMenuId("");
		return "ddmshome";
	}
	
	public String getOtmsHome()	{
		setCurrTopMenuId("");
		return "otmshome";
	}
	
	public String getCclgHome()	{
		setCurrTopMenuId("");
		return "cclghome";
	}
	
	public String getCclnHome(){
		setCurrTopMenuId("");
		return "cclnhome";
	}
	
	public int getBreadCrumsSize() {
		if(bos != null)
			return bos.size();
		else
			return 0;
	}
	
	
	public  String getSkinName() {
		return skinName;
	}

	public  void setSkinName(String skinName) {
		this.skinName = skinName;
	}

	public void changeSkin(ActionEvent e){
		HtmlCommandLink cl = (HtmlCommandLink) e.getComponent();
		//GlobalAction action=(GlobalAction) JSFUtil.getBeanByName("action");
		Map<String, Object> attributes = cl.getAttributes();
		setSkinName(attributes.get("skinName").toString());
	}

	public Object getSkinChooserState() {
		return skinChooserState;
	}

	public void setSkinChooserState(Object skinChooserState) {
		this.skinChooserState = skinChooserState;
	}
	
	
}
