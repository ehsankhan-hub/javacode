package com.bsf.web.core;



import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.StringTokenizer;

import javax.naming.AuthenticationException;
import javax.naming.CommunicationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

public class ActiveDirectoryUtilTest {
	/**
	 * @param userName
	 * @param password
	 * @return
	 */
	private static LdapContext getLdapContext(String userName, String password) throws Exception {
		Hashtable env = new Hashtable();

		// Get Ldap IPAddress from LinQ2 Configuration
		//String LdapAddress = "erewrewqr";
		String LdapAddress = "10.10.25.104";
		// Get Ldap port from LinQ2 Configuration
		String port = "389";

		// Get Ldap domain from LinQ2 Configuration
		String domain = "bsf.com";
		// Construct proper domain understood by Active Directory		

		//String adminName = buffer.toString();		
		String adminName = userName +"@"+ domain;		

		String ldapURL = "ldap://" + LdapAddress + ":" + port;
		System.out.println("ldapURL %%%%%%%%%%%%%%%%%%%%%: " + ldapURL);
		System.out.println("AdminName %%%%%%%%%%%%%%%%%%%%%: " + adminName);	
		System.out.println("domain %%%%%%%%%%%%%%%%%%%%%: " + domain);

		env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		// Setting username
		env.put(Context.SECURITY_PRINCIPAL, adminName);
		// setting password
		env.put(Context.SECURITY_CREDENTIALS, password);
		env.put(Context.PROVIDER_URL, ldapURL);
		env.put(Context.REFERRAL,"follow");
		
		LdapContext ctx = null;

		try {
			ctx = new InitialLdapContext(env, null);

		}catch(CommunicationException ce){			
			throw ce;
		}
		catch(AuthenticationException ae){			
			throw ae;
		}catch(NamingException ne){
			throw ne;
		}	
		return ctx;
	}	
	/**
	 * @param domainName
	 * @return
	 */
	private static String getDomain(String domainName){		

		StringTokenizer st = new StringTokenizer(domainName,".");
		StringBuilder buf = new StringBuilder();
		while( st.hasMoreTokens()){			
			if ( buf.length()>0) buf.append(",");
			buf.append("DC=").append(st.nextToken());
		}		
		return buf.toString();		
	}
	/**
	 * @param userName
	 * @param password
	 * @return
	 */
	public static boolean authenticateUser(String userName, String password) throws Exception{
		boolean authenticated = false;
		try {
			LdapContext ctx = getLdapContext(userName, password);
			if (ctx != null)
				authenticated = true;
		} catch (Exception e) {
			throw e;
		}
		return authenticated;
	}	
	/**
	 * @param adminUserName
	 * @param password
	 * @param userName
	 * @return
	 */
	public static boolean userExistsInAD(String adminUserName,
			String adminPassword, String userName) throws Exception {

		boolean exists = false;
		try {
			LdapContext ctx = getLdapContext(adminUserName, adminPassword);

			if (ctx != null) {

				SearchControls searchCtls = new SearchControls();
				searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);

				// constructing search filter
				String filter = "(sAMAccountName=" + userName + ")";

				// Search Filter for particular user
				String searchFilter = "(&(objectCategory=group)(|" + filter	+ "))";
				// Get the domain from linq2 configurations
				String domain = "bsf.com";		
				String searchBase = getDomain(domain);


				NamingEnumeration enums = ctx.search(searchBase, searchFilter, searchCtls);

				if (enums == null)
					System.out.println("Unauthorized User...:" + userName);

				System.out.println("The enums: " + enums);
					System.out.println("userName :" + userName);
				if (enums != null) {
					while (enums.hasMoreElements()) {
						SearchResult sr = (SearchResult) enums.next();
						Attributes allAttrs = sr.getAttributes();

						for (NamingEnumeration ne = allAttrs.getAll(); ne.hasMoreElements();) {
							Attribute natt = (Attribute) ne.next();
							String sid = natt.getID();

							for (Enumeration vals = natt.getAll(); vals.hasMoreElements();) {
							
								String nextElement = (String)vals.nextElement();
							//	System.out.println("SID :" + sid);
								System.out.println( sid +"\t"+ ": \t"+  nextElement);
							
								if ( nextElement.equalsIgnoreCase(userName))
									exists = true;
							}
						}
					}
				}
				ctx.close();
			}
		} catch (Exception e) {
			throw e;
		}
		return exists;
	}	
	/**
	 * @param adminUserName
	 * @param password
	 * @param userName
	 * @return
	 */
	public static Map<Object, Object> retrieveUserDetails(String adminUserName,
			String adminPassword, String userName) throws Exception {

		Map<Object, Object> map = new HashMap<Object, Object>();
		try {
			LdapContext ctx = getLdapContext(adminUserName, adminPassword);

			if (ctx != null) {

				SearchControls searchCtls = new SearchControls();
				searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);

				// constructing search filter
				String filter = "sAMAccountName="+userName+"";
				String[] users = {userName};
				
				
				String[] attrIDs = {"ou","OU"};

				String searchFilter = "(&("+filter+"))";
				//String searchFilter  ="(&(objectCategory=person)(objectClass=user))";
				// Search Filter for particular user
				//String searchFilter = "(&(objectcategory=group))";
				
//				
				
//				//String searchFilter = "(objectclass=*)";
				// Get the domain from linq2 configurations
				String domain = "bsf.com";
				String searchBase = getDomain(domain);
				System.out.println("search base"+searchBase);
				System.out.println(searchFilter);

				NamingEnumeration enums = ctx.search(searchBase, searchFilter, searchCtls);

				if (enums == null)
					System.out.println("Unauthorized User...:" + userName);

				//System.out.println("The enums: " + enums);
				String ou = null;
				if (enums != null) {
					int i=0;
					while (enums.hasMoreElements()) {
						SearchResult sr = (SearchResult) enums.next();
						Attributes allAttrs = sr.getAttributes();
						//System.out.println(sr.getClassName());
						for (NamingEnumeration ne = allAttrs.getAll(); ne.hasMoreElements();) {
							Attribute natt = (Attribute) ne.next();
							String sid = natt.getID();
							System.out.println("*sid*"+sid+"=");
							
							//if(sid.equalsIgnoreCase("distinguishedName"))	{
								if(true){
							for (Enumeration vals = natt.getAll(); vals.hasMoreElements();) {
								ou = (String)vals.nextElement();
								System.out.println(ou);
								/*String uniqueName = retrieveUniqueName(ou,"IPP");
							if(uniqueName!=null)
									System.out.println(i+"--"+uniqueName);*/
								i++;
							
							}
							
							}
						}
						
					}
					System.out.println("Total Groups in Active Directory::"+i);
				}
				ctx.close();
			}
		} catch (Exception e) {
			throw e;
		}
		return map;
	}
	public static void main(String[] args) {
	
		try {
			System.out.println("User authentication::"+new ActiveDirectoryUtilTest().authenticateUser("bsf20661", "oct@12345"));
			//System.out.println("User Details::"+new ActiveDirectoryUtilTest().retrieveUserDetails("bsf29581", "muddu@1234", "bsf29580"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Used to retrieve the CN i.e unique name for the group. 
	 * basically it takes a string of the form CN=GROUP NAME,CN=USERS,DC=SAMPLE,DC=COM.
	 * and returns GROUP NAME.
	 * * @param ou - Attributes values.
	 * @return
	 */
	private  static String retrieveUniqueName(String ou,String searchGroupName) {

		String groupName = ou;
		if(searchGroupName != null && searchGroupName.length() >0)	{
			
			groupName = groupName.substring(3,groupName.indexOf(","));
			if(groupName.equalsIgnoreCase(searchGroupName) || groupName.contains(searchGroupName))	{

				return groupName;
			}else {
				
				return null;
			}
		}
		groupName = groupName.substring(3,groupName.indexOf(","));
		return groupName;
	}
	
}
