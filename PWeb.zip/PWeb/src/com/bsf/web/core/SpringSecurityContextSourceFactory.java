package com.bsf.web.core;
import org.apache.log4j.Logger;
import org.springframework.security.ldap.DefaultSpringSecurityContextSource;

import com.bsf.ppm.BackendSystem;
import com.bsf.ppm.dao.BackendSystemDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.jpa.util.BackendUtil;
public class SpringSecurityContextSourceFactory {
	private static final Logger log = Logger.getLogger(SpringSecurityContextSourceFactory.class);
	private BackendSystemDAO  backendSystemDAO;
	
	public BackendSystemDAO getBackendSystemDAO() {
		return backendSystemDAO;
	}

	public void setBackendSystemDAO(BackendSystemDAO backendSystemDAO) {
		this.backendSystemDAO = backendSystemDAO;
	}

	public  DefaultSpringSecurityContextSource createInstance(){
		BackendSystem cc = null;
		try {
			
			cc=backendSystemDAO.getBackendByName("bsfcen");
		} catch (DAOException e) {
			
			e.printStackTrace();
		}
		log.info("Ldap URL+--------------------------------"+BackendUtil.getParameterValue(cc, "ldap.url"));
		DefaultSpringSecurityContextSource s=new DefaultSpringSecurityContextSource(BackendUtil.getParameterValue(cc, "ldap.url"));
		System.out.println("Ldap Root+--------------------------------"+BackendUtil.getParameterValue(cc, "ldap.root"));
		System.out.println(ActiveDirectoryUtil.getDomain(BackendUtil.getParameterValue(cc, "ldap.root")));
		s.setBase(ActiveDirectoryUtil.getDomain(BackendUtil.getParameterValue(cc, "ldap.root")));
		return s;
	}	
}
