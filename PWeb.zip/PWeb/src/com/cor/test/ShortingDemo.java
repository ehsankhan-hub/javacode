package com.cor.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ShortingDemo {
public static void main(String args[]){

	Employee employee=new Employee(4, "Ehsan");
	Employee employee1=new Employee(2,"Zeeshan");
	Employee employee2=new Employee(6,"Abdul");
	
	List<Employee> empList=new ArrayList<Employee>();
	empList.add(employee);
	empList.add(employee1);
	empList.add(employee2);
	
	for(Employee em:empList){
	
	System.out.println("List  without sorting="+em.getEmpId());
	
	}
	
	Collections.sort(empList);
	
	for(Employee em:empList){
		
		System.out.println("List after sorting="+em.getEmpId());
		
	}
}
}

class Employee implements Comparable<Employee>{

	private int empId;
	private String empName;
	private String address;
	
	public String toString(int empId,String empName){
		
		return "Emp ID="+empId+ "Emp Name="+empName;
		
	}
	
	public Employee(int empId,String empName){
		this.empId=empId;
		this.empName=empName;
	}
	
	public int compareTo(Employee emp){
		
		if(this.empName==emp.empName){
			return 0;
		}
		return 0;
		
		//return this.empId-emp.empId;
	}


	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
