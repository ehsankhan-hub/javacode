class Q{
	int run;
	
	public void put(int run){
		System.out.println("Set===="+run);
		this.run=run;
	}
	
	public void get(){
		System.out.println("Get---"+run);
	}
}

class Producer implements Runnable{
Q q;
    public Producer(Q q){
    	this.q=q;
    Thread t =new Thread(this,"Producer");
    t.start();
    }
    
	public void run(){
	int i=0;
	while(true){
		q.put(i++);
		try{
			Thread.sleep(1000);}catch(Exception ex){
			
		}
	}
	
	
	}
}

class Consumer implements Runnable{
	
	Q q;
	
	public Consumer(Q q){
		this.q=q;
		Thread  t=new Thread(this,"Consumer");
		t.start();
	}
	
	public void run(){
		while(true){
		q.get();
		
		try{
			Thread.sleep(1000);}catch(Exception ex){
			
		}
		}
	}
}



public class ThreadSynch {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Q q=new Q();
		new Producer(q);
		new Consumer(q);

	}

}
