import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;


public class MyBean
{
 
    private String input;
 
    public String getInput()
    {
        return input;
    }
 
    public void setInput(String input)
    {
        this.input = input;
    }
 
    public String action()
    {
        // process the valid user input
 
        return null;
    }
 
    public String changeInput()
    {
    	
        // change input
        input = "changed input";
        System.out.println("input=="+input);
     // reset the input field
       // UIInput field = (UIInput) FacesContext.getCurrentInstance().getViewRoot().findComponent("form1:input");
      //  field.resetValue();
     
        return null;
      
    }
 
}