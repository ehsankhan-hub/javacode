import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.faces.convert.DateTimeConverter;

import sun.util.resources.LocaleData;


public class DateFormat {
public static void main(String args[]){
	SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
	String dateInString = "07062013";
    Date date1=new Date();
    SimpleDateFormat formatter1 = new SimpleDateFormat("yyyyMMdd");
	try {
		String str=formatter.format(date1);
		 System.out.println("date1 str=="+str);
		Date datestr=(Date)formatter1.parse(str);
		SimpleDateFormat newFormat = new SimpleDateFormat("yyyyMMdd");
   System.out.println("date1 date=="+newFormat.format(datestr));
	
   Date today = Calendar.getInstance().getTime();
   
   SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

   String dateString = format.format( new Date()   );
   Date   date       = format.parse ( "2009-12-31" );  
   
   System.out.println("date===---------"+date);


  
   
   System.out.println("today=="+today);
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	Date curDate=new Date();
    Date currentDate=null;
    try{
    	
    	 System.out.println("curDate"+curDate);
    	// Get Calendar object set to the date and time of the given Date object
    	Calendar cal = Calendar.getInstance();
    	cal.setTime(curDate);
    	 
    	// Set time fields to zero
    	cal.set(Calendar.HOUR_OF_DAY, 0);
    	cal.set(Calendar.MINUTE, 0);
    	cal.set(Calendar.SECOND, 0);
    	cal.set(Calendar.MILLISECOND, 0);
    	 
    	// Put it back in the Date object
    	curDate = cal.getTime();

    	   
      	 System.out.println("currentDate="+curDate);	
  
    }
    catch(Exception e){
    	e.printStackTrace();
    }
    SimpleDateFormat sm = new SimpleDateFormat("mm-dd-yyyy");
    // myDate is the java.util.Date in yyyy-mm-dd format
    // Converting it into String using formatter
    String strDate = sm.format(new Date());
    //Converting the String back to java.util.Date
   
    try {
   
    	 Date dt = sm.parse(strDate);
    	 System.out.println("dt="+dt);	
    } catch (Exception e) {
        e.printStackTrace();
    }

    
}
}
