import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.xmlbeans.impl.xb.ltgfmt.FileDesc.Role;

import com.bsf.ppm.PpmSflInstructions;



public class UploadExcelFile {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UploadExcelFile upExFil=new UploadExcelFile();
		//upExFil.ReadExcelFile();
		readExcelFile("D://excelFiles/Details.xlsx");
	}
	
	public void ReadExcelFile(){
		List<String> list=new ArrayList<String>();
		try {

	        FileInputStream file = new FileInputStream(new File("D://excelFiles/Details1.xlsx"));
	        XSSFWorkbook workbook = new XSSFWorkbook(file);
	        XSSFSheet sheet = workbook.getSheetAt(0);
	        Iterator<Row> rowIterator = sheet.iterator();
	        rowIterator.next();
	        while(rowIterator.hasNext())
	        {
	            Row row = rowIterator.next();
	            //For each row, iterate through each columns
	            Iterator<Cell> cellIterator = row.cellIterator();

	            while(cellIterator.hasNext())
	            {
	                Cell cell = cellIterator.next();
	                //This will change all Cell Types to String
	                cell.setCellType(Cell.CELL_TYPE_STRING);
	                switch(cell.getCellType()) 
	                {
	                    case Cell.CELL_TYPE_BOOLEAN:
	                        System.out.println("boolean===>>>"+cell.getBooleanCellValue() + "\t");
	                        break;
	                    case Cell.CELL_TYPE_NUMERIC:

	                        break;
	                    case Cell.CELL_TYPE_STRING:

	                       list.add(cell.getStringCellValue());

	                                                 break;
	                }


	            }
	           
	      for(String strList:list)      {
	    	  
	    	  System.out.println(" --"+strList);
	    	  
	      }
	       
	         int cellT= row.getCell(2).getCellType();
	      
	         System.out.println("cellT--"+cellT);
	         
	          String  name=row.getCell(0).getStringCellValue().trim();
	          String   empid=row.getCell(1).getStringCellValue();
	          String  add=row.getCell(2).getStringCellValue().trim();
	          double   mobile=row.getCell(3).getNumericCellValue();
	          System.out.println("name "+name);
	          System.out.println("empid "+empid);
	          System.out.println("add "+add);
	          System.out.println("mobile "+mobile);
	          
	          System.out.println(name+empid+add+mobile);
	           // ex.InsertRowInDB(name,empid,add,mobile);
	            System.out.println("");


	        }
	        file.close();
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	  }

	public static void readExcelFile(String fileName) {
		 
		// Create an ArrayList to store the data read from excel sheet.
        List<List<XSSFCell>> sheetData = new ArrayList();

        try  {
        	FileInputStream fis = new FileInputStream(fileName);
            // Create an excel workbook from the file system.
        	XSSFWorkbook workbook = new XSSFWorkbook(fis);
            // Get the first sheet on the workbook.
        	XSSFSheet sheet = workbook.getSheetAt(0);

            // When we have a sheet object in hand we can iterator on
            // each sheet's rows and on each row's cells. We store the
            // data read on an ArrayList so that we can printed the
            // content of the excel to the console.
            Iterator rows = sheet.rowIterator();
            while (rows.hasNext()) {
            	XSSFRow row = (XSSFRow) rows.next();
                Iterator cells = row.cellIterator();

                List<XSSFCell> data = new ArrayList();
                while (cells.hasNext()) {
                	XSSFCell cell = (XSSFCell) cells.next();
                    data.add(cell);
                }
                sheetData.add(data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        showExcelData(sheetData);
    }
	
	private static void showExcelData(List<List<XSSFCell>> sheetData) {
        // Iterates the data and print it out to the console.
        for (List<XSSFCell> data : sheetData) {
            for (XSSFCell cell : data) {
                System.out.println(cell);
                for (int i = 0; i < sheetData.size(); i++) {
                	 List list = (List) sheetData.get(i);
                	//for (int j = 0; j < list.size(); j++) {
                	//Cell cell1 = (Cell) list.get(j);
                	//System.out.println(cell1);
                	 Cell cell0 = (Cell) list.get(i+0);
                	 Cell cell1 = (Cell) list.get(i+1);
                	 Cell cell2 = (Cell) list.get(i+2);
                	 String  debitAccount=(new DataFormatter().formatCellValue(cell0));
    		         String  creditAccount=(new DataFormatter().formatCellValue(cell1));
    		         String  dayOfPayment=(new DataFormatter().formatCellValue(cell2));  	 
                	
    		         PpmSflInstructions ppmSflInstructions=new PpmSflInstructions();
    		          
    		          ppmSflInstructions.setInstReference("12321");
    		          ppmSflInstructions.setDebitAccount(debitAccount);
    		          ppmSflInstructions.setCreditAccount(creditAccount);
    		         // ppmSflInstructions.setDayOfPayment(Integer.parseInt(dayOfPayment));
                	
    		          saveData(ppmSflInstructions);
                	
           // }
        }
                
              
	
	
	}
}
	}
	
	  public static void saveData(PpmSflInstructions ppmSflInstructions){
      	
		  System.out.println("saveData--"+ppmSflInstructions.getDebitAccount());
      }
}

