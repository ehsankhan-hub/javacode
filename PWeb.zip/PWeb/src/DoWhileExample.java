


public class DoWhileExample {  
public static void main(String[] args) {  
    boolean flag=false;
	int i=1;  
    do{ 
      i++;
      flag=false;
   
       System.out.println(i);  
    i++;  
    }while(!flag&&i<=10);  
}  
}  
