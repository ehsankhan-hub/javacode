
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

      int a=5;
      int b=5;
      
      int i=10;
      int j=10;
      
      if(a==b||i==j){
      
      if(a==b){
    	  System.out.println("Equal");
      }
      
      else if(i==j){
    	  System.out.println("Equal 2"); 
      }
      
      else{
    	  System.out.println("Else block");
      }
		
	}
	}
}
