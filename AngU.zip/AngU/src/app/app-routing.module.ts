import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './guards/auth.guard';
import { CustomLayoutComponent } from './custom-layout/custom-layout.component';
import { PaymentDashboardComponent } from './dashboard/payment/payment-dashboard/payment-dashboard.component';
import { SetupComponent } from './setup/setup.component';
import { CustomerComponent } from './setup/customer/customer.component';
import { CustomerEditComponent } from './setup/customer/edit/edit.component';
import { CustomerAddComponent } from './setup/customer/add/add.component';
import { PaymentheadComponent } from './dashboard/paymenthead/paymenthead.component';
import { PaymentdetailsComponent } from './dashboard/paymentdetails/paymentdetails.component';
import { PayrollheaderComponent } from './dashboard/payrollheader/payrollheader.component';
import { PayrolldetailsComponent } from './dashboard/payrolldetails/payrolldetails.component';
import { AccountComponent } from './setup/account/account.component';
import { AccountEditComponent } from './setup/account/edit/accountedit.component';
import { AccountSaveComponent } from './setup/account/add/accountadd.component';
import { FileLogComponent } from './dashboard/filelogs/filelogs.component';

const routes: Routes = [{ path: '', redirectTo: 'landing', pathMatch: 'prefix' },
{ path: 'login', component: LoginComponent },
{
  path: 'landing', component: CustomLayoutComponent, canActivate: [AuthGuard],
  children: [{ path: '', redirectTo: 'dashboard', pathMatch: 'prefix', canActivate: [AuthGuard] },
  {
    path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard],
    children: [{ path: '', redirectTo: 'paymentHead', pathMatch: 'prefix', canActivate: [AuthGuard] },
    { path: 'paymentHead', component: PaymentheadComponent, canActivate: [AuthGuard] },
    { path: 'payrollHead', component: PayrollheaderComponent, canActivate: [AuthGuard] },
    { path: 'fileLog', component: FileLogComponent, canActivate: [AuthGuard] },
    { path: 'paymentDetails/:customerId/:fileId', component: PaymentdetailsComponent, canActivate: [AuthGuard] },
    { path: 'payrollDetails/:customerId/:fileId', component: PayrolldetailsComponent, canActivate: [AuthGuard] }]
  },
  {
    path: 'setup', component: SetupComponent, canActivate: [AuthGuard],
    children: [{ path: '', redirectTo: 'customer', pathMatch: 'prefix', canActivate: [AuthGuard] },
    { path: 'customer', component: CustomerComponent, canActivate: [AuthGuard] },
    { path: 'customerEdit/:id', component: CustomerEditComponent, canActivate: [AuthGuard]  },
    { path: 'customerAdd', component: CustomerAddComponent, canActivate: [AuthGuard]  },
    { path: 'account', component: AccountComponent, canActivate: [AuthGuard] },
    { path: 'account', component: AccountComponent, canActivate: [AuthGuard] },
    { path: 'accountEdit/:customerId/:accountNumber/:accountType', component: AccountEditComponent, canActivate: [AuthGuard] },
    { path: 'addAccount', component: AccountSaveComponent, canActivate: [AuthGuard] }]
  }]
}];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
