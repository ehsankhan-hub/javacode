export class Constants {
    //public static get REST_URL(): string { return "http://10.10.119.123:8080/MACUGBO"; };
    //public static get REST_URL(): string { return "http://10.40.11.181:8089/MACUGBO"; };
    public static get REST_URL(): string { return "http://localhost:8080"; };
    


}

////"http://10.10.119.123:8080/MACUGBO";