import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { first } from 'rxjs/operators';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CustomerEntity } from '../customer.entity';
import { MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'cust-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.scss']
})
export class CustomerAddComponent implements OnInit {
  id: string;
  private sub: any;
  customerForm: FormGroup;
  customerModel: CustomerEntity;
  resourcesLoaded: boolean;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor(private route: ActivatedRoute, private router: Router,
    private customerService: CustomerService,
    private toastaService: ToastrService) {
    this.customerForm = this.createFormGroup();
    this.customerModel = {} as CustomerEntity;
    this.customerModel.wpsFlag = 'Y';
    this.customerModel.tag20ReplyFlag = 'Y';
    this.customerModel.customerValueDateFlag = 'Y';
    this.customerModel.mt940ArabicFlag = 'N';
    this.customerModel.payrollBalanceCheckFlag = 'Y';
    this.customerModel.paymentSeries=0;
    this.customerModel.customerCategory = 'small';
  }

  ngOnInit() {

  }

  save() {    
    if(this.customerForm.invalid){
      this.toastaService.warning('Please fill the required details.');
      return;
    }
    this.resourcesLoaded = false;
    this.customerService.saveCustomer(this.customerModel)
      .pipe(first())
      .subscribe(
        data => {
          this.resourcesLoaded = true;
          if (data.status) {
            this.toastaService.success(data.message);
            this.router.navigate(['/landing/setup/customer']);
          } else {
            this.toastaService.error(data.message);
          }
        },
        error => {
          console.log(error);
          this.resourcesLoaded = true;
          this.toastaService.error("Create Failed!!!");
        });
  }
  createFormGroup() {
    return new FormGroup({
      customerId: new FormControl('',[Validators.required,
      Validators.minLength(11)]),
      customerName: new FormControl('',[Validators.required,
      Validators.minLength(1)]),
      customerCategory: new FormControl(),
      customerValueDateFlag: new FormControl(),
      customerMolId: new FormControl(),
      customerPerson: new FormControl('',[Validators.required,
        Validators.minLength(1)]),
      customerAddress: new FormControl(),
      customerCountryCode: new FormControl(),
      customerZipCode: new FormControl(),
      customerEmail: new FormControl(),
      customerPhone: new FormControl(),
      customerMobile: new FormControl(),
      customerStatus: new FormControl(),
      wpsFlag: new FormControl(),
      tag20ReplyFlag: new FormControl(),
      payrollId: new FormControl(),
      mt940ArabicFlag: new FormControl(),
      payrollBalanceCheckFlag: new FormControl(),
      paymentSeries: new FormControl()
    });
  }
}
