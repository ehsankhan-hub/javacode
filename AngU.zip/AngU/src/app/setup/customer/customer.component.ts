import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { MatPaginator, MatSort, MatSelect } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { CustomersDataSource } from './customer.datasource';
import { CustomerService } from './customer.service';
import { debounceTime, distinctUntilChanged, tap, first } from 'rxjs/operators';
import { fromEvent, merge } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent implements OnInit, AfterViewInit {
  totalCount: LongRange;
  dataSource: CustomersDataSource;
  displayedColumns = ["id", "payrollId", "customerStatus", "actions"];
  selected = '';
  resourcesLoaded = true;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('filterCustomerId') filterCustomerId: ElementRef;
  @ViewChild('filterStatus') filterStatus: MatSelect;

  constructor(
    private route: ActivatedRoute,
    private toastaService: ToastrService,
    private customerService: CustomerService) { }

  ngOnInit() {

    this.loadCount();
    this.dataSource = new CustomersDataSource(this.customerService);
    this.dataSource.loadcustomers('', '', 'asc', 0, 3);
    console.log(this.route.snapshot);
  }

  ngAfterViewInit() {
    // server-side search
    fromEvent(this.filterCustomerId.nativeElement, 'keyup')
      .pipe(
        debounceTime(150),
        distinctUntilChanged(),
        tap(() => {
          this.paginator.pageIndex = 0;
          this.loadLessonsPage();
        })
      )
      .subscribe();
    this.filterStatus.optionSelectionChanges.subscribe(res => {
      if (res.source.selected) {
        this.paginator.pageIndex = 0;
        this.loadLessonsPage();
      }

    });

    // reset the paginator after sorting
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

    // on sort or paginate events, load a new page
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => this.loadLessonsPage())
      )
      .subscribe();
  }

  loadLessonsPage() {
    this.dataSource.loadcustomers(
      this.filterCustomerId.nativeElement.value,
      this.filterStatus.value,
      this.sort.direction,
      this.paginator.pageIndex,
      this.paginator.pageSize);
  }


  loadCount() {
    this.resourcesLoaded = false;
    this.customerService.findTotalCustomers()
      .pipe(first())
      .subscribe(
        data => {
          this.totalCount = data.count;
          this.resourcesLoaded = true;
        },
        error => {
          console.log(error);
          this.resourcesLoaded = true;
        });
  }
  deleteData(row) {
    let customerId = row.id;
    if (customerId != null) {
      this.customerService.updateCustomerStatus(customerId, "DELETE")
        .pipe(first())
        .subscribe(
          data => {
            if (data.status) {
              this.toastaService.success(data.message);
            } else {
              this.toastaService.error(data.message);
            }
          }
        )
    }
  }
}
