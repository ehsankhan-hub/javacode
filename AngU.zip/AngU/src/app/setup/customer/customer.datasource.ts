import {CollectionViewer, DataSource} from "@angular/cdk/collections";
import {catchError, finalize} from "rxjs/operators";
import { BehaviorSubject, of, Observable } from "rxjs";
import { CustomerService } from "./customer.service";
import { CustomerEntity } from "./customer.entity";



export class CustomersDataSource implements DataSource<CustomerEntity> {

    private customersSubject = new BehaviorSubject<CustomerEntity[]>([]);

    private loadingSubject = new BehaviorSubject<boolean>(false);

    public loading$ = this.loadingSubject.asObservable();

    constructor(private customerService: CustomerService) {

    }

    loadcustomers(
                customerId: string,
                status: string,
                sortDirection:string,
                pageIndex:number,
                pageSize:number) {

        this.loadingSubject.next(true);

        this.customerService.findCustomers(customerId,status, sortDirection,
            pageIndex, pageSize).pipe(
                catchError(() => of([])),
                finalize(() => this.loadingSubject.next(false))
            )
            .subscribe(customers => this.customersSubject.next(customers));

    }

    connect(collectionViewer: CollectionViewer): Observable<CustomerEntity[]> {
        console.log("Connecting data source");
        return this.customersSubject.asObservable();
    }

    disconnect(collectionViewer: CollectionViewer): void {
        this.customersSubject.complete();
        this.loadingSubject.complete();
    }

}