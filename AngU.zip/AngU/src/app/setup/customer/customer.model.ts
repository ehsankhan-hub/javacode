export interface Customer {
    id:string;
    payrollId:string;
}