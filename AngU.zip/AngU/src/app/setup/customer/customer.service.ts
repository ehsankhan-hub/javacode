import { Injectable } from "@angular/core";
import { HttpClient, HttpParams, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import { Constants } from "src/app/app.constants";
import { CustomerEntity } from "./customer.entity";

@Injectable()
export class CustomerService {

    constructor(private http: HttpClient) { }

    findCustomers(
        customerId = '',
        status = '',
        sortOrder = 'asc',
        pageNumber = 0, pageSize = 3): Observable<CustomerEntity[]> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        var param = new HttpParams()
            .set('customerId', customerId)
            .set('status', status)
            .set('sortOrder', sortOrder)
            .set('pageNumber', pageNumber.toString())
            .set('pageSize', pageSize.toString())
        return this.http.get<any>(Constants.REST_URL + '/customer/list', {
            params: param,
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

    findTotalCustomers(): Observable<any> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        return this.http.get<any>(Constants.REST_URL + '/customer/totalCount', {
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

    getCustomer(
        customerId = ''): Observable<CustomerEntity> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        var param = new HttpParams()
            .set('customerId', customerId)
        return this.http.get<CustomerEntity>(Constants.REST_URL + '/customer/'+customerId, {
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

    updateCustomerStatus(
        customerId = '', status = ''): Observable<any> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        var param = new HttpParams()
            .set('customerId', customerId)
            .set('status', status)
        return this.http.get<CustomerEntity>(Constants.REST_URL + '/customer/statusUpdate', {
            params: param,
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

    updateCustomer(
        customerEntity : CustomerEntity): Observable<any> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/json'
        });
        
        return this.http.post<CustomerEntity>(Constants.REST_URL + '/customer/update', customerEntity, {
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

    saveCustomer(
        customerEntity : CustomerEntity): Observable<any> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/json'
        });
        
        return this.http.post<CustomerEntity>(Constants.REST_URL + '/customer/save', customerEntity, {
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }
}