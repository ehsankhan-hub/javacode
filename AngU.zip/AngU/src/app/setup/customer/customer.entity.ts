export interface CustomerEntity{
    customerId: string;
    customerName: string;
    customerCategory: string;
    customerValueDateFlag: string;
    customerMolId: string;
    customerPerson: string;
    customerAddress: string;
    customerCountryCode: string;
    customerZipCode: string;
    customerEmail: string;
    customerPhone: string;
    customerMobile: string;
    customerStatus: string;
    wpsFlag: string;
    tag20ReplyFlag: string;
    payrollId: string;
    mt940ArabicFlag: string;
    payrollBalanceCheckFlag: string;
    paymentSeries: number;
 }