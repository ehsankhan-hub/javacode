import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { first } from 'rxjs/operators';
import { FormGroup, FormControl } from '@angular/forms';
import { CustomerEntity } from '../customer.entity';
import { MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class CustomerEditComponent implements OnInit {
  id: string;
  private sub: any;
  customerForm: FormGroup;
  customerModel: CustomerEntity;
  resourcesLoaded: boolean;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor(private route: ActivatedRoute, private router: Router,
    private customerService: CustomerService,
    private toastaService: ToastrService) {
    this.customerForm = this.createFormGroup();
    this.customerModel = {} as CustomerEntity;
  }

  ngOnInit() {
    this.resourcesLoaded = false;
    this.sub = this.route.params.subscribe(params => {
      this.id = params['id'];
      this.customerService.getCustomer(this.id)
        .pipe(first())
        .subscribe(
          data => {
            this.customerModel = data;
            this.resourcesLoaded = true;
          },
          error => {
            console.log(error);
            this.resourcesLoaded = true;
          });
    });
  }

  update() {
    this.resourcesLoaded = false;
    this.customerService.updateCustomer(this.customerModel)
      .pipe(first())
      .subscribe(
        data => {
          this.resourcesLoaded = true;
          if (data.status) {
            this.toastaService.success(data.message);
            this.router.navigate(['/landing/setup/customer']);
          } else {
            this.toastaService.error(data.message);
          }
        },
        error => {
          console.log(error);
          this.resourcesLoaded = true;
          this.toastaService.error("Update Failed!!!");
        });
  }
  createFormGroup() {
    return new FormGroup({
      customerId: new FormControl(),
      customerName: new FormControl(),
      customerCategory: new FormControl(),
      customerCertificateSeriaNumber: new FormControl(),
      customerValueDateFlag: new FormControl(),
      customerMolId: new FormControl(),
      customerCorporateLimit: new FormControl(),
      customerBsfLimit: new FormControl(),
      customerSarieLimit: new FormControl(),
      customerSwiftLimit: new FormControl(),
      customerForeignCurrencyLimit: new FormControl(),
      customerPerson: new FormControl(),
      customerAddress: new FormControl(),
      customerCountryCode: new FormControl(),
      customerZipCode: new FormControl(),
      customerEmail: new FormControl(),
      customerPhone: new FormControl(),
      customerMobile: new FormControl(),
      customerStatus: new FormControl(),
      wpsFlag: new FormControl(),
      zipFlag: new FormControl(),
      tag20ReplyFlag: new FormControl(),
      payrollId: new FormControl(),
      payrollAttachSignFlag: new FormControl(),
      mt940ArabicFlag: new FormControl(),
      payrollBalanceCheckFlag: new FormControl(),
      paymentSeries: new FormControl()
    });
  }
}
