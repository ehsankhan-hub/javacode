import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from "@angular/core";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { AccountEntity } from "../account.entity";
import { ActivatedRoute, Router } from "@angular/router";
import { AccountService } from "../account.service";
import { first, debounceTime, distinctUntilChanged, tap } from "rxjs/operators";
import { ToastrService } from "ngx-toastr";
import { fromEvent } from "rxjs";

@Component({
    selector: 'account-add',
    templateUrl: './accountadd.component.html',
    styleUrls: ['./accountadd.component.scss']
})
export class AccountSaveComponent implements OnInit, AfterViewInit {

    customerId: string;
    accountNumber: string;
    accountType: string;
    accountForm: FormGroup;
    accountModel: AccountEntity;
    resourcesLoaded: boolean;
    accountServiceSelected : string;
    customerArray : Array<{}>;
    bicCodeArray : Array<{}>;
    @ViewChild('valAccountNumber') selectAccount: ElementRef;
    constructor(private route: ActivatedRoute, private accountService: AccountService, private toastaService: ToastrService, private router: Router) {
        this.accountForm = this.createAccountFormGroup();
        this.accountModel = {} as AccountEntity;
    }

    ngOnInit() {
        this.accountModel.accountService = '';
        this.listCustomers();
        this.loadgenParameters('BNKBICCOD');
        this.accountModel.rateIndicator= 1;
        this.accountModel.transferLimit = -1;
    }

    ngAfterViewInit() {
        fromEvent(this.selectAccount.nativeElement, 'keyup')
      .pipe(
        debounceTime(150),
        distinctUntilChanged(),
        tap(() => {
          this.validateAccount();
        })
      )
      .subscribe();      
    }
    saveAccount() {
        if(this.accountForm.invalid){
            this.toastaService.warning('Please fill required details...');
            return;
        }
        this.resourcesLoaded = false;
        this.accountService.saveAccount(this.accountModel)
            .pipe(first())
            .subscribe(
                data => {
                    this.resourcesLoaded = true;
                    if (data.status) {
                        this.toastaService.success(data.message);
                        this.router.navigate(['/landing/setup/account']);
                    } else {
                        this.toastaService.error(data.message);
                    }
                },
                error => {
                    this.resourcesLoaded = true;
                }
            );
    }

    listCustomers() {
        this.resourcesLoaded = false;
        this.accountService.listCustomers()
            .pipe(first())
            .subscribe(
                data => {
                    this.resourcesLoaded = true;
                    this.customerArray = data["data"];
                },
                error => {
                    this.resourcesLoaded = true;
                }
            );
    }

    createAccountFormGroup() {
        return new FormGroup({
            customerId: new FormControl('',[Validators.required]),
            accountNumber: new FormControl('',[Validators.required,
                Validators.minLength(11)]),
            accountService: new FormControl('',[Validators.required,
                Validators.minLength(3)]),
            currencyCode: new FormControl('',[Validators.required,
                Validators.minLength(3)]),
            bicCode: new FormControl('',[Validators.required,
                Validators.minLength(3)]),
            accountTransferLimit: new FormControl(),
            accountStatus: new FormControl(),
            rateIndicator : new FormControl(),
            transferLimit : new FormControl()
        });
    }

    loadgenParameters(code : string) {
        this.resourcesLoaded = false;
        this.accountService.loadgenParameters(code)
            .pipe(first())
            .subscribe(
                data => {
                    this.resourcesLoaded = true;
                    this.bicCodeArray = data["data"];
                    this.accountModel.bicCode = 'BSFRSARI';
                },
                error => {
                    this.resourcesLoaded = true;
                }
            );
    }

    validateAccount() {
        this.resourcesLoaded = false;
        this.accountService.validateAccount(this.accountModel.accountNumber)
            .pipe(first())
            .subscribe(
                data => {
                    this.resourcesLoaded = true;
                    if(data.accountCurrency!= null && data.accountCurrency!= 'null'){
                        this.accountModel.currencyCode = data.accountCurrency;
                    }
                },
                error => {
                    this.resourcesLoaded = true;
                }
            );
    }
}