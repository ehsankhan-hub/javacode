export interface AccountEntity{
    customerId:string;
    accountNumber:string;
    accountService:string;
    currencyCode:string;
    bicCode:string;
    accountTransferLimit:string;
    accountStatus:string;
    transferLimit:number;
    rateIndicator : number;
}