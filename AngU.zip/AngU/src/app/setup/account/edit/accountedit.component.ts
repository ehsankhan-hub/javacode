import { Component, OnInit } from "@angular/core";
import { FormGroup, FormControl } from "@angular/forms";
import { AccountEntity } from "../account.entity";
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from "../account.service";
import { first } from "rxjs/operators";
import { ToastrService } from "ngx-toastr";

@Component({
    selector: 'account-edit',
    templateUrl: './accountedit.component.html',
    styleUrls: ['./accountedit.component.scss']
})
export class AccountEditComponent implements OnInit {

    customerId: string;
    accountNumber: string;
    accountType: string;
    accountForm: FormGroup;
    accountModel: AccountEntity;
    resourcesLoaded: boolean;

    constructor(private route: ActivatedRoute, private accountService: AccountService, private toastaService: ToastrService, private router: Router) {
        this.accountForm = this.createAccountFormGroup();
        this.accountModel = {} as AccountEntity;
    }

    ngOnInit() {
        this.resourcesLoaded = false;
        this.route.params.subscribe(params => {
            this.customerId = params['customerId'];
            this.accountNumber = params['accountNumber'];
            this.accountType = params['accountType'];
            this.accountService.getAccount(this.customerId, this.accountNumber, this.accountType)
                .pipe(first())
                .subscribe(data => {
                    this.accountModel = data;
                    console.log(this.accountModel);
                    this.resourcesLoaded = true;
                },
                    error => {
                        this.resourcesLoaded = true;
                    });
        });
    }

    updateAccount() {
        this.accountService.updateAccount(this.accountModel)
            .pipe(first())
            .subscribe(
                data => {
                    this.resourcesLoaded = false;
                    if (data.status) {
                        this.toastaService.success(data.message);
                        this.router.navigate(['/landing/setup/account']);
                    } else {
                        this.toastaService.error(data.message);
                    }
                },
                error => {
                    this.resourcesLoaded = false;
                    this.toastaService.error('Updation Failed!!!');
                }
            );
    }

    createAccountFormGroup() {
        return new FormGroup({
            customerId: new FormControl(),
            accountNumber: new FormControl(),
            accountService: new FormControl(),
            currencyCode: new FormControl(),
            bicCode: new FormControl(),
            accountTransferLimit: new FormControl(),
            accountStatus: new FormControl(),
            rateIndicator :  new FormControl()
        });
    }
}