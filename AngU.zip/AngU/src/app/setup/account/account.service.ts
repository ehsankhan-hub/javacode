import { Injectable } from "@angular/core";
import { HttpClient, HttpParams, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import { Constants } from "src/app/app.constants";
import { AccountEntity } from "./account.entity";

@Injectable()
export class AccountService {

    constructor(private http: HttpClient) { }

    fetchAllAccounts(customerId = '', status = '', accountnumber = '', type = '', pageNumber = 0, pageSize = 3): Observable<AccountEntity[]> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        var param = new HttpParams()
            .set('customerId', customerId)
            .set('status', status)
            .set('accountnumber', accountnumber)
            .set('accounttype', type)
            .set('pageNumber', pageNumber.toString())
            .set('pageSize', pageSize.toString());
        return this.http.get<any>(Constants.REST_URL + '/accounts/list', {
            params: param,
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

    findTotalAccounts(customerId = '', status = '', accountnumber = '', type = ''): Observable<any> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        var param = new HttpParams()
            .set('customerId', customerId)
            .set('status', status)
            .set('accountnumber', accountnumber)
            .set('accounttype', type);
        return this.http.get<any>(Constants.REST_URL + '/accounts/totalCount', {
            params: param,
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

    getAccount(customerId = '', accountNumber = '', accountType = ''): Observable<AccountEntity> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        return this.http.get<AccountEntity>(Constants.REST_URL + '/accounts/findAccount/' + customerId + '/' + accountNumber + '/' + accountType, {
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

    updateAccount(accountEntity: AccountEntity): Observable<any> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/json'
        });

        return this.http.post<AccountEntity>(Constants.REST_URL + '/accounts/updateAccount', accountEntity, {
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

    saveAccount(accountEntity: AccountEntity): Observable<any> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/json'
        });

        return this.http.post<AccountEntity>(Constants.REST_URL + '/accounts/createAccount', accountEntity, {
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

    listCustomers():  Observable<any> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/json'
        });

        return this.http.get<any>(Constants.REST_URL + '/customer/custemerIdNameList', {
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

    loadgenParameters(code : string):  Observable<any> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/json'
        });

        var param = new HttpParams()
            .set('tableCode', code);

        return this.http.get<any>(Constants.REST_URL + '/systemParameter/itemCodesByTableCode', {
            params: param,
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

    validateAccount(accountNumber : string):  Observable<any> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/json'
        });

        var param = new HttpParams()
            .set('accountNumber', accountNumber);

        return this.http.get<any>(Constants.REST_URL + '/accounts/validateAccount', {
            params: param,
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }
}