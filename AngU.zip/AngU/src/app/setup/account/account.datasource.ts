import { CollectionViewer, DataSource } from "@angular/cdk/collections";
import { catchError, finalize } from "rxjs/operators";
import { BehaviorSubject, of, Observable } from "rxjs";
import { AccountEntity } from "./account.entity";
import { AccountService } from "./account.service";

export class AccountDataSource implements DataSource<AccountEntity>{

    private accountSubject = new BehaviorSubject<AccountEntity[]>([]);

    private loadingSubject = new BehaviorSubject<boolean>(false);

    constructor(private accountService: AccountService) { }

    loadAccounts(customerId: string, status: string, accountnumber: string, accounttype: string, pageIndex: number,
        pageSize: number) {
        this.loadingSubject.next(true);
        this.accountService.fetchAllAccounts(customerId, status, accountnumber, accounttype, pageIndex, pageSize).pipe(
            catchError(() => of([])),
            finalize(() => this.loadingSubject.next(false))
        )
            .subscribe(accounts => this.accountSubject.next(accounts));
    }

    connect(collectionViewer: CollectionViewer): Observable<AccountEntity[]> {
        console.log("Connecting data source");
        return this.accountSubject.asObservable();
    }

    disconnect(collectionViewer: CollectionViewer): void {
        this.accountSubject.complete();
        this.loadingSubject.complete();
    }

}