import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { AccountEntity } from './account.entity';
import { AccountDataSource } from './account.datasource';
import { AccountService } from './account.service';
import { ActivatedRoute } from '@angular/router';
import { first, debounceTime, distinctUntilChanged, tap } from 'rxjs/operators';
import { fromEvent, merge } from 'rxjs';
import { MatSelect, MatPaginator } from '@angular/material';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss']
})
export class AccountComponent implements OnInit, AfterViewInit {

  selected: string;
  totalCount: LongRange;
  account: AccountEntity;
  datasource: AccountDataSource;
  displayedColumns = ["customerId", "accountNumber", "accountType", "accountStatus", "rateIndicator", "actions"];
  resourcesLoaded = true;
  @ViewChild('filterCustomerId') filterCustomerId: ElementRef;
  @ViewChild('filterStatus') filterStatus: MatSelect;
  @ViewChild('filterAccountNumber') filterAccountNumber: ElementRef;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private route: ActivatedRoute,
    private accountservice: AccountService) { }

  ngOnInit() {
    this.loadCount();
    this.selected = '';
    this.datasource = new AccountDataSource(this.accountservice);
    this.datasource.loadAccounts('', '', '', '', 0, 10);
  }
  ngAfterViewInit() {
    fromEvent(this.filterCustomerId.nativeElement, 'keyup')
      .pipe(
        debounceTime(150),
        distinctUntilChanged(),
        tap(() => {
          this.paginator.pageIndex = 0;
          this.loadAccountPage();
        })
      )
      .subscribe();


    fromEvent(this.filterAccountNumber.nativeElement, 'keyup')
      .pipe(
        debounceTime(150),
        distinctUntilChanged(),
        tap(() => {
          this.paginator.pageIndex = 0;
          this.loadAccountPage();
        })
      )
      .subscribe();


    this.filterStatus.optionSelectionChanges.subscribe(res => {
      this.paginator.pageIndex = 0;
      this.loadAccountPage();
    });

    // reset the paginator after sorting

    // on sort or paginate events, load a new page
    this.paginator.page
      .pipe(
        tap(() => this.loadAccountPage())
      )
      .subscribe();
  }

  loadCount() {
    this.resourcesLoaded = false;
    this.accountservice.findTotalAccounts('', '', '', '')
      .pipe(first())
      .subscribe(
        data => {
          this.totalCount = data.count;
          this.resourcesLoaded = true;
        },
        error => {
          console.log(error);
          this.resourcesLoaded = true;
        });
  }

  loadAccountPage() {
    this.datasource.loadAccounts(
      this.filterCustomerId.nativeElement.value,
      this.filterStatus.value,
      this.filterAccountNumber.nativeElement.value,
      '',
      this.paginator.pageIndex,
      this.paginator.pageSize);
  }

  editData(editData) {
    console.log(editData);
  }
}
