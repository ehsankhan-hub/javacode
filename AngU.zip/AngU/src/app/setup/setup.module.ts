import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from '../app-routing.module';
import { CustomMaterialModule } from '../custom-material.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SetupComponent } from './setup.component';
import { CustomerComponent } from './customer/customer.component';
import { CustomerService } from './customer/customer.service';
import { LayoutModule } from '@angular/cdk/layout';
import { CustomerEditComponent } from './customer/edit/edit.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CustomerAddComponent } from './customer/add/add.component';
import { AccountComponent } from './account/account.component';
import { AccountEditComponent } from './account/edit/accountedit.component';
import { AccountSaveComponent } from './account/add/accountadd.component';
import { AccountService } from './account/account.service';

@NgModule({
  declarations: [
    SetupComponent,CustomerComponent, AccountComponent, CustomerEditComponent, CustomerAddComponent,
    AccountEditComponent,AccountSaveComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CustomMaterialModule,
    FlexLayoutModule,
    LayoutModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [CustomerService,AccountService],
  bootstrap: [SetupComponent]
})
export class SetupModule { }
