import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from '../app-routing.module';
import { DashboardComponent } from './dashboard.component';
import { AppModule } from '../app.module';
import { CustomMaterialModule } from '../custom-material.module';
import { CustomLayoutComponent } from '../custom-layout/custom-layout.component';
import { PaymentDashboardComponent } from './payment/payment-dashboard/payment-dashboard.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { PaymentheadComponent } from './paymenthead/paymenthead.component';
import { PaymentdetailsComponent } from './paymentdetails/paymentdetails.component';
import { PaymentHeadService } from './paymenthead/paymenthead.service';
import { PaymentDetailsService } from './paymentdetails/paymendetails.service';
import { PayrollheaderComponent } from './payrollheader/payrollheader.component';
import { PayrolldetailsComponent } from './payrolldetails/payrolldetails.component';
import { PayrollDetailsService } from './payrolldetails/payrolldetails.service';
import { PayrollHeaderService } from './payrollheader/payrollheader.service';
import { FileLogService } from './filelogs/filelogs.service';
import { FileLogComponent } from './filelogs/filelogs.component';

@NgModule({
  declarations: [
    DashboardComponent,PaymentDashboardComponent, PaymentheadComponent, PaymentdetailsComponent, PayrollheaderComponent, PayrolldetailsComponent,FileLogComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CustomMaterialModule,
    FlexLayoutModule
  ],
  providers: [PaymentHeadService,PaymentDetailsService,PayrollHeaderService,PayrollDetailsService,FileLogService],
  bootstrap: [DashboardComponent]
})
export class DashboardModule { }
