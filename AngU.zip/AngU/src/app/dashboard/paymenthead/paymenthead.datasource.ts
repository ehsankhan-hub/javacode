import { PaymentHeadEntity } from "./paymenthead.entity";
import { DataSource } from "@angular/cdk/table";
import { BehaviorSubject, Observable, of } from "rxjs";
import { catchError, finalize } from "rxjs/operators";
import { CollectionViewer } from "@angular/cdk/collections";
import { PaymentHeadService } from "./paymenthead.service";

export class PaymentHeadDataSource implements DataSource<PaymentHeadEntity> 
{
    private paymentHeadSubject = new BehaviorSubject<PaymentHeadEntity[]>([]);

    private loadingSubject = new BehaviorSubject<boolean>(false);

    public loading$ = this.loadingSubject.asObservable();

    constructor(private paymentHeadervice: PaymentHeadService) {

    }

    loadPaymentHead(
                customerId: string,
                status: string,
                fileId:string,
                pageIndex:number,
                pageSize:number) {

        this.loadingSubject.next(true);

        this.paymentHeadervice.findAllHeader(customerId,status, fileId,
            pageIndex, pageSize).pipe(
                catchError(() => of([])),
                finalize(() => this.loadingSubject.next(false))
            )
            .subscribe(paymentHead => this.paymentHeadSubject.next(paymentHead));

    }

    connect(collectionViewer: CollectionViewer): Observable<PaymentHeadEntity[]> {
        console.log("Connecting data source");
        return this.paymentHeadSubject.asObservable();
    }

    disconnect(collectionViewer: CollectionViewer): void {
        this.paymentHeadSubject.complete();
        this.loadingSubject.complete();
    }

}