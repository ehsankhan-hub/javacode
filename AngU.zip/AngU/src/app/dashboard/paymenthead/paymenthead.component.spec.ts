import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentheadComponent } from './paymenthead.component';

describe('PaymentheadComponent', () => {
  let component: PaymentheadComponent;
  let fixture: ComponentFixture<PaymentheadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentheadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentheadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
