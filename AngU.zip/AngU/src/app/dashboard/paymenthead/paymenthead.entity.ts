export interface PaymentHeadEntity{
    customerId: string;
    fileId : string;
    status : string;
    description : string;
}