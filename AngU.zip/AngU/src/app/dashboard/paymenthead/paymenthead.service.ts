import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Observable } from "rxjs";
import { PaymentHeadEntity } from "./paymenthead.entity";
import { Constants } from "src/app/app.constants";
import { map } from "rxjs/operators";

@Injectable()
export class PaymentHeadService {
    constructor(private http: HttpClient) { }

    findAllHeader(
        customerId = '',
        fileId = '',
        status = '',
        pageNumber = 0, pageSize = 3): Observable<PaymentHeadEntity[]> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        var param = new HttpParams()
            .set('customerId', customerId)
            .set('status', status)
            .set('fileId', fileId)
            .set('pageNumber', pageNumber.toString())
            .set('pageSize', pageSize.toString());
        return this.http.get<any>(Constants.REST_URL + '/payment/header/list', {
            params: param,
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

    findTotalHeader(customerId = '',
    fileId = '',
    status = ''): Observable<any> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        var param = new HttpParams()
            .set('customerId', customerId)
            .set('status', status)
            .set('fileId', fileId);
        return this.http.get<any>(Constants.REST_URL + '/payment/header/count', {
            params: param,
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

}