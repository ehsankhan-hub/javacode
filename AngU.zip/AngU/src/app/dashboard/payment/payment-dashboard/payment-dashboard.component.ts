import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-dashboard',
  templateUrl: './payment-dashboard.component.html',
  styleUrls: ['./payment-dashboard.component.scss']
})
export class PaymentDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
