import { DataSource } from "@angular/cdk/table";
import { BehaviorSubject, Observable, of } from "rxjs";
import { catchError, finalize } from "rxjs/operators";
import { CollectionViewer } from "@angular/cdk/collections";
import { PaymentDetailsService } from "./paymendetails.service";
import { PaymentDetailsEntity } from "./paymentdetails.entity";

export class PaymentDetailsDataSource implements DataSource<PaymentDetailsEntity> 
{
    private paymentDetailsSubject = new BehaviorSubject<PaymentDetailsEntity[]>([]);

    private loadingSubject = new BehaviorSubject<boolean>(false);

    public loading$ = this.loadingSubject.asObservable();

    constructor(private paymentDetailservice: PaymentDetailsService) {

    }

    loadPaymentDetails(
                customerId: string,
                status: string,
                fileId:string,
                transactionRef : string,
                pageIndex:number,
                pageSize:number) {

        this.loadingSubject.next(true);

        this.paymentDetailservice.findAllDetails(customerId,status, fileId,transactionRef,
            pageIndex, pageSize).pipe(
                catchError(() => of([])),
                finalize(() => this.loadingSubject.next(false))
            )
            .subscribe(paymentDetails => this.paymentDetailsSubject.next(paymentDetails));

    }

    connect(collectionViewer: CollectionViewer): Observable<PaymentDetailsEntity[]> {
        console.log("Connecting data source");
        return this.paymentDetailsSubject.asObservable();
    }

    disconnect(collectionViewer: CollectionViewer): void {
        this.paymentDetailsSubject.complete();
        this.loadingSubject.complete();
    }

}