export interface PaymentDetailsEntity{
    customerId: string;
    fileId : string;
    transactionReference : string;
    status : string;
    description : string;
}