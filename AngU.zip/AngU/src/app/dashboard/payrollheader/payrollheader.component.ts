import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { MatPaginator, MatSort, MatSelect } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, tap, first } from 'rxjs/operators';
import { fromEvent, merge } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { PayrollHeaderDataSource } from './payrollheader.datasource';
import { PayrollHeaderService } from './payrollheader.service';
@Component({
  selector: 'app-payrollheader',
  templateUrl: './payrollheader.component.html',
  styleUrls: ['./payrollheader.component.scss']
})
export class PayrollheaderComponent implements OnInit, AfterViewInit {
  totalCount: LongRange;
  dataSource: PayrollHeaderDataSource;
  displayedColumns = ["customerId", "fileId", "status", "description", "actions"];
  selected = '';
  resourcesLoaded = true;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('filterCustomerId') filterCustomerId: ElementRef;
  @ViewChild('filterStatus') filterStatus: MatSelect;

  constructor(
    private route: ActivatedRoute,
    private toastaService: ToastrService,
    private payrollHeaderService: PayrollHeaderService,
    private router : Router) { }

  ngOnInit() {

    this.loadCount();
    this.dataSource = new PayrollHeaderDataSource(this.payrollHeaderService);
    this.dataSource.loadPayrollHeader('', '', '', 0, 3);
    console.log(this.route.snapshot);
  }

  ngAfterViewInit() {
    this.paginator.page
    .pipe(
        tap(() => this.loadPayrollHeaderPage())
    )
    .subscribe();
    // server-side search
    fromEvent(this.filterCustomerId.nativeElement, 'keyup')
      .pipe(
        debounceTime(150),
        distinctUntilChanged(),
        tap(() => {
          this.paginator.pageIndex = 0;
          this.loadPayrollHeaderPage();
        })
      )
      .subscribe();
    this.filterStatus.optionSelectionChanges.subscribe(res => {
      if (res.source.selected) {
        this.paginator.pageIndex = 0;
        this.loadPayrollHeaderPage();
      }

    });


  }

  loadPayrollHeaderPage() {
    this.dataSource.loadPayrollHeader(
      this.filterCustomerId.nativeElement.value,
      this.filterStatus.value,
      '',
      this.paginator.pageIndex,
      this.paginator.pageSize);
  }


  loadCount() {
    this.resourcesLoaded = false;
    this.payrollHeaderService.findTotalHeader(this.filterCustomerId.nativeElement.value,
      this.filterStatus.value,
      '')
      .pipe(first())
      .subscribe(
        data => {
          this.totalCount = data.count;
          this.resourcesLoaded = true;
        },
        error => {
          console.log(error);
          this.resourcesLoaded = true;
        });
  }
  details(row) {
    let customerId = row.customerId;
    let fileId = row.fileId;
    this.router.navigate(['/landing/dashboard/payrollDetails/'+customerId+"/"+fileId]);
  }
}
