export interface PayrollHeaderEntity{
    customerId: string;
    fileId : string;
    status : string;
    description : string;
}