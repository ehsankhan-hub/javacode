import { PayrollHeaderEntity } from "./payrollHeader.entity";
import { DataSource } from "@angular/cdk/table";
import { BehaviorSubject, Observable, of } from "rxjs";
import { catchError, finalize } from "rxjs/operators";
import { CollectionViewer } from "@angular/cdk/collections";
import { PayrollHeaderService } from "./payrollheader.service";

export class PayrollHeaderDataSource implements DataSource<PayrollHeaderEntity> 
{
    private payrollHeaderSubject = new BehaviorSubject<PayrollHeaderEntity[]>([]);

    private loadingSubject = new BehaviorSubject<boolean>(false);

    public loading$ = this.loadingSubject.asObservable();

    constructor(private payrollHeaderervice: PayrollHeaderService) {

    }

    loadPayrollHeader(
                customerId: string,
                status: string,
                fileId:string,
                pageIndex:number,
                pageSize:number) {

        this.loadingSubject.next(true);

        this.payrollHeaderervice.findAllHeader(customerId,status, fileId,
            pageIndex, pageSize).pipe(
                catchError(() => of([])),
                finalize(() => this.loadingSubject.next(false))
            )
            .subscribe(payrollHeader => this.payrollHeaderSubject.next(payrollHeader));

    }

    connect(collectionViewer: CollectionViewer): Observable<PayrollHeaderEntity[]> {
        console.log("Connecting data source");
        return this.payrollHeaderSubject.asObservable();
    }

    disconnect(collectionViewer: CollectionViewer): void {
        this.payrollHeaderSubject.complete();
        this.loadingSubject.complete();
    }

}