export interface FileLogEntity{
    type: string;
    fileId : string;
    status : string;
    description : string;
}