import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { MatPaginator, MatSort } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, tap, first } from 'rxjs/operators';
import { fromEvent, merge } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { FileLogDataSource } from './filelogs.datasource';
import { FileLogService } from './filelogs.service';
@Component({
  selector: 'app-filelogs',
  templateUrl: './filelogs.component.html',
  styleUrls: ['./filelogs.component.scss']
})
export class FileLogComponent implements OnInit, AfterViewInit {
  totalCount: LongRange;
  dataSource: FileLogDataSource;
  displayedColumns = ["fileId","type", "status", "description","time"];
  selected = '';
  resourcesLoaded = true;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private route: ActivatedRoute,
    private toastaService: ToastrService,
    private fileLogService: FileLogService,
    private router : Router) { }

  ngOnInit() {

    this.loadCount();
    this.dataSource = new FileLogDataSource(this.fileLogService);
    this.dataSource.lodLogs('','',0,10);
    console.log(this.route.snapshot);
  }

  ngAfterViewInit() {
    this.paginator.page
    .pipe(
        tap(() => this.loadLogs())
    )
    .subscribe();
  }

  loadLogs() {
    this.dataSource.lodLogs(
      '',
      '',
      this.paginator.pageIndex,
      this.paginator.pageSize);
  }


  loadCount() {
    this.resourcesLoaded = false;
    this.fileLogService.findTotalLogs(
      '','')
      .pipe(first())
      .subscribe(
        data => {
          this.totalCount = data.count;
          this.resourcesLoaded = true;
        },
        error => {
          console.log(error);
          this.resourcesLoaded = true;
        });
  }
}
