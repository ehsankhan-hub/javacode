import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Observable } from "rxjs";
import { Constants } from "src/app/app.constants";
import { map } from "rxjs/operators";
import { FileLogEntity } from "./filelogs.entity";

@Injectable()
export class FileLogService {
    constructor(private http: HttpClient) { }

    findLogs(
        fileId = '',
        type = '',
        pageNumber = 0, pageSize = 10): Observable<FileLogEntity[]> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        var param = new HttpParams()
            .set('type', type)
            .set('fileId', fileId)
            .set('pageNumber', pageNumber.toString())
            .set('pageSize', pageSize.toString());
        return this.http.get<any>(Constants.REST_URL + '/payment/filelogs', {
            params: param,
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

    findTotalLogs(
        fileId = '',
        type = ''): Observable<any> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        var param = new HttpParams()
            .set('fileId', fileId)
            .set('type', type);
        return this.http.get<any>(Constants.REST_URL + '/payment/filelogs/count', {
            params: param,
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }


}