import { DataSource } from "@angular/cdk/table";
import { BehaviorSubject, Observable, of } from "rxjs";
import { catchError, finalize } from "rxjs/operators";
import { CollectionViewer } from "@angular/cdk/collections";
import { FileLogEntity } from "./filelogs.entity";
import { FileLogService } from "./filelogs.service";

export class FileLogDataSource implements DataSource<FileLogEntity> 
{
    private paymentHeadSubject = new BehaviorSubject<FileLogEntity[]>([]);

    private loadingSubject = new BehaviorSubject<boolean>(false);

    public loading$ = this.loadingSubject.asObservable();

    constructor(private paymentHeadervice: FileLogService) {

    }

    lodLogs(
                type: string,
                fileId:string,
                pageIndex:number,
                pageSize:number) {

        this.loadingSubject.next(true);

        this.paymentHeadervice.findLogs(fileId,type,
            pageIndex, pageSize).pipe(
                catchError(() => of([])),
                finalize(() => this.loadingSubject.next(false))
            )
            .subscribe(paymentHead => this.paymentHeadSubject.next(paymentHead));

    }

    connect(collectionViewer: CollectionViewer): Observable<FileLogEntity[]> {
        console.log("Connecting data source");
        return this.paymentHeadSubject.asObservable();
    }

    disconnect(collectionViewer: CollectionViewer): void {
        this.paymentHeadSubject.complete();
        this.loadingSubject.complete();
    }

}