import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayrolldetailsComponent } from './payrolldetails.component';

describe('PayrolldetailsComponent', () => {
  let component: PayrolldetailsComponent;
  let fixture: ComponentFixture<PayrolldetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayrolldetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayrolldetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
