import { Component, OnInit, ViewChild, AfterViewInit, ElementRef } from '@angular/core';
import { MatPaginator, MatSort, MatSelect } from '@angular/material';
import { PayrollDetailsDataSource } from './payrolldetails.datasource';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PayrollDetailsService } from './payrolldetails.service';
import { tap, debounceTime, distinctUntilChanged, first } from 'rxjs/operators';
import { fromEvent } from 'rxjs';

@Component({
  selector: 'app-payrolldetails',
  templateUrl: './payrolldetails.component.html',
  styleUrls: ['./payrolldetails.component.scss']
})
export class PayrolldetailsComponent implements OnInit, AfterViewInit {
  customerId: string;
  fileId: string;
  totalCount: LongRange;
  dataSource: PayrollDetailsDataSource;
  displayedColumns = ["customerId", "fileId", "status", "description", "actions"];
  selected = '';
  resourcesLoaded = true;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('filterCustomerId') filterCustomerId: ElementRef;
  @ViewChild('filterTransactionId') filterTransactionId: ElementRef;
  @ViewChild('filterFileId') filterFileId: ElementRef;
  @ViewChild('filterStatus') filterStatus: MatSelect;

  constructor(
    private route: ActivatedRoute,
    private toastaService: ToastrService,
    private paymendDetailsService: PayrollDetailsService,
    private router: Router) { }

  ngOnInit() {

    this.loadCount();
    this.dataSource = new PayrollDetailsDataSource(this.paymendDetailsService);
    this.dataSource.loadPayrollDetails('', '', '', '', 0, 3);
    console.log(this.route.snapshot);
    this.route.params.subscribe(params => {
      console.log(params);
      this.customerId = params['customerId'];
      this.fileId = params['fileId'];
      this.filterCustomerId.nativeElement.value = this.customerId;
      this.filterFileId.nativeElement.value = this.fileId;

    });
  }

  ngAfterViewInit() {
    this.paginator.page
      .pipe(
        tap(() => this.loadPayrollDetailsPage())
      )
      .subscribe();
    // server-side search
    fromEvent(this.filterCustomerId.nativeElement, 'keyup')
      .pipe(
        debounceTime(150),
        distinctUntilChanged(),
        tap(() => {
          this.paginator.pageIndex = 0;
          this.loadPayrollDetailsPage();
        })
      )
      .subscribe();

    fromEvent(this.filterTransactionId.nativeElement, 'keyup')
      .pipe(
        debounceTime(150),
        distinctUntilChanged(),
        tap(() => {
          this.paginator.pageIndex = 0;
          this.loadPayrollDetailsPage();
        })
      )
      .subscribe();

    fromEvent(this.filterFileId.nativeElement, 'keyup')
      .pipe(
        debounceTime(150),
        distinctUntilChanged(),
        tap(() => {
          this.paginator.pageIndex = 0;
          this.loadPayrollDetailsPage();
        })
      )
      .subscribe();




    this.filterStatus.optionSelectionChanges.subscribe(res => {
      if (res.source.selected) {
        this.paginator.pageIndex = 0;
        this.loadPayrollDetailsPage();
      }

    });
  }

  loadPayrollDetailsPage() {
    this.dataSource.loadPayrollDetails(
      this.filterCustomerId.nativeElement.value,
      this.filterStatus.value,
      this.filterFileId.nativeElement.value,
      this.filterTransactionId.nativeElement.value,
      this.paginator.pageIndex,
      this.paginator.pageSize);
  }


  loadCount() {
    this.resourcesLoaded = false;
    this.paymendDetailsService.findTotalDetails(this.filterCustomerId.nativeElement.value,
      this.filterStatus.value,
      this.filterFileId.nativeElement.value,
      this.filterTransactionId.nativeElement.value)
      .pipe(first())
      .subscribe(
        data => {
          this.totalCount = data.count;
          this.resourcesLoaded = true;
        },
        error => {
          console.log(error);
          this.resourcesLoaded = true;
        });
  }
  details(row) {
    let customerId = row.customerId;
    let fileId = row.fileId;
    this.router.navigate(['/landing/dashboard/payrollDetails/' + customerId + "/" + fileId]);
  }
}
