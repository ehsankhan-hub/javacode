export interface PayrollDetailsEntity{
    customerId: string;
    fileId : string;
    transactionReference : string;
    status : string;
    description : string;
}