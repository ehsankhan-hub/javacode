import { DataSource } from "@angular/cdk/table";
import { BehaviorSubject, Observable, of } from "rxjs";
import { catchError, finalize } from "rxjs/operators";
import { CollectionViewer } from "@angular/cdk/collections";
import { PayrollDetailsEntity } from "./payrolldetails.entity";
import { PayrollDetailsService } from "./payrolldetails.service";

export class PayrollDetailsDataSource implements DataSource<PayrollDetailsEntity> 
{
    private payrollDetailsSubject = new BehaviorSubject<PayrollDetailsEntity[]>([]);

    private loadingSubject = new BehaviorSubject<boolean>(false);

    public loading$ = this.loadingSubject.asObservable();

    constructor(private payrollDetailservice: PayrollDetailsService) {

    }

    loadPayrollDetails(
                customerId: string,
                status: string,
                fileId:string,
                transactionRef : string,
                pageIndex:number,
                pageSize:number) {

        this.loadingSubject.next(true);

        this.payrollDetailservice.findAllDetails(customerId,status, fileId,transactionRef,
            pageIndex, pageSize).pipe(
                catchError(() => of([])),
                finalize(() => this.loadingSubject.next(false))
            )
            .subscribe(payrollDetails => this.payrollDetailsSubject.next(payrollDetails));

    }

    connect(collectionViewer: CollectionViewer): Observable<PayrollDetailsEntity[]> {
        console.log("Connecting data source");
        return this.payrollDetailsSubject.asObservable();
    }

    disconnect(collectionViewer: CollectionViewer): void {
        this.payrollDetailsSubject.complete();
        this.loadingSubject.complete();
    }

}