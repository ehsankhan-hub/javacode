import { Injectable } from "@angular/core";
import { HttpClient, HttpParams, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { Constants } from "src/app/app.constants";
import { map } from "rxjs/operators";
import { PayrollDetailsEntity } from "./payrolldetails.entity";

@Injectable()
export class PayrollDetailsService {
    constructor(private http: HttpClient) { }

    findAllDetails(
        customerId = '',
        status = '',
        fileId = '',
        transactionRef = '',        
        pageNumber = 0, pageSize = 3): Observable<PayrollDetailsEntity[]> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        var param = new HttpParams()
            .set('customerId', customerId)
            .set('status', status)
            .set('fileId', fileId)
            .set('transactionRef', transactionRef)
            .set('pageNumber', pageNumber.toString())
            .set('pageSize', pageSize.toString());
        return this.http.get<any>(Constants.REST_URL + '/payroll/details/list', {
            params: param,
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

    findTotalDetails(customerId = '',
    fileId = '',
    transactionRef = '',
    status = ''): Observable<any> {
        var headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        var param = new HttpParams()
            .set('customerId', customerId)
            .set('status', status)
            .set('fileId', fileId)
            .set('transactionRef', transactionRef);
        return this.http.get<any>(Constants.REST_URL + '/payroll/details/count', {
            params: param,
            headers: headers
        }).pipe(
            map(res => { return res })
        );
    }

}