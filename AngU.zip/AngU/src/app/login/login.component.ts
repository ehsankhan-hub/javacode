import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from './login.service';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { first } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'login-template',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
    loginForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;
    error = '';
    username = "";
    password = "";
    showSpinner = false;
    usernameFormControl;
    passwordFormControl;
    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private toastaService: ToastrService,
        private authenticationService: AuthenticationService) { }

    ngOnInit() {
        this.usernameFormControl = new FormControl('', [Validators.required]);
        this.passwordFormControl = new FormControl('', [Validators.required]);

        this.loginForm = this.formBuilder.group({
            username: this.usernameFormControl,
            password: this.passwordFormControl
        });

        // reset login status
        // this.authenticationService.logout();

        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    }

    // convenience getter for easy access to form fields
    get f() { return this.loginForm.controls; }

    onSubmit() {
        // stop here if form is invalid
        if (this.loginForm.invalid) {
            return;
        }
        this.submitted = true;
        this.loading = true;
        this.authenticationService.login(this.f.username.value, this.f.password.value)
            .pipe(first())
            .subscribe(
                data => {
                    this.returnUrl = "/";
                    console.log(data);
                    if (data.access_token) {
                        this.returnUrl = "landing";
                    }
                    this.toastaService.success("Login Successful.");
                    this.router.navigate([this.returnUrl]);
                },
                error => {
                    this.error = error;
                    this.loading = false;
                    this.toastaService.error("Login Failed. Invalid credentials!!!");
                });
    }

    keyDownFunction(event) {
        if(event.keyCode == 13) {
            this.onSubmit();
        }
      }
}
