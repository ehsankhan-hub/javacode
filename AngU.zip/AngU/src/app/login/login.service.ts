import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Constants } from '../app.constants';
@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    constructor(private http: HttpClient) {

    }

    login(userId: string, userPassword: string) {
        const body = new HttpParams()
            .set('grant_type', "password")
            .set('username', userId)
            .set('password', userPassword)
            
       
        var basic = "Basic " + btoa("BSF:bsf@999");
        var headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': basic });
        var options = { headers: headers };

        return this.http.post<any>(Constants.REST_URL+'/oauth/token', body,options)
        
            .pipe(map(result => {
                // login successful if there's a jwt token in the response
               /* if (jhjh && jhjh.token) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', JSON.stringify(user));
                }*/

                if(result.access_token){
                    localStorage.setItem('currentUser', result.access_token);  
                }

                return result;
            }));
    }

    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
    }
}