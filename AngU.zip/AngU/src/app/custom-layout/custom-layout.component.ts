import { Component } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Constants } from '../app.constants';

@Component({
  selector: 'app-custom-layout',
  templateUrl: './custom-layout.component.html',
  styleUrls: ['./custom-layout.component.scss'],
})
export class CustomLayoutComponent {
  resourcesLoaded: boolean;
  navList = '';
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );

  constructor(private breakpointObserver: BreakpointObserver, private http: HttpClient,
    private router: Router) {
    var token = localStorage.getItem('currentUser');
    var headers = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded'
    });
    var options = { headers: headers };
    this.resourcesLoaded = false;
    this.http.get(Constants.REST_URL + '/users/navList', options)
      .subscribe(
        result => {
          if (result["data"]) {
            this.navList = result["data"];
            this.resourcesLoaded = true;
          }

        },
        error => {
          console.log("Rrror", error);
          localStorage.removeItem('currentUser');
          location.reload();
        }
      );
  }

  onLogout() {
    var token = localStorage.getItem('currentUser');
    console.log(token)
    var headers = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded'
    });
    var options = { headers: headers };
    this.http.post<any>(Constants.REST_URL + '/users/logout', {}, options)
      .subscribe(
        data => {
          if (data.status) {
            localStorage.removeItem('currentUser');
            location.reload();
          }

        },
        error => {
          console.log("Rrror", error);
          localStorage.removeItem('currentUser');
          location.reload();
        }
      );
  }
}


