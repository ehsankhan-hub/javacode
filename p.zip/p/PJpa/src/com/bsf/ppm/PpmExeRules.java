package com.bsf.ppm;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;
import org.hibernate.annotations.GenericGenerator;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.SelectableAuditableEntity;

/**
 * <p>Pojo mapping TABLE OEPAYSD.PPM_GROUP</p>
 *
 * <p>Generated at Wed Aug 10 12:21:25 AST 2016</p>
 * @author Salto-db Generator v1.0.16 / EJB3
 * 
 */
@Entity
@Table(name = "PPM_EXE_RULES")
@SuppressWarnings("serial")
public class PpmExeRules extends SelectableAuditableEntity  {

	/**
	 * Attribute groupCode.
	 */
	private String groupCode;
	
	
	private int ruleId;
	
	/**
	 * Attribute groupName.
	 */
	public String exeRuleName;
	
	/**
	 * Attribute groupDesc.
	 */
	private String exeType;
	
	/**
	 * Attribute groupPriority.
	 */
	private String exeRuleDesc;
	
	/**
	 * Attribute groupPercent.
	 */
	private String comments;
	
	/**
	 * Attribute status.
	 */
	private String status;
	
	/**
	 * Attribute createDate.
	 */
	private Date createDate;
	
	/**
	 * Attribute createdBy.
	 */
	private UserInfo createdBy;
	
	/**
	 * Attribute updateDate.
	 */
	private Date updateDate;
	
	/**
	 * Attribute updatedBy.
	 */
	private UserInfo updatedBy;
	
	
	private Long rulesCount;
	
	protected boolean selected;
	
	
	/**
	 * List of PpmExeRulesCriteria
	 */
	private List<PpmExeRulesCriteria> ppmExeRulesCriteria = null;
    
		
	public PpmExeRules(){
		
	}
	/**
	 * @return groupCode
	 */
	@Id
	@Basic
	@Column(name="EXE_RULE_NAME")	
	public String getExeRuleName() {
		return exeRuleName;
	}

	
	public void setExeRuleName(String exeRuleName) {
		this.exeRuleName = exeRuleName;
	}
		
	
	@Column(name = "GROUP_CODE", length = 5)
		public String getGroupCode() {
		return groupCode;
	}
   	
	/**
	 * @param groupCode new value for groupCode 
	 */
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	
	@Column(name="EXE_TYPE")	
	public String getExeType() {
		return exeType;
	}

	public void setExeType(String exeType) {
		this.exeType = exeType;
	}
	@Column(name="EXE_RULE_DESC")	
	public String getExeRuleDesc() {
		return exeRuleDesc;
	}

	public void setExeRuleDesc(String exeRuleDesc) {
		this.exeRuleDesc = exeRuleDesc;
	}
	@Column(name="COMMENTS")	
	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * @return status
	 */
	@Basic
	@Column(name = "STATUS", length = 1)
		public String getStatus() {
		return status;
	}

	/**
	 * @param status new value for status 
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * @return createDate
	 */
	@Basic
	@Column(name = "CREATE_DATE")
		public Date getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate new value for createDate 
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	
	/**
	 * @return createdBy
	 */
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "CREATED_BY")
		public UserInfo getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy new value for createdBy 
	 */
	public void setCreatedBy(UserInfo createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * @return updateDate
	 */
	@Basic
	@Column(name = "UPDATE_DATE")
		public Date getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate new value for updateDate 
	 */
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	
	/**
	 * @return updatedBy
	 */
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "UPDATED_BY")
		public UserInfo getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy new value for updatedBy 
	 */
	public void setUpdatedBy(UserInfo updatedBy) {
		this.updatedBy = updatedBy;
	}
    
	@XmlTransient
	@Transient
	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
	this.selected = selected;
	}
	
	/**
	 * Get the list of PpmExeRulesCriteria
	 */
	@OneToMany(fetch = FetchType.EAGER,mappedBy = "ppmExeRules", cascade = CascadeType.ALL)
	public List<PpmExeRulesCriteria> getPpmExeRulesCriteria() {
		return ppmExeRulesCriteria;
	}
	public void setPpmExeRulesCriteria(List<PpmExeRulesCriteria> ppmExeRulesCriteria) {
		this.ppmExeRulesCriteria = ppmExeRulesCriteria;
	}
	
	/*@Override
	@Transient
	public int compareTo(PpmExeRules benInfo) 
	{
    int anotherBenInfoOrderId =  benInfo.getRuleId();
    return (int) (this.getRuleId() - ruleId);    
}*/
	
	@Override
	@XmlTransient
	@Transient
	public String getPk() {
		return getExeRuleName();
	}
	
	


}