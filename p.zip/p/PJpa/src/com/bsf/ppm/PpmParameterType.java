package com.bsf.ppm;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.GenericGenerator;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.SelectableAuditableEntity;

/**
 * <p>Pojo mapping TABLE OEPAYSD.PPM_GROUP</p>
 *
 * <p>Generated at Wed Aug 10 12:21:25 AST 2016</p>
 * @author Salto-db Generator v1.0.16 / EJB3
 * 
 */
@Entity
@Table(name = "PPM_PARAMETER_TYPE")
@SuppressWarnings("serial")
public class PpmParameterType extends SelectableAuditableEntity  {

	/**
	 * Attribute paramTypeId.
	 */
	private int paramTypeId;
	
	/**
	 * Attribute parmtypecode.
	 */
	private String parmtypecode;
	/**
	 * Attribute paramDesc.
	 */
	public String paramDesc;
	
	/**
	 * Attribute valueType.
	 */
	private String valueType;
	
	/**
	 * Attribute isMultiValue.
	 */
	private String isMultiValue;
	
	/**
	 * Attribute isRange.
	 */
	private String isRange;
	
	/**
	 * Attribute isUserMaint.
	 */
	private String isUserMaint;
	
	/**
	 * Attribute createDate.
	 */
	private Date createDate;
	
	/**
	 * Attribute createdBy.
	 */
	private UserInfo createdBy;
	
	/**
	 * Attribute updateDate.
	 */
	private Date updateDate;
	
	/**
	 * Attribute updatedBy.
	 */
	private UserInfo updatedBy;
	
	
	private Long rulesCount;
	
	protected boolean selected;
	
	
	/**
	 * List of PpmExeRulesCriteria
	 */
	private List<PpmParameterValue> ppmParameterValue = null;
    
		
	public PpmParameterType(){
		
	}
	
	/**
	 * @return groupCode
	 */
	/*@Id
	@Basic
	@SequenceGenerator(name = "instructionSeq", sequenceName = "PPM_INS_REF")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "instructionSeq")*/
	@Id
	@Basic
	/*@GenericGenerator(name="generator", strategy="increment")
	@GeneratedValue(generator="generator")*/
	/*@Column(name="PARAM_TYPE_ID")
	public int getParamTypeId() {
		return paramTypeId;
	}

	public void setParamTypeId(int paramTypeId) {
		this.paramTypeId = paramTypeId;
	}
	*/
	@Column(name="PARAM_TYPE_CODE")	
	public String getParmtypecode() {
		return parmtypecode;
	}

	public void setParmtypecode(String parmtypecode) {
		this.parmtypecode = parmtypecode;
	}
	
	
	@Column(name="DESCR")	
	public String getParamDesc() {
		return paramDesc;
	}
	

	public void setParamDesc(String paramDesc) {
		this.paramDesc = paramDesc;
	}
	@Column(name="VALUE_TYPE")	
	public String getValueType() {
		return valueType;
	}
	public void setValueType(String valueType) {
		this.valueType = valueType;
	}
	@Column(name="IS_MULTI_VALUE")	
	public String getIsMultiValue() {
		return isMultiValue;
	}
	public void setIsMultiValue(String isMultiValue) {
		this.isMultiValue = isMultiValue;
	}
	@Column(name="IS_RANGE")	
	public String getIsRange() {
		return isRange;
	}
	public void setIsRange(String isRange) {
		this.isRange = isRange;
	}
	@Column(name="IS_USER_MAINTAIN")	
	public String getIsUserMaint() {
		return isUserMaint;
	}
	public void setIsUserMaint(String isUserMaint) {
		this.isUserMaint = isUserMaint;
	}
	
	/**
	 * @return createDate
	 */
	@Basic
	@Column(name = "CREATE_DATE")
		public Date getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate new value for createDate 
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	
	/**
	 * @return createdBy
	 */
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "CREATED_BY")
		public UserInfo getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy new value for createdBy 
	 */
	public void setCreatedBy(UserInfo createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * @return updateDate
	 */
	@Basic
	@Column(name = "UPDATE_DATE")
		public Date getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate new value for updateDate 
	 */
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	
	/**
	 * @return updatedBy
	 */
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "UPDATED_BY")
		public UserInfo getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy new value for updatedBy 
	 */
	public void setUpdatedBy(UserInfo updatedBy) {
		this.updatedBy = updatedBy;
	}
    
	/**
	 * Get the list of PpmExeRulesCriteria
	 */
	
	@OneToMany(fetch = FetchType.EAGER,mappedBy = "ppmParameterType", cascade = CascadeType.ALL)
	public List<PpmParameterValue> getPpmParameterValue() {
		return ppmParameterValue;
	}

	public void setPpmParameterValue(List<PpmParameterValue> ppmParameterValue) {
		this.ppmParameterValue = ppmParameterValue;
	}

	
	
	
	/*@Override
	@Transient
	public int compareTo(PpmExeRules benInfo) 
	{
    int anotherBenInfoOrderId =  benInfo.getRuleId();
    return (int) (this.getRuleId() - ruleId);    
}*/
	
	@Override
	@XmlTransient
	@Transient
	public String getPk() {
		return getParmtypecode();
	}

	
	


}