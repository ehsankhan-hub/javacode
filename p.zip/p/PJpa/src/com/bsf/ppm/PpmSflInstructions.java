package com.bsf.ppm;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlTransient;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.SelectableAuditableEntity;

@Entity
@Table(name = "PPM_SFL_INSTRUCTIONS")
public class PpmSflInstructions extends SelectableAuditableEntity{
	private static final long serialVersionUID = 10000002345L;
	private String instReference;
	private String debitAccount;
	private String creditAccount;
	private Date instStartDate;
	private int noOfInst;
	private BigDecimal instTotalAmount;
	private int instAmount;
	private Date instEndDate;
	private String frequency;
	private int dayOfPayment;
	private int maxDayRange;
	/**
	 * Attribute createdDate.
	 */
	private Timestamp createdDate;
	
	/**
	 * Attribute userInfo
	 */
	 private String createdBy;
	 
	 private int rowNumber;
	 
	 private String columnName;
	 
	 private String columnValue;
	 
	 private String errorValue;
	 
	
	 
	 
	 
	 @Id 
	 @Basic
	 @Column(name = "INST_REFERENCE")
	 public String getInstReference() {
		return instReference;
	}




	public void setInstReference(String instReference) {
		this.instReference = instReference;
	}



	@Column(name = "DEBIT_ACCOUNT")
	public String getDebitAccount() {
		return debitAccount;
	}




	public void setDebitAccount(String debitAccount) {
		this.debitAccount = debitAccount;
	}


	@Column(name = "CREDIT_ACCOUNT")
	public String getCreditAccount() {
		return creditAccount;
	}

	public void setCreditAccount(String creditAccount) {
		this.creditAccount = creditAccount;
	}

   
	@Column(name="NO_OF_INST")
	public int getNoOfInst() {
		return noOfInst;
	}
	public void setNoOfInst(int noOfInst) {
		this.noOfInst = noOfInst;
	}
	
	@Column(name="TOTAL_AMOUNT")
	public BigDecimal getInstTotalAmount() {
		return instTotalAmount;
	}
	public void setInstTotalAmount(BigDecimal instTotalAmount) {
		this.instTotalAmount = instTotalAmount;
	}
	
	@Column(name="INST_AMOUNT")
	public int getInstAmount() {
		return instAmount;
	}

	public void setInstAmount(int instAmount) {
		this.instAmount = instAmount;
	}


	@Column(name = "START_DATE_G")
	public Date getInstStartDate() {
		return instStartDate;
	}

	public void setInstStartDate(Date instStartDate) {
		this.instStartDate = instStartDate;
	}
	
	



	@Column(name = "END_DATE_G")
	public Date getInstEndDate() {
		return instEndDate;
	}




	public void setInstEndDate(Date instEndDate) {
		this.instEndDate = instEndDate;
	}



	@Column(name = "FREQUENCY")
	public String getFrequency() {
		return frequency;
	}




	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}



	@Column(name = "DAY_OF_PAYMENT")
	public int getDayOfPayment() {
		return dayOfPayment;
	}




	public void setDayOfPayment(int dayOfPayment) {
		this.dayOfPayment = dayOfPayment;
	}



	@Column(name = "MAX_DAYS_RANGE")
	public int getMaxDayRange() {
		return maxDayRange;
	}




	public void setMaxDayRange(int maxDayRange) {
		this.maxDayRange = maxDayRange;
	}



	@Column(name = "CREATED_DATE")
	public Timestamp getCreatedDate() {
		return createdDate;
	}




	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}



	 @Column(name = "CREATED_BY")
	//@ManyToOne(cascade=CascadeType.MERGE)
	//@JoinColumn(name = "CREATED_BY")
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

       @Override
		@XmlTransient
		@Transient
		public String getPk() {
			return String.valueOf(getInstReference());
		}


    @Transient
   	public int getRowNumber() {
   		return rowNumber;
   	}

   	public void setRowNumber(int rowNumber) {
   		this.rowNumber = rowNumber;
   	}
   	
   	@Transient
    public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
    
	@Transient
	public String getColumnValue() {
		return columnValue;
	}

	public void setColumnValue(String columnValue) {
		this.columnValue = columnValue;
	}




	@Transient
	public String getErrorValue() {
		return errorValue;
	}

	public void setErrorValue(String errorValue) {
		this.errorValue = errorValue;
	}



	


    
	
	
	
   
       
       
}
