package com.bsf.ppm;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlTransient;
import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.SelectableAuditableEntity;

/**
 * <p>Pojo mapping TABLE OEPAYSD.PPM_GROUP</p>
 *
 * <p>Generated at Wed Aug 10 12:21:25 AST 2016</p>
 * @author Salto-db Generator v1.0.16 / EJB3
 * 
 */
@Entity
@Table(name = "PPM_GROUP")
@SuppressWarnings("serial")
public class PpmGroup extends SelectableAuditableEntity {

	/**
	 * Attribute groupCode.
	 */
	private String groupCode;
	
	/**
	 * Attribute groupName.
	 */
	private String groupName;
	
	/**
	 * Attribute groupDesc.
	 */
	private String groupDesc;
	
	/**
	 * Attribute groupPriority.
	 */
	private int groupPriority;
	
	/**
	 * Attribute groupPercent.
	 */
	private int groupPercent;
	
	/**
	 * Attribute status.
	 */
	private String status;
	
	/**
	 * Attribute createDate.
	 */
	private Date createDate;
	
	/**
	 * Attribute createdBy.
	 */
	private UserInfo createdBy;
	
	/**
	 * Attribute updateDate.
	 */
	private Date updateDate;
	
	/**
	 * Attribute updatedBy.
	 */
	private UserInfo updatedBy;
	
	
	/**
	 * @return groupCode
	 */
	@Id
	@Basic
	@Column(name = "GROUP_CODE", length = 5)
		public String getGroupCode() {
		return groupCode;
	}

	/**
	 * @param groupCode new value for groupCode 
	 */
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	
	/**
	 * @return groupName
	 */
	@Basic
	@Column(name = "GROUP_NAME", length = 30)
		public String getGroupName() {
		return groupName;
	}

	/**
	 * @param groupName new value for groupName 
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	/**
	 * @return groupDesc
	 */
	@Basic
	@Column(name = "GROUP_DESC", length = 50)
		public String getGroupDesc() {
		return groupDesc;
	}

	/**
	 * @param groupDesc new value for groupDesc 
	 */
	public void setGroupDesc(String groupDesc) {
		this.groupDesc = groupDesc;
	}
	
	/**
	 * @return groupPriority
	 */
	@Basic
	@Column(name = "GROUP_PRIORITY")
		public int getGroupPriority() {
		return groupPriority;
	}

	/**
	 * @param groupPriority new value for groupPriority 
	 */
	public void setGroupPriority(int groupPriority) {
		this.groupPriority = groupPriority;
	}
	
	/**
	 * @return groupPercent
	 */
	@Basic
	@Column(name = "GROUP_PERCENT")
		public int getGroupPercent() {
		return groupPercent;
	}

	/**
	 * @param groupPercent new value for groupPercent 
	 */
	public void setGroupPercent(int groupPercent) {
		this.groupPercent = groupPercent;
	}
	
	/**
	 * @return status
	 */
	@Basic
	@Column(name = "STATUS", length = 1)
		public String getStatus() {
		return status;
	}

	/**
	 * @param status new value for status 
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * @return createDate
	 */
	@Basic
	@Column(name = "CREATE_DATE")
		public Date getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate new value for createDate 
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	
	/**
	 * @return createdBy
	 */
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "CREATED_BY")
		public UserInfo getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy new value for createdBy 
	 */
	public void setCreatedBy(UserInfo createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * @return updateDate
	 */
	@Basic
	@Column(name = "UPDATE_DATE")
		public Date getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate new value for updateDate 
	 */
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	
	/**
	 * @return updatedBy
	 */
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "UPDATED_BY")
		public UserInfo getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy new value for updatedBy 
	 */
	public void setUpdatedBy(UserInfo updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	@XmlTransient
	@Transient
	public String getPk() {
		return getGroupCode();
	}
	


}