package com.bsf.ppm;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

@Embeddable
public class EmbeddedValueId implements Serializable{
	private String parmtypecode;	
	private String value1;
	private String groupCode;
	//private String value2;
	private static final long serialVersionUID = 1L;
	
	@Column(name="PARAM_TYPE_CODE")
	public String getParmtypecode() {
		return parmtypecode;
	}
	public void setParmtypecode(String parmtypecode) {
		this.parmtypecode = parmtypecode;
	}
	@Column(name="VALUE1")
	public String getValue1() {
		return value1;
	}
	public void setValue1(String value1) {
		this.value1 = value1;
	}
	@Column(name="GROUP_CODE")
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	
	public EmbeddedValueId(){
		
	}
     public EmbeddedValueId(String parmtypecode,String value1,String groupCode){
	 super();
    	 this.parmtypecode=parmtypecode;
	 this.value1=value1;
	 this.groupCode=groupCode;
	}
//	@Column(name="VALUE2")
//	public String getValue2() {
//		return value2;
//	}
//	public void setValue2(String value2) {
//		this.value2 = value2;
//	}
	
     // Must have a equals method
     @Override
 	 public boolean equals(Object obj) {
	        if (obj == null) return false;
	        if (!this.getClass().equals(obj.getClass())) return false;
	         
	        EmbeddedValueId obj2 = (EmbeddedValueId)obj;
	 
	        if (this.parmtypecode.equals(obj2.getParmtypecode()) &&
	            this.groupCode.equals(obj2.getGroupCode()) && this.value1.equals(obj2.getValue1())) {
	            return true;
	        }
	        return false;
	    }
     // Must have a hashCode method
     @Override
      public int hashCode() {      
	        int tmp = 0;
	        tmp = (parmtypecode + groupCode+value1).hashCode();
	        return tmp;
	    }
	}

	
	

