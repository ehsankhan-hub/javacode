package com.bsf.ppm;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.bsf.ipp.UserInfo;

/**
 * <p>Pojo mapping TABLE IPPUSER.MAIL_MESSAGE</p>
 * @author Kaza
 * 
 */
@Entity
@NamedQueries({
	@NamedQuery(name = "MailMessage.findAll", 
	    query = "select o from MailMessage o"),
	@NamedQuery(name = "MailMessage.findUnprocessedMails", 
	    	    query = "select o from MailMessage o where o.mailStatus=:mailStatus and " +
	    	    		"(o.processingDate is null OR trunc(o.processingDate)<=trunc(SYSDATE))")
})
@Table(name = "MAIL_MESSAGE")
@SuppressWarnings("serial")
public class MailMessage implements Serializable {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute mailSubject.
	 */
	private String mailSubject;
	
	/**
	 * Attribute message.
	 */
	private String message;
	
	/**
	 * Attribute createdDate.
	 */
	private Timestamp createdDate;
	
	/**
	 * Attribute processedDate.
	 */
	private Timestamp processedDate;
	
	/**
	 * Attribute processingDate.
	 */
	private Date processingDate;
	
	/**
	 * Attribute mailStatus.
	 */
	private Long mailStatus;
	
	/**
	 * Attribute userInfo
	 */
	 private UserInfo userInfo;	

	/**
	 * Attribute application
	 */
	 private Application application;	

	/**
	 * List of MailAddress
	 */
	private List<MailAddress> mailAddressList = null;

	/**
	 * List of MailAttachment
	 */
	private List<MailAttachment> mailAttachmentList = null;

	
	/**
	 * @return id
	 */
	@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "mailIdGen")
	@TableGenerator(name = "mailIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "MAIL_MESSAGE", valueColumnName = "ID_VALUE")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return mailSubject
	 */
	@Basic
	@Column(name = "MAIL_SUBJECT", length = 250)
		public String getMailSubject() {
		return mailSubject;
	}

	/**
	 * @param mailSubject new value for mailSubject 
	 */
	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}
	
	/**
	 * @return message
	 */
	@Basic
	@Column(name = "MESSAGE", length = 2500)
		public String getMessage() {
		return message;
	}

	/**
	 * @param message new value for message 
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
	/**
	 * @return createdDate
	 */
	@Basic
	@Column(name = "CREATED_DATE")
		public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate new value for createdDate 
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	
	/**
	 * @return processedDate
	 */
	@Basic
	@Column(name = "PROCESSED_DATE")
		public Timestamp getProcessedDate() {
		return processedDate;
	}

	/**
	 * @param processedDate new value for processedDate 
	 */
	public void setProcessedDate(Timestamp processedDate) {
		this.processedDate = processedDate;
	}
	
	/**
	 * @return mailStatus
	 */
	@Basic
	@Column(name = "MAIL_STATUS")
		public Long getMailStatus() {
		return mailStatus;
	}

	/**
	 * @param mailStatus new value for mailStatus 
	 */
	public void setMailStatus(Long mailStatus) {
		this.mailStatus = mailStatus;
	}
	
	/**
	 * get userInfo
	 */
	@ManyToOne
	@JoinColumn(name = "USER_ID")
	public UserInfo getUserInfo() {
		return this.userInfo;
	}
	
	/**
	 * set userInfo
	 */
	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	/**
	 * get application
	 */
	@ManyToOne
	@JoinColumn(name = "APPLICATION_NAME")
	public Application getApplication() {
		return this.application;
	}
	
	/**
	 * set application
	 */
	public void setApplication(Application application) {
		this.application = application;
	}

	/**
	 * @return processingDate
	 */
	@Basic
	@Temporal(TemporalType.DATE)
	@Column(name = "PROCESSING_DATE")
	public Date getProcessingDate() {
		return processingDate;
	}

	/**
	 * set processingDate
	 */
	public void setProcessingDate(Date processingDate) {
		this.processingDate = processingDate;
	}

	/**
	 * Get the list of MailAddress
	 */
	@OneToMany(mappedBy="mailMessage", cascade=CascadeType.ALL)
	 public List<MailAddress> getMailAddressList() {
	 	return this.mailAddressList;
	 }
	 
	/**
	 * Set the list of MailAddress
	 */
	 public void setMailAddressList(List<MailAddress> mailAddressList) {
	 	this.mailAddressList = mailAddressList;
	 }
	/**
	 * , fetch=FetchType.LAZY, cascade=CascadeType.ALL
	 * Get the list of MailAttachment
	 */
	 @OneToMany(mappedBy="mailMessage" , cascade=CascadeType.ALL)
	 public List<MailAttachment> getMailAttachmentList() {
	 	return this.mailAttachmentList;
	 }
	 
	/**
	 * Set the list of MailAttachment
	 */
	 public void setMailAttachmentList(List<MailAttachment> mailAttachmentList) {
	 	this.mailAttachmentList = mailAttachmentList;
	 }

}