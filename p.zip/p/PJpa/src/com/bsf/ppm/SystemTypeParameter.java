package com.bsf.ppm;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * <p>Pojo mapping TABLE IPPUSER.SYSTEM_TYPE_PARAMETER</p>
 * @author Kaza
 * 
 */
@Entity
@NamedQuery(name = "SystemTypeParameter.findAll", 
    query = "select o from SystemTypeParameter o")
@Table(name = "SYSTEM_TYPE_PARAMETER")
public class SystemTypeParameter implements Serializable {
    private Long id;
    private String paramName;
    private List<SystemConfiguration> systemConfigurationList;
    private SystemType systemType;

    public SystemTypeParameter() {
    }

    @Id
    @Column(nullable = false)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Column(name="PARAM_NAME")
    public String getParamName() {
        return paramName;
    }

    public void setParamName(String paramName) {
        this.paramName = paramName;
    }


    @OneToMany(mappedBy = "systemTypeParameter")
    public List<SystemConfiguration> getSystemConfigurationList() {
        return systemConfigurationList;
    }

    public void setSystemConfigurationList(List<SystemConfiguration> systemConfigurationList) {
        this.systemConfigurationList = systemConfigurationList;
    }

    public SystemConfiguration addSystemConfiguration(SystemConfiguration systemConfiguration) {
        getSystemConfigurationList().add(systemConfiguration);
        systemConfiguration.setSystemTypeParameter(this);
        return systemConfiguration;
    }

    public SystemConfiguration removeSystemConfiguration(SystemConfiguration systemConfiguration) {
        getSystemConfigurationList().remove(systemConfiguration);
        systemConfiguration.setSystemTypeParameter(null);
        return systemConfiguration;
    }

    @ManyToOne
    @JoinColumn(name = "SYSTEM_TYPE_ID", referencedColumnName = "ID")
    public SystemType getSystemType() {
        return systemType;
    }

    public void setSystemType(SystemType systemType) {
        this.systemType = systemType;
    }
}
