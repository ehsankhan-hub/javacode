package com.bsf.ppm;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.bsf.ipp.dao.SelectableAuditableCacheableEntity;
import com.bsf.ppm.util.StringUtils;

@Entity
/*@NamedQueries({
	@NamedQuery(name = "Ppm_DebitBlockStaging.selectA_AccountsfromCamm", query = "Select PpmDebitBlockStaging  "
		+ " where acctStatusCamm=:acctStatusCammDb or acctStatusCamm=:acctStatusCammXb  and  statuRsnCodeCamm=:statuRsnCodeCamm")
})*/

@Table(name = "PPM_DEBIT_BLOCK_STAGING")
@SuppressWarnings("serial")
public class PpmDebitBlockStaging  extends SelectableAuditableCacheableEntity {
    
	private String accNumber;
	
	private String custCode;
	
	private String creditAcctNo;
	
	private String acctCurCode;
	
	private String status;
	
	private String ctznAcctStatus;
	
	private String acctStatusCamm;
	
	private String statuRsnCodeCamm;
	
	private String benAcct;
	
	private Date createdDate;
	
	private String createdBy;
	
	private Date updatedDate;
	
	private String updatedBy;
	
	private String deletedBy;
	
	private Date deletedDate;
	
		
	
	/*@Column(name = "ACT_NO")
	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}
    */
	@Id 
	@Basic
	@Column(name = "CUST_CODE")
	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	/*@Column(name = "CREDIT_ACCT_NO")
	public String getCreditAcctNo() {
		return creditAcctNo;
	}

	public void setCreditAcctNo(String creditAcctNo) {
		this.creditAcctNo = creditAcctNo;
	}

	@Column(name="ACT_CUR_CODE")	
	public String getAcctCurCode() {
		return acctCurCode;
	}

	public void setAcctCurCode(String acctCurCode) {
		this.acctCurCode = acctCurCode;
	}*/
	@Column(name="STATUS")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	/*@Column(name="CTZN_ACCT_STATUS")
	public String getCtznAcctStatus() {
		return ctznAcctStatus;
	}

	public void setCtznAcctStatus(String ctznAcctStatus) {
		this.ctznAcctStatus = ctznAcctStatus;
	}

	@Column(name="ACCT_STATUS_CAMM")
	public String getAcctStatusCamm() {
		return acctStatusCamm;
	}

	public void setAcctStatusCamm(String acctStatusCamm) {
		this.acctStatusCamm = acctStatusCamm;
	}
	@Column(name="STATUS_RSN_CODE_CAMM")
	public String getStatuRsnCodeCamm() {
		return statuRsnCodeCamm;
	}

	public void setStatuRsnCodeCamm(String statuRsnCodeCamm) {
		this.statuRsnCodeCamm = statuRsnCodeCamm;
	}
	
	@Column(name="BEN_ACT")	
	public String getBenAcct() {
		return benAcct;
	}

	public void setBenAcct(String benAcct) {
		this.benAcct = benAcct;
	}*/

	@Column(name="CREATED_DATE")
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@Column(name="CREATED_BY")
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	@Column(name="UPDATED_DATE")
	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	@Column(name="UPDATED_BY")
	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	@Column(name="DELETED_BY")
	public String getDeletedBy() {
		return deletedBy;
	}

	public void setDeletedBy(String deletedBy) {
		this.deletedBy = deletedBy;
	}
	
	
	@Column(name="DELETED_DATE")
	public Date getDeletedDate() {
		return deletedDate;
	}

	

	public void setDeletedDate(Date deletedDate) {
		this.deletedDate = deletedDate;
	}
	
	
	

	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getCustCode());
	}
	@Override
	@Transient
	public String getKey() {
		// TODO Auto-generated method stub
		return getCustCode()+"";
	}
	
	
	
	
	
	
	

}
