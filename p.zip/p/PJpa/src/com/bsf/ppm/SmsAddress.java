package com.bsf.ppm;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * <p>Pojo mapping TABLE IPPUSER.SMS_ADDRESS</p>
 * @author Kaza
 * 
 */
@Entity
@Table(name = "SMS_ADDRESS")
@SuppressWarnings("serial")
public class SmsAddress implements Serializable {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute smsAddress.
	 */
	private String smsAddress;
	
	/**
	 * Attribute smsMessage
	 */
	 private SmsMessage smsMessage;	

	
	/**
	 * @return id
	 */
	@Basic
	@Id
	@Column(name = "ID")
		public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return smsAddress
	 */
	@Basic
	@Column(name = "SMS_ADDRESS", length = 100)
		public String getSmsAddress() {
		return smsAddress;
	}

	/**
	 * @param smsAddress new value for smsAddress 
	 */
	public void setSmsAddress(String smsAddress) {
		this.smsAddress = smsAddress;
	}
	
	/**
	 * get smsMessage
	 */
	@ManyToOne
	@JoinColumn(name = "SMS_ID")
	public SmsMessage getSmsMessage() {
		return this.smsMessage;
	}
	
	/**
	 * set smsMessage
	 */
	public void setSmsMessage(SmsMessage smsMessage) {
		this.smsMessage = smsMessage;
	}



}