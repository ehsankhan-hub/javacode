package com.bsf.ppm;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import com.bsf.ipp.dao.SelectableAuditableEntity;

/**
 * <p>Pojo mapping TABLE IPPUSER.SAUDI_HOLIDAY</p>
 *
 * <p>Generated at Sat Jul 18 09:59:34 AST 2009</p>
 * @author Salto-db Generator v1.0.16 / EJB3
 * 
 */
@Entity
@NamedQueries({
	@NamedQuery(name = "SaudiHoliday.searchByDateAndType", query = "select obj from SaudiHoliday obj where" +
			" to_char(obj.holidayDate, 'DDMMYYYY') = to_char(:holidayDate,'DDMMYYYY')  and obj.holidayType=:holidayType  and obj.status=:status ")
})
@Table(name = "SAUDI_HOLIDAY")
@SuppressWarnings("serial")
public class SaudiHoliday extends SelectableAuditableEntity {

	/**
	 * Attribute id.
	 */
	private Long id;

	/**
	 * Attribute source.
	 */
	private String source;

	/**
	 * Attribute holidayDate.
	 */
	private Date holidayDate;

	/**
	 * Attribute holidayType.
	 */
	private String holidayType;

	/**
	 * Attribute holidayDescription.
	 */
	private String holidayDescription;

	/**
	 * Attribute createdBy
	 */
	private String createdBy;	

	/**
	 * Attribute createdDate.
	 */
	private Timestamp createdDate;

	/**
	 * Attribute modifiedBy
	 */
	private String modifiedBy;	

	/**
	 * Attribute modifiedDate.
	 */
	private Timestamp modifiedDate;

	/**
	 * Attribute status.
	 */
	private Long status;


	/**
	 * @return id
	 */
	@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "saudiHolidyIdGen")
	@TableGenerator(name = "saudiHolidyIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "SAUDI_HOLIDAY", valueColumnName = "ID_VALUE")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return source
	 */
	@Basic
	@Column(name = "SOURCE", length = 3)
	public String getSource() {
		return source;
	}

	/**
	 * @param source new value for source 
	 */
	public void setSource(String source) {
		this.source = source;
	}

	/**
	 * @return holidayDate
	 */
	@Basic
	@Column(name = "HOLIDAY_DATE")
	public Date getHolidayDate() {
		return holidayDate;
	}

	/**
	 * @param holidayDate new value for holidayDate 
	 */
	public void setHolidayDate(Date holidayDate) {
		this.holidayDate = holidayDate;
	}

	/**
	 * @return holidayType
	 */
	@Basic
	@Column(name = "HOLIDAY_TYPE", length = 2)
	public String getHolidayType() {
		return holidayType;
	}

	/**
	 * @param holidayType new value for holidayType 
	 */
	public void setHolidayType(String holidayType) {
		this.holidayType = holidayType;
	}

	/**
	 * @return holidayDescription
	 */
	@Basic
	@Column(name = "HOLIDAY_DESCRIPTION", length = 50)
	public String getHolidayDescription() {
		return holidayDescription;
	}

	/**
	 * @param holidayDescription new value for holidayDescription 
	 */
	public void setHolidayDescription(String holidayDescription) {
		this.holidayDescription = holidayDescription;
	}

	/**
	 * get createdBy
	 */
	@Basic
	@Column(name = "CREATED_BY")
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * set createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return createdDate
	 */
	@Basic
	@Column(name = "CREATED_DATE")
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate new value for createdDate 
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * get modifiedBy
	 */
	@Basic
	@Column(name = "MODIFIED_BY")
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * set modifiedBy
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return modifiedDate
	 */
	@Basic
	@Column(name = "MODIFIED_DATE")
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate new value for modifiedDate 
	 */
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return status
	 */
	@Basic
	@Column(name = "STATUS")
	public Long getStatus() {
		return status;
	}

	/**
	 * @param status new value for status 
	 */
	public void setStatus(Long status) {
		this.status = status;
	}

	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getId());
	}	
}