package com.bsf.ppm;

import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.bsf.ipp.dao.SelectableAuditableEntity;

/**
 * <p>
 * Pojo mapping TABLE IPPUSER.BRANCH_CODE
 * </p>
 * @author Kaza
 * 
 */
@Entity
@Table(name = "BRANCH_CODE" )
@NamedQueries({
	@NamedQuery(name = "BranchCode.findByBranchCode", 
			    query = "select obj from BranchCode obj where obj.branchCode=:branchCode ")	
})
@SuppressWarnings("serial")
public class BranchCode extends SelectableAuditableEntity {

	/**
	 * Attribute id.
	 */
	//private Long id;

	/**
	 * Attribute branchCode.
	 */
	private String branchCode;

	/**
	 * Attribute description.
	 */
	private String description;

	/**
	 * Attribute createdDate.
	 */
	private Timestamp createdDate;

	/**
	 * Attribute modifiedDate.
	 */
	private Timestamp modifiedDate;

	/**
	 * Attribute createdBy
	 */
	private String createdBy;
	/**
	 * Attribute modifiedBy
	 */
	private String modifiedBy;
	/**
	 * Attribute status.
	 */
	private Long status;
	
	/**
	 * Attribute region.
	 */
	private String region;
	

	/*@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "branchCodeIdGen")
	@TableGenerator(name = "branchCodeIdGen", table = "idgen", allocationSize = 1, pkColumnName = "table_name", pkColumnValue = "BRANCH_CODE", valueColumnName = "id_value")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}*/

	/**
	 * @param id
	 *            new value for id
	 */
	/*public void setId(Long id) {
		this.id = id;
	}*/

	/**
	 * @return branchCode
	 */
	@Id
	@Basic
	@Column(name = "BRANCH_CODE", length = 3)
	public String getBranchCode() {
		return branchCode;
	}

	/**
	 * @param branchCode
	 *            new value for branchCode
	 */
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	/**
	 * @return description
	 */
	@Basic
	@Column(name = "DESCRIPTION", length = 30)
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            new value for description
	 */
	public void setDescription(String description) {
		this.description = description;
	}


	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getBranchCode());
	}

	/**
	 * @return createdDate
	 */
	@Basic
	@Column(name = "CREATED_DATE")
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate
	 *            new value for createdDate
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return modifiedDate
	 */
	@Basic
	@Column(name = "MODIFIED_DATE")
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate
	 *            new value for modifiedDate
	 */
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}	

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * get modifiedBy
	 */
	@Basic
	@Column(name = "MODIFIED_BY")
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * get createdBy
	 */
	@Basic
	@Column(name = "CREATED_BY")
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * set createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return status
	 */
	@Basic
	@Column(name = "STATUS")
	public Long getStatus() {
		return status;
	}

	/**
	 * @param status new value for status 
	 */
	public void setStatus(Long status) {
		this.status = status;
	}


	/**
	 * @return the region
	 */
	@Basic
	@Column(name = "REGION", length = 1)
	public String getRegion() {
		return region;
	}

	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	@Override
	public String toString(){
		return "[ branchCode="+getBranchCode()+"]";
	}

	

}