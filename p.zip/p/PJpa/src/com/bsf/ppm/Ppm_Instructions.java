package com.bsf.ppm;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.bsf.ipp.dao.SelectableAuditableCacheableEntity;
import com.bsf.ppm.util.StringUtils;

@Entity
@NamedQueries({
	@NamedQuery(name = "Ppm_Instructions.updatePriorityByGroupCode", query = "update Ppm_Instructions ins "
		+ " set ins.instProrty=:instProrty where ins.instgroupcode=:instgroupcode and ins.status=:status")
})

@Table(name = "PPM_INSTRUCTIONS")
@SuppressWarnings("serial")
public class Ppm_Instructions  extends SelectableAuditableCacheableEntity {
    
	private String accNumber;
	
	private String custCode;
	
	private String instActionType;
	
	private String accountstatus;
	
	private String profitCenter;
		
	private String instReference;
	
	private int instProrty;
	
	private String instgroupcode="";
	
	private String clandertype;
	
	private String acctcurcode="";
		
	private String status;
	
	private String createdBy;
	
	private String instBranch;
	
	private Date startDateG;
	
	private Date endDateG;
	
	private String startDateH;
	
	private String endDateH;
	
	private BigDecimal monthlyAmoun;
	
	private BigDecimal totalAmount;
	
	private int dayofPayment;
	
    private String instCalendar;
	/**
	 * Attribute createdDate.
	 */
	private Timestamp createdDate;
	
	private String frequency;
	
	private InstructionDetails instdetails;
	
	private List<StatusHistory> statusHistory;
	
	private String initComment;
	
	private String validatorComment; 
	
	private Timestamp validatedDate;
	
	private String validatdBy;
	
	private Timestamp updatedDate;
	
	private String updatedBy;
	
	private String exeType;
	
	private int noofBen;
	
	private String maxDayRange;
	
	private String eventTriggerOn;
	
	private String trgrNextCycleDay;
	
	private String balCheck;
	
	private String balSweep;
	
	private Integer noOfInst=0;
	
	private Integer noOfSucsInst=0;
	
	private Double paidAmount;
	
	private Integer noOfPendInst;
	
	private Double instPercent;
	
	@Id 
	@Basic
	@Column(name = "INST_REFERENCE")
	public String getInstReference() {
		return instReference;
	}

	public void setInstReference(String instReference) {
		this.instReference = instReference;
	}
		
	@Column(name = "ACT_NO")
	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}

	@Column(name = "CUST_CODE")	
	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	@Column(name="INST_ACTION_TYPE")
	public String getInstActionType() {
		return instActionType;
	}

	
	public void setInstActionType(String instActionType) {
		this.instActionType = instActionType;
	}

	@Column(name = "STATUS")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
   	
	
	@Transient
	public String getProfitCenter() {
		return profitCenter;
	}

	public void setProfitCenter(String profitCenter) {
		this.profitCenter = profitCenter;
	}
		
	
	@Column(name = "INST_GROUP_CODE")
	public String getInstgroupcode() {
		return instgroupcode;
	}
    
	public void setInstgroupcode(String instgroupcode) {
		this.instgroupcode = instgroupcode;
	}
	
   	@Column(name="INST_CALENDAR")
	public String getClandertype() {
		return clandertype;
	}

	public void setClandertype(String clandertype) {
		this.clandertype = clandertype;
	}

	@Column(name = "ACT_CUR_CODE")
	public String getAcctcurcode() {
		return acctcurcode;
	}

	public void setAcctcurcode(String acctcurcode) {
		this.acctcurcode = acctcurcode;
	}
    @Column(name="FREQUENCY")
	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
    
	//@OneToOne(cascade = CascadeType.ALL )
	//@JoinColumn(name = "INST_REFERENCE")
	@OneToOne(fetch = FetchType.EAGER,mappedBy = "ppmInstructions", cascade = CascadeType.ALL)
	public InstructionDetails getInstdetails() {
		return instdetails;
	}
  
	public void setInstdetails(InstructionDetails instdetails) {
		this.instdetails = instdetails;
	}
    @Column(name="CREATED_BY")
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
    
	/**
	 * @return createdDate
	 */
	@Basic
	@Column(name = "CREATED_DATE")
		public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate new value for createdDate 
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
    @Column(name="INST_PRIORITY")
	public int getInstProrty() {
		return instProrty;
	}

	public void setInstProrty(int instProrty) {
		this.instProrty = instProrty;
	}
    @Column(name="INIT_BRANCH")
	public String getInstBranch() {
		return instBranch;
	}

	public void setInstBranch(String instBranch) {
		this.instBranch = instBranch;
	}
    @Column(name="START_DATE_G")
    public Date getStartDateG() {
		return startDateG;
	}
	public void setStartDateG(Date startDateG) {
		this.startDateG = startDateG;
	}
    
	@Column(name="END_DATE_G")
	 public Date getEndDateG() {
		return endDateG;
	}

	public void setEndDateG(Date endDateG) {
		this.endDateG = endDateG;
	}
	 
    
	 @Column(name="START_DATE_H")
     public String getStartDateH() {
		return startDateH;
	}
   	public void setStartDateH(String startDateH) {
		this.startDateH = startDateH;
	}

    @Column(name="END_DATE_H")
	public String getEndDateH() {
		return endDateH;
	}

	public void setEndDateH(String endDateH) {
		this.endDateH = endDateH;
	}
    
	@Column(name="INST_AMOUNT")
	public BigDecimal getMonthlyAmoun() {
		return monthlyAmoun;
	}

	public void setMonthlyAmoun(BigDecimal monthlyAmoun) {
		this.monthlyAmoun = monthlyAmoun;
	}
    @Column(name="TOTAL_AMOUNT")
	public BigDecimal getTotalAmount() {
    	return totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}
    
	@Column(name="DAY_OF_PAYMENT")
	public int getDayofPayment() {
		return dayofPayment;
	}

	public void setDayofPayment(int dayofPayment) {
		this.dayofPayment = dayofPayment;
	}
	
	//@Fetch(FetchMode.SELECT)
	@SuppressWarnings("unchecked")
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "INST_REFERENCE")
	//@OneToMany(fetch = FetchType.EAGER,mappedBy = "ppmInstructions", cascade = CascadeType.ALL)
	public List<StatusHistory> getStatusHistory() {
		return (List<StatusHistory>) statusHistory;
	}

	public void setStatusHistory(List<StatusHistory>statusHistory) {
		this.statusHistory = (List<StatusHistory>) statusHistory;
	}	
	@Column(name="INITIATOR_COMMENT")
	public String getInitComment() {
		return initComment;
	}

	public void setInitComment(String initComment) {
		this.initComment = initComment;
	}

	@Column(name="VALIDATOR_COMMENT")	
	public String getValidatorComment() {
		return validatorComment;
	}

	public void setValidatorComment(String validatorComment) {
		this.validatorComment = validatorComment;
	}

	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getInstReference());
	}
	@Override
	@Transient
	public String getKey() {
		// TODO Auto-generated method stub
		return getInstReference()+"";
	}
    @Column(name="VALIDATED_DATE")
	public Timestamp getValidatedDate() {
		return validatedDate;
	}

	public void setValidatedDate(Timestamp validatedDate) {
		this.validatedDate = validatedDate;
	}
    @Column(name="VALIDATED_BY")
	public String getValidatdBy() {
		return validatdBy;
	}

	public void setValidatdBy(String validatdBy) {
		this.validatdBy = validatdBy;
	}
    @Column(name="UPDATED_DATE")
	public Timestamp getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}
    @Column(name="UPDATED_BY")
	public String getUpdatedBy() {
		return updatedBy;
	}
    
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
    @Column(name="INST_EXE_TYPE")
	public String getExeType() {
		return exeType;
	}

	public void setExeType(String exeType) {
		this.exeType = exeType;
	}
    @Column(name="NO_OF_BEN")
	public int getNoofBen() {
		return noofBen;
	}

	public void setNoofBen(int noofBen) {
		this.noofBen = noofBen;
	}
    @Column(name="MAX_DAYS_RANGE")
	public String getMaxDayRange() {
		return maxDayRange;
	}

	public void setMaxDayRange(String maxDayRange) {
		this.maxDayRange = maxDayRange;
	}
    @Column(name="EVNT_TRIGGER_ON")
	public String getEventTriggerOn() {
		return eventTriggerOn;
	}

	public void setEventTriggerOn(String eventTriggerOn) {
		this.eventTriggerOn = eventTriggerOn;
	}
    @Column(name="TRGR_NXT_CYCLE_DAY")
	public String getTrgrNextCycleDay() {
		return trgrNextCycleDay;
	}

	public void setTrgrNextCycleDay(String trgrNextCycleDay) {
		this.trgrNextCycleDay = trgrNextCycleDay;
	}
    @Column(name="BAL_CHECK")
	public String getBalCheck() {
		return balCheck;
	}

	public void setBalCheck(String balCheck) {
		this.balCheck = balCheck;
	}
    @Column(name="BAL_SWEEP")
	public String getBalSweep() {
		return balSweep;
	}

	public void setBalSweep(String balSweep) {
		this.balSweep = balSweep;
	}
    @Column(name="NO_OF_INST")
	public Integer getNoOfInst() {
    	if(noOfInst==null){
    	noOfInst=0;	 
    	}
		return noOfInst;
	}
   
	public void setNoOfInst(Integer noOfInst) {
		this.noOfInst = noOfInst;
	}
	 @Column(name="NO_OF_SUCS_INST")
	public Integer getNoOfSucsInst() {
		if(noOfSucsInst==null){
		noOfSucsInst=0;	 
		 }
		return noOfSucsInst;
	}

	public void setNoOfSucsInst(Integer noOfSucsInst) {
		this.noOfSucsInst = noOfSucsInst;
	}
	@Column(name="PAID_AMOUNT")
	public Double getPaidAmount() {
	return paidAmount;
	
	}

	public void setPaidAmount(Double paidAmount) {
		this.paidAmount = paidAmount;
	}
    
	
	@Transient
	public Integer getNoOfPendInst() {
		System.out.println("noOfSucsInst=="+noOfSucsInst);
		System.out.println("noOfInst---"+noOfInst);
		if(noOfSucsInst!=null&&!"".equals(noOfSucsInst)){
		noOfPendInst=(noOfInst-noOfSucsInst);
		}
		return noOfPendInst;
	}

	public void setNoOfPendInst(Integer noOfPendInst) {
		this.noOfPendInst = noOfPendInst;
	}
    
	@Column(name="INST_PERCENT")
	public Double getInstPercent() {
		return instPercent;
	}

	public void setInstPercent(Double instPercent) {
		this.instPercent = instPercent;
	}
	
	
   
	
	
	
	
	

}
