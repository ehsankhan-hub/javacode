package com.bsf.ppm;

import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.bsf.ipp.dao.SelectableAuditableEntity;


/**
 * <p>Pojo mapping TABLE IPPUSER.COUNTRY_CODE</p>
 * @author Kaza
 * 
 */
@Entity
@Table(name = "COUNTRY_CODE")
@SuppressWarnings("serial")
public class CountryCode extends SelectableAuditableEntity {

	/**
	 * Attribute id.
	 */
	//private Long id;
	
	/**
	 * Attribute countryCode.
	 */
	private String countryCode;
	
	/**
	 * Attribute description.
	 */
	private String description;
	
	/**
	 * Attribute bsfMapping.
	 */
	private String bsfMapping;
	


	/**
	 * Attribute createdDate.
	 */
	private Timestamp createdDate;
	
	/**
	 * Attribute userInfo
	 */
	 private String createdBy;	
         /**
	 * Attribute modifiedBy
	 */
	 private String modifiedBy;	

	/**
	 * Attribute modifiedDate.
	 */
	private Timestamp modifiedDate;
	
	/**
	 * Attribute status.
	 */
	private Long status;
	
	private String ibanRequired;
	
	private String ibanLength;
	
	/**
	 * @return id
	 */
	/*@Basic
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "countryCodeIdGen")
	@TableGenerator(name = "countryCodeIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "COUNTRY_CODE", valueColumnName = "ID_VALUE")
	@Column(name = "ID")
		public Long getId() {
		return id;
	}*/

	/**
	 * @param id new value for id 
	 */
	/*public void setId(Long id) {
		this.id = id;
	}*/
	
	/**
	 * @return countryCode
	 */
	@Id
	@Basic
	@Column(name = "COUNTRY_CODE", length = 2)
		public String getCountryCode() {
		return countryCode;
	}

	/**
	 * @param countryCode new value for countryCode 
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	
	/**
	 * @return description
	 */
	@Basic
	@Column(name = "DESCRIPTION", length = 30)
		public String getDescription() {
		return description;
	}

	/**
	 * @param description new value for description 
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * @return bsfMapping
	 */
	@Basic
	@Column(name = "BSF_MAPPING", length = 10)
		public String getBsfMapping() {
		return bsfMapping;
	}

	/**
	 * @param bsfMapping new value for bsfMapping 
	 */
	public void setBsfMapping(String bsfMapping) {
		this.bsfMapping = bsfMapping;
	}
	

	


	/**
	 * @return createdDate
	 */
	@Basic
	@Column(name = "CREATED_DATE")
		public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate new value for createdDate 
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	

	/**
	 * @return modifiedDate
	 */
	@Basic
	@Column(name = "MODIFIED_DATE")
		public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate new value for modifiedDate 
	 */
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	
	/**
	 * get userInfo
	 */
	
	@Basic
	@Column(name = "MODIFIED_BY")
	public String getModifiedBy() {
		return this.modifiedBy;
	}
	
	/**
	 * set userInfo
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	/**
	 * get userInfo
	 */
	@Basic
	@Column(name = "CREATED_BY")
	public String getCreatedBy() {
		return this.createdBy;
	}
	
	/**
	 * set userInfo
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getCountryCode());
	}
	
	/**
	 * @return status
	 */
	@Basic
	@Column(name = "STATUS")
		public Long getStatus() {
		return status;
	}

	/**
	 * @param status new value for status 
	 */
	public void setStatus(Long status) {
		this.status = status;
	}
	public String toString(){
		return "[ countryCode="+getCountryCode()+"]";
	}

	/**
	 * @param ibanRequired the ibanRequired to set
	 */
	public void setIbanRequired(String ibanRequired) {
		this.ibanRequired = ibanRequired;
	}

	/**
	 * @return the ibanRequired
	 */
	@Basic
	@Column(name = "IBAN_RQD")
	public String getIbanRequired() {
		return ibanRequired;
	}

	/**
	 * @param ibanLength the ibanLength to set
	 */
	public void setIbanLength(String ibanLength) {
		this.ibanLength = ibanLength;
	}

	/**
	 * @return the ibanLength
	 */
	@Basic
	@Column(name = "IBAN_LEN")
	public String getIbanLength() {
		return ibanLength;
	}
}