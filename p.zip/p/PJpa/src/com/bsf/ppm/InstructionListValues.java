package com.bsf.ppm;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Date;

import javax.persistence.Transient;

public class InstructionListValues {
	private String instReference;
	private Long instDtlId;
	private String status;
	private Double totalAmount=0.00;
	private String frequency;
	private String samaReference;
	private String accNumber;
	private String custName;
	private String iDType;
	private String custIdNumber;
	private String acctType;
	private String custProfitCenter;
	private BigDecimal instAmount;
	private String startDateH;
	private String endDateH;
	private Date startDateG;
	private Date endDateG;
	private String bakName;
	private String benAcc;
	private String benName;
	private String benAddress;
	private String benBankAddrs1;
	private String payDtls;
	
	private String filePath;
	private Long modifyRef;
	private String isApplied;
	private String relatedRefOld;
	private String relatedRefNew;
	private String docDateOld;
	private String docDateNew;
	private String docDateRecOld;
	private String docDateRecNew;
	private String relatedDocOld;
	private String relatedDocNew;
	private String fieldName;
	private Integer noOfSucsInst=0;
	private Double paidAmount=0.00;
	private Integer noOfPendInst;
	private Double remainingTotalAmt=0.00;
	private String tnsType;
	private Integer noOfInst=0;
	private String dayOfPayment;
	private String calenderType;
	private String relatedDoc;
	private Date createdDate;
	private String initComment;
	private String validatorComnt;
	private String branchCode;
	//Modification related fields 
	
	private Date modifiedDate;
	private Date modApprovedDate;
  
	//*Execution Details for inquiry
	private  String instExeType;
	private  String maxDaysRange;
	private  String evntTriggerOn;
	private  String trgrNxtCycleDay;
	private  Date instLastSucDate;
	private  Integer numOfFailInst=0;
	
	public String getInstReference() {
		return instReference;
	}
	public void setInstReference(String instReference) {
		this.instReference = instReference;
	}
	public Long getInstDtlId() {
		return instDtlId;
	}
	public void setInstDtlId(Long instDtlId) {
		this.instDtlId = instDtlId;
	}
	public String getStatus() {
		if(status.equalsIgnoreCase("ACT")){
			status="Active";
		}
		else if(status.equalsIgnoreCase("RJT")){
			status="Rejected";
		}
		else if(status.equalsIgnoreCase("NEW")){
			status="Sent for validation";
		}
		else if(status.equalsIgnoreCase("SUI")){
			status="Initiated for Suspend";
		}
		else if(status.equalsIgnoreCase("SUS")){
			status="Suspended";
		}
		else if(status.equalsIgnoreCase("CLS")){
			status="Closed";
		}
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getFrequency() {
		if(frequency!=null){
		if(frequency.equalsIgnoreCase("M")){
		frequency="Monthly"	;
		}
		else if(frequency.equalsIgnoreCase("H"))
		{
			frequency="Half Yearly";
		}
		else if(frequency.equalsIgnoreCase("Y")){
			frequency="Yearly";
		}
		else if(frequency.equalsIgnoreCase("Q")){
			frequency="Quarterly";
		}
		else if(frequency.equalsIgnoreCase("D")){
			frequency="15 Days";
		}
		}
	   return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getSamaReference() {
		return samaReference;
	}
	public void setSamaReference(String samaReference) {
		this.samaReference = samaReference;
	}
	public InstructionListValues(){
		
	}
	public String getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
		
	public String getiDType() {
		return iDType;
	}
	public void setiDType(String iDType) {
		this.iDType = iDType;
	}
	public String getCustIdNumber() {
		return custIdNumber;
	}
	public void setCustIdNumber(String custIdNumber) {
		this.custIdNumber = custIdNumber;
	}
	public String getAcctType() {
		if(acctType!=null){
		    if(acctType.equalsIgnoreCase("PVI")){
		    acctType="Individual";	
		    }
		    else if(acctType.equalsIgnoreCase("BUS")){
		    acctType="Corporations"	;
		    }
		        
		    }
		return acctType;
	}
	public void setAcctType(String acctType) {
		this.acctType = acctType;
	}
	public String getCustProfitCenter() {
		return custProfitCenter;
	}
	public void setCustProfitCenter(String custProfitCenter) {
		this.custProfitCenter = custProfitCenter;
	}
	public BigDecimal getInstAmount() {
		return instAmount;
	}
	public void setInstAmount(BigDecimal instAmount) {
		this.instAmount = instAmount;
	}
	public String getStartDateH() {
		return startDateH;
	}
	public void setStartDateH(String startDateH) {
		this.startDateH = startDateH;
	}
	public String getEndDateH() {
		return endDateH;
	}
	public void setEndDateH(String endDateH) {
		this.endDateH = endDateH;
	}
	public Date getStartDateG() {
		return startDateG;
	}
	public void setStartDateG(Date startDateG) {
		this.startDateG = startDateG;
	}
	public Date getEndDateG() {
		return endDateG;
	}
	public void setEndDateG(Date endDateG) {
		this.endDateG = endDateG;
	}
	public String getBakName() {
		return bakName;
	}
	public void setBakName(String bakName) {
		this.bakName = bakName;
	}
	public String getBenAcc() {
		return benAcc;
	}
	public void setBenAcc(String benAcc) {
		this.benAcc = benAcc;
	}
	public String getBenName() {
		return benName;
	}
	public void setBenName(String benName) {
		this.benName = benName;
	}
	public String getBenAddress() {
		return benAddress;
	}
	public void setBenAddress(String benAddress) {
		this.benAddress = benAddress;
	}
	public String getBenBankAddrs1() {
		return benBankAddrs1;
	}
	public void setBenBankAddrs1(String benBankAddrs1) {
		this.benBankAddrs1 = benBankAddrs1;
	}
	public String getPayDtls() {
		return payDtls;
	}
	public void setPayDtls(String payDtls) {
		this.payDtls = payDtls;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public Long getModifyRef() {
		return modifyRef;
	}
	public void setModifyRef(Long modifyRef) {
		this.modifyRef = modifyRef;
	}
	public String getIsApplied() {
		return isApplied;
	}
	public void setIsApplied(String isApplied) {
		this.isApplied = isApplied;
	}
	public String getRelatedRefOld() {
		return relatedRefOld;
	}
	public void setRelatedRefOld(String relatedRefOld) {
		this.relatedRefOld = relatedRefOld;
	}
	public String getRelatedRefNew() {
		return relatedRefNew;
	}
	public void setRelatedRefNew(String relatedRefNew) {
		this.relatedRefNew = relatedRefNew;
	}
	public String getDocDateOld() {
		return docDateOld;
	}
	public void setDocDateOld(String docDateOld) {
		this.docDateOld = docDateOld;
	}
	public String getDocDateNew() {
		return docDateNew;
	}
	public void setDocDateNew(String docDateNew) {
		this.docDateNew = docDateNew;
	}
	public String getDocDateRecOld() {
		return docDateRecOld;
	}
	public void setDocDateRecOld(String docDateRecOld) {
		this.docDateRecOld = docDateRecOld;
	}
	public String getDocDateRecNew() {
		return docDateRecNew;
	}
	public void setDocDateRecNew(String docDateRecNew) {
		this.docDateRecNew = docDateRecNew;
	}
	public String getRelatedDocOld() {
		return relatedDocOld;
	}
	public void setRelatedDocOld(String relatedDocOld) {
		this.relatedDocOld = relatedDocOld;
	}
	public String getRelatedDocNew() {
		return relatedDocNew;
	}
	public void setRelatedDocNew(String relatedDocNew) {
		this.relatedDocNew = relatedDocNew;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public Integer getNoOfSucsInst() {
		if(noOfSucsInst==null){
			noOfSucsInst=0;	
		return noOfSucsInst;
		}
			
		return noOfSucsInst;
	}
	public void setNoOfSucsInst(Integer noOfSucsInst) {
		this.noOfSucsInst = noOfSucsInst;
	}
	/*public Double getPaidAmount() {
		DecimalFormat dft=null;
		Double paidAmountFormated=0.00;
		dft =new DecimalFormat("0.00");
		if((paidAmount==null)||(paidAmount==0.0)){
			
			paidAmountFormated=Double.valueOf(dft.format(paidAmount/1000));
			 System.out.println("paidAmount=="+dft.format(paidAmount));
			 return paidAmountFormated;
	   
		}
		paidAmountFormated=Double.valueOf(dft.format(paidAmount/1000));
		System.out.println("paidAmount OUTSIDE=="+dft.format(paidAmount));
		return paidAmountFormated;
	}*/
	public Double getPaidAmount() {
		return paidAmount;
	}
	
	public void setPaidAmount(Double paidAmount) {
		this.paidAmount = paidAmount;
	}
	
	@Transient
	public Integer getNoOfPendInst() {
		
		if(noOfSucsInst!=null&&!"".equals(noOfSucsInst)){
		noOfPendInst=(noOfInst-noOfSucsInst);
		
		}
		return noOfPendInst;
	}
	
	@Transient
	public Double getRemainingTotalAmt() {
		if((paidAmount!=null)&&(totalAmount!=null)){
		
			
		remainingTotalAmt=totalAmount-paidAmount;
		
		}
		return remainingTotalAmt;
	}
	
	public String getTnsType() {
		return tnsType;
	}
	public void setTnsType(String tnsType) {
		this.tnsType = tnsType;
	}
	public Integer getNoOfInst() {
		if(noOfInst==null){
			noOfInst=0;	
		}
		return noOfInst;
	}
	public void setNoOfInst(Integer noOfInst) {
		this.noOfInst = noOfInst;
	}
	public String getDayOfPayment() {
		return dayOfPayment;
	}
	public void setDayOfPayment(String dayOfPayment) {
		this.dayOfPayment = dayOfPayment;
	}
	public String getCalenderType() {
		return calenderType;
	}
	public void setCalenderType(String calenderType) {
		this.calenderType = calenderType;
	}
	public String getRelatedDoc() {
		return relatedDoc;
	}
	public void setRelatedDoc(String relatedDoc) {
		this.relatedDoc = relatedDoc;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
		
	public String getInitComment() {
		return initComment;
	}
	public void setInitComment(String initComment) {
		this.initComment = initComment;
	}
		
	public String getValidatorComnt() {
		return validatorComnt;
	}
	public void setValidatorComnt(String validatorComnt) {
		this.validatorComnt = validatorComnt;
	}
		
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	// Modification related setter getter
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Date getModApprovedDate() {
		return modApprovedDate;
	}
	public void setModApprovedDate(Date modApprovedDate) {
		this.modApprovedDate = modApprovedDate;
	}
	
	public String getInstExeType() {
		return instExeType;
	}
	
	public void setInstExeType(String instExeType) {
		this.instExeType = instExeType;
	}
	public String getMaxDaysRange() {
		return maxDaysRange;
	}
	public void setMaxDaysRange(String maxDaysRange) {
		this.maxDaysRange = maxDaysRange;
	}
	public String getEvntTriggerOn() {
		return evntTriggerOn;
	}
	public void setEvntTriggerOn(String evntTriggerOn) {
		this.evntTriggerOn = evntTriggerOn;
	}
	public String getTrgrNxtCycleDay() {
		return trgrNxtCycleDay;
	}
	public void setTrgrNxtCycleDay(String trgrNxtCycleDay) {
		this.trgrNxtCycleDay = trgrNxtCycleDay;
	}
	public Date getInstLastSucDate() {
		return instLastSucDate;
	}
	public void setInstLastSucDate(Date instLastSucDate) {
		this.instLastSucDate = instLastSucDate;
	}
	public Integer getNumOfFailInst() {
		if(numOfFailInst==null){
			numOfFailInst=0;
		}
		return numOfFailInst;
	}
	public void setNumOfFailInst(Integer numOfFailInst) {
		this.numOfFailInst = numOfFailInst;
	}
}
