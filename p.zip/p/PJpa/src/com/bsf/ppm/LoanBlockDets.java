package com.bsf.ppm;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlTransient;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.SelectableAuditableCacheableEntity;
import com.bsf.ipp.dao.SelectableAuditableEntity;
import com.bsf.ppm.PpmExeRulesCriteria.PpmExeRulesCriteriaPK;

@Entity
@Table(name = "LOAN_BLOCK_DETS")
@SuppressWarnings("serial")
public class LoanBlockDets extends SelectableAuditableEntity {
/**
* Attribute serialVersionUID for the SerialVersionUID of the class
*/
private static final long serialVersionUID = -4687311450303931234L;
private Date instDate;
private String amount;
private String bankBlckRef;
private Date blockInitDate;
private String createdBy;
private boolean cnfrmButton;

@EmbeddedId
private LoanBlockDetsCompPk loanBlockDetsCompPk=new LoanBlockDetsCompPk();


@Id 
@Basic
public LoanBlockDetsCompPk getLoanBlockDetsCompPk() {
	return loanBlockDetsCompPk;
}
public void setLoanBlockDetsCompPk(LoanBlockDetsCompPk loanBlockDetsCompPk) {
	this.loanBlockDetsCompPk = loanBlockDetsCompPk;
}

@Column(name = "INST_DATE")
public Date getInstDate() {
	return instDate;
}
public void setInstDate(Date instDate) {
	this.instDate = instDate;
}
@Column(name = "AMOUNT")
public String getAmount() {
	return amount;
}
public void setAmount(String amount) {
	this.amount = amount;
}
@Column(name = "BANK_BLCK_REF")
public String getBankBlckRef() {
	return bankBlckRef;
}
public void setBankBlckRef(String bankBlckRef) {
	this.bankBlckRef = bankBlckRef;
}
@Column(name ="BLOCK_INIT_DATE")
public Date getBlockInitDate() {
	return blockInitDate;
}
public void setBlockInitDate(Date blockInitDate) {
	this.blockInitDate = blockInitDate;
}

/**
* @return createdBy
*/
//@ManyToOne(cascade = CascadeType.MERGE)
@Column(name = "CREATED_BY")
public String getCreatedBy() {
return createdBy;
}
/**
* @param createdBy new value for createdBy 
*/
public void setCreatedBy(String createdBy) {
this.createdBy = createdBy;
}

@XmlTransient
@Transient
public boolean getCnfrmButton() {
	return cnfrmButton;
}
public void setCnfrmButton(boolean cnfrmButton) {
	this.cnfrmButton = cnfrmButton;
}


@Override
@XmlTransient
@Transient
public String getPk() {
	return String.valueOf(loanBlockDetsCompPk.getReference());
}
/*@Override
@Transient
public String getKey() {
	// TODO Auto-generated method stub
	return String.valueOf(getReference());
}*/

@SuppressWarnings("serial")
@Embeddable
public static class LoanBlockDetsCompPk implements Serializable {
	/**
	 * Attribute reference.
	 */
	private String reference;
	
	/**
	 * Attribute acctNumber.
	 */
	private String acctNumber;
	
	/**
	 * Attribute createdDate.
	 */
	private Date createdDate;
	
	
	
	@Column(name = "REFERENCE")
	public String getReference() {
		return reference;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
	@Column(name = "ACCT_NO")
	public String getAcctNumber() {
		return acctNumber;
	}
	public void setAcctNumber(String acctNumber) {
		this.acctNumber = acctNumber;
	}
	
	@Column(name = "CREATED_DATE")
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	

   public LoanBlockDetsCompPk(){
		
	}
  
     public LoanBlockDetsCompPk(String reference,String acctNumber,Date createdDate){
	 super();
      this.reference=reference;
      this.acctNumber=acctNumber;
	 this.createdDate=createdDate;
	 
	}
     // Must have a equals method
     @Override
 	 public boolean equals(Object obj) {
	        if (obj == null) return false;
	        if (!this.getClass().equals(obj.getClass())) return false;
	         
	        LoanBlockDetsCompPk obj2 = (LoanBlockDetsCompPk)obj;
	       
	       if (this.reference.equals(obj2.getReference()) &&
	            this.acctNumber.equals(obj2.getAcctNumber()) && this.createdDate.equals(obj2.getCreatedDate())) {
	            return true;
	        }
	        return false;
	    }
     // Must have a hashCode method
     @Override
      public int hashCode() {      
	        int tmp = 0;
	        tmp = (reference + acctNumber+createdDate).hashCode();
	        return tmp;
	    }
	}


}
