package com.bsf.ppm;

import java.io.Serializable;
import java.sql.Blob;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

/**
 * <p>Pojo mapping TABLE IPPUSER.MAIL_ATTACHMENT</p>
 * @author Kaza
 * 
 */
@Entity
@NamedQuery(name = "MailAttachment.findAll", 
	    query = "select o from MailAttachment o")
@Table(name = "MAIL_ATTACHMENT")
@SuppressWarnings("serial")
public class MailAttachment implements Serializable {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute mailData.
	 */
	//private byte[] mailData;
	private Blob mailData;
	
	/**
	 * Attribute fileName.
	 */
	private String fileName;
	
	/**
	 * Attribute mailMessage
	 */
	 private MailMessage mailMessage;
	 
	
	/**
	 * @return id
	 */
	@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "mailAttachmentIdGen")
	@TableGenerator(name = "mailAttachmentIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "MAIL_ATTACHMENT", valueColumnName = "ID_VALUE")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return mailData
	 */
	@Basic
	@Column(name = "MAIL_DATA")
		public Blob getMailData() {
		return mailData;
	}

	/**
	 * @param mailData new value for mailData 
	 */
	public void setMailData(Blob mailData) {
		this.mailData = mailData;
	}
	
	/**
	 * @return the fileName
	 */
	@Basic
	@Column(name = "FILE_NAME")	
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * get mailMessage
	 */
	@ManyToOne
	@JoinColumn(name = "MAIL_ID")
	public MailMessage getMailMessage() {
		return this.mailMessage;
	}
	
	/**
	 * set mailMessage
	 */
	public void setMailMessage(MailMessage mailMessage) {
		this.mailMessage = mailMessage;
	}

}