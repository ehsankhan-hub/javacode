package com.bsf.ppm;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

/**
 * <p>Pojo mapping TABLE IPPUSER.BATCH_JOB_HISTORY</p>
 * @author Kaza
 * 
 */
@Entity
@Table(name = "BATCH_JOB_HISTORY")
@SuppressWarnings("serial")
public class BatchJobHistory implements Serializable {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute jobName.
	 */
	private String jobName;
	
	/**
	 * Attribute handler.
	 */
	private String handler;
	
	/**
	 * Attribute startTime.
	 */
	private Timestamp startTime;
	
	/**
	 * Attribute endTime.
	 */
	private Timestamp endTime;
	
	/**
	 * Attribute successfulProcessedRecords.
	 */
	private Integer successfulProcessedRecords;
	
	/**
	 * Attribute unsuccessfulProcessedRecords.
	 */
	private Integer unsuccessfulProcessedRecords;
	
	
	/**
	 * @return id
	 */
	@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "batchJobHistoryIdGen")
	@TableGenerator(name = "batchJobHistoryIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "BATCH_JOB_HISTORY", valueColumnName = "ID_VALUE")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return jobName
	 */
	@Basic
	@Column(name = "JOB_NAME", length = 50)
		public String getJobName() {
		return jobName;
	}

	/**
	 * @param jobName new value for jobName 
	 */
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	
	/**
	 * @return handler
	 */
	@Basic
	@Column(name = "HANDLER", length = 100)
		public String getHandler() {
		return handler;
	}

	/**
	 * @param handler new value for handler 
	 */
	public void setHandler(String handler) {
		this.handler = handler;
	}
	
	/**
	 * @return startTime
	 */
	@Basic
	@Column(name = "START_TIME")
		public Timestamp getStartTime() {
		return startTime;
	}

	/**
	 * @param startTime new value for startTime 
	 */
	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}
	
	/**
	 * @return endTime
	 */
	@Basic
	@Column(name = "END_TIME")
		public Timestamp getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime new value for endTime 
	 */
	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}
	
	/**
	 * @return successfulProcessedRecords
	 */
	@Basic
	@Column(name = "SUCCESSFUL_PROCESSED_RECORDS")
		public Integer getSuccessfulProcessedRecords() {
		return successfulProcessedRecords;
	}

	/**
	 * @param successfulProcessedRecords new value for successfulProcessedRecords 
	 */
	public void setSuccessfulProcessedRecords(Integer successfulProcessedRecords) {
		this.successfulProcessedRecords = successfulProcessedRecords;
	}
	
	/**
	 * @return unsuccessfulProcessedRecords
	 */
	@Basic
	@Column(name = "UNSUCCESSFUL_PROCESSED_RECORDS")
		public Integer getUnsuccessfulProcessedRecords() {
		return unsuccessfulProcessedRecords;
	}

	/**
	 * @param unsuccessfulProcessedRecords new value for unsucessfulProcessedRecords 
	 */
	public void setUnsuccessfulProcessedRecords(Integer unsuccessfulProcessedRecords) {
		this.unsuccessfulProcessedRecords = unsuccessfulProcessedRecords;
	}
	
	public String toString(){
		return "[ jobName=".concat(getJobName()).concat(",StartTime=").concat(getStartTime().toString()).concat(",EndTime=").concat(getEndTime().toString()).concat("]");
	}


}