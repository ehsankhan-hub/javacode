package com.bsf.ppm;


import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LOAN_INSTALMENTS_DETS")
@SuppressWarnings("serial")
public class LoanInstalmentsDets implements Serializable{
/**
* Attribute serialVersionUID for the SerialVersionUID of the class
*/
private static final long serialVersionUID = -4687311450303931235L;	
private String reference;
private String blockedFlag;
private Date updateDate;
private String updateUser;
private String description;
private String acctNumber;
@Id 
@Basic
@Column(name = "REFERENCE")
public String getReference() {
	return reference;
}
public void setReference(String reference) {
	this.reference = reference;
}
@Column(name="BLOCKED_FLAG")
public String getBlockedFlag() {
	return blockedFlag;
}
public void setBlockedFlag(String blockedFlag) {
	this.blockedFlag = blockedFlag;
}

@Column(name="UPDT_DATE")
public Date getUpdateDate() {
	return updateDate;
}
public void setUpdateDate(Date updateDate) {
	this.updateDate = updateDate;
}
@Column(name="UPDT_USER")
public String getUpdateUser() {
	return updateUser;
}
public void setUpdateUser(String updateUser) {
	this.updateUser = updateUser;
}
@Column(name="DESCRIPTION")
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
@Column(name="ACCT_NO")
public String getAcctNumber() {
	return acctNumber;
}
public void setAcctNumber(String acctNumber) {
	this.acctNumber = acctNumber;
}



}
