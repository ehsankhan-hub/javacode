package com.bsf.ppm;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.bsf.ipp.dao.Cacheable;

/**
 * <p>Pojo mapping TABLE IPPUSER.BACKEND_ERROR_CODES</p>
 * @author Kaza
 * 
 */
@Entity
@Table(name = "BACKEND_ERROR_CODES")
@SuppressWarnings("serial")
public class BackendErrorCodes implements Cacheable {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute code.
	 */
	private String code;
	
	/**
	 * Attribute description.
	 */
	private String description;
	
	/**
	 * Attribute system.
	 */
	private String system;
	
	
	/**
	 * @return id
	 */
	@Basic
	@Id
	@Column(name = "ID")
		public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return code
	 */
	@Basic
	@Column(name = "CODE", length = 4)
		public String getCode() {
		return code;
	}

	/**
	 * @param code new value for code 
	 */
	public void setCode(String code) {
		this.code = code;
	}
	
	/**
	 * @return description
	 */
	@Basic
	@Column(name = "DESCRIPTION", length = 256)
		public String getDescription() {
		return description;
	}

	/**
	 * @param description new value for description 
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * @return system
	 */
	@Basic
	@Column(name = "SYSTEM", length = 10)
		public String getSystem() {
		return system;
	}

	/**
	 * @param system new value for system 
	 */
	public void setSystem(String system) {
		this.system = system;
	}

	@Transient
	public String getKey() {
		// TODO Auto-generated method stub
		return getCode();
	}
	
	public String toString(){
		return getDescription();
	}
}