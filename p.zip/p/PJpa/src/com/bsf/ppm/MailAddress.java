package com.bsf.ppm;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

/**
 * <p>Pojo mapping TABLE IPPUSER.MAIL_ADDRESS</p>
 * Kaza
 * 
 */
@Entity
@NamedQuery(name = "MailAddress.findAll", 
	    query = "select o from MailAddress o")
@Table(name = "MAIL_ADDRESS")
@SuppressWarnings("serial")
public class MailAddress implements Serializable {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute addressType.
	 */
	private Long addressType;
	
	/**
	 * Attribute mailAddress.
	 */
	private String mailAddress;
	
	/**
	 * Attribute mailMessage
	 */
	 private MailMessage mailMessage;	

	
	/**
	 * @return id
	 */
	@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "mailAddressIdGen")
	@TableGenerator(name = "mailAddressIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "MAIL_ADDRESS", valueColumnName = "ID_VALUE")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return addressType
	 */
	@Basic
	@Column(name = "ADDRESS_TYPE")
		public Long getAddressType() {
		return addressType;
	}

	/**
	 * @param addressType new value for addressType 
	 */
	public void setAddressType(Long addressType) {
		this.addressType = addressType;
	}
	
	/**
	 * @return mailAddress
	 */
	@Basic
	@Column(name = "MAIL_ADDRESS", length = 100)
		public String getMailAddress() {
		return mailAddress;
	}

	/**
	 * @param mailAddress new value for mailAddress 
	 */
	public void setMailAddress(String mailAddress) {
		this.mailAddress = mailAddress;
	}
	
	/**
	 * get mailMessage
	 */
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "MAIL_ID")
	public MailMessage getMailMessage() {
		return this.mailMessage;
	}
	
	/**
	 * set mailMessage
	 */
	public void setMailMessage(MailMessage mailMessage) {
		this.mailMessage = mailMessage;
	}



}