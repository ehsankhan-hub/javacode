package com.bsf.ppm;

import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;
import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.SelectableAuditableCacheableEntity;
import com.bsf.ppm.constants.IConstants.RATE_INDICATOR;

/**
 * <p>Pojo mapping TABLE IPPUSER.CURRENCY_CODE</p>
 * @author Kaza
 * 
 */
@Entity
@NamedQuery(name = "CurrencyCode.findByCurrencyCode", 
	    query = "select o from CurrencyCode  o where o.currencyCode=:currencyCode and o.status=:status")
@Table(name = "CURRENCY_CODE")
@SuppressWarnings("serial")
public class CurrencyCode extends SelectableAuditableCacheableEntity  {

	/**
	 * Attribute id.
	 */
	//private Long id;

	/**
	 * Attribute currencyCode.
	 */
	private String currencyCode;

	/**
	 * Attribute precision.
	 */
	private Long precision;
	
	/**
	 * Attribute cutoffTime.
	 */
	private String cutoffTime;
	
	private RATE_INDICATOR rateIndicator;
	
	private String autoFxCutoffTime;
	
	private Short maxFutureDaysAllowed;

	/**
	 * Attribute description.
	 */
	private String description;

	/**
	 * Attribute status.
	 */
	private Long status;

	/**
	 * Attribute createdBy
	 */
	private UserInfo createdBy;	
	/**
	 * Attribute modifiedBy
	 */
	private UserInfo modifiedBy;	

	/**
	 * Attribute createdDate.
	 */
	private Timestamp createdDate;

	/**
	 * Attribute modifiedDate.
	 */
	private Timestamp modifiedDate;


	/**
	 * @return id
	 */
	/*@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "currencyCodeIdGen")
	@TableGenerator(name = "currencyCodeIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "CURRENCY_CODE", valueColumnName = "ID_VALUE")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}*/

	/**
	 * @param id new value for id 
	 */
	/*public void setId(Long id) {
		this.id = id;
	}*/

	/**
	 * @return currencyCode
	 */
	@Id
	@Basic
	@Column(name = "CURRENCY_CODE", length = 3)
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * @param currencyCode new value for currencyCode 
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * @return precision
	 */
	@Basic
	@Column(name = "PRECISION")
	public Long getPrecision() {
		return precision;
	}

	/**
	 * @param precision new value for precision 
	 */
	public void setPrecision(Long precision) {
		this.precision = precision;
	}
	/**
	 * @return cutoffTime
	 */
	@Basic
	@Column(name = "CUTOFF_TIME", length = 5)
	public String getCutoffTime() {
		return cutoffTime;
	}

	/**
	 * @param cutoffTime new value for cutoffTime 
	 */
	public void setCutoffTime(String cutoffTime) {
		this.cutoffTime = cutoffTime;
	}

	/**
	 * @return description
	 */
	@Basic
	@Column(name = "DESCRIPTION", length = 30)
	public String getDescription() {
		return description;
	}

	/**
	 * @param description new value for description 
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return createdDate
	 */
	@Basic
	@Column(name = "CREATED_DATE")
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate new value for createdDate 
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}



	/**
	 * @return modifiedDate
	 */
	@Basic
	@Column(name = "MODIFIED_DATE")
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate new value for modifiedDate 
	 */
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * get modifiedBy
	 */
	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name = "MODIFIED_BY")
	public UserInfo getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * set modifiedBy
	 */
	public void setModifiedBy(UserInfo modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * get createdBy
	 */
	@ManyToOne
	@JoinColumn(name = "CREATED_BY")
	public UserInfo getCreatedBy() {
		return this.createdBy;
	}
	/**
	 * set createdBy
	 */
	public void setCreatedBy(UserInfo createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the status
	 */
	@Basic
	@Column(name = "STATUS")	
	public Long getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Long status) {
		this.status = status;
	}

	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getCurrencyCode());
	}

	@Transient
	public String getKey() {
		// TODO Auto-generated method stub
		return getCurrencyCode();
	}
	
	@Override
	public String toString() {
		
		return currencyCode;
	}
	
	
	@Basic
	@Column(name = "RATE_INDICATOR")
	public RATE_INDICATOR getRateIndicator() {
		return rateIndicator;
	}

	public void setRateIndicator(RATE_INDICATOR rateIndicator) {
		this.rateIndicator = rateIndicator;
	}

	
	@Basic
	@Column(name = "AUTO_FX_CUTOFF_TIME", length = 5)
	public String getAutoFxCutoffTime() {
		return autoFxCutoffTime;
	}

	public void setAutoFxCutoffTime(String autoFxCutoffTime) {
		this.autoFxCutoffTime = autoFxCutoffTime;
	}

	@Basic
	@Column(name = "MAX_FUTURE_DAY_ALLOWED", length = 5)
	public Short getMaxFutureDaysAllowed() {
		return maxFutureDaysAllowed;
	}

	public void setMaxFutureDaysAllowed(Short maxFutureDaysAllowed) {
		this.maxFutureDaysAllowed = maxFutureDaysAllowed;
	}
	
	
}