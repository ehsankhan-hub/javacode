
package com.bsf.ppm.jpa.util;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

import org.apache.commons.lang.StringUtils;

import com.bsf.ipp.GeneralConfiguration;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.BackendSystem;
import com.bsf.ppm.SystemConfiguration;
import com.bsf.ppm.SystemTypeParameter;

public class BackendUtil {

	public static String getParameterValue(BackendSystem backEnd,
			String paramName) {

		String paramValue = null;
		if (backEnd != null) {
			List<SystemConfiguration> sysConfigs = backEnd
					.getSystemConfigurations();

			for (SystemConfiguration sysConfig : sysConfigs) {

				SystemTypeParameter sysTypeParam = sysConfig
						.getSystemTypeParameter();
				if (sysTypeParam.getParamName().equals(paramName)) {
					paramValue = sysConfig.getParamValue();
				}
			}
		}
		return paramValue;
	}

	/**
	 * Fetch GeneralConfigParameter Value
	 * 
	 * @param generalConfig
	 *            GeneralConfiguration to search
	 * @param paramName
	 *            general Config Param Name
	 * @return paramValue for the general Config Parameter
	 */
	public static String getGeneralConfigParameterValue(
			GeneralConfiguration generalConfig, String paramName) {
		if (generalConfig == null)
			return null;
		if (generalConfig.getGeneralConfigParameters() != null
				&& generalConfig.getGeneralConfigParameters().containsKey(
						paramName))
			return generalConfig.getGeneralConfigParameters().get(paramName)
					.getParamValue();
		return null;

	}
	
	/**
	 * @param generalConfigurationCache General Config object For BusinessDate
	 * @param paramName to fetch from BusinessDate. "CutOffTime" or "CutOverTime". 
	 * @return Date object for the paramName 
	 */
	public static Date getConfiguredBusinessDateTime(Cache generalConfigurationCache, String paramName) {
		Date configuredTime = null;
		String paramValue = null;
		// Fetch BusinessDate General Configuration
		Element elem = generalConfigurationCache.get("BusinessDate");
		if (elem != null) {
			GeneralConfiguration generalConfig = (GeneralConfiguration) elem
			.getObjectValue();
			// check if generalConfig is active
			if (generalConfig.getStatus().equals(
					Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()))) {
				//Get the Param value from general config matching the paramName
				paramValue = BackendUtil.getGeneralConfigParameterValue(
						generalConfig, paramName);
			}
		}

		//Build the Time Object
		String[] strArray = StringUtils.split(paramValue, ':');

		if(strArray != null && strArray.length ==2) {
			Calendar gc = GregorianCalendar.getInstance();
			gc.set(Calendar.DATE,gc.get(Calendar.DATE));
			gc.set(Calendar.HOUR_OF_DAY, new Integer(strArray[0]).intValue());
			gc.set(Calendar.MINUTE, new Integer(strArray[1]).intValue());
			configuredTime = gc.getTime();
		}

		return configuredTime;
	}

}
