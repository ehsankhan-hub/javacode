package com.bsf.ppm.jpa.util;

import com.bsf.ppm.util.LogUtil;

public class OutwardLogUtil extends LogUtil{
	
	public static void creditBatchErrorLogs(String log){
		outwardCreditLog.error(log);
	}
	public static void creditBatchInfoLogs(String log){
		outwardCreditLog.info(log);
	}

}
