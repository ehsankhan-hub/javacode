package com.bsf.ppm;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.transaction.annotation.Transactional;

@Entity
@Table(name = "PPM_INSTRUCTIONS_MODIFY")
@SuppressWarnings("serial")
public class InstructionsModify implements Serializable{

private Long id;
private String instRefer;
private Long instDtlId;
private String fieldName;
private String oldValue;
private String newVlaue;
private String isApplied;
private Date modifiedDate;
private String modifiedBy;
private Date approvedDate;
private String approvedBy;
private String samaReference;
@Id
@Basic
@Column(name="MODIFY_REF")
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
@Column(name="INST_REFERENCE")
public String getInstRefer() {
	return instRefer;
}
public void setInstRefer(String instRefer) {
	this.instRefer = instRefer;
}
@Column(name="INST_DTL_ID")
public Long getInstDtlId() {
	return instDtlId;
}
public void setInstDtlId(Long instDtlId) {
	this.instDtlId = instDtlId;
}
@Column(name="FIELD_NAME")
public String getFieldName() {
	return fieldName;
}
public void setFieldName(String fieldName) {
	this.fieldName = fieldName;
}
@Column(name="OLD_VALUE")
public String getOldValue() {
	return oldValue;
}
public void setOldValue(String oldValue) {
	this.oldValue = oldValue;
}
@Column(name="NEW_VALUE")
public String getNewVlaue() {
	return newVlaue;
}
public void setNewVlaue(String newVlaue) {
	this.newVlaue = newVlaue;
}
@Column(name="IS_APPLIED")
public String getIsApplied() {
	return isApplied;
}

public void setIsApplied(String isApplied) {
	this.isApplied = isApplied;
}
@Column(name="MODIFIED_DATE")
public Date getModifiedDate() {
	return modifiedDate;
}

public void setModifiedDate(Date modifiedDate) {
	this.modifiedDate = modifiedDate;
}
@Column(name="MODIFIED_BY")
public String getModifiedBy() {
	return modifiedBy;
}

public void setModifiedBy(String modifiedBy) {
	this.modifiedBy = modifiedBy;
}
@Column(name="APPROVED_DATE")
public Date getApprovedDate() {
	return approvedDate;
}

public void setApprovedDate(Date approvedDate) {
	this.approvedDate = approvedDate;
}
@Column(name="APPROVED_BY")
public String getApprovedBy() {
	return approvedBy;
}
public void setApprovedBy(String approvedBy) {
	this.approvedBy = approvedBy;
}
@Transient
public String getSamaReference() {
	return samaReference;
}
public void setSamaReference(String samaReference) {
	this.samaReference = samaReference;
}




	
}
