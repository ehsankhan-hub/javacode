package com.bsf.ppm;

import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.bsf.ppm.constants.IConstants;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AccessGroups {

	private DataSource dataSource;
	private static final Logger log = Logger.getLogger("DaoLog") ;
	
public String[] getUserGroups(String userId){
		
		String[] columns={"",""};
		String query = IConstants.USER_GROUPS;	
		log.info("Query = "+query);
		Connection conn=null;
		PreparedStatement pStat;
		ResultSet result =null;
		try {
			conn = dataSource.getConnection();
			pStat = conn.prepareStatement(query);
			pStat.setString(1, userId);	
			result = pStat.executeQuery() ;
			 while(result.next()){
				 columns[0]=(String)result.getObject("pCode");
				 columns[1]=(String)result.getObject("dCode");
				 System.out.println("columns[0]=="+columns[0]);
				 System.out.println("columns[1]=="+columns[1]);
			 }
			 
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				result.close();				
				conn.close();
			} catch (SQLException e1) {				
				e1.printStackTrace();
			}
			e.printStackTrace();
		}finally{
			try {
				result.close();		
				conn.close();
			} catch (SQLException e1) {				
				e1.printStackTrace();
			}
		}
		return columns;
	}

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
}
