package com.bsf.ppm.fts;

import java.util.Date;

import javax.persistence.Transient;

import com.bsf.ppm.formatting.annotations.Align;
import com.bsf.ppm.formatting.annotations.Field;
import com.bsf.ppm.formatting.annotations.FixedFormatDecimal;
import com.bsf.ppm.formatting.annotations.FixedFormatPattern;
import com.bsf.ppm.formatting.annotations.Record;
/**
* Class to hold FTSRequestEntity
* @author ClassGenerator by Zakir 
*/
@Record
public class FTSRequestPostingEntityMRKM  extends FTSHeaderEntity{

	/** Transaction Type � Static Value - �#061�-  (SARIE incoming transfer)  */
	private String transType;
	/** Transaction (Business); Date [YYYYMMDD]- Business Date */
	private Date transDate;
	/** Value (Business / Future / Back); Date [YYYYMMDD]- Business Date */
	private Date valueDate;
	/** Transaction Currency- Static value �SAR� */
	private String transCrncy;
	/** Transaction Amount in Transaction Currency - [0000000000000.00] � Incoming Transfer  Amount */
	private String transAmount;
	/** Transaction Amount in Saudi Riyals - [0000000000000.00] � Incoming Transfer  Amount */
	private String transAmountSar;
	/** Account statement narrative. �INCOMING TRF � + Remitter name +|�,� +  Trf. Reference + �,� + other references */
	private String genNarrative;
	/** User Narrative */
	private String screenNarrative;
	/** Debit Account Left Padded with Zeros- BSF Internal account  for incoming Transfers  */
	private String debitAcctNo;
	/** Debit Account Currency - Static value �SAR� */
	private String debitAcctCrncy;
	/** Debit Amount - [0000000000000.00] � Incoming Transfer  Amount */
	private String debitAmount;
	/** Debit Currency Rate - (00.000000)-  Static value �01.000000� */
	private Double debitCrncyRate;
	/** Debit Value Date - [YYYYMMDD]. Business date  */
	private Date debitValueDate;
	/** Debit Account Sarraf Flag (From Acct Inquiry); [Y/N]. Static Value � �N� */
	private String debitSrfFlag;
	/** Debit Account Servicing Branch - Branch code to which the account belongs */
	private String debitBranch;
	/** Credit Account Left Padded with Zeros � Incoming Transfer beneficiary account  */
	private String creditAcctNo;
	/** Credit Account currency-  Credit Account currency */
	private String creditAcctCrncy;
	/** Credit Amount in Credit Acct Currency  - [0000000000000.00] � Incoming Transfer  Amount */
	private String creditAmount;
	/** Credit Currency Rate - [00.000000]- Static value �01.000000� */
	private Double creditCrncyRate;
	/** Credit Value Date - [YYYYMMDD]- Business date */
	private Date creditValueDate;
	/** Credit Account Sarraf Flag (From Acct Inquiry); Static Value � �N� */
	private String creditSrfFlag;
	/** Credit Account Servicing Branch � Branch code to which the account belongs */
	private String creditBranch;
	/** Commission Currency */
	private String commissionCrncy;
	/** Commission Amount  - [0000000000000.00] */
	private String commissionAmount;
	/** Commission Account No. [20 digits, left padded with Zeros] */
	private String commissionAcct;
	/** Charges Currency- Static value �SAR� */
	private String chargesCrncy;
	/** Charges Amount  - [0000000000000.00]-Static value �0000000000000.00� */
	private String chargesAmount;
	/** Charges Account No. [20 digits, left padded with Zeros] */
	private String chargesAcct;
	/** GTD Deal Ticket Number */
	private String gtdDealTicket;
	/** Initiation Time - [HHMMSS] */
	private Date initTime;
	/** Validating Officer s BSF ID */
	private String validationOfficer;
	/** Validation Time - [HHMMSS] */
	private Date validationTime;
	/** Authorizing Officer s BSF ID */
	private String authorznOfficer;
	/** Authorization Time - [HHMMSS] */
	private Date authorznTime;
	/** Reasons for Authorization */
	private String authorznReason;
	/** Authorization Status - [AUI/ANC/AUA/AUR] */
	private String authorznStatus;
	/** Computed field - Length of Dynamic Part */
	private Integer dynamicPartLen;
	/** Static Part - Cheque Number (Applicable for Cheque Transactions) */
	private String staticPartChequeNo;
	/** Static Part - ID Type */
	private String staticPartIdType;
	/** Static Part - ID Number */
	private String staticPartIdNumber;
	/** Static Part -  Print Detail Flag (Y/N) Indicator to say whether a Transaction Print is Required) */
	private String staticPartPrintDetail;
	/** Static Part - Mail Advice Flag (Y/N Indicator to say whether a Mail Advice is to be sent for this Transaction) */
	private String staticPartMailAdvice;
	/** MARKI Transaction type start */
	//private String rsstReference;
	private String rsstReference;
	private String rsstReasonCode;
	private String rsstReasonDes;
	private Date rsstExpDate;
	private String flag;
	private String branch;
	private String blckReference;
	/** MARKI Transaction type end */
		
	
	private String transAmountPrecision;
	private String transAmountSarPrecision;
	private String debitAmountPrecision;
	private String debitCrncyRatePrecision;
	private String creditAmountPrecision;
	private String creditCrncyRatePrecision;
	private String commissionAmountPrecision;
	private String chargesAmountPrecision;
	
	
	@Transient
	public String getTransAmountPrecision() {
		return transAmountPrecision;
	}

	public void setTransAmountPrecision(String transAmountPrecision) {
		this.transAmountPrecision = transAmountPrecision;
	}

	@Transient
	public String getTransAmountSarPrecision() {
		return transAmountSarPrecision;
	}

	public void setTransAmountSarPrecision(String transAmountSarPrecision) {
		this.transAmountSarPrecision = transAmountSarPrecision;
	}

	@Transient
	public String getDebitAmountPrecision() {
		return debitAmountPrecision;
	}

	public void setDebitAmountPrecision(String debitAmountPrecision) {
		this.debitAmountPrecision = debitAmountPrecision;
	}

	@Transient
	public String getDebitCrncyRatePrecision() {
		return debitCrncyRatePrecision;
	}

	public void setDebitCrncyRatePrecision(String debitCrncyRatePrecision) {
		this.debitCrncyRatePrecision = debitCrncyRatePrecision;
	}

	@Transient
	public String getCreditAmountPrecision() {
		return creditAmountPrecision;
	}

	public void setCreditAmountPrecision(String creditAmountPrecision) {
		this.creditAmountPrecision = creditAmountPrecision;
	}

	@Transient
	public String getCreditCrncyRatePrecision() {
		return creditCrncyRatePrecision;
	}

	public void setCreditCrncyRatePrecision(String creditCrncyRatePrecision) {
		this.creditCrncyRatePrecision = creditCrncyRatePrecision;
	}

	@Transient
	public String getCommissionAmountPrecision() {
		return commissionAmountPrecision;
	}

	public void setCommissionAmountPrecision(String commissionAmountPrecision) {
		this.commissionAmountPrecision = commissionAmountPrecision;
	}

	@Transient
	public String getChargesAmountPrecision() {
		return chargesAmountPrecision;
	}

	public void setChargesAmountPrecision(String chargesAmountPrecision) {
		this.chargesAmountPrecision = chargesAmountPrecision;
	}


	public static FTSRequestPostingEntityMRKM getInstance() {
		FTSRequestPostingEntityMRKM request = new FTSRequestPostingEntityMRKM();
		request.setSourceSystem("LLS"); //static
		request.setRequestFunction("FINUPD04"); //static
		//request.setRequestFunction("FINUPD01"); //static
		request.setServerDate(new Date()); 
		request.setServerTime(new Date());
		//request.setFTSReference(""); //static
		request.setFtsTransFunc(" "); //static to spaces
		request.setCammTranNum(0); //static to 000000
		request.setNoOfBlocks(1);  //static to 001
		request.setCurrBlockNo(1); //static to 001
		request.setNoOfItems(0);
		request.setCustomerCode(" "); //static to spaces
		request.setAccountNo(""); //static to spaces
		request.setInitBranch("022"); //static to 066
		//request.setInitOfficer("  ");
		request.setCardNumber(" "); //static to spaces
		//request.setFunctionCode("201"); //Static set to 201
		request.setCAMMActionCode("5555"); //CaMM action code set to 5555
		request.setLastUpdateDate(new Date());
		request.setLastUpdateTime(new Date());
		//request.setTransactionStatus("AUI"); //Static to AUI
		request.setFTSActionCode("6666"); // FTS action code set to 6666
		request.setProcessingSeq(1);
		request.setDetailLength(528);
		//request.setTransType("#061"); // Static set to #061
		request.setTransDate(new Date());
		//request.setValueDate(new Date());
		//request.setTransCrncy("SAR");
		request.setTransAmount("0000000000000.00");
		request.setTransAmountSar("0000000000000.00");
		request.setDebitAmount("0000000000000.00");
		request.setCreditAmount("0000000000000.00");
		request.setCommissionAmount("0000000000000.00");
		request.setChargesAmount("0000000000000.00");
        
		//request.setDebitAcctNo(" "); //Acc no default to spaces
		//request.setDebitAcctCrncy("SAR");
		//request.setDebitAmount(new Double(1000));
		request.setDebitCrncyRate(new Double(01.000000));
		request.setCreditCrncyRate(new Double(01.000000));
		//request.setDebitValueDate(new Date());
		request.setDebitSrfFlag("N");
		request.setDebitBranch("022"); //set to 066 default
		//request.setCreditAcctNo(""); //Acc no default to spaces
		//request.setCreditAcctCrncy("SAR");
		//request.setCreditValueDate(new Date());
		request.setCreditSrfFlag("N");
		request.setCreditBranch("022");
		request.setCommissionCrncy("SAR");
		//request.setRsstReasonDes("2");
		request.setCommissionAcct("");
		
		request.setChargesAcct("00000000000000000000");
		request.setChargesCrncy("SAR");
		request.setGtdDealTicket("");
		request.setInitTime(new Date());
		request.setValidationOfficer("");
		request.setValidationTime(new Date());
		request.setAuthorznOfficer("");
		request.setAuthorznTime(new Date());
		request.setAuthorznReason("NNNNNNNNNN");
		//request.setAuthorznStatus("AUR");
		request.setDynamicPartLen(0);
		request.setStaticPartChequeNo("000000000000000");
		request.setStaticPartIdType("");
		request.setStaticPartIdNumber("");
		request.setStaticPartPrintDetail("N");
		request.setStaticPartMailAdvice("N");
		//request.setBrokerCustomerId("");

		return request;
	} 
 

 
	/** 
	* get Transaction Type � Static Value - �#061�-  (SARIE incoming transfer) 
	* @return the transType
	*/
	@Field(offset=161, length=4, paddingChar=' ')
	public String getTransType() {
		return transType;
	} 
 
	/** 
	* set Transaction Type � Static Value - �#061�-  (SARIE incoming transfer) 
	* @param transType new value for transType
	*/
	public void setTransType(String transType) {
		this.transType=transType;
	} 
 
	/** 
	* get Transaction (Business); Date [YYYYMMDD]- Business Date
	* @return the transDate
	*/
	@Field(offset=165, length=8)
	@FixedFormatPattern("yyyyMMdd")
	public Date getTransDate() {
		return transDate;
	} 
 
	/** 
	* set Transaction (Business); Date [YYYYMMDD]- Business Date
	* @param transDate new value for transDate
	*/
	public void setTransDate(Date transDate) {
		this.transDate=transDate;
	} 
 
	/** 
	* get Value (Business / Future / Back); Date [YYYYMMDD]- Business Date
	* @return the valueDate
	*/
	@Field(offset=173, length=8)
	@FixedFormatPattern("yyyyMMdd")
	public Date getValueDate() {
		return valueDate;
	} 
 
	/** 
	* set Value (Business / Future / Back); Date [YYYYMMDD]- Business Date
	* @param valueDate new value for valueDate
	*/
	public void setValueDate(Date valueDate) {
		this.valueDate=valueDate;
	} 
 
	/** 
	* get Transaction Currency- Static value �SAR�
	* @return the transCrncy
	*/
	@Field(offset=181, length=3, paddingChar=' ')
	public String getTransCrncy() {
		return transCrncy;
	} 
 
	/** 
	* set Transaction Currency- Static value �SAR�
	* @param transCrncy new value for transCrncy
	*/
	public void setTransCrncy(String transCrncy) {
		this.transCrncy=transCrncy;
	} 
 
	/** 
	* get Transaction Amount in Transaction Currency - [0000000000000.00] � Incoming Transfer  Amount
	* @return the transAmount
	*/
	@Field(offset=184, length=16, paddingChar='0', align=Align.RIGHT)
	@FixedFormatDecimal(useDecimalDelimiter=true)
	public String getTransAmount() {
		return transAmount;
	} 
 
	/** 
	* set Transaction Amount in Transaction Currency - [0000000000000.00] � Incoming Transfer  Amount
	* @param transAmount new value for transAmount
	*/
	public void setTransAmount(String transAmount) {
		this.transAmount=transAmount;
	} 
 
	/** 
	* get Transaction Amount in Saudi Riyals - [0000000000000.00] � Incoming Transfer  Amount
	* @return the transAmountSar
	*/
	@Field(offset=200, length=16, paddingChar='0', align=Align.RIGHT)
	@FixedFormatDecimal(useDecimalDelimiter=true)
	public String getTransAmountSar() {
		return transAmountSar;
	} 
 
	/** 
	* set Transaction Amount in Saudi Riyals - [0000000000000.00] � Incoming Transfer  Amount
	* @param transAmountSar new value for transAmountSar
	*/
	public void setTransAmountSar(String transAmountSar) {
		this.transAmountSar=transAmountSar;
	} 
 
	/** 
	* get Account statement narrative. �INCOMING TRF � + Remitter name +|�,� +  Trf. Reference + �,� + other references
	* @return the genNarrative
	*/
	@Field(offset=216, length=60, paddingChar=' ')
	public String getGenNarrative() {
		return genNarrative;
	} 
 
	/** 
	* set Account statement narrative. �INCOMING TRF � + Remitter name +|�,� +  Trf. Reference + �,� + other references
	* @param genNarrative new value for genNarrative
	*/
	public void setGenNarrative(String genNarrative) {
		this.genNarrative=genNarrative;
	} 
 
	/** 
	* get User Narrative
	* @return the screenNarrative
	*/
	@Field(offset=256, length=20, paddingChar=' ')
	public String getScreenNarrative() {
		return screenNarrative;
	} 
 
	/** 
	* set User Narrative
	* @param screenNarrative new value for screenNarrative
	*/
	public void setScreenNarrative(String screenNarrative) {
		this.screenNarrative=screenNarrative;
	} 
 
	/** 
	* get Debit Account Left Padded with Zeros- BSF Internal account  for incoming Transfers 
	* @return the debitAcctNo
	*/
	@Field(offset=296, length=20, paddingChar='0', align=Align.RIGHT)
	public String getDebitAcctNo() {
		return debitAcctNo;
	} 
 
	/** 
	* set Debit Account Left Padded with Zeros- BSF Internal account  for incoming Transfers 
	* @param debitAcctNo new value for debitAcctNo
	*/
	public void setDebitAcctNo(String debitAcctNo) {
		this.debitAcctNo=debitAcctNo;
	} 
 
	/** 
	* get Debit Account Currency - Static value �SAR�
	* @return the debitAcctCrncy
	*/
	@Field(offset=316, length=3, paddingChar=' ')
	public String getDebitAcctCrncy() {
		return debitAcctCrncy;
	} 
 
	/** 
	* set Debit Account Currency - Static value �SAR�
	* @param debitAcctCrncy new value for debitAcctCrncy
	*/
	public void setDebitAcctCrncy(String debitAcctCrncy) {
		this.debitAcctCrncy=debitAcctCrncy;
	} 
 
	/** 
	* get Debit Amount - [0000000000000.00] � Incoming Transfer  Amount
	* @return the debitAmount
	*/
	@Field(offset=319, length=16, paddingChar='0', align=Align.RIGHT)
	@FixedFormatDecimal(useDecimalDelimiter=true)
	public String getDebitAmount() {
		return debitAmount;
	} 
 
	/** 
	* set Debit Amount - [0000000000000.00] � Incoming Transfer  Amount
	* @param debitAmount new value for debitAmount
	*/
	public void setDebitAmount(String debitAmount) {
		this.debitAmount=debitAmount;
	} 
 
	/*
	* get Debit Currency Rate - (00.000000)-  Static value �01.000000�
	* @return the debitCrncyRate
	*/
	@Field(offset=335, length=9, paddingChar='0', align=Align.RIGHT)
	@FixedFormatDecimal(decimals=5, useDecimalDelimiter=true)
	public Double getDebitCrncyRate() {
		return debitCrncyRate;
	} 
 
     /** 
	* set Debit Currency Rate - (00.000000)-  Static value �01.000000�
	* @param debitCrncyRate new value for debitCrncyRate
	*/
	public void setDebitCrncyRate(Double debitCrncyRate) {
		this.debitCrncyRate=debitCrncyRate;
	} 
 
	/** 
	* get Debit Value Date - [YYYYMMDD]. Business date 
	* @return the debitValueDate
	*/
	@Field(offset=344, length=8)
	@FixedFormatPattern("yyyyMMdd")
	public Date getDebitValueDate() {
		return debitValueDate;
	} 
 
	/** 
	* set Debit Value Date - [YYYYMMDD]. Business date 
	* @param debitValueDate new value for debitValueDate
	*/
	public void setDebitValueDate(Date debitValueDate) {
		this.debitValueDate=debitValueDate;
	} 
 
	/** 
	* get Debit Account Sarraf Flag (From Acct Inquiry); [Y/N]. Static Value � �N�
	* @return the debitSrfFlag
	*/
	@Field(offset=352, length=1, paddingChar=' ')
	public String getDebitSrfFlag() {
		return debitSrfFlag;
	} 
 
	/** 
	* set Debit Account Sarraf Flag (From Acct Inquiry); [Y/N]. Static Value � �N�
	* @param debitSrfFlag new value for debitSrfFlag
	*/
	public void setDebitSrfFlag(String debitSrfFlag) {
		this.debitSrfFlag=debitSrfFlag;
	} 
 
	/** 
	* get Debit Account Servicing Branch - Branch code to which the account belongs
	* @return the debitBranch
	*/
	@Field(offset=353, length=6, paddingChar=' ')
	public String getDebitBranch() {
		return debitBranch;
	} 
 
	/** 
	* set Debit Account Servicing Branch - Branch code to which the account belongs
	* @param debitBranch new value for debitBranch
	*/
	public void setDebitBranch(String debitBranch) {
		this.debitBranch=debitBranch;
	} 
 
	/** 
	* get Credit Account Left Padded with Zeros � Incoming Transfer beneficiary account 
	* @return the creditAcctNo
	*/
	@Field(offset=359, length=20, paddingChar='0', align=Align.RIGHT)
	public String getCreditAcctNo() {
		return creditAcctNo;
	} 
 
	/** 
	* set Credit Account Left Padded with Zeros � Incoming Transfer beneficiary account 
	* @param creditAcctNo new value for creditAcctNo
	*/
	public void setCreditAcctNo(String creditAcctNo) {
		this.creditAcctNo=creditAcctNo;
	} 
 
	/** 
	* get Credit Account currency-  Credit Account currency
	* @return the creditAcctCrncy
	*/
	@Field(offset=379, length=3, paddingChar=' ')
	public String getCreditAcctCrncy() {
		return creditAcctCrncy;
	} 
 
	/** 
	* set Credit Account currency-  Credit Account currency
	* @param creditAcctCrncy new value for creditAcctCrncy
	*/
	public void setCreditAcctCrncy(String creditAcctCrncy) {
		this.creditAcctCrncy=creditAcctCrncy;
	} 
 
	/** 
	* get Credit Amount in Credit Acct Currency  - [0000000000000.00] � Incoming Transfer  Amount
	* @return the creditAmount
	*/
	@Field(offset=382, length=16, paddingChar='0', align=Align.RIGHT)
	@FixedFormatDecimal(useDecimalDelimiter=true)
	public String getCreditAmount() {
		return creditAmount;
	} 
 
	/** 
	* set Credit Amount in Credit Acct Currency  - [0000000000000.00] � Incoming Transfer  Amount
	* @param creditAmount new value for creditAmount
	*/
	public void setCreditAmount(String creditAmount) {
		this.creditAmount=creditAmount;
	} 
 
	/** 
	* get Credit Currency Rate - [00.000000]- Static value �01.000000�
	* @return the creditCrncyRate
	*/
	@Field(offset=398, length=9, paddingChar='0', align=Align.RIGHT)
	@FixedFormatDecimal(decimals=5, useDecimalDelimiter=true)
	public Double getCreditCrncyRate() {
		return creditCrncyRate;
	} 
 
	/** 
	* set Credit Currency Rate - [00.000000]- Static value �01.000000�
	* @param creditCrncyRate new value for creditCrncyRate
	*/
	public void setCreditCrncyRate(Double creditCrncyRate) {
		this.creditCrncyRate=creditCrncyRate;
	} 
 
	/** 
	* get Credit Value Date - [YYYYMMDD]- Business date
	* @return the creditValueDate
	*/
	@Field(offset=407, length=8)
	@FixedFormatPattern("yyyyMMdd")
	public Date getCreditValueDate() {
		return creditValueDate;
	} 
 
	/** 
	* set Credit Value Date - [YYYYMMDD]- Business date
	* @param creditValueDate new value for creditValueDate
	*/
	public void setCreditValueDate(Date creditValueDate) {
		this.creditValueDate=creditValueDate;
	} 
 
	/** 
	* get Credit Account Sarraf Flag (From Acct Inquiry); Static Value � �N�
	* @return the creditSrfFlag
	*/
	@Field(offset=415, length=1, paddingChar=' ')
	public String getCreditSrfFlag() {
		return creditSrfFlag;
	} 
 
	/** 
	* set Credit Account Sarraf Flag (From Acct Inquiry); Static Value � �N�
	* @param creditSrfFlag new value for creditSrfFlag
	*/
	public void setCreditSrfFlag(String creditSrfFlag) {
		this.creditSrfFlag=creditSrfFlag;
	} 
 
	/** 
	* get Credit Account Servicing Branch � Branch code to which the account belongs
	* @return the creditBranch
	*/
	@Field(offset=416, length=6, paddingChar=' ')
	public String getCreditBranch() {
		return creditBranch;
	} 
 
	/** 
	* set Credit Account Servicing Branch � Branch code to which the account belongs
	* @param creditBranch new value for creditBranch
	*/
	public void setCreditBranch(String creditBranch) {
		this.creditBranch=creditBranch;
	} 
 
	/** 
	* get Commission Currency
	* @return the commissionCrncy
	*/
	@Field(offset=422, length=3, paddingChar=' ')
	public String getCommissionCrncy() {
		return commissionCrncy;
	} 
 
	/** 
	* set Commission Currency
	* @param commissionCrncy new value for commissionCrncy
	*/
	public void setCommissionCrncy(String commissionCrncy) {
		this.commissionCrncy=commissionCrncy;
	} 
 
	/** 
	* get Commission Amount  - [0000000000000.00]
	* @return the commissionAmount
	*/
	@Field(offset=425, length=16, paddingChar='0', align=Align.RIGHT)
	@FixedFormatDecimal(useDecimalDelimiter=true)
	public String getCommissionAmount() {
		return commissionAmount;
	} 
 
	/** 
	* set Commission Amount  - [0000000000000.00]
	* @param commissionAmount new value for commissionAmount
	*/
	public void setCommissionAmount(String commissionAmount) {
		this.commissionAmount=commissionAmount;
	} 
 
	/** 
	* get Commission Account No. [20 digits, left padded with Zeros]
	* @return the commissionAcct
	*/
	@Field(offset=441, length=20, paddingChar='0', align=Align.RIGHT)
	public String getCommissionAcct() {
		return commissionAcct;
	} 
 
	/** 
	* set Commission Account No. [20 digits, left padded with Zeros]
	* @param commissionAcct new value for commissionAcct
	*/
	public void setCommissionAcct(String commissionAcct) {
		this.commissionAcct=commissionAcct;
	} 
 
	/** 
	* get Charges Currency- Static value �SAR�
	* @return the chargesCrncy
	*/
	@Field(offset=461, length=3, paddingChar=' ')
	public String getChargesCrncy() {
		return chargesCrncy;
	} 
 
	/** 
	* set Charges Currency- Static value �SAR�
	* @param chargesCrncy new value for chargesCrncy
	*/
	public void setChargesCrncy(String chargesCrncy) {
		this.chargesCrncy=chargesCrncy;
	} 
 
	/** 
	* get Charges Amount  - [0000000000000.00]-Static value �0000000000000.00�
	* @return the chargesAmount
	*/
	@Field(offset=464, length=16, paddingChar='0', align=Align.RIGHT)
	@FixedFormatDecimal(useDecimalDelimiter=true)
	public String getChargesAmount() {
		return chargesAmount;
	} 
 
	/** 
	* set Charges Amount  - [0000000000000.00]-Static value �0000000000000.00�
	* @param chargesAmount new value for chargesAmount
	*/
	public void setChargesAmount(String chargesAmount) {
		this.chargesAmount=chargesAmount;
	} 
 
	/** 
	* get Charges Account No. [20 digits, left padded with Zeros]
	* @return the chargesAcct
	*/
	@Field(offset=480, length=20, paddingChar='0', align=Align.RIGHT)
	public String getChargesAcct() {
		return chargesAcct;
	} 
 
	/** 
	* set Charges Account No. [20 digits, left padded with Zeros]
	* @param chargesAcct new value for chargesAcct
	*/
	public void setChargesAcct(String chargesAcct) {
		this.chargesAcct=chargesAcct;
	} 
 
	/** 
	* get GTD Deal Ticket Number
	* @return the gtdDealTicket
	*/
	@Field(offset=500, length=20, paddingChar=' ')
	public String getGtdDealTicket() {
		return gtdDealTicket;
	} 
 
	/** 
	* set GTD Deal Ticket Number
	* @param gtdDealTicket new value for gtdDealTicket
	*/
	public void setGtdDealTicket(String gtdDealTicket) {
		this.gtdDealTicket=gtdDealTicket;
	} 
 
	/** 
	* get Initiation Time - [HHMMSS]
	* @return the initTime
	*/
	@Field(offset=520, length=6)
	@FixedFormatPattern("HHmmss")
	public Date getInitTime() {
		return initTime;
	} 
 
	/** 
	* set Initiation Time - [HHMMSS]
	* @param initTime new value for initTime
	*/
	public void setInitTime(Date initTime) {
		this.initTime=initTime;
	} 
 
	/** 
	* get Validating Officer s BSF ID
	* @return the validationOfficer
	*/
	@Field(offset=526, length=9, paddingChar=' ')
	public String getValidationOfficer() {
		return validationOfficer;
	} 
 
	/** 
	* set Validating Officer s BSF ID
	* @param validationOfficer new value for validationOfficer
	*/
	public void setValidationOfficer(String validationOfficer) {
		this.validationOfficer=validationOfficer;
	} 
 
	/** 
	* get Validation Time - [HHMMSS]
	* @return the validationTime
	*/
	@Field(offset=535, length=6)
	@FixedFormatPattern("HHmmss")
	public Date getValidationTime() {
		return validationTime;
	} 
 
	/** 
	* set Validation Time - [HHMMSS]
	* @param validationTime new value for validationTime
	*/
	public void setValidationTime(Date validationTime) {
		this.validationTime=validationTime;
	} 
 
	/** 
	* get Authorizing Officer s BSF ID
	* @return the authorznOfficer
	*/
	@Field(offset=541, length=9, paddingChar=' ')
	public String getAuthorznOfficer() {
		return authorznOfficer;
	} 
 
	/** 
	* set Authorizing Officer s BSF ID
	* @param authorznOfficer new value for authorznOfficer
	*/
	public void setAuthorznOfficer(String authorznOfficer) {
		this.authorznOfficer=authorznOfficer;
	} 
 
	/** 
	* get Authorization Time - [HHMMSS]
	* @return the authorznTime
	*/
	@Field(offset=550, length=6)
	@FixedFormatPattern("HHmmss")
	public Date getAuthorznTime() {
		return authorznTime;
	} 
 
	/** 
	* set Authorization Time - [HHMMSS]
	* @param authorznTime new value for authorznTime
	*/
	public void setAuthorznTime(Date authorznTime) {
		this.authorznTime=authorznTime;
	} 
 
	/** 
	* get Reasons for Authorization
	* @return the authorznReason
	*/
	@Field(offset=556, length=10, paddingChar=' ')
	public String getAuthorznReason() {
		return authorznReason;
	} 
 
	/** 
	* set Reasons for Authorization
	* @param authorznReason new value for authorznReason
	*/
	public void setAuthorznReason(String authorznReason) {
		this.authorznReason=authorznReason;
	} 
 
	/** 
	* get Authorization Status - [AUI/ANC/AUA/AUR]
	* @return the authorznStatus
	*/
	@Field(offset=566, length=6, paddingChar=' ')
	public String getAuthorznStatus() {
		return authorznStatus;
	} 
 
	/** 
	* set Authorization Status - [AUI/ANC/AUA/AUR]
	* @param authorznStatus new value for authorznStatus
	*/
	public void setAuthorznStatus(String authorznStatus) {
		this.authorznStatus=authorznStatus;
	} 
 
	/** 
	* get Computed field - Length of Dynamic Part
	* @return the dynamicPartLen
	*/
	@Field(offset=572, length=3, paddingChar='0', align=Align.RIGHT)
	public Integer getDynamicPartLen() {
		return dynamicPartLen;
	} 
 
	/** 
	* set Computed field - Length of Dynamic Part
	* @param dynamicPartLen new value for dynamicPartLen
	*/
	public void setDynamicPartLen(Integer dynamicPartLen) {
		this.dynamicPartLen=dynamicPartLen;
	} 
 
	/** 
	* get Static Part - Cheque Number (Applicable for Cheque Transactions)
	* @return the staticPartChequeNo
	*/
	@Field(offset=575, length=15, paddingChar=' ')
	public String getStaticPartChequeNo() {
		return staticPartChequeNo;
	} 
 
	/** 
	* set Static Part - Cheque Number (Applicable for Cheque Transactions)
	* @param staticPartChequeNo new value for staticPartChequeNo
	*/
	public void setStaticPartChequeNo(String staticPartChequeNo) {
		this.staticPartChequeNo=staticPartChequeNo;
	} 
 
	/** 
	* get Static Part - ID Type
	* @return the staticPartIdType
	*/
	@Field(offset=590, length=6, paddingChar=' ')
	public String getStaticPartIdType() {
		return staticPartIdType;
	} 
 
	/** 
	* set Static Part - ID Type
	* @param staticPartIdType new value for staticPartIdType
	*/
	public void setStaticPartIdType(String staticPartIdType) {
		this.staticPartIdType=staticPartIdType;
	} 
 
	/** 
	* get Static Part - ID Number
	* @return the staticPartIdNumber
	*/
	@Field(offset=596, length=20, paddingChar=' ')
	public String getStaticPartIdNumber() {
		return staticPartIdNumber;
	} 
 
	/** 
	* set Static Part - ID Number
	* @param staticPartIdNumber new value for staticPartIdNumber
	*/
	public void setStaticPartIdNumber(String staticPartIdNumber) {
		this.staticPartIdNumber=staticPartIdNumber;
	} 
 
	/** 
	* get Static Part -  Print Detail Flag (Y/N) Indicator to say whether a Transaction Print is Required)
	* @return the staticPartPrintDetail
	*/
	@Field(offset=616, length=1, paddingChar=' ')
	public String getStaticPartPrintDetail() {
		return staticPartPrintDetail;
	} 
 
	/** 
	* set Static Part -  Print Detail Flag (Y/N) Indicator to say whether a Transaction Print is Required)
	* @param staticPartPrintDetail new value for staticPartPrintDetail
	*/
	public void setStaticPartPrintDetail(String staticPartPrintDetail) {
		this.staticPartPrintDetail=staticPartPrintDetail;
	} 
 
	/** 
	* get Static Part - Mail Advice Flag (Y/N Indicator to say whether a Mail Advice is to be sent for this Transaction)
	* @return the staticPartMailAdvice
	*/
	@Field(offset=617, length=1, paddingChar=' ')
	public String getStaticPartMailAdvice() {
		return staticPartMailAdvice;
	} 
    
	/** 
	* set Static Part - Mail Advice Flag (Y/N Indicator to say whether a Mail Advice is to be sent for this Transaction)
	* @param staticPartMailAdvice new value for staticPartMailAdvice
	*/
	public void setStaticPartMailAdvice(String staticPartMailAdvice) {
		this.staticPartMailAdvice=staticPartMailAdvice;
	} 
	@Field(offset=618, length=13, paddingChar=' ')
	public String getRsstReference() {
		return rsstReference;
	}

	public void setRsstReference(String rsstReference) {
		this.rsstReference = rsstReference;
	}
	
	/** MARKI Transaction type start 
	
	
	
	/**
	 * @return the RsstReasonCode
	 */
	@Field(offset=631, length=10, paddingChar=' ')
	public String getRsstReasonCode() {
		return rsstReasonCode;
	}

	public void setRsstReasonCode(String rsstReasonCode) {
		this.rsstReasonCode = rsstReasonCode;
	}
	/**
	 * @return the RsstReasonDes
	 */
	@Field(offset=641, length=40, paddingChar=' ')
	public String getRsstReasonDes() {
		return rsstReasonDes;
	}

	public void setRsstReasonDes(String rsstReasonDes) {
		this.rsstReasonDes = rsstReasonDes;
	}
	/**
	 * @return the rsstExpDate
	 */
	@Field(offset=681, length=8)
	@FixedFormatPattern("yyyyMMdd")
	public Date getRsstExpDate() {
		return rsstExpDate;
	}

	public void setRsstExpDate(Date rsstExpDate) {
		this.rsstExpDate = rsstExpDate;
	}
	
	/**
	 * @return the flag
	 */
	@Field(offset=689, length=1,paddingChar=' ')	
	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}
	/**
	 * @return the flag
	 */
	/*@Field(offset=690, length=6,paddingChar=' ')	
	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}*/
	/**
	 * @return the flag
	 */
	@Field(offset=690, length=40,paddingChar=' ')	
	public String getBlckReference() {
		return blckReference;
	}

	public void setBlckReference(String blckReference) {
		this.blckReference = blckReference;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder(super.toString());
		sb.append("|transType="+transType);
		sb.append("|transDate="+transDate);
		sb.append("|valueDate="+valueDate);
		sb.append("|transCrncy="+transCrncy);
		sb.append("|transAmount="+transAmount);
		sb.append("|transAmountSar="+transAmountSar);
		sb.append("|genNarrative="+genNarrative);
		sb.append("|screenNarrative="+screenNarrative);
		sb.append("|debitAcctNo="+debitAcctNo);
		sb.append("|debitAcctCrncy="+debitAcctCrncy);
		sb.append("|debitAmount="+debitAmount);
		sb.append("|debitCrncyRate="+debitCrncyRate);
		sb.append("|debitValueDate="+debitValueDate);
		sb.append("|debitSrfFlag="+debitSrfFlag);
		sb.append("|debitBranch="+debitBranch);
		sb.append("|creditAcctNo="+creditAcctNo);
		sb.append("|creditAcctCrncy="+creditAcctCrncy);
		sb.append("|creditAmount="+creditAmount);
		sb.append("|creditCrncyRate="+creditCrncyRate);
		sb.append("|creditValueDate="+creditValueDate);
		sb.append("|creditSrfFlag="+creditSrfFlag);
		sb.append("|creditBranch="+creditBranch);
		sb.append("|commissionCrncy="+commissionCrncy);
		sb.append("|commissionAmount="+commissionAmount);
		sb.append("|commissionAcct="+commissionAcct);
		sb.append("|chargesCrncy="+chargesCrncy);
		sb.append("|chargesAmount="+chargesAmount);
		sb.append("|chargesAcct="+chargesAcct);
		sb.append("|gtdDealTicket="+gtdDealTicket);
		sb.append("|initTime="+initTime);
		sb.append("|validationOfficer="+validationOfficer);
		sb.append("|validationTime="+validationTime);
		sb.append("|authorznOfficer="+authorznOfficer);
		sb.append("|authorznTime="+authorznTime);
		sb.append("|authorznReason="+authorznReason);
		sb.append("|authorznStatus="+authorznStatus);
		sb.append("|dynamicPartLen="+dynamicPartLen);
		sb.append("|staticPartChequeNo="+staticPartChequeNo);
		sb.append("|staticPartIdType="+staticPartIdType);
		sb.append("|staticPartIdNumber="+staticPartIdNumber);
		sb.append("|staticPartPrintDetail="+staticPartPrintDetail);
		sb.append("|staticPartMailAdvice="+staticPartMailAdvice);
		
		//sb.append("|debitNarrative="+debitNarrative);
		
		
		sb.append("|rsstReference="+rsstReference);
		sb.append("|rsstReasonCode="+rsstReasonCode);
		sb.append("|rsstReasonDes="+rsstReasonDes);
		sb.append("|rsstExpDate="+rsstExpDate);
		
			
		
		return sb.toString();
	}

	
 
}