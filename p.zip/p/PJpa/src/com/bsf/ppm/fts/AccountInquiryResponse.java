package com.bsf.ppm.fts;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.bsf.ipp.FtsParameter;
import com.bsf.ppm.formatting.annotations.Field;
import com.bsf.ppm.formatting.annotations.FixedFormatDecimal;
import com.bsf.ppm.formatting.annotations.FixedFormatPattern;
import com.bsf.ppm.formatting.annotations.Record;
/**
* Class to hold AccountInquiryResponse
* @author ClassGenerator by Zakir 
*/
@Record
public class AccountInquiryResponse {

	/** As in request message */
	private String sourceSystem;
	/** As in request message */
	private String requestFunction;
	/** As in request message */
	private Date serverDate;
	/** As in request message */
	private Date serverTime;
	/** As in request message */
	private String fTSReference;
	/** Oracle Function last called (Populated on Reply) */
	private String ftsTransFunc;
	/** CAMM transaction reference */
	private Integer cammTranNum;
	/** As in request message */
	private Integer noOfBlocks;
	/** As in request message */
	private Integer currBlockNo;
	/** As in request message */
	private Integer noOfItems;
	/** As in request message */
	private String custCode;
	/** As in request message */
	private String accountNumber;
	/** As in request message */
	private String initBranch;
	/** Initiating Officer */
	private String initOfficer;
	/** As in request message */
	private String cardNumber;
	/** CAMM Action Code 5555 on Request - Populated on Reply 0000= Success */
	private String cammActionCode;
	/** As in request message */
	private Date lastUpdDate;
	/** As in request message */
	private Date lastUpdTime;
	/** NOR (Normal) */
	private String tranStatus;
	/** FTS Action Code 6666 on Request - Populated on Reply 0000= Success */
	private String ftsActionCode;
	/** Processing Sequence - seq in Transaction with multiple types of calls to FTS/CAMM */
	private Integer processingSeq;
	/** Length of Detail (Computed) */
	private Integer detailLength;
	/** Account Number left paded with zeros  */
	private String accountNumberLeftPadded;
	/** Account Currency */
	private String accountCurrency;
	/** Product Type Code */
	private String productTypeCode;
	/** Product Type Description */
	private String productTypeDesc;
	/** Client Segment Code */
	private String clientSegmentCode;
	/** Client Segment Description */
	private String clientSegmentDesc;
	/** Account Status Code */
	private String acctStatusCode;
	/** Account Status Description */
	private String acctStatusDesc;
	/** Account Branch */
	private String acctBranch;
	/** Customer Full Name */
	private String custFullName;
	/** Sarraf Card Flag */
	private String sarrafCardFlag;
	/** Language Indicator */
	private String languageIndicator;
	/** Available Balance */
	private Double availableBalance;
	/** Calendar Preference */
	private String calendarPref;
	/** Customer Type */
	private String custType;
	/** Customer Sub-Type */
	private String custSubType;
	/** Customer Type Description */
	private String custTypeDescription;
	/** Relationship Officer Code */
	private String rlnOfficerCode;
	/** Relationship Officer Description */
	private String rlnOfficerDesc;
	/** Profit Center */
	private String profitCenter;
	/** Risk Appreciation Code */
	private String riskApprCode;
	/** Risk Appreciation Description */
	private String riskApprDesc;
	/** Remedial Flag */
	private String remedialFlag;
	/** Deceased Flag */
	private String deceasedFlag;
	/** ID Type */
	private String idType;
	/** ID Number */
	private String idNumber;
	/** ID Ext No. */
	private String idExtNo;
	/** Ledger Balance */
	private Double ledgerBalance;
	/** Funds On Hold */
	private Double fundsOnHold;
	/**  Authorized Overdraft Limit */
	private Double authorizedOdLimit;
	/** Overdraft Limit Expiry Date - [YYYYMMDD] */
	private String odLimitExpDate;
	/** Original Overdraft Limit */
	private Double originalOdLimit;
	/** Restraint Indicator */
	private String restraintIndicator;
	/** Cheque Number */
	private Long chequeNumber;
	/** Cheque Status */
	private String chequeStatus;
	/** Total Overdraft Amount */
	private Double totalOdAmount;
	/** Total Transactions in Progress Amount */
	private Double totalTxnsInProgressAmount;
	/** Total Pledged Amount */
	private Double totalPledgedAmount;
	/** Account Type */
	private String accountType;
	/** ID Expiry Date */
	private String idExpiryDate;
	/** ID Expiry Indicator */
	private String idExpiryIndicator;
	/** ID Expiry Message */
	private String idExpiryMessage;
	/** Freeze Flag Y / N */
	private String freezeFlag;
	/** Previous Status */
	private String previousFlag;
	/** CAMM Internal Key */
	private Long internalKey;
	/** Address of account holder */
	private String address;
	/** D (Dormant), I Inactive or spaces */
	private String dormantFlag;
	/** 
	* get As in request message
	* @return the sourceSystem
	*/
	@Field(offset=1, length=3, paddingChar=' ')
	public String getSourceSystem() {
		return sourceSystem;
	} 
 
	/** 
	* set As in request message
	* @param sourceSystem new value for sourceSystem
	*/
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem=sourceSystem;
	} 
 
	/** 
	* get As in request message
	* @return the requestFunction
	*/
	@Field(offset=4, length=8, paddingChar=' ')
	public String getRequestFunction() {
		return requestFunction;
	} 
 
	/** 
	* set As in request message
	* @param requestFunction new value for requestFunction
	*/
	public void setRequestFunction(String requestFunction) {
		this.requestFunction=requestFunction;
	} 
 
	/** 
	* get As in request message
	* @return the serverDate
	*/
	@Field(offset=12, length=8)
	@FixedFormatPattern("yyyyMMdd")
	public Date getServerDate() {
		return serverDate;
	} 
 
	/** 
	* set As in request message
	* @param serverDate new value for serverDate
	*/
	public void setServerDate(Date serverDate) {
		this.serverDate=serverDate;
	} 
 
	/** 
	* get As in request message
	* @return the serverTime
	*/
	@Field(offset=20, length=6)
	@FixedFormatPattern("HHmmss")
	public Date getServerTime() {
		return serverTime;
	} 
 
	/** 
	* set As in request message
	* @param serverTime new value for serverTime
	*/
	public void setServerTime(Date serverTime) {
		this.serverTime=serverTime;
	} 
 
	/** 
	* get As in request message
	* @return the fTSReference
	*/
	@Field(offset=26, length=10, paddingChar=' ')
	public String getFTSReference() {
		return fTSReference;
	} 
 
	/** 
	* set As in request message
	* @param fTSReference new value for fTSReference
	*/
	public void setFTSReference(String fTSReference) {
		this.fTSReference=fTSReference;
	} 
 
	/** 
	* get Oracle Function last called (Populated on Reply)
	* @return the ftsTransFunc
	*/
	@Field(offset=36, length=10, paddingChar=' ')
	public String getFtsTransFunc() {
		return ftsTransFunc;
	} 
 
	/** 
	* set Oracle Function last called (Populated on Reply)
	* @param ftsTransFunc new value for ftsTransFunc
	*/
	public void setFtsTransFunc(String ftsTransFunc) {
		this.ftsTransFunc=ftsTransFunc;
	} 
 
	/** 
	* get CAMM transaction reference
	* @return the cammTranNum
	*/
	@Field(offset=46, length=6)
	public Integer getCammTranNum() {
		return cammTranNum;
	} 
 
	/** 
	* set CAMM transaction reference
	* @param cammTranNum new value for cammTranNum
	*/
	public void setCammTranNum(Integer cammTranNum) {
		this.cammTranNum=cammTranNum;
	} 
 
	/** 
	* get As in request message
	* @return the noOfBlocks
	*/
	@Field(offset=52, length=3)
	public Integer getNoOfBlocks() {
		return noOfBlocks;
	} 
 
	/** 
	* set As in request message
	* @param noOfBlocks new value for noOfBlocks
	*/
	public void setNoOfBlocks(Integer noOfBlocks) {
		this.noOfBlocks=noOfBlocks;
	} 
 
	/** 
	* get As in request message
	* @return the currBlockNo
	*/
	@Field(offset=55, length=3)
	public Integer getCurrBlockNo() {
		return currBlockNo;
	} 
 
	/** 
	* set As in request message
	* @param currBlockNo new value for currBlockNo
	*/
	public void setCurrBlockNo(Integer currBlockNo) {
		this.currBlockNo=currBlockNo;
	} 
 
	/** 
	* get As in request message
	* @return the noOfItems
	*/
	@Field(offset=58, length=3)
	public Integer getNoOfItems() {
		return noOfItems;
	} 
 
	/** 
	* set As in request message
	* @param noOfItems new value for noOfItems
	*/
	public void setNoOfItems(Integer noOfItems) {
		this.noOfItems=noOfItems;
	} 
 
	/** 
	* get As in request message
	* @return the custCode
	*/
	@Field(offset=61, length=10)
	public String getCustCode() {
		return custCode;
	} 
 
	/** 
	* set As in request message
	* @param custCode new value for custCode
	*/
	public void setCustCode(String custCode) {
		this.custCode=custCode;
	} 
 
	/** 
	* get As in request message
	* @return the accountNumber
	*/
	@Field(offset=71, length=20, paddingChar=' ')
	public String getAccountNumber() {
		return accountNumber;
	} 
 
	/** 
	* set As in request message
	* @param accountNumber new value for accountNumber
	*/
	public void setAccountNumber(String accountNumber) {
		this.accountNumber=accountNumber;
	} 
 
	/** 
	* get As in request message
	* @return the initBranch
	*/
	@Field(offset=91, length=6, paddingChar=' ')
	public String getInitBranch() {
		return initBranch;
	} 
 
	/** 
	* set As in request message
	* @param initBranch new value for initBranch
	*/
	public void setInitBranch(String initBranch) {
		this.initBranch=initBranch;
	} 
 
	/** 
	* get Initiating Officer
	* @return the initOfficer
	*/
	@Field(offset=97, length=9, paddingChar=' ')
	public String getInitOfficer() {
		return initOfficer;
	} 
 
	/** 
	* set Initiating Officer
	* @param initOfficer new value for initOfficer
	*/
	public void setInitOfficer(String initOfficer) {
		this.initOfficer=initOfficer;
	} 
 
	/** 
	* get As in request message
	* @return the cardNumber
	*/
	@Field(offset=106, length=23, paddingChar=' ')
	public String getCardNumber() {
		return cardNumber;
	} 
 
	/** 
	* set As in request message
	* @param cardNumber new value for cardNumber
	*/
	public void setCardNumber(String cardNumber) {
		this.cardNumber=cardNumber;
	} 
 
	/** 
	* get CAMM Action Code 5555 on Request - Populated on Reply 0000= Success
	* @return the cammActionCode
	*/
	@Field(offset=129, length=4)
	public String getCammActionCode() {
		return cammActionCode;
	} 
 
	/** 
	* set CAMM Action Code 5555 on Request - Populated on Reply 0000= Success
	* @param cammActionCode new value for cammActionCode
	*/
	public void setCammActionCode(String cammActionCode) {
		this.cammActionCode=cammActionCode;
	} 
 
	/** 
	* get As in request message
	* @return the lastUpdDate
	*/
	@Field(offset=133, length=8)
	@FixedFormatPattern("yyyyMMdd")
	public Date getLastUpdDate() {
		return lastUpdDate;
	} 
 
	/** 
	* set As in request message
	* @param lastUpdDate new value for lastUpdDate
	*/
	public void setLastUpdDate(Date lastUpdDate) {
		this.lastUpdDate=lastUpdDate;
	} 
 
	/** 
	* get As in request message
	* @return the lastUpdTime
	*/
	@Field(offset=141, length=6)
	@FixedFormatPattern("HHmmss")
	public Date getLastUpdTime() {
		return lastUpdTime;
	} 
 
	/** 
	* set As in request message
	* @param lastUpdTime new value for lastUpdTime
	*/
	public void setLastUpdTime(Date lastUpdTime) {
		this.lastUpdTime=lastUpdTime;
	} 
 
	/** 
	* get NOR (Normal)
	* @return the tranStatus
	*/
	@Field(offset=147, length=3, paddingChar=' ')
	public String getTranStatus() {
		return tranStatus;
	} 
 
	/** 
	* set NOR (Normal)
	* @param tranStatus new value for tranStatus
	*/
	public void setTranStatus(String tranStatus) {
		this.tranStatus=tranStatus;
	} 
 
	/** 
	* get FTS Action Code 6666 on Request - Populated on Reply 0000= Success
	* @return the ftsActionCode
	*/
	@Field(offset=150, length=4)
	public String getFtsActionCode() {
		return ftsActionCode;
	} 
 
	/** 
	* set FTS Action Code 6666 on Request - Populated on Reply 0000= Success
	* @param ftsActionCode new value for ftsActionCode
	*/
	public void setFtsActionCode(String ftsActionCode) {
		this.ftsActionCode=ftsActionCode;
	} 
 
	/** 
	* get Processing Sequence - seq in Transaction with multiple types of calls to FTS/CAMM
	* @return the processingSeq
	*/
	@Field(offset=154, length=3)
	public Integer getProcessingSeq() {
		return processingSeq;
	} 
 
	/** 
	* set Processing Sequence - seq in Transaction with multiple types of calls to FTS/CAMM
	* @param processingSeq new value for processingSeq
	*/
	public void setProcessingSeq(Integer processingSeq) {
		this.processingSeq=processingSeq;
	} 
 
	/** 
	* get Length of Detail (Computed)
	* @return the detailLength
	*/
	@Field(offset=157, length=4)
	public Integer getDetailLength() {
		return detailLength;
	} 
 
	/** 
	* set Length of Detail (Computed)
	* @param detailLength new value for detailLength
	*/
	public void setDetailLength(Integer detailLength) {
		this.detailLength=detailLength;
	} 
 
	/** 
	* get Account Number left paded with zeros 
	* @return the accountNumber
	*/
	@Field(offset=161, length=11, paddingChar=' ')
	public String getAccountNumberLeftPadded() {
		return accountNumberLeftPadded;
	} 
 
	/** 
	* set Account Number left paded with zeros 
	* @param accountNumber new value for accountNumber
	*/
	public void setAccountNumberLeftPadded(String accountNumberLeftPadded) {
		this.accountNumberLeftPadded=accountNumberLeftPadded;
	} 
 
	/** 
	* get Account Currency
	* @return the accountCurrency
	*/
	@Field(offset=172, length=3, paddingChar=' ')
	public String getAccountCurrency() {
		return accountCurrency;
	} 
 
	/** 
	* set Account Currency
	* @param accountCurrency new value for accountCurrency
	*/
	public void setAccountCurrency(String accountCurrency) {
		this.accountCurrency=accountCurrency;
	} 
 
	/** 
	* get Product Type Code
	* @return the productTypeCode
	*/
	@Field(offset=175, length=6, paddingChar=' ')
	public String getProductTypeCode() {
		return productTypeCode;
	} 
 
	/** 
	* set Product Type Code
	* @param productTypeCode new value for productTypeCode
	*/
	public void setProductTypeCode(String productTypeCode) {
		this.productTypeCode=productTypeCode;
	} 
 
	/** 
	* get Product Type Description
	* @return the productTypeDesc
	*/
	@Field(offset=181, length=40, paddingChar=' ')
	public String getProductTypeDesc() {
		return productTypeDesc;
	} 
 
	/** 
	* set Product Type Description
	* @param productTypeDesc new value for productTypeDesc
	*/
	public void setProductTypeDesc(String productTypeDesc) {
		this.productTypeDesc=productTypeDesc;
	} 
 
	/** 
	* get Client Segment Code
	* @return the clientSegmentCode
	*/
	@Field(offset=221, length=6, paddingChar=' ')
	public String getClientSegmentCode() {
		return clientSegmentCode;
	} 
 
	/** 
	* set Client Segment Code
	* @param clientSegmentCode new value for clientSegmentCode
	*/
	public void setClientSegmentCode(String clientSegmentCode) {
		this.clientSegmentCode=clientSegmentCode;
	} 
 
	/** 
	* get Client Segment Description
	* @return the clientSegmentDesc
	*/
	@Field(offset=227, length=20, paddingChar=' ')
	public String getClientSegmentDesc() {
		return clientSegmentDesc;
	} 
 
	/** 
	* set Client Segment Description
	* @param clientSegmentDesc new value for clientSegmentDesc
	*/
	public void setClientSegmentDesc(String clientSegmentDesc) {
		this.clientSegmentDesc=clientSegmentDesc;
	} 
 
	/** 
	* get Account Status Code
	* @return the acctStatusCode
	*/
	@Field(offset=247, length=6, paddingChar=' ')
	public String getAcctStatusCode() {
		return acctStatusCode;
	} 
 
	/** 
	* set Account Status Code
	* @param acctStatusCode new value for acctStatusCode
	*/
	public void setAcctStatusCode(String acctStatusCode) {
		this.acctStatusCode=acctStatusCode;
	} 
 
	/** 
	* get Account Status Description
	* @return the acctStatusDesc
	*/
	@Field(offset=253, length=20, paddingChar=' ')
	public String getAcctStatusDesc() {
		return acctStatusDesc;
	} 
 
	/** 
	* set Account Status Description
	* @param acctStatusDesc new value for acctStatusDesc
	*/
	public void setAcctStatusDesc(String acctStatusDesc) {
		this.acctStatusDesc=acctStatusDesc;
	} 
 
	/** 
	* get Account Branch
	* @return the acctBranch
	*/
	@Field(offset=273, length=6, paddingChar=' ')
	public String getAcctBranch() {
		return acctBranch;
	} 
 
	/** 
	* set Account Branch
	* @param acctBranch new value for acctBranch
	*/
	public void setAcctBranch(String acctBranch) {
		this.acctBranch=acctBranch;
	} 
 
	/** 
	* get Customer Full Name
	* @return the custFullName
	*/
	@Field(offset=279, length=40, paddingChar=' ')
	public String getCustFullName() {
		return custFullName;
	} 
 
	/** 
	* set Customer Full Name
	* @param custFullName new value for custFullName
	*/
	public void setCustFullName(String custFullName) {
		this.custFullName=custFullName;
	} 
 
	/** 
	* get Sarraf Card Flag
	* @return the sarrafCardFlag
	*/
	@Field(offset=319, length=1, paddingChar=' ')
	public String getSarrafCardFlag() {
		return sarrafCardFlag;
	} 
 
	/** 
	* set Sarraf Card Flag
	* @param sarrafCardFlag new value for sarrafCardFlag
	*/
	public void setSarrafCardFlag(String sarrafCardFlag) {
		this.sarrafCardFlag=sarrafCardFlag;
	} 
 
	/** 
	* get Language Indicator
	* @return the languageIndicator
	*/
	@Field(offset=320, length=1, paddingChar=' ')
	public String getLanguageIndicator() {
		return languageIndicator;
	} 
 
	/** 
	* set Language Indicator
	* @param languageIndicator new value for languageIndicator
	*/
	public void setLanguageIndicator(String languageIndicator) {
		this.languageIndicator=languageIndicator;
	} 
 
	/** 
	* get Available Balance
	* @return the availableBalance
	*/
	@Field(offset=321, length=16)
	@FixedFormatDecimal(useDecimalDelimiter=true)
	public Double getAvailableBalance() {
		return availableBalance;
	} 
 
	/** 
	* set Available Balance
	* @param availableBalance new value for availableBalance
	*/
	public void setAvailableBalance(Double availableBalance) {
		this.availableBalance=availableBalance;
	} 
 
	/** 
	* get Calendar Preference
	* @return the calendarPref
	*/
	@Field(offset=337, length=6, paddingChar=' ')
	public String getCalendarPref() {
		return calendarPref;
	} 
 
	/** 
	* set Calendar Preference
	* @param calendarPref new value for calendarPref
	*/
	public void setCalendarPref(String calendarPref) {
		this.calendarPref=calendarPref;
	} 
 
	/** 
	* get Customer Type
	* @return the custType
	*/
	@Field(offset=343, length=6, paddingChar=' ')
	public String getCustType() {
		return custType;
	} 
 
	/** 
	* set Customer Type
	* @param custType new value for custType
	*/
	public void setCustType(String custType) {
		this.custType=custType;
	} 
 
	/** 
	* get Customer Sub-Type
	* @return the custSubType
	*/
	@Field(offset=349, length=6, paddingChar=' ')
	public String getCustSubType() {
		return custSubType;
	} 
 
	/** 
	* set Customer Sub-Type
	* @param custSubType new value for custSubType
	*/
	public void setCustSubType(String custSubType) {
		this.custSubType=custSubType;
	} 
 
	/** 
	* get Customer Type Description
	* @return the custTypeDescription
	*/
	@Field(offset=355, length=35, paddingChar=' ')
	public String getCustTypeDescription() {
		return custTypeDescription;
	} 
 
	/** 
	* set Customer Type Description
	* @param custTypeDescription new value for custTypeDescription
	*/
	public void setCustTypeDescription(String custTypeDescription) {
		this.custTypeDescription=custTypeDescription;
	} 
 
	/** 
	* get Relationship Officer Code
	* @return the rlnOfficerCode
	*/
	@Field(offset=390, length=6, paddingChar=' ')
	public String getRlnOfficerCode() {
		return rlnOfficerCode;
	} 
 
	/** 
	* set Relationship Officer Code
	* @param rlnOfficerCode new value for rlnOfficerCode
	*/
	public void setRlnOfficerCode(String rlnOfficerCode) {
		this.rlnOfficerCode=rlnOfficerCode;
	} 
 
	/** 
	* get Relationship Officer Description
	* @return the rlnOfficerDesc
	*/
	@Field(offset=396, length=40, paddingChar=' ')
	public String getRlnOfficerDesc() {
		return rlnOfficerDesc;
	} 
 
	/** 
	* set Relationship Officer Description
	* @param rlnOfficerDesc new value for rlnOfficerDesc
	*/
	public void setRlnOfficerDesc(String rlnOfficerDesc) {
		this.rlnOfficerDesc=rlnOfficerDesc;
	} 
 
	/** 
	* get Profit Center
	* @return the profitCenter
	*/
	@Field(offset=436, length=6, paddingChar=' ')
	public String getProfitCenter() {
		return profitCenter;
	} 
 
	/** 
	* set Profit Center
	* @param profitCenter new value for profitCenter
	*/
	public void setProfitCenter(String profitCenter) {
		this.profitCenter=profitCenter;
	} 
 
	/** 
	* get Risk Appreciation Code
	* @return the riskApprCode
	*/
	@Field(offset=442, length=6, paddingChar=' ')
	public String getRiskApprCode() {
		return riskApprCode;
	} 
 
	/** 
	* set Risk Appreciation Code
	* @param riskApprCode new value for riskApprCode
	*/
	public void setRiskApprCode(String riskApprCode) {
		this.riskApprCode=riskApprCode;
	} 
 
	/** 
	* get Risk Appreciation Description
	* @return the riskApprDesc
	*/
	@Field(offset=448, length=35, paddingChar=' ')
	public String getRiskApprDesc() {
		return riskApprDesc;
	} 
 
	/** 
	* set Risk Appreciation Description
	* @param riskApprDesc new value for riskApprDesc
	*/
	public void setRiskApprDesc(String riskApprDesc) {
		this.riskApprDesc=riskApprDesc;
	} 
 
	/** 
	* get Remedial Flag
	* @return the remedialFlag
	*/
	@Field(offset=483, length=1, paddingChar=' ')
	public String getRemedialFlag() {
		return remedialFlag;
	} 
 
	/** 
	* set Remedial Flag
	* @param remedialFlag new value for remedialFlag
	*/
	public void setRemedialFlag(String remedialFlag) {
		this.remedialFlag=remedialFlag;
	} 
 
	/** 
	* get Deceased Flag
	* @return the deceasedFlag
	*/
	@Field(offset=484, length=1, paddingChar=' ')
	public String getDeceasedFlag() {
		return deceasedFlag;
	} 
 
	/** 
	* set Deceased Flag
	* @param deceasedFlag new value for deceasedFlag
	*/
	public void setDeceasedFlag(String deceasedFlag) {
		this.deceasedFlag=deceasedFlag;
	} 
 
	/** 
	* get ID Type
	* @return the idType
	*/
	@Field(offset=485, length=6, paddingChar=' ')
	public String getIdType() {
		return idType;
	} 
 
	/** 
	* set ID Type
	* @param idType new value for idType
	*/
	public void setIdType(String idType) {
		this.idType=idType;
	} 
 
	/** 
	* get ID Number
	* @return the idNumber
	*/
	@Field(offset=491, length=15, paddingChar=' ')
	public String getIdNumber() {
		return idNumber;
	} 
 
	/** 
	* set ID Number
	* @param idNumber new value for idNumber
	*/
	public void setIdNumber(String idNumber) {
		this.idNumber=idNumber;
	} 
 
	/** 
	* get ID Ext No.
	* @return the idExtNo
	*/
	@Field(offset=506, length=3, paddingChar=' ')
	public String getIdExtNo() {
		return idExtNo;
	} 
 
	/** 
	* set ID Ext No.
	* @param idExtNo new value for idExtNo
	*/
	public void setIdExtNo(String idExtNo) {
		this.idExtNo=idExtNo;
	} 
 
	/** 
	* get Ledger Balance
	* @return the ledgerBalance
	*/
	@Field(offset=509, length=16)
	@FixedFormatDecimal(useDecimalDelimiter=true)
	public Double getLedgerBalance() {
		return ledgerBalance;
	} 
 
	/** 
	* set Ledger Balance
	* @param ledgerBalance new value for ledgerBalance
	*/
	public void setLedgerBalance(Double ledgerBalance) {
		this.ledgerBalance=ledgerBalance;
	} 
 
	/** 
	* get Funds On Hold
	* @return the fundsOnHold
	*/
	@Field(offset=525, length=16)
	@FixedFormatDecimal(useDecimalDelimiter=true)
	public Double getFundsOnHold() {
		return fundsOnHold;
	} 
 
	/** 
	* set Funds On Hold
	* @param fundsOnHold new value for fundsOnHold
	*/
	public void setFundsOnHold(Double fundsOnHold) {
		this.fundsOnHold=fundsOnHold;
	} 
 
	/** 
	* get  Authorized Overdraft Limit
	* @return the authorizedOdLimit
	*/
	@Field(offset=541, length=16)
	@FixedFormatDecimal(useDecimalDelimiter=true)
	public Double getAuthorizedOdLimit() {
		return authorizedOdLimit;
	} 
 
	/** 
	* set  Authorized Overdraft Limit
	* @param authorizedOdLimit new value for authorizedOdLimit
	*/
	public void setAuthorizedOdLimit(Double authorizedOdLimit) {
		this.authorizedOdLimit=authorizedOdLimit;
	} 
 
	/** 
	* get Overdraft Limit Expiry Date - [YYYYMMDD].This can be zeros or spaces or both. Be Cautious when formatting to Date
	* @return the odLimitExpDate
	*/
	@Field(offset=557, length=8)
	@FixedFormatPattern("yyyyMMdd")
	public String getOdLimitExpDate() {
		return odLimitExpDate;
	} 
 
	/** 
	* set Overdraft Limit Expiry Date - [YYYYMMDD].
	* @param odLimitExpDate new value for odLimitExpDate
	*/
	public void setOdLimitExpDate(String odLimitExpDate) {
		this.odLimitExpDate=odLimitExpDate;
	} 
 
	/** 
	* get Original Overdraft Limit
	* @return the originalOdLimit
	*/
	@Field(offset=565, length=16)
	@FixedFormatDecimal(useDecimalDelimiter=true)	
	public Double getOriginalOdLimit() {
		return originalOdLimit;
	} 
 
	/** 
	* set Original Overdraft Limit
	* @param originalOdLimit new value for originalOdLimit
	*/
	public void setOriginalOdLimit(Double originalOdLimit) {
		this.originalOdLimit=originalOdLimit;
	} 
 
	/** 
	* get Restraint Indicator
	* @return the restraintIndicator
	*/
	@Field(offset=581, length=1, paddingChar=' ')
	public String getRestraintIndicator() {
		return restraintIndicator;
	} 
 
	/** 
	* set Restraint Indicator
	* @param restraintIndicator new value for restraintIndicator
	*/
	public void setRestraintIndicator(String restraintIndicator) {
		this.restraintIndicator=restraintIndicator;
	} 
 
	/** 
	* get Cheque Number
	* @return the chequeNumber
	*/
	@Field(offset=582, length=13)
	public Long getChequeNumber() {
		return chequeNumber;
	} 
 
	/** 
	* set Cheque Number
	* @param chequeNumber new value for chequeNumber
	*/
	public void setChequeNumber(Long chequeNumber) {
		this.chequeNumber=chequeNumber;
	} 
 
	/** 
	* get Cheque Status
	* @return the chequeStatus
	*/
	@Field(offset=595, length=1, paddingChar=' ')
	public String getChequeStatus() {
		return chequeStatus;
	} 
 
	/** 
	* set Cheque Status
	* @param chequeStatus new value for chequeStatus
	*/
	public void setChequeStatus(String chequeStatus) {
		this.chequeStatus=chequeStatus;
	} 
 
	/** 
	* get Total Overdraft Amount
	* @return the totalOdAmount
	*/
	@Field(offset=596, length=16)
	@FixedFormatDecimal(useDecimalDelimiter=true)
	public Double getTotalOdAmount() {
		return totalOdAmount;
	} 
 
	/** 
	* set Total Overdraft Amount
	* @param totalOdAmount new value for totalOdAmount
	*/
	public void setTotalOdAmount(Double totalOdAmount) {
		this.totalOdAmount=totalOdAmount;
	} 
 
	/** 
	* get Total Transactions in Progress Amount
	* @return the totalTxnsInProgressAmount
	*/
	@Field(offset=612, length=16)
	@FixedFormatDecimal(useDecimalDelimiter=true)
	public Double getTotalTxnsInProgressAmount() {
		return totalTxnsInProgressAmount;
	} 
 
	/** 
	* set Total Transactions in Progress Amount
	* @param totalTxnsInProgressAmount new value for totalTxnsInProgressAmount
	*/
	public void setTotalTxnsInProgressAmount(Double totalTxnsInProgressAmount) {
		this.totalTxnsInProgressAmount=totalTxnsInProgressAmount;
	} 
 
	/** 
	* get Total Pledged Amount
	* @return the totalPledgedAmount
	*/
	@Field(offset=628, length=16)
	@FixedFormatDecimal(useDecimalDelimiter=true)
	public Double getTotalPledgedAmount() {
		return totalPledgedAmount;
	} 
 
	/** 
	* set Total Pledged Amount
	* @param totalPledgedAmount new value for totalPledgedAmount
	*/
	public void setTotalPledgedAmount(Double totalPledgedAmount) {
		this.totalPledgedAmount=totalPledgedAmount;
	} 
 
	/** 
	* get Account Type
	* @return the accountType
	*/
	@Field(offset=644, length=4, paddingChar=' ')
	public String getAccountType() {
		return accountType;
	} 
 
	/** 
	* set Account Type
	* @param accountType new value for accountType
	*/
	public void setAccountType(String accountType) {
		this.accountType=accountType;
	} 
 
	/** 
	* get ID Expiry Date. This can be zeros or spaces or both. Be Cautious when formatting to Date
	* @return the idExpiryDate
	*/
	@Field(offset=648, length=8)
	@FixedFormatPattern("yyyyMMdd")
	public String getIdExpiryDate() {
		return idExpiryDate;
	} 
 
	/** 
	* set ID Expiry Date
	* @param idExpiryDate new value for idExpiryDate
	*/
	public void setIdExpiryDate(String idExpiryDate) {
		this.idExpiryDate=idExpiryDate;
	} 
 
	/** 
	* get ID Expiry Indicator
	* @return the idExpiryIndicator
	*/
	@Field(offset=656, length=1, paddingChar=' ')
	public String getIdExpiryIndicator() {
		return idExpiryIndicator;
	} 
 
	/** 
	* set ID Expiry Indicator
	* @param idExpiryIndicator new value for idExpiryIndicator
	*/
	public void setIdExpiryIndicator(String idExpiryIndicator) {
		this.idExpiryIndicator=idExpiryIndicator;
	} 
 
	/** 
	* get ID Expiry Message
	* @return the idExpiryMessage
	*/
	@Field(offset=657, length=40, paddingChar=' ')
	public String getIdExpiryMessage() {
		return idExpiryMessage;
	} 
 
	/** 
	* set ID Expiry Message
	* @param idExpiryMessage new value for idExpiryMessage
	*/
	public void setIdExpiryMessage(String idExpiryMessage) {
		this.idExpiryMessage=idExpiryMessage;
	} 
 
	/** 
	* get Freeze Flag Y / N
	* @return the freezeFlag
	*/
	@Field(offset=697, length=1, paddingChar=' ')
	public String getFreezeFlag() {
		return freezeFlag;
	} 
 
	/** 
	* set Freeze Flag Y / N
	* @param freezeFlag new value for freezeFlag
	*/
	public void setFreezeFlag(String freezeFlag) {
		this.freezeFlag=freezeFlag;
	} 
 
	/** 
	* get Previous Status
	* @return the previousFlag
	*/
	@Field(offset=698, length=6, paddingChar=' ')
	public String getPreviousFlag() {
		return previousFlag;
	} 
 
	/** 
	* set Previous Status
	* @param previousFlag new value for previousFlag
	*/
	public void setPreviousFlag(String previousFlag) {
		this.previousFlag=previousFlag;
	} 
 
	/** 
	* get CAMM Internal Key
	* @return the internalKey
	*/
	@Field(offset=704, length=10)
	public Long getInternalKey() {
		return internalKey;
	} 
 
	/** 
	* set CAMM Internal Key
	* @param internalKey new value for internalKey
	*/
	public void setInternalKey(Long internalKey) {
		this.internalKey=internalKey;
	} 
 
	/** 
	* get Address of account holder
	* @return the address
	*/
	@Field(offset=714, length=50, paddingChar=' ')
	public String getAddress() {
		return address;
	} 
 
	/** 
	* set Address of account holder
	* @param address new value for address
	*/
	public void setAddress(String address) {
		this.address=address;
	} 
 
	/** 
	* get D (Dormant), I Inactive or spaces
	* @return the dormantFlag
	*/
	@Field(offset=764, length=1, paddingChar=' ')
	public String getDormantFlag() {
		return dormantFlag;
	} 
 
	/** 
	* set D (Dormant), I Inactive or spaces
	* @param dormantFlag new value for dormantFlag
	*/
	public void setDormantFlag(String dormantFlag) {
		this.dormantFlag=dormantFlag;
	} 
 
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("|sourceSystem="+sourceSystem);
		sb.append("|requestFunction="+requestFunction);
		sb.append("|serverDate="+serverDate);
		sb.append("|serverTime="+serverTime);
		sb.append("|fTSReference="+fTSReference);
		sb.append("|ftsTransFunc="+ftsTransFunc);
		sb.append("|cammTranNum="+cammTranNum);
		sb.append("|noOfBlocks="+noOfBlocks);
		sb.append("|currBlockNo="+currBlockNo);
		sb.append("|noOfItems="+noOfItems);
		sb.append("|custCode="+custCode);
		sb.append("|accountNumber="+accountNumber);
		sb.append("|initBranch="+initBranch);
		sb.append("|initOfficer="+initOfficer);
		sb.append("|cardNumber="+cardNumber);
		sb.append("|cammActionCode="+cammActionCode);
		sb.append("|lastUpdDate="+lastUpdDate);
		sb.append("|lastUpdTime="+lastUpdTime);
		sb.append("|tranStatus="+tranStatus);
		sb.append("|ftsActionCode="+ftsActionCode);
		sb.append("|processingSeq="+processingSeq);
		sb.append("|detailLength="+detailLength);
		sb.append("|accountNumber="+accountNumber);
		sb.append("|accountCurrency="+accountCurrency);
		sb.append("|productTypeCode="+productTypeCode);
		sb.append("|productTypeDesc="+productTypeDesc);
		sb.append("|clientSegmentCode="+clientSegmentCode);
		sb.append("|clientSegmentDesc="+clientSegmentDesc);
		sb.append("|acctStatusCode="+acctStatusCode);
		sb.append("|acctStatusDesc="+acctStatusDesc);
		sb.append("|acctBranch="+acctBranch);
		sb.append("|custFullName="+custFullName);
		sb.append("|sarrafCardFlag="+sarrafCardFlag);
		sb.append("|languageIndicator="+languageIndicator);
		sb.append("|availableBalance="+availableBalance);
		sb.append("|calendarPref="+calendarPref);
		sb.append("|custType="+custType);
		sb.append("|custSubType="+custSubType);
		sb.append("|custTypeDescription="+custTypeDescription);
		sb.append("|rlnOfficerCode="+rlnOfficerCode);
		sb.append("|rlnOfficerDesc="+rlnOfficerDesc);
		sb.append("|profitCenter="+profitCenter);
		sb.append("|riskApprCode="+riskApprCode);
		sb.append("|riskApprDesc="+riskApprDesc);
		sb.append("|remedialFlag="+remedialFlag);
		sb.append("|deceasedFlag="+deceasedFlag);
		sb.append("|idType="+idType);
		sb.append("|idNumber="+idNumber);
		sb.append("|idExtNo="+idExtNo);
		sb.append("|ledgerBalance="+ledgerBalance);
		sb.append("|fundsOnHold="+fundsOnHold);
		sb.append("|authorizedOdLimit="+authorizedOdLimit);
		sb.append("|odLimitExpDate="+odLimitExpDate);
		sb.append("|originalOdLimit="+originalOdLimit);
		sb.append("|restraintIndicator="+restraintIndicator);
		sb.append("|chequeNumber="+chequeNumber);
		sb.append("|chequeStatus="+chequeStatus);
		sb.append("|totalOdAmount="+totalOdAmount);
		sb.append("|totalTxnsInProgressAmount="+totalTxnsInProgressAmount);
		sb.append("|totalPledgedAmount="+totalPledgedAmount);
		sb.append("|accountType="+accountType);
		sb.append("|idExpiryDate="+idExpiryDate);
		sb.append("|idExpiryIndicator="+idExpiryIndicator);
		sb.append("|idExpiryMessage="+idExpiryMessage);
		sb.append("|freezeFlag="+freezeFlag);
		sb.append("|previousFlag="+previousFlag);
		sb.append("|internalKey="+internalKey);
		sb.append("|address="+address);
		sb.append("|dormantFlag="+dormantFlag);

		return sb.toString();
	} 
 
	public List<FtsParameter> toParamList(){
		ArrayList<FtsParameter> list=new ArrayList<FtsParameter>();
		list.add(new FtsParameter("sourceSystem", sourceSystem));
		list.add(new FtsParameter("requestFunction",requestFunction));
		list.add(new FtsParameter("serverDate",serverDate));
		list.add(new FtsParameter("serverTime",serverTime));
		list.add(new FtsParameter("fTSReference",fTSReference));
		list.add(new FtsParameter("ftsTransFunc",ftsTransFunc));
		list.add(new FtsParameter("cammTranNum",cammTranNum));
		list.add(new FtsParameter("noOfBlocks",noOfBlocks));
		list.add(new FtsParameter("currBlockNo",currBlockNo));
		list.add(new FtsParameter("noOfItems",noOfItems));
		list.add(new FtsParameter("custCode",custCode));
		list.add(new FtsParameter("accountNumber",accountNumber));
		list.add(new FtsParameter("initBranch",initBranch));
		list.add(new FtsParameter("initOfficer",initOfficer));
		list.add(new FtsParameter("cardNumber",cardNumber));
		list.add(new FtsParameter("cammActionCode",cammActionCode));
		list.add(new FtsParameter("lastUpdDate",lastUpdDate));
		list.add(new FtsParameter("lastUpdTime",lastUpdTime));
		list.add(new FtsParameter("tranStatus",tranStatus));
		list.add(new FtsParameter("ftsActionCode",ftsActionCode));
		list.add(new FtsParameter("processingSeq",processingSeq));
		list.add(new FtsParameter("detailLength",detailLength));
		list.add(new FtsParameter("accountNumber",accountNumber));
		list.add(new FtsParameter("accountCurrency",accountCurrency));
		list.add(new FtsParameter("productTypeCode",productTypeCode));
		list.add(new FtsParameter("productTypeDesc",productTypeDesc));
		list.add(new FtsParameter("clientSegmentCode",clientSegmentCode));
		list.add(new FtsParameter("clientSegmentDesc",clientSegmentDesc));
		list.add(new FtsParameter("acctStatusCode",acctStatusCode));
		list.add(new FtsParameter("acctStatusDesc",acctStatusDesc));
		list.add(new FtsParameter("acctBranch",acctBranch));
		list.add(new FtsParameter("custFullName",custFullName));
		list.add(new FtsParameter("sarrafCardFlag",sarrafCardFlag));
		list.add(new FtsParameter("languageIndicator",languageIndicator));
		list.add(new FtsParameter("availableBalance",availableBalance));
		list.add(new FtsParameter("calendarPref",calendarPref));
		list.add(new FtsParameter("custType",custType));
		list.add(new FtsParameter("custSubType",custSubType));
		list.add(new FtsParameter("custTypeDescription",custTypeDescription));
		list.add(new FtsParameter("rlnOfficerCode",rlnOfficerCode));
		list.add(new FtsParameter("rlnOfficerDesc",rlnOfficerDesc));
		list.add(new FtsParameter("profitCenter",profitCenter));
		list.add(new FtsParameter("riskApprCode",riskApprCode));
		list.add(new FtsParameter("riskApprDesc",riskApprDesc));
		list.add(new FtsParameter("remedialFlag",remedialFlag));
		list.add(new FtsParameter("deceasedFlag",deceasedFlag));
		list.add(new FtsParameter("idType",idType));
		list.add(new FtsParameter("idNumber",idNumber));
		list.add(new FtsParameter("idExtNo",idExtNo));
		list.add(new FtsParameter("ledgerBalance",ledgerBalance));
		list.add(new FtsParameter("fundsOnHold",fundsOnHold));
		list.add(new FtsParameter("authorizedOdLimit",authorizedOdLimit));
		list.add(new FtsParameter("odLimitExpDate",odLimitExpDate));
		list.add(new FtsParameter("originalOdLimit",originalOdLimit));
		list.add(new FtsParameter("restraintIndicator",restraintIndicator));
		list.add(new FtsParameter("chequeNumber",chequeNumber));
		list.add(new FtsParameter("chequeStatus",chequeStatus));
		list.add(new FtsParameter("totalOdAmount",totalOdAmount));
		list.add(new FtsParameter("totalTxnsInProgressAmount",totalTxnsInProgressAmount));
		list.add(new FtsParameter("totalPledgedAmount",totalPledgedAmount));
		list.add(new FtsParameter("accountType",accountType));
		list.add(new FtsParameter("idExpiryDate",idExpiryDate));
		list.add(new FtsParameter("idExpiryIndicator",idExpiryIndicator));
		list.add(new FtsParameter("idExpiryMessage",idExpiryMessage));
		list.add(new FtsParameter("freezeFlag",freezeFlag));
		list.add(new FtsParameter("previousFlag",previousFlag));
		list.add(new FtsParameter("internalKey",internalKey));
		list.add(new FtsParameter("address",address));
		list.add(new FtsParameter("dormantFlag",dormantFlag));

		
		return list;
		
	}
}