package com.bsf.ppm.fts;

import com.bsf.ppm.formatting.exception.FixedFormatException;
import com.bsf.ppm.formatting.format.FixedFormatManager;
import com.bsf.ppm.formatting.format.FixedFormatter;
import com.bsf.ppm.formatting.format.FormatInstructions;
import com.bsf.ppm.formatting.format.impl.FixedFormatManagerImpl;

/**
 * Formatter for {@link FTSHeader} data
 *
 */
public class FTSHeaderFormatter implements FixedFormatter<FTSHeader> {

	@Override
	public String format(FTSHeader value, FormatInstructions instructions, String precision)
			throws FixedFormatException {
		FixedFormatManager fixedFormatManager = new FixedFormatManagerImpl();
		return fixedFormatManager.export(value);
	}

	@Override
	public FTSHeader parse(String value, FormatInstructions instructions)
			throws FixedFormatException {
		FixedFormatManager fixedFormatManager = new FixedFormatManagerImpl();
		return fixedFormatManager.load(FTSHeader.class, value);
	}

}
