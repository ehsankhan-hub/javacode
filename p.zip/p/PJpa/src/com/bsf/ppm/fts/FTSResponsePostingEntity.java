package com.bsf.ppm.fts;

import com.bsf.ppm.formatting.annotations.Align;
import com.bsf.ppm.formatting.annotations.Field;
import com.bsf.ppm.formatting.annotations.Record;

@Record
public class FTSResponsePostingEntity extends FTSHeaderEntity{
private String debitAcctNumber;

/** 
* get Debit Account Left Padded with Zeros- BSF Internal account  for incoming Transfers 
* @return the debitAcctNo
*/
@Field(offset=296, length=20, paddingChar='0', align=Align.RIGHT)
public String getDebitAcctNumber() {
	return debitAcctNumber;
}

public void setDebitAcctNumber(String debitAcctNumber) {
	this.debitAcctNumber = debitAcctNumber;
}


}
