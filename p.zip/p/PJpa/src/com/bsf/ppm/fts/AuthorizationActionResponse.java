package com.bsf.ppm.fts;

import java.util.Date;

import com.bsf.ppm.formatting.annotations.Field;
import com.bsf.ppm.formatting.annotations.FixedFormatPattern;
import com.bsf.ppm.formatting.annotations.Record;
@Record
public class AuthorizationActionResponse {


	/** As in request message */
	private String sourceSystem;
	/** As in request message */
	private String requestFunction;
	/** As in request message */
	private Date serverDate;
	/** As in request message */
	private Date serverTime;
	/** As in request message */
	private String fTSReference;
	/** Oracle API name last invoked */
	private String ftsTransFunc;
	/** CAMM transaction reference */
	private Integer cammTranNum;
	/** As in request message */
	private Integer noOfBlocks;
	/** As in request message */
	private Integer currBlockNo;
	/** As in request message */
	private Integer noOfItems;
	/** As in request message */
	private String customerCode;
	/** As in request message */
	private Long accountNo;
	/** As in request message */
	private String initBranch;
	/** As in request message */
	private String initOfficer;
	/** As in request message */
	private String cardNumber;
	/** CAMM Action code -�5999� � Authorization  Initiated Successfully. Return code other than �5999� � Failure.Refer to Error codes table.  */
	private String cAMMActionCode;
	/** response Server Date */
	private Date lastUpdateDate;
	/** Response  Time */
	private Date lastUpdateTime;
	/** NOR (Normal) */
	private String transactionStatus;
	/** FTS Action code �0000� � Successful.  �9999� � Failure.Refer to Error codes table. */
	private String fTSActionCode;
	/** As in request message */
	private Integer processingSeq;
	/** Length of Detail (Computed) */
	private Integer detailLength;

	/** 
	* get As in request message
	* @return the sourceSystem
	*/
	@Field(offset=1, length=3, paddingChar=' ')
	public String getSourceSystem() {
		return sourceSystem;
	} 
 
	/** 
	* set As in request message
	* @param sourceSystem new value for sourceSystem
	*/
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem=sourceSystem;
	} 
 
	/** 
	* get As in request message
	* @return the requestFunction
	*/
	@Field(offset=4, length=8, paddingChar=' ')
	public String getRequestFunction() {
		return requestFunction;
	} 
 
	/** 
	* set As in request message
	* @param requestFunction new value for requestFunction
	*/
	public void setRequestFunction(String requestFunction) {
		this.requestFunction=requestFunction;
	} 
 
	/** 
	* get As in request message
	* @return the serverDate
	*/
	@Field(offset=12, length=8)
	@FixedFormatPattern("yyyyMMdd")
	public Date getServerDate() {
		return serverDate;
	} 
 
	/** 
	* set As in request message
	* @param serverDate new value for serverDate
	*/
	public void setServerDate(Date serverDate) {
		this.serverDate=serverDate;
	} 
 
	/** 
	* get As in request message
	* @return the serverTime
	*/
	@Field(offset=20, length=6)
	@FixedFormatPattern("HHmmss")
	public Date getServerTime() {
		return serverTime;
	} 
 
	/** 
	* set As in request message
	* @param serverTime new value for serverTime
	*/
	public void setServerTime(Date serverTime) {
		this.serverTime=serverTime;
	} 
 
	/** 
	* get As in request message
	* @return the fTSReference
	*/
	@Field(offset=26, length=10, paddingChar=' ')
	public String getFTSReference() {
		return fTSReference;
	} 
 
	/** 
	* set As in request message
	* @param fTSReference new value for fTSReference
	*/
	public void setFTSReference(String fTSReference) {
		this.fTSReference=fTSReference;
	} 
 
	/** 
	* get Oracle API name last invoked
	* @return the ftsTransFunc
	*/
	@Field(offset=36, length=10, paddingChar=' ')
	public String getFtsTransFunc() {
		return ftsTransFunc;
	} 
 
	/** 
	* set Oracle API name last invoked
	* @param ftsTransFunc new value for ftsTransFunc
	*/
	public void setFtsTransFunc(String ftsTransFunc) {
		this.ftsTransFunc=ftsTransFunc;
	} 
 
	/** 
	* get CAMM transaction reference
	* @return the cammTranNum
	*/
	@Field(offset=46, length=6)
	public Integer getCammTranNum() {
		return cammTranNum;
	} 
 
	/** 
	* set CAMM transaction reference
	* @param cammTranNum new value for cammTranNum
	*/
	public void setCammTranNum(Integer cammTranNum) {
		this.cammTranNum=cammTranNum;
	} 
 
	/** 
	* get As in request message
	* @return the noOfBlocks
	*/
	@Field(offset=52, length=3)
	public Integer getNoOfBlocks() {
		return noOfBlocks;
	} 
 
	/** 
	* set As in request message
	* @param noOfBlocks new value for noOfBlocks
	*/
	public void setNoOfBlocks(Integer noOfBlocks) {
		this.noOfBlocks=noOfBlocks;
	} 
 
	/** 
	* get As in request message
	* @return the currBlockNo
	*/
	@Field(offset=55, length=3)
	public Integer getCurrBlockNo() {
		return currBlockNo;
	} 
 
	/** 
	* set As in request message
	* @param currBlockNo new value for currBlockNo
	*/
	public void setCurrBlockNo(Integer currBlockNo) {
		this.currBlockNo=currBlockNo;
	} 
 
	/** 
	* get As in request message
	* @return the noOfItems
	*/
	@Field(offset=58, length=3)
	public Integer getNoOfItems() {
		return noOfItems;
	} 
 
	/** 
	* set As in request message
	* @param noOfItems new value for noOfItems
	*/
	public void setNoOfItems(Integer noOfItems) {
		this.noOfItems=noOfItems;
	} 
 
	/** 
	* get As in request message
	* @return the customerCode
	*/
	@Field(offset=61, length=10, paddingChar=' ')
	public String getCustomerCode() {
		return customerCode;
	} 
 
	/** 
	* set As in request message
	* @param customerCode new value for customerCode
	*/
	public void setCustomerCode(String customerCode) {
		this.customerCode=customerCode;
	} 
 
	/** 
	* get As in request message
	* @return the accountNo
	*/
	@Field(offset=71, length=20)
	public Long getAccountNo() {
		return accountNo;
	} 
 
	/** 
	* set As in request message
	* @param accountNo new value for accountNo
	*/
	public void setAccountNo(Long accountNo) {
		this.accountNo=accountNo;
	} 
 
	/** 
	* get As in request message
	* @return the initBranch
	*/
	@Field(offset=91, length=6, paddingChar=' ')
	public String getInitBranch() {
		return initBranch;
	} 
 
	/** 
	* set As in request message
	* @param initBranch new value for initBranch
	*/
	public void setInitBranch(String initBranch) {
		this.initBranch=initBranch;
	} 
 
	/** 
	* get As in request message
	* @return the initOfficer
	*/
	@Field(offset=97, length=9, paddingChar=' ')
	public String getInitOfficer() {
		return initOfficer;
	} 
 
	/** 
	* set As in request message
	* @param initOfficer new value for initOfficer
	*/
	public void setInitOfficer(String initOfficer) {
		this.initOfficer=initOfficer;
	} 
 
	/** 
	* get As in request message
	* @return the cardNumber
	*/
	@Field(offset=106, length=23, paddingChar=' ')
	public String getCardNumber() {
		return cardNumber;
	} 
 
	/** 
	* set As in request message
	* @param cardNumber new value for cardNumber
	*/
	public void setCardNumber(String cardNumber) {
		this.cardNumber=cardNumber;
	} 
 
	/** 
	* get CAMM Action code -�5999� � Authorization  Initiated Successfully. Return code other than �5999� � Failure.Refer to Error codes table. 
	* @return the cAMMActionCode
	*/
	@Field(offset=129, length=4)
	public String getCAMMActionCode() {
		return cAMMActionCode;
	} 
 
	/** 
	* set CAMM Action code -�5999� � Authorization  Initiated Successfully. Return code other than �5999� � Failure.Refer to Error codes table. 
	* @param cAMMActionCode new value for cAMMActionCode
	*/
	public void setCAMMActionCode(String cAMMActionCode) {
		this.cAMMActionCode=cAMMActionCode;
	} 
 
	/** 
	* get response Server Date
	* @return the lastUpdateDate
	*/
	@Field(offset=133, length=8)
	@FixedFormatPattern("yyyyMMdd")
	public Date getLastUpdateDate() {
		return lastUpdateDate;
	} 
 
	/** 
	* set response Server Date
	* @param lastUpdateDate new value for lastUpdateDate
	*/
	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate=lastUpdateDate;
	} 
 
	/** 
	* get Response  Time
	* @return the lastUpdateTime
	*/
	@Field(offset=141, length=6)
	@FixedFormatPattern("HHmmss")
	public Date getLastUpdateTime() {
		return lastUpdateTime;
	} 
 
	/** 
	* set Response  Time
	* @param lastUpdateTime new value for lastUpdateTime
	*/
	public void setLastUpdateTime(Date lastUpdateTime) {
		this.lastUpdateTime=lastUpdateTime;
	} 
 
	/** 
	* get NOR (Normal)
	* @return the transactionStatus
	*/
	@Field(offset=147, length=3, paddingChar=' ')
	public String getTransactionStatus() {
		return transactionStatus;
	} 
 
	/** 
	* set NOR (Normal)
	* @param transactionStatus new value for transactionStatus
	*/
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus=transactionStatus;
	} 
 
	/** 
	* get FTS Action code �0000� � Successful.  �9999� � Failure.Refer to Error codes table.
	* @return the fTSActionCode
	*/
	@Field(offset=150, length=4)
	public String getFTSActionCode() {
		return fTSActionCode;
	} 
 
	/** 
	* set FTS Action code �0000� � Successful.  �9999� � Failure.Refer to Error codes table.
	* @param fTSActionCode new value for fTSActionCode
	*/
	public void setFTSActionCode(String fTSActionCode) {
		this.fTSActionCode=fTSActionCode;
	} 
 
	/** 
	* get As in request message
	* @return the processingSeq
	*/
	@Field(offset=154, length=3)
	public Integer getProcessingSeq() {
		return processingSeq;
	} 
 
	/** 
	* set As in request message
	* @param processingSeq new value for processingSeq
	*/
	public void setProcessingSeq(Integer processingSeq) {
		this.processingSeq=processingSeq;
	} 
 
	/** 
	* get Length of Detail (Computed)
	* @return the detailLength
	*/
	@Field(offset=157, length=4)
	public Integer getDetailLength() {
		return detailLength;
	} 
 
	/** 
	* set Length of Detail (Computed)
	* @param detailLength new value for detailLength
	*/
	public void setDetailLength(Integer detailLength) {
		this.detailLength=detailLength;
	} 
 
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("|sourceSystem="+sourceSystem);
		sb.append("|requestFunction="+requestFunction);
		sb.append("|serverDate="+serverDate);
		sb.append("|serverTime="+serverTime);
		sb.append("|fTSReference="+fTSReference);
		sb.append("|ftsTransFunc="+ftsTransFunc);
		sb.append("|cammTranNum="+cammTranNum);
		sb.append("|noOfBlocks="+noOfBlocks);
		sb.append("|currBlockNo="+currBlockNo);
		sb.append("|noOfItems="+noOfItems);
		sb.append("|customerCode="+customerCode);
		sb.append("|accountNo="+accountNo);
		sb.append("|initBranch="+initBranch);
		sb.append("|initOfficer="+initOfficer);
		sb.append("|cardNumber="+cardNumber);
		sb.append("|cAMMActionCode="+cAMMActionCode);
		sb.append("|lastUpdateDate="+lastUpdateDate);
		sb.append("|lastUpdateTime="+lastUpdateTime);
		sb.append("|transactionStatus="+transactionStatus);
		sb.append("|fTSActionCode="+fTSActionCode);
		sb.append("|processingSeq="+processingSeq);
		sb.append("|detailLength="+detailLength);

		return sb.toString();
	} 
 
}
