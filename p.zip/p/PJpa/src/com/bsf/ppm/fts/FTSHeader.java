package com.bsf.ppm.fts;

import java.util.Date;

import com.bsf.ppm.formatting.annotations.Field;
import com.bsf.ppm.formatting.annotations.FixedFormatPattern;
import com.bsf.ppm.formatting.annotations.Record;

/**
 * Class to hold FTS message header
 * @author Rakesh
 *
 */
@Record
public class FTSHeader {
	private String sourceSystem;
	private String requestFunction;
	private Date serverDate;
	private Date serverTime;
	private String ftsReference;
	private String ftsTransFunc;
	private String cammTranNum;
	private Integer numBlocks;
	private Integer currBlockNo;
	private Integer numItems;
	private String customerCode;
	private String accountNo;
	private String initBranch;
	private String initOfficer;
	private String cardNumber;
	private String functionCode;
	private String cammActionCode;
	private Date lastUpdateDate;
	private Date lastUpdateTime;
	private String transactionStatus;
	private String ftsActionCode;
	private Integer processingSeq;
	private Integer detailLength;
	
	@Field(offset = 1, length = 3)
	public String getSourceSystem() {
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	
	@Field(offset = 4, length = 8)
	public String getRequestFunction() {
		return requestFunction;
	}
	public void setRequestFunction(String requestFunction) {
		this.requestFunction = requestFunction;
	}
	
	@Field(offset = 12, length = 8)
	@FixedFormatPattern("yyyyMMdd")
	public Date getServerDate() {
		return serverDate;
	}
	public void setServerDate(Date serverDate) {
		this.serverDate = serverDate;
	}
	
	@Field(offset = 20, length = 6)
	@FixedFormatPattern("HHmmss")
	public Date getServerTime() {
		return serverTime;
	}
	public void setServerTime(Date serverTime) {
		this.serverTime = serverTime;
	}
	
	@Field(offset = 26, length = 10)
	public String getFtsReference() {
		return ftsReference;
	}
	public void setFtsReference(String ftsReference) {
		this.ftsReference = ftsReference;
	}
	
	@Field(offset = 36, length = 10)
	public String getFtsTransFunc() {
		return ftsTransFunc;
	}
	public void setFtsTransFunc(String ftsTransFunc) {
		this.ftsTransFunc = ftsTransFunc;
	}
	
	@Field(offset = 46, length = 6)
	public String getCammTranNum() {
		return cammTranNum;
	}
	public void setCammTranNum(String cammTranNum) {
		this.cammTranNum = cammTranNum;
	}
	
	@Field(offset = 52, length = 3)
	public Integer getNumBlocks() {
		return numBlocks;
	}
	public void setNumBlocks(Integer numBlocks) {
		this.numBlocks = numBlocks;
	}
	
	@Field(offset = 55, length = 3)
	public Integer getCurrBlockNo() {
		return currBlockNo;
	}
	public void setCurrBlockNo(Integer currBlockNo) {
		this.currBlockNo = currBlockNo;
	}
	
	@Field(offset = 58, length = 3)
	public Integer getNumItems() {
		return numItems;
	}
	public void setNumItems(Integer numItems) {
		this.numItems = numItems;
	}
	
	@Field(offset = 61, length = 10)
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	
	@Field(offset = 71, length = 20)
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	
	@Field(offset = 91, length = 6)
	public String getInitBranch() {
		return initBranch;
	}
	public void setInitBranch(String initBranch) {
		this.initBranch = initBranch;
	}
	
	@Field(offset = 97, length = 9)
	public String getInitOfficer() {
		return initOfficer;
	}
	public void setInitOfficer(String initOfficer) {
		this.initOfficer = initOfficer;
	}
	
	@Field(offset = 106, length = 20)
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	
	@Field(offset = 126, length = 3)
	public String getFunctionCode() {
		return functionCode;
	}
	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}
	
	@Field(offset = 129, length = 4)
	public String getCammActionCode() {
		return cammActionCode;
	}
	public void setCammActionCode(String cammActionCode) {
		this.cammActionCode = cammActionCode;
	}
	
	@Field(offset = 133, length = 8)
	@FixedFormatPattern("yyyyMMdd")
	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}
	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	
	@Field(offset = 141, length = 6)
	@FixedFormatPattern("HHmmss")
	public Date getLastUpdateTime() {
		return lastUpdateTime;
	}
	public void setLastUpdateTime(Date lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}
	
	@Field(offset = 147, length = 3)
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	
	@Field(offset = 150, length = 4)
	public String getFtsActionCode() {
		return ftsActionCode;
	}
	
	public void setFtsActionCode(String ftsActionCode) {
		this.ftsActionCode = ftsActionCode;
	}
	
	@Field(offset = 154, length = 3)
	public Integer getProcessingSeq() {
		return processingSeq;
	}
	
	public void setProcessingSeq(Integer processingSeq) {
		this.processingSeq = processingSeq;
	}
	
	@Field(offset = 157, length = 4)
	public Integer getDetailLength() {
		return detailLength;
	}
	public void setDetailLength(Integer detailLength) {
		this.detailLength = detailLength;
	}
	
}
