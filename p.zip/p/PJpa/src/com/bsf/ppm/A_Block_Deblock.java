package com.bsf.ppm;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.bsf.ipp.dao.SelectableAuditableCacheableEntity;
import com.bsf.ppm.util.StringUtils;

@Entity
/*@NamedQueries({
	@NamedQuery(name = "Ppm_DebitBlockStaging.selectA_AccountsfromCamm", query = "Select PpmDebitBlockStaging  "
		+ " where acctStatusCamm=:acctStatusCammXb  and  statuRsnCodeCamm=:statuRsnCodeCamm")
})*/

@Table(name = "A_BLOCK_DEBLOCK")
@SuppressWarnings("serial")
public class A_Block_Deblock  extends SelectableAuditableCacheableEntity {
    
	
	//private String instReference;
	
	private String accNumber;
	
	private String custCode;
		
	private String acctStatusCamm;
	
	private String statuRsnCodeCamm;
	
	private Date  deblkDate; 
	
	private String seqNo;
	
	
		
	@Id 
	@Basic
	/*@Column(name = "INST_REFERENCE")
	public String getInstReference() {
		return instReference;
	}

	public void setInstReference(String instReference) {
		this.instReference = instReference;
	}*/
		
	@Column(name = "ACCT_NO")
	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}

	@Column(name = "CUST_CODE")		
	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	@Column(name="BLK_TYPE")
	public String getAcctStatusCamm() {
		return acctStatusCamm;
	}

	public void setAcctStatusCamm(String acctStatusCamm) {
		this.acctStatusCamm = acctStatusCamm;
	}
	@Column(name="BLK_RSN_CODE")
	public String getStatuRsnCodeCamm() {
		return statuRsnCodeCamm;
	}

	public void setStatuRsnCodeCamm(String statuRsnCodeCamm) {
		this.statuRsnCodeCamm = statuRsnCodeCamm;
	}
	
		
	@Column(name="DEBLK_DATE")
	public Date getDeblkDate() {
		return deblkDate;
	}

	public void setDeblkDate(Date deblkDate) {
		this.deblkDate = deblkDate;
	}
	
	@Column(name="SEQ_NO")
	public String getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}

	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getAccNumber());
	}
	@Override
	@Transient
	public String getKey() {
		// TODO Auto-generated method stub
		return getAccNumber()+"";
	}
	
	
	
	
	
	
	

}
