package com.bsf.ppm;

import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import com.bsf.ipp.dao.SelectableAuditableEntity;

/**
 * <p>Pojo mapping TABLE IPPUSER.SYSTEM_TYPE</p>
 * @author Kaza
 * 
 */
@Entity
@NamedQuery(name = "SystemType.findAll", query = "select o from SystemType o")
@Table(name = "SYSTEM_TYPE")
public class SystemType extends SelectableAuditableEntity {
    private Long id;
    private String typeName;
    private List<SystemTypeParameter> systemTypeParameterList;
    private List<BackendSystem> backendSystemList;

    public SystemType() {
    }

	@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "systemTypeIdGen")
	@TableGenerator(name = "systemTypeIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "SYSTEM_TYPE", valueColumnName = "ID_VALUE")
	@Column(name = "ID",nullable = false)    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Column(name="TYPE_NAME")
    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    @OneToMany(mappedBy = "systemType", fetch=FetchType.EAGER, cascade=CascadeType.ALL)
    public List<SystemTypeParameter> getSystemTypeParameterList() {
        return systemTypeParameterList;
    }

    public void setSystemTypeParameterList(List<SystemTypeParameter> systemTypeParameterList) {
        this.systemTypeParameterList = systemTypeParameterList;
    }

    public SystemTypeParameter addSystemTypeParameter(SystemTypeParameter systemTypeParameter) {
        getSystemTypeParameterList().add(systemTypeParameter);
        systemTypeParameter.setSystemType(this);
        return systemTypeParameter;
    }

    public SystemTypeParameter removeSystemTypeParameter(SystemTypeParameter systemTypeParameter) {
        getSystemTypeParameterList().remove(systemTypeParameter);
        systemTypeParameter.setSystemType(null);
        return systemTypeParameter;
    }

    @OneToMany(mappedBy = "systemType")
    public List<BackendSystem> getBackendSystemList() {
        return backendSystemList;
    }

    public void setBackendSystemList(List<BackendSystem> backendSystemList) {
        this.backendSystemList = backendSystemList;
    }

    public BackendSystem addBackendSystem(BackendSystem backendSystem) {
        getBackendSystemList().add(backendSystem);
        backendSystem.setSystemType(this);
        return backendSystem;
    }

    public BackendSystem removeBackendSystem(BackendSystem backendSystem) {
        getBackendSystemList().remove(backendSystem);
        backendSystem.setSystemType(null);
        return backendSystem;
    }
    
	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getId());
	}    
}
