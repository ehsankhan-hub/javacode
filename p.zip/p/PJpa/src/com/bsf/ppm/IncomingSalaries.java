package com.bsf.ppm;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.SelectableAuditableCacheableEntity;

/**
 * <p>Pojo mapping TABLE INCOMING_SALARIES</p>
 *
 * @author Ehsan
 * 
 */
@Entity
/*@NamedQuery(name = "IncomingSalaries.findAll", 
	    query = "select o from IncomingSalaries o")*/
@Table(name = "INCOMING_SALARIES")
@SuppressWarnings("serial")
public class IncomingSalaries extends SelectableAuditableCacheableEntity {

	/**
	 * Attribute sequenceNum.
	 */
	private Long sequenceNum;
	
	/**
	 * Attribute systemName.
	 */
	private String longRef;
	
	
	/**
	 * Attribute logSystemDate.
	 */
	private Date logSystemDate;
	
	/**
	 * Attribute sourceSystem.
	 */
	private String sourceSystem;
	
	/**
	 * Attribute transType.
	 */
	private String transType;
	
	/**
	 * Attribute creditAcctNo.
	 */
	private String creditAcctNo="";
	
	
	/**
	 * Attribute creditAmmount.
	 */
	private Double creditAmmount;
	
	
	/**
	 * Attribute processStatus.
	 */
	private String processStatus;
	
		
	/**
	 * List of Ppm_Inst_Transactions
	 */
	private List<Ppm_Inst_Transactions> ppmInstTransactions = null;

	
	/**
	 * @return id
	 */
	@Id
	@Basic
	@Column(name ="SEQUENCE_NO")
	public Long getSequenceNum() {
		return sequenceNum;
	}

	public void setSequenceNum(Long sequenceNum) {
		this.sequenceNum = sequenceNum;
	}
	
	@Column(name ="LOG_REFERENCE")	
	public String getLongRef() {
		return longRef;
	}

	public void setLongRef(String longRef) {
		this.longRef = longRef;
	}
	
	
	
	@Column(name ="LOG_SYSTEM_DATE")
	public Date getLogSystemDate() {
		return logSystemDate;
	}

	public void setLogSystemDate(Date logSystemDate) {
		this.logSystemDate = logSystemDate;
	}
	@Column(name ="SOURCE_SYSTEM")
	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	@Column(name ="TRANS_TYPE")	
	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	@Column(name ="CREDT_ACCT_NO")
	public String getCreditAcctNo() {
		return creditAcctNo;
	}

	public void setCreditAcctNo(String creditAcctNo) {
		this.creditAcctNo = creditAcctNo;
	}
	@Column(name ="CREDT_AMOUNT")
	public Double getCreditAmmount() {
		return creditAmmount;
	}

	public void setCreditAmmount(Double creditAmmount) {
		this.creditAmmount = creditAmmount;
	}
	@Column(name ="PROCESS_FLAG")
	public String getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	/*
	 * Get the list of PPM_INST_TRANSACTIONS
	 * , fetch=FetchType.EAGER, cascade=CascadeType.ALL
	 */
	//@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	//@JoinColumn(name = "PPM_INCMNG_SEQ")
	 @OneToMany(fetch = FetchType.EAGER,mappedBy = "incomingSalaries", cascade = CascadeType.ALL)
	// @OrderBy("sequenceNum asc")
	public List<Ppm_Inst_Transactions> getPpmInstTransactions() {
		return ppmInstTransactions;
	}

	public void setPpmInstTransactions(
			List<Ppm_Inst_Transactions> ppmInstTransactions) {
		this.ppmInstTransactions = ppmInstTransactions;
	}

    @Override
	@Transient
	public String getPk() {
		return String.valueOf(getSequenceNum());
	}

   
	

	/*public String toString(){
		StringBuffer buff = new StringBuffer();
		if (getPpm_Inst_Transactions()!=null && getPpm_Inst_Transactions().size()>0){
			List<Ppm_Inst_Transactions> list = getPpm_Inst_Transactions();
			
			for (Ppm_Inst_Transactions ppmInstTransactions : list) {
				
				//Ppm_Inst_Transactions parameter =  ppmInstTransactions.getInstRef();
				//buff.append(parameter.getInstRef() +"=" + ppmInstTransactions.getInstRef()+ ",");
			}
			
		}
		return buff.toString();
	}*/
    
	@Override
	@Transient
	public String getKey() {
		// TODO Auto-generated method stub
		return getSequenceNum().toString();
	} 


}