package com.bsf.ppm;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.bsf.ipp.dao.SelectableAuditableCacheableEntity;
import com.bsf.ppm.util.StringUtils;

@Entity
/*@NamedQueries({
	@NamedQuery(name = "Ppm_DebitBlockStaging.selectA_AccountsfromCamm", query = "Select PpmDebitBlockStaging  "
		+ " where acctStatusCamm=:acctStatusCammXb  and  statuRsnCodeCamm=:statuRsnCodeCamm")
})*/

@Table(name = "A_ACCOUNT")
@SuppressWarnings("serial")
public class A_Account  extends SelectableAuditableCacheableEntity {
    
	
	//private String instReference;
	
	private String accNumber;
	
	private String acctCurCode;
	
	private int status;
	
	private String acctStatusCamm;
	
	private String statuRsnCodeCamm;
	
	
		
	@Id 
	@Basic
	/*@Column(name = "INST_REFERENCE")
	public String getInstReference() {
		return instReference;
	}

	public void setInstReference(String instReference) {
		this.instReference = instReference;
	}*/
		
	@Column(name = "ACCT_NO")
	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}

	
	@Column(name="CRNCY_CODE")	
	public String getAcctCurCode() {
		return acctCurCode;
	}

	public void setAcctCurCode(String acctCurCode) {
		this.acctCurCode = acctCurCode;
	}
	
	@Column(name="STATUS_CODE")
	public String getAcctStatusCamm() {
		return acctStatusCamm;
	}

	public void setAcctStatusCamm(String acctStatusCamm) {
		this.acctStatusCamm = acctStatusCamm;
	}
	@Column(name="STATUS_RSN_CODE")
	public String getStatuRsnCodeCamm() {
		return statuRsnCodeCamm;
	}

	public void setStatuRsnCodeCamm(String statuRsnCodeCamm) {
		this.statuRsnCodeCamm = statuRsnCodeCamm;
	}
	
	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getAccNumber());
	}
	@Override
	@Transient
	public String getKey() {
		// TODO Auto-generated method stub
		return getAccNumber()+"";
	}
	
	
	
	
	
	
	

}
