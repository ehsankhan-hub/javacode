package com.bsf.ppm;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.bsf.ipp.UserInfo;


/**
 * <p>Pojo mapping TABLE IPPUSER.SMS_MESSAGE</p>
 *
 * @author Kaza
 * 
 */
@Entity
@Table(name = "SMS_MESSAGE")
@SuppressWarnings("serial")
public class SmsMessage implements Serializable {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute senderId.
	 */
	private String senderId;
	
	/**
	 * Attribute smsLanguage.
	 */
	private String smsLanguage;
	
	/**
	 * Attribute smsMessage.
	 */
	private String smsMessage;
	
	/**
	 * Attribute priority.
	 */
	private Long priority;
	
	/**
	 * Attribute deliveryTime.
	 */
	private Timestamp deliveryTime;
	
	/**
	 * Attribute createdDate.
	 */
	private Timestamp createdDate;
	
	/**
	 * Attribute processedDate.
	 */
	private Timestamp processedDate;
	
	/**
	 * Attribute smsStatus.
	 */
	private Long smsStatus;
	
	/**
	 * Attribute application
	 */
	 private Application application;	

	/**
	 * Attribute userInfo
	 */
	 private UserInfo userInfo;	

	/**
	 * List of SmsAddress
	 */
	private List<SmsAddress> smsAddressList = null;

	
	/**
	 * @return id
	 */
	@Basic
	@Id
	@Column(name = "ID")
		public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return senderId
	 */
	@Basic
	@Column(name = "SENDER_ID", length = 50)
		public String getSenderId() {
		return senderId;
	}

	/**
	 * @param senderId new value for senderId 
	 */
	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}
	
	/**
	 * @return smsLanguage
	 */
	@Basic
	@Column(name = "SMS_LANGUAGE", length = 10)
		public String getSmsLanguage() {
		return smsLanguage;
	}

	/**
	 * @param smsLanguage new value for smsLanguage 
	 */
	public void setSmsLanguage(String smsLanguage) {
		this.smsLanguage = smsLanguage;
	}
	
	/**
	 * @return smsMessage
	 */
	@Basic
	@Column(name = "SMS_MESSAGE", length = 500)
		public String getSmsMessage() {
		return smsMessage;
	}

	/**
	 * @param smsMessage new value for smsMessage 
	 */
	public void setSmsMessage(String smsMessage) {
		this.smsMessage = smsMessage;
	}
	
	/**
	 * @return priority
	 */
	@Basic
	@Column(name = "PRIORITY")
		public Long getPriority() {
		return priority;
	}

	/**
	 * @param priority new value for priority 
	 */
	public void setPriority(Long priority) {
		this.priority = priority;
	}
	
	/**
	 * @return deliveryTime
	 */
	@Basic
	@Column(name = "DELIVERY_TIME")
		public Timestamp getDeliveryTime() {
		return deliveryTime;
	}

	/**
	 * @param deliveryTime new value for deliveryTime 
	 */
	public void setDeliveryTime(Timestamp deliveryTime) {
		this.deliveryTime = deliveryTime;
	}
	
	/**
	 * @return createdDate
	 */
	@Basic
	@Column(name = "CREATED_DATE")
		public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate new value for createdDate 
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	
	/**
	 * @return processedDate
	 */
	@Basic
	@Column(name = "PROCESSED_DATE")
		public Timestamp getProcessedDate() {
		return processedDate;
	}

	/**
	 * @param processedDate new value for processedDate 
	 */
	public void setProcessedDate(Timestamp processedDate) {
		this.processedDate = processedDate;
	}
	
	/**
	 * @return smsStatus
	 */
	@Basic
	@Column(name = "SMS_STATUS")
		public Long getSmsStatus() {
		return smsStatus;
	}

	/**
	 * @param smsStatus new value for smsStatus 
	 */
	public void setSmsStatus(Long smsStatus) {
		this.smsStatus = smsStatus;
	}
	
	/**
	 * get application
	 */
	@ManyToOne
	@JoinColumn(name = "APPLICATION_ID")
	public Application getApplication() {
		return this.application;
	}
	
	/**
	 * set application
	 */
	public void setApplication(Application application) {
		this.application = application;
	}

	/**
	 * get userInfo
	 */
	@ManyToOne
	@JoinColumn(name = "USER_ID")
	public UserInfo getUserInfo() {
		return this.userInfo;
	}
	
	/**
	 * set userInfo
	 */
	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	/**
	 * Get the list of SmsAddress
	 */
	 @OneToMany(mappedBy="smsMessage")
	 public List<SmsAddress> getSmsAddressList() {
	 	return this.smsAddressList;
	 }
	 
	/**
	 * Set the list of SmsAddress
	 */
	 public void setSmsAddressList(List<SmsAddress> smsAddressList) {
	 	this.smsAddressList = smsAddressList;
	 }


}