package com.bsf.ppm;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.SelectableAuditableCacheableEntity;

/**
 * <p>Pojo mapping TABLE IPPUSER.BACKEND_SYSTEM</p>
 *
 * @author Kaza
 * 
 */
@Entity
@NamedQuery(name = "BackendSystem.findAll", 
	    query = "select o from BackendSystem o")
@Table(name = "BACKEND_SYSTEM")
@SuppressWarnings("serial")
public class BackendSystem extends SelectableAuditableCacheableEntity {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute systemName.
	 */
	private String systemName;
	
	/**
	 * Attribute systemDescription.
	 */
	private String systemDescription;
	
	/**
	 * Attribute systemType
	 */
	 private SystemType systemType;	

	/**
	 * Attribute status.
	 */
	private Long status;
	
	/**
	 * Attribute createdDate.
	 */
	private Timestamp createdDate;
	
	/**
	 * Attribute userInfo
	 */
	 private UserInfo modifiedBy;	

	/**
	 * Attribute modifiedDate.
	 */
	private Timestamp modifiedDate;
	
	/**
	 * Attribute userInfo
	 */
	 private UserInfo createdBy;	

	/**
	 * List of BatchJob
	 */
	private List<BatchJob> batchJobs = null;

	/**
	 * List of SystemConfiguration
	 */
	private List<SystemConfiguration> systemConfigurations = null;

	
	/**
	 * @return id
	 */
	@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "backendSystemIdGen")
	@TableGenerator(name = "backendSystemIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "BACKEND_SYSTEM", valueColumnName = "ID_VALUE")
	@Column(name = "ID", nullable = false)
	public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return systemName
	 */
	@Basic
	@Column(name = "SYSTEM_NAME", length = 12)
		public String getSystemName() {
		return systemName;
	}

	/**
	 * @param systemName new value for systemName 
	 */
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	
	/**
	 * @return systemDescription
	 */
	@Basic
	@Column(name = "SYSTEM_DESCRIPTION", length = 30)
		public String getSystemDescription() {
		return systemDescription;
	}

	/**
	 * @param systemDescription new value for systemDescription 
	 */
	public void setSystemDescription(String systemDescription) {
		this.systemDescription = systemDescription;
	}
	
	/**
	 * get systemType
	 */
	@ManyToOne
	@JoinColumn(name = "SYSTEM_TYPE_ID")
	public SystemType getSystemType() {
		return this.systemType;
	}
	
	/**
	 * set systemType
	 */
	public void setSystemType(SystemType systemType) {
		this.systemType = systemType;
	}

	/**
	 * @return status
	 */
	@Basic
	@Column(name = "STATUS")
		public Long getStatus() {
		return status;
	}

	/**
	 * @param status new value for status 
	 */
	public void setStatus(Long status) {
		this.status = status;
	}
	
	/**
	 * @return createdDate
	 */
	@Basic
	@Column(name = "CREATED_DATE")
		public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate new value for createdDate 
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	
	/**
	 * get userInfo
	 */
	@ManyToOne
	@JoinColumn(name = "MODIFIED_BY")
	public UserInfo getModifiedBy() {
		return modifiedBy;
	}
	
	/**
	 * set userInfo
	 */
	public void setModifiedBy(UserInfo modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return modifiedDate
	 */
	@Basic
	@Column(name = "MODIFIED_DATE")
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate new value for modifiedDate 
	 */
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	/**
	 * get userInfo
	 */
	@ManyToOne
	@JoinColumn(name = "CREATED_BY")
	public UserInfo getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * set userInfo
	 */
	public void setCreatedBy(UserInfo createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Get the list of BatchJob
	 */
	 @OneToMany(mappedBy="backendSystem")
	 public List<BatchJob> getBatchJobs() {
	 	return this.batchJobs;
	 }
	 
	/**
	 * Set the list of BatchJob
	 */
	 public void setBatchJobs(List<BatchJob> batchJobs) {
	 	this.batchJobs = batchJobs;
	 }
	/**
	 * Get the list of SystemConfiguration
	 * , fetch=FetchType.EAGER, cascade=CascadeType.ALL
	 */
	 @OneToMany(mappedBy="backendSystem", fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	 @OrderBy("id asc")
	 public List<SystemConfiguration> getSystemConfigurations() {
	 	return this.systemConfigurations;
	 }
	 
	/**
	 * Set the list of SystemConfiguration
	 */
	 public void setSystemConfigurations(List<SystemConfiguration> systemConfigurations) {
	 	this.systemConfigurations = systemConfigurations;
	 }

    @Override
	@Transient
	public String getPk() {
		return String.valueOf(getId());
	}

    public String toString(){
		StringBuffer buff = new StringBuffer();
		if (getSystemConfigurations()!=null && getSystemConfigurations().size()>0){
			List<SystemConfiguration> list = getSystemConfigurations();
			
			for (SystemConfiguration systemConfiguration : list) {
				
				SystemTypeParameter parameter =  systemConfiguration.getSystemTypeParameter();
				buff.append(parameter.getParamName() +"=" + systemConfiguration.getParamValue()+ ",");
			}
			
		}
		return buff.toString();
	}
    
	@Override
	@Transient
	public String getKey() {
		// TODO Auto-generated method stub
		return getSystemName();
	} 


}