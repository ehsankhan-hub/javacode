package com.bsf.ppm;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;
import org.hibernate.annotations.GenericGenerator;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.SelectableAuditableEntity;
import com.bsf.ppm.PpmParameterValue.PpmParameterValuePK;

/**
 * <p>Pojo mapping TABLE OEPAYSD.PPM_GROUP</p>
 *
 * <p>Generated at Wed Aug 10 12:21:25 AST 2016</p>
 * @author Salto-db Generator v1.0.16 / EJB3
 * 
 */
@Entity
/*@NamedQueries({
	@NamedQuery(name = "PpmExeRulesCrit.updatePpmExeRulesCrit", query = "update PpmExeRulesCriteria crit "
		+ " set crit.value1=:value1 where crit.exeRuleName=:exeRuleName and crit.fieldName=:fieldName and crit.value1=:value1 ")
})*/
@Table(name = "PPM_EXE_RULES_CRITERIA")
@SuppressWarnings("serial")
public class PpmExeRulesCriteria extends SelectableAuditableEntity implements Comparable<PpmExeRulesCriteria> {

	
	
	private int ruleId;
	
	
	private int cndtnId;
	
	/**
	 * Attribute value2.
	 */
	private String value2;
	
	/**
	 * Attribute optrSign.
	 */
	private String optrSign;
	
	
	/**
	 * Attribute status.
	 */
	private int seqNum;
		
	
	
	/**
	 * Attribute createDate.
	 */
	private Date createDate;
	
	/**
	 * Attribute createdBy.
	 */
	private UserInfo createdBy;
	
	/**
	 * Attribute updateDate.
	 */
	private Date updateDate;
	
	/**
	 * Attribute updatedBy.
	 */
	private UserInfo updatedBy;
	
	
	
	private PpmExeRules ppmExeRules;
	
	public PpmExeRulesCriteria(){
		
	}
	
	@EmbeddedId
	private PpmExeRulesCriteriaPK ppmExeRulesCriteriaPK=new PpmExeRulesCriteriaPK();
	
	
	
	@Id
	@Basic
	public PpmExeRulesCriteriaPK getPpmExeRulesCriteriaPK() {
		return ppmExeRulesCriteriaPK;
	}
    
	public void setPpmExeRulesCriteriaPK(PpmExeRulesCriteriaPK ppmExeRulesCriteriaPK) {
		this.ppmExeRulesCriteriaPK = ppmExeRulesCriteriaPK;
	}
	
	@Column(name="VALUE2")
	public String getValue2() {
		return value2;
	}
	public void setValue2(String value2) {
		this.value2 = value2;
	}
	@Column(name="OPRT_SIGN")
	public String getOptrSign() {
		return optrSign;
	}
	public void setOptrSign(String optrSign) {
		this.optrSign = optrSign;
	}
		
	@Column(name="SEQ_NUM")
	public int getSeqNum() {
		return seqNum;
	}
	public void setSeqNum(int seqNum) {
		this.seqNum = seqNum;
	}
	
	@ManyToOne
	@JoinColumn(name = "EXE_RULE_NAME",insertable = false, updatable = false)
	public PpmExeRules getPpmExeRules() {
		return ppmExeRules;
	}
	public void setPpmExeRules(PpmExeRules ppmExeRules) {
		this.ppmExeRules = ppmExeRules;
	}
	/**
	 * @return createDate
	 */
	@Basic
	@Column(name = "CREATE_DATE")
		public Date getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate new value for createDate 
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	
	/**
	 * @return createdBy
	 */
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "CREATED_BY")
		public UserInfo getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy new value for createdBy 
	 */
	public void setCreatedBy(UserInfo createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * @return updateDate
	 */
	@Basic
	@Column(name = "UPDATE_DATE")
		public Date getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate new value for updateDate 
	 */
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	
	/**
	 * @return updatedBy
	 */
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "UPDATED_BY")
		public UserInfo getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy new value for updatedBy 
	 */
	public void setUpdatedBy(UserInfo updatedBy) {
		this.updatedBy = updatedBy;
	}
	

		
	@Override
	@Transient
	public int compareTo(PpmExeRulesCriteria benInfo) 
	{
    return (int) (this.getSeqNum() - seqNum);    
	
}
	@Override
	@XmlTransient
	@Transient
	public String getPk() {
		// TODO Auto-generated method stub
		return ppmExeRulesCriteriaPK.getExeRuleName();
	}
	
	/*@Override
	@XmlTransient
	@Transient
	public List <PpmExeRulesCriteriaPK>getListPk(){
		List<PpmExeRulesCriteriaPK> ppmExeRulesCriteriaPKList=new ArrayList<PpmExeRulesCriteriaPK>();
		String rueleName=ppmExeRulesCriteriaPK.getExeRuleName();
		String fieldName=ppmExeRulesCriteriaPK.getFieldName();
		String value1=ppmExeRulesCriteriaPK.getValue1();
		PpmExeRulesCriteriaPK ppmExeRulesCriteriaPK=new PpmExeRulesCriteriaPK();
		ppmExeRulesCriteriaPK.setExeRuleName(rueleName);
		ppmExeRulesCriteriaPK.setFieldName(fieldName);
		ppmExeRulesCriteriaPK.setValue1(value1);
		ppmExeRulesCriteriaPKList.add(ppmExeRulesCriteriaPK);
		System.out.println("PrimaryKey="+ppmExeRulesCriteriaPK.getFieldName());
		return ppmExeRulesCriteriaPKList;
	}
	*/
	@SuppressWarnings("serial")
	@Embeddable
	public static class PpmExeRulesCriteriaPK implements Serializable {
		/**
		 * Attribute exeRuleName.
		 */
		private String exeRuleName;
		
		/**
		 * Attribute fieldName.
		 */
		private String fieldName;
		
		/**
		 * Attribute value1.
		 */
		private String value1;
		
		public boolean selected;
		
		@Column(name="EXE_RULE_NAME")	
		public String getExeRuleName() {
			return exeRuleName;
		}
	   	public void setExeRuleName(String exeRuleName) {
			this.exeRuleName = exeRuleName;
		}
		@Column(name="FIELD_NAME")
		public String getFieldName() {
			return fieldName;
		}
		public void setFieldName(String fieldName) {
			this.fieldName = fieldName;
		}
		@Column(name="VALUE1")
		public String getValue1() {
			return value1;
		}
		public void setValue1(String value1) {
			this.value1 = value1;
		}
		
	
       public PpmExeRulesCriteriaPK(){
			
		}
      
	     public PpmExeRulesCriteriaPK(String exeRuleName,String fieldName,String value1){
		 super();
	      this.exeRuleName=exeRuleName;
	      this.fieldName=fieldName;
		 this.value1=value1;
		 
		}
	     // Must have a equals method
	     @Override
	 	 public boolean equals(Object obj) {
		        if (obj == null) return false;
		        if (!this.getClass().equals(obj.getClass())) return false;
		         
		        PpmExeRulesCriteriaPK obj2 = (PpmExeRulesCriteriaPK)obj;
		        System.out.println("obj2==="+obj2);
		        System.out.println("thisObj==="+this);
		       if (this.exeRuleName.equals(obj2.getExeRuleName()) &&
		            this.fieldName.equals(obj2.getFieldName()) && this.value1.equals(obj2.getValue1())) {
		            return true;
		        }
		        return false;
		    }
	     // Must have a hashCode method
	     @Override
	      public int hashCode() {      
		        int tmp = 0;
		        tmp = (exeRuleName + fieldName+value1).hashCode();
		        return tmp;
		    }
		}

	
		
		


}