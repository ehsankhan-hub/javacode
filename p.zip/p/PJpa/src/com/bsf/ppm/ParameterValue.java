package com.bsf.ppm;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "PPM_PARAMETER_VALUE")
@SuppressWarnings("serial")
public class ParameterValue implements Serializable{
private String parmtypecode;	
private String value1;
private String value2;
private String groupCode;
private ParamValueId varamValueId;

@EmbeddedId
public ParamValueId getVaramValueId() {
	return varamValueId;
}
public void setVaramValueId(ParamValueId varamValueId) {
	this.varamValueId = varamValueId;
}

/*
@Id
@AttributeOverrides({
@AttributeOverride(name = "parmtypecode",
column = @Column(name="PARAM_TYPE_CODE")),
@AttributeOverride(name = "groupCode",
column = @Column(name="GROUP_CODE")),
@AttributeOverride(name = "value1",
column = @Column(name="VALUE1"))


})
*/

@Column(name="PARAM_TYPE_CODE",insertable = false, updatable = false)
public String getParmtypecode() {
	return parmtypecode;
}
public void setParmtypecode(String parmtypecode) {
	this.parmtypecode = parmtypecode;
}
@Column(name="VALUE1",insertable = false, updatable = false)
public String getValue1() {
	return value1;
}
public void setValue1(String value1) {
	this.value1 = value1;
}

@Column(name="GROUP_CODE",insertable = false, updatable = false)
public String getGroupCode() {
	return groupCode;
}
public void setGroupCode(String groupCode) {
	this.groupCode = groupCode;
}

@Column(name="VALUE2",insertable = false, updatable = false)
public String getValue2() {
	return value2;
}
public void setValue2(String value2) {
	this.value2 = value2;
}

}
