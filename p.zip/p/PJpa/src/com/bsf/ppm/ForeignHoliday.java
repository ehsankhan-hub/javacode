package com.bsf.ppm;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.SelectableAuditableEntity;

/**
 * <p>Pojo mapping TABLE IPPUSER.FOREIGN_HOLIDAY</p>
 *
 * <p>Generated at Sat Jul 18 09:59:34 AST 2009</p>
 * @author Salto-db Generator v1.0.16 / EJB3
 * 
 */
@Entity
@NamedQueries({
	@NamedQuery(name = "ForeignHoliday.updateHolidayType", query = "Update ForeignHoliday fh set fh.holidayType=:holidayType," +
			"fh.holidayDescription=:holidayDescription " +
			"where  fh.countryCode=:countryCode and " +
			"fh.holidayDate=:holidayDate"),
	@NamedQuery(name = "ForeignHoliday.searchByCountryAndDate", query = "select obj from ForeignHoliday obj where" +
			" obj.countryCode=:countryCode and to_char(obj.holidayDate, 'DDMMYYYY') = to_char(:holidayDate,'DDMMYYYY')  and obj.holidayType=:holidayType  and obj.status=:status "),
	@NamedQuery(name = "ForeignHoliday.searchHWTypeHolidaysByCountryAndDate", query = "select obj from ForeignHoliday obj where" +
			" obj.countryCode=:countryCode and to_char(obj.holidayDate, 'DDMMYYYY') = to_char(:holidayDate,'DDMMYYYY')  and (obj.holidayType='H' or  obj.holidayType='W') and obj.status=:status "),
	@NamedQuery(name = "ForeignHoliday.isDateSystemHoliday", query = "select obj from ForeignHoliday obj where" +
					" trunc(holidayDate)=trunc(:holidayDate) and obj.holidayType='X'  and obj.status=:status "),
	@NamedQuery(name = "ForeignHoliday.isDateNormalHoliday", query = "select obj from ForeignHoliday obj where" +
					" trunc(holidayDate)=trunc(:holidayDate) and (obj.holidayType='W' or  obj.holidayType='H') and (obj.countryCode=:fromCountry or obj.countryCode=:toCountry) and  obj.status=:status ")	
})
@Table(name = "FOREIGN_HOLIDAY")
@SuppressWarnings("serial")
public class ForeignHoliday  extends SelectableAuditableEntity {

	/**
	 * Attribute id.
	 */
	private Long id;

	/**
	 * Attribute countryCode.
	 */
	private String countryCode;

	/**
	 * Attribute countryName.
	 */
	private String countryName;

	/**
	 * Attribute holidayDate.
	 */
	private Date holidayDate;

	/**
	 * Attribute holidayType.
	 */
	private String holidayType;

	/**
	 * Attribute holidayDescription.
	 */
	private String holidayDescription;

	/**
	 * Attribute userInfo
	 */
	private UserInfo createdBy;	

	/**
	 * Attribute createdDate.
	 */
	private Timestamp createdDate;

	/**
	 * Attribute userInfo
	 */
	private UserInfo modifiedBy;	

	/**
	 * Attribute modifiedDate.
	 */
	private Timestamp modifiedDate;

	/**
	 * Attribute status.
	 */
	private Long status;


	/**
	 * @return id
	 */
	@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "foreignHolidayIdGen")
	@TableGenerator(name = "foreignHolidayIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "FOREIGN_HOLIDAY", valueColumnName = "ID_VALUE")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}
	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return countryCode
	 */
	@Basic
	@Column(name = "COUNTRY_CODE", length = 3)
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * @param countryCode new value for countryCode 
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * @return countryName
	 */
	@Basic
	@Column(name = "COUNTRY_NAME", length = 50)
	public String getCountryName() {
		return countryName;
	}

	/**
	 * @param countryName new value for countryName 
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	/**
	 * @return holidayDate
	 */
	@Basic
	@Column(name = "HOLIDAY_DATE")
	public Date getHolidayDate() {
		return holidayDate;
	}

	/**
	 * @param holidayDate new value for holidayDate 
	 */
	public void setHolidayDate(Date holidayDate) {
		this.holidayDate = holidayDate;
	}

	/**
	 * @return holidayType
	 */
	@Basic
	@Column(name = "HOLIDAY_TYPE", length = 2)
	public String getHolidayType() {
		return holidayType;
	}

	/**
	 * @param holidayType new value for holidayType 
	 */
	public void setHolidayType(String holidayType) {
		this.holidayType = holidayType;
	}

	/**
	 * @return holidayDescription
	 */
	@Basic
	@Column(name = "HOLIDAY_DESCRIPTION", length = 50)
	public String getHolidayDescription() {
		return holidayDescription;
	}

	/**
	 * @param holidayDescription new value for holidayDescription 
	 */
	public void setHolidayDescription(String holidayDescription) {
		this.holidayDescription = holidayDescription;
	}
	/**
	 * get userInfo
	 */
	@ManyToOne
	@JoinColumn(name = "CREATED_BY")
	public UserInfo getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * set userInfo
	 */
	public void setCreatedBy(UserInfo createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return createdDate
	 */
	@Basic
	@Column(name = "CREATED_DATE")
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate new value for createdDate 
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * get userInfo
	 */
	@ManyToOne
	@JoinColumn(name = "MODIFIED_BY")
	public UserInfo getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * set userInfo
	 */
	public void setModifiedBy(UserInfo modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return modifiedDate
	 */
	@Basic
	@Column(name = "MODIFIED_DATE")
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate new value for modifiedDate 
	 */
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return status
	 */
	@Basic
	@Column(name = "STATUS")
	public Long getStatus() {
		return status;
	}

	/**
	 * @param status new value for status 
	 */
	public void setStatus(Long status) {
		this.status = status;
	}


	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getId());
	}	

	@Override
	public String toString(){
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd");
		return sdf.format(holidayDate)+" for "+countryName;
	}
}