package com.bsf.ppm;

import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.SelectableAuditableEntity;

/**
 * <p>Pojo mapping TABLE IPPUSER.USER_GROUP</p>
 * @author Kaza
 * 
 */
@Entity
@Table(name = "USER_GROUP")
@SuppressWarnings("serial")
public class UserGroup  extends SelectableAuditableEntity{

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute name.
	 */
	private String name;
	
	/**
	 * Attribute adMapping.
	 */
	private String adMapping;
	
	/**
	 * Attribute application
	 */
	 private Application application;	

	 /**
		 * Attribute createdBy.
		 */
	 private UserInfo createdBy;
		
		/**
		 * Attribute createdDate.
		 */
		private Timestamp createdDate;
		
		/**
		 * Attribute modifiedBy.
		 */
		private UserInfo modifiedBy;	
		
		/**
		 * Attribute modifiedDate.
		 */
		private Timestamp modifiedDate;
		
		/**
		 * Attribute status.
		 */
		private Long status;
	 
	/**
	 * List of GroupPrivileges
	 */
	private Set<BusinessObject> businessObject = null;
	
	/**
	 * @return id
	 */
	@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "groupIdGen")
	@TableGenerator(name = "groupIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "GROUP_ID", valueColumnName = "ID_VALUE")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return name
	 */
	@Basic
	@Column(name = "NAME", length = 60)
		public String getName() {
		return name;
	}

	/**
	 * @param name new value for name 
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return adMapping
	 */
	@Basic
	@Column(name = "AD_MAPPING", length = 150)
		public String getAdMapping() {
		return adMapping;
	}

	/**
	 * @param adMapping new value for adMapping 
	 */
	public void setAdMapping(String adMapping) {
		this.adMapping = adMapping!=null?adMapping.toUpperCase():adMapping; //made upper case as it is retrieved in upper case from directory server.
	}
	
	/**
	 * get application
	 */
	@ManyToOne
	@JoinColumn(name = "APPLICATION_NAME", referencedColumnName = "APPLICATION_NAME")
	public Application getApplication() {
		return this.application;
	}
	
	/**
	 * set application
	 */
	public void setApplication(Application application) {
		this.application = application;
	}

	
	@ManyToMany(fetch=FetchType.EAGER)
	@JoinTable(name="GROUP_PRIVILEGES",
	joinColumns=@JoinColumn(name="GROUP_ID"),
	inverseJoinColumns=@JoinColumn(name="BUSINESS_OBJECT_ID"))
	 public Set<BusinessObject> getBusinessObject() { 
		return businessObject;
	}

	public void setBusinessObject(Set<BusinessObject> businessObject) {
		this.businessObject = businessObject;
	}

	/**
		 * @return createdBy
		 */
		@ManyToOne(cascade=CascadeType.MERGE)
		@JoinColumn(name = "CREATED_BY")
		public UserInfo getCreatedBy() {
			return createdBy;
		}

		/**
		 * @param createdBy new value for createdBy 
		 */
		public void setCreatedBy(UserInfo createdBy) {
			this.createdBy = createdBy;
		}
		
		/**
		 * @return createdDate
		 */
		@Basic
		@Column(name = "CREATED_DATE")
			public Timestamp getCreatedDate() {
			return createdDate;
		}

		/**
		 * @param createdDate new value for createdDate 
		 */
		public void setCreatedDate(Timestamp createdDate) {
			this.createdDate = createdDate;
		}
		
		/**
		 * @return modifiedBy
		 */
		@ManyToOne(cascade=CascadeType.MERGE)
		@JoinColumn(name = "MODIFIED_BY")
			public UserInfo getModifiedBy() {
			return modifiedBy;
		}

		/**
		 * @param modifiedBy new value for modifiedBy 
		 */
		public void setModifiedBy(UserInfo modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		
		/**
		 * @return modifiedDate
		 */
		@Basic
		@Column(name = "MODIFIED_DATE")
			public Timestamp getModifiedDate() {
			return modifiedDate;
		}

		/**
		 * @param modifiedDate new value for modifiedDate 
		 */
		public void setModifiedDate(Timestamp modifiedDate) {
			this.modifiedDate = modifiedDate;
		}
		
		/**
		 * @return status
		 */
		@Basic
		@Column(name = "STATUS")
			public Long getStatus() {
			return status;
		}

		/**
		 * @param status new value for status 
		 */
		public void setStatus(Long status) {
			this.status = status;
		}
	 
	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getId());
	}




}