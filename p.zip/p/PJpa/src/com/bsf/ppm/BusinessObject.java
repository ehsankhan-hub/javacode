package com.bsf.ppm;

import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;
import com.bsf.ipp.dao.Cacheable;

/**
 * <p>
 * Pojo mapping TABLE IPPUSER.BUSINESS_OBJECT
 * </p>
 * 
 * @author Kaza
 * 
 */
@Entity
@Table(name = "BUSINESS_OBJECT")
@SuppressWarnings("serial")
@NamedQueries( {
@NamedQuery(
			name="BusinessObject.findMAXforSADDynamicQueue",
			query = "select max(id) from BusinessObject o where  o.objectparent='602010000'")})

public class BusinessObject implements Cacheable {

	/**
	 * Attribute id.
	 */
	private Long id;

	/**
	 * Attribute objectname.
	 */
	private String objectname;

	/**
	 * Attribute displaytag.
	 */
	private String displaytag;

	/**
	 * Attribute url.
	 */
	private String url;

	/**
	 * Attribute action.
	 */
	private String action;

	/**
	 * Attribute objectparent.
	 */
	private Long objectparent;

	/**
	 * Attribute objecthierarchy.
	 */
	private String objecthierarchy;

	private String objecthierarchyId;

	public BusinessObject(long i) {
		id = i;
	}

	public BusinessObject() {

	}

	@Transient
	public String getObjecthierarchyId() {
		if (objecthierarchy != null && objecthierarchy.length() > 3)
			objecthierarchyId = objecthierarchy.substring(3).replace("/", ":");
		else
			objecthierarchyId="";
		return objecthierarchyId;
	}

	public void setObjecthierarchyId(String objecthierarchyId) {
		this.objecthierarchyId = objecthierarchyId;
	}

	/**
	 * Attribute objectlevel.
	 */
	private Short objectlevel;

	/**
	 * Attribute objectstatus.
	 */
	private Short objectstatus;

	/**
	 * Attribute application
	 */
	private Application application;

	/**
	 * List of GroupPrivileges
	 */
	private Set<UserGroup> userGroups = null;

	private boolean selected = false;

	@Transient
	public boolean getSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	private String childList = "";

	private String parentList = "";

	@Transient
	public String getParentList() {
		return parentList;
	}

	public void setParentList(String parentList) {
		this.parentList = parentList;
	}

	@Transient
	public String getChildList() {
		return childList;
	}

	public void setChildList(String childList) {
		this.childList = childList;
	}

	/**
	 * @return id
	 */
	@Basic
	@Id
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            new value for id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return objectname
	 */
	@Basic
	@Column(name = "OBJECTNAME", length = 60)
	public String getObjectname() {
		return objectname;
	}

	/**
	 * @param objectname
	 *            new value for objectname
	 */
	public void setObjectname(String objectname) {
		this.objectname = objectname;
	}

	/**
	 * @return displaytag
	 */
	@Basic
	@Column(name = "DISPLAYTAG", length = 60)
	public String getDisplaytag() {
		return displaytag;
	}

	/**
	 * @param displaytag
	 *            new value for displaytag
	 */
	public void setDisplaytag(String displaytag) {
		this.displaytag = displaytag;
	}

	/**
	 * @return url
	 */
	@Basic
	@Column(name = "URL", length = 200)
	public String getUrl() {
		return url;
	}

	/**
	 * @param url
	 *            new value for url
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return action
	 */
	@Basic
	@Column(name = "ACTION", length = 200)
	public String getAction() {
		return action;
	}

	/**
	 * @param action
	 *            new value for action
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @return objectparent
	 */
	@Basic
	@Column(name = "OBJECTPARENT")
	public Long getObjectparent() {
		return objectparent;
	}

	/**
	 * @param objectparent
	 *            new value for objectparent
	 */
	public void setObjectparent(Long objectparent) {
		this.objectparent = objectparent;
	}

	/**
	 * @return objecthierarchy
	 */
	@Basic
	@Column(name = "OBJECTHIERARCHY", length = 1000)
	public String getObjecthierarchy() {
		return objecthierarchy;
	}

	/**
	 * @param objecthierarchy
	 *            new value for objecthierarchy
	 */
	public void setObjecthierarchy(String objecthierarchy) {
		this.objecthierarchy = objecthierarchy;
	}

	/**
	 * @return objectlevel
	 */
	@Basic
	@Column(name = "OBJECTLEVEL")
	public Short getObjectlevel() {
		return objectlevel;
	}

	/**
	 * @param objectlevel
	 *            new value for objectlevel
	 */
	public void setObjectlevel(Short objectlevel) {
		this.objectlevel = objectlevel;
	}

	/**
	 * @return objectstatus
	 */
	@Basic
	@Column(name = "OBJECTSTATUS")
	public Short getObjectstatus() {
		return objectstatus;
	}

	/**
	 * @param objectstatus
	 *            new value for objectstatus
	 */
	public void setObjectstatus(Short objectstatus) {
		this.objectstatus = objectstatus;
	}

	/**
	 * get application
	 */
	@ManyToOne
	@JoinColumn(name = "APPLICATION_NAME")
	public Application getApplication() {
		return this.application;
	}

	/**
	 * set application
	 */
	public void setApplication(Application application) {
		this.application = application;
	}

	@ManyToMany
	@JoinTable(name = "GROUP_PRIVILEGES", joinColumns = @JoinColumn(name = "BUSINESS_OBJECT_ID"), inverseJoinColumns = @JoinColumn(name = "GROUP_ID"))
	public Set<UserGroup> getUserGroups() {
		return userGroups;
	}

	public void setUserGroups(Set<UserGroup> userGroups) {
		this.userGroups = userGroups;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof BusinessObject) {
			BusinessObject busObj = (BusinessObject) obj;
			if (this.id.longValue() == busObj.id.longValue()) {
				return true;
			}
		}

		return false;

	}

	@Transient
	public String getKey() {
		// TODO Auto-generated method stub
		return getId() + "";
	}

}