package com.bsf.ppm;

import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.SelectableAuditableEntity;

/**
 * <p>Pojo mapping TABLE MAIL_TEMPLATE</p>
 * @author Kaza
 * 
 */
@Entity
@NamedQuery(name = "MailTemplate.findAll", 
	    query = "select o from MailTemplate o")
@Table(name = "MAIL_TEMPLATE")
@SuppressWarnings("serial")
public class MailTemplate extends SelectableAuditableEntity {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute subject.
	 */
	private String subject;
	
	/**
	 * Attribute message.
	 */
	private String message;
	
	/**
	 * Attribute mailFrom.
	 */
	private String mailFrom;
	
	/**
	 * Attribute mailTo.
	 */
	private String mailTo;
	
	/**
	 * Attribute cc.
	 */
	private String cc;
	
	/**
	 * Attribute bcc.
	 */
	private String bcc;
	
	/**
	 * Attribute status.
	 */
	private Long status;
	
	private UserInfo createdBy;
	
	private Timestamp createdDate;
	
	private UserInfo modifiedBy;
	
	private Timestamp modifiedDate;
	
	private Application applicationId;
	/**
	 * @return id
	 */
	@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "mailTemplateIdGen")
	@TableGenerator(name = "mailTemplateIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "MAIL_TEMPLATE", valueColumnName = "ID_VALUE")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return subject
	 */
	@Basic
	@Column(name = "SUBJECT", length = 250)
		public String getSubject() {
		return subject;
	}

	/**
	 * @param subject new value for subject 
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	/**
	 * @return message
	 */
	@Basic
	@Column(name = "MESSAGE", length = 2500)
		public String getMessage() {
		return message;
	}

	/**
	 * @param message new value for message 
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
	/**
	 * @return mailFrom
	 */
	@Basic
	@Column(name = "MAIL_FROM", length = 100)
		public String getMailFrom() {
		return mailFrom;
	}

	/**
	 * @param mailFrom new value for mailFrom 
	 */
	public void setMailFrom(String mailFrom) {
		this.mailFrom = mailFrom;
	}
	
	/**
	 * @return mailTo
	 */
	@Basic
	@Column(name = "MAIL_TO", length = 1024)
		public String getMailTo() {
		return mailTo;
	}

	/**
	 * @param mailTo new value for mailTo 
	 */
	public void setMailTo(String mailTo) {
		this.mailTo = mailTo;
	}
	
	/**
	 * @return cc
	 */
	@Basic
	@Column(name = "CC", length = 1024)
		public String getCc() {
		return cc;
	}

	/**
	 * @param cc new value for cc 
	 */
	public void setCc(String cc) {
		this.cc = cc;
	}
	
	/**
	 * @return bcc
	 */
	@Basic
	@Column(name = "BCC", length = 1024)
		public String getBcc() {
		return bcc;
	}

	/**
	 * @param bcc new value for bcc 
	 */
	public void setBcc(String bcc) {
		this.bcc = bcc;
	}
	
	/**
	 * @return status
	 */
	@Basic
	@Column(name = "STATUS")
		public Long getStatus() {
		return status;
	}

	/**
	 * @param status new value for status 
	 */
	public void setStatus(Long status) {
		this.status = status;
	}

	@Override
	@Transient
	public String getPk() {
		return String.valueOf(id);
	}
	
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(UserInfo createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdBy
	 */
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name="CREATED_BY")
	public UserInfo getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdDate
	 */
	@Basic
	@Column(name="CREATED_DATE")
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(UserInfo modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return the modifiedBy
	 */
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "MODIFIED_BY")
	public UserInfo getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return the modifiedDate
	 */
	@Basic
	@Column(name="MODIFIED_DATE")
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param applicationId the applicationId to set
	 */
	public void setApplicationId(Application applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * @return the applicationId
	 */
	@ManyToOne
	@JoinColumn(name="APPLICATION_NAME")
	public Application getApplicationId() {
		return applicationId;
	}
	
	@Transient
	public String getFormattedMailTo(){
		if(mailTo !=null){
			return mailTo.replaceAll(",", ", ");
		}
	   return null;
	}

}