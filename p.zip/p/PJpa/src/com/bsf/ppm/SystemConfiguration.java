package com.bsf.ppm;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

/**
 * <p>Pojo mapping TABLE IPPUSER.SYSTEM_CONFIGURATION</p>
 * @author Kaza
 * 
 */
@Entity
@NamedQuery(name = "SystemConfiguration.findAll", 
	    query = "select o from SystemConfiguration o")
@Table(name = "SYSTEM_CONFIGURATION")
@SuppressWarnings("serial")
public class SystemConfiguration implements Serializable {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute paramValue.
	 */
	private String paramValue;
	
	/**
	 * Attribute systemTypeParameter
	 */
	 private SystemTypeParameter systemTypeParameter;	

	/**
	 * Attribute backendSystem
	 */
	 private BackendSystem backendSystem;	

	/**
	 * @return id
	 */
	@Basic
	@Id
	@GeneratedValue(strategy=GenerationType.TABLE, generator = "systemConfigIdGen")
	@TableGenerator(name = "systemConfigIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "SYSTEM_CONFIGURATION", valueColumnName = "ID_VALUE")
	@Column(name = "ID",nullable = false)  	
	public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return paramValue
	 */
	@Basic
	@Column(name = "PARAM_VALUE", length = 100)
		public String getParamValue() {
		return paramValue;
	}

	/**
	 * @param paramValue new value for paramValue 
	 */
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	
	/**
	 * get systemTypeParameter
	 */
	@ManyToOne
	@JoinColumn(name = "SYSTEM_TYPE_PARAMETERS_ID")
	public SystemTypeParameter getSystemTypeParameter() {
		return this.systemTypeParameter;
	}
	
	/**
	 * set systemTypeParameter
	 */
	public void setSystemTypeParameter(SystemTypeParameter systemTypeParameter) {
		this.systemTypeParameter = systemTypeParameter;
	}

	/**
	 * get backendSystem
	 */
	@ManyToOne
	@JoinColumn(name = "BACKEND_SYSTEM_ID" )
	public BackendSystem getBackendSystem() {
		return this.backendSystem;
	}
	
	/**
	 * set backendSystem
	 */
	public void setBackendSystem(BackendSystem backendSystem) {
		this.backendSystem = backendSystem;
	}



}