package com.bsf.ppm;

import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import com.bsf.ipp.dao.SelectableAuditableEntity;

/**
 * <p>
 * Pojo mapping TABLE IPPUSER.FTS_POSTING_LOG
 * </p>
 * 
 * @author Kaza
 * 
 */
@Entity
@Table(name = "FTS_POSTING_LOG")
@SuppressWarnings("serial")
@NamedQuery(name = "FtsPostingLog.findByFtsReference", query = "select obj from FtsPostingLog obj "
		+ " where obj.ftsReference=:ftsReference order by id desc")
public class FtsPostingLog extends SelectableAuditableEntity {

	/**
	 * Attribute id.
	 */
	private Long id;

	/**
	 * Attribute ftsMessageSent.
	 */
	private String ftsMessageSent;

	/**
	 * Attribute messageSentTime.
	 */
	private Timestamp messageSentTime;

	/**
	 * Attribute ftsMessageRecieved.
	 */
	private String ftsMessageRecieved;

	/**
	 * Attribute messageReceivedTime.
	 */
	private Timestamp messageReceivedTime;

	/**
	 * Attribute applicationId.
	 */
	private String applicationId;
	/**
	 * Attribute applicationId.
	 */
	private String ftsReference;

	/**
	 * @return id
	 */
	@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "ftsPostingLogIdGen")
	@TableGenerator(name = "ftsPostingLogIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "FTS_POSTING_LOG", valueColumnName = "ID_VALUE")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            new value for id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return ftsMessageSent
	 */
	@Basic
	@Column(name = "FTS_MESSAGE_SENT", length = 1024)
	public String getFtsMessageSent() {
		return ftsMessageSent;
	}

	/**
	 * @param ftsMessageSent
	 *            new value for ftsMessageSent
	 */
	public void setFtsMessageSent(String ftsMessageSent) {
		this.ftsMessageSent = ftsMessageSent;
	}

	/**
	 * @return messageSentTime
	 */
	@Basic
	@Column(name = "MESSAGE_SENT_TIME")
	public Timestamp getMessageSentTime() {
		return messageSentTime;
	}

	/**
	 * @param messageSentTime
	 *            new value for messageSentTime
	 */
	public void setMessageSentTime(Timestamp messageSentTime) {
		this.messageSentTime = messageSentTime;
	}

	/**
	 * @return ftsMessageRecieved
	 */
	@Basic
	@Column(name = "FTS_MESSAGE_RECIEVED", length = 1024)
	public String getFtsMessageRecieved() {
		return ftsMessageRecieved;
	}

	/**
	 * @param ftsMessageRecieved
	 *            new value for ftsMessageRecieved
	 */
	public void setFtsMessageRecieved(String ftsMessageRecieved) {
		this.ftsMessageRecieved = ftsMessageRecieved;
	}

	/**
	 * @return messageReceivedTime
	 */
	@Basic
	@Column(name = "MESSAGE_RECEIVED_TIME")
	public Timestamp getMessageReceivedTime() {
		return messageReceivedTime;
	}

	/**
	 * @param messageReceivedTime
	 *            new value for messageReceivedTime
	 */
	public void setMessageReceivedTime(Timestamp messageReceivedTime) {
		this.messageReceivedTime = messageReceivedTime;
	}

	/**
	 * @return applicationId
	 */
	@Basic
	@Column(name = "APPLICATION")
	public String getApplicationId() {
		return applicationId;
	}

	/**
	 * @param applicationId
	 *            new value for applicationId
	 */
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getId());
	}

	/**
	 * @return ftsReference
	 */
	@Basic
	@Column(name = "FTS_REFERENCE", length = 10)
	public String getFtsReference() {
		return ftsReference;
	}

	/**
	 * @param ftsReference
	 *            new value for ftsReference
	 */
	public void setFtsReference(String ftsReference) {
		this.ftsReference = ftsReference;
	}

}