package com.bsf.ppm;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "PPM_STATUS_HISTORY")
@SuppressWarnings("serial")
public class StatusHistory implements Serializable{

private String instReference;

private Date createdDate;

private String changedBy;

private String oldStatus;

private String newStatus;


@Id //@GeneratedValue
@Basic
//@SequenceGenerator(name = "instructionSeq", sequenceName = "PPM_INS_REF")
//@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "instructionSeq")
@Column(name = "INST_REFERENCE")
public String getInstReference() {
	return instReference;
}

public void setInstReference(String instReference) {
	this.instReference = instReference;
}
@Column(name="CHANGE_DATE")
public Date getCreatedDate() {
	return createdDate;
}

public void setCreatedDate(Date createdDate) {
	this.createdDate = createdDate;
}
@Column(name="CHANGED_BY")
public String getChangedBy() {
	return changedBy;
}

public void setChangedBy(String changedBy) {
	this.changedBy = changedBy;
}
@Column(name="OLD_STATUS")
public String getOldStatus() {
	if(oldStatus!=null){
		if(oldStatus.equalsIgnoreCase("NEW")){
			oldStatus="Sent for validation";
		}
		if(oldStatus.equalsIgnoreCase("ACT")){
			oldStatus="Active";
		}
		else if(oldStatus.equalsIgnoreCase("RJT")){
			oldStatus="Rejected";
		}
		
		else if(oldStatus.equalsIgnoreCase("SUI")){
			oldStatus="Initiated for Suspend";
		}
		else if(newStatus.equalsIgnoreCase("SUS")){
			oldStatus="Suspended";
		}
		else if(oldStatus.equalsIgnoreCase("MOD")){
			oldStatus="Initiated for Modification";
		}
		else if(oldStatus.equalsIgnoreCase("CLS")){
			oldStatus="Closed";
		}
	}
	return oldStatus;
}

public void setOldStatus(String oldStatus) {
	this.oldStatus = oldStatus;
}
@Column(name="NEW_STATUS")
public String getNewStatus() {
	if(newStatus!=null){
		if(newStatus.equalsIgnoreCase("NEW")){
			newStatus="Sent for validation";
		}
		if(newStatus.equalsIgnoreCase("ACT")){
			newStatus="Active";
		}
		else if(newStatus.equalsIgnoreCase("RJT")){
			newStatus="Rejected";
		}
		
		else if(newStatus.equalsIgnoreCase("SUI")){
			newStatus="Initiated for Suspend";
		}
		else if(newStatus.equalsIgnoreCase("SUS")){
			newStatus="Suspended";
		}
		else if(newStatus.equalsIgnoreCase("MOD")){
			newStatus="Initiated for Modification";
		}
		else if(newStatus.equalsIgnoreCase("CLS")){
			newStatus="Closed";
		}
	}
	return newStatus;
}

public void setNewStatus(String newStatus) {
	this.newStatus = newStatus;
}






	
}
