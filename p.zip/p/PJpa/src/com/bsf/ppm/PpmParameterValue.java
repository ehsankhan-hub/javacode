package com.bsf.ppm;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.GenericGenerator;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.SelectableAuditableEntity;

/**
 * <p>Pojo mapping TABLE OEPAYSD.PPM_GROUP</p>
 *
 * <p>Generated at Wed Aug 10 12:21:25 AST 2016</p>
 * @author Salto-db Generator v1.0.16 / EJB3
 * 
 */
@Entity
@Table(name = "PPM_PARAMETER_VALUE")
@SuppressWarnings("serial")

public class PpmParameterValue extends SelectableAuditableEntity  {
    
	
	/**
	 * Attribute paramTypeId.
	 */
	private int paramTypeId;
	
	/**
	 * Attribute paramType.
	 */
	private String parmtypecode;
	
	/**
	 * Attribute groupCode.
	 */
	private String groupCode;
	
	/**
	 * Attribute fieldName.
	 */
	private String fieldName;
	
	
	/**
	 * Attribute value1.
	 */
	private String value1;
	
	/**
	 * Attribute value2.
	 */
	private String value2;
	
	/**
	 * Attribute value3.
	 */
	private String value3;
	
	
	/**
	 * Attribute value3.
	 */
	private String value4;
	
	
	
	/**
	 * Attribute value3.
	 */
	private String value5;
	
	/**
	 * Attribute createDate.
	 */
	private Date createDate;
	
	/**
	 * Attribute createdBy.
	 */
	private UserInfo createdBy;
	
	/**
	 * Attribute updateDate.
	 */
	private Date updateDate;
	
	/**
	 * Attribute updatedBy.
	 */
	private UserInfo updatedBy;
	
	protected boolean selected;
	
	private PpmParameterType ppmParameterType;
	
	public PpmParameterValue(){
		
	}
	/*@XmlTransient
	@Transient
	public void setParmtypecode(String parmtypecode) {
		this.parmtypecode = parmtypecode;
	}
	public String getParmtypecode() {
		return parmtypecode;
	}*/
	
	
	
	@XmlTransient
	@Transient
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	
	@XmlTransient
	@Transient
	public String getValue1() {
		return value1;
	}
	public void setValue1(String value1) {
		this.value1 = value1;
	}

	@EmbeddedId
	private PpmParameterValuePK ppmParameterValue=new PpmParameterValuePK();
	
	@Basic
	@Id
	public PpmParameterValuePK getPpmParameterValue() {
		return ppmParameterValue;
	}
	public void setPpmParameterValue(PpmParameterValuePK ppmParameterValue) {
		this.ppmParameterValue = ppmParameterValue;
	}
	
	@Column(name="FIELD_NAME")	
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	
	@Column(name="VALUE2")	
	public String getValue2() {
		return value2;
	}
	public void setValue2(String value2) {
		this.value2 = value2;
	}
	@Column(name="VALUE3")	
	public String getValue3() {
		return value3;
	}
	public void setValue3(String value3) {
		this.value3 = value3;
	}
	@Column(name="VALUE4")	
	public String getValue4() {
		return value4;
	}
	public void setValue4(String value4) {
		this.value4 = value4;
	}
	@Column(name="VALUE5")	
	public String getValue5() {
		return value5;
	}
	public void setValue5(String value5) {
		this.value5 = value5;
	}
	 
	/**
	 * @return createDate
	 */
	@Basic
	@Column(name = "CREATE_DATE")
		public Date getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate new value for createDate 
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	
	/**
	 * @return createdBy
	 */
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "CREATED_BY")
		public UserInfo getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy new value for createdBy 
	 */
	public void setCreatedBy(UserInfo createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * @return updateDate
	 */
	@Basic
	@Column(name = "UPDATE_DATE")
		public Date getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate new value for updateDate 
	 */
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	
	/**
	 * @return updatedBy
	 */
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "UPDATED_BY")
		public UserInfo getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy new value for updatedBy 
	 */
	public void setUpdatedBy(UserInfo updatedBy) {
		this.updatedBy = updatedBy;
	}
    
	@XmlTransient
	@Transient
	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
	this.selected = selected;
	}
	
	@ManyToOne
	@JoinColumn(name = "PARAM_TYPE_CODE",insertable = false, updatable = false)
	public PpmParameterType getPpmParameterType() {
		return ppmParameterType;
	}
	public void setPpmParameterType(PpmParameterType ppmParameterType) {
		this.ppmParameterType = ppmParameterType;
	}

	
	

	@Override
	@XmlTransient
	@Transient
	public String getPk() {
	return ppmParameterValue.getParmtypecode();
	}
	
	
	

	@SuppressWarnings("serial")
	@Embeddable
	public static class PpmParameterValuePK implements Serializable {
		private String parmtypecode;	
		private String value1;
		private String groupCode;
		//private String value2;
		private static final long serialVersionUID = 1321L;
		
		@Column(name="PARAM_TYPE_CODE")
		public String getParmtypecode() {
			return parmtypecode;
		}

		public void setParmtypecode(String parmtypecode) {
			this.parmtypecode = parmtypecode;
		}

		
		@Column(name="VALUE1")
		public String getValue1() {
			return value1;
		}
		
		public void setValue1(String value1) {
			this.value1 = value1;
		}
		@Column(name="GROUP_CODE")
		public String getGroupCode() {
			return groupCode;
		}
		public void setGroupCode(String groupCode) {
			this.groupCode = groupCode;
		}
		
		public PpmParameterValuePK(){
			
		}
	     public PpmParameterValuePK(String parmtypecode,String groupCode,String value1){
		 super();
	      this.parmtypecode=parmtypecode;
		 this.value1=value1;
		 this.groupCode=groupCode;
		}
	     // Must have a equals method
	     @Override
	 	 public boolean equals(Object obj) {
		        if (obj == null) return false;
		        if (!this.getClass().equals(obj.getClass())) return false;
		         
		        PpmParameterValuePK obj2 = (PpmParameterValuePK)obj;
		 
		        if (this.parmtypecode.equals(obj2.getParmtypecode()) &&
		            this.groupCode.equals(obj2.getGroupCode()) && this.value1.equals(obj2.getValue1())) {
		            return true;
		        }
		        return false;
		    }
	     // Must have a hashCode method
	     @Override
	      public int hashCode() {      
		        int tmp = 0;
		        tmp = (parmtypecode + groupCode+value1).hashCode();
		        return tmp;
		    }
		}




}


