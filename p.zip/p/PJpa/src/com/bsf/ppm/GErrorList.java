package com.bsf.ppm;


import javax.persistence.Basic;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.bsf.ipp.dao.SelectableAuditableEntity;

/**
 * <p>Pojo mapping TABLE G_ERROR_LIST</p>
 *
 * @author Ehsan
 * 
 */
@Entity
@NamedQuery(name = "GErrorList.findAll", 
	    query = "select o from GErrorList o")
@Table(name = "G_ERROR_LIST")
@SuppressWarnings("serial")
public class GErrorList extends SelectableAuditableEntity {

	
	private String errorCode;
	private String errorMsg;
	private String errorDescription;
	private String systemCode;
	private String errorMsgA;
	
	@Id
	@Basic
	@Column(name = "ERROR_CODE",nullable = false, length = 10)
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	@Basic
	@Column(name = "ERROR_MSG", length = 120)
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	
	@Basic
	@Column(name = "ERROR_DESCRIPTION", length = 1000)
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	
	@Basic
	@Column(name = "SYSTEM_CODE", length = 6)
	public String getSystemCode() {
		return systemCode;
	}
	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}
	
	@Basic
	@Column(name = "ERROR_MSG_A", length = 150)
	public String getErrorMsgA() {
		return errorMsgA;
	}
	public void setErrorMsgA(String errorMsgA) {
		this.errorMsgA = errorMsgA;
	}
	
	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getErrorCode());
	}

}