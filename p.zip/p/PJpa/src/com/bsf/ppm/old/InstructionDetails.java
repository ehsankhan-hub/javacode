package com.bsf.ppm.old;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.bsf.ppm.old.DomesticBank;
@Entity
@Table(name = "PPM_INSTRUCTIONS_DETAILS")
@SuppressWarnings("serial")
public class InstructionDetails implements Serializable{
	
/**
	 * 
	 */
private static final long serialVersionUID = 1L;

private Long instDtlId;

private Long instReference;

private String instAccNum;

private String instAccCrncy;

private String benAcc;

private String benAccCrncy;

private String benName;

private String benBank;

private String instTrnsTyp;


private String samaReference;

private String accountstatus;

private String benPftCtr; 

private String custName;

private String relatedDoc;

private String docDate;

private String docRcvDate;

@Id //@GeneratedValue
@Basic
//@SequenceGenerator(name = "instructionSeq", sequenceName = "PPM_INS_DTL_ID" )
//@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "instructionSeq")
@Column(name="INST_DTL_ID")
public Long getInstDtlId() {
	return instDtlId;
}
public void setInstDtlId(Long instDtlId) {
	this.instDtlId = instDtlId;
}

@Column(name="INST_REFERENCE")
public Long getInstReference() {
	return instReference;
}



public void setInstReference(Long instReference) {
	this.instReference = instReference;
}

@Column(name="INST_ACT_NO")
public String getInstAccNum() {
	return instAccNum;
}

public void setInstAccNum(String instAccNum) {
	this.instAccNum = instAccNum;
}
@Column(name="INST_ACT_CRNCY")
public String getInstAccCrncy() {
	return instAccCrncy;
}

public void setInstAccCrncy(String instAccCrncy) {
	this.instAccCrncy = instAccCrncy;
}
@Column(name="BEN_ACT")
public String getBenAcc() {
	return benAcc;
}

public void setBenAcc(String benAcc) {
	this.benAcc = benAcc;
}
@Column(name="BEN_ACT_CRNCY")
public String getBenAccCrncy() {
	return benAccCrncy;
}

public void setBenAccCrncy(String benAccCrncy) {
	this.benAccCrncy = benAccCrncy;
}
@Column(name="BEN_NAME")
public String getBenName() {
	return benName;
}

public void setBenName(String benName) {
	this.benName = benName;
}
@Column(name="BEN_BANK")
public String getBenBank() {
	return benBank;
}

public void setBenBank(String benBank) {
	this.benBank = benBank;
}
@Column(name="INST_TRANS_TYPE")
public String getInstTrnsTyp() {
	return instTrnsTyp;
}
public void setInstTrnsTyp(String instTrnsTyp) {
	this.instTrnsTyp = instTrnsTyp;
}
@Column(name="RELATED_REFERENCE")
public String getSamaReference() {
	return samaReference;
}
public void setSamaReference(String samaReference) {
	this.samaReference = samaReference;
}


@Column(name = "ACT_STATUS")
public String getAccountstatus() {
	return accountstatus;
}

public void setAccountstatus(String accountstatus) {
	this.accountstatus = accountstatus;
}
@Column(name="BEN_PFTCTR")
public String getBenPftCtr() {
	return benPftCtr;
}
public void setBenPftCtr(String benPftCtr) {
	this.benPftCtr = benPftCtr;
}
@Column(name="CUST_NAME")
public String getCustName() {
	return custName;
}
public void setCustName(String custName) {
	this.custName = custName;
}
@Column(name="RELATED_DOC")
public String getRelatedDoc() {
	return relatedDoc;
}
public void setRelatedDoc(String relatedDoc) {
	this.relatedDoc = relatedDoc;
}
@Column(name="DOC_DATE")
public String getDocDate() {
	return docDate;
}
public void setDocDate(String docDate) {
	this.docDate = docDate;
}
@Column(name="DOC_RCV_DATE")
public String getDocRcvDate() {
	return docRcvDate;
}
public void setDocRcvDate(String docRcvDate) {
	this.docRcvDate = docRcvDate;
}










}
