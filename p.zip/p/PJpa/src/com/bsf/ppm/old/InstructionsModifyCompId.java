package com.bsf.ppm.old;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Id;

@Embeddable
public class InstructionsModifyCompId implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 6252991836954561796L;
	private Long id;
	private Long instRefer;
	private Long instDtlId;
	private String fieldName;
	private String oldValue;
	private String newVlaue;
	private String isApplied;
	private Date modifiedDate;
	private String modifiedBy;
	private Date approvedDate;
	private String approvedBy;
	
	
	@Column(name="MODIFY_REF")
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	@Column(name="INST_REFERENCE",insertable = false, updatable = false)
	public Long getInstRefer() {
		return instRefer;
	}
	public void setInstRefer(Long instRefer) {
		this.instRefer = instRefer;
	}
	@Column(name="INST_DTL_ID",insertable = false, updatable = false)
	public Long getInstDtlId() {
		return instDtlId;
	}
	public void setInstDtlId(Long instDtlId) {
		this.instDtlId = instDtlId;
	}
	@Column(name="FIELD_NAME",insertable = false, updatable = false)
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	@Column(name="OLD_VALUE",insertable = false, updatable = false)
	public String getOldValue() {
		return oldValue;
	}
	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}
	@Column(name="NEW_VALUE",insertable = false, updatable = false)
	public String getNewVlaue() {
		return newVlaue;
	}
	public void setNewVlaue(String newVlaue) {
		this.newVlaue = newVlaue;
	}
	@Column(name="IS_APPLIED",insertable = false, updatable = false)
	public String getIsApplied() {
		return isApplied;
	}

	public void setIsApplied(String isApplied) {
		this.isApplied = isApplied;
	}
	@Column(name="MODIFIED_DATE",insertable = false, updatable = false)
	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	@Column(name="MODIFIED_BY",insertable = false, updatable = false)
	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	@Column(name="APPROVED_DATE",insertable = false, updatable = false)
	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}
	@Column(name="APPROVED_BY",insertable = false, updatable = false)
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}




		
	}
