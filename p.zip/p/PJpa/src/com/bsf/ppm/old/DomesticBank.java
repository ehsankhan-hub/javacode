
package com.bsf.ppm.old;

import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import com.bsf.ipp.dao.SelectableAuditableCacheableEntity;

/**
 * <p>Pojo mapping TABLE IPPUSER.BENEFICIARY_DETAILS</p>
 * @author Zakir
 * 
 */
@Entity
@NamedQueries({
	@NamedQuery(name = "DomesticBank.fetchByIbanClearingCode", query = "select obj from DomesticBank obj " +
			" where obj.ibanClearingCode=:ibanClearingCode and obj.status=:status "),
	@NamedQuery(name = "DomesticBank.fetchByBankCode", query = "select obj from DomesticBank obj " +
			" where obj.bankCode=:bankCode and obj.status=:status "),
	@NamedQuery(name = "DomesticBank.fetchByBankBic", query = "select obj from DomesticBank obj " +
			" where obj.bankBic=:bankBic and obj.status=:status "),
	@NamedQuery(name = "DomesticBank.fetchAllActive", query = "select obj from DomesticBank obj " +
			" where obj.status=:status "),
	@NamedQuery(name = "DomesticBank.updateSequenceByBankCode", query = "update DomesticBank obj " +
			" set obj.bulkSequence=:bulkSequence where obj.bankCode=:bankCode ")
	
})
@Table(name = "DOMESTIC_BANK")
@SuppressWarnings("serial")
public class DomesticBank extends  SelectableAuditableCacheableEntity  {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute bankCode.
	 */
	private String bankCode;
	
	/**
	 * Attribute bankBic.
	 */
	private String bankBic;
	
	/**
	 * Attribute bankName.
	 */
	private String bankName;
	
	/**
	 * Attribute bulkInstructionsCount.
	 */
	private Long bulkInstructionsCount;
	
	/**
	 * Attribute bulkSequence.
	 */
	private Long bulkSequence;
	
	/**
	 * Attribute ibanClearingCode.
	 */
	private String ibanClearingCode;
	
	/**
	 * Attribute createdBy.
	 */
	private String createdBy;
	
	/**
	 * Attribute createdDate.
	 */
	private Timestamp createdDate;
	
	/**
	 * Attribute modifiedBy.
	 */
	private String modifiedBy;
	
	/**
	 * Attribute modifiedDate.
	 */
	private Timestamp modifiedDate;
	
	/**
	 * Attribute status.
	 */
	private Long status;
	
	
	/**
	 * @return id
	 */
	@Basic
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "domesticBankIdGen")
	@TableGenerator(name = "domesticBankIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "DOMESTIC_BANK", valueColumnName = "ID_VALUE")
	@Column(name = "ID")		
	public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return bankCode
	 */
	@Basic
	@Column(name = "BANK_CODE", length = 4)
		public String getBankCode() {
		return bankCode;
	}

	/**
	 * @param bankCode new value for bankCode 
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	
	/**
	 * @return bankBic
	 */
	@Basic
	@Column(name = "BANK_BIC", length = 11)
		public String getBankBic() {
		return bankBic;
	}

	/**
	 * @param bankBic new value for bankBic 
	 */
	public void setBankBic(String bankBic) {
		this.bankBic = bankBic;
	}
	
	/**
	 * @return bankName
	 */
	@Basic
	@Column(name = "BANK_NAME", length = 30)
		public String getBankName() {
		return bankName;
	}

	/**
	 * @param bankName new value for bankName 
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	/**
	 * @return bulkInstructionsCount
	 */
	@Basic
	@Column(name = "BULK_INSTRUCTIONS_COUNT")
		public Long getBulkInstructionsCount() {
		return bulkInstructionsCount;
	}

	/**
	 * @param bulkInstructionsCount new value for bulkInstructionsCount 
	 */
	public void setBulkInstructionsCount(Long bulkInstructionsCount) {
		this.bulkInstructionsCount = bulkInstructionsCount;
	}
	
	/**
	 * @return bulkSequence
	 */
	@Basic
	@Column(name = "BULK_SEQUENCE")
		public Long getBulkSequence() {
		return bulkSequence;
	}

	/**
	 * @param bulkSequence new value for bulkSequence 
	 */
	public void setBulkSequence(Long bulkSequence) {
		this.bulkSequence = bulkSequence;
	}
	
	/**
	 * @return ibanClearingCode
	 */
	@Basic
	@Column(name = "IBAN_CLEARING_CODE", length = 2)
		public String getIbanClearingCode() {
		return ibanClearingCode;
	}

	/**
	 * @param ibanClearingCode new value for ibanClearingCode 
	 */
	public void setIbanClearingCode(String ibanClearingCode) {
		this.ibanClearingCode = ibanClearingCode;
	}
	
	/**
	 * @return createdBy
	 */
	@Basic
	@Column(name = "CREATED_BY")
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy new value for createdBy 
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * @return createdDate
	 */
	@Basic
	@Column(name = "CREATED_DATE")
		public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate new value for createdDate 
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	
	/**
	 * @return modifiedBy
	 */
	@Basic
	@Column(name = "MODIFIED_BY")
	public String getModifiedBy() {
		return modifiedBy;
	}
	/**
	 * @param modifiedBy new value for modifiedBy 
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	/**
	 * @return modifiedDate
	 */
	@Basic
	@Column(name = "MODIFIED_DATE")
		public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate new value for modifiedDate 
	 */
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	/**
	 * @return status
	 */
	@Basic
	@Column(name = "STATUS")
		public Long getStatus() {
		return status;
	}

	/**
	 * @param status new value for status 
	 */
	public void setStatus(Long status) {
		this.status = status;
	}

	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getId());
	}
	
	public String toString(){
		return "[ Bank Code="+getBankCode()+"]";
	}

	@Transient
	public String getKey() {
		
		return getBankCode();
	}

}