package com.bsf.ppm.old;

import java.math.BigDecimal;
import java.util.Date;

public class InstructionListValues {
	private Long instReference;
	private Long instDtlId;
	private String status;
	private BigDecimal totalAmount;
	private String frequency;
	private String samaReference;
	private String accNumber;
	private String custName;
	private BigDecimal instAmount;
	private String startDateH;
	private String endDateH;
	private Date startDateG;
	private Date endDateG;
	private String bakName;
	private String benAcc;
	private String filePath;
	private Long modifyRef;
	private String isApplied;
	private String relatedRefOld;
	private String relatedRefNew;
	private String docDateOld;
	private String docDateNew;
	private String docDateRecOld;
	private String docDateRecNew;
	private String relatedDocOld;
	private String relatedDocNew;
	
	public Long getInstReference() {
		return instReference;
	}
	public void setInstReference(Long instReference) {
		this.instReference = instReference;
	}
	public Long getInstDtlId() {
		return instDtlId;
	}
	public void setInstDtlId(Long instDtlId) {
		this.instDtlId = instDtlId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public BigDecimal getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getSamaReference() {
		return samaReference;
	}
	public void setSamaReference(String samaReference) {
		this.samaReference = samaReference;
	}
	public InstructionListValues(){
		
	}
	public String getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public BigDecimal getInstAmount() {
		return instAmount;
	}
	public void setInstAmount(BigDecimal instAmount) {
		this.instAmount = instAmount;
	}
	public String getStartDateH() {
		return startDateH;
	}
	public void setStartDateH(String startDateH) {
		this.startDateH = startDateH;
	}
	public String getEndDateH() {
		return endDateH;
	}
	public void setEndDateH(String endDateH) {
		this.endDateH = endDateH;
	}
	public Date getStartDateG() {
		return startDateG;
	}
	public void setStartDateG(Date startDateG) {
		this.startDateG = startDateG;
	}
	public Date getEndDateG() {
		return endDateG;
	}
	public void setEndDateG(Date endDateG) {
		this.endDateG = endDateG;
	}
	public String getBakName() {
		return bakName;
	}
	public void setBakName(String bakName) {
		this.bakName = bakName;
	}
	public String getBenAcc() {
		return benAcc;
	}
	public void setBenAcc(String benAcc) {
		this.benAcc = benAcc;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public Long getModifyRef() {
		return modifyRef;
	}
	public void setModifyRef(Long modifyRef) {
		this.modifyRef = modifyRef;
	}
	public String getIsApplied() {
		return isApplied;
	}
	public void setIsApplied(String isApplied) {
		this.isApplied = isApplied;
	}
	public String getRelatedRefOld() {
		return relatedRefOld;
	}
	public void setRelatedRefOld(String relatedRefOld) {
		this.relatedRefOld = relatedRefOld;
	}
	public String getRelatedRefNew() {
		return relatedRefNew;
	}
	public void setRelatedRefNew(String relatedRefNew) {
		this.relatedRefNew = relatedRefNew;
	}
	public String getDocDateOld() {
		return docDateOld;
	}
	public void setDocDateOld(String docDateOld) {
		this.docDateOld = docDateOld;
	}
	public String getDocDateNew() {
		return docDateNew;
	}
	public void setDocDateNew(String docDateNew) {
		this.docDateNew = docDateNew;
	}
	public String getDocDateRecOld() {
		return docDateRecOld;
	}
	public void setDocDateRecOld(String docDateRecOld) {
		this.docDateRecOld = docDateRecOld;
	}
	public String getDocDateRecNew() {
		return docDateRecNew;
	}
	public void setDocDateRecNew(String docDateRecNew) {
		this.docDateRecNew = docDateRecNew;
	}
	public String getRelatedDocOld() {
		return relatedDocOld;
	}
	public void setRelatedDocOld(String relatedDocOld) {
		this.relatedDocOld = relatedDocOld;
	}
	public String getRelatedDocNew() {
		return relatedDocNew;
	}
	public void setRelatedDocNew(String relatedDocNew) {
		this.relatedDocNew = relatedDocNew;
	}
	
	
	
}
