package com.bsf.ppm.old;

import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.SelectableAuditableEntity;

/**
 * <p>Pojo mapping TABLE IPPUSER.BATCH_JOB</p>
 * @author Kaza
 * 
 */
@Entity
@Table(name = "BATCH_JOB")
@SuppressWarnings("serial")
public class BatchJob extends SelectableAuditableEntity  {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute jobName.
	 */
	private String jobName;
	
	/**
	 * Attribute jobDescription.
	 */
	private String jobDescription;
	
	/**
	 * Attribute cronSchedule.
	 */
	private String cronSchedule;
	
	/**
	 * Attribute processorClass.
	 */
	private String processorClass;
	
	/**
	 * Attribute handlerClass.
	 */
	private String handlerClass;
	
	/**
	 * Attribute springBatch.
	 */
	private Long springBatch;
	
	/**
	 * Attribute external.
	 */
	private Long jobType;
	
	/**
	 * Attribute jobStatus.
	 */
	private Long jobStatus;
	
	/**
	 * Attribute isRunning.
	 */
	private boolean running;
	
	/**
	 * Attribute application
	 */
	 private Application application;	

	/**
	 * Attribute backendSystem
	 */
	 private BackendSystem backendSystem;	

	/**
	 * Attribute userInfo
	 */
	 private UserInfo createdBy;	

	/**
	 * Attribute createdDate.
	 */
	private Timestamp createdDate;
	
	/**
	 * Attribute userInfo
	 */
	 private UserInfo modifiedBy;	

	/**
	 * Attribute modifiedDate.
	 */
	private Timestamp modifiedDate;
	
	
	/**
	 * @return id
	 */
	@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "batchJobIdGen")
	@TableGenerator(name = "batchJobIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "BATCH_JOB", valueColumnName = "ID_VALUE")
	@Column(name = "ID")
	public Long getId() {
		return id;
	} 

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return jobName
	 */
	@Basic
	@Column(name = "JOB_NAME", length = 50)
		public String getJobName() {
		return jobName;
	}

	/**
	 * @param jobName new value for jobName 
	 */
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	
	/**
	 * @return jobDescription
	 */
	@Basic
	@Column(name = "JOB_DESCRIPTION", length = 250)
		public String getJobDescription() {
		return jobDescription;
	}

	/**
	 * @param jobDescription new value for jobDescription 
	 */
	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}
	
	/**
	 * @return cronSchedule
	 */
	@Basic
	@Column(name = "CRON_SCHEDULE", length = 50)
		public String getCronSchedule() {
		return cronSchedule;
	}

	/**
	 * @param cronSchedule new value for cronSchedule 
	 */
	public void setCronSchedule(String cronSchedule) {
		this.cronSchedule = cronSchedule;
	}
	
	/**
	 * @return processorClass
	 */
	@Basic
	@Column(name = "PROCESSOR_CLASS", length = 250)
		public String getProcessorClass() {
		return processorClass;
	}

	/**
	 * @param processorClass new value for processorClass 
	 */
	public void setProcessorClass(String processorClass) {
		this.processorClass = processorClass;
	}
	
	/**
	 * @return handlerClass
	 */
	@Basic
	@Column(name = "HANDLER_CLASS", length = 250)
		public String getHandlerClass() {
		return handlerClass;
	}

	/**
	 * @param handlerClass new value for handlerClass 
	 */
	public void setHandlerClass(String handlerClass) {
		this.handlerClass = handlerClass;
	}
	
	/**
	 * @return springBatch
	 */
	@Basic
	@Column(name = "SPRING_BATCH")
		public Long getSpringBatch() {
		return springBatch;
	}

	/**
	 * @param springBatch new value for springBatch 
	 */
	public void setSpringBatch(Long springBatch) {
		this.springBatch = springBatch;
	}
	
	/**
	 * @return external
	 */
	@Basic
	@Column(name = "EXTERNAL")
		public Long getJobType() {
		return jobType;
	}

	/**
	 * @param external new value for external 
	 */
	public void setJobType(Long jobType) {
		this.jobType = jobType;
	}
	
	/**
	 * @return jobStatus
	 */
	@Basic
	@Column(name = "JOB_STATUS")
		public Long getJobStatus() {
		return jobStatus;
	}

	/**
	 * @param jobStatus new value for jobStatus 
	 */
	public void setJobStatus(Long jobStatus) {
		this.jobStatus = jobStatus;
	}
	
	/**
	 * @return the running
	 */
	@Transient
	public boolean isRunning() {
		return running;
	}

	/**
	 * @param running the running to set
	 */
	public void setRunning(boolean running) {
		this.running = running;
	}

	/**
	 * get application
	 */
	@ManyToOne
	@JoinColumn(name = "APPLICATION_NAME")
	public Application getApplication() {
		return this.application;
	}
	
	/**
	 * set application
	 */
	public void setApplication(Application application) {
		this.application = application;
	}

	/**
	 * get backendSystem
	 */
	@ManyToOne
	@JoinColumn(name = "BACKEND_SYSTEM_ID")
	public BackendSystem getBackendSystem() {
		return this.backendSystem;
	}
	
	/**
	 * set backendSystem
	 */
	public void setBackendSystem(BackendSystem backendSystem) {
		this.backendSystem = backendSystem;
	}

	/**
	 * get createdBy
	 */
	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name = "CREATED_BY")
	public UserInfo getCreatedBy() {
		return this.createdBy;
	}
	
	/**
	 * set createdBy
	 */
	public void setCreatedBy(UserInfo createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return createdDate
	 */
	@Basic
	@Column(name = "CREATED_DATE")
		public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate new value for createdDate 
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	
	/**
	 * get modifiedBy
	 */
	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name = "MODIFIED_BY")
	public UserInfo getModifiedBy() {
		return this.modifiedBy;
	}
	
	/**
	 * set modifiedBy
	 */
	public void setModifiedBy(UserInfo modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return modifiedDate
	 */
	@Basic
	@Column(name = "MODIFIED_DATE", length = 40)
		public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate new value for modifiedDate 
	 */
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getId());
	}	

	@Transient
	public String getHandlerClassSimpleName() {
		String handlerClassSimpleName = null;
		if (handlerClass != null)
			handlerClassSimpleName = handlerClass.substring(handlerClass.lastIndexOf(".")+1);
		return handlerClassSimpleName;
	}

	@Transient
	public String getProcessorClassSimpleName() {
		String processorClassSimpleName = null;	
		if (processorClass != null)
			processorClassSimpleName = processorClass.substring(processorClass.lastIndexOf(".")+1);
		return processorClassSimpleName;
	}
	@Override
	public String toString() {
	
		return getJobName();
	}
	
}