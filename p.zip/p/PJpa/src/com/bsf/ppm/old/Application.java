package com.bsf.ppm.old;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.SelectableAuditableEntity;
import com.bsf.ppm.constants.IConstants;

/**
 * <p>
 * Pojo mapping TABLE IPPUSER.APPLICATION
 * </p>
 * @author Kaza
 * 
 */
@Entity
@Table(name = "APPLICATION")
@SuppressWarnings("serial")
@NamedQueries({
	@NamedQuery(name="Application.findReqdApplications",
    query = "select obj from Application obj where obj.id > 1" ),
    @NamedQuery(name="Application.findByName",
    	    query = "select obj from Application obj where obj.applicationName=:applicationName" ),
    @NamedQuery(name = "Application.updateStatus", query = "update Application ipt "
		+ "set ipt.status=:status where ipt.applicationName=:applicationName ")
})
public class Application extends SelectableAuditableEntity {

	/**
	 * Attribute id.
	 */
	//private Long id;

	/**
	 * Attribute applicationName.
	 */
	private String applicationName;

	/**
	 * Attribute status.
	 */
	private Long status;

	/**
	 * Attribute createdDate.
	 */
	private Timestamp createdDate;

	/**
	 * Attribute lastStoppedDate.
	 */
	private Timestamp lastStoppedDate;

	/**
	 * Attribute lastStartedDate.
	 */
	private Timestamp lastStartedDate;

	/**
	 * Attribute userInfo
	 */
	private UserInfo modifiedBy;

	/**
	 * Attribute description.
	 */
	private String description;

	/**
	 * List of AuthorizationRequest
	 */
	private List<AuthorizationRequest> authorizationRequests = null;

	/**
	 * List of BatchJob
	 */
	private List<BatchJob> batchJobs = null;

	/**
	 * List of BusinessObject
	 */
	private List<BusinessObject> businessObjects = null;

	
	/**
	 * @return id
	 */
	/*@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "applicationIdGen")
	@TableGenerator(name = "applicationIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "APPLICATION", valueColumnName = "ID_VALUE")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}*/

	/**
	 * @param id
	 *            new value for id
	 */
	/*public void setId(Long id) {
		this.id = id;
	}
*/
	/**
	 * @return applicationName
	 */
	@Basic
	@Id
	@Column(name = "APPLICATION_NAME", length = 40)
	public String getApplicationName() {
		return applicationName;
	}

	/**
	 * @param applicationName
	 *            new value for applicationName
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * @return status
	 */
	@Basic
	@Column(name = "STATUS")
	public Long getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            new value for status
	 */
	public void setStatus(Long status) {
		this.status = status;
	}

	/**
	 * @return createdDate
	 */
	@Basic
	@Column(name = "CREATED_DATE")
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate
	 *            new value for createdDate
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return lastStoppedDate
	 */
	@Basic
	@Column(name = "LAST_STOPPED_DATE")
	public Timestamp getLastStoppedDate() {
		return lastStoppedDate;
	}

	/**
	 * @param lastStoppedDate
	 *            new value for lastStoppedDate
	 */
	public void setLastStoppedDate(Timestamp lastStoppedDate) {
		this.lastStoppedDate = lastStoppedDate;
	}

	/**
	 * @return lastStartedDate
	 */
	@Basic
	@Column(name = "LAST_STARTED_DATE")
	public Timestamp getLastStartedDate() {
		return lastStartedDate;
	}

	/**
	 * @param lastStartedDate
	 *            new value for lastStartedDate
	 */
	public void setLastStartedDate(Timestamp lastStartedDate) {
		this.lastStartedDate = lastStartedDate;
	}

	/**
	 * get userInfo
	 */
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "MODIFIED_BY")
	public UserInfo getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * set userInfo
	 */
	public void setModifiedBy(UserInfo modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return description
	 */
	@Basic
	@Column(name = "DESCRIPTION", length = 100)
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            new value for description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Get the list of AuthorizationRequest
	 */
	@OneToMany(mappedBy = "application")
	public List<AuthorizationRequest> getAuthorizationRequests() {
		return this.authorizationRequests;
	}

	/**
	 * Set the list of AuthorizationRequest
	 */
	public void setAuthorizationRequests(
			List<AuthorizationRequest> authorizationRequests) {
		this.authorizationRequests = authorizationRequests;
	}

	/**
	 * Get the list of BatchJob
	 */
	@OneToMany(mappedBy = "application")
	public List<BatchJob> getBatchJobs() {
		return this.batchJobs;
	}

	/**
	 * Set the list of BatchJob
	 */
	public void setBatchJobs(List<BatchJob> batchJobs) {
		this.batchJobs = batchJobs;
	}

	/**
	 * Get the list of BusinessObject
	 */
	@OneToMany(mappedBy = "application")
	public List<BusinessObject> getBusinessObjects() {
		return this.businessObjects;
	}

	/**
	 * Set the list of BusinessObject
	 */
	public void setBusinessObjects(List<BusinessObject> businessObjects) {
		this.businessObjects = businessObjects;
	}


	/**
	 * @return Primary Key as String
	 */
	@Override
	@Transient
	public String getPk() {
		return String.valueOf(getApplicationName());
	}

	/**
	 * @return String name for the matching status from IConstants
	 */
	@Transient
	public String getStatusString() {
		
		if (getStatus() != null)
			return IConstants.STATUS_TYPE.values()[getStatus().intValue()]
					.name();
		return "";

	}

}