package com.bsf.ppm.old;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

/**
 * <p>Pojo mapping TABLE IPP_DEV.ACCESS_HISTORY</p>
 *
 * <p>Generated at Mon Apr 16 13:10:03 AST 2012</p>
 * @author Salto-db Generator v1.0.16 / EJB3
 * 
 */
@Entity
@Table(name = "USER_ACCESS_HISTORY")
@SuppressWarnings("serial")
public class AccessHistory implements Serializable {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute userId.
	 */
	private String userId;
	
	/**
	 * Attribute ip.
	 */
	private String ip;
	
	/**
	 * Attribute loginDate.
	 */
	private Timestamp loginDate;
	
	/**
	 * Attribute logoutDate.
	 */
	private Timestamp logoutDate;
	
	
	/**
	 * @return id
	 */
	@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "accessHistoryIdGen")
	@TableGenerator(name = "accessHistoryIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "ACCESS_HISTORY", valueColumnName = "ID_VALUE")
	@Column(name = "ID")
		public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return userId
	 */
	@Basic
	@Column(name = "USER_ID", length = 20)
		public String getUserId() {
		return userId;
	}

	/**
	 * @param userId new value for userId 
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/**
	 * @return ip
	 */
	@Basic
	@Column(name = "IP", length = 15)
		public String getIp() {
		return ip;
	}

	/**
	 * @param ip new value for ip 
	 */
	public void setIp(String ip) {
		this.ip = ip;
	}
	
	/**
	 * @return loginDate
	 */
	@Basic
	@Column(name = "LOGIN_DATE")
		public Timestamp getLoginDate() {
		return loginDate;
	}

	/**
	 * @param loginDate new value for loginDate 
	 */
	public void setLoginDate(Timestamp loginDate) {
		this.loginDate = loginDate;
	}
	
	/**
	 * @return logoutDate
	 */
	@Basic
	@Column(name = "LOGOUT_DATE")
		public Timestamp getLogoutDate() {
		return logoutDate;
	}

	/**
	 * @param logoutDate new value for logoutDate 
	 */
	public void setLogoutDate(Timestamp logoutDate) {
		this.logoutDate = logoutDate;
	}
	


}