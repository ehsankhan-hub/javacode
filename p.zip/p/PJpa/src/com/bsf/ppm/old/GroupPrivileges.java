package com.bsf.ppm.old;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import com.bsf.ipp.dao.SelectableAuditableEntity;

/**
 * <p>Pojo mapping TABLE IPPUSER.GROUP_PRIVILEGES</p>
 * @author Kaza
 * 
 */
@Entity
@Table(name = "GROUP_PRIVILEGES")
@SuppressWarnings("serial")
public class GroupPrivileges extends SelectableAuditableEntity {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute userGroup
	 */
	 private UserGroup userGroup;	

	/**
	 * Attribute businessObject
	 */
	 private BusinessObject businessObject;	

	

 	@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "groupPrivilegeIdGen")
	@TableGenerator(name = "groupPrivilegeIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "GROUP_PRIVILEGES", valueColumnName = "ID_VALUE")
	@Column(name = "ID")
		public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * get userGroup
	 */
	@ManyToOne
	@JoinColumn(name = "GROUP_ID")
	public UserGroup getUserGroup() {
		return this.userGroup;
	}
	
	/**
	 * set userGroup
	 */
	public void setUserGroup(UserGroup userGroup) {
		this.userGroup = userGroup;
	}

	/**
	 * get businessObject
	 */
	@ManyToOne
	@JoinColumn(name = "BUSINESS_OBJECT_ID")
	public BusinessObject getBusinessObject() {
		return this.businessObject;
	}
	
	/**
	 * set businessObject
	 */
	public void setBusinessObject(BusinessObject businessObject) {
		this.businessObject = businessObject;
	}

	@Transient
	@Override
	public String getPk() {
		
		return String.valueOf(getId());
	}



}