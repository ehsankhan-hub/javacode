package com.bsf.ppm.old;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * <p>Pojo mapping TABLE IPPUSER.AUTHORIZATION_REQUEST</p>
 *
 * @author Kaza
 * 
 */
@Entity
@Table(name = "AUTHORIZATION_REQUEST")
@SuppressWarnings("serial")
public class AuthorizationRequest implements Serializable {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	/**
	 * Attribute referenceId.
	 */
	private String referenceId;
	
	/**
	 * Attribute referenceTable.
	 */
	private String referenceTable;
	
	/**
	 * Attribute creationTime.
	 */
	private String creationTime;
	
	/**
	 * Attribute lastRequestTime.
	 */
	private Timestamp lastRequestTime;
	
	/**
	 * Attribute requestStatus.
	 */
	private Long requestStatus;
	
	/**
	 * Attribute application
	 */
	 private Application application;	

	
	/**
	 * @return id
	 */
	@Basic
	@Id
	@Column(name = "ID")
		public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return referenceId
	 */
	@Basic
	@Column(name = "REFERENCE_ID", length = 50)
		public String getReferenceId() {
		return referenceId;
	}

	/**
	 * @param referenceId new value for referenceId 
	 */
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}
	
	/**
	 * @return referenceTable
	 */
	@Basic
	@Column(name = "REFERENCE_TABLE", length = 100)
		public String getReferenceTable() {
		return referenceTable;
	}

	/**
	 * @param referenceTable new value for referenceTable 
	 */
	public void setReferenceTable(String referenceTable) {
		this.referenceTable = referenceTable;
	}
	
	/**
	 * @return creationTime
	 */
	@Basic
	@Column(name = "CREATION_TIME", length = 40)
		public String getCreationTime() {
		return creationTime;
	}

	/**
	 * @param creationTime new value for creationTime 
	 */
	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}
	
	/**
	 * @return lastRequestTime
	 */
	@Basic
	@Column(name = "LAST_REQUEST_TIME")
		public Timestamp getLastRequestTime() {
		return lastRequestTime;
	}

	/**
	 * @param lastRequestTime new value for lastRequestTime 
	 */
	public void setLastRequestTime(Timestamp lastRequestTime) {
		this.lastRequestTime = lastRequestTime;
	}
	
	/**
	 * @return requestStatus
	 */
	@Basic
	@Column(name = "REQUEST_STATUS")
		public Long getRequestStatus() {
		return requestStatus;
	}

	/**
	 * @param requestStatus new value for requestStatus 
	 */
	public void setRequestStatus(Long requestStatus) {
		this.requestStatus = requestStatus;
	}
	
	/**
	 * get application
	 */
	@ManyToOne
	@JoinColumn(name = "APPLICATION_ID")
	public Application getApplication() {
		return this.application;
	}
	
	/**
	 * set application
	 */
	public void setApplication(Application application) {
		this.application = application;
	}
}