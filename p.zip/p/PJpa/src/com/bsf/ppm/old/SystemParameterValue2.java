package com.bsf.ppm.old;

import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.bsf.ipp.dao.SelectableAuditableCacheableEntity;

/**
 * <p>Pojo mapping TABLE IPP_DEV2.SYSTEM_PARAMETER_VALUE_2</p>
 *
 * <p>Generated at Tue Jan 21 11:19:37 AST 2014</p>
 * @author Salto-db Generator v1.0.16 / EJB3
 * 
 */
@Entity
@Table(name = "SYSTEM_PARAMETER_VALUE_2")
@NamedQueries({
	@NamedQuery(name="SystemParameterValue2.findByValue2AndValue3", 
			query="select obj from SystemParameterValue2 obj " +
			"where value2=:value2 and value3=:value3")
})
@SuppressWarnings("serial")
public class SystemParameterValue2 extends SelectableAuditableCacheableEntity {

	/**
	 * Attribute paramTypeCode.
	 */
	private String paramTypeCode;
	
	/**
	 * Attribute brnCode.
	 */
	private String brnCode;
	
	/**
	 * Attribute value1.
	 */
	private String value1;
	
	/**
	 * Attribute value2.
	 */
	private String value2;
	
	/**
	 * Attribute value3.
	 */
	private String value3;
	
	/**
	 * Attribute value4.
	 */
	private String value4;
	
	/**
	 * Attribute value5.
	 */
	private String value5;
	
	/**
	 * Attribute updtDate.
	 */
	private Timestamp updtDate;
	
	/**
	 * Attribute updtUser.
	 */
	private String updtUser;
	
	/**
	 * Attribute updtUserOrgUnit.
	 */
	private String updtUserOrgUnit;
	
	
	/**
	 * @return paramTypeCode
	 */
	@Basic
	@Column(name = "PARAM_TYPE_CODE", length = 6)
		public String getParamTypeCode() {
		return paramTypeCode;
	}

	/**
	 * @param paramTypeCode new value for paramTypeCode 
	 */
	public void setParamTypeCode(String paramTypeCode) {
		this.paramTypeCode = paramTypeCode;
	}
	
	/**
	 * @return brnCode
	 */
	@Basic
	@Column(name = "BRN_CODE", length = 6)
		public String getBrnCode() {
		return brnCode;
	}

	/**
	 * @param brnCode new value for brnCode 
	 */
	public void setBrnCode(String brnCode) {
		this.brnCode = brnCode;
	}
	
	/**
	 * @return value1
	 */
	@Id
	@Basic
	@Column(name = "VALUE1", length = 50)
		public String getValue1() {
		return value1;
	}

	/**
	 * @param value1 new value for value1 
	 */
	public void setValue1(String value1) {
		this.value1 = value1;
	}
	
	/**
	 * @return value2
	 */
	@Basic
	@Column(name = "VALUE2", length = 50)
		public String getValue2() {
		return value2;
	}

	/**
	 * @param value2 new value for value2 
	 */
	public void setValue2(String value2) {
		this.value2 = value2;
	}
	
	/**
	 * @return value3
	 */
	@Basic
	@Column(name = "VALUE3", length = 50)
		public String getValue3() {
		return value3;
	}

	/**
	 * @param value3 new value for value3 
	 */
	public void setValue3(String value3) {
		this.value3 = value3;
	}
	
	/**
	 * @return value4
	 */
	@Basic
	@Column(name = "VALUE4", length = 50)
		public String getValue4() {
		return value4;
	}

	/**
	 * @param value4 new value for value4 
	 */
	public void setValue4(String value4) {
		this.value4 = value4;
	}
	
	/**
	 * @return value5
	 */
	@Basic
	@Column(name = "VALUE5", length = 50)
		public String getValue5() {
		return value5;
	}

	/**
	 * @param value5 new value for value5 
	 */
	public void setValue5(String value5) {
		this.value5 = value5;
	}
	
	/**
	 * @return updtDate
	 */
	@Basic
	@Column(name = "UPDT_DATE")
		public Timestamp getUpdtDate() {
		return updtDate;
	}

	/**
	 * @param updtDate new value for updtDate 
	 */
	public void setUpdtDate(Timestamp updtDate) {
		this.updtDate = updtDate;
	}
	
	/**
	 * @return updtUser
	 */
	@Basic
	@Column(name = "UPDT_USER", length = 10)
		public String getUpdtUser() {
		return updtUser;
	}

	/**
	 * @param updtUser new value for updtUser 
	 */
	public void setUpdtUser(String updtUser) {
		this.updtUser = updtUser;
	}
	
	/**
	 * @return updtUserOrgUnit
	 */
	@Basic
	@Column(name = "UPDT_USER_ORG_UNIT", length = 6)
		public String getUpdtUserOrgUnit() {
		return updtUserOrgUnit;
	}

	/**
	 * @param updtUserOrgUnit new value for updtUserOrgUnit 
	 */
	public void setUpdtUserOrgUnit(String updtUserOrgUnit) {
		this.updtUserOrgUnit = updtUserOrgUnit;
	}

	@Override
	@Transient
	public String getPk() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Transient
	public String getKey() {
		return getValue2()+getValue3()+getParamTypeCode();
	}

}