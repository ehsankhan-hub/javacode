package com.bsf.ppm;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlTransient;

import com.bsf.ipp.dao.SelectableAuditableEntity;

@Entity
@Table(name = "ACCOUNT_CLASS")
@SuppressWarnings("serial")
public class AccountClass extends SelectableAuditableEntity {

	@Id
	@Basic
	@Column(name = "ACCT_NO", length = 11)
	private String accountNo;

	@Basic
	@Column(name = "EMP_CTGRY", length = 6)
	private String empCategory;

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getEmpCategory() {
		return empCategory;
	}

	public void setEmpCategory(String empCategory) {
		this.empCategory = empCategory;
	}

	@Override
	@XmlTransient
	@Transient
	public String getPk() {

		return getAccountNo();
	}

}
