package com.bsf.ppm;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlTransient;

import com.bsf.ipp.dao.SelectableAuditableEntity;

/**
 * <p>Pojo mapping TABLE OEPAYSD.PPM_GROUP</p>
 *
 * <p>Generated at Wed Aug 10 12:21:25 AST 2016</p>
 * @author Salto-db Generator v1.0.16 / EJB3
 * 
 */
@Entity
@Table(name = "PPM_PARAMETER_VALUE")
@SuppressWarnings("serial")
public class PpmParameterValuesSetup extends SelectableAuditableEntity  {
	
	
	@Basic
	@Id
	@Column(name="VALUE3",length = 50)
	 private String value3;
	
	@Basic
	@Column(name="PARAM_TYPE_CODE",length = 15)
	private String paramTypeCode;
	
	@Basic
	@Column(name="GROUP_CODE",length = 10)
	private String groupCode;


   
	@Basic
	@Column(name="VALUE2",length = 50)
    private String value2;
 
	@Basic
	@Column(name="VALUE1",length = 50)	
	private String value1;
	
	
	
 
	@Basic
	@Column(name="CREATE_DATE")
 private Date createDate;
 
	@Basic
	@Column(name="CREATED_BY",length = 10)
 private String createdBy;
 
	@Basic
	@Column(name="UPDATE_DATE")
 private Date updateDate;

	@Basic
	@Column(name="UPDATED_BY",length = 10)
 private String updatedBy;

 
public String getParamTypeCode() {
		return paramTypeCode;
	}


	public void setParamTypeCode(String paramTypeCode) {
		this.paramTypeCode = paramTypeCode;
	}


	public String getGroupCode() {
		return groupCode;
	}


	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}


public String getValue1() {
	return value1;
}


public void setValue1(String value1) {
	this.value1 = value1;
}


public String getValue2() {
	return value2;
}


public void setValue2(String value2) {
	this.value2 = value2;
}


public String getValue3() {
	return value3;
}


public void setValue3(String value3) {
	this.value3 = value3;
}


public Date getCreateDate() {
	return createDate;
}


public void setCreateDate(Date createDate) {
	this.createDate = createDate;
}


public String getCreatedBy() {
	return createdBy;
}


public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
}


public Date getUpdateDate() {
	return updateDate;
}


public void setUpdateDate(Date updateDate) {
	this.updateDate = updateDate;
}


public String getUpdatedBy() {
	return updatedBy;
}


public void setUpdatedBy(String updatedBy) {
	this.updatedBy = updatedBy;
}


@Override
@XmlTransient
@Transient
	public String getPk() {
		return getValue1();
	}
	
	
	
	
	
	
	
	
	
	
}


