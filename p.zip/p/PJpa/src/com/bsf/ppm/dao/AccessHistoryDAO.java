package com.bsf.ppm.dao;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.AccessHistory;
import com.bsf.ppm.exceptions.DAOException;

public interface AccessHistoryDAO extends PaginatedDAO<AccessHistory, Long> 
{
	public void maintHistory(AccessHistory entity,boolean isLogin) throws DAOException;

}
