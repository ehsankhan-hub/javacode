package com.bsf.ppm.dao.jpa;

import java.util.List;

import javax.persistence.Query;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.CurrencyCode;
import com.bsf.ppm.dao.CurrencyCodeDAO;
import com.bsf.ppm.exceptions.DAOException;
/**
 * @author Zakir
 * Java Persistence API implementation for the CurrencyCodeDAO.
 */
@Transactional
public class CurrencyCodeJpaDAO extends PaginatedJpaDAO<CurrencyCode, String> implements CurrencyCodeDAO {

	@Override
	public boolean isUnique(CurrencyCode entity) throws DAOException {
		long recordCount = -1;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
					.append(getPersistentClass().getSimpleName()).append(
							"  obj  where obj.currencyCode=:currencyCode ");
			Query jpaQuery = entityManager.createQuery(query.toString());
			/*if(entity.getId() !=null) {
				jpaQuery.setParameter("id", entity.getId());
			}
			else {
				jpaQuery.setParameter("id",Long.valueOf(-1));
			}*/
			jpaQuery.setParameter("currencyCode", entity.getCurrencyCode());
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}

		return recordCount <= 0;
	}

	@Override
	public CurrencyCode getByCurrencyCode(String currency) {
		try {
			List<CurrencyCode> list = findByNamedQuery("CurrencyCode.findByCurrencyCode", new String[]{"currencyCode","status"}, new Object[]{currency, 1L} );
			if(list != null && list.size()>0)
				return list.get(0);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}

}
