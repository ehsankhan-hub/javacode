package com.bsf.ppm.dao;

import java.util.Map;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.CountryCode;
import com.bsf.ppm.exceptions.DAOException;

/**
 * @author Zakir
 * Data Access Object for CountryCode Entity. Extends PaginatedDAO
 */
public interface CountryCodeDAO extends PaginatedDAO<CountryCode, String>{
	/**
	 * @return
	 */
	public Map<String,String> getAllCounties();

	public String fetchCountryForChqDrawnCountry(String chqCurrency) throws DAOException;

}
