package com.bsf.ppm.dao;

import com.bsf.ipp.dao.GenericDAO;
import com.bsf.ppm.BusinessObject;

public interface BusinessObjectDAO extends GenericDAO<BusinessObject, Long> {

}
