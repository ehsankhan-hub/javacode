package com.bsf.ppm.dao;

import java.util.List;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.A_Block_Deblock;
import com.bsf.ppm.PpmDebitBlockStaging;
import com.bsf.ppm.Ppm_Instructions;
import com.bsf.ppm.exceptions.DAOException;



public interface PpmDebitBlockStagingDAO extends PaginatedDAO<PpmDebitBlockStaging, String>{
	public List<PpmDebitBlockStaging> getAccountsFromStaging(String status)throws DAOException;
	public PpmDebitBlockStaging  getCustomerCode(String status)throws DAOException;
	
	public String getPPMReference() throws DAOException;
	public Long getInstDetaiSeqGen() throws DAOException ;
	
	public PpmDebitBlockStaging findPpmDebitBlockStagingSalaryPercent(PpmDebitBlockStaging ppmDebitBlockStaging)throws DAOException;
	public String getPPMReferenceSalaryPercen() throws DAOException;
	public void savePpmDebitBlockStaging(PpmDebitBlockStaging ppmDebitBlockStaging)throws DAOException;
	public void updatePpmDebitBlockStaging(PpmDebitBlockStaging ppmDebitBlockStaging)throws DAOException;
	public void savePpmDebitBlockStaging(List<PpmDebitBlockStaging> ppmDebitBlockStaging)throws DAOException;
	
	public Long getInstDetaiSeqGenSalaryPercen() throws DAOException;
	public String getCtznAccount(String dbAccountNo)throws DAOException,Exception;
}
