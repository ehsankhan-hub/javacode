package com.bsf.ppm.dao.jpa;

import java.sql.Connection;

import org.hibernate.Session;

import com.bsf.ppm.util.JNDIUtil;
import com.bsf.ppm.util.SessionFactoryCisprodManager;

public class CisDatabaseConnectionTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Connection conn=null;
		try{
		conn=JNDIUtil.getCisDatabaseConnection();
		System.out.println("Connection from CIS database="+conn);
		}
		catch(Exception ex){
			ex.printStackTrace();
		}

	}

}
