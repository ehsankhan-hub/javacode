package com.bsf.ppm.dao.jpa;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.AbstractJpaDAO;
import com.bsf.ppm.MailMessage;
import com.bsf.ppm.dao.MailMessageDAO;
import com.bsf.ppm.exceptions.DAOException;

/**
 * <p>DAO class for email message related operations.
 * Java Persistence API implementation for the MailMessageDAO.</p>
 * @author Rakesh
 *
 */
@Transactional
public class MailMessageJpaDAO extends AbstractJpaDAO<MailMessage, Long> implements MailMessageDAO {

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(MailMessage entity) throws DAOException {
		
		return false;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.MailMessageDAO#findByMailStatus(java.lang.Integer)
	 */
	@Override
	public List<MailMessage> findByMailStatus(Integer mailStatus)
			throws DAOException {
		Map criterias = new HashMap();
		criterias.put("mailStatus", mailStatus.longValue());
		return findByCriteria(criterias);
	}

}
