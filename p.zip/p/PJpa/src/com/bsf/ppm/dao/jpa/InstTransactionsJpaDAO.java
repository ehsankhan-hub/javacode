package com.bsf.ppm.dao.jpa;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.persistence.Query;
import javax.sql.DataSource;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.GeneralConfiguration;
import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.dao.InstTransactionsDAO;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.fts.FTSRequestPostingEntityMRKI;
import com.bsf.ppm.fts.FTSRequestPostingEntityMRKM;
import com.bsf.ppm.fts.FTSResponsePostingEntity;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.Ppm_Inst_Transactions;
import com.bsf.ppm.InstructionListValues;
import com.bsf.ppm.spring.SpringAppContext;
import com.bsf.ppm.util.JNDIUtil;
import com.bsf.ppm.util.StringUtils;

@Transactional
public  class InstTransactionsJpaDAO extends PaginatedJpaDAO<Ppm_Inst_Transactions, String> implements InstTransactionsDAO {
	
public Cache generalConfigurationCache;

public void setGeneralConfigurationCache(Cache generalConfigurationCache) {
	this.generalConfigurationCache = generalConfigurationCache;
}


public Long getTTReferenceSeqGen() throws DAOException {
	String sql = "SELECT PPM_TT_REF.NEXTVAL FROM DUAL";
	try {
		// Execute native query and get the result list
		List results= entityManager.createNativeQuery(sql).getResultList();
		// Iterate the list and get the sequence value
		BigDecimal bd = (BigDecimal)results.iterator().next();
		System.out.println("TTReference Value="+bd);
		return bd.longValue();
	} catch (RuntimeException ex) {
		throw new DAOException("error.executeQuery", ex,
				getPersistentClass().getName(), sql);
	}
}

public Long getReferenceSeqGen() throws DAOException {
	String sql = "SELECT PPM_LLS_REF.NEXTVAL FROM DUAL";
	try {
		// Execute native query and get the result list
		List results= entityManager.createNativeQuery(sql).getResultList();
		// Iterate the list and get the sequence value
		BigDecimal bd = (BigDecimal)results.iterator().next();
		System.out.println("TTReference Value="+bd);
		return bd.longValue();
	} catch (RuntimeException ex) {
		throw new DAOException("error.executeQuery", ex,
				getPersistentClass().getName(), sql);
	}
}

@Override
public Ppm_Inst_Transactions getInstTransaction(String trnsRef)throws DAOException{
	//String selectQ="FROM Ppm_Inst_Transactions trns WHERE trns.ppmTrnsRef ="+"'"+trnsRef.trim()+"'";
	List<Object[]>list=null; 
	List<Ppm_Inst_Transactions> instTrnsDtl=new ArrayList<Ppm_Inst_Transactions>();
	//String selectQ="SELECT ppmTrnsRef,instRef,status,cammActionCode,ftsActionCode FROM  Ppm_Inst_Transactions WHERE ppmTrnsRef ="+"'"+trnsRef.trim()+"'";
	String query="SELECT ppmTrnsRef,instRef,trnsType,status,trnsDate,valueDate,trnsCrncy,trnsAmount,amountInSar,genNarrative,scnNarrative,drAmount,debitAcc"+
	",drActCrncy ,creditAcc,crActCrncy,crAmount,benBankAddress1,benName,benBank,benCountry,benBankCode,paymentDtls,amount,crValueDate,commCrncy"+
	",commAct,commAmount,chrgCrncy,chrgAct,chrgAmount,sourceSystem,ppmTrnsStatus,cammActionCode,ftsActionCode ,ppmStatusBy,ppmStatusDate,remitterName FROM  Ppm_Inst_Transactions WHERE ppmTrnsRef ="+"'"+trnsRef.trim()+"'";
	Ppm_Inst_Transactions ppm_Inst_Transactions=new Ppm_Inst_Transactions();
	list=(List<Object[]>)entityManager.createQuery(query).getResultList();;
	 for (int i = 0; i < list.size(); i++) {
   	  Object[] obj  = list.get(i);
   	String ppmTrnsRef=(String)obj[0];
	String instRef=(String)obj[1];
	String trnsType=(String)obj[2];
	System.out.println("trnsType=="+trnsType);
	String status=(String)obj[3];
	Date trnsDate=(Date)obj[4];
	Date valueDate=(Date)obj[5];
	String trnsCrncy=(String)obj[6];
	BigDecimal trnsAmount=(BigDecimal)obj[7];
	BigDecimal amountInSar=(BigDecimal)obj[8];
	String genNarrative=(String)obj[9];
	String scnNarrative=(String)obj[10];
	Double drAmount=(Double)obj[11];
	String debitAcc=(String)obj[12];
	String drActCrncy=(String)obj[13];
	String creditAcc=(String)obj[14];
	String crActCrncy=(String)obj[15];
	Double crAmount=(Double)obj[16];
	String benBankAddress1=(String)obj[17];
	String benName=(String)obj[18];
	String benBank=(String)obj[19];
	String benCountry=(String)obj[20];
	String benBankCode=(String)obj[21];
	String paymentDtls=(String)obj[22];
	Double amount=(Double)obj[23];
	Date crValueDate=(Date)obj[24];
	String commCrncy=(String)obj[25];
	String commAct=(String)obj[26];
	BigDecimal commAmount=(BigDecimal)obj[27];
	String chrgCrncy=(String)obj[28];
	String chrgAct=(String)obj[29];
	BigDecimal chrgAmount=(BigDecimal)obj[30];
	String sourceSystem=(String)obj[31];
	String ppmTrnsStatus=(String)obj[32];
	String cammActionCode=(String)obj[33];
	String ftsActionCode=(String)obj[34]; 
	String ppmStatusBy=(String)obj[35];
	Date ppmStatusDate=(Date)obj[36];
	String ramitterName=(String)obj[37];
			
  	
  	System.out.println("ppmTrnsStatus=="+ppmTrnsStatus);
  	ppm_Inst_Transactions.setPpmTrnsRef(ppmTrnsRef);
  	ppm_Inst_Transactions.setInstRef(instRef);
  	ppm_Inst_Transactions.setTrnsType(trnsType);
  	ppm_Inst_Transactions.setStatus(status);
  	ppm_Inst_Transactions.setTrnsDate(trnsDate);
  	ppm_Inst_Transactions.setValueDate(valueDate);
  	ppm_Inst_Transactions.setTrnsCrncy(trnsCrncy);
  	ppm_Inst_Transactions.setTrnsAmount(trnsAmount);
  	if(amountInSar!=null&&!"".equals(amountInSar)){
  	ppm_Inst_Transactions.setAmountInSar(amountInSar.doubleValue());
  	}
  	ppm_Inst_Transactions.setGenNarrative(genNarrative);
  	ppm_Inst_Transactions.setScnNarrative(scnNarrative);
  	if(drAmount!=null&&!"".equals(drAmount)){
  	ppm_Inst_Transactions.setDrAmount(drAmount.doubleValue());
  	}
  	ppm_Inst_Transactions.setDebitAcc(debitAcc);
  	ppm_Inst_Transactions.setDrActCrncy(drActCrncy);
  	ppm_Inst_Transactions.setCreditAcc(creditAcc);
  	ppm_Inst_Transactions.setCrActCrncy(crActCrncy);
	if(crAmount!=null&&crAmount!=0.0){
  	ppm_Inst_Transactions.setCrAmount(crAmount);
	}
  	ppm_Inst_Transactions.setBenBankAddress1(benBankAddress1);
  	ppm_Inst_Transactions.setBenName(benName);
  	ppm_Inst_Transactions.setBenBank(benBank);
  	ppm_Inst_Transactions.setBenCountry(benCountry);
  	ppm_Inst_Transactions.setBenBankCode(benBankCode);
  	ppm_Inst_Transactions.setPaymentDtls(paymentDtls);
  	if(amount!=null&&amount!=0.0){
  	ppm_Inst_Transactions.setAmount(amount.doubleValue());
  	}
  	ppm_Inst_Transactions.setCrValueDate(crValueDate);
  	ppm_Inst_Transactions.setCommCrncy(commCrncy);
  	ppm_Inst_Transactions.setCommAct(commAct);
  	if(commAmount!=null&&!"".equals(commAmount)){
  	ppm_Inst_Transactions.setCommAmount(commAmount.doubleValue());
  	}
  	ppm_Inst_Transactions.setChrgCrncy(chrgCrncy);
  	ppm_Inst_Transactions.setChrgAct(chrgAct);
	if(chrgAmount!=null&&!"".equals(chrgAmount)){
  	ppm_Inst_Transactions.setChrgAmount(chrgAmount.doubleValue());
	}
	ppm_Inst_Transactions.setSourceSystem(sourceSystem);
  	ppm_Inst_Transactions.setPpmTrnsStatus(ppmTrnsStatus);
  	ppm_Inst_Transactions.setCammActionCode(cammActionCode);
  	ppm_Inst_Transactions.setFtsActionCode(ftsActionCode);
  	ppm_Inst_Transactions.setPpmStatusBy(ppmStatusBy);
  	ppm_Inst_Transactions.setPpmStatusDate(ppmStatusDate);
  	ppm_Inst_Transactions.setRemitterName(ramitterName);
  	
	}
	return ppm_Inst_Transactions;
	}


@Override
public Ppm_Inst_Transactions getTrnsInstRef(String instRef)throws DAOException{
	String selectQ="FROM Ppm_Inst_Transactions trns WHERE trns.instRef ="+"'"+instRef.trim()+"'";
	Query query=entityManager.createQuery(selectQ);
	//query.setParameter("trnsRef",trnsRef);
	Ppm_Inst_Transactions ppm_Inst_Transactions=(Ppm_Inst_Transactions)query.getSingleResult();
	return ppm_Inst_Transactions;
	}

//get Credit Account for TTAC Transaction type from F_CORRESPONDENTS table

public String getCreditAcct(String trnsCrncy)throws DAOException{
	StringBuilder selectQuery=new StringBuilder();
	selectQuery.append("select corresp_act from F_CORRESPONDENTS where crncy_code= ");
	selectQuery.append("'"+trnsCrncy+"'");
	selectQuery.append("and dd_tt_flag='T' and rownum=1");
	String query=(String)entityManager.createNativeQuery(selectQuery.toString()).getSingleResult().toString();
	return query;
}
// get day of holidays from ppm_parameter_value
public ParameterValue getSARIHolidays(String date)throws DAOException{
List<Object[]>list=null; 
ParameterValue parameterValue=new ParameterValue();
StringBuilder query=new StringBuilder();
query.append("select value1,value2 from ppm_parameter_value where param_type_code='SARIEHOLIDAY' and value1");
query.append("<="+"'"+date+"'");
query.append("and value2>="+"'"+date+"'");
list=(List<Object[]>)entityManager.createNativeQuery(query.toString()).getResultList();
if(list.size()==0){
parameterValue=null;	
}
for(int i=0;i<list.size();i++){
Object[] obj  = list.get(i);
String value1=(String)obj[0];
String value2=(String)obj[1];
parameterValue.setValue1(value1);
parameterValue.setValue2(value2);
}
return parameterValue;
}
   /*Update PPM_INST_TRANSACTIONS Status,PPM_CAMM_ACTION_CODE and PPM_FTS_ACTION_CODE*/
    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
	public int updateInstTransactions(Ppm_Inst_Transactions ppm_Inst_Transactions,String cammActionCode,String ftsActionCode,String status)throws DAOException{
	    int countSucc=0;
	   
		//String status=ppm_Inst_Transactions.getStatus();
		if(status.equals("FAIL")){
			status="F";
		}
		else if(status.equals("ERROR")){
			status="E";	
		}
		else if(status.equals("PROCESSED")){
			status="P";	
		}
		
		try {
			
		//String updateQuery="UPDATE Ppm_Inst_Transactions SET status=+"'"+status+"'" ,ftsActionCode=:ftsActionCode,cammActionCode=:cammActionCode,ppmStatusDate=:ppmStatusDate,ppmStatusBy=:ppmStatusBy WHERE ppmTrnsRef=:ppmTrnsRef";
		StringBuilder updateQuery=new StringBuilder();
		updateQuery.append("UPDATE Ppm_Inst_Transactions type set ");
		updateQuery.append("type.PPM_PROCESS_STATUS= ");
		updateQuery.append("'"+status+"'");
		updateQuery.append(",type.PPM_FTS_ACTION_CODE= ");
		updateQuery.append("'"+ftsActionCode+"'");
		updateQuery.append(",type.PPM_CAMM_ACTION_CODE= ");
		updateQuery.append("'"+cammActionCode+"'");
		updateQuery.append(",type.PPM_STATUS_DATE= ");
		updateQuery.append("sysdate");
		updateQuery.append(",type.PPM_STATUS_BY= ");
		updateQuery.append("'"+"BATCH"+"'");
		updateQuery.append(" WHERE ");
		updateQuery.append("type.PPM_TRAN_REF= ");
		updateQuery.append("'"+ppm_Inst_Transactions.getPpmTrnsRef()+"'");
		Query queryUpdate=entityManager.createNativeQuery(updateQuery.toString());
		countSucc=queryUpdate.executeUpdate();
	    
	   }
	   catch(Exception daoe){
		   daoe.printStackTrace();
	   }
	   return countSucc;
	}
    
    
    /*Update PPM_INST_TRANSACTIONS Status,PPM_CAMM_ACTION_CODE and PPM_FTS_ACTION_CODE*/
    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
	public int updateInstTransactionsStatus(String trnsRef,String status)throws DAOException{
	    int countSucc=0;
	   
		try {
			
		//String updateQuery="UPDATE Ppm_Inst_Transactions SET status=+"'"+status+"'" ,ftsActionCode=:ftsActionCode,cammActionCode=:cammActionCode,ppmStatusDate=:ppmStatusDate,ppmStatusBy=:ppmStatusBy WHERE ppmTrnsRef=:ppmTrnsRef";
		StringBuilder updateQuery=new StringBuilder();
		updateQuery.append("UPDATE Ppm_Inst_Transactions t set ");
		updateQuery.append("t.PPM_PROCESS_STATUS= ");
		updateQuery.append("'"+status+"'");
		updateQuery.append(",t.PPM_STATUS_DATE= ");
		updateQuery.append("TRUNC(sysdate)");
		updateQuery.append(" WHERE ");
		updateQuery.append("t.PPM_TRAN_REF = ");
		updateQuery.append("'"+ trnsRef+"'");
		Query queryUpdate=entityManager.createNativeQuery(updateQuery.toString());
	    System.out.println("Udate start---------");
	    countSucc=queryUpdate.executeUpdate();
	    System.out.println("Updated successfully...."+countSucc);
	   }
	   catch(Exception daoe){
		   daoe.printStackTrace();
	   }
	   return countSucc;
	}
    
    /*Update PPM_INST_TRANSACTIONS Status,PPM_CAMM_ACTION_CODE and PPM_FTS_ACTION_CODE*/
    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
	public int updateInstTransactionsCtznAccount(String ctznAccount,String trnsRef)throws DAOException{
	    int countSucc=0;
	   
		try {
			
		//String updateQuery="UPDATE Ppm_Inst_Transactions SET status=+"'"+status+"'" ,ftsActionCode=:ftsActionCode,cammActionCode=:cammActionCode,ppmStatusDate=:ppmStatusDate,ppmStatusBy=:ppmStatusBy WHERE ppmTrnsRef=:ppmTrnsRef";
		StringBuilder updateQuery=new StringBuilder();
		updateQuery.append("UPDATE Ppm_Inst_Transactions type set ");
		updateQuery.append("type.PPM_BEN_ACCOUNT= ");
		updateQuery.append("'"+ctznAccount+"'");
		updateQuery.append(" WHERE ");
		updateQuery.append("type.PPM_TRAN_REF = ");
		updateQuery.append("'"+ trnsRef+"'");
		Query queryUpdate=entityManager.createNativeQuery(updateQuery.toString());
		System.out.println("Udate start---------");
	    countSucc=queryUpdate.executeUpdate();
	    System.out.println("Updated successfully...."+countSucc);
	   }
	   catch(Exception daoe){
		   daoe.printStackTrace();
	   }
	   return countSucc;
	}
  
  
  
  
@Override	
public List<Ppm_Inst_Transactions> getTrnsBackendProcDtl()throws DAOException{
	List<Object[]>list=null;      
	List<Ppm_Inst_Transactions> instTrnsDtl=new ArrayList<Ppm_Inst_Transactions>();
	Ppm_Inst_Transactions ppm_Inst_Transactions=new Ppm_Inst_Transactions();
	try {
		
		
		//String query="SELECT PPM_TRAN_REF,PPM_PROCESS_STATUS FROM  Ppm_Inst_Transactions_OLD WHERE PPM_PROCESS_STATUS='N'";
		 String query="SELECT ppmTrnsRef,instRef,trnsType,status,trnsDate,valueDate,trnsCrncy,trnsAmount,amountInSar,genNarrative,scnNarrative,drAmount,debitAcc"+
         ",drActCrncy ,creditAcc,crActCrncy,crAmount,benBankAddress1,benName,benBank,benCountry,benBankCode,paymentDtls,amount,crValueDate,commCrncy"+
         ",commAct,commAmount,chrgCrncy,chrgAct,chrgAmount,sourceSystem,ppmTrnsStatus,cammActionCode,ftsActionCode ,ppmStatusBy,ppmStatusDate,remitterName FROM  Ppm_Inst_Transactions WHERE status='N' AND sourceSystem='SPP' ";
		// instTrnsDtl= entityManager.createQuery(query).getResultList();
	//return 	instTrnsDtl;

		 
	      list=(List<Object[]>)entityManager.createQuery(query).getResultList();
	      
	      for (int i = 0; i < list.size(); i++) {
	    	  Object[] obj  = list.get(i);
	    	String ppmTrnsRef=(String)obj[0];
	    	String instRef=(String)obj[1];
	    	String trnsType=(String)obj[2];
	    	System.out.println("trnsType=="+trnsType);
	    	String status=(String)obj[3];
	    	Date trnsDate=(Date)obj[4];
	    	Date valueDate=(Date)obj[5];
	    	System.out.println("valueDate=="+valueDate);
	    	String trnsCrncy=(String)obj[6];
	    	BigDecimal trnsAmount=(BigDecimal)obj[7];
	    	BigDecimal amountInSar=(BigDecimal)obj[8];
	    	String genNarrative=(String)obj[9];
	    	String scnNarrative=(String)obj[10];
	    	Double drAmount=(Double)obj[11];
	    	String debitAcc=(String)obj[12];
	    	String drActCrncy=(String)obj[13];
	    	String creditAcc=(String)obj[14];
	    	String crActCrncy=(String)obj[15];
	    	Double crAmount=(Double)obj[16];
	    	String benBankAddress1=(String)obj[17];
	    	String benName=(String)obj[18];
	    	String benBank=(String)obj[19];
	    	String benCountry=(String)obj[20];
	    	String benBankCode=(String)obj[21];
	    	String paymentDtls=(String)obj[22];
	    	Double amount=(Double)obj[23];
	    	Date crValueDate=(Date)obj[24];
	    	String commCrncy=(String)obj[25];
	    	String commAct=(String)obj[26];
	    	BigDecimal commAmount=(BigDecimal)obj[27];
	    	String chrgCrncy=(String)obj[28];
	    	String chrgAct=(String)obj[29];
	    	BigDecimal chrgAmount=(BigDecimal)obj[30];
	    	String sourceSystem=(String)obj[31];
	    	String ppmTrnsStatus=(String)obj[32];
	    	String cammActionCode=(String)obj[33];
	    	String ftsActionCode=(String)obj[34]; 
	    	String ppmStatusBy=(String)obj[35];
	    	Date ppmStatusDate=(Date)obj[36];
	    	String ramitterName=(String)obj[37];	
	      	
	      	System.out.println("ppmTrnsStatus=="+ppmTrnsStatus);
	      	ppm_Inst_Transactions.setPpmTrnsRef(ppmTrnsRef);
	      	ppm_Inst_Transactions.setInstRef(instRef);
	      	ppm_Inst_Transactions.setTrnsType(trnsType);
	      	ppm_Inst_Transactions.setStatus(status);
	      	ppm_Inst_Transactions.setTrnsDate(trnsDate);
	      	ppm_Inst_Transactions.setValueDate(valueDate);
	      	ppm_Inst_Transactions.setTrnsCrncy(trnsCrncy);
	      	ppm_Inst_Transactions.setTrnsAmount(trnsAmount);
	      	if(amountInSar!=null&&!"".equals(amountInSar)){
	      	ppm_Inst_Transactions.setAmountInSar(amountInSar.doubleValue());
	      	}
	      	ppm_Inst_Transactions.setGenNarrative(genNarrative);
	      	ppm_Inst_Transactions.setScnNarrative(scnNarrative);
	      	if(drAmount!=null&&!"".equals(drAmount)){
	      	ppm_Inst_Transactions.setDrAmount(drAmount.doubleValue());
	      	}
	      	ppm_Inst_Transactions.setDebitAcc(debitAcc);
	      	ppm_Inst_Transactions.setDrActCrncy(drActCrncy);
	      	ppm_Inst_Transactions.setCreditAcc(creditAcc);
	      	ppm_Inst_Transactions.setCrActCrncy(crActCrncy);
	    	if(crAmount!=null&&crAmount!=0.0){
	      	ppm_Inst_Transactions.setCrAmount(crAmount);
	    	}
	      	ppm_Inst_Transactions.setBenBankAddress1(benBankAddress1);
	      	ppm_Inst_Transactions.setBenName(benName);
	      	ppm_Inst_Transactions.setBenBank(benBank);
	      	ppm_Inst_Transactions.setBenCountry(benCountry);
	      	ppm_Inst_Transactions.setBenBankCode(benBankCode);
	      	ppm_Inst_Transactions.setPaymentDtls(paymentDtls);
	      	if(amount!=null&&amount!=0.0){
	      	ppm_Inst_Transactions.setAmount(amount.doubleValue());
	      	}
	      	ppm_Inst_Transactions.setCrValueDate(crValueDate);
	      	ppm_Inst_Transactions.setCommCrncy(commCrncy);
	      	ppm_Inst_Transactions.setCommAct(commAct);
	      	if(commAmount!=null&&!"".equals(commAmount)){
	      	ppm_Inst_Transactions.setCommAmount(commAmount.doubleValue());
	      	}
	      	ppm_Inst_Transactions.setChrgCrncy(chrgCrncy);
	      	ppm_Inst_Transactions.setChrgAct(chrgAct);
	    	if(chrgAmount!=null&&!"".equals(chrgAmount)){
	      	ppm_Inst_Transactions.setChrgAmount(chrgAmount.doubleValue());
	    	}
	    	ppm_Inst_Transactions.setSourceSystem(sourceSystem);
	      	ppm_Inst_Transactions.setPpmTrnsStatus(ppmTrnsStatus);
	      	ppm_Inst_Transactions.setCammActionCode(cammActionCode);
	      	ppm_Inst_Transactions.setFtsActionCode(ftsActionCode);
	      	ppm_Inst_Transactions.setPpmStatusBy(ppmStatusBy);
	      	ppm_Inst_Transactions.setPpmStatusDate(ppmStatusDate);
	      	ppm_Inst_Transactions.setRemitterName(ramitterName);	
	        instTrnsDtl.add(ppm_Inst_Transactions); 	
	        ppm_Inst_Transactions = new Ppm_Inst_Transactions();
	      }
	      }
	      catch (Exception ex) {
				ex.printStackTrace();	
				}
	      return instTrnsDtl;
		  }




private GeneralConfiguration getGeneralConfigByName(String configName) {
	if (generalConfigurationCache == null)
		generalConfigurationCache = (Cache)SpringAppContext.getBean("generalConfigurationCache");
	Element elem = generalConfigurationCache.get(configName);
	if (elem != null) {
		return (GeneralConfiguration) elem.getObjectValue();
	}
	return null;
}
public String loadBusinessDate(){

	GeneralConfiguration generalConfig =  getGeneralConfigByName("BusinessDate");		
	String businessDate = "";

	if (generalConfig != null && generalConfig.getGeneralConfigParameters() != null
			&& generalConfig.getGeneralConfigParameters().containsKey("BusinessDate")){
	return	businessDate =  generalConfig.getGeneralConfigParameters().get("BusinessDate").getParamValue();
		
	}
	return null;
}
/*TRANSACTION REPORTS START*/
@SuppressWarnings("unchecked")
public List<Ppm_Inst_Transactions> getTransReport(String instReferenc,Date trnsDateFrom,Date trnsDateTo,Double totalAmount,String creditAcc,String debitAcc,String instStatus)throws DAOException {
	System.out.println("First date from DAO="+trnsDateFrom);
	List<InstructionListValues> listInstValu=new ArrayList<InstructionListValues>();
	InstructionListValues instVal =new InstructionListValues();
	List<Ppm_Inst_Transactions>list=new ArrayList<Ppm_Inst_Transactions>();
	try {
	StringBuilder query=new StringBuilder();
	if(((!"".equals(trnsDateFrom)&&trnsDateFrom!=null)&&(!"".equals(trnsDateTo)&&trnsDateTo!=null))||(instReferenc!=""&&instReferenc!=null)||(totalAmount!=null&&totalAmount!=0.0)||(!"".equals(creditAcc)&&creditAcc!=null)||(!"".equals(debitAcc)&&debitAcc!=null)||(!"".equals(instStatus)&&instStatus!=null)){
	//query.append("SELECT inst.INST_REFERENCE,inst.ACT_NO,inst.TOTAL_AMOUNT,inst.STATUS,inst.FREQUENCY, instDtl.RELATED_REFERENCE,inst.INST_AMOUNT,inst.START_DATE_H,inst.END_DATE_H,inst.START_DATE_G,inst.END_DATE_G,instDtl.BEN_BANK,instDtl.BEN_ACT,inst.INST_ACTION_TYPE,inst.NO_OF_INST,inst.DAY_OF_PAYMENT,inst.INST_CALENDAR, instDtl.BEN_NAME,instDtl.BEN_ADDRESS,instDtl.BEN_BANK_ADD1,instDtl.PAY_DETAILS FROM PPM_INSTRUCTIONS inst ,PPM_INSTRUCTIONS_DETAILS instDtl WHERE inst.INST_REFERENCE=instDtl.INST_REFERENCE ");
	query.append("SELECT object(trns) from Ppm_Inst_Transactions as trns WHERE 1=1 ");
	//query.append("'"+instReferenc+"'");
	}
	
	if(!"".equals(instReferenc)&&instReferenc!=null){
		list=null;
		query.append(" AND ");
		query.append("trns.instRef=");
		query.append("'"+instReferenc+"'");
		
		   
	}
	if(((!"".equals(trnsDateFrom)&&trnsDateFrom!=null)&&(!"".equals(trnsDateTo)&&trnsDateTo!=null))){
		list=null;
					
		SimpleDateFormat sd=new SimpleDateFormat("MM/dd/yyyy");
	    String frmDate=sd.format(trnsDateFrom);
    	SimpleDateFormat sdLdate=new SimpleDateFormat("MM/dd/yyyy");
	    String toDate=sdLdate.format(trnsDateTo);
		query.append(" AND ");
		query.append("trns.trnsDate");
		query.append(" BETWEEN ");
		query.append("to_Date(");
		query.append("'"+frmDate+"',"); 
		query.append("'mm/dd/yyyy')");
		query.append(" AND ");
		query.append("to_Date(");
		query.append("'"+toDate+"',"); 
		query.append("'mm/dd/yyyy')");
	}
	
	if(totalAmount!=null&&totalAmount!=0.0){
	list=null;
	query.append(" AND ");
	query.append("trns.amount= ");
	query.append("'"+totalAmount+"'");
	}
	if(!"".equals(creditAcc)&&creditAcc!=null){
		list=null;
		query.append(" AND ");
		query.append("trns.creditAcc= ");
		query.append("'"+creditAcc+"'");	
	}
	if(!"".equals(debitAcc)&&debitAcc!=null){
		list=null;
		query.append(" AND ");
		query.append("trns.debitAcc= ");
		query.append("'"+debitAcc+"'");	
	}
	
	System.out.println("Status ==="+instStatus);
	if(!"".equals(instStatus)&&instStatus!=null){
	System.out.println("First if block==="+instStatus);
	if(!"ALL".equalsIgnoreCase(instStatus)){
	System.out.println(" if All condition ==="+instStatus);	
	list=null;
	query.append(" AND ");
	query.append("trns.processStatus= ");
	query.append("'"+instStatus+"'");	
	}
	}
	
	
	if(((!"".equals(trnsDateFrom)&&trnsDateFrom!=null)&&(!"".equals(trnsDateTo)&&trnsDateTo!=null))||instReferenc!=""&&instReferenc!=null||totalAmount!=null&&totalAmount!=0.0||(!"".equals(creditAcc)&&creditAcc!=null)||(!"".equals(debitAcc)&&debitAcc!=null)||(!"".equals(instStatus)&&instStatus!=null)){
		list=null;
		
		list= entityManager.createQuery(query.toString()).getResultList();
	    System.out.println("Relsuls from list=="+list);
		
	
	}
	}
	catch (Exception ex) {
	ex.printStackTrace();	
	}
	
	return list;
}

@Override
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
public boolean updateStatus(List<Ppm_Inst_Transactions> ppm_Inst_Transactions) throws DAOException {
	
	
	Connection con=null;
	PreparedStatement preparedStatement = null;
	int[] updateCount = null ;
			
	try {
		
	DataSource ds = (DataSource)SpringAppContext.getApplicationContext().getBean("dataSource");
	//con = JNDIUtil.getSimpleDBConnection();
	 con=ds.getConnection();
     String sbQuery ="UPDATE PPM_INST_TRANSACTIONS SET PPM_PROCESS_STATUS=? WHERE PPM_TRAN_REF=? AND PPM_PROCESS_STATUS=?";
	
	//con.setAutoCommit(false);
	
	    preparedStatement = con.prepareStatement(sbQuery);
	
		for(Ppm_Inst_Transactions ppmInstTrns: ppm_Inst_Transactions){
			//System.out.println("ppmInstTrns.getInstRef()--"+ppmInstTrns.getPpmTrnsRef());
			//System.out.println("Status --"+ppmInstTrns.getStatus());
			//if(ppmInstTrns.getStatus().equals("Pending")){
			preparedStatement.setString(1, "1");	
			//}
			preparedStatement.setString(2, ppmInstTrns.getPpmTrnsRef());
			preparedStatement.setString(3, "N");
			preparedStatement.addBatch();
		}			
		
		updateCount = preparedStatement.executeBatch();
		//System.out.println("updateCount==="+updateCount.length);
		//con.commit();
	
		}catch (Exception e) {
	        e.printStackTrace();
	        try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	    } finally {
	
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
	
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
	    }
	    
	    return updateCount.length >= 0 ;
}

@Override
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
public String getMaxRecordsToPost()throws DAOException{
	String sqlNoOfRecords="select value2 from ParameterValue where param_type_code='MAXRECORD'";
	String parameterValue=(String) entityManager.createQuery(sqlNoOfRecords).getSingleResult();
	return parameterValue;
}



@Override
public boolean isUnique(Ppm_Inst_Transactions entity) throws DAOException {
	// TODO Auto-generated method stub
	return false;
}



/*Update PPM_INST_TRANSACTIONS Status,PPM_CAMM_ACTION_CODE and PPM_FTS_ACTION_CODE*/
@Override
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
public int updateInstTransactionsStatusTaskRejected(String trnsRef,String status)throws DAOException{
    int countSucc=0;
    Connection conn=null;
    Statement stmt=null;
	try {
	DataSource ds = (DataSource)SpringAppContext.getApplicationContext().getBean("dataSource");
		//con = JNDIUtil.getSimpleDBConnection();
	conn=ds.getConnection();	
	//String updateQuery="UPDATE Ppm_Inst_Transactions SET status=+"'"+status+"'" ,ftsActionCode=:ftsActionCode,cammActionCode=:cammActionCode,ppmStatusDate=:ppmStatusDate,ppmStatusBy=:ppmStatusBy WHERE ppmTrnsRef=:ppmTrnsRef";
	StringBuilder updateQuery=new StringBuilder();
	updateQuery.append("UPDATE Ppm_Inst_Transactions t set ");
	updateQuery.append("t.PPM_PROCESS_STATUS= ");
	updateQuery.append("'"+status+"'");
	updateQuery.append(",t.PPM_STATUS_DATE= ");
	updateQuery.append("TRUNC(sysdate)");
	updateQuery.append(" WHERE ");
	updateQuery.append("t.PPM_TRAN_REF = ");
	updateQuery.append("'"+ trnsRef+"'");
	//Query queryUpdate=entityManager.createNativeQuery(updateQuery.toString());
    //conn=JNDIUtil.getSimpleDBConnection();
    stmt= conn.createStatement();
    countSucc=stmt.executeUpdate(updateQuery.toString());
	
   }
   catch(Exception daoe){
	   daoe.printStackTrace();
   }
   finally{
		try {

			if (stmt != null)
				stmt.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		try {

			if (conn != null)
				conn.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
   }
  	
   return countSucc;
}





}