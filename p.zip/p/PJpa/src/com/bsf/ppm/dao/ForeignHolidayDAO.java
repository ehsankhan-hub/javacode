package com.bsf.ppm.dao;

import java.util.Date;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.ForeignHoliday;
import com.bsf.ppm.exceptions.DAOException;

public interface ForeignHolidayDAO extends PaginatedDAO<ForeignHoliday, Long>{
	/**
	 * @param valueDate
	 * @param maxDate
	 * @param fromCountry
	 * @param toCountry
	 * @return
	 * @throws DAOException
	 */
	public Date getDateAfterHoliday(Date valueDate ,int maxDate,String fromCountry,String toCountry) throws DAOException;

	/**
	 * @param valueDate
	 * @param fromCountry
	 * @param toCountry
	 * @return
	 * @throws DAOException
	 */
	public Date getLastWorkingDateAfterToday(Date valueDate,String fromCountry,String toCountry) throws DAOException;

	/**
	 * @param valueDate
	 * @return
	 * @throws DAOException
	 */
	public boolean isValueDateIsSystemHoliday(Date valueDate) throws DAOException;

	/**
	 * @param valueDate
	 * @param fromCurrency
	 * @param toCurrency
	 * @param institutionBic
	 * @return
	 * @throws DAOException
	 */
	public boolean isDateNormalHoliday(Date valueDate, String fromCurrency,String toCurrency) throws DAOException;
	

}
