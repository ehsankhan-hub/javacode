package com.bsf.ppm.dao;

import java.io.Serializable;

import com.bsf.ppm.exceptions.DAOException;

/**
 * @author Zakir
 * Data Access Object for Generating Sequences from Oracle Sequences
 */
public interface SequenceGeneratorDAO extends Serializable {

	/**
	 * Fetch the nextValue from DB Sequence.
	 * @param sequenceName name of the DB sequence
	 * @return the Long - next value of the sequence
	 * @throws DAOException
	 */
	public Long getnextValueForSequence(String sequenceName) throws DAOException;
	
	/**
	 * @param <p>messageNumber message for which 
	 * the next value is retrieved from the DB sequence</p>
	 * @return Long  - next value of the sequence fetched from DB
	 * @throws DAOException
	 */
	public Long getnextValueForMessage(String messageNumber) throws DAOException;
}
