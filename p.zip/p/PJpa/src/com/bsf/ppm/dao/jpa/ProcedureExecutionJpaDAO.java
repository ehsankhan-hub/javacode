package com.bsf.ppm.dao.jpa;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.bsf.ppm.dao.ProcedureExcecutionDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.util.JNDIUtil;

/**
 * @author Zakir
 * Java Persistence API implementation for the SequenceGeneratorDAO.
 */
@SuppressWarnings("serial")
public class ProcedureExecutionJpaDAO  implements ProcedureExcecutionDAO {

	/** Logger for ProcedureExecutionJpaDAO */
	private static Logger log = Logger.getLogger(ProcedureExecutionJpaDAO.class);

	/** Attribute sessionFactory representing hibernate sessionFactory */
	private org.hibernate.SessionFactory sessionFactory;

	
	/**
	 * Execute the statistics procedures with procedure name
	 * (bankPymtStatistics,pymtAmtStatistics,paymentStatistics) with date parameter
	 * @param procedureName name of the Stored Procedure
	 * @return
	 * @throws DAOException
	 */
	@SuppressWarnings("deprecation")
	@Override	
	public boolean callStatisticsProcedure(String procedureName,
			Timestamp queryDate,String appId) throws DAOException {
		
		boolean result = false;
		//Fetch connection Object		
		Connection con  = JNDIUtil.getSimpleDBConnection();
		CallableStatement callableStmt = null;
		
		try {
			
			// Prepare callable statement
			callableStmt = con.prepareCall("{call "+procedureName+"(?,?)}");
			callableStmt.setTimestamp(1, queryDate);
			callableStmt.setString(2,appId);
			//execute the callable statement
			result = callableStmt.execute();

		} catch(SQLException e) {
			log.error("Could not execute the procedure "+procedureName);
			throw new DAOException("error.execute.procedure",e,new Object[]{procedureName});
		}
		finally {
			try {
				if(callableStmt != null) callableStmt.close();
				if(con != null) con.close();				
			} catch (SQLException e) {
				log.warn(e.getMessage());
			}
		}
		return result;
	}
	
	
}
