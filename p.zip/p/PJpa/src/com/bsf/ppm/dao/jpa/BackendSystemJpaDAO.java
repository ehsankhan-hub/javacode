package com.bsf.ppm.dao.jpa;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.dao.BackendSystemDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.BackendSystem;
/**
 * @author Zakir
 * Java Persistence API implementation for the BackendSystemDAO.
 */
@Transactional
public class BackendSystemJpaDAO extends PaginatedJpaDAO<BackendSystem, Long> implements BackendSystemDAO {

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(BackendSystem entity) throws DAOException {
		long recordCount = -1;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
					.append(getPersistentClass().getSimpleName()).append(
							"  obj  where obj.id !=:id  and  obj.systemName=:systemName ");
			Query jpaQuery = entityManager.createQuery(query.toString());
			if(entity.getId() !=null) {
				jpaQuery.setParameter("id", entity.getId());
			}
			else {
				jpaQuery.setParameter("id",Long.valueOf(-1));
			}
			jpaQuery.setParameter("systemName", entity.getSystemName());
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
		
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}
		return recordCount <= 0;
	}
	
	public BackendSystem getBackendByName(String backendName) throws DAOException{
		Map<String, String> backendSearchCriteria = new HashMap<String, String>();
		backendSearchCriteria.put("systemName",backendName);
		List<BackendSystem> backendSystems = findByCriteria(backendSearchCriteria);
		//System.out.print("backendSystems name="+backendSystems.get(0));
		if(backendSystems.size() > 0 )
		return backendSystems.get(0);
		else
		return null;
	}

}
