package com.bsf.ppm.dao;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.BatchJob;

/**
 * @author Zakir
 * Data Access Object for BatchJob Entity. Extends PaginatedDAO
 */
public interface BatchJobDAO extends PaginatedDAO<BatchJob, Long> {

}
