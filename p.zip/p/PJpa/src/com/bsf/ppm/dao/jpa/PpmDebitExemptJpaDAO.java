package com.bsf.ppm.dao.jpa;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.A_Account;
import com.bsf.ppm.A_Block_Deblock;
import com.bsf.ppm.C_Block_Deblock;
import com.bsf.ppm.IncomingSalaries;
import com.bsf.ppm.PpmDebitBlockStaging;
import com.bsf.ppm.PpmDebitExempt;
import com.bsf.ppm.dao.PpmAccountInquiryDAO;
import com.bsf.ppm.dao.PpmDebitBlockStagingDAO;
import com.bsf.ppm.dao.PpmDebitExemptDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.util.JNDIUtil;


@Transactional
public  class PpmDebitExemptJpaDAO extends PaginatedJpaDAO<PpmDebitExempt, String> implements PpmDebitExemptDAO {
	
	@Override
	public List<PpmDebitExempt> getBlockAccountsDtlsCamm()
			throws DAOException {
		List<PpmDebitExempt> list=null;  
		
		try{
        list=entityManager.createQuery("select custCode from C_Block_Deblock where ((acctStatusCamm='DB' and statuRsnCodeCamm='20') OR (acctStatusCamm='FB' AND statuRsnCodeCamm='43')) AND deblkDate is null group by custCode").getResultList(); 
       
		}
		catch(Exception de){
			de.printStackTrace();
		}
		
		if(list != null && list.size()>0)
		{
			
		return list;
		}
		else{
			return null;
		}
	}
	
	@Transactional	
	public PpmDebitExempt getCustomerCode(String customerCode)
			throws DAOException {
		String query = "";
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;

		query = "select * from PPM_DEBIT_EXEMPT where CUST_CODE=" + "'"
				+ customerCode + "'";

		PpmDebitExempt ppmDebitExempt = null;
		try {
			con = JNDIUtil.getConnection();
			
			// log.info("Successfully get the database connection..."+con);
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				ppmDebitExempt = new PpmDebitExempt();
				String custCode = rs.getString("CUST_CODE");
				
				ppmDebitExempt.setCustCode(custCode);
				// debitBlock.add(ppmDebitBlockStag);
				break;
			}
		} catch (Exception e) {
			// log.error("Exception occured--"+e.getMessage());
			e.printStackTrace();
		} finally {
			if (rs != null) {
				// log.info("Trying to close ResultSet connection");
				try {
					rs.close();
					// log.info("Successfully closed ResultSet connection");
				} catch (SQLException e) {
					// log.error("Exception occured--"+e.getMessage());
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				// log.info("Trying to close Statement connection");
				try {
					stmt.close();
					// log.info("Successfully closed Statement connection");
				} catch (SQLException e) {
					// log.error("Exception occured--"+e.getMessage());
					e.printStackTrace();
				}
			}
			if (con != null) {
				// log.info("Trying to close Connection");
				try {
					con.close();
					// log.info("Successfully closed Connection");
				} catch (SQLException e) {
					// log.error("Exception occured--"+e.getMessage());
					e.printStackTrace();
				}
			}
		}

		return ppmDebitExempt;
	}
	
	
	
	
	@Override
	public String getByAcctNo(String cpt)
			throws DAOException {
       
        String list=null; 
        try{
        
        list=(String)entityManager.createQuery("select custCode from C_Block_Deblock where ((acctStatusCamm='DB' and statuRsnCodeCamm='20') OR (acctStatusCamm='FB' AND statuRsnCodeCamm='43')) AND custCode="+"'"+cpt+"'" +"AND deblkDate is null group by custCode").getSingleResult();
       		
        }
		catch(Exception de){
			de.printStackTrace();
		}
		
		if(list != null)
		{
			
		return list;
		}
		else
		{
		return null;
		}	
		
		
	
	}
	
	
	
	

@Override
public boolean isUnique(PpmDebitExempt entity) throws DAOException {
	// TODO Auto-generated method stub
	return false;
}

}