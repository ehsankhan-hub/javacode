package com.bsf.ppm.dao;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.BatchJobHistory;

/**
 * @author Zakir
 * Data Access Object for BatchJobHistory Entity
 * Provides search and find methods for searchCriteria ,sorting, pageNumbers
 */
public interface BatchJobHistoryDAO extends PaginatedDAO<BatchJobHistory, Long> {

}
