package com.bsf.ppm.dao;

import java.util.List;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.DomesticBank;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.AccountClass;
import com.bsf.ppm.InstructionDetails;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.PpmExeRulesCriteria;
import com.bsf.ppm.PpmParameterType;
import com.bsf.ppm.PpmParameterValue;
import com.bsf.ppm.PpmParameterValuesSetup;


public interface ParameterValueDAO extends PaginatedDAO<ParameterValue, String>{
	
	public List<ParameterValue> getFrequencyList()throws DAOException;
	//SFL General Narrative 
	public ParameterValue getSFLGenralNarrative()
			throws DAOException;
	
	public List<DomesticBank> getDomesticBankList()throws DAOException;
	
	public List<ParameterValue> getPriorityList()throws DAOException;
	
	public List<ParameterValue> getAccountType(String acctType)throws DAOException;
	
	public List<ParameterValue> getMaxDayRangAndTrgrNextCyclDay(String dayRange)throws DAOException;
	
	public  List<ParameterValue> getBlockUnblockFlag()throws DAOException;
    
	public List<ParameterValue> getStatus()throws DAOException;
	
	public List<ParameterValue> getFieldNameList()throws DAOException;
	
	public List<ParameterValue> getValueList(String param)throws DAOException;
	
	public List<ParameterValue> getPercent()throws DAOException;
	
	public String getFilePath()throws DAOException;
	
	public List<InstructionDetails> getSamaDocFilePath(String instReference)throws DAOException;

	public List<ParameterValue> getExecutionTypeList()throws DAOException;

	public List<ParameterValue> getGroupCode() throws DAOException ;
	
	/*TRANSACTION REPORTS*/
	public List<ParameterValue> getSourceSystemList()throws DAOException;
    
	public List<ParameterValue> getTransTypeList()throws DAOException;
	
	//By SARaheem
	
	public List<ParameterValue> getEmpCategoryList()throws DAOException;
	public List<ParameterValue> getEmpCategoryDescList()throws DAOException;
	
	public List<PpmParameterValuesSetup> getEmpCategorySetupList() throws DAOException;
	
	public void updateEmpCategorySetupList(AccountClass item) throws DAOException;	
	
	public void insertLogHistory(AccountClass item,String action) throws DAOException;
	
	public void insertLogHistoryEmpSetupDel(String empCategory) throws DAOException;
	
	
	
	public List<AccountClass> checkCategoryExists(String category)throws DAOException;
	
}
