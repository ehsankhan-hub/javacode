package com.bsf.ppm.dao.jpa;

import javax.persistence.Query;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.SystemType;
import com.bsf.ppm.dao.SystemTypeDAO;
import com.bsf.ppm.exceptions.DAOException;
/**
 * @author Zakir
 * Java Persistence API implementation for the SystemTypeDAO.
 */
@Transactional
public class SystemTypeJpaDAO extends PaginatedJpaDAO<SystemType, Long> implements SystemTypeDAO {

	@Override
	public boolean isUnique(SystemType entity) throws DAOException {
		long recordCount = -1;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
					.append(getPersistentClass().getSimpleName()).append(
							"  obj  where obj.id !=:id  and  obj.typeName=:typeName ");
			Query jpaQuery = entityManager.createQuery(query.toString());
			if(entity.getId() !=null) {
				jpaQuery.setParameter("id", entity.getId());
			}
			else {
				jpaQuery.setParameter("id",Long.valueOf(-1));
			}
			jpaQuery.setParameter("currencyCode", entity.getTypeName());
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}

		return recordCount <= 0;
	}

}
