package com.bsf.ppm.dao;

import java.util.List;

import com.bsf.ipp.dao.GenericDAO;
import com.bsf.ppm.UserGroup;
import com.bsf.ppm.exceptions.DAOException;

public interface UserGroupDAO extends GenericDAO<UserGroup, Long> {
	
	public List<UserGroup> getGroupsByADName(List<String> adGroupNames) throws DAOException;

}
