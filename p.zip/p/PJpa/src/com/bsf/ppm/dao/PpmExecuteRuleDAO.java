package com.bsf.ppm.dao;

import java.util.List;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.PpmExeRules;
import com.bsf.ppm.PpmExeRulesCriteria;
import com.bsf.ppm.PpmParameterValue;
import com.bsf.ppm.exceptions.DAOException;

public interface PpmExecuteRuleDAO extends PaginatedDAO<PpmExeRules, String> {
	
	public void updateEntityStatusByIds(String[] ids,String idField, 
	String statusField,String status, UserInfo modifiedBy) throws DAOException;
	public boolean isUniqueJoinTable(List<PpmExeRulesCriteria> benList) throws DAOException ;
	public boolean isUniqueFromListObject(List<PpmExeRulesCriteria> benList) throws DAOException ;
	public void deletRule(String exeRuleName)throws DAOException;
	public List<PpmExeRulesCriteria>getRuleDtlCrtList(String ruleName)throws DAOException;
	public List<PpmExeRulesCriteria>deleteDtlCrtList(String exeRuleName,String fieldName,String value1)throws DAOException;
	public PpmExeRules getPpmExeRulesList(String ruleName)throws DAOException;
	public void updatePpmExeRulesCrit(String ruleName,String fieldName,String value1)
	throws DAOException;
	public void  updatePpmExeRuleNewCrit(int ruleId,String ruleName,String fupddName,String fupdValue) throws DAOException;
	

}
