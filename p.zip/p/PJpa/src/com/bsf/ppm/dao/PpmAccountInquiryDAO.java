package com.bsf.ppm.dao;

import java.util.List;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.A_Account;
import com.bsf.ppm.A_Block_Deblock;
import com.bsf.ppm.C_Block_Deblock;
import com.bsf.ppm.PpmDebitBlockStaging;
import com.bsf.ppm.exceptions.DAOException;



public interface PpmAccountInquiryDAO extends PaginatedDAO<C_Block_Deblock, String>{
/*public List<A_Block_Deblock>   getBlockAccountsDtlsCamm()
			throws DAOException;
public A_Block_Deblock getByAcctNo(String acctNo)
		throws DAOException;*/
	
	public List<C_Block_Deblock>   getBlockAccountsDtlsCamm()
			throws DAOException;
public String  getByAcctNo(String acctNo)
		throws DAOException;
	
	

}
