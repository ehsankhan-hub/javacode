package com.bsf.ppm.dao.jpa;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;

import com.bsf.ppm.C_Block_Deblock;
import com.bsf.ppm.PpmDebitBlockStaging;
import com.bsf.ppm.Ppm_Instructions;
import com.bsf.ppm.dao.PpmDebitBlockStagingDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.spring.SpringAppContext;
import com.bsf.ppm.util.JNDIUtil;
import com.bsf.ppm.util.SessionFactoryCisprodManager;


//@Transactional
public  class PpmDebitBlockStagingJpaDAO extends PaginatedJpaDAO<PpmDebitBlockStaging, String> implements PpmDebitBlockStagingDAO {

private static final Logger logger = Logger.getLogger("SalaryPercentInstructionCreation");	
	
private DataSource dataSourceSlry;	
	


public DataSource getDataSourceSlry() {
	dataSourceSlry=(DataSource) SpringAppContext.getBean("dataSourceSlry");
	return dataSourceSlry;
}


public void setDataSourceSlry(DataSource dataSourceSlry) {
	this.dataSourceSlry = dataSourceSlry;
}


@Transactional	
public List<PpmDebitBlockStaging> getAccountsFromStaging(String status)throws DAOException{
	String query="";
	if(status.equals("")){
		query="from PpmDebitBlockStaging";	
	
	}
	else{
	query="from PpmDebitBlockStaging where status="+"'"+status+"'";	
	}
    List<PpmDebitBlockStaging> debitBlock=null;
	try{
	debitBlock=entityManager.createQuery(query).getResultList();
    if(debitBlock!=null&&debitBlock.size()>0){
	return debitBlock;
	}
	
	}
			
	catch(Exception ex){
		ex.printStackTrace();
		
	}
	
	return debitBlock;
}



/*@Transactional	
public List<PpmDebitBlockStaging> getAccountsFromStaging(String status)throws DAOException{
	String query="";
	Connection con=null;
	Statement stmt = null;
	ResultSet rs=null;
	PpmDebitBlockStaging ppmDebitBlockStag=null;
	if(status.equals("")){
		query="select * from PPM_DEBIT_BLOCK_STAGING";	
	
	}
	else{
	query="select * from PPM_DEBIT_BLOCK_STAGING where status="+"'"+status+"'";	
	}
    List<PpmDebitBlockStaging> debitBlock=new ArrayList<PpmDebitBlockStaging>();
	try{
		con=JNDIUtil.getConnection();
		
		//log.info("Successfully get the database connection..."+con);
		stmt=con.createStatement();
		rs=stmt.executeQuery(query);
		 while (rs.next()) {
			
	     String custCode = rs.getString("CUST_CODE");
	     String statusAaction=rs.getString("STATUS");
	     
	     ppmDebitBlockStag=new PpmDebitBlockStaging();
	     ppmDebitBlockStag.setCustCode(custCode);
	     ppmDebitBlockStag.setStatus(statusAaction);
	     debitBlock.add(ppmDebitBlockStag);
	   	 }
	}
	catch (Exception e) {
		//log.error("Exception occured--"+e.getMessage());
		e.printStackTrace();
	}finally {
	    if (rs != null) {
	    	//log.info("Trying to close ResultSet connection");
	        try {
	            rs.close();
	       //  log.info("Successfully closed ResultSet connection");   
	        } catch (SQLException e) {
	       //  log.error("Exception occured--"+e.getMessage());	
              e.printStackTrace();
	        }
	    }
	    if (stmt != null) {
	    	//log.info("Trying to close Statement connection");
	        try {
	        	stmt.close();
	      //  log.info("Successfully closed Statement connection");	
	        } catch (SQLException e) { 
	       // log.error("Exception occured--"+e.getMessage());	
            e.printStackTrace();
	        }
	    }
	    if (con != null) {
	    	//log.info("Trying to close Connection");
	        try {
	            con.close();
	           // log.info("Successfully closed Connection");
	        } catch (SQLException e) {
	        	//log.error("Exception occured--"+e.getMessage());
	        	e.printStackTrace();
	        }
	    }
	}
	
	
	
	return debitBlock;
}*/



@Transactional	
public PpmDebitBlockStaging getCustomerCode(String customerCode)throws DAOException{
	String query="";
	JNDIUtil jndiUtil=new JNDIUtil();
	Connection con=null;
	Statement stmt = null;
	ResultSet rs=null;
	PpmDebitBlockStaging ppmDebitBlockStag=null;
	
	query="select * from PPM_DEBIT_BLOCK_STAGING where CUST_CODE="+"'"+customerCode+"'";	
	
    List<PpmDebitBlockStaging> debitBlock=new ArrayList<PpmDebitBlockStaging>();
	try{
		con=JNDIUtil.getConnection();
		
		//log.info("Successfully get the database connection..."+con);
		stmt=con.createStatement();
		rs=stmt.executeQuery(query);
		 while (rs.next()) {
			
	     String custCode = rs.getString("CUST_CODE");
	     
	     ppmDebitBlockStag=new PpmDebitBlockStaging();
	     ppmDebitBlockStag.setCustCode(custCode);
	     //debitBlock.add(ppmDebitBlockStag);
	   	 }
	}
	catch (Exception e) {
		//log.error("Exception occured--"+e.getMessage());
		e.printStackTrace();
	}finally {
	    if (rs != null) {
	    	//log.info("Trying to close ResultSet connection");
	        try {
	            rs.close();
	       //  log.info("Successfully closed ResultSet connection");   
	        } catch (SQLException e) {
	       //  log.error("Exception occured--"+e.getMessage());	
              e.printStackTrace();
	        }
	    }
	    if (stmt != null) {
	    	//log.info("Trying to close Statement connection");
	        try {
	        	stmt.close();
	      //  log.info("Successfully closed Statement connection");	
	        } catch (SQLException e) { 
	       // log.error("Exception occured--"+e.getMessage());	
            e.printStackTrace();
	        }
	    }
	    if (con != null) {
	    	//log.info("Trying to close Connection");
	        try {
	            con.close();
	           // log.info("Successfully closed Connection");
	        } catch (SQLException e) {
	        	//log.error("Exception occured--"+e.getMessage());
	        	e.printStackTrace();
	        }
	    }
	}
	
	
	
	return ppmDebitBlockStag;
}


public String getCtznAccount(String dbAccountNo)	throws DAOException,Exception{
	boolean result = false;
	Connection con=null;
	CallableStatement stmt =null;
	String returnCode="";
	String ctznAccount="";
	try{
	con = JNDIUtil.getConnection();
	
	System.out.println("Connection ==="+con);
	//SessionFactory sessionFactory=new AnnotationConfiguration().configure().buildSessionFactory();
	//Session session=sessionFactory.openSession();
	
	//System.out.println("session---"+session);
	
	if(con !=null)	{
		//con.setAutoCommit(false);
		stmt = con.prepareCall("{call CTZN_ACCT_PKG.retrieve_ctzn_acct(?, ?,?)}");
		stmt.setString(1, dbAccountNo);
		stmt.registerOutParameter(2, java.sql.Types.VARCHAR);
		stmt.registerOutParameter(3, java.sql.Types.VARCHAR);
		result=stmt.execute();
		
		ctznAccount=stmt.getString(2);
		returnCode=stmt.getString(3);
		
		logger.info("Trying call procedure RETRIEVE_CTZN_ACCT Procedure getting return code:="+returnCode);
	}
	}
	catch (Exception e) {
		try {
			if (con!=null)
			{con.close();
			}				
			
		} catch (SQLException e1) {			
			e1.printStackTrace();
		}
			e.printStackTrace();
	}finally{
		try {	
			
			//log.info("Trying to close CallableStatement ");
			if (stmt!=null)
			{
				stmt.close();
			//log.info("Successfully closed CallableStatement");   
			}
			if (con != null){
			//log.info("Trying to close Connection ");	
			con.close();
			//log.info("Successfully closed Connection");
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	}
	if(ctznAccount==null){
		return returnCode;
	}
	
	return 	ctznAccount;
	
}


/*  */
@Override
public String getPPMReferenceSalaryPercen() throws DAOException {
	String sql = "SELECT PPM_INS_REF.NEXTVAL FROM DUAL";
	JNDIUtil jndiUtil=new JNDIUtil();
	Connection con=null;
	Statement stmt = null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	Long ppmReferceneId = null;
	try {
		con=JNDIUtil.getConnection();
		ps = con.prepareStatement(sql);
		System.out.println(ps);
		rs=ps.executeQuery();
		if(rs.next()){
		ppmReferceneId=rs.getLong(1)	;
		}
	}
   	
		
		//System.out.println("Sequence Value="+bd.longValue());
		
	 catch (Exception ex) {
		ex.printStackTrace();
	}
	finally {
	    if (rs != null) {
	    	//log.info("Trying to close ResultSet connection");
	        try {
	            rs.close();
	       //  log.info("Successfully closed ResultSet connection");   
	        } catch (SQLException e) {
	       //  log.error("Exception occured--"+e.getMessage());	
              e.printStackTrace();
	        }
	    }
	    if (stmt != null) {
	    	//log.info("Trying to close Statement connection");
	        try {
	        	stmt.close();
	      //  log.info("Successfully closed Statement connection");	
	        } catch (SQLException e) { 
	       // log.error("Exception occured--"+e.getMessage());	
            e.printStackTrace();
	        }
	    }
	    if (con != null) {
	    	//log.info("Trying to close Connection");
	        try {
	            con.close();
	           // log.info("Successfully closed Connection");
	        } catch (SQLException e) {
	        	//log.error("Exception occured--"+e.getMessage());
	        	e.printStackTrace();
	        }
	    }
	}
	return "P"+ppmReferceneId;
}
/*  */



/*  */
@Override
public String getPPMReference() throws DAOException {
	String sql = "SELECT PPM_INS_REF.NEXTVAL FROM DUAL";
	
	try {
		// Execute native query and get the result list
		List results= entityManager.createNativeQuery(sql).getResultList();
		// Iterate the list and get the sequence value
		BigDecimal bd = (BigDecimal)results.iterator().next();
		
		System.out.println("Sequence Value="+bd.longValue());
		return "P"+bd.longValue();
	} catch (RuntimeException ex) {
		throw new DAOException("error.executeQuery", ex,
				getPersistentClass().getName(), sql);
	}
}
/*  */



/*  */
@Override
public Long getInstDetaiSeqGen() throws DAOException {
	String sql = "SELECT PPM_INS_DTL_ID.NEXTVAL FROM DUAL";
	try {
		// Execute native query and get the result list
		List results= entityManager.createNativeQuery(sql).getResultList();
		// Iterate the list and get the sequence value
		BigDecimal bd = (BigDecimal)results.iterator().next();
		System.out.println("Sequence Value="+bd);
		return bd.longValue();
	} catch (RuntimeException ex) {
		throw new DAOException("error.executeQuery", ex,
				getPersistentClass().getName(), sql);
	}
}


@Override
public Long getInstDetaiSeqGenSalaryPercen() throws DAOException {
	String sql = "SELECT PPM_INS_DTL_ID.NEXTVAL FROM DUAL";
	JNDIUtil jndiUtil=new JNDIUtil();
	Connection con=null;
	Statement stmt = null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	Long ppmReferceneId = null;
	try {
		con=JNDIUtil.getConnection();
		ps = con.prepareStatement(sql);
		System.out.println(ps);
		rs=ps.executeQuery();
		if(rs.next()){
		ppmReferceneId=rs.getLong(1)	;
		}
	} catch (Exception ex) {
		ex.printStackTrace();
	}
	finally {
	    if (rs != null) {
	    	//log.info("Trying to close ResultSet connection");
	        try {
	            rs.close();
	       //  log.info("Successfully closed ResultSet connection");   
	        } catch (SQLException e) {
	       //  log.error("Exception occured--"+e.getMessage());	
              e.printStackTrace();
	        }
	    }
	    if (stmt != null) {
	    	//log.info("Trying to close Statement connection");
	        try {
	        	stmt.close();
	      //  log.info("Successfully closed Statement connection");	
	        } catch (SQLException e) { 
	       // log.error("Exception occured--"+e.getMessage());	
            e.printStackTrace();
	        }
	    }
	    if (con != null) {
	    	//log.info("Trying to close Connection");
	        try {
	            con.close();
	           // log.info("Successfully closed Connection");
	        } catch (SQLException e) {
	        	//log.error("Exception occured--"+e.getMessage());
	        	e.printStackTrace();
	        }
	    }
	}
   
	return ppmReferceneId;
}
@Transactional	
public void savePpmDebitBlockStaging(PpmDebitBlockStaging ppmDebitBlockStaging)throws DAOException{
	
	
	Session session=JNDIUtil.getSession();
	
	Transaction transaction=session.beginTransaction();
	session.save(ppmDebitBlockStaging);
	transaction.commit();
	session.flush();
	session.close();
	System.out.println("session---"+session);
}


@Transactional	
public void savePpmDebitBlockStaging(List<PpmDebitBlockStaging> ppmDebitBlockStaging)throws DAOException{
	
	try{
	Session session=SessionFactoryCisprodManager.getSession();
	Transaction transaction=session.beginTransaction();
	for (int i=0;i<ppmDebitBlockStaging.size();i++){
		session.save(ppmDebitBlockStaging);	
	    if ( i % 100 == 0 ) { 
	    	session.flush();
	    	
	    	
	    }
	}
	
	transaction.commit();
	session.close();	
	}
	catch(Exception ex){
		ex.printStackTrace();
	}
	
	
	
	
}



@Transactional	
public void updatePpmDebitBlockStaging(PpmDebitBlockStaging ppmDebitBlockStaging)throws DAOException{
	
	///SessionFactory sessionFactory=new AnnotationConfiguration().configure().buildSessionFactory();
	//Session session=sessionFactory.openSession();
	try {
		Session session=JNDIUtil.getSession();
		
		Transaction transaction=session.beginTransaction();
		session.saveOrUpdate(ppmDebitBlockStaging);
		transaction.commit();
		session.flush();
		session.close();
		
	} catch (Exception e) {
		System.out.println(e);
		throw new DAOException(e.getMessage());
	}
}

public PpmDebitBlockStaging findPpmDebitBlockStagingSalaryPercent(PpmDebitBlockStaging ppmDebitBlockStaging)throws DAOException{
	//String query="from Ppm_Instructions where custCode="+"'"+ppmInstruction.getCustCode()+"' AND instReference="+"'"+ppmInstruction.getInstReference()+"'";
	String query="from PpmDebitBlockStaging where custCode="+"'"+ppmDebitBlockStaging.getCustCode()+"'";
	//SessionFactory sessionFactory=new AnnotationConfiguration().configure().buildSessionFactory();
	//Session session=sessionFactory.openSession();
	PpmDebitBlockStaging ppmInst= null;
	try {
		Session session=JNDIUtil.getSession();
		ppmInst=(PpmDebitBlockStaging)session.createQuery(query).uniqueResult();
		
		System.out.println("ppmInst"+ppmInst.getCustCode()); 
		session.close();			
	} catch (Exception e) {
		System.out.println(e);
		throw new DAOException(e.getMessage());
	}
	
	//Ppm_Instructions ppmInst=(Ppm_Instructions)session.get(Ppm_Instructions.class, ppmInstruction.getInstReference());
	return ppmInst;
}


@Override
public boolean isUnique(PpmDebitBlockStaging entity) throws DAOException {
	// TODO Auto-generated method stub
	return false;
}

}