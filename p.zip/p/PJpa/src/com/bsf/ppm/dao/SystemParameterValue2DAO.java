package com.bsf.ppm.dao;

import com.bsf.ipp.dao.GenericDAO;
import com.bsf.ppm.SystemParameterValue2;
import com.bsf.ppm.exceptions.DAOException;

public interface SystemParameterValue2DAO extends GenericDAO<SystemParameterValue2, String>{
	
	public SystemParameterValue2 fetchByCodeValues(String codeVal2, String codeVal3) throws DAOException;

}
