package com.bsf.ppm.dao;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.BackendSystem;

/**
 * @author Zakir
 * Data Access Object for BackendSystem Entity. Extends PaginatedDAO
 */
public interface BackendSystemDAO extends PaginatedDAO<BackendSystem, Long> {

	public BackendSystem getBackendByName(String backendName) throws DAOException;
}
