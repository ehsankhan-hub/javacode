/**
 * 
 */
package com.bsf.ppm.dao;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.UserGroup;

/**
 * @author bsaleem
 * 
 * This interface is a plain  DAO for retrieving Groups related data.
 *
 */
public interface GroupDAO extends PaginatedDAO<UserGroup, Long> {

}
