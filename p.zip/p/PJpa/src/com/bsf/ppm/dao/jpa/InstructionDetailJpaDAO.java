package com.bsf.ppm.dao.jpa;


import org.springframework.transaction.annotation.Transactional;
import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.dao.InstructionDetailDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.InstructionDetails;

@Transactional
public class InstructionDetailJpaDAO extends PaginatedJpaDAO<InstructionDetails, String> implements InstructionDetailDAO {

	
	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(InstructionDetails entity) {
		// TODO Auto-generated method stub
		return false;
	}

	
	public InstructionDetails getInstructionDetails(Long ref) throws DAOException {
	String query="from com.bsf.ppm.InstructionDetails where instReference="+ref+"";
	InstructionDetails result=(InstructionDetails)entityManager.createQuery(query.toString()).getSingleResult();	
	return result ;
	}
	
	public InstructionDetails getInstructionDtlByDtlId(Long dtlId) throws DAOException {
		String query="from com.bsf.ppm.InstructionDetails where instReference="+dtlId+"";
		InstructionDetails result=(InstructionDetails)entityManager.createQuery(query.toString()).getSingleResult();	
		return result ;
		}
	
	
  
		
	

}