package com.bsf.ppm.dao.jpa;

import java.util.ArrayList;
import java.util.List;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.SystemParameterValue2;
import com.bsf.ppm.dao.SystemParameterValue2DAO;
import com.bsf.ppm.exceptions.DAOException;

public class SystemParameterValue2JpaDAO extends 
PaginatedJpaDAO<SystemParameterValue2, String>
implements SystemParameterValue2DAO{

	@Override
	public boolean isUnique(SystemParameterValue2 entity) throws DAOException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public SystemParameterValue2 fetchByCodeValues(String value2,
			String value3) throws DAOException {
		List<SystemParameterValue2> listItems = new ArrayList<SystemParameterValue2>();
		
		String[] namedParams = { "value2", "value3" };
		Object[] params = { value2, value3 };
		listItems = findByNamedQuery("SystemParameterValue2.findByValue2AndValue3",
				namedParams, params);
		
		if (listItems != null && listItems.size() > 0) {
			return listItems.get(0);
		}
		return null;
	}	
	
}
