package com.bsf.ppm.dao.jpa;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TemporalType;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.ForeignHoliday;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.dao.ForeignHolidayDAO;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.util.DateUtils;

public class ForeignHolidayJpaDAO extends PaginatedJpaDAO<ForeignHoliday, Long>
implements ForeignHolidayDAO{

	@Override
	public boolean isUnique(ForeignHoliday entity) throws DAOException {
		long recordCount ;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
			.append(getPersistentClass().getSimpleName()).append(
			"  obj  where obj.id !=:id  and  obj.holidayDate=:holidayDate and obj.countryCode=:countryCode");
			Query jpaQuery = entityManager.createQuery(query.toString());
			if(entity.getId() !=null)
				jpaQuery.setParameter("id", entity.getId());
			else
				jpaQuery.setParameter("id",Long.valueOf(-1));	
			jpaQuery.setParameter("holidayDate", entity.getHolidayDate());
			jpaQuery.setParameter("countryCode", entity.getCountryCode());
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}

		return recordCount <= 0;
	}

	/**
	 * @param valueDate
	 * @param maxDate
	 * @param fromCountry
	 * @param toCountry
	 * @return
	 */
	public Date getDateAfterHoliday(Date valueDate ,int maxDate,String fromCountry,String toCountry) throws DAOException{
		try {
			String query = "select dt from " +
			"(SELECT trunc(:valueDate+ level-1)   dt FROM dual  CONNECT BY level <=(:maxDate-trunc(:valueDate-sysdate)) ) " +
			"where dt not  in (select trunc(holiday_date)  from  FOREIGN_HOLIDAY where country_code in(:fromCountry,:toCountry)" +
			" and holiday_type in ('H','W') " +
			"and  holiday_date between :valueDate and  sysdate+(:maxDate-trunc(:valueDate-sysdate)))  and rownum<=1  " +
			"and trunc(sysdate) <=:valueDate  and  (sysdate+:maxDate) >trunc(:valueDate) order by dt";
			Query nativeQuery = entityManager.createNativeQuery(query);
			nativeQuery.setParameter("valueDate",valueDate,TemporalType.DATE);
			nativeQuery.setParameter("maxDate",maxDate);

			nativeQuery.setParameter("fromCountry",fromCountry);
			nativeQuery.setParameter("toCountry",toCountry);
			List<java.sql.Date> resultList = nativeQuery.getResultList();
			if(resultList !=null && resultList.size()>0){
				return new Date(resultList.get(0).getTime());
			}
			return null;
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("getDateAfterHol", ex, getPersistentClass()
					.getName());
		}

	}

	@Override
	public Date getLastWorkingDateAfterToday(Date valueDate,String fromCountry, String toCountry) throws DAOException {
		try {
			String 
			query="select dt from (select dt from (SELECT trunc(sysdate+ level-1)   dt FROM dual  " +
			"CONNECT BY level <=:valueDate-trunc(sysdate) )  where  trunc(:valueDate)>=trunc(sysdate)" +
			"and  dt not  in (select trunc(holiday_date)  from FOREIGN_HOLIDAY " +
			"where country_code in(:fromCountry,:toCountry)  and holiday_type in ('H','W')  " +
			"and  holiday_date between sysdate and :valueDate ) order by dt desc ) where rownum<=2";
			Query nativeQuery = entityManager.createNativeQuery(query);
			nativeQuery.setParameter("valueDate",valueDate,TemporalType.DATE);
			nativeQuery.setParameter("fromCountry",fromCountry);
			nativeQuery.setParameter("toCountry",toCountry);
			List<java.sql.Date> resultList = nativeQuery.getResultList();
			if(resultList !=null && resultList.size()>1){
				return new Date(resultList.get(1).getTime());
			}
			return null;
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("getDateAfterHol", ex, getPersistentClass()
					.getName());
		}

	}

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.ForeignHolidayDAO#isValueDateIsSystemHoliday(java.util.Date)
	 */
	@Override
	public boolean isValueDateIsSystemHoliday(Date valueDate)
	throws DAOException {
		String[] namedParams = { "holidayDate",	IConstants.DEFAULT_STATUS_FIELD };
		Object[] params={valueDate,Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal())};
		List<ForeignHoliday> bicList = findByNamedQuery("ForeignHoliday.isDateSystemHoliday", namedParams, params);
		if(bicList !=null && bicList.size()>0){
			return true;
		}
		return false;

	}
	
	public boolean isValueDateIsHoliday(Date valueDate,String fromCurrency,String toCrrency)
	throws DAOException {
		String[] namedParams = { "holidayDate",	IConstants.DEFAULT_STATUS_FIELD };
		Object[] params={valueDate,Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal())};
		List<ForeignHoliday> bicList = findByNamedQuery("ForeignHoliday.isDateSystemHoliday", namedParams, params);
		if(bicList !=null && bicList.size()>0){
			return true;
		}
		return false;

	}

	/**
	 * @param destCountry
	 * @param valueDate
	 * @param maxDate
	 * @return
	 * @throws ApplicationException
	 */
	public Date getDateAfterHolidays(String destCountry,Date valueDate,Date maxDate) throws ApplicationException{
		Calendar calendar=Calendar.getInstance();
		String[] param = { "countryCode", "holidayDate",	IConstants.DEFAULT_STATUS_FIELD };
		Object[] paramValues = { destCountry, valueDate ,Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()) };
		List<ForeignHoliday> list= null; 
		boolean isHoliday = true;
		while(isHoliday){
			list =findByNamedQuery("ForeignHoliday.searchHWTypeHolidaysByCountryAndDate", param, paramValues);
			if (list!=null && list.size()>0){							
				calendar.add(Calendar.DAY_OF_MONTH, 1);
				paramValues[1] = calendar.getTime();								
			}
			else{
				isHoliday = false;
			}
		}	

		if(DateUtils.compareTruncatedDates(maxDate,calendar.getTime() )>=0){
			return calendar.getTime();
		}
		return null;
	}

	@Override
	public boolean isDateNormalHoliday(Date valueDate, String fromCurrency,
			String toCurrency) throws DAOException {
		
		String[] namedParams = { "holidayDate",	"fromCountry","toCountry",IConstants.DEFAULT_STATUS_FIELD };
		
		Object[] params={valueDate,fromCurrency.subSequence(0, 2),toCurrency.subSequence(0, 2),Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal())};
		List<ForeignHoliday> bicList = findByNamedQuery("ForeignHoliday.isDateNormalHoliday", namedParams, params);
		if(bicList !=null && bicList.size()>0){
			return true;
		}
		return false;

	}




}
