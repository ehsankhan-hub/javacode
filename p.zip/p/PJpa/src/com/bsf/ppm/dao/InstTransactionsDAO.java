package com.bsf.ppm.dao;
import java.util.Date;
import java.util.List;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.Ppm_Inst_Transactions;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.fts.FTSRequestPostingEntityMRKI;
import com.bsf.ppm.fts.FTSRequestPostingEntityMRKM;
import com.bsf.ppm.fts.FTSResponsePostingEntity;
import com.bsf.ppm.Ppm_Inst_Transactions;


public interface InstTransactionsDAO extends PaginatedDAO<Ppm_Inst_Transactions, String>{
public String loadBusinessDate()	;
public int updateInstTransactionsCtznAccount(String ctznAccount,String trnsRef)throws DAOException;
public Long getTTReferenceSeqGen() throws DAOException ;
public Long getReferenceSeqGen() throws DAOException ;
public  Ppm_Inst_Transactions getInstTransaction(String trnsRef)throws DAOException;
public Ppm_Inst_Transactions getTrnsInstRef(String instRef)throws DAOException;
public String getCreditAcct(String trnsCrncy)throws DAOException;
public ParameterValue getSARIHolidays(String date)throws DAOException;
public List<Ppm_Inst_Transactions> getTrnsBackendProcDtl()throws DAOException;
public int updateInstTransactions(Ppm_Inst_Transactions ppm_Inst_Transactions,String cammActionCode,String ftsActionCode,String status)throws DAOException;
public boolean updateStatus(List<Ppm_Inst_Transactions> ppm_Inst_Transactions) throws DAOException;
public int updateInstTransactionsStatus(String trnsRef,String status)throws DAOException;
public String getMaxRecordsToPost()throws DAOException;
public List<Ppm_Inst_Transactions> getTransReport(String instReferenc,Date trnsDateFrom,Date trnsDateTo,Double totalAmount,String creditAcc,String debitAcc,String instStatus)throws DAOException;
public int updateInstTransactionsStatusTaskRejected(String trnsRef,String status)throws DAOException;
}
