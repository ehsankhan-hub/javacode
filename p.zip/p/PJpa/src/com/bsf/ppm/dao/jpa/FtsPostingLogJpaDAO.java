package com.bsf.ppm.dao.jpa;

import java.util.List;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.FtsPostingLog;
import com.bsf.ppm.dao.FtsPostingLogDAO;
import com.bsf.ppm.exceptions.DAOException;
/**
 * @author Zakir
 * Java Persistence API implementation for the FtsPostingLogDAO.
 */
@Transactional
public class FtsPostingLogJpaDAO extends PaginatedJpaDAO<FtsPostingLog, Long> implements FtsPostingLogDAO {

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(FtsPostingLog entity) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public FtsPostingLog getByFtsReference(String ftsReference)
			throws DAOException {
		String[] namedParams = { "ftsReference" };
		Object[] params = { ftsReference };
		List<FtsPostingLog> fetchedData = findByNamedQuery(
				"FtsPostingLog.findByFtsReference", namedParams, params);
		if (fetchedData != null && fetchedData.size()>0)
			return fetchedData.get(0);
		return null;
	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public FtsPostingLog save(FtsPostingLog entity) throws DAOException {		
		return super.save(entity);
	}

}
