package com.bsf.ppm.dao;

import java.util.Date;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.LoanBlockDets;
import com.bsf.ppm.LoanInstalmentsDets;
import com.bsf.ppm.exceptions.DAOException;

public interface LoanBlockDetsDAO extends PaginatedDAO<LoanBlockDets, String> {
	
public int updateIncomingSalaries() throws DAOException;	
public LoanBlockDets getDataBasedCurrentAndFutureDate(Date date) throws DAOException;
public int updateLoanInstDets(String reference,String accctNo)throws DAOException;
//By SARaheem
public int updateIncomingSalariesStatus_P() throws DAOException;
}
