package com.bsf.ppm.dao;

import java.util.Date;
import java.util.List;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.Application;
import com.bsf.ppm.IncomingSalaries;
import com.bsf.ppm.exceptions.DAOException;

public interface IncomingSalaryDAO extends PaginatedDAO<IncomingSalaries, String> {
	public List<IncomingSalaries> getAccounts(int dateRange)throws DAOException;
}
