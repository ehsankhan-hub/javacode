package com.bsf.ppm.dao.jpa;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.dao.StatusHistoryDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.InstructionListValues;
import com.bsf.ppm.StatusHistory;

public class StatusHistoryJpaDAO extends PaginatedJpaDAO<StatusHistory, Long> implements StatusHistoryDAO{

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(StatusHistory entity) {
		// TODO Auto-generated method stub
		return false;
	}

	@SuppressWarnings("unchecked")
	public List<StatusHistory>getStatusHistoryRecords(String instRefeId)throws DAOException{
		List<StatusHistory> statusHList=new ArrayList<StatusHistory>();
		StatusHistory statusHist=new StatusHistory();
		//String query="FROM max(sh.createdDate) as CreatedDate StatusHistory sh WHERE sh.instReference="+instRefeId+"" +" GROUP BY " +" instReference";
		//String query="FROM max(createdDate) StatusHistory";
		String query="SELECT INST_REFERENCE,CHANGE_DATE,CHANGED_BY,OLD_STATUS,NEW_STATUS FROM PPM_STATUS_HISTORY WHERE INST_REFERENCE="+"'"+instRefeId+"'"+ " ORDER BY CHANGE_DATE ASC";
		List <Object[]>queryList= entityManager.createNativeQuery(query).getResultList();
		
		
		for(int i=0;i<queryList.size();i++){
			Object obj[] = queryList.get(i);
			String instReference=(String)obj[0];
			if(instReference!=null){
			statusHist.setInstReference(instReference);	
			}
			Date changeDate=(Date)obj[1];
			String changeBy=(String)obj[2];
			String oldStatus=(String)obj[3];
			String newStatus=(String)obj[4];
		
			statusHist.setCreatedDate(changeDate);
			statusHist.setChangedBy(changeBy);
			statusHist.setOldStatus(oldStatus);
			statusHist.setNewStatus(newStatus);
			statusHList.add(statusHist);
			statusHist=new StatusHistory();
		}
		
		return statusHList;
}

public void insertStatusHisttory(InstructionListValues itemItemDtl,String changeBy,String statusfromItst,String btnType)throws DAOException {	
	String queryStaHisAudit="INSERT INTO PPM_STATUS_HISTORY(INST_REFERENCE,CHANGE_DATE,CHANGED_BY,OLD_STATUS,NEW_STATUS) VALUES("+itemItemDtl.getInstReference()+""+","+"sysdate"+","+"'"+changeBy+"'"+","+"'"+statusfromItst+"'"+","+"'"+btnType+"'"+")"; 
    Query query=entityManager.createNativeQuery(queryStaHisAudit);
    query.executeUpdate();
	    
}	

}
