package com.bsf.ppm.dao.jpa;

import javax.persistence.Query;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.AccessHistory;
import com.bsf.ppm.dao.AccessHistoryDAO;
import com.bsf.ppm.exceptions.DAOException;

import org.springframework.transaction.annotation.Transactional;
public class AccessHistoryJpaDAO extends PaginatedJpaDAO<AccessHistory, Long>
implements AccessHistoryDAO
{

	@Override
	public boolean isUnique(AccessHistory entity) throws DAOException {
		
		return false;
	}
	
	private AccessHistory lastLogin(long ID)
	{
		
		AccessHistory lastLogin=new AccessHistory();
		 StringBuffer query = new StringBuffer("Select obj from ")
			.append(getPersistentClass().getSimpleName()).append(
					"  obj  where obj.id =:ID");
		
		Query jpaQuery = entityManager.createQuery(query.toString());
		jpaQuery.setParameter("ID", ID);
		ArrayList<AccessHistory> lastLoginList = (ArrayList<AccessHistory>)jpaQuery.getResultList();
		
		if(lastLoginList.size()>0)
		{
			lastLogin= lastLoginList.get(0);
		}
		
	
		return lastLogin;
	}
	
	
	
	private void logIn(AccessHistory entity) throws DAOException
	{	
		
		super.save(entity);	
	}
	
	private void logOff(AccessHistory entity) throws DAOException
	{
		AccessHistory lastestLogin=new AccessHistory();
		Timestamp currTime = new Timestamp(Calendar.getInstance()
				.getTimeInMillis());
		lastestLogin=lastLogin(entity.getId());
		
		if(lastestLogin.getLogoutDate()==null)
		{
		lastestLogin.setLogoutDate(currTime);
		}		
		if(lastestLogin!=null)
		{
			if(lastestLogin.getUserId()!=null)
			{
			if(!lastestLogin.getUserId().isEmpty())
				super.update(lastestLogin);	
			}
		}
		
	}

	@Override
	@Transactional 
	public void maintHistory(AccessHistory entity, boolean isLogin)
			throws DAOException {
		if(isLogin)
		{
			logIn(entity);	
		}
		else
		{		
			logOff(entity);
		}		
		
	}

}
