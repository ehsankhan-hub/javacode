package com.bsf.ppm.dao;

import com.bsf.ipp.dao.GenericDAO;
import com.bsf.ppm.AuthorizationRequest;

/**
 * @author Zakir
 * Data Access Object for AuthorizationRequest Entity
 */
public interface AuthorizationRequestDAO extends GenericDAO<AuthorizationRequest, Long> {

}
