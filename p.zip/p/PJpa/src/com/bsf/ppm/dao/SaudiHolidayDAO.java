package com.bsf.ppm.dao;

import java.util.Date;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.SaudiHoliday;
import com.bsf.ppm.exceptions.DAOException;

public interface SaudiHolidayDAO extends PaginatedDAO<SaudiHoliday, Long>{

	boolean isValueDateHoliday(Date valueDate) throws DAOException;

}
