package com.bsf.ppm.dao.jpa;

import javax.persistence.Query;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.MailTemplate;
import com.bsf.ppm.dao.MailTemplateDAO;
import com.bsf.ppm.exceptions.DAOException;

/**
 * <p>
 * DAO class for email message related operations. Java Persistence API
 * implementation for the MailTemplateDAO.
 * </p>
 * 
 * @author Abdulhamid Dhaiban
 * 
 */
@Transactional
public class MailTemplateJpaDAO extends PaginatedJpaDAO<MailTemplate, Long>
		implements MailTemplateDAO {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(MailTemplate entity) throws DAOException {
		long recordCount;
		try {
			StringBuffer query = new StringBuffer(
					"Select count(obj) AS RECCOUNT from ").append(
					getPersistentClass().getSimpleName()).append(
					"  obj  where obj.id !=:id  and  "
							+ "  obj.subject=:subject and obj.message=:message");
			Query jpaQuery = entityManager.createQuery(query.toString());
			if (entity.getId() != null)
				jpaQuery.setParameter("id", entity.getId());
			else
				jpaQuery.setParameter("id", Long.valueOf(-1));
			jpaQuery.setParameter("subject", entity.getSubject());
			jpaQuery.setParameter("message", entity.getMessage());
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex,
					getPersistentClass().getName());
		}

		return recordCount <= 0;

	}
}
