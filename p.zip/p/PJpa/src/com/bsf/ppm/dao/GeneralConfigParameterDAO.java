package com.bsf.ppm.dao;

import com.bsf.ipp.GeneralConfigParameter;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.exceptions.DAOException;

public interface GeneralConfigParameterDAO extends PaginatedDAO<GeneralConfigParameter, Long> {
	
	
	public String getByGeneralConfigParameterName(String paramName) throws DAOException;

}
