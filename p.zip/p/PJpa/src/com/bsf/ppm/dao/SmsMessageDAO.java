package com.bsf.ppm.dao;

import java.util.List;

import com.bsf.ipp.dao.GenericDAO;
import com.bsf.ppm.SmsMessage;
import com.bsf.ppm.exceptions.DAOException;

/**
 * @author Zakir
 * Data Access Object Interface for SmsMessage Entity. Extends PaginatedDAO
 */
public interface SmsMessageDAO extends GenericDAO<SmsMessage, Long> {

	/**
	 * Search for Sms messages satisfying the sms status criteria
	 * @param smsStatus
	 * @return List of Sms Messages satisfying sms status
	 * @throws DAOException
	 */
	public List<SmsMessage> findBySmsStatus(Long smsStatus) throws DAOException;
}
