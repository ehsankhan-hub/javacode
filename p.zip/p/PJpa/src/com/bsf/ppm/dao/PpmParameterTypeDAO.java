package com.bsf.ppm.dao;

import java.util.List;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.PpmExeRules;
import com.bsf.ppm.PpmExeRulesCriteria;
import com.bsf.ppm.PpmParameterType;
import com.bsf.ppm.PpmParameterValue;
import com.bsf.ppm.exceptions.DAOException;

public interface PpmParameterTypeDAO extends PaginatedDAO<PpmParameterType, String> {
	
	public boolean isUnique(List<PpmParameterValue> ruleDtlList) throws DAOException;
	public boolean isUniqueFromListObject(List<PpmParameterValue> benList) throws DAOException ;
	public boolean isUniqueJoinTable(List<PpmParameterValue> benList) throws DAOException;
	public void updateEntityStatusByIds(String[] ids,String idField, 
			UserInfo modifiedBy) throws DAOException;
	
	public void deletRule(String exeRuleName)throws DAOException;
	public List<PpmParameterValue>getParamValueList(String parmtypecode)throws DAOException;
	public List<PpmParameterValue>deleteParamValueList(String typeCode,String groupCode,String value1)throws DAOException;
	public PpmParameterType getPpmParamTypeList(String parmtypecode)throws DAOException;

}
