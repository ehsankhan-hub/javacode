package com.bsf.ppm.dao;

import java.util.List;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.A_Account;
import com.bsf.ppm.A_Block_Deblock;
import com.bsf.ppm.C_Block_Deblock;
import com.bsf.ppm.PpmDebitBlockStaging;
import com.bsf.ppm.PpmDebitExempt;
import com.bsf.ppm.exceptions.DAOException;



public interface PpmDebitExemptDAO extends PaginatedDAO<PpmDebitExempt, String>{
/*public List<A_Block_Deblock>   getBlockAccountsDtlsCamm()
			throws DAOException;
public A_Block_Deblock getByAcctNo(String acctNo)
		throws DAOException;*/
	public PpmDebitExempt getCustomerCode(String customerCode)throws DAOException;
	
	public List<PpmDebitExempt>   getBlockAccountsDtlsCamm()
			throws DAOException;
public String  getByAcctNo(String acctNo)
		throws DAOException;
	
	

}
