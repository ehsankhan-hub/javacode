package com.bsf.ppm.dao;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.BackendErrorCodes;
import com.bsf.ppm.exceptions.DAOException;

/**
 * @author Zakir
 * Data Access Object for BackendErrorCodes Entity. Extends PaginatedDAO
 */
public interface BackendErrorCodeDAO extends PaginatedDAO<BackendErrorCodes, Long> {

	/**
	 * Fetch BackendErrorCdoes Entity with the Action Code
	 * @param code fts action code
	 * @return BackendErrorCode identified by fts action code passed
	 * @throws DAOException
	 */
	public BackendErrorCodes getBackendErrorByActionCode(String code) throws DAOException;
}
