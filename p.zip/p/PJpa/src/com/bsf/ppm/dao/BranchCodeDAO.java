package com.bsf.ppm.dao;

import java.util.List;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.BranchCode;
import com.bsf.ppm.exceptions.BusinessException;
import com.bsf.ppm.exceptions.DAOException;

/**
 * @author Zakir
 * Data Access Object for BranchCode Entity. Extends PaginatedDAO
 */
public interface BranchCodeDAO extends PaginatedDAO<BranchCode, String> {
	public BranchCode getBranchByCode(String branchCode)  throws DAOException, BusinessException;
	public List<BranchCode> findBranchByClgCenter(String clgCenter)  throws DAOException, BusinessException;
	
}