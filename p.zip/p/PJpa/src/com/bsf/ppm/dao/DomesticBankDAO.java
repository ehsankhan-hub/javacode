package com.bsf.ppm.dao;

import java.util.List;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.DomesticBank;
import com.bsf.ppm.exceptions.DAOException;

/**
 * @author Jakeer Hussain
 * Data Access Object for  DomesticBank Entity. Extends PaginatedDAO
 */
public interface DomesticBankDAO extends PaginatedDAO<DomesticBank, Long> {

	/**
	 * Fetch Domestic Bank by ibanClearingCode
	 * @param ibanClearingCode
	 * @return DomesticBank matching the ibanClearingCode
	 * @throws DAOException
	 */
	public DomesticBank fetchByIbanClearingCode(String ibanClearingCode)
			throws DAOException;

	/**
	 * Fetch Domestic Bank by ibanClearingCode
	 * @param bankCode
	 * @return DomesticBank matching the bankCode
	 * @throws DAOException
	 */
	public DomesticBank fetchByBankCode(String bankCode) throws DAOException;
	
	/**
	 * Fetch Domestic Bank by Bank Bic
	 * @param bankBic
	 * @return DomesticBank matching the bankBic
	 * @throws DAOException
	 */
	public DomesticBank fetchByBankBic(String bankBic) throws DAOException;

	/** 
	 * Fetch All Active Domestic Banks 
	 * @return list of Active DomesticBank's
	 * @throws DAOException
	 */
	public List<DomesticBank> fetchAll() throws DAOException;

	/**
	 * Update Bulk Sequence for the Bank code
	 * @param bankCode
	 * @throws DAOException
	 */
	public void updateSequenceByBankCode(String bankCode, Long sequence) throws DAOException;

}
