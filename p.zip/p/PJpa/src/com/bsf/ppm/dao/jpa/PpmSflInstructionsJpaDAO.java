package com.bsf.ppm.dao.jpa;

import javax.persistence.Query;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.BatchJob;
import com.bsf.ppm.PpmSflInstructions;
import com.bsf.ppm.dao.BatchJobDAO;
import com.bsf.ppm.dao.PpmSflInstructionsDAO;
import com.bsf.ppm.exceptions.DAOException;

/**
 * @author Zakir
 * Java Persistence API implementation for the BatchJobDAO.
 */
public class PpmSflInstructionsJpaDAO extends PaginatedJpaDAO<PpmSflInstructions, Long> implements PpmSflInstructionsDAO {

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(PpmSflInstructions entity) throws DAOException {
	return true;
	}

}
