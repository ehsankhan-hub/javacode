package com.bsf.ppm.dao.jpa;

import javax.persistence.Query;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.BusinessObject;
import com.bsf.ppm.dao.BusinessObjectDAO;
import com.bsf.ppm.exceptions.DAOException;


@Transactional
public class BusinessObjectJpaDAO extends PaginatedJpaDAO<BusinessObject, Long> implements BusinessObjectDAO {

	@Override
	public boolean isUnique(BusinessObject entity) throws DAOException {
		long recordCount = -1;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
					.append(getPersistentClass().getSimpleName()).append(
							"  obj  where obj.id !=:id  and  obj.objectname=:objectname ");
			Query jpaQuery = entityManager.createQuery(query.toString());
			if(entity.getId() !=null)
			  jpaQuery.setParameter("id", entity.getId());
			else
				jpaQuery.setParameter("id",Long.valueOf(-1));	
				jpaQuery.setParameter("name", entity.getObjectname());
				recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}
		return recordCount <= 0;
	}

	
}
