package com.bsf.ppm.dao;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.FtsPostingLog;
import com.bsf.ppm.exceptions.DAOException;

/**
 * @author Zakir
 * Data Access Object for FtsPostingLog Entity
 * Provides search and find methods for searchCriteria ,sorting, pageNumbers
 */
public interface FtsPostingLogDAO extends PaginatedDAO<FtsPostingLog, Long> {
	public FtsPostingLog getByFtsReference(String ftsReference) throws DAOException;

	public FtsPostingLog save(FtsPostingLog entity) throws DAOException;
}
