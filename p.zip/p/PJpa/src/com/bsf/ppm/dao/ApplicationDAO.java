package com.bsf.ppm.dao;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.Application;
import com.bsf.ppm.exceptions.DAOException;

/**
 * @author Zakir
 * Data Access Object for Application Entity
 * Provides search and find methods for searchCriteria ,sorting, pageNumbers
 */
public interface ApplicationDAO extends PaginatedDAO<Application, String> {
	
	public void updateStatus(String applicationName, Long status) throws DAOException;
	public Application getByApplicationName(String applicationName) throws DAOException;
}
