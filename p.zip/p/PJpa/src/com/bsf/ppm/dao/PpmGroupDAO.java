package com.bsf.ppm.dao;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.PpmGroup;
import com.bsf.ppm.exceptions.DAOException;

public interface PpmGroupDAO extends PaginatedDAO<PpmGroup, String> {
	
	public void updateEntityStatusByIds(String[] ids,String idField, 
			String statusField,String status, UserInfo modifiedBy) throws DAOException;

}
