package com.bsf.ppm.dao;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.MailTemplate;

/**
 * Interface for data access operations related to mail Template
 * @author Zakir
 */
public interface MailTemplateDAO extends PaginatedDAO<MailTemplate, Long>  {

}
