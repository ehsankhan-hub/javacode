package com.bsf.ppm.dao.jpa;

import javax.persistence.Query;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.dao.UserDAO;
import com.bsf.ppm.exceptions.DAOException;

public class UserJpaDAO extends PaginatedJpaDAO<UserInfo, String> implements UserDAO {

	@Override
	public boolean isUnique(UserInfo entity) throws DAOException {
		long recordCount = -1;
		try {
			
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
					.append(getPersistentClass().getSimpleName()).append(
							"  obj  where obj.id !=:id");
			Query jpaQuery = entityManager.createQuery(query.toString());
			if(entity.getUserId() !=null)
			  jpaQuery.setParameter("id", entity.getUserId());
			else
				 jpaQuery.setParameter("id","-1");	
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
			
			update(entity);	
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}

		return recordCount <= 0;
	}
	
	

}
