/**
 * 
 */
package com.bsf.ppm.dao;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.GErrorList;


/**
 * @author bsaleem
 * 
 * This interface is a plain  DAO for retrieving Groups related data.
 *
 */
public interface GErrorListDAO extends PaginatedDAO<GErrorList, Long> {
	
//	public String getTuxedoErrorCodes(GErrorCodes entity) throws DAOException;

}
