package com.bsf.ppm.dao.jpa;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.A_Account;
import com.bsf.ppm.A_Block_Deblock;
import com.bsf.ppm.C_Block_Deblock;
import com.bsf.ppm.IncomingSalaries;
import com.bsf.ppm.PpmDebitBlockStaging;
import com.bsf.ppm.dao.PpmAccountInquiryDAO;
import com.bsf.ppm.dao.PpmDebitBlockStagingDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.util.JNDIUtil;


@Transactional
public  class PpmAccountInquiryJpaDAO extends PaginatedJpaDAO<C_Block_Deblock, String> implements PpmAccountInquiryDAO {
	
	@Override
	public List<C_Block_Deblock> getBlockAccountsDtlsCamm()
			throws DAOException {
		List<C_Block_Deblock> list=new ArrayList<C_Block_Deblock>();  
		Connection con=null;
		Statement stmt = null;
		ResultSet rs=null;
		C_Block_Deblock cBlockDeblock=null;
		String query="select CUST_CODE from C_Block_Deblock where ((BLK_TYPE='DB' and BLK_RSN_CODE='20') OR (BLK_TYPE='FB' AND BLK_RSN_CODE='43')) AND DEBLK_DATE is null   group by CUST_CODE";
		try{
       // list=entityManager.createQuery("select custCode from C_Block_Deblock where ((acctStatusCamm='DB' and statuRsnCodeCamm='20') OR (acctStatusCamm='FB' AND statuRsnCodeCamm='43')) AND deblkDate is null group by custCode").getResultList(); 
			//log.info("Trying to get the database connection...");	
			con=JNDIUtil.getConnection();
			
			//log.info("Successfully get the database connection..."+con);
			stmt=con.createStatement();
			rs=stmt.executeQuery(query);
			 while (rs.next()) {
				
		     String custCode = rs.getString("CUST_CODE");
		     
		     cBlockDeblock=new C_Block_Deblock();
		     cBlockDeblock.setCustCode(custCode);
		     list.add(cBlockDeblock);
		   	 }
		}
		catch (Exception e) {
			//log.error("Exception occured--"+e.getMessage());
			e.printStackTrace();
		}finally {
		    if (rs != null) {
		    	//log.info("Trying to close ResultSet connection");
		        try {
		            rs.close();
		       //  log.info("Successfully closed ResultSet connection");   
		        } catch (SQLException e) {
		       //  log.error("Exception occured--"+e.getMessage());	
                  e.printStackTrace();
		        }
		    }
		    if (stmt != null) {
		    	//log.info("Trying to close Statement connection");
		        try {
		        	stmt.close();
		      //  log.info("Successfully closed Statement connection");	
		        } catch (SQLException e) { 
		       // log.error("Exception occured--"+e.getMessage());	
                e.printStackTrace();
		        }
		    }
		    if (con != null) {
		    	//log.info("Trying to close Connection");
		        try {
		            con.close();
		           // log.info("Successfully closed Connection");
		        } catch (SQLException e) {
		        	//log.error("Exception occured--"+e.getMessage());
		        	e.printStackTrace();
		        }
		    }
		}
		return list;
		
	}
	
	
	/*@Override
	public List<C_Block_Deblock> getBlockAccountsDtlsCamm()
			throws DAOException {
		List<C_Block_Deblock> list=new ArrayList<C_Block_Deblock>();  
		C_Block_Deblock cblockDblock=new C_Block_Deblock();
				
		try{
        list=entityManager.createQuery("select custCode from C_Block_Deblock where ((acctStatusCamm='DB' and statuRsnCodeCamm='20') OR (acctStatusCamm='FB' AND statuRsnCodeCamm='43')) AND deblkDate is null group by custCode").getResultList(); 
		
        
        
		}
		catch (Exception e) {
			//log.error("Exception occured--"+e.getMessage());
			e.printStackTrace();
		}
		
		return list;
		
	}*/
	
	
	
	
	
	/*@Override
	public List<A_Block_Deblock> getBlockAccountsDtlsCamm()
			throws DAOException {
          String query= "SELECT accNumber,acctStatusCamm, MAX(seqNo),custCode,statuRsnCodeCamm FROM A_Block_Deblock WHERE (acctStatusCamm='DB' and statuRsnCodeCamm='20')" +
                "OR (acctStatusCamm='FB' AND statuRsnCodeCamm='43') AND deblkDate is null  "+ 
                "group by accNumber, acctStatusCamm,custCode,statuRsnCodeCamm";
        
       // List<A_Block_Deblock> list=entityManager.createQuery("from A_Account where ((acctStatusCamm='DB' OR acctStatusCamm='FB') AND (statuRsnCodeCamm='27' OR statuRsnCodeCamm='40')) ").getResultList(); 
       
        List<Object[]>list=null;
        A_Block_Deblock a_Block_Deblocks=new A_Block_Deblock();
		List<A_Block_Deblock> a_Block_DeblocksList=new ArrayList<A_Block_Deblock>();
		try{
		list=(List<Object[]>)entityManager.createQuery(query).getResultList();
		
		for (int i = 0; i < list.size(); i++) {
		   	Object[] obj  = list.get(i);
		   	String accountNo=(String)obj[0];
		   	String acctStatusCamm=(String)obj[1];
		   	String seqNoMax=(String)obj[2];
		   	String custCode=(String)obj[3];
		   	String statuRsnCodeCamm=(String)obj[4];
		   	
		   	a_Block_Deblocks.setAccNumber(accountNo);
		   	a_Block_Deblocks.setAcctStatusCamm(acctStatusCamm);
		   	a_Block_Deblocks.setCustCode(custCode);
		   	a_Block_Deblocks.setStatuRsnCodeCamm(statuRsnCodeCamm);
		   	a_Block_Deblocks.setSeqNo(seqNoMax);
		   	a_Block_DeblocksList.add(a_Block_Deblocks);
		   	a_Block_Deblocks=new A_Block_Deblock();  	  
		}  	  
		}
		catch(Exception de){
			de.printStackTrace();
		}
		
		if(list != null && list.size()>0)
		{
			
		return a_Block_DeblocksList;
		}
		else
			return null;
	
	}*/
	
	
	
	/*@Override
	public String getByAcctNo(String cpt)
			throws DAOException {
        
        String list=null; 
        try{
        
        list=(String)entityManager.createQuery("select custCode from C_Block_Deblock where ((acctStatusCamm='DB' and statuRsnCodeCamm='20') OR (acctStatusCamm='FB' AND statuRsnCodeCamm='43')) AND custCode="+"'"+cpt+"'" +"AND deblkDate is null group by custCode").getSingleResult();
       		
        }
		catch(Exception de){
			de.printStackTrace();
		}
		
		if(list != null)
		{
			
		return list;
		}
		else
		{
		return null;
		}	
		
		
	
	}*/
	
	
	@Override
	public String getByAcctNo(String cpt)
			throws DAOException {
            
    		List<C_Block_Deblock> list=new ArrayList<C_Block_Deblock>();  
    		JNDIUtil jndiUtil=new JNDIUtil();
    		String custCode="";
    		Connection con=null;
    		Statement stmt = null;
    		ResultSet rs=null;
    		C_Block_Deblock cBlockDeblock=null;
    		String query="select CUST_CODE from C_Block_Deblock where ((BLK_TYPE='DB' and BLK_RSN_CODE='20') OR (BLK_TYPE='FB' AND BLK_RSN_CODE='43')) AND CUST_CODE="+"'"+cpt+"'" +" AND DEBLK_DATE is null  group by CUST_CODE";
    		try{
           // list=entityManager.createQuery("select custCode from C_Block_Deblock where ((acctStatusCamm='DB' and statuRsnCodeCamm='20') OR (acctStatusCamm='FB' AND statuRsnCodeCamm='43')) AND deblkDate is null group by custCode").getResultList(); 
    			//log.info("Trying to get the database connection...");	
    			con=JNDIUtil.getConnection();
    			
    			//log.info("Successfully get the database connection..."+con);
    			stmt=con.createStatement();
    			rs=stmt.executeQuery(query);
    			 while (rs.next()) {
    				
    		     custCode = rs.getString("CUST_CODE");
    		    
    		     cBlockDeblock=new C_Block_Deblock();
    		     cBlockDeblock.setCustCode(custCode);
    		     list.add(cBlockDeblock);
    		   	 }
    		}
    		catch (Exception e) {
    			//log.error("Exception occured--"+e.getMessage());
    			e.printStackTrace();
    		}finally {
    		    if (rs != null) {
    		    	//log.info("Trying to close ResultSet connection");
    		        try {
    		            rs.close();
    		       //  log.info("Successfully closed ResultSet connection");   
    		        } catch (SQLException e) {
    		       //  log.error("Exception occured--"+e.getMessage());	
                      e.printStackTrace();
    		        }
    		    }
    		    if (stmt != null) {
    		    	//log.info("Trying to close Statement connection");
    		        try {
    		        	stmt.close();
    		      //  log.info("Successfully closed Statement connection");	
    		        } catch (SQLException e) { 
    		       // log.error("Exception occured--"+e.getMessage());	
                    e.printStackTrace();
    		        }
    		    }
    		    if (con != null) {
    		    	//log.info("Trying to close Connection");
    		        try {
    		            con.close();
    		           // log.info("Successfully closed Connection");
    		        } catch (SQLException e) {
    		        	//log.error("Exception occured--"+e.getMessage());
    		        	e.printStackTrace();
    		        }
    		    }
    		}
    		return custCode;
		
		
	
	}
	
	
	
	/*@Override
	public A_Block_Deblock getByAcctNo(String acctNo)
			throws DAOException {
        System.out.println("getBlockAccountsDtlsCamm");
        String query= "SELECT accNumber,acctStatusCamm, MAX(seqNo),custCode,statuRsnCodeCamm FROM A_Block_Deblock WHERE (acctStatusCamm='DB' and statuRsnCodeCamm='20')" +
                "OR (acctStatusCamm='FB' AND statuRsnCodeCamm='43') and accNumber="+"'"+acctNo+"'" +
                " group by accNumber, acctStatusCamm,custCode,statuRsnCodeCamm";
        
       // List<A_Block_Deblock> list=entityManager.createQuery("from A_Account where ((acctStatusCamm='DB' OR acctStatusCamm='FB') AND (statuRsnCodeCamm='27' OR statuRsnCodeCamm='40')) ").getResultList(); 
       
        List<Object[]>list=null;
        A_Block_Deblock a_Block_Deblocks=new A_Block_Deblock();
		
		try{
		list =(List<Object[]>)entityManager.createQuery(query).getResultList();
		if(list!=null)
		for (int i = 0; i < list.size(); i++) {
		   	Object[] obj  = list.get(i);
		    String accountNo=(String)obj[0];
		   	String acctStatusCamm=(String)obj[1];
		   	String seqNoMax=(String)obj[2];
		   	String custCode=(String)obj[3];
		   	String statuRsnCodeCamm=(String)obj[4];
		   	
		   	a_Block_Deblocks.setAccNumber(accountNo);
		   	a_Block_Deblocks.setAcctStatusCamm(acctStatusCamm);
		   	a_Block_Deblocks.setCustCode(custCode);
		   	a_Block_Deblocks.setStatuRsnCodeCamm(statuRsnCodeCamm);
		   	a_Block_Deblocks.setSeqNo(seqNoMax);
		   	
		   		  
		}
		
		}
		catch(Exception de){
			de.printStackTrace();
		}
		
		if(list != null && list.size()>0)
		{
			
		return a_Block_Deblocks;
		}
		else
		return null;
			
		
		
	
	}*/

	

@Override
public boolean isUnique(C_Block_Deblock entity) throws DAOException {
	// TODO Auto-generated method stub
	return false;
}

}