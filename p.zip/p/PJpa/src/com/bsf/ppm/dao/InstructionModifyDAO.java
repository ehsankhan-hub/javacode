package com.bsf.ppm.dao;

import java.util.List;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.InstructionDetails;
import com.bsf.ppm.InstructionListValues;
import com.bsf.ppm.InstructionsModify;

public interface InstructionModifyDAO extends PaginatedDAO<InstructionsModify, String> {
public Long getInstModifyIdSeqGen() throws DAOException;
public int saveInstModify(InstructionsModify instMod)throws DAOException ;
public int rejectInstModify(InstructionListValues instModify)throws DAOException ;
public InstructionsModify updateInstModify(InstructionListValues itemItemDtl,String btnTyp)throws DAOException ;

public List<InstructionListValues> getModifyValidateResults(String instReferenc,String samaReference)throws DAOException;
}
