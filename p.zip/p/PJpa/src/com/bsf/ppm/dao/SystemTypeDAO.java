package com.bsf.ppm.dao;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.SystemType;

/**
 * @author Zakir
 * Data Access Object Interface for SystemType Entity. Extends PaginatedDAO
 */
public interface SystemTypeDAO extends PaginatedDAO<SystemType, Long> {

}
