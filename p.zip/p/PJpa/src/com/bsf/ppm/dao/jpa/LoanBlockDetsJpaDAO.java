package com.bsf.ppm.dao.jpa;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.Query;
import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.LoanBlockDets;
import com.bsf.ppm.LoanInstalmentsDets;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.LoanBlockDetsDAO;
import com.bsf.ppm.exceptions.DAOException;

public class LoanBlockDetsJpaDAO  extends PaginatedJpaDAO<LoanBlockDets, String> implements LoanBlockDetsDAO  {

	@Override
	public boolean isUnique(LoanBlockDets entity) throws DAOException {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public int updateIncomingSalaries() throws DAOException{
	String incomingSalaries="update incoming_salaries set process_flag='Y' where sequence_no in (select ppm_incmng_seq from ppm_inst_transactions where ppm_process_status='P' and ppm_status_date>=sysdate-1)";
	Query query=entityManager.createNativeQuery(incomingSalaries);
	return query.executeUpdate();
	}
	
	
	
	
	//By SARaheem
	@Override
	public int updateIncomingSalariesStatus_P() throws DAOException{
	String incomingSalaries="update incoming_salaries set process_flag='P' where log_system_date>=sysdate-1 and process_flag='N'";
	Query query=entityManager.createNativeQuery(incomingSalaries);
	return query.executeUpdate();
	}
	
	
	@Override
	public LoanBlockDets getDataBasedCurrentAndFutureDate(Date date)throws DAOException {
		SimpleDateFormat sdLdate=new SimpleDateFormat("MM/dd/yyyy");
	    String toDate=sdLdate.format(date);
		StringBuffer selectQ=new StringBuffer("FROM LoanBlockDets loanBlk WHERE loanBlk.createdDate "); 
		selectQ.append("to_Date(");
		selectQ.append("'"+toDate+"',"); 
		selectQ.append("'mm/dd/yyyy')");
		Query query=entityManager.createQuery(selectQ.toString());
		//query.setParameter("trnsRef",trnsRef);
		LoanBlockDets loanBlockDets=(LoanBlockDets)query.getSingleResult();
		return loanBlockDets;	

	}
	/*public LoanInstalmentsDets getLoanInstDets(String refrence)throws DAOException {
	String query=" FROM LoanInstalmentsDets ";
	entityManager.createQuery(query).
	}*/
	
	@Override
	public int updateLoanInstDets(String reference,String accctNo)throws DAOException {
	String update="update loan_instalments_dets set blocked_flag='N' ,updt_date=sysdate,updt_user=" +"'"+JSFUtil.getLoggedInUserInfo().getUserId()+"',"+"Description='Deblocked' where reference="+"'"+reference+"'" +"AND acct_no="+"'"+accctNo+"'";
	Query query=entityManager.createNativeQuery(update);
	return query.executeUpdate();
	}
	
	

}
