package com.bsf.ppm.dao.jpa;

import java.sql.Timestamp;
import java.util.Calendar;
import javax.persistence.Query;
import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.AccountClass;
import com.bsf.ppm.PpmGroup;
import com.bsf.ppm.dao.PpmEmpCategoryMgmtDAO;
import com.bsf.ppm.dao.PpmGroupDAO;
import com.bsf.ppm.exceptions.DAOException;

public class PpmEmpCategoryMgmtJpaDAO extends PaginatedJpaDAO<AccountClass, String> implements 	PpmEmpCategoryMgmtDAO {

	@Override
	public boolean isUnique(AccountClass entity) throws DAOException {
		long recordCount = -1;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
					.append(getPersistentClass().getSimpleName()).append(
							"  obj  where obj.accountNo=:accountNo ");
			Query jpaQuery = entityManager.createQuery(query.toString());
			jpaQuery.setParameter("accountNo", entity.getAccountNo());
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}

		return recordCount <= 0;
	}

	@Override
	public void updateEntityStatusByIds(String[] ids, String idField,
			String statusField, String status, UserInfo updatedBy)
			throws DAOException {
		     System.out.println("String[] ids="+ids.length);
		try {

			// Build the Disable Query
			StringBuilder disableQuery = new StringBuilder("update ").append(
					getPersistentClass().getSimpleName()).append(
					" as type set type.").append(statusField).append(
					"=:status, type.updatedBy=:updatedBy").append(
					", type.updateDate=:updateDate")
					.append("  where type.").append(idField)
					.append("=:typeId ");

			// Build Query Object
			Query query = entityManager.createQuery(disableQuery.toString());
            System.out.println("statusField=="+statusField);
            System.out.println("status=="+status);
            System.out.println("idField=="+idField);
			// Execute Query for each Id in the ids array
			for (int i = 0; i < ids.length; i++) {
				
				query.setParameter("status", status);
				query.setParameter("updatedBy", updatedBy);
				query.setParameter("updateDate", new Timestamp(Calendar
				.getInstance().getTimeInMillis()));
				query.setParameter("typeId",(ids[i]));
				System.out.println("(ids[i]) updateEntityStatusByIds="+ids[i]);
				int updated=query.executeUpdate();
				System.out.println("Record Updated Successfully=="+updated);
			}
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.disable.entities", ex,
					getPersistentClass().getName());
		}

	}
	
}
