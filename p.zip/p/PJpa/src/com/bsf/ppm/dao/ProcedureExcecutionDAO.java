package com.bsf.ppm.dao;

import java.io.Serializable;
import java.sql.Timestamp;

import com.bsf.ppm.exceptions.DAOException;

/**
 * @author Zakir
 * Data Access Object for Procedure Calls
 */
public interface ProcedureExcecutionDAO extends Serializable {

	/**
	 * Execute the statistics procedures with procedure name
	 * (bankPymtStatistics,pymtAmtStatistics,paymentStatistics) with date parameter
	 * @param procedureName name of the Stored Procedure
	 * @return
	 * @throws DAOException
	 */
	public boolean callStatisticsProcedure(String procedureName, Timestamp queryDate,String appId) throws DAOException;
	
}
