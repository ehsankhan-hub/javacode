package com.bsf.ppm.dao.jpa;

import java.util.ArrayList;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.DomesticBank;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.ParameterValueDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.AccountClass;
import com.bsf.ppm.InstructionDetails;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.PpmParameterValuesSetup;


@Transactional
public class ParameterValueJpaDAO extends
		PaginatedJpaDAO<ParameterValue, String> implements ParameterValueDAO {

	public String getFilePath() throws DAOException {
		String query = "SELECT trim(value2) FROM PPM_parameter_value WHERE param_type_code = 'LOADFILE' AND GROUP_CODE='SPP' AND VALUE1 = 'FILEPATH'";
		Object quer = entityManager.createNativeQuery(query).getSingleResult();
		String fileLocation = (String) quer;
		System.out.println("fileLocation==" + fileLocation);
		return fileLocation;
	}

	public List<InstructionDetails> getSamaDocFilePath(String instReference)
			throws DAOException {
		String query = "FROM InstructionDetails WHERE instReference="+ "'"+instReference+"'";
		List<InstructionDetails> instDquery = (List<InstructionDetails>) entityManager.createQuery(query).getResultList();
		return instDquery;
	}
    
	@SuppressWarnings("unchecked")
	@Override
	public List<ParameterValue> getFrequencyList() throws DAOException {
		String sql = "FROM com.bsf.ppm.ParameterValue PV WHERE PV.parmtypecode='FREQTYPE' and PV.groupCode='SPP'";
		try {
			List<ParameterValue> results = (List<ParameterValue>) entityManager
					.createQuery(sql).getResultList();

			return results;
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.executeQuery", ex);

		}
	}
	//SFL General Narrative 
	@SuppressWarnings("unchecked")
	@Override
	public ParameterValue getSFLGenralNarrative()
			throws DAOException {
		String sql = "FROM ParameterValue PV WHERE PV.parmtypecode=" + "'SFLGENNARTIVE'" + " AND PV.groupCode='SPP'";
		try {
		ParameterValue results = (ParameterValue) entityManager.createQuery(sql).getSingleResult();
		return results;
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			return null;
			//throw new DAOException("error.executeQuery", ex);
		}
	}
	
	
    
	@SuppressWarnings("unchecked")
	@Override
	public List<ParameterValue> getAccountType(String acctType)
			throws DAOException {
		String sql = "FROM ParameterValue PV WHERE PV.parmtypecode=" + "'"
				+ acctType + "'" + " AND PV.groupCode='SPP'";
		try {
			List<ParameterValue> results = (List<ParameterValue>) entityManager
					.createQuery(sql).getResultList();

			return results;
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.executeQuery", ex);

		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ParameterValue> getMaxDayRangAndTrgrNextCyclDay(String dayRange)
			throws DAOException {
		String sql = "FROM ParameterValue PV WHERE PV.parmtypecode=" + "'"
				+ dayRange + "'" + " AND PV.groupCode='SPP' AND rownum = 1";
		try {
			List<ParameterValue> results = (List<ParameterValue>) entityManager
					.createQuery(sql).getResultList();
			return results;
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.executeQuery", ex);

		}
	}

	// BlockUnbloc if success select query to check update flag Y or N

	@SuppressWarnings("unchecked")
	@Override
	public List<ParameterValue> getBlockUnblockFlag() throws DAOException {
		String sql = "FROM ParameterValue PV WHERE PV.parmtypecode='IS_DBLCKUPD' AND PV.groupCode='SPP'	AND rownum = 1";
		try {
			List<ParameterValue> results = (List<ParameterValue>) entityManager
					.createQuery(sql).getResultList();
			return results;
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.executeQuery", ex);

		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DomesticBank> getDomesticBankList() throws DAOException {
		String sql = "FROM com.bsf.ppm.DomesticBank";
		System.out.println("Select query:" + sql);
		try {
			System.out.println("entityManager=========" + entityManager);
			List<DomesticBank> results = (List<DomesticBank>) entityManager
					.createQuery(sql).getResultList();
			System.out.println("results===1" + results);

			return results;
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.executeQuery", ex);

		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ParameterValue> getPriorityList() throws DAOException {
		List<Object> list = null;
		List<ParameterValue> listInstValu = new ArrayList<ParameterValue>();
		String sql = "select value1 from ppm_parameter_value where param_type_code='EXEPRTY' and group_code='ALL'";
		try {
			list = (List<Object>) entityManager.createNativeQuery(sql)
					.getResultList();

			ParameterValue instVal = new ParameterValue();

			for (int i = 0; i < list.size(); i++) {
				Object obj = list.get(i);
				String value1 = (String) obj;
				// String value2=(String)obj;
				instVal.setValue1(value1);
				listInstValu.add(instVal);
				instVal = new ParameterValue();
			}
		}

		catch (Exception ex) {
			ex.printStackTrace();
		}

		return listInstValu;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ParameterValue> getFieldNameList() throws DAOException {
		List<Object> list = null;
		List<ParameterValue> listInstValu = new ArrayList<ParameterValue>();
		String sql = "select value1 from ppm_parameter_value where param_type_code='ACTNFLD' and group_code='ALL'";
		try {

			list = (List<Object>) entityManager.createNativeQuery(sql)
					.getResultList();
			ParameterValue instVal = new ParameterValue();

			for (int i = 0; i < list.size(); i++) {
				Object obj = list.get(i);
				String value1 = (String) obj;
				instVal.setValue1(value1);
				listInstValu.add(instVal);
				instVal = new ParameterValue();
			}
		}

		catch (Exception ex) {
			ex.printStackTrace();
		}

		return listInstValu;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ParameterValue> getValueList(String parma) throws DAOException {
		List<Object> list = null;
		List<ParameterValue> listInstValu = new ArrayList<ParameterValue>();
		String sql = "select value1 from ppm_parameter_value 	where param_type_code="
				+ "'" + parma + "'" + "and group_code='ALL'";
		System.out.println("parma:" + parma);
		System.out.println("Select query:" + sql);
		try {
			System.out.println("entityManager=========" + entityManager);
			list = (List<Object>) entityManager.createNativeQuery(sql)
					.getResultList();
			ParameterValue instVal = new ParameterValue();

			for (int i = 0; i < list.size(); i++) {
				Object obj = list.get(i);
				String value1 = (String) obj;
				// String value2=(String)obj;
				instVal.setValue1(value1);
				listInstValu.add(instVal);
				instVal = new ParameterValue();
			}
		}

		catch (Exception ex) {
			ex.printStackTrace();
		}

		return listInstValu;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ParameterValue> getStatus() throws DAOException {
		List<Object> list = null;
		List<ParameterValue> listInstValu = new ArrayList<ParameterValue>();
		String sql = "SELECT VALUE1 FROM ppm_Parameter_Value WHERE PARAM_TYPE_CODE='GSTATUS' AND GROUP_CODE='ALL'";
		try {
			list = (List<Object>) entityManager.createNativeQuery(sql)
					.getResultList();
			ParameterValue instVal = new ParameterValue();

			for (int i = 0; i < list.size(); i++) {
				Object obj = list.get(i);
				String value1 = (String) obj;
				// String value2=(String)obj;
				instVal.setValue1(value1);
				listInstValu.add(instVal);
				instVal = new ParameterValue();
			}
		}

		catch (Exception ex) {
			ex.printStackTrace();
		}

		return listInstValu;
	}

	@Override
	public List<ParameterValue> getPercent() throws DAOException {
		List<ParameterValue> list = null;
		String sql = "FROM com.bsf.ppm.ParameterValue PV WHERE PV.parmtypecode='EXEPRNCT' and PV.groupCode='SPP'";
		try {
			/*SessionFactory sessionFactory = null;
			sessionFactory = JNDIUtil.getSessionFactory();
			Session session = sessionFactory.openSession();*/
			
			list = (List<ParameterValue>) entityManager.createQuery(sql).getResultList();
			
			return list;
		}catch (Exception ex) {
			System.out.println("Error in fetching percent"+ ex.getMessage());
			throw new DAOException("error.executeQuery", ex);
		}
	}

	/* Execution Rules DropDown values methods */

	@SuppressWarnings("unchecked")
	@Override
	public List<ParameterValue> getExecutionTypeList() throws DAOException {
		List<Object> list = null;
		List<ParameterValue> listInstValu = new ArrayList<ParameterValue>();
		System.out.println("getParameterVDAO------------" + entityManager);
		String sql = "select value1 from ppm_parameter_value where param_type_code='EXETYPE' and group_code='SPP'";
		try {
			list = (List<Object>) entityManager.createNativeQuery(sql)
					.getResultList();
			ParameterValue instVal = new ParameterValue();

			for (int i = 0; i < list.size(); i++) {
				Object obj = list.get(i);
				String value1 = (String) obj;
				// String value2=(String)obj;
				instVal.setValue1(value1);
				listInstValu.add(instVal);
				instVal = new ParameterValue();
			}
		}

		catch (Exception ex) {
			ex.printStackTrace();
		}

		return listInstValu;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ParameterValue> getGroupCode() throws DAOException {
		List<Object> list = null;
		List<ParameterValue> listInstValu = new ArrayList<ParameterValue>();
		String sql = "select group_code from ppm_group where status='A' order by group_code desc";
		try {
			list = (List<Object>) entityManager.createNativeQuery(sql)
					.getResultList();
			ParameterValue instVal = new ParameterValue();

			for (int i = 0; i < list.size(); i++) {
				Object obj = list.get(i);
				String value1 = (String) obj;
				// String value2=(String)obj;
				instVal.setValue1(value1);
				listInstValu.add(instVal);
				instVal = new ParameterValue();
			}
		}

		catch (Exception ex) {
			ex.printStackTrace();
		}

		return listInstValu;
	}

	@Override
	public boolean isUnique(ParameterValue entity) throws DAOException {
		
		return false;
	}

	/* Transaction Reports start */

	@SuppressWarnings("unchecked")
	@Override
	public List<ParameterValue> getSourceSystemList() throws DAOException {
		String sql = "FROM com.bsf.ppm.bo.ParameterValue PV WHERE PV.parmtypecode='SOURCE_SYSTEM' and PV.groupCode='ALL'";
		try {
			List<ParameterValue> results = (List<ParameterValue>) entityManager
					.createQuery(sql).getResultList();

			return results;
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.executeQuery", ex);

		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ParameterValue> getTransTypeList() throws DAOException {
		String sql = "FROM com.bsf.ppm.bo.ParameterValue PV WHERE PV.parmtypecode='TRANS_TYPE' and PV.groupCode='ALL'";
		System.out.println("Select query:" + sql);
		try {
			List<ParameterValue> results = (List<ParameterValue>) entityManager
					.createQuery(sql).getResultList();

			return results;
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.executeQuery", ex);

		}
	}

	/* Transaction Reports end */

	// By SARaheem

	@SuppressWarnings("unchecked")
	@Override
	public List<ParameterValue> getEmpCategoryList() throws DAOException {
		String sql = "FROM com.bsf.ppm.ParameterValue PV WHERE PV.parmtypecode='EMPCTRY' and PV.groupCode='LLS'";
		try {
			List<ParameterValue> results = (List<ParameterValue>) entityManager
					.createQuery(sql).getResultList();

			return results;
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.executeQuery", ex);

		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ParameterValue> getEmpCategoryDescList() throws DAOException {

		List<Object> list = null;
		List<ParameterValue> listInstValu = new ArrayList<ParameterValue>();
		
		String sql = "select value1 ||' Type '||value2 ||' days - '|| value3 from ppm_parameter_value where param_type_code = 'EMPCTRY'";
			//	String sql = "select ACCT_NO from loan_instalments_dets where ACCT_NO = '82388100129'";
				try {
			list = (List<Object>) entityManager.createNativeQuery(sql).getResultList();
			ParameterValue instVal = new ParameterValue();

			for (int i = 0; i < list.size(); i++) {
				Object obj = list.get(i);
				String value1 = (String) obj;
				instVal.setValue1(value1);
				listInstValu.add(instVal);
				instVal = new ParameterValue();
			}
			return listInstValu;
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.executeQuery", ex);

		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void updateEmpCategorySetupList(AccountClass item) throws DAOException {

		List<Object> list = null;
		
		String sql = "select * from loan_instalments_dets where acct_no='"+item.getAccountNo()+"'";
		System.out.println("Select Sql is ::: "+sql);
		try {
			
			list = (List<Object>) entityManager.createNativeQuery(sql).getResultList();
			System.out.println("list size in update emp catg setup ::: "+list.size());
			
			
			if(list != null && !list.isEmpty()){
	
			String updateSql = "update loan_instalments_dets set emp_ctgry='"+item.getEmpCategory()+"',updt_date=sysdate,updt_user='"+JSFUtil.getLoggedInUserInfo().getUserId()+"',description='EMPCTGRY Updated by User' where acct_no='"+item.getAccountNo()+"'";
				
			int updateCount =	entityManager.createNativeQuery(updateSql).executeUpdate();
			
			if(updateCount > 0){
				System.out.println("Udate successful in loan_instalments_dets table");
				
			}else{
				
				System.out.println("Udate Fail in loan_instalments_dets table");
			}
				
			}
			
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.executeQuery", ex);

		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<PpmParameterValuesSetup> getEmpCategorySetupList() throws DAOException {

		List<PpmParameterValuesSetup> list = null;
		List<PpmParameterValuesSetup> listInstValu = new ArrayList<PpmParameterValuesSetup>();
		String sql = "select v.value1 ,v.value3 ,v.value2 ,create_date,created_By,Update_date,Updated_By from ppm_parameter_value v where param_type_code = 'EMPCTRY' and group_code='LLS' ";
		try {
			list = (List<PpmParameterValuesSetup>) entityManager.createNativeQuery(sql).getResultList();
			
			System.out.println("PpmParameterValuesSetup List Size ::: "+list.size());
			
			
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.executeQuery", ex);

		}
		
		return list;
	}
	
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<AccountClass> checkCategoryExists(String category) throws DAOException {

		List<AccountClass> list = null;
		
		String sql = "select emp_ctgry from account_class where emp_ctgry = '"+category+"'";
		try {
			list = (List<AccountClass>) entityManager.createNativeQuery(sql).getResultList();
			
			System.out.println("PpmParameterValuesSetup List Size ::: "+list.size());
			
			
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.executeQuery", ex);

		}
		
		return list;
	}
	
	
	public void insertLogHistory(AccountClass item,String action) throws DAOException{
		
		
		String newStatusQuery = "select value1 ||' _ '|| value2 from ppm_parameter_value where param_type_code = 'EMPCTRY' and value1 = '"+item.getEmpCategory()+"'";
		
		String newStatus = (String) entityManager.createNativeQuery(newStatusQuery).getSingleResult();
		
		System.out.println("newStatus :: "+ newStatus);
		
		
		String updateSql = "insert into ppm_status_history(inst_reference,change_date,changed_by,old_status,new_status) values  ('"+item.getAccountNo()+"',sysdate,'"+JSFUtil.getLoggedInUserInfo().getUserId()+"','"+action+"','"+newStatus+"')";
		
		int updateCount =	entityManager.createNativeQuery(updateSql).executeUpdate();
		
		if(updateCount > 0){
			System.out.println("insert into ppm_status_history successfull");
			
		}else{
			
			System.out.println("insert into ppm_status_history failed.");
		}
		
		
		
	}
	
	
public void insertLogHistoryEmpSetupDel(String empCategory) throws DAOException{
		
		
		
		String updateSql = "insert into ppm_status_history(inst_reference,change_date,changed_by,old_status,new_status) values  ('EMPCTRY',sysdate,'"+JSFUtil.getLoggedInUserInfo().getUserId()+"','"+empCategory+"','DELETE')";
		
		int updateCount =	entityManager.createNativeQuery(updateSql).executeUpdate();
		
		if(updateCount > 0){
			System.out.println("insert into ppm_status_history successfull");
			
		}else{
			
			System.out.println("insert into ppm_status_history failed.");
		}
		
		
		
	}



}