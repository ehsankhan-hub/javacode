package com.bsf.ppm.dao.jpa;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.persistence.Query;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.bsf.ipp.IPPUTIL;
import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.dao.InstructionDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.fts.FTSResponsePostingEntity;
import com.bsf.ppm.util.JNDIUtil;
import com.bsf.ppm.util.StringUtils;
import com.bsf.ppm.InstructionDetails;
import com.bsf.ppm.InstructionListValues;
import com.bsf.ppm.LoanBlockDets;
import com.bsf.ppm.LoanInstalmentsDets;
import com.bsf.ppm.Ppm_Inst_Transactions;
import com.bsf.ppm.Ppm_Instructions;

@Transactional
public class InstructionJpaDAO extends PaginatedJpaDAO<Ppm_Instructions, String> implements InstructionDAO {


private static final Logger logger = Logger.getLogger("com.bsf.ppm.controller");	
/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(Ppm_Instructions entity) {
		// TODO Auto-generated method stub
		return false;
	}

	
	/* Batch Job if Source system SPP*/
	 @Override
	 @Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
	 public int updateInstruction(Ppm_Inst_Transactions instTransactions,Ppm_Instructions instruction,BigDecimal trnsAonunt)throws DAOException{
		 int result=0;	
		 String status="";
			 try{
			 BigDecimal paidAmount=new BigDecimal(0);
			 Integer noOfSucsInst=0;
			 BigDecimal totalAmount=new BigDecimal(0);
			 if(instruction.getPaidAmount()!=null&&instruction.getPaidAmount()!=0.0){
			 paidAmount=new BigDecimal(instruction.getPaidAmount());
			logger.info("paidAmount=="+paidAmount);
			}
			 SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
			 String trnsDate=dateFormat.format(instTransactions.getTrnsDate());
			 			 	 
			 if(instruction.getNoOfSucsInst()!=null&&instruction.getNoOfSucsInst()!=0&&(instruction.getNoOfSucsInst()>0)){
				 noOfSucsInst= instruction.getNoOfSucsInst(); 
			 }
			 if(instruction.getTotalAmount()!=null&&instruction.getTotalAmount().compareTo(BigDecimal.ZERO)!=0){
				 totalAmount =instruction.getTotalAmount();
			 }
			 if(instruction.getStatus()!=null&&!"".equals(instruction.getStatus())){
			 status=instruction.getStatus(); 
			 }
			 int doubValue=totalAmount.compareTo(paidAmount);
			 if(doubValue>0){
				 logger.info("doubValue>");
			 }
			 else if(doubValue<0){
				 logger.info("totalAmount<"); 
			 }
			 else{
			
			 }	 
			 if(trnsAonunt!=null&&(trnsAonunt.compareTo(BigDecimal.ZERO)!=0)){
			 paidAmount=trnsAonunt.add(paidAmount);
			 }
			 if(!"CLS".equals(status)){
			  int noOfSuccInst=instruction.getNoOfSucsInst();	
			  StringBuffer queryUpdate=new StringBuffer();
			  queryUpdate.append("UPDATE ppm_instructions i SET i.paid_amount="+"'"+paidAmount+"'");
			  if(instruction.getNoOfInst()==noOfSuccInst+1){
			  status="CLS";
			  queryUpdate.append(",i.status=");
			  queryUpdate.append("'"+status+"'");
			  }
			  queryUpdate.append(",i.no_of_sucs_inst="+"'"+noOfSucsInst+"'+1" 
		       +",i.last_inst_date=sysdate"+
		       ",i.inst_last_suc_date=sysdate"+ 
		       ",i.inst_last_run_date= ");
			  queryUpdate.append("'"+trnsDate+"'");
			  queryUpdate.append(" WHERE i.inst_reference ="+"'"+instruction.getInstReference().trim()+"'");
			  Query query= entityManager.createNativeQuery(queryUpdate.toString());
			  result=query.executeUpdate();
			  logger.info("updateInstruction result=="+result);
			 }
			 else{
				 logger.info("Status not equal to CLS.");
			 result=2; 
			 }
			 }
			 catch(Exception e){
			 logger.error("Tryig to update ppm_instructions getting error:: "+e.getMessage());
			 }
			 return result;
		 }
		   
	
	/* public int updateInstruction(Ppm_Instructions instruction,BigDecimal trnsAonunt)throws DAOException{
	 int result=0;	 
		 try{
		 //EntityManagerFactory entityManagerFac = (EntityManagerFactory)SpringAppContext.getBean("entityManagerFactory");
		 //entityManager=entityManagerFac.createEntityManager();	
		 BigDecimal paidAmount=new BigDecimal(0.0);
		 Integer noOfSucsInst=0;
		 BigDecimal totalAmount=new BigDecimal(0.00);
		 if(instruction.getPaidAmount()!=null&&!"".equals(instruction.getPaidAmount())){
		 paidAmount=new BigDecimal(instruction.getPaidAmount());
		 }
		 String status="";
		 	 
		 if(instruction.getNoOfSucsInst()!=null&&!"".equals(instruction.getNoOfSucsInst())&&(instruction.getNoOfSucsInst()>0)){
			 noOfSucsInst= instruction.getNoOfSucsInst(); 
		 }
		 if(instruction.getTotalAmount()!=null&&!"".equals(instruction.getTotalAmount())){
			 totalAmount =instruction.getTotalAmount();
		 }
		 if(instruction.getStatus()!=null&&!"".equals(instruction.getStatus())){
		 status=instruction.getStatus(); 
		 }
		 System.out.println("paidAmount==after add of trnsAonunt="+paidAmount);
		 System.out.println("noOfSucsInst==="+instruction.getNoOfSucsInst());
		 System.out.println("totalAmount==="+totalAmount);
		 int doubValue=totalAmount.compareTo(paidAmount);
		 System.out.println("paidAmount =="+paidAmount);
		 System.out.println("trnsAonunt=="+trnsAonunt);
		 if(doubValue>0){
			 System.out.println("doubValue>");
		 }
		 else if(doubValue<0){
			 System.out.println("totalAmount<"); 
		 }
		 else{
		
		 }	 
		
		 paidAmount=trnsAonunt.add(paidAmount);
		 if(!"CLS".equals(status)){
		  int noOfSuccInst=instruction.getNoOfSucsInst();	
		  StringBuffer queryUpdate=new StringBuffer();
		  queryUpdate.append("UPDATE ppm_instructions i SET i.paid_amount="+"'"+paidAmount+"'");
		  if(instruction.getNoOfInst()==noOfSuccInst+1){
		  status="CLS";
		  queryUpdate.append(",i.status=");
		  queryUpdate.append("'"+status+"'");
		  }
		  queryUpdate.append(",i.no_of_sucs_inst="+"'"+noOfSucsInst+"'+1" 
	       +",i.last_inst_date=sysdate"+
	       ",i.inst_last_suc_date=sysdate"+                            
	       " WHERE i.inst_reference ="+"'"+instruction.getInstReference().trim()+"'");
		 System.out.println("queryUpdate==="+queryUpdate);
		 Query query= entityManager.createNativeQuery(queryUpdate.toString());
		 result=query.executeUpdate();
		 System.out.println("updateInstruction result=="+result);
		 }
		 else{
		 result=2; 
		 }
		 }
		 catch(Exception e){
		 e.printStackTrace(); 
		 logger.error("Tryig to update ppm_instructions getting error:: "+IPPUTIL.buildExceptionMessage(e));
		 }
		 return result;
	 }*/
	 		 
	 /*Batch Job if Source system LLS get the detail from LOAN_INSTALMENTS_DETS table using instReference */
	 public LoanInstalmentsDets getLoanInstallmentDets(String instRef)throws DAOException{
		 LoanInstalmentsDets loanInstalmentsDets=null;
		 try{
		 String querySlect="FROM LoanInstalmentsDets WHERE reference="+"'"+instRef+"'";
		 loanInstalmentsDets=(LoanInstalmentsDets)entityManager.createQuery(querySlect).getSingleResult();	 
	     System.out.println("loanInstalmentsDets from getLoanInstallmentDets="+loanInstalmentsDets);
		 }
		 catch(Exception ex){
		 //ex.printStackTrace();
		 return loanInstalmentsDets;
		 }
	     return loanInstalmentsDets;
	 }
	@Override
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class) 
	public int updateLoanInstalmentsDets(LoanInstalmentsDets loanInstalmentsDets)throws DAOException {
	int result=0;
	//try {
		// Build the Update Query
		String updateQuery = "update "+
				"LoanInstalmentsDets as type set type.blockedFlag=:blockedFlag , type.updateDate=:updateDate , type.updateUser=:updateUser,"+
				"type.description=:description where type.reference=:reference and type.acctNumber=:acctNumber";
		
		    // Build Query Object
		    Query query = entityManager.createQuery(updateQuery.toString());
    		query.setParameter("blockedFlag","Y");
    		query.setParameter("updateDate",new Date());
			query.setParameter("updateUser","PPM");
			query.setParameter("description","Success");
			query.setParameter("reference",loanInstalmentsDets.getReference());
			query.setParameter("acctNumber",loanInstalmentsDets.getAcctNumber());
			result=query.executeUpdate();
		
	/*} catch (Exception ex) {
		ex.printStackTrace();
	}*/
	
	return result;
	
	
	}
	
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class) 
	public int updateLoanInstalmentsDetsPostingFail(LoanInstalmentsDets loanInstalmentsDets)throws DAOException {
	int result=0;
	//try {
		// Build the Update Query
		String updateQuery = "update "+
				"LoanInstalmentsDets as type set type.blockedFlag=:blockedFlag , type.updateDate=:updateDate , type.updateUser=:updateUser,"+
				"type.description=:description where type.reference=:reference and type.acctNumber=:acctNumber";
		
		    // Build Query Object
		    Query query = entityManager.createQuery(updateQuery.toString());
    		query.setParameter("blockedFlag","N");
    		query.setParameter("updateDate",new Date());
			query.setParameter("updateUser","PPM");
			query.setParameter("description","Fail");
			query.setParameter("reference",loanInstalmentsDets.getReference());
			query.setParameter("acctNumber",loanInstalmentsDets.getAcctNumber());
			result=query.executeUpdate();
		
	/*} catch (Exception ex) {
		ex.printStackTrace();
	}*/
	
	return result;
	
	
	}
	
	
	/*@Override
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class) 
	public int insertLoanBlockDets(LoanBlockDets loanBlockDets)throws DAOException {
	int result=0;
	try {
		// Build the Update Query
		String updateQuery = "update "+
				"LoanInstalmentsDets as type set type.blockedFlag=:blockedFlag, type.updateDate=:updateDate , type.updateUser=:updateUser,"+
				"type.description=:description where type.reference=:reference";

		    // Build Query Object
		    Query query = entityManager.createQuery(updateQuery.toString());
    		query.setParameter("blockedFlag","Y");
			query.setParameter("updateDate",new Date());
			query.setParameter("updateUser","Auto");
			query.setParameter("description","Success");
			query.setParameter("reference",loanBlockDets.getReference());
			result=query.executeUpdate();
		
	} catch (Exception ex) {
		ex.printStackTrace();
	}
	
	return result;
	
	
	}*/
	
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
	public int insertLoanBlockDets(LoanBlockDets loanBlockDets)throws DAOException {
		try {
			// Persist the Entity
			entityManager.persist(loanBlockDets);
			return 1;
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.save.entity", ex,loanBlockDets.toString());
		}
	}

	
	
	@SuppressWarnings("unchecked")
	public List<InstructionListValues> getAllInstruction(String instReferenc,String samaReference)throws DAOException {
		
		List<InstructionListValues> listInstValu=new ArrayList<InstructionListValues>();
		InstructionListValues instVal =new InstructionListValues();
		List<Object[]>list=null;
		try {
		StringBuilder query=new StringBuilder();
		System.out.println("samaReference"+samaReference);
		System.out.println("instReferenc"+instReferenc);
		if(("".equals(samaReference))&&("".equals(instReferenc))){
			query.append("SELECT inst.INST_REFERENCE,inst.ACT_NO,inst.TOTAL_AMOUNT,inst.STATUS,inst.FREQUENCY, instDtl.RELATED_REFERENCE,inst.INST_AMOUNT,inst.START_DATE_H,inst.END_DATE_H,inst.START_DATE_G,inst.END_DATE_G,instDtl.BEN_BANK,instDtl.BEN_ACT,inst.INST_ACTION_TYPE,inst.NO_OF_INST,inst.DAY_OF_PAYMENT,inst.INST_CALENDAR,instDtl.BEN_NAME,instDtl.BEN_ADDRESS,instDtl.BEN_BANK_ADD1,instDtl.PAY_DETAILS,instDtl.RELATED_DOC,inst.INITIATOR_COMMENT,inst.VALIDATOR_COMMENT FROM PPM_INSTRUCTIONS inst ,PPM_INSTRUCTIONS_DETAILS instDtl WHERE inst.INST_REFERENCE=instDtl.INST_REFERENCE AND inst.STATUS='NEW' ");
			
			
		}
		else{
			System.out.println("query==="+query);
			query.append("SELECT inst.INST_REFERENCE,inst.ACT_NO,inst.TOTAL_AMOUNT,inst.STATUS,inst.FREQUENCY, instDtl.RELATED_REFERENCE,inst.INST_AMOUNT,inst.START_DATE_H,inst.END_DATE_H,inst.START_DATE_G,inst.END_DATE_G,instDtl.BEN_BANK,instDtl.BEN_ACT,inst.INST_ACTION_TYPE,inst.NO_OF_INST,inst.DAY_OF_PAYMENT,inst.INST_CALENDAR,instDtl.BEN_NAME,instDtl.BEN_ADDRESS,instDtl.BEN_BANK_ADD1,instDtl.PAY_DETAILS,instDtl.RELATED_DOC,inst.INITIATOR_COMMENT,inst.VALIDATOR_COMMENT FROM PPM_INSTRUCTIONS inst ,PPM_INSTRUCTIONS_DETAILS instDtl WHERE inst.INST_REFERENCE=instDtl.INST_REFERENCE ");		
		}
		if(!"".equals(samaReference)&&samaReference!=null){
			list=null;
			query.append("AND ");
			query.append("instDtl.RELATED_REFERENCE=");
			query.append("'"+samaReference+"'");
			
			   
		}
		if(instReferenc!=""&&instReferenc!=null){
		list=null;
		query.append("AND ");
		query.append("inst.INST_REFERENCE= ");
		query.append("'"+instReferenc+"'");
		}
		query.append(" order by inst.INST_REFERENCE ");
		
		list=(List<Object[]>) entityManager.createNativeQuery(query.toString()).getResultList();
				
		for (int i = 0; i < list.size(); i++) {
			Object[] obj = list.get(i);
	    	String instReference=(String)obj[0];
	    	String accNumber=(String)obj[1];
	    	BigDecimal totalAmont=(BigDecimal)obj[2];
	    	String status=(String)obj[3];
	    	String frequency=(String)obj[4];
	        String samaReferencevalue=(String)obj[5];
	        BigDecimal instAmount=(BigDecimal)obj[6];
	        String startDateH=(String)obj[7];
	        String endDateH=(String)obj[8];
	        Date startDateG=(Date)obj[9];
	        Date endDateG=(Date)obj[10];
	        String bankName=(String)obj[11];
	        String benAcc=(String)obj[12];
	        String tnsType=(String)obj[13];
	        BigDecimal noOfInst=(BigDecimal)obj[14];
	        String dayOfPayment=(String)obj[15];
	        String calendarType=(String)obj[16];
	        String benName=(String)obj[17];
	        String benAddress=(String)obj[18];
	        String benBankAddrdss1=(String)obj[19];
	        String payDtls=(String)obj[20];
	        String relatedDoc=(String)obj[21];
	        String initComment=(String)obj[22];
	        String validatorComnt=(String)obj[23];
	        if(instReference!=(null)){
	    	instVal.setInstReference(instReference);
	        }
	        if(accNumber!=(null)){
	        instVal.setAccNumber(accNumber);
	        }
	        if(totalAmont!=(null)){
	        instVal.setTotalAmount(totalAmont.doubleValue());
	        }
	        instVal.setStatus(status);
	        if(frequency!=null){
	        instVal.setFrequency(frequency);
	        }
	        
	        instVal.setSamaReference(samaReferencevalue);
	        if(instAmount!=null) {
	        instVal.setInstAmount(instAmount);
	        }
	        if(startDateH!=null){
	        	instVal.setStartDateH(startDateH);
	        }
	        if(endDateH!=null){
	        	instVal.setEndDateH(endDateH);
	        
	        }
	        if(startDateG!=null){
	        	instVal.setStartDateG(startDateG);
	        }
	        if(endDateG!=null){
	        	instVal.setEndDateG(endDateG);
	        }
	        if(bankName!=null){
	        	instVal.setBakName(bankName);
	        }
	        if(benAcc!=null){
	        	instVal.setBenAcc(benAcc);
	        }
	        if(tnsType!=null){
	        instVal.setTnsType(tnsType);
	        }
	        if(noOfInst!=null){
	        	instVal.setNoOfInst(noOfInst.intValue());
	        }
	        if(dayOfPayment!=null){
	        	instVal.setDayOfPayment(dayOfPayment);	
	        }
	        if(calendarType!=null){
	        instVal.setCalenderType(calendarType);
	        }
	        if(benName!=null||!"".equals(benName)){
	        	instVal.setBenName(benName);
	        }
	        if(benAddress!=null||!"".equals(benAddress)){
	        	instVal.setBenAddress(benAddress);
	        }
	        if(benBankAddrdss1!=null||!"".equals(benBankAddrdss1)){
	        	instVal.setBenBankAddrs1(benBankAddrdss1);
	        }
	        if(payDtls!=null||!"".equals(payDtls)){
	        	instVal.setPayDtls(payDtls);
	        }
	        if(relatedDoc!=null||!"".equals(relatedDoc)){
	        	instVal.setRelatedDoc(relatedDoc);
	        }
	        if(initComment!=null&&!"".equals(initComment)){
				 instVal.setInitComment(initComment);
			 }
			 if(validatorComnt!=null&&!"".equals(validatorComnt)){
				 instVal.setValidatorComnt(validatorComnt);
			 }
	        listInstValu.add(instVal); 	
	        instVal = new InstructionListValues();
	    }
			
		
		}
		catch (Exception ex) {
		ex.printStackTrace();	
		}
		
		return listInstValu;
	}
    
	@SuppressWarnings("unchecked")
	public List<InstructionListValues> getAllInquiryInstruction(String instReferenc,String samaReference,BigDecimal totalAmount,String cptNummber,Date firstInstDate,Date lastInstDate,String instStatus)throws DAOException {
		List<InstructionListValues> listInstValu=new ArrayList<InstructionListValues>();
		InstructionListValues instVal =new InstructionListValues();
		List<Object[]>list=null;
		try {
		StringBuilder query=new StringBuilder();
		if((!"".equals(samaReference)&&samaReference!=null)||(instReferenc!=""&&instReferenc!=null)||(totalAmount!=null&&totalAmount.compareTo(BigDecimal.ZERO) != 0)||(!"".equals(cptNummber)&&cptNummber!=null)||(!"".equals(instStatus)&&instStatus!=null)||(!"".equals(firstInstDate)&&firstInstDate!=null)&&(!"".equals(lastInstDate)&&lastInstDate!=null)){
		query.append("SELECT inst.INST_REFERENCE,inst.ACT_NO,inst.TOTAL_AMOUNT,inst.STATUS,inst.FREQUENCY, instDtl.RELATED_REFERENCE,inst.INST_AMOUNT,inst.START_DATE_H,inst.END_DATE_H,inst.START_DATE_G,inst.END_DATE_G,instDtl.BEN_BANK,instDtl.BEN_ACT,inst.INST_ACTION_TYPE,inst.NO_OF_INST,inst.DAY_OF_PAYMENT,inst.INST_CALENDAR, instDtl.BEN_NAME,instDtl.BEN_ADDRESS,instDtl.BEN_BANK_ADD1,instDtl.PAY_DETAILS,instDtl.CUST_NAME,inst.CREATED_DATE,inst.NO_OF_SUCS_INST,inst.PAID_AMOUNT,instDtl.RELATED_DOC,inst.INST_EXE_TYPE,inst.MAX_DAYS_RANGE,inst.EVNT_TRIGGER_ON,inst.TRGR_NXT_CYCLE_DAY,inst.INST_LAST_SUC_DATE,inst.NO_OF_FAIL_INST,inst.INITIATOR_COMMENT,inst.VALIDATOR_COMMENT,inst.INIT_BRANCH FROM PPM_INSTRUCTIONS inst ,PPM_INSTRUCTIONS_DETAILS instDtl WHERE inst.INST_REFERENCE=instDtl.INST_REFERENCE ");
		}
		if(!"".equals(samaReference)&&samaReference!=null){
			list=null;
			query.append(" AND ");
			query.append("instDtl.RELATED_REFERENCE=");
			query.append("'"+samaReference+"'");
			
			   
		}
		if(instReferenc!=""&&instReferenc!=null){
		list=null;
		query.append(" AND ");
		query.append("inst.INST_REFERENCE= ");
		query.append("'"+instReferenc+"'");
		}
		if(totalAmount!=null&&totalAmount.compareTo(BigDecimal.ZERO) != 0){
		list=null;
		query.append(" AND ");
		query.append("inst.TOTAL_AMOUNT= ");
		query.append("'"+totalAmount+"'");
		}
		
		
		
		if(!"".equals(cptNummber)&&cptNummber!=null){
		if(cptNummber.length()==11){
			list=null;
			query.append(" AND ");
			query.append("instDtl.INST_ACT_NO = ");
			query.append("'"+cptNummber+"'");	
		}
		else if(cptNummber.length()==6){
			list=null;
			query.append(" AND ");
			query.append("instDtl.INST_ACT_NO LIKE ");
			query.append("'"+"%"+cptNummber+"%"+"'");
		}
		}
		
		if((!"".equals(firstInstDate)&&firstInstDate!=null)&&(!"".equals(lastInstDate)&&lastInstDate!=null)){
			
			System.out.println("firstInstDate-"+firstInstDate);
			SimpleDateFormat sd=new SimpleDateFormat("MM/dd/yyyy");
		    String frstDate=sd.format(firstInstDate);
	    	SimpleDateFormat sdLdate=new SimpleDateFormat("MM/dd/yyyy");
		    String lstDate=sdLdate.format(lastInstDate);
	    	list=null;
			query.append(" AND ");
			query.append("inst.START_DATE_G >=");
			query.append("to_Date(");
			query.append("'"+frstDate+"',");
			query.append("'mm/dd/yyyy')");
			query.append(" AND ");
			query.append("inst.END_DATE_G <=");
			query.append("to_Date(");
			query.append("'"+lstDate+"',");
			query.append("'mm/dd/yyyy')");
		}
		
		if(!"".equals(instStatus)&&instStatus!=null){
		if(!"ALL".equalsIgnoreCase(instStatus)){
		list=null;
		query.append(" AND ");
		query.append("inst.STATUS= ");
		query.append("'"+instStatus+"'");	
		}
		
		}
		query.append(" order by inst.INST_REFERENCE ");
		
		if((!"".equals(samaReference)&&samaReference!=null)||(instReferenc!=""&&instReferenc!=null)||(totalAmount!=null&&totalAmount.compareTo(BigDecimal.ZERO) != 0)||((!"".equals(cptNummber)&&cptNummber!=null)&&(cptNummber.length()==11)||(cptNummber.length()==6))||(!"".equals(instStatus)&&instStatus!=null)||(!"".equals(firstInstDate)&&firstInstDate!=null)&&(!"".equals(lastInstDate)&&lastInstDate!=null)){
			list=null;
			list=(List<Object[]>) entityManager.createNativeQuery(query.toString()).getResultList();
		
			
			for (int i = 0; i < list.size(); i++) {
 				Object[] obj = list.get(i);
				String instReference=(String)obj[0];
		    	String accNumber=(String)obj[1];
		    	BigDecimal totalAmont=(BigDecimal)obj[2];
		    	String status=(String)obj[3];
		    	String frequency=(String)obj[4];
		        String samaReferencevalue=(String)obj[5];
		        BigDecimal instAmount=(BigDecimal)obj[6];
		        String startDateH=(String)obj[7];
		        String endDateH=(String)obj[8];
		        Date startDateG=(Date)obj[9];
		        Date endDateG=(Date)obj[10];
		        String bankName=(String)obj[11];
		        String benAcc=(String)obj[12];
		        String tnsType=(String)obj[13];
		        BigDecimal noOfInst=(BigDecimal)obj[14];
		        String dayOfPayment=(String)obj[15];
		        String calendarType=(String)obj[16];
		        String benName=(String)obj[17];
		        String benAddress=(String)obj[18];
		        String benBankAddrdss1=(String)obj[19];
		        String payDtls=(String)obj[20];
		        String custName=(String)obj[21];
		        Date createdDate=(Date)obj[22];
		        BigDecimal numOfSucsInst=(BigDecimal)obj[23];
		        BigDecimal paidAmnt=(BigDecimal)obj[24];
		        String relatedDoc=(String)obj[25];
		        String instExeType=(String)obj[26];
		        String maxDaysRange=(String)obj[27];
		        String evntTriggerOn=(String)obj[28];
		        String trgrNxtCycleDay=(String)obj[29];
		        Date instLastSucDate=(Date)obj[30];	
		        BigDecimal numOfFailInst=(BigDecimal)obj[31];
		        String initComment=(String)obj[32];
		        String validatorComnt=(String)obj[33];
		        String branchCode=(String)obj[34];
		        if(instReference!=(null)){
		    	instVal.setInstReference(instReference);
		        }
		        if(accNumber!=(null)){
		        instVal.setAccNumber(accNumber);
		        }
		        if(totalAmont!=(null)){
		        instVal.setTotalAmount(totalAmont.doubleValue());
		        }
		        instVal.setStatus(status);
		        if(frequency!=null){
		        instVal.setFrequency(frequency);
		        }
		        
		        instVal.setSamaReference(samaReferencevalue);
		        if(instAmount!=null) {
		        instVal.setInstAmount(instAmount);
		        }
		        if(startDateH!=null){
		        	instVal.setStartDateH(startDateH);
		        }
		        if(endDateH!=null){
		        	instVal.setEndDateH(endDateH);
		        
		        }
		        if(startDateG!=null){
		        	instVal.setStartDateG(startDateG);
		        }
		        if(endDateG!=null){
		        	instVal.setEndDateG(endDateG);
		        }
		        if(bankName!=null){
		        	instVal.setBakName(bankName);
		        }
		        if(benAcc!=null){
		        	instVal.setBenAcc(benAcc);
		        }
		        if(tnsType!=null){
			        instVal.setTnsType(tnsType);
			    }
			        if(noOfInst!=null){
			        	instVal.setNoOfInst(noOfInst.intValue());
			    }
			    if(dayOfPayment!=null){
			        	instVal.setDayOfPayment(dayOfPayment);	
			     }
			    if(calendarType!=null){
				 instVal.setCalenderType(calendarType);
				 }
				 if(benName!=null||!"".equals(benName)){
				        	instVal.setBenName(benName);
				 }
				if(benAddress!=null||!"".equals(benAddress)){
				 instVal.setBenAddress(benAddress);
				  }
				 if(benBankAddrdss1!=null||!"".equals(benBankAddrdss1)){
				  instVal.setBenBankAddrs1(benBankAddrdss1);
				 }
				 if(payDtls!=null||!"".equals(payDtls)){
				  instVal.setPayDtls(payDtls);
				 }
				 if(custName!=null||!"".equals(custName)){
					 instVal.setCustName(custName);
				 }
				 if(createdDate!=null&&!"".equals(createdDate)){
					 instVal.setCreatedDate(createdDate);
				 }
				 if(numOfSucsInst!=null&&!"".equals(numOfSucsInst)){
					 instVal.setNoOfSucsInst(numOfSucsInst.intValue()) ;
				 }
				 if(paidAmnt!=null&&!"".equals(paidAmnt)){
					 instVal.setPaidAmount(paidAmnt.doubleValue());
				 }
				 if(relatedDoc!=null&&!"".equals(relatedDoc)){
					 instVal.setRelatedDoc(relatedDoc);
				 }
				 if(instExeType!=null&&!"".equals(instExeType)){
					 instVal.setInstExeType(instExeType) ;
				 }
				 if(maxDaysRange!=null&&!"".equals(maxDaysRange)){
					 instVal.setMaxDaysRange(maxDaysRange);
				 }
				 if(evntTriggerOn!=null&&!"".equals(evntTriggerOn)){
					 instVal.setEvntTriggerOn(evntTriggerOn) ;
				 }
				 if(trgrNxtCycleDay!=null&&!"".equals(trgrNxtCycleDay)){
					 instVal.setTrgrNxtCycleDay(trgrNxtCycleDay) ;
				 }
				 if(instLastSucDate!=null&&!"".equals(instLastSucDate)){
					 instVal.setInstLastSucDate(instLastSucDate) ;
				 }
				 if(numOfFailInst!=null&&numOfFailInst.compareTo(BigDecimal.ZERO) != 0){
					 instVal.setNumOfFailInst(numOfFailInst.intValue());
				 }
				 if(initComment!=null&&!"".equals(initComment)){
					 instVal.setInitComment(initComment);
				 }
				 if(validatorComnt!=null&&!"".equals(validatorComnt)){
					 instVal.setValidatorComnt(validatorComnt);
				 }
				 if(branchCode!=null&&!"".equals(branchCode)){
					 instVal.setBranchCode(branchCode);
				 }
				 
				 
				 
				 
				 
		        listInstValu.add(instVal); 	
		        instVal = new InstructionListValues();
		    }
			
		}
		}
		catch (Exception ex) {
		ex.printStackTrace();	
		}
		
		return listInstValu;
	}
    
	@SuppressWarnings("unchecked")
	public List<InstructionListValues> getListMaintenence(String cptNummber){
		List<InstructionListValues> listInstValu=new ArrayList<InstructionListValues>();
		InstructionListValues instVal =new InstructionListValues();
		List<Object[]>list=null;
		try {
		StringBuilder query=new StringBuilder();
		query.append("SELECT inst.INST_REFERENCE,inst.ACT_NO,inst.TOTAL_AMOUNT,inst.STATUS,inst.FREQUENCY, instDtl.RELATED_REFERENCE,inst.INST_AMOUNT,instDtl.DOC_DATE,instDtl.DOC_RCV_DATE,inst.START_DATE_G,inst.END_DATE_G,instDtl.BEN_BANK,instDtl.CUST_NAME,instDtl.INST_DTL_ID,instDtl.BEN_ACT,instDtl.RELATED_DOC,inst.NO_OF_SUCS_INST,inst.PAID_AMOUNT,inst.INST_CALENDAR, instDtl.BEN_NAME,instDtl.BEN_ADDRESS,instDtl.BEN_BANK_ADD1,instDtl.PAY_DETAILS,inst.NO_OF_INST,inst.DAY_OF_PAYMENT,inst.INST_ACTION_TYPE FROM PPM_INSTRUCTIONS inst ,PPM_INSTRUCTIONS_DETAILS instDtl WHERE inst.INST_REFERENCE=instDtl.INST_REFERENCE ");
		
		if(!"".equals(cptNummber)&&cptNummber!=null){
			list=null;
			query.append("AND ");
			query.append("inst.ACT_NO LIKE ");
			query.append("'"+"%"+cptNummber+"%"+"'");
		}
		
		query.append(" order by inst.INST_REFERENCE ");
		if(!"".equals(cptNummber)&&cptNummber!=null){
			list=null;
			list=(List<Object[]>) entityManager.createNativeQuery(query.toString()).getResultList();
		
			
			for (int i = 0; i < list.size(); i++) {
				Object[] obj = list.get(i);
				String instReference=(String)obj[0];
		    	String accNumber=(String)obj[1];
		    	BigDecimal totalAmont=(BigDecimal)obj[2];
		    	String status=(String)obj[3];
		    	String frequency=(String)obj[4];
		        String samaReferencevalue=(String)obj[5];
		        BigDecimal instAmount=(BigDecimal)obj[6];
		        String startDateH=(String)obj[7];
		        String endDateH=(String)obj[8];
		        Date startDateG=(Date)obj[9];
		        Date endDateG=(Date)obj[10];
		        String bankName=(String)obj[11];
		        String custName=(String)obj[12];
		        BigDecimal instDtlId=(BigDecimal)obj[13];
		        String benAcc=(String)obj[14];
		        String relatedDoc=(String)obj[15]; 
		        // String filePath=(String)obj[15];
		        BigDecimal numOfSucsInst=(BigDecimal)obj[16];
		        BigDecimal paidAmnt=(BigDecimal)obj[17];
		        String calendarType=(String)obj[18];
		        String benName=(String)obj[19];
		        String benAddress=(String)obj[20];
		        String benBankAddrdss1=(String)obj[21];
		        String payDtls=(String)obj[22];
		        BigDecimal noOfInst=(BigDecimal)obj[23];
		        String dayOfPayment=(String)obj[24];
		        String tnsType=(String)obj[25];
		       	if(instReference!=(null)){
		    	instVal.setInstReference(instReference);
		        }
		        if(instDtlId!=null){
		        instVal.setInstDtlId(instDtlId.longValue());
		        }
		        if(accNumber!=(null)){
		        instVal.setAccNumber(accNumber);
		        }
		        if(totalAmont!=(null)){
		        instVal.setTotalAmount(totalAmont.doubleValue());
		        }
		        instVal.setStatus(status);
		        if(frequency!=null){
		        instVal.setFrequency(frequency);
		        }
		        
		        instVal.setSamaReference(samaReferencevalue);
		        if(instAmount!=null) {
		        instVal.setInstAmount(instAmount);
		        }
		        if(startDateH!=null){
		        	instVal.setStartDateH(startDateH);
		        }
		        if(endDateH!=null){
		        	instVal.setEndDateH(endDateH);
		        
		        }
		        if(startDateG!=null){
		        	instVal.setStartDateG(startDateG);
		        }
		        if(endDateG!=null){
		        	instVal.setEndDateG(endDateG);
		        }
		        if(bankName!=null){
		        	instVal.setBakName(bankName);
		        }
		        if(custName!=null){
		        	instVal.setCustName(custName);
		        }
		        if(benAcc!=null){
		        instVal.setBenAcc(benAcc);
		        }
		      /*  if(filePath!=null){
		        instVal.setFilePath(filePath);
		        }*/
		        if(numOfSucsInst!=null){
		        instVal.setNoOfSucsInst(numOfSucsInst.intValue());
		        }
		        if(paidAmnt!=null||"".equals(paidAmnt)){
		        instVal.setPaidAmount(paidAmnt.doubleValue());
		        }
		        if(calendarType!=null){
					 instVal.setCalenderType(calendarType);
					 }
					 if(benName!=null||!"".equals(benName)){
					        	instVal.setBenName(benName);
					 }
					if(benAddress!=null||!"".equals(benAddress)){
					 instVal.setBenAddress(benAddress);
					  }
					 if(benBankAddrdss1!=null||!"".equals(benBankAddrdss1)){
					  instVal.setBenBankAddrs1(benBankAddrdss1);
					 }
					 if(payDtls!=null||!"".equals(payDtls)){
					  instVal.setPayDtls(payDtls);
					 }
					  if(noOfInst!=null){
				        	instVal.setNoOfInst(noOfInst.intValue());
				    }
				    if(dayOfPayment!=null){
				        	instVal.setDayOfPayment(dayOfPayment);	
				     }
				    if(tnsType!=null){
				        instVal.setTnsType(tnsType);
				    } 
				    if(relatedDoc!=null&&!"".equals(relatedDoc)){
				    	instVal.setRelatedDoc(relatedDoc);
				    }
		        listInstValu.add(instVal); 	
		        instVal = new InstructionListValues();
		    }
			
		}
		}
		catch (Exception ex) {
		ex.printStackTrace();	
		}
		
		return listInstValu;
	}
	public InstructionDetails getInstructionDetails(String ref) throws DAOException {
	String query="from com.bsf.ppm.InstructionDetails where instReference= "+"'"+ref+"'";
	InstructionDetails result=(InstructionDetails)entityManager.createQuery(query.toString()).getSingleResult();	
	return result ;
	}
	
	/*  */
	@Override
	public Long getPPMReference() throws DAOException {
		String sql = "SELECT PPM_INS_REF.NEXTVAL FROM DUAL";
		try {
			// Execute native query and get the result list
			List results= entityManager.createNativeQuery(sql).getResultList();
			// Iterate the list and get the sequence value
			BigDecimal bd = (BigDecimal)results.iterator().next();
			
			System.out.println("Sequence Value="+bd.longValue());
			return bd.longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), sql);
		}
	}
	
	/*  */
	@Override
	public String getSFLReference() throws DAOException {
		String sql = "SELECT PPM_INS_REF.NEXTVAL FROM DUAL";
		try {
			// Execute native query and get the result list
			List results= entityManager.createNativeQuery(sql).getResultList();
			// Iterate the list and get the sequence value
			BigDecimal bd = (BigDecimal)results.iterator().next();
			
			System.out.println("Sequence Value="+bd.longValue());
			return "SFL"+bd.longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), sql);
		}
	}
	
	/*  */
	@Override
	public Long getInstDetaiSeqGen() throws DAOException {
		String sql = "SELECT PPM_INS_DTL_ID.NEXTVAL FROM DUAL";
		try {
			// Execute native query and get the result list
			List results= entityManager.createNativeQuery(sql).getResultList();
			// Iterate the list and get the sequence value
			BigDecimal bd = (BigDecimal)results.iterator().next();
			System.out.println("Sequence Value="+bd);
			return bd.longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), sql);
		}
	}
	
	
	
	@Override
	public void updateInstDtl(int ruleId,String ruleName,String value1)
			throws DAOException {

		String[] namedParams = { "ruleId","exeRuleName", "value1" };
		Object[] params = {ruleId, ruleName,value1};
		updateByNamedQuery("PpmExeRulesCrit.updatePpmExeRulesCrit", namedParams,params);
	}
	
	@Override
	public void updateInstructionPriority(String groupCode, int groupPriority)
			throws DAOException {

		String[] namedParams = { "instProrty", "instgroupcode", "status" };
		Object[] params = { groupPriority, groupCode, "ACT" };
		updateByNamedQuery("Ppm_Instructions.updatePriorityByGroupCode", namedParams,
				params);
	}
/*TRANSACTION REPORTS START*/
	@SuppressWarnings("unchecked")
	public List<Ppm_Inst_Transactions> getTransReport(String instReferenc,Date trnsDateFrom,Date trnsDateTo,BigDecimal totalAmount,String creditAcc,String debitAcc,String instStatus)throws DAOException {
		List<InstructionListValues> listInstValu=new ArrayList<InstructionListValues>();
		InstructionListValues instVal =new InstructionListValues();
		List<Ppm_Inst_Transactions>list=new ArrayList<Ppm_Inst_Transactions>();
		try {
		StringBuilder query=new StringBuilder();
		if(((!"".equals(trnsDateFrom)&&trnsDateFrom!=null)&&(!"".equals(trnsDateTo)&&trnsDateTo!=null))||(instReferenc!=""&&instReferenc!=null)||(totalAmount!=null&&totalAmount.compareTo(BigDecimal.ZERO) != 0)||(!"".equals(creditAcc)&&creditAcc!=null)||(!"".equals(debitAcc)&&debitAcc!=null)||(!"".equals(instStatus)&&instStatus!=null)){
		//query.append("SELECT inst.INST_REFERENCE,inst.ACT_NO,inst.TOTAL_AMOUNT,inst.STATUS,inst.FREQUENCY, instDtl.RELATED_REFERENCE,inst.INST_AMOUNT,inst.START_DATE_H,inst.END_DATE_H,inst.START_DATE_G,inst.END_DATE_G,instDtl.BEN_BANK,instDtl.BEN_ACT,inst.INST_ACTION_TYPE,inst.NO_OF_INST,inst.DAY_OF_PAYMENT,inst.INST_CALENDAR, instDtl.BEN_NAME,instDtl.BEN_ADDRESS,instDtl.BEN_BANK_ADD1,instDtl.PAY_DETAILS FROM PPM_INSTRUCTIONS inst ,PPM_INSTRUCTIONS_DETAILS instDtl WHERE inst.INST_REFERENCE=instDtl.INST_REFERENCE ");
		query.append("SELECT object(trns) from Ppm_Inst_Transactions as trns WHERE 1=1 ");
		//query.append("'"+instReferenc+"'");
		}
		
		if(!"".equals(instReferenc)&&instReferenc!=null){
			list=null;
			query.append(" AND ");
			query.append("trns.instRef=");
			query.append("'"+instReferenc+"'");
			
			   
		}
		if(((!"".equals(trnsDateFrom)&&trnsDateFrom!=null)&&(!"".equals(trnsDateTo)&&trnsDateTo!=null))){
			list=null;
						
			SimpleDateFormat sd=new SimpleDateFormat("MM/dd/yyyy");
		    String frmDate=sd.format(trnsDateFrom);
	    	SimpleDateFormat sdLdate=new SimpleDateFormat("MM/dd/yyyy");
		    String toDate=sdLdate.format(trnsDateTo);
			query.append(" AND ");
			query.append("trns.trnsDate");
			query.append(" BETWEEN ");
			query.append("to_Date(");
			query.append("'"+frmDate+"',"); 
			query.append("'mm/dd/yyyy')");
			query.append(" AND ");
			query.append("to_Date(");
			query.append("'"+toDate+"',"); 
			query.append("'mm/dd/yyyy')");
		}
		
		if(totalAmount!=null&&totalAmount.compareTo(BigDecimal.ZERO) != 0){
		list=null;
		query.append(" AND ");
		query.append("trns.amount= ");
		query.append("'"+totalAmount+"'");
		}
		if(!"".equals(creditAcc)&&creditAcc!=null){
			list=null;
			query.append(" AND ");
			query.append("trns.creditAcc= ");
			query.append("'"+creditAcc+"'");	
		}
		if(!"".equals(debitAcc)&&debitAcc!=null){
			list=null;
			query.append(" AND ");
			query.append("trns.debitAcc= ");
			query.append("'"+debitAcc+"'");	
		}
		if(!"".equals(instStatus)&&instStatus!=null){
		if(!"ALL".equalsIgnoreCase(instStatus)){
		list=null;
		query.append(" AND ");
		query.append("trns.processStatus= ");
		query.append("'"+instStatus+"'");	
		}
		}
		query.append(" order by trns.instRef ");
		
		if(((!"".equals(trnsDateFrom)&&trnsDateFrom!=null)&&(!"".equals(trnsDateTo)&&trnsDateTo!=null))||(instReferenc!=""&&instReferenc!=null)||(totalAmount!=null&&totalAmount.compareTo(BigDecimal.ZERO) != 0)||(!"".equals(creditAcc)&&creditAcc!=null)||(!"".equals(debitAcc)&&debitAcc!=null)||(!"".equals(instStatus)&&instStatus!=null)){
			list=null;
			
			list= entityManager.createQuery(query.toString()).getResultList();
		    System.out.println("Relsuls from list=="+list);
			
					
		}
		}
		catch (Exception ex) {
		ex.printStackTrace();	
		}
		
		return list;
	}
	
	///Salary Percentage start 
	
	public void updateInstruction(Ppm_Instructions ppmInstruction)throws DAOException{
		//SessionFactory sessionFactory=new AnnotationConfiguration().configure().buildSessionFactory();
		
		Session session=null;
		try {
			session=JNDIUtil.getSession();
					
			
			Transaction transaction=session.beginTransaction();
			session.update(ppmInstruction);
			transaction.commit();
			session.flush();
			session.close();
			
		} catch (Exception e) {
			System.out.println(e);
			throw new DAOException(e.getMessage());
		}
		
	}
	
	public void saveInstruction(Ppm_Instructions ppmInstruction)throws DAOException{
		//SessionFactory sessionFactory=new AnnotationConfiguration().configure().buildSessionFactory();
		SessionFactory sessionFactory=null;
	    Session session=null;
			try {
			session=JNDIUtil.getSession();
			Transaction transaction=session.beginTransaction();
			session.save(ppmInstruction);
			transaction.commit();
			session.flush();
			session.close();
			
		} catch (Exception e) {
			System.out.println(e);
			throw new DAOException(e.getMessage());
		}
		
	}
	
	public Ppm_Instructions findInstructionSalaryPercent(Ppm_Instructions ppmInstruction)throws DAOException{
		//String query="from Ppm_Instructions where custCode="+"'"+ppmInstruction.getCustCode()+"' AND instReference="+"'"+ppmInstruction.getInstReference()+"'";
		String query="from Ppm_Instructions where custCode="+"'"+ppmInstruction.getCustCode()+"'";
		//SessionFactory sessionFactory=new AnnotationConfiguration().configure().buildSessionFactory();
		//Session session=sessionFactory.openSession();
		Ppm_Instructions ppmInst= null;
		Session session=null;
			try {
			session=JNDIUtil.getSession();
			ppmInst=(Ppm_Instructions)session.createQuery(query).uniqueResult();
			
			System.out.println("ppmInst"+ppmInst.getCustCode()); 
			session.close();			
		} catch (Exception e) {
			System.out.println(e);
			throw new DAOException(e.getMessage());
		}
		
		//Ppm_Instructions ppmInst=(Ppm_Instructions)session.get(Ppm_Instructions.class, ppmInstruction.getInstReference());
		return ppmInst;
	}
	
	@Override
	public int updateEntityStatusByIds(String[] ids, String idField,
			String statusField, String status, UserInfo updatedBy)
			throws DAOException {
		int updated=0;
		     System.out.println("String[] ids="+ids.length);
		try {

			// Build the Disable Query
			StringBuilder disableQuery = new StringBuilder("update ").append(
					getPersistentClass().getSimpleName()).append(
					" as type set type.").append(statusField).append(
					"=:status, type.updatedBy=:updatedBy").append(
					", type.updatedDate=:updateDate")
					.append("  where type.").append(idField)
					.append("=:typeId ");

			// Build Query Object
			Query query = entityManager.createQuery(disableQuery.toString());
            System.out.println("statusField=="+statusField);
            System.out.println("status=="+status);
            System.out.println("idField=="+idField);
			// Execute Query for each Id in the ids array
			for (int i = 0; i < ids.length; i++) {
				
				query.setParameter("status", status);
				query.setParameter("updatedBy", updatedBy.getUserId());
				query.setParameter("updateDate", new Timestamp(Calendar
				.getInstance().getTimeInMillis()));
				query.setParameter("typeId",(ids[i]));
				System.out.println("(ids[i]) updateEntityStatusByIds="+ids[i]);
				updated=query.executeUpdate();
				System.out.println("Record Updated Successfully=="+updated);
			}
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.disable.entities", ex,
					getPersistentClass().getName());
		}
		return updated;

	}
	
	public void updateStagingTable(String custCode,String status)throws DAOException{
		String updateStagiQue="update Ppm_Debit_Block_Staging set status="+"'"+status+"'" +" where cust_Code="+"'"+custCode+"'";
		Query query =entityManager.createNativeQuery(updateStagiQue);
		query.executeUpdate();
	}
	
	
	
	///Salary Percentage end
    		
	

}