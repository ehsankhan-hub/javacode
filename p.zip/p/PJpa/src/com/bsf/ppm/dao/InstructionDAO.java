package com.bsf.ppm.dao;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.LoanBlockDets;
import com.bsf.ppm.Ppm_Instructions;
import com.bsf.ppm.InstructionDetails;
import com.bsf.ppm.InstructionListValues;
import com.bsf.ppm.LoanInstalmentsDets;
import com.bsf.ppm.Ppm_Inst_Transactions;
public interface InstructionDAO extends PaginatedDAO<Ppm_Instructions, String> {
	
	/*public Instruction getByFtsReference(String ftsReference) throws DAOException;*/
	
    	
	//public Instruction save(Instruction entity) throws DAOException;
	/*public InstructionsModify save(InstructionsModify entity)throws DAOException;*/
	public String getSFLReference() throws DAOException;
	public LoanInstalmentsDets getLoanInstallmentDets(String instRef)throws DAOException;
	public int updateLoanInstalmentsDets(LoanInstalmentsDets loanInstalmentsDets)throws DAOException ;
	public int updateLoanInstalmentsDetsPostingFail(LoanInstalmentsDets loanInstalmentsDets)throws DAOException ;
	public int insertLoanBlockDets(LoanBlockDets loanBlockDets)throws DAOException;
	public int updateInstruction(Ppm_Inst_Transactions instTransactions,Ppm_Instructions instruction,BigDecimal trnsAonunt)throws DAOException;
	public List<InstructionListValues> getAllInstruction(String instReferenc,String samaReference)throws DAOException ;
	public List<InstructionListValues> getAllInquiryInstruction(String instReferenc,String samaReference,BigDecimal totalAmount,String accountCptDate,Date firstInstDate,Date lastInstDate,String status)throws DAOException ;
	public List<InstructionListValues> getListMaintenence(String cptNummber)throws DAOException;
	public Long getPPMReference() throws DAOException;
	public InstructionDetails getInstructionDetails(String ref) throws DAOException;
	public Long getInstDetaiSeqGen() throws DAOException ;
	public void updateInstDtl(int ruleId,String ruleName,String value1)
	throws DAOException ;
	public void updateInstructionPriority(String groupCode, int groupPriority) throws DAOException;
	/*TRANSACTION REPORTS*/
	public List<Ppm_Inst_Transactions> getTransReport(String instReferenc,Date trnsDateFrom,Date trnsDateTo,BigDecimal totalAmount,String creditAcc,String debitAcc,String instStatus)throws DAOException ;
	
	//Salary Percent start
	public void saveInstruction(Ppm_Instructions ppmInstruction)throws DAOException;
	
	public void updateInstruction(Ppm_Instructions ppmInstruction)throws DAOException;
	
	public Ppm_Instructions findInstructionSalaryPercent(Ppm_Instructions ppmInstruction)throws DAOException;
	
	public int updateEntityStatusByIds(String[] ids, String idField,
			String statusField, String status, UserInfo updatedBy)
			throws DAOException;
	public void updateStagingTable(String custCode,String status)throws DAOException;
	//Salary Percent end
}
