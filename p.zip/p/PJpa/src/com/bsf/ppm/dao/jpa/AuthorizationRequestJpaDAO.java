package com.bsf.ppm.dao.jpa;

import com.bsf.ipp.dao.jpa.AbstractJpaDAO;
import com.bsf.ppm.AuthorizationRequest;
import com.bsf.ppm.dao.AuthorizationRequestDAO;
import com.bsf.ppm.exceptions.DAOException;

/**
 * <p> Data access class to manage CRUD operations on Authorization Request entity
 * Java Persistence API implementation for the AuthorizationRequestDAO.</p> 
 * @author Rakesh
 *
 */
public class AuthorizationRequestJpaDAO extends AbstractJpaDAO<AuthorizationRequest, Long>implements AuthorizationRequestDAO {

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(AuthorizationRequest entity) throws DAOException {
		// TODO Auto-generated method stub
		return false;
	}

}
