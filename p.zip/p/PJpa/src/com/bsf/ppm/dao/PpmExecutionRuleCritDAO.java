package com.bsf.ppm.dao;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.PpmExeRules;
import com.bsf.ppm.PpmExeRulesCriteria;
import com.bsf.ppm.exceptions.DAOException;

public interface PpmExecutionRuleCritDAO extends PaginatedDAO<PpmExeRulesCriteria, String>{
	public boolean isUnique(PpmExeRulesCriteria entity) throws DAOException ;
	public boolean isUniqueJoinTable(PpmExeRulesCriteria entity) throws DAOException ;
}
