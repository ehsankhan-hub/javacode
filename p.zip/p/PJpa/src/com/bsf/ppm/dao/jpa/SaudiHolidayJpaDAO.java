package com.bsf.ppm.dao.jpa;

import java.util.Date;

import javax.persistence.Query;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.SaudiHoliday;
import com.bsf.ppm.dao.SaudiHolidayDAO;
import com.bsf.ppm.exceptions.DAOException;

public class SaudiHolidayJpaDAO extends PaginatedJpaDAO<SaudiHoliday, Long>
implements SaudiHolidayDAO{

	@Override
	public boolean isUnique(SaudiHoliday entity) throws DAOException {
		long recordCount ;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
			.append(getPersistentClass().getSimpleName()).append(
					"  obj  where obj.id !=:id  and  obj.holidayDate=:holidayDate");
				Query jpaQuery = entityManager.createQuery(query.toString());
				if(entity.getId() !=null)
					jpaQuery.setParameter("id", entity.getId());
				else
					jpaQuery.setParameter("id",Long.valueOf(-1));	
				jpaQuery.setParameter("holidayDate", entity.getHolidayDate());
				recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
			} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}

		return recordCount <= 0;
	}

	@Override
	public boolean isValueDateHoliday(Date valueDate) throws DAOException {
		// TODO Auto-generated method stub
		return false;
	}


}
