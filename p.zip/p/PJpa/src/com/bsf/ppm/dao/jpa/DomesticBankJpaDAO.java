package com.bsf.ppm.dao.jpa;

import java.util.List;

import javax.persistence.Query;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.DomesticBank;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.dao.DomesticBankDAO;
import com.bsf.ppm.exceptions.DAOException;

/**
* @author Jakeer Hussain
* Java Persistence API implementation for the DomesticBankDAO
*/
public class DomesticBankJpaDAO extends PaginatedJpaDAO<DomesticBank, Long>
											implements DomesticBankDAO {

	@Override
	public boolean isUnique(DomesticBank entity) throws DAOException {
		long recordCount;
		try {
			StringBuffer query = new StringBuffer(
					"Select count(obj) AS RECCOUNT from ")
					.append(getPersistentClass().getSimpleName())
					.append(
							"  obj  where obj.id !=:id  and  obj.bankCode=:bankCode");
			Query jpaQuery = entityManager.createQuery(query.toString());
			if (entity.getId() != null)
				jpaQuery.setParameter("id", entity.getId());
			else
				jpaQuery.setParameter("id", Long.valueOf(-1));
			jpaQuery.setParameter("bankCode", entity.getBankCode());
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex,
					getPersistentClass().getName());
		}

		return recordCount <= 0;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ipp.otms.dao.DomesticBankDAO#fetchByIbanClearingCode(java.lang.String)
	 */
	@Override
	public DomesticBank fetchByIbanClearingCode(String ibanClearingCode) throws DAOException {
		
		String[] namedParams={"ibanClearingCode","status"};
		Object[] params= {ibanClearingCode, new Long(IConstants.STATUS_TYPE.ACTIVE.ordinal())};
		
		//Fetch Payments List 
		List<DomesticBank> stpLimitsList = findByNamedQuery("DomesticBank.fetchByIbanClearingCode", namedParams, params);
		
		if(stpLimitsList != null && stpLimitsList.size()>0) {
			return stpLimitsList.get(0);
		}
		return null;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ipp.otms.dao.DomesticBankDAO#fetchByBankCode(java.lang.String)
	 */
	@Override
	public DomesticBank fetchByBankCode(String bankCode) throws DAOException {
		
		String[] namedParams={"bankCode", "status"};
		Object[] params= {bankCode, new Long(IConstants.STATUS_TYPE.ACTIVE.ordinal())};
		
		//Fetch Payments List 
		List<DomesticBank> stpLimitsList = findByNamedQuery("DomesticBank.fetchByBankCode", namedParams, params);
		
		if(stpLimitsList != null && stpLimitsList.size()>0) {
			return stpLimitsList.get(0);
		}
		return null;
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ipp.otms.dao.DomesticBankDAO#fetchByBankBic(java.lang.String)
	 */
	@Override
	public DomesticBank fetchByBankBic(String bankBic) throws DAOException {
		
		String[] namedParams={"bankBic", "status"};
		Object[] params= {bankBic, new Long(IConstants.STATUS_TYPE.ACTIVE.ordinal())};
		
		//Fetch Payments List 
		List<DomesticBank> stpLimitsList = findByNamedQuery("DomesticBank.fetchByBankBic", namedParams, params);
		
		if(stpLimitsList != null && stpLimitsList.size()>0) {
			return stpLimitsList.get(0);
		}
		return null;
	}
	

	/* (non-Javadoc)
	 * @see com.bsf.ipp.otms.dao.DomesticBankDAO#fetchAll()
	 */
	@Override
	public List<DomesticBank> fetchAll() throws DAOException {
		
		String[] namedParams={"status"};
		Object[] params= {new Long(IConstants.STATUS_TYPE.ACTIVE.ordinal())};
		
		//Fetch Payments List 
		List<DomesticBank> domesticBanksList = findByNamedQuery("DomesticBank.fetchAllActive", namedParams, params);
		
		if(domesticBanksList != null && domesticBanksList.size()>0) {
			return domesticBanksList;
		}
		return null;
	}
	
	@Override
	public void updateSequenceByBankCode(String bankCode, Long bulkSequence) throws DAOException {
		String[] namedParams={"bulkSequence", "bankCode"};
		Object[] params= {bulkSequence, bankCode};
		
		updateByNamedQuery("DomesticBank.updateSequenceByBankCode", namedParams, params);
		
	}
	
}
