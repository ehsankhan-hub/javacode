package com.bsf.ppm.dao;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.CurrencyCode;

/**
 * @author Zakir
 * Data Access Object for CurrencyCode Entity. Extends PaginatedDAO
 */
public interface CurrencyCodeDAO extends PaginatedDAO<CurrencyCode, String> {

	
	public CurrencyCode getByCurrencyCode(String currency);
}
