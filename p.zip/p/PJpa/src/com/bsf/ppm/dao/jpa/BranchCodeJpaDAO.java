package com.bsf.ppm.dao.jpa;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.Query;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.BranchCode;
import com.bsf.ppm.dao.BranchCodeDAO;
import com.bsf.ppm.exceptions.BusinessException;
import com.bsf.ppm.exceptions.DAOException;

/**
 * @author Zakir
 * Java Persistence API implementation for the BranchAccountDAO.
 */
public class BranchCodeJpaDAO extends PaginatedJpaDAO<BranchCode, String>
		implements BranchCodeDAO {

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(BranchCode entity) throws DAOException {
		long recordCount = -1;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
					.append(getPersistentClass().getSimpleName()).append(
							"  obj  where obj.branchCode=:branchCode ");
			Query jpaQuery = entityManager.createQuery(query.toString());
			/*if(entity.getId() !=null)
			  jpaQuery.setParameter("id", entity.getId());
			else
				 jpaQuery.setParameter("id",Long.valueOf(-1));	*/
			jpaQuery.setParameter("branchCode", entity.getBranchCode());
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}

		return recordCount <= 0;
	}
	
	@Override
	public BranchCode getBranchByCode(String branchCode) throws DAOException, BusinessException
	{
		List<BranchCode> list = findByNamedQuery("BranchCode.findByBranchCode", new String[]{"branchCode"}, new String[]{branchCode});
		if(list != null && list.size()>0)
		{
			return list.get(0);
		}
		else
			return null;
	}
	
	public List<BranchCode> findBranchByClgCenter(String clgCenter)  throws DAOException, BusinessException{
		List<BranchCode> list = null;
		list = new ArrayList<BranchCode>();
		//BranchCode item = null;
		BranchCode branch =null;
		
		String query = "Select bc.branch_code , bc.description as branchDesc ,  bc.status "+ 
		" from clg_branch_mapping bm,branch_code bc"+ 
		" where bm.branch_code=bc.branch_code"+
		" and bm.clg_center=:clgCenter "+
		" order by branch_code";;
		
		Query nativeQuery = entityManager.createNativeQuery(query);
		nativeQuery.setParameter("clgCenter",clgCenter);
		
		List<Object[]> resultsList = nativeQuery.getResultList();
		Iterator<Object[]> itr = resultsList.iterator();
		while (itr.hasNext()) {
			Object[] columns = itr.next();
			branch = new BranchCode();
			branch.setBranchCode(columns[0].toString());
			branch.setDescription(columns[1].toString());
			list.add(branch);
		}
		
		return list;
	}
		
}