package com.bsf.ppm.dao;
import java.util.List;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.InstructionListValues;
import com.bsf.ppm.StatusHistory;

public interface StatusHistoryDAO extends PaginatedDAO<StatusHistory, Long>{
	public List<StatusHistory>getStatusHistoryRecords(String instRefeId)throws DAOException;
	public void insertStatusHisttory(InstructionListValues itemItemDtl,String changeBy,String statusfromItst,String btnType)throws DAOException;
	
}
