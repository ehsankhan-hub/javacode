package com.bsf.ppm.dao.jpa;

import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.GErrorList;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.dao.GErrorListDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.spring.SpringAppContext;


/**
 * @author bsaleem
 * 
 * JPA based DAO Class used to perform backend operations related to groups.
 */
@Transactional
public class GErrorListJpaDAO extends PaginatedJpaDAO<GErrorList, Long> implements GErrorListDAO  {


	@Override
	public boolean isUnique(GErrorList entity) throws DAOException {
		// TODO Auto-generated method stub
		return false;
	}

}
