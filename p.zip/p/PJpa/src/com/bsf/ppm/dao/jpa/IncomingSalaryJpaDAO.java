package com.bsf.ppm.dao.jpa;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.Application;
import com.bsf.ppm.IncomingSalaries;
import com.bsf.ppm.dao.IncomingSalaryDAO;
import com.bsf.ppm.exceptions.DAOException;

@Transactional
public class IncomingSalaryJpaDAO  extends PaginatedJpaDAO<IncomingSalaries, String> implements IncomingSalaryDAO{

	@Override
	public boolean isUnique(IncomingSalaries entity) throws DAOException {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public List<IncomingSalaries> getAccounts(int dateRange)throws DAOException{
		List<Object[]>list=null;
		String query="select CREDT_ACCT_NO,LOG_SYSTEM_DATE from Incoming_Salaries where log_System_Date>=sysdate - "+dateRange;
		IncomingSalaries incomingSalary=new IncomingSalaries();
		
		List<IncomingSalaries>incomingSalaryList=new ArrayList<IncomingSalaries>();
		try{
		list=(List<Object[]>)entityManager.createNativeQuery(query).getResultList();
		
		for (int i = 0; i < list.size(); i++) {
		   	Object[] obj  = list.get(i);
		   	String accountNo=(String)obj[0];
		   	Date log_sys_Date=(Date)obj[1];
		   	incomingSalary.setCreditAcctNo(accountNo);
		   	incomingSalary.setLogSystemDate(log_sys_Date);
		   	incomingSalaryList.add(incomingSalary);
		   	incomingSalary=new IncomingSalaries();  	  
		}  	  
		
		
		}
		catch(Exception daoe){
			daoe.printStackTrace();
		}
		return incomingSalaryList;	
	}
	

}
