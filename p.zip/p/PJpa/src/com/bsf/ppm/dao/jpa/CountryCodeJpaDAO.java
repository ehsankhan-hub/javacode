package com.bsf.ppm.dao.jpa;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.CountryCode;
import com.bsf.ppm.dao.CountryCodeDAO;
import com.bsf.ppm.exceptions.DAOException;


/**
 * 
 * Java Persistence API implementation for the CountryCodeDAO.
 */
@Transactional
public class CountryCodeJpaDAO extends PaginatedJpaDAO<CountryCode, String>
implements CountryCodeDAO{
	
	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(CountryCode entity) throws DAOException {
		long recordCount ;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
					.append(getPersistentClass().getSimpleName()).append(
							"  obj  where obj.countryCode=:countryCode ");
			Query jpaQuery = entityManager.createQuery(query.toString());
			/*if(entity.getId() !=null)
			  jpaQuery.setParameter("id", entity.getId());
			else
				 jpaQuery.setParameter("id",Long.valueOf(-1));	*/
			jpaQuery.setParameter("countryCode", entity.getCountryCode());
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}

		return recordCount <= 0;
	}
	/**
	 * @return
	 */
	public Map<String,String> getAllCounties(){
		Map<String,String> counties=new HashMap<String, String>();
		try {
			List<CountryCode> countiesList = findAll();
			for(CountryCode countryCode:countiesList){
				counties.put(countryCode.getCountryCode(),countryCode.getDescription());
			}
		} catch (Exception e) {
		}
		return counties;
		
	}
	@Override
	public String fetchCountryForChqDrawnCountry(String chqCurrency)
			throws DAOException {

		String curr = null;
		String query = "SELECT CWA.COUNTRY_CODE FROM CURRENCY_WASH_ACCOUNTS CWA, COUNTRY_CODE CC " +
				" WHERE CWA.COUNTRY_CODE = CC.BSF_MAPPING AND CWA.Currency_Code=:chqCurrency";
		
		Query nativeQuery = entityManager.createNativeQuery(query);
		nativeQuery.setParameter("chqCurrency", chqCurrency);		
		List<Object[]> resultList = nativeQuery.getResultList();
		
		for(Object item:resultList){
			curr = (String) item;
		}
		 
		 return curr!=null?curr:"";
	}
}
