package com.bsf.ppm.dao.jpa;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.GeneralConfiguration;
import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.dao.GeneralConfigurationDAO;
import com.bsf.ppm.exceptions.DAOException;
/**
 * @author Zakir
 * Java Persistence API implementation for the BackendSystemDAO.
 */
@Transactional
public class GeneralConfigurationJpaDAO extends PaginatedJpaDAO<GeneralConfiguration, Long> implements GeneralConfigurationDAO {

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(GeneralConfiguration entity) throws DAOException {
		long recordCount = -1;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
					.append(getPersistentClass().getSimpleName()).append(
							"  obj  where obj.id !=:id  and  obj.configurationName=:configurationName ");
			Query jpaQuery = entityManager.createQuery(query.toString());
			if(entity.getId() !=null) {
				jpaQuery.setParameter("id", entity.getId());
			}
			else {
				jpaQuery.setParameter("id",Long.valueOf(-1));
			}
			jpaQuery.setParameter("configurationName", entity.getConfigurationName());
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}
		return recordCount <= 0;
	}
	
	/** Fetch General Configuration Object by name
	 * @param generalConfigName to search for
	 * @return GeneralConfiguration matching the name generalConfigName passed
	 * @throws DAOException
	 */
	@Override
	public GeneralConfiguration getGeneralConfigByName(String generalConfigName) throws DAOException	{
		
		Map<String, String> configSearchCriteria = new HashMap<String, String>();
		configSearchCriteria.put("configurationName",generalConfigName);
		List<GeneralConfiguration> backendSystems = findByCriteria(configSearchCriteria);
		if(backendSystems.size() > 0 )
			return backendSystems.get(0);
		else
			return null;
	}
	
	public Long getForexWSReference() throws DAOException {

		String sql = "select SEQ_FOREX_WS_REFERENCE.NEXTVAL from dual";
		try {
			// Execute native query and get the result list
			List results= entityManager.createNativeQuery(sql).getResultList();
			// Iterate the list and get the sequence value
			BigDecimal bd = (BigDecimal)results.iterator().next();
			Long value = bd.longValue();
			return value;
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), sql);
		}
	}

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.GeneralConfigurationDAO#getMacTTReference()
	 */
	@Override
	public Long getMacTTReference() throws DAOException {
		String sql = "select SEQ_MAC_TT_REFERENCE.NEXTVAL from dual";
		try {
			// Execute native query and get the result list
			List results= entityManager.createNativeQuery(sql).getResultList();
			// Iterate the list and get the sequence value
			BigDecimal bd = (BigDecimal)results.iterator().next();
			Long value = bd.longValue();
			return value;
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), sql);
		}
	}

	@Override
	public Long getB2BTTReference() throws DAOException {
		String sql = "select SEQ_B2B_TT_REFERENCE.NEXTVAL from dual";
		try {
			// Execute native query and get the result list
			List results= entityManager.createNativeQuery(sql).getResultList();
			// Iterate the list and get the sequence value
			BigDecimal bd = (BigDecimal)results.iterator().next();
			Long value = bd.longValue();
			return value;
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), sql);
		}
	}

	@Override
	public Long getCLNFtsReference() throws DAOException {

		String sql = "select SEQ_CLN_INQ.NEXTVAL from dual";
		try {
			// Execute native query and get the result list
			List results= entityManager.createNativeQuery(sql).getResultList();
			// Iterate the list and get the sequence value
			BigDecimal bd = (BigDecimal)results.iterator().next();
			Long value = bd.longValue();
			return value;
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), sql);
		}
	}

	@Override
	public Long getCLNUpdateReference() throws DAOException {

		String sql = "select SEQ_CLN_UPD.NEXTVAL from dual";
		try {
			// Execute native query and get the result list
			List results= entityManager.createNativeQuery(sql).getResultList();
			// Iterate the list and get the sequence value
			BigDecimal bd = (BigDecimal)results.iterator().next();
			Long value = bd.longValue();
			return value;
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), sql);
		}
	}

	@Override
	public Long getCLNIccReference() throws DAOException {

		String sql = "select SEQ_CLN_ICC.NEXTVAL from dual";
		try {
			// Execute native query and get the result list
			List results= entityManager.createNativeQuery(sql).getResultList();
			// Iterate the list and get the sequence value
			BigDecimal bd = (BigDecimal)results.iterator().next();
			Long value = bd.longValue();
			return value;
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), sql);
		}
	}
	
	@Override
	public Long getCLNOccReference() throws DAOException {

		String sql = "select SEQ_CLN_OCC.NEXTVAL from dual";
		try {
			// Execute native query and get the result list
			List results= entityManager.createNativeQuery(sql).getResultList();
			// Iterate the list and get the sequence value
			BigDecimal bd = (BigDecimal)results.iterator().next();
			Long value = bd.longValue();
			return value;
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), sql);
		}
	}

	@Override
	public Long getCLNOutUpdateReference() throws DAOException {

		String sql = "select SEQ_CLN_OUT_UPD.NEXTVAL from dual";
		try {
			// Execute native query and get the result list
			List results= entityManager.createNativeQuery(sql).getResultList();
			// Iterate the list and get the sequence value
			BigDecimal bd = (BigDecimal)results.iterator().next();
			Long value = bd.longValue();
			return value;
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), sql);
		}
	}
	
	@Override
	public Long getCLNOutSchedualNo() throws DAOException {
		String sql = "SELECT SEQ_CLN_OUT_SCHEDUAL.NEXTVAL FROM DUAL";
		try {
			// Execute native query and get the result list
			List results= entityManager.createNativeQuery(sql).getResultList();
			// Iterate the list and get the sequence value
			BigDecimal bd = (BigDecimal)results.iterator().next();
			Long value = bd.longValue();
			return value;
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), sql);
		}
	}
	
	@Override
	public Long getCLNTOutSchedualNo() throws DAOException {
		String sql = "SELECT SEQ_CLN_TC_SCHEDUAL.NEXTVAL FROM DUAL";
		try {
			// Execute native query and get the result list
			List results= entityManager.createNativeQuery(sql).getResultList();
			// Iterate the list and get the sequence value
			BigDecimal bd = (BigDecimal)results.iterator().next();
			Long value = bd.longValue();
			return value;
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), sql);
		}
	}
	

	
	
	
	
}
