package com.bsf.ppm.dao;

import java.math.BigDecimal;
import java.util.List;

import com.bsf.ipp.GeneralConfiguration;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.exceptions.DAOException;

/**
 * @author Zakir
 * Data Access Object for GeneralConfiguration Entity
 * Provides search and find methods for searchCriteria ,sorting, pageNumbers
 */
public interface GeneralConfigurationDAO extends PaginatedDAO<GeneralConfiguration, Long> {

	/** Fetch General Configuration Object by name
	 * @param generalConfigName to search for
	 * @return GeneralConfiguration matching the name generalConfigName passed
	 * @throws DAOException
	 */
	public GeneralConfiguration getGeneralConfigByName(String generalConfigName) throws DAOException;
	
	/**
	 * @return
	 * @throws DAOException
	 */
	public Long getForexWSReference() throws DAOException ;

	/**
	 * @return
	 * @throws DAOException
	 */
	public Long getMacTTReference() throws DAOException ;

	/**
	 * @return
	 * @throws DAOException
	 */
	public Long getB2BTTReference()throws DAOException ;
	
	/**
	 * This method will return nextSequence value of 
	 * native query
	 * @return
	 * @throws DAOException
	 */
	public Long getCLNFtsReference() throws DAOException;
	
	/**
	 * This method will return nextSequence value of 
	 * native query
	 * @return
	 * @throws DAOException
	 */
	public Long getCLNUpdateReference() throws DAOException;
	
	/**
	 * This method will return nextSequence value of 
	 * native query
	 * @return
	 * @throws DAOException
	 */
	public Long getCLNIccReference() throws DAOException;
	
	/**
	 * This method will return nextSequence value of 
	 * native query
	 * @return
	 * @throws DAOException
	 */
	public Long getCLNOccReference() throws DAOException;
	
	/**
	 * This method will return nextSequence value of 
	 * native query
	 * @return
	 * @throws DAOException
	 */
	public Long getCLNOutUpdateReference() throws DAOException;
	
	/**
	 * 
	 * @return
	 */
	public Long getCLNOutSchedualNo() throws DAOException;
	
	/**
	 * @return
	 * @throws DAOException
	 */
	public Long getCLNTOutSchedualNo() throws DAOException;
	

}

