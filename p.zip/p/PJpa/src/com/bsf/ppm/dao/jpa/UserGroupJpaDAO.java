package com.bsf.ppm.dao.jpa;

import java.util.List;

import javax.persistence.Query;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.UserGroup;
import com.bsf.ppm.dao.UserGroupDAO;
import com.bsf.ppm.exceptions.DAOException;


public class UserGroupJpaDAO extends PaginatedJpaDAO<UserGroup, Long> implements UserGroupDAO{

	@Override
	public boolean isUnique(UserGroup entity) throws DAOException {

		long recordCount = -1;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
					.append(getPersistentClass().getSimpleName()).append(
							"  obj  where obj.id !=:id  and  obj.userGroup.id=:userGroupId and  obj.businessObject.id=:busObjId ");
			Query jpaQuery = entityManager.createQuery(query.toString());
			if(entity.getId() !=null)	{
				
				jpaQuery.setParameter("id", entity.getId());
			}
			else	{
				jpaQuery.setParameter("id",Long.valueOf(-1));
			}
			//jpaQuery.setParameter("userGroupId", entity.getUserGroup().getId());
			//jpaQuery.setParameter("busObjId", entity.getBusinessObject().getId());
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}
		return recordCount <= 0;
	}

	@Override
	public List<UserGroup> getGroupsByADName(List<String> adGroupNames)
			throws DAOException {
		
		if(adGroupNames !=null && adGroupNames.size()>0)	{
		
			StringBuffer query= new StringBuffer("select o from UserGroup o where o.adMapping IN ( "); 
			for(String groupName:adGroupNames)	{
				
				query.append("'"+groupName+"',");
			}
			String temp = query.substring(0, query.length()-1);
			temp =  temp+")";
			return this.executeSimpleQuery(temp);
		}
		return null;

	}
}
