package com.bsf.ppm.dao;

import java.util.List;

import com.bsf.ipp.dao.GenericDAO;
import com.bsf.ppm.MailMessage;
import com.bsf.ppm.exceptions.DAOException;

/**
 * Interface for data access operations related to mail messages
 * @author Rakesh
 *
 */
public interface MailMessageDAO extends GenericDAO<MailMessage, Long>  {
	/**
	 * Search for Mail messages satisfying the mail status criteria
	 * @param mailStatus
	 * @return List of Mail Messages satisfying mail status
	 * @throws DAOException
	 */
	public List<MailMessage> findByMailStatus(Integer mailStatus) throws DAOException;
}
