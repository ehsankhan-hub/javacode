package com.bsf.ppm.dao.jpa;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.AbstractJpaDAO;
import com.bsf.ppm.MailMessage;
import com.bsf.ppm.SmsMessage;
import com.bsf.ppm.dao.SmsMessageDAO;
import com.bsf.ppm.exceptions.DAOException;

/**
 * <p>DAO class for SMS message related operations
 * Java Persistence API implementation for the SmsMessageDAO.</p>
 * @author Rakesh
 *
 */
@Transactional
public class SmsMessageJpaDAO extends AbstractJpaDAO<SmsMessage, Long> implements SmsMessageDAO {

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(SmsMessage entity) throws DAOException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.SmsMessageDAO#findBySmsStatus(java.lang.Long)
	 */
	@Override
	public List<SmsMessage> findBySmsStatus(Long smsStatus) throws DAOException {
		Map criterias = new HashMap();
		criterias.put("smsStatus", smsStatus);
		return findByCriteria(criterias);
	}
	


}
