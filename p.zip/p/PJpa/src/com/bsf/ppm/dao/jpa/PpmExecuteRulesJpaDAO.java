package com.bsf.ppm.dao.jpa;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import javax.persistence.Query;
import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.PpmExeRules;
import com.bsf.ppm.PpmExeRulesCriteria;
import com.bsf.ppm.PpmGroup;
import com.bsf.ppm.PpmParameterValue;
import com.bsf.ppm.dao.PpmExecuteRuleDAO;
import com.bsf.ppm.dao.PpmGroupDAO;
import com.bsf.ppm.exceptions.DAOException;

public class PpmExecuteRulesJpaDAO extends PaginatedJpaDAO<PpmExeRules, String> implements
PpmExecuteRuleDAO {

	@Override
	public boolean isUnique(PpmExeRules entity) throws DAOException {
		long recordCount = -1;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
					.append(getPersistentClass().getSimpleName()).append(
							"  obj  where obj.exeRuleName=:exeRuleName ");
			Query jpaQuery = entityManager.createQuery(query.toString());
			jpaQuery.setParameter("exeRuleName", entity.getExeRuleName());
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
			
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}
        
		return recordCount <= 0;
	}
    
	@Override
	public boolean isUniqueJoinTable(List<PpmExeRulesCriteria> benList) throws DAOException {
		long recordCount = -1;
		Iterator<PpmExeRulesCriteria> ppmExeRulesCriteriaItr=benList.iterator();
		String exeRuleName="";
		String fieldName="" ;
		String value1="";
		while(ppmExeRulesCriteriaItr.hasNext()){
			System.out.println("benList.iterator()=="+benList.size());
			PpmExeRulesCriteria ppmExeRulesCriteria=ppmExeRulesCriteriaItr.next();
			
			exeRuleName=ppmExeRulesCriteria.getPpmExeRulesCriteriaPK().getExeRuleName();
			fieldName=ppmExeRulesCriteria.getPpmExeRulesCriteriaPK().getFieldName();
			value1=ppmExeRulesCriteria.getPpmExeRulesCriteriaPK().getValue1();
			System.out.println("exeRuleName===----"+exeRuleName);
			System.out.println("fieldName===----"+fieldName);
		try {
			StringBuffer query = new StringBuffer("Select count(*) AS RECCOUNT from ")
					.append("com.bsf.ppm.PpmExeRulesCriteria").append(
							"  obj  where obj.ppmExeRulesCriteriaPK.exeRuleName=:exeRuleName and obj.ppmExeRulesCriteriaPK.fieldName=:fieldName and obj.ppmExeRulesCriteriaPK.value1=:value1");
			Query jpaQuery = entityManager.createQuery(query.toString());
			jpaQuery.setParameter("exeRuleName", exeRuleName);
			jpaQuery.setParameter("fieldName", fieldName);
			jpaQuery.setParameter("value1", value1);
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
			
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass().getName());
		}
		}
		return recordCount <= 0;
	}
	
	@Override
	public boolean isUniqueFromListObject(List<PpmExeRulesCriteria> benList) throws DAOException {
		long recordCount = -1;
        List<Long>list=new ArrayList<Long>();
        if(benList.size()>0){
        if(benList.size()==1){
        	System.out.println("List size one=="+benList.size());
        recordCount=0;	
        }
        else{
      
		for (int i=0; i<benList.size()-1; i++) {
		    for (int j=i+1; j<benList.size(); j++) {
		   	if((benList.get(i).getPpmExeRulesCriteriaPK()).equals(benList.get(j).getPpmExeRulesCriteriaPK())){
		   		System.out.println("PpmExeRulesCriteria is eqal");
		   		recordCount=1;
		   		}
				
		    }
		    
		}
		
		for(Long recordCont:list){
			System.out.println("recordCont==isUniqueFromListObject=="+recordCont);
			if(recordCont==1){
			recordCount=1;	
			}
			}
			System.out.println("recordCount isUniqueFromListObject <= 0===="+(recordCount <= 0));
			
        }
        
        }
        return recordCount <= 0;
	}
	
	@Override
	public void updateEntityStatusByIds(String[] ids, String idField,
			String statusField, String status, UserInfo updatedBy)
			throws DAOException {
		     System.out.println("String[] ids="+ids.length);
		try {

			// Build the Disable Query
			StringBuilder disableQuery = new StringBuilder("update ").append(
					getPersistentClass().getSimpleName()).append(
					" as type set type.").append(statusField).append(
					"=:status, type.updatedBy=:updatedBy").append(
					", type.updateDate=:updateDate")
					.append("  where type.").append(idField)
					.append("=:typeId ");

			// Build Query Object
			Query query = entityManager.createQuery(disableQuery.toString());
            System.out.println("statusField=="+statusField);
            System.out.println("status=="+status);
            System.out.println("idField=="+idField);
			// Execute Query for each Id in the ids array
			for (int i = 0; i < ids.length; i++) {
				
				query.setParameter("status", status);
				query.setParameter("updatedBy", updatedBy);
				query.setParameter("updateDate", new Timestamp(Calendar
				.getInstance().getTimeInMillis()));
				query.setParameter("typeId",(ids[i]));
				System.out.println("(ids[i]) updateEntityStatusByIds="+ids[i]);
				int updated=query.executeUpdate();
				System.out.println("Record Updated Successfully=="+updated);
			}
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.disable.entities", ex,
					getPersistentClass().getName());
		}

	}
	
	public void deletRule(String exeRuleName)throws DAOException{
	StringBuilder queryDeletExeRule = new StringBuilder("delete ").append(
			"PpmExeRules ").append(" where exeRuleName=:exeRuleName");
	StringBuilder queryDeletExeRuleCrit = new StringBuilder("delete ").append("PpmExeRulesCriteria ").append(" where ppmExeRulesCriteriaPK.exeRuleName=:exeRuleName");		
	Query query = entityManager.createQuery(queryDeletExeRule.toString());
	System.out.println("query delete"+query.toString());
	query.setParameter("exeRuleName", exeRuleName);
	query.executeUpdate();
	Query queryExeRulCrt = entityManager.createQuery(queryDeletExeRuleCrit.toString());
	System.out.println("queryExeRulCrt delete"+queryExeRulCrt.toString());
	queryExeRulCrt.setParameter("exeRuleName", exeRuleName);
	queryExeRulCrt.executeUpdate();
	}
	
	public List<PpmExeRulesCriteria>getRuleDtlCrtList(String ruleName)throws DAOException{
	String queryExeRuleCrt = "From  PpmExeRulesCriteria where ppmExeRulesCriteriaPK.exeRuleName="+"'"+ruleName+"'"+"";
	List<PpmExeRulesCriteria> results= (List<PpmExeRulesCriteria>)entityManager.createQuery(queryExeRuleCrt.toString()).getResultList();	
	return results;
	}
	public List<PpmExeRulesCriteria>deleteDtlCrtList(String exeRuleName,String fieldName,String value1)throws DAOException{
		String queryExeRuleCrt = "DELETE From PpmExeRulesCriteria where ppmExeRulesCriteriaPK.exeRuleName="+"'"+exeRuleName+"'"+" AND ppmExeRulesCriteriaPK.fieldName="+"'"+fieldName+"'"+" AND ppmExeRulesCriteriaPK.value1="+"'"+value1+"'";
		entityManager.createQuery(queryExeRuleCrt.toString()).executeUpdate();	
		return null;
		}
	
	public PpmExeRules getPpmExeRulesList(String ruleName)throws DAOException{
		String queryExeRule = "From  PpmExeRules where exeRuleName="+"'"+ruleName+"'"+"";
		PpmExeRules results= (PpmExeRules) entityManager.createQuery(queryExeRule.toString()).getSingleResult();	
		return results;	
	}
	
	@Override
	public void updatePpmExeRulesCrit(String ruleName,String fieldName,String value1)
			throws DAOException {

		String[] namedParams = {"exeRuleName","fieldName", "value1" };
		Object[] params = { ruleName,fieldName,value1};
		updateByNamedQuery("PpmExeRulesCrit.updatePpmExeRulesCrit", namedParams,params);
	}
	@Override
	public void  updatePpmExeRuleNewCrit(int ruleId,String ruleName,String fupddName,String fupdValue) throws DAOException{
	String insertNewRuleUpd="INSERT INTO PPM_EXE_RULES_CRITERIA(RULE_ID,EXE_RULE_NAME,FIELD_NAME,VALUE1)values("+"'"+ruleId+"'"+","+"'"+ruleName+"'"+","+"'"+fupddName+"'"+","+"'"+fupdValue+"'"+")";	
	Query query=entityManager.createNativeQuery(insertNewRuleUpd);
	query.executeUpdate();
	}
}
