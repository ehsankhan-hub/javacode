package com.bsf.ppm.dao.jpa;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.Application;
import com.bsf.ppm.dao.ApplicationDAO;
import com.bsf.ppm.exceptions.DAOException;
/**
 * @author Zakir
 * Java Persistence API implementation for the ApplicationDAO.
 */
@Transactional
public class ApplicationJpaDAO extends PaginatedJpaDAO<Application, String> implements ApplicationDAO {

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(Application entity) {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.PaginatedJpaDAO#searchByPages(int, int, java.lang.String, boolean)
	 */
	@Override
	public List<Application> searchByPages(int firstItem, int batchSize, String sortField,
			boolean sortAscending) throws DAOException {
		return searchByPages(null, firstItem, batchSize, sortField, sortAscending);
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.PaginatedJpaDAO#searchByPages(java.util.Map, int, int, java.lang.String, boolean)
	 */
	@Override
	public List<Application> searchByPages(Map criterias, int firstItem, int batchSize,
			String sortField, boolean sortAscending) throws DAOException {
		
		//Build the Query String
		StringBuffer query = new StringBuffer("Select obj from ").append(
				getPersistentClass().getSimpleName()).append(" obj");
		Map<String, Object> namedParameter = null;
		//Set the search criteria
		if (criterias != null && criterias.size() > 0) {
			namedParameter = new HashMap<String, Object>();
			
			Iterator<Map.Entry<String, Object>> it = criterias.entrySet().iterator();
			int i = 0;
			Map.Entry<String, Object> pairs = null;
			while (it.hasNext()) {
				i++;
				pairs = it.next();
				if (i == 1) {
					
					query.append(" where obj.applicationName not in ('ROOT','CORE')  and");
				}
				
				if (pairs.getValue() instanceof String)	{
					
					query.append(" ").append(pairs.getKey()).append(" like '%")
							.append(pairs.getValue()).append("%'");
				}else if(pairs.getValue() instanceof Date)	{
					
					 //nextDate sets the nextDate from the current Date. 
					Date nextDate = new Date(((Date)pairs.getValue()).getTime() + 86400000l);
					query.append(" ").append(pairs.getKey()).append(" >=:").append(pairs.getKey()).append(" and ").append(pairs.getKey()).append(" <:")
					.append("nextDate"+i);
					namedParameter.put(pairs.getKey(), pairs.getValue());
					namedParameter.put("nextDate"+i,nextDate);
					
				}else {
					
					query.append(" ").append(pairs.getKey()).append("=:")
							.append(pairs.getKey());
					namedParameter.put(pairs.getKey(), pairs.getValue());
				}

				if (i < criterias.size())
					query.append(" and ");
			}
		}
		//Set Order by Field
		if (sortField != null) {
			query.append("  ORDER BY obj.").append(sortField);
			if (sortAscending)
				query.append(" asc");
			else
				query.append(" desc");

		}
		//Create Query Object
		Query jpaQuery = entityManager.createQuery(query.toString());
		//Set the parameter values for the Query
		if (namedParameter != null && namedParameter.size() > 0) {
			Iterator<Map.Entry<String, Object>> it = namedParameter.entrySet()
					.iterator();
			Map.Entry<String, Object> pairs = null;
			while (it.hasNext()) {
				pairs = it.next();
				jpaQuery.setParameter(pairs.getKey(), pairs.getValue());
			}

		}
		//Set limits for Rows count to be fetched
		jpaQuery.setFirstResult(firstItem);
		jpaQuery.setMaxResults(batchSize);
		//Execute and return the list of Items
		return (List<Application>) jpaQuery.getResultList();
	}
	

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.PaginatedDAO#getResultSize()
	 */
	@Override
	public long getResultSize() throws DAOException {
		//Build the Query String
		StringBuffer query = new StringBuffer("Select count(obj) from ")
				.append(getPersistentClass().getSimpleName()).append(" obj where obj.id >1");
		//Create Query Object
		Query jpaQuery = entityManager.createQuery(query.toString());
		//Return the rows count
		return ((Long) jpaQuery.getSingleResult()).longValue();
	}

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.PaginatedDAO#getResultSize(java.util.Map)
	 */
	@Override
	public long getResultSize(Map<String, Object> criterias)
			throws DAOException {
		//Build the Query String
		StringBuffer query = new StringBuffer("Select count(obj) from ")
				.append(getPersistentClass().getSimpleName()).append(" obj");
		Map<String, Object> namedParameter = null;
		//Set the search criteria
		if (criterias != null && criterias.size() > 0) {
			
			namedParameter = new HashMap<String, Object>();
			Object[] keyArray = criterias.keySet().toArray();
			for (int i = 0; i < keyArray.length; i++) {
				
				if (i == 0) {
					
					query.append(" where obj.applicationName not in ('ROOT','CORE') and");
				}
				if(criterias.get(keyArray[i]) instanceof String )	{
					
					query.append(" ").append(keyArray[i]).append(" like '%").append(criterias.get(keyArray[i])).append("%'");
				}else if(criterias.get(keyArray[i]) instanceof StringBuffer){
					
					query.append(" ").append(keyArray[i]).append(" in ")
					.append(criterias.get(keyArray[i]));
				}else if(criterias.get(keyArray[i]) instanceof Date)	{
					
					Date nextDate = new Date(((Date)criterias.get(keyArray[i])).getTime() + 86400000l);
					query.append(" ").append(keyArray[i]).append(" >=:").append(keyArray[i]).append(" and ").append(keyArray[i]).append("<=:")
					.append("nextDate"+i);
					namedParameter.put(keyArray[i].toString(), criterias.get(keyArray[i]));
					namedParameter.put("nextDate"+i, nextDate);
					
				}else 	{
					
					query.append(" ").append(keyArray[i]).append("=:")
					.append(keyArray[i]);
					namedParameter.put(keyArray[i].toString(), criterias.get(keyArray[i]));
				}
				if (i != (keyArray.length - 1)) {
					
					query.append(" and");
				}
			}
		}
		//Create Query Object
		Query jpaQuery = entityManager.createQuery(query.toString());
		
		if (namedParameter != null && namedParameter.size() > 0) {
			Iterator<Map.Entry<String, Object>> it = namedParameter.entrySet()
					.iterator();
			Map.Entry<String, Object> pairs = null;
			while (it.hasNext()) {
				pairs = it.next();
				jpaQuery.setParameter(pairs.getKey(), pairs.getValue());
			}
		}
		//Return the rows count matching the search criteria
		return ((Long) jpaQuery.getSingleResult()).longValue();
	}

	@Override
	public void updateStatus(String applicationName, Long status) throws DAOException {
		String[] namedParams={"status","applicationName"};
		Object[] params= {status,applicationName};
		updateByNamedQuery("Application.updateStatus", namedParams, params);
	
	}

	@Override
	public Application getByApplicationName(String applicationName)
			throws DAOException {
		String[] namedParams={"applicationName"};
		Object[] params= {applicationName};
		List<Application> apps=findByNamedQuery("Application.findByName", namedParams, params);
		
		if (apps!=null && apps.size()>0){
			return apps.get(0);
		}		
		return null;
	}	
	
	
}
