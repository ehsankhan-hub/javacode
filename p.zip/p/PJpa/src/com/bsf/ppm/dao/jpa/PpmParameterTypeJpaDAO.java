package com.bsf.ppm.dao.jpa;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.persistence.Query;
import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.PpmExeRules;
import com.bsf.ppm.PpmExeRulesCriteria;
import com.bsf.ppm.PpmGroup;
import com.bsf.ppm.PpmParameterType;
import com.bsf.ppm.PpmParameterValue;
import com.bsf.ppm.PpmParameterValue.PpmParameterValuePK;
import com.bsf.ppm.dao.PpmExecuteRuleDAO;
import com.bsf.ppm.dao.PpmGroupDAO;
import com.bsf.ppm.dao.PpmParameterTypeDAO;
import com.bsf.ppm.exceptions.DAOException;

public class PpmParameterTypeJpaDAO extends PaginatedJpaDAO<PpmParameterType, String> implements
PpmParameterTypeDAO {
    
	@Override
	public boolean isUnique(PpmParameterType entity) throws DAOException {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public boolean isUniqueFromListObject(List<PpmParameterValue> benList) throws DAOException {
		long recordCount = -1;
        List<Long>list=new ArrayList<Long>();
        if(benList.size()>0){
        if(benList.size()==1){
        	System.out.println("List size one=="+benList.size());
        recordCount=0;	
        }
        else{
      
		for (int i=0; i<benList.size()-1; i++) {
		    for (int j=i+1; j<benList.size(); j++) {
		   	if((benList.get(i).getPpmParameterValue()).equals(benList.get(j).getPpmParameterValue())){
		   		System.out.println("Parma value is eqal");
		   		recordCount=1;
		   		}
				
		    }
		    
		}
		
		for(Long recordCont:list){
			System.out.println("recordCont==isUniqueFromListObject=="+recordCont);
			if(recordCont==1){
			recordCount=1;	
			}
			}
			System.out.println("recordCount isUniqueFromListObject <= 0===="+(recordCount <= 0));
			
        }
        
        }
        return recordCount <= 0;
	}
	
	@Override
	public boolean isUnique(List<PpmParameterValue> ruleDtlList) throws DAOException {
		long recordCount = -1;
		Iterator<PpmParameterValue> itrppmparamValue=ruleDtlList.iterator();
		String parmtypecode="";
		String groupCode="" ;
		String value1="";
		while(itrppmparamValue.hasNext()){
			System.out.println("benList.iterator()=="+ruleDtlList.size());
			PpmParameterValue ppmParmVale=itrppmparamValue.next();
						
			parmtypecode=ppmParmVale.getPpmParameterValue().getParmtypecode();
			groupCode=ppmParmVale.getPpmParameterValue().getGroupCode();
			value1=ppmParmVale.getPpmParameterValue().getValue1();
			System.out.println("parmtypecode===----"+parmtypecode);
			System.out.println("groupCode===----"+groupCode);
			System.out.println("value1===----"+value1);
		try {
			StringBuffer query = new StringBuffer("Select count(*) AS RECCOUNT from ")
			.append("com.bsf.ppm.PpmParameterValue").append(
			"  obj  where obj.ppmParameterValue.parmtypecode=:parmtypecode and obj.ppmParameterValue.groupCode=:groupCode and obj.ppmParameterValue.value1=:value1");
            Query jpaQuery = entityManager.createQuery(query.toString());
            jpaQuery.setParameter("parmtypecode", parmtypecode);
            jpaQuery.setParameter("groupCode", groupCode);
            jpaQuery.setParameter("value1", value1);
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
			System.out.println("recordCount===from isUnique:::::"+recordCount);
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}
		}
		return recordCount <= 0;
	}
	@Override
	public boolean isUniqueJoinTable(List<PpmParameterValue> benList) throws DAOException {
		long recordCount = -1;
		List<Long> recordCountList=new ArrayList<Long>();
		Iterator<PpmParameterValue> itrppmparamValue=benList.iterator();
		String parmtypecode="";
		String groupCode="" ;
		String value1="";
		while(itrppmparamValue.hasNext()){
			System.out.println("benList.iterator()=="+benList.size());
			PpmParameterValue ppmParmVale=itrppmparamValue.next();
			
			parmtypecode=ppmParmVale.getPpmParameterValue().getParmtypecode();
			groupCode=ppmParmVale.getPpmParameterValue().getGroupCode();
			value1=ppmParmVale.getPpmParameterValue().getValue1();
			System.out.println("parmtypecode===----"+parmtypecode);
			System.out.println("groupCode===----"+groupCode);
			System.out.println("value1===----"+value1);
			
			//Set<PpmParameterValue> ppmParameterValue=new HashSet<PpmParameterValue>(benList);
			//System.out.println("ppmParameterValue benList"+ppmParameterValue.size());	
			
		try {
			StringBuffer query = new StringBuffer("Select count(*) AS RECCOUNT from ")
					.append("com.bsf.ppm.PpmParameterValue").append(
							"  obj  where obj.ppmParameterValue.parmtypecode=:parmtypecode and obj.ppmParameterValue.groupCode=:groupCode and obj.ppmParameterValue.value1=:value1");
			Query jpaQuery = entityManager.createQuery(query.toString());
			jpaQuery.setParameter("parmtypecode", parmtypecode);
			jpaQuery.setParameter("groupCode", groupCode);
			jpaQuery.setParameter("value1", value1);
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
			recordCountList.add(recordCount);
			System.out.println("recordCount===from isUniqueJoinTable==="+recordCountList.size());
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass().getName());
		}
        
		
	}
	for(Long recordCont:recordCountList){
	System.out.println("recordCont===="+recordCont);
	if(recordCont==1){
	recordCount=1;	
	}
	}
	System.out.println("recordCount <= 0===="+(recordCount <= 0));
	return recordCount <= 0;
	}	
	
	@Override
	public void updateEntityStatusByIds(String[] ids, String idField,
			 UserInfo updatedBy)
			throws DAOException {
		     System.out.println("String[] ids="+ids.length);
		try {

			// Build the Disable Query
			StringBuilder deleteQuery = new StringBuilder("delete ").append(
					getPersistentClass().getSimpleName()).append(
					" as type ").append("  where type.").append(idField)
					.append("=:typeId ");
			
			StringBuilder deleteExeCritQuery=new StringBuilder("delete ").append(
					"PpmParameterValue ").append(
					" as type ").append("  where type.ppmParameterValue.").append(idField)
					.append("=:typeId ");

			// Build Query Object
			Query query = entityManager.createQuery(deleteQuery.toString());
			Query queryExeCrit = entityManager.createQuery(deleteExeCritQuery.toString());
            //System.out.println("statusField=="+statusField);
                   System.out.println("idField=="+idField);
			// Execute Query for each Id in the ids array
			for (int i = 0; i < ids.length; i++) {
				//query.setParameter("status", status);
				query.setParameter("typeId",(ids[i]));
				queryExeCrit.setParameter("typeId",(ids[i]));
				int updated=query.executeUpdate();
				queryExeCrit.executeUpdate();
				System.out.println("Record Deleted Successfully=="+updated);
			}
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.disable.entities", ex,
					getPersistentClass().getName());
		}

	}
	
	public void deletRule(String paramType)throws DAOException{
	StringBuilder queryDeletExeRule = new StringBuilder("delete ").append(
			getPersistentClass().getSimpleName()).append(" where parmtypecode=:paramType");
	StringBuilder queryDeletPpmParameterValue = new StringBuilder("delete ").append("PpmParameterValue ").append(" where parmtypecode=:parmtypecode");		
	Query query = entityManager.createQuery(queryDeletPpmParameterValue.toString());
	Query queryPpmParameterValue = entityManager.createQuery(queryDeletPpmParameterValue.toString());
	query.setParameter("parmtypecode", paramType);
	queryPpmParameterValue.setParameter("parmtypecode", paramType);
	query.executeUpdate();
	//queryExeRulCrt.executeUpdate();
	}
	
	public List<PpmParameterValue>getParamValueList(String parmtypecode)throws DAOException{
	String queryPpmParamValue = "From PpmParameterValue where ppmParameterValue.parmtypecode=:parmtypecode";
	System.out.println("queryPpmParamValue=="+queryPpmParamValue);
	System.out.println("parmtypecode==="+parmtypecode);
	Query query=entityManager.createQuery(queryPpmParamValue.toString());
	query.setParameter("parmtypecode", parmtypecode);
	List<PpmParameterValue> results= (List<PpmParameterValue>) query.getResultList();	
    
	System.out.println("results from ppmParamTypeJpa=="+results.size());
	return results;
	}
	public List<PpmParameterValue>deleteParamValueList(String typeCode,String groupCode,String value1)throws DAOException{
		String queryParamValue = "DELETE From PpmParameterValue where ppmParameterValue.parmtypecode="+"'"+typeCode+"'"+" AND ppmParameterValue.groupCode="+"'"+groupCode+"'"+" AND ppmParameterValue.value1="+"'"+value1+"'";
		entityManager.createQuery(queryParamValue.toString()).executeUpdate();	
		return null;
		}
	
	public PpmParameterType getPpmParamTypeList(String parmtypecode)throws DAOException{
		String queryExeRule = "From  PpmParameterType where parmtypecode="+"'"+parmtypecode+"'"+"";
		PpmParameterType results= (PpmParameterType) entityManager.createQuery(queryExeRule.toString()).getSingleResult();	
		return results;	
	}
	
	
}
