package com.bsf.ppm.dao.jpa;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.BackendErrorCodes;
import com.bsf.ppm.dao.BackendErrorCodeDAO;
import com.bsf.ppm.exceptions.DAOException;
/**
 * @author Zakir
 * Java Persistence API implementation for the BackendErrorCodeDAO.
 */
@Transactional
public class BackendErrorCodeJpaDAO extends PaginatedJpaDAO<BackendErrorCodes, Long> implements BackendErrorCodeDAO {

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(BackendErrorCodes entity) {
		// TODO Auto-generated method stub
		return false;
	}
	
	/**
	 * Fetch BackendErrorCdoes Entity with the Action Code
	 * @param code fts action code
	 * @return BackendErrorCode identified by fts action code passed
	 * @throws DAOException
	 */
	@Override
	public BackendErrorCodes getBackendErrorByActionCode(String code) throws DAOException	{
		
		Map<String, String> backendSearchCriteria = new HashMap<String, String>();
		backendSearchCriteria.put("code",code);
		List<BackendErrorCodes> backendErrorCodes = findByCriteria(backendSearchCriteria);
		if(backendErrorCodes.size() > 0 )
			return backendErrorCodes.get(0);
		else
			return null;
	}

}
