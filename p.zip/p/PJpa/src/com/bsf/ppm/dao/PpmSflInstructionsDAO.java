package com.bsf.ppm.dao;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.BatchJob;
import com.bsf.ppm.PpmSflInstructions;

/**
 * @author Ehsan
 * Data Access Object for BatchJob Entity. Extends PaginatedDAO
 */
public interface PpmSflInstructionsDAO extends PaginatedDAO<PpmSflInstructions, Long> {

}
