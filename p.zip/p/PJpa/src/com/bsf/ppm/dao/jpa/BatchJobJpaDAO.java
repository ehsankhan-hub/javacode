package com.bsf.ppm.dao.jpa;

import javax.persistence.Query;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.BatchJob;
import com.bsf.ppm.dao.BatchJobDAO;
import com.bsf.ppm.exceptions.DAOException;

/**
 * @author Zakir
 * Java Persistence API implementation for the BatchJobDAO.
 */
public class BatchJobJpaDAO extends PaginatedJpaDAO<BatchJob, Long> implements BatchJobDAO {

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(BatchJob entity) throws DAOException {
		long recordCount = -1;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
					.append(getPersistentClass().getSimpleName()).append(
							"  obj  where obj.id !=:id  and  obj.jobName=:jobName ");
			Query jpaQuery = entityManager.createQuery(query.toString());
			if(entity.getId() !=null)
			  jpaQuery.setParameter("id", entity.getId());
			else
				 jpaQuery.setParameter("id",Long.valueOf(-1));	
			jpaQuery.setParameter("jobName", entity.getJobName());
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}

		return recordCount <= 0;
	}

}
