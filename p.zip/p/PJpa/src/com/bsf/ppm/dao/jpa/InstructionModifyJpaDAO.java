package com.bsf.ppm.dao.jpa;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.LockModeType;
import javax.persistence.Query;

import org.jboss.cache.commands.read.GetDataMapCommand;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.controller.jsf.JSFUtil;
import com.bsf.ppm.dao.InstructionDetailDAO;
import com.bsf.ppm.dao.InstructionModifyDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.InstructionDetails;
import com.bsf.ppm.InstructionListValues;
import com.bsf.ppm.InstructionsModify;
import com.bsf.ppm.InstructionsModifyCompId;

public class InstructionModifyJpaDAO extends PaginatedJpaDAO<InstructionsModify, String> implements InstructionModifyDAO{
	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(InstructionsModify entity) {
		// TODO Auto-generated method stub
		return false;
	}
	
	/*  */
	@Override
	public Long getInstModifyIdSeqGen() throws DAOException {
		String sql = "SELECT PPM_MODIFY_REF.NEXTVAL FROM DUAL";
		
		try {
			// Execute native query and get the result list
			List results= entityManager.createNativeQuery(sql).getResultList();
			// Iterate the list and get the sequence value
			BigDecimal bd = (BigDecimal)results.iterator().next();
			System.out.println("Sequence Value="+bd);
			return bd.longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), sql);
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<InstructionListValues> getModifyValidateResults(String instReferenc,String ModifyReference)throws DAOException {
		
		List<InstructionListValues> listInstValu=new ArrayList<InstructionListValues>();
		InstructionListValues instVal =new InstructionListValues();
		List<Object[]>list=null;
		try {
		StringBuilder query=new StringBuilder();
		
		query.append("select inst.INST_REFERENCE,inst.ACT_NO,inst.TOTAL_AMOUNT,inst.STATUS,inst.FREQUENCY, instDtl.RELATED_REFERENCE,inst.INST_AMOUNT,inst.START_DATE_H,inst.END_DATE_H,inst.START_DATE_G,inst.END_DATE_G,instDtl.BEN_BANK,instDtl.BEN_ACT,instMod.MODIFY_REF,instMod.Is_Applied, instMod.RELATED_REFERENCE_OLD,instMod.RELATED_REFERENCE_NEW,instMod.DOC_DATE_OLD,instMod.DOC_DATE_NEW,instMod.DOC_RCV_DATE_OLD,instMod.DOC_RCV_DATE_NEW,instMod.RELATED_DOC_OLD,instMod.RELATED_DOC_NEW,instMod.STATUS_OLD,instMod.STATUS_NEW,inst.NO_OF_SUCS_INST,inst.PAID_AMOUNT,instDtl.INST_DTL_ID,inst.INST_ACTION_TYPE,inst.NO_OF_INST,inst.DAY_OF_PAYMENT,inst.INST_CALENDAR,instDtl.BEN_NAME,instDtl.BEN_ADDRESS,instDtl.BEN_BANK_ADD1,instDtl.PAY_DETAILS,inst.INITIATOR_COMMENT from "+ 
		"ppm_instructions inst,PPM_INSTRUCTIONS_DETAILS instDtl,(SELECT modify_ref,Inst_Reference,INST_DTL_ID,IS_APPLIED,"+
		    "MAX(DECODE(FIELD_NAME, 'RELATED_REFERENCE', old_value)) AS RELATED_REFERENCE_OLD,"+
		    "MAX(DECODE(FIELD_NAME, 'RELATED_REFERENCE', new_value)) AS RELATED_REFERENCE_NEW,"+
		    "MAX(DECODE(FIELD_NAME, 'DOC_DATE', old_value)) AS DOC_DATE_OLD ,"+
		    "MAX(DECODE(FIELD_NAME, 'DOC_DATE', new_value)) AS DOC_DATE_NEW ,"+
		    "MAX(DECODE(FIELD_NAME, 'DOC_RCV_DATE', old_value)) AS DOC_RCV_DATE_OLD,"+
		    "MAX(DECODE(FIELD_NAME, 'DOC_RCV_DATE', NEW_value)) AS DOC_RCV_DATE_NEW,"+
		    "MAX(DECODE(FIELD_NAME, 'RELATED_DOC', old_value)) AS RELATED_DOC_OLD,"+
		    "MAX(DECODE(FIELD_NAME, 'RELATED_DOC', NEW_value)) AS RELATED_DOC_NEW, "+ 
		    "MAX(DECODE(FIELD_NAME, 'STATUS', old_value)) AS STATUS_OLD ,"+
		    "MAX(DECODE(FIELD_NAME, 'STATUS', new_value)) AS STATUS_NEW "+
		     "FROM ppm_instructions_modify "+
		"GROUP BY modify_ref,Inst_Reference,INST_DTL_ID,IS_APPLIED) instMod "+
		"WHERE inst.INST_REFERENCE=instDtl.Inst_Reference "+
		"and inst.inst_reference=instMod.Inst_Reference "+
		"and instDtl.Inst_Dtl_Id=instMod.Inst_Dtl_Id "+
		"and instMod.Is_Applied='N' ");
		
		
		
		//query.append("SELECT inst.INST_REFERENCE,inst.ACT_NO,inst.TOTAL_AMOUNT,inst.STATUS,inst.FREQUENCY, instDtl.RELATED_REFERENCE,inst.INST_AMOUNT,inst.START_DATE_H,inst.END_DATE_H,inst.START_DATE_G,inst.END_DATE_G,instDtl.BEN_BANK,instDtl.BEN_ACT,instMod.MODIFY_REF FROM PPM_INSTRUCTIONS inst ,PPM_INSTRUCTIONS_DETAILS instDtl,PPM_INSTRUCTIONS_MODIFY instMod WHERE inst.INST_REFERENCE=instDtl.INST_REFERENCE AND inst.STATUS='NEW' ");
		
		if(!"".equals(ModifyReference)&&ModifyReference!=null){
			list=null;
			query.append("AND ");
			query.append("instMod.modify_ref=");
			query.append("'"+ModifyReference+"'");
			
			   
		}
		if(instReferenc!=""&&instReferenc!=null){
		list=null;
		query.append("AND ");
		query.append("inst.INST_REFERENCE= ");
		query.append("'"+instReferenc+"'");
		
		
		}
		
		list=(List<Object[]>) entityManager.createNativeQuery(query.toString()).getResultList();
			
		for (int i = 0; i < list.size(); i++) {
			Object[] obj = list.get(i);
	    	String instReference=(String)obj[0];
	    	String accNumber=(String)obj[1];
	    	BigDecimal totalAmont=(BigDecimal)obj[2];
	    	String status=(String)obj[3];
	    	String frequency=(String)obj[4];
	        String samaReferencevalue=(String)obj[5];
	        BigDecimal instAmount=(BigDecimal)obj[6];
	        String startDateH=(String)obj[7];
	        String endDateH=(String)obj[8];
	        Date startDateG=(Date)obj[9];
	        Date endDateG=(Date)obj[10];
	        String bankName=(String)obj[11];
	        String benAcc=(String)obj[12];
	        BigDecimal modifyRef=(BigDecimal)obj[13];
	        //String isApplied=(String)obj[14];
	        String relatedRefOld=(String)obj[15];
	        String relatedRefNew=(String)obj[16];
	        String docDateOld=(String)obj[17];
	        String docDateNew=(String)obj[18];
	        String docDateRecOld=(String)obj[19];
	        String docDateRecNew=(String)obj[20];
	        String relatedDocOld=(String)obj[21];
	        String relatedDocNew=(String)obj[22];
	        String fieldOldStatus=(String)obj[23];
	        String fieldNewStatus=(String)obj[24];
	        BigDecimal numOfSucsInst=(BigDecimal)obj[25];
	        BigDecimal paidAmnt=(BigDecimal)obj[26];
	        BigDecimal instDtlId=(BigDecimal)obj[27];
	        String tnsType=(String)obj[28];
	        BigDecimal noOfInst=(BigDecimal)obj[29];
	        String dayOfPayment=(String)obj[30];
	        String calendarType=(String)obj[31];
	        String benName=(String)obj[33];
	        String benAddress=(String)obj[33];
	        String benBankAddrdss1=(String)obj[34];
	        String payDtls=(String)obj[35];
	        String initiatorComment=(String)obj[36];
	        System.out.println("paidAmnt="+paidAmnt);
	        if(instReference!=(null)){
	    	instVal.setInstReference(instReference);
	        }
	        if(accNumber!=(null)){
	        instVal.setAccNumber(accNumber);
	        }
	        if(totalAmont!=(null)){
	        instVal.setTotalAmount(totalAmont.doubleValue());
	        }
	        instVal.setStatus(status);
	        if(frequency!=null){
	        instVal.setFrequency(frequency);
	        }
	        
	        instVal.setSamaReference(samaReferencevalue);
	        if(instAmount!=null) {
	        instVal.setInstAmount(instAmount);
	        }
	        if(startDateH!=null){
	        	instVal.setStartDateH(startDateH);
	        }
	        if(endDateH!=null){
	        	instVal.setEndDateH(endDateH);
	        
	        }
	        if(startDateG!=null){
	        	instVal.setStartDateG(startDateG);
	        }
	        if(endDateG!=null){
	        	instVal.setEndDateG(endDateG);
	        }
	        if(bankName!=null){
	        	instVal.setBakName(bankName);
	        }
	        if(benAcc!=null){
	        	instVal.setBenAcc(benAcc);
	        }
	        if(modifyRef!=null){
	        	instVal.setModifyRef(modifyRef.longValue());
	        }
	      /*  if(isApplied!=null){
	            instVal.setIsApplied(isApplied);
	        }*/
	        
	        if(relatedRefOld!=null){
	        	instVal.setRelatedRefOld(relatedRefOld);
	        }
	        if(relatedRefNew!=null){
	        	instVal.setRelatedRefNew(relatedRefNew);
	        }
	        if(docDateOld!=null){
	        	instVal.setDocDateOld(docDateOld);
	        }
	        if(docDateNew!=null){
	        	instVal.setDocDateNew(docDateNew);
	        }
	        if(docDateRecOld!=null){
	        	instVal.setDocDateRecOld(docDateRecOld);
	        }
	        if(docDateRecNew!=null){
	        	instVal.setDocDateRecNew(docDateRecNew);
	        }
	        if(relatedDocOld!=null){
	        	instVal.setRelatedDocOld(relatedDocOld);
	        }
	        if(relatedDocNew!=null){
	        	instVal.setRelatedDocNew(relatedDocNew);
	        }
	        if(fieldOldStatus!=null){
		        instVal.setFieldName(fieldOldStatus);
		        }
	        if(fieldNewStatus!=null){
	        instVal.setFieldName(fieldNewStatus);
	        }
	        if(numOfSucsInst!=null){
		        instVal.setNoOfSucsInst(numOfSucsInst.intValue());
		    }
		    if(paidAmnt!=null){
		        instVal.setPaidAmount(paidAmnt.doubleValue());
		    }
		    instVal.setInstDtlId(instDtlId.longValue());
		    if(tnsType!=null){
		        instVal.setTnsType(tnsType);
		        }
		        if(noOfInst!=null){
		        	instVal.setNoOfInst(noOfInst.intValue());
		        }
		        if(dayOfPayment!=null){
		        	instVal.setDayOfPayment(dayOfPayment);	
		        }
		        if(calendarType!=null){
		        instVal.setCalenderType(calendarType);
		        }
		        if(benName!=null||!"".equals(benName)){
		        	instVal.setBenName(benName);
		        }
		        if(benAddress!=null||!"".equals(benAddress)){
		        	instVal.setBenAddress(benAddress);
		        }
		        if(benBankAddrdss1!=null||!"".equals(benBankAddrdss1)){
		        	instVal.setBenBankAddrs1(benBankAddrdss1);
		        }
		        if(payDtls!=null||!"".equals(payDtls)){
		        	instVal.setPayDtls(payDtls);
		        }
		        if(initiatorComment!=null||!"".equals(initiatorComment)){
		        	instVal.setInitComment(initiatorComment);
		        }
	        listInstValu.add(instVal); 	
	        instVal = new InstructionListValues();
	    }
			
		
		}
		catch (Exception ex) {
		ex.printStackTrace();	
		}
		
		return listInstValu;
	}
	
	
	public int saveInstModify(InstructionsModify instModify)throws DAOException {
	Long modifyId=instModify.getId();
	Long instDtlId=instModify.getInstDtlId();
	String instRef=instModify.getInstRefer();
	String approvedBy= "";//instModify.getApprovedBy();
	//Date approvedDate=instModify.getApprovedDate();
	String modifiedBy=instModify.getModifiedBy();
	String isApplied=instModify.getIsApplied();
	System.out.println("isApplied"+isApplied);
	String oldValue=instModify.getOldValue();
	String newValue=instModify.getNewVlaue();
	String fieldName=instModify.getFieldName();
	String query="INSERT INTO PPM_INSTRUCTIONS_MODIFY(MODIFY_REF,INST_DTL_ID,INST_REFERENCE,APPROVED_BY,APPROVED_DATE,MODIFIED_BY,MODIFIED_DATE,IS_APPLIED,OLD_VALUE,NEW_VALUE,FIELD_NAME)VALUES("+modifyId+","+instDtlId+","+instRef+","+"'"+approvedBy+"'"+","+"sysdate"+","+"'"+modifiedBy+"'"+","+"sysdate"+","+"'"+isApplied+"'"+","+"'"+oldValue+"'"+","+"'"+newValue+"'"+","+"'"+fieldName+"'"+")";
	Query que=entityManager.createNativeQuery(query);
	int insert=que.executeUpdate();
	return insert;
	}
	 /*In case of Acept */
	public InstructionsModify updateInstModify(InstructionListValues itemItemDtl,String btnTyp)throws DAOException {
		//Long instRef=itemItemDtl.getInstReference();
		String fieldName="";
		System.out.println("btnTyp======="+btnTyp);
		InstructionsModify instructionsModify=new InstructionsModify();
		//String query="SELECT FIELD_NAME FROM PPM_INSTRUCTIONS_MODIFY WHERE INST_REFERENCE="+instRef+"";
		String query="FROM InstructionsModify WHERE id="+itemItemDtl.getModifyRef()+"";
		List <InstructionsModify> updInstMo=(List<InstructionsModify>)entityManager.createQuery(query).getResultList();
	    for(InstructionsModify  instmod:updInstMo){
		fieldName=	instmod.getFieldName();	
		Date modifDate=instmod.getModifiedDate();
		Date approvedDate=instmod.getApprovedDate();
		instructionsModify.setApprovedDate(approvedDate);
		instructionsModify.setModifiedDate(modifDate);
		System.out.println("fieldName=="+fieldName);	
	    }
		
		int insert=0;
		//if("STATUS".equals(fieldName)){
		System.out.println("fieldName---"+fieldName);	
		StringBuilder updateInstModify=new StringBuilder();
		updateInstModify.append("UPDATE PPM_INSTRUCTIONS_MODIFY SET IS_APPLIED='Y' ");
		updateInstModify.append(",APPROVED_BY=");
		updateInstModify.append("'"+JSFUtil.getLoggedInUserInfo().getUserId()+"'");
		updateInstModify.append(",APPROVED_DATE=");
		updateInstModify.append("sysdate");
		updateInstModify.append(" WHERE MODIFY_REF="+"'"+itemItemDtl.getModifyRef()+"'");
		Query updInstModfy=entityManager.createNativeQuery(updateInstModify.toString());
		insert=updInstModfy.executeUpdate();
		StringBuilder queryUpdateInst=new StringBuilder();
		queryUpdateInst.append("UPDATE PPM_INSTRUCTIONS SET STATUS =");
		queryUpdateInst.append("'SUS'");
		queryUpdateInst.append(" WHERE INST_REFERENCE="+"'"+itemItemDtl.getInstReference()+"'");
		Query updInstModfyInst=entityManager.createNativeQuery(queryUpdateInst.toString());
		insert=updInstModfyInst.executeUpdate();
		System.out.println("InstructionModify table updated number of rows"+insert);
		//}
		//else{
		Long modifyRef=itemItemDtl.getModifyRef();
		String instRef=itemItemDtl.getInstReference();
		Long instDtlId=itemItemDtl.getInstDtlId();
		InstructionListValues updateInstDtl=new InstructionListValues(); 
		String relatRefNew=  itemItemDtl.getRelatedRefNew();
		String docDate=itemItemDtl.getDocDateNew();
		String docDateRecNew=itemItemDtl.getDocDateRecNew();
		String relatDocNew=itemItemDtl.getRelatedDocNew();
		System.out.println("docDateRecNew=="+docDateRecNew);
		System.out.println("relatDocNew="+relatDocNew);
		System.out.println("relatRefNew="+relatRefNew);
		System.out.println("docDateNew="+docDate);
		
		 String docDateNew=docDate;
		  System.out.println("docDate==="+docDate);
		  String year="";
		  String month="";
		  String days="";
		  if(docDate!=null&&!"".equals(docDate)){
		  year=  docDate.substring(0, 4); 
		  month=docDate.substring(4, 6);
		  days=docDate.substring(6, 8);
		  }
		  docDate=year+month+days;
		  docDateNew=docDate;
		  
		
		System.out.println("instRef=="+instRef+"");
		
		
		
		
		
		if((relatRefNew!=null&&!"".equals(relatRefNew))){
		StringBuilder queryUpdate=new StringBuilder();
		queryUpdate.append("UPDATE PPM_INSTRUCTIONS_DETAILS SET RELATED_REFERENCE =	");
		queryUpdate.append("'"+relatRefNew+"'");
		queryUpdate.append(" WHERE INST_REFERENCE="+"'"+instRef+"'");
		Query que=entityManager.createNativeQuery(queryUpdate.toString());
		que.executeUpdate();
		}
	    if((docDateNew!=null&&!"".equals(docDateNew))){
			StringBuilder queryUpdate=new StringBuilder();
			queryUpdate.append("UPDATE PPM_INSTRUCTIONS_DETAILS SET DOC_DATE= ");
			queryUpdate.append("'"+docDateNew+"'");
			queryUpdate.append(" WHERE INST_REFERENCE="+"'"+instRef+"'");
			Query que=entityManager.createNativeQuery(queryUpdate.toString());
			que.executeUpdate();	
		}
	   if((docDateRecNew!=null&&!"".equals(docDateRecNew))){
			StringBuilder queryUpdate=new StringBuilder();
			queryUpdate.append("UPDATE PPM_INSTRUCTIONS_DETAILS SET DOC_RCV_DATE= ");
			queryUpdate.append("'"+docDateRecNew+"'");
			queryUpdate.append(" WHERE INST_REFERENCE="+"'"+instRef+"'");
			Query que=entityManager.createNativeQuery(queryUpdate.toString());
			que.executeUpdate();	
		}
		if((relatDocNew!=null&&!"".equals(relatDocNew))){
			StringBuilder queryUpdate=new StringBuilder();
			queryUpdate.append("UPDATE PPM_INSTRUCTIONS_DETAILS SET RELATED_DOC= ");
			queryUpdate.append("'"+relatDocNew+"'");
			queryUpdate.append(" WHERE INST_REFERENCE="+"'"+instRef+"'");
			Query que=entityManager.createNativeQuery(queryUpdate.toString());
			que.executeUpdate();	
		}
	
		return instructionsModify;
		
		}
	    /*In case of Reject */
	    public int rejectInstModify(InstructionListValues itemItemDtl)throws DAOException {
	    	
	    Long modifyRef=itemItemDtl.getModifyRef();
	    String instRef=itemItemDtl.getInstReference();
	    /*StringBuilder queryUpdateInst=new StringBuilder();
		queryUpdateInst.append("UPDATE Ppm_Instructions SET status ='ACT' ");
		queryUpdateInst.append(" WHERE instReference="+"'"+instRef+"'");
		Query updInstModfyInst=entityManager.createQuery(queryUpdateInst.toString());
		int updModf=updInstModfyInst.executeUpdate();
		System.out.println("Instruction table updated status="+updModf);*/
	    StringBuilder updateInstModify=new StringBuilder();
		updateInstModify.append("UPDATE PPM_INSTRUCTIONS_MODIFY SET IS_APPLIED ='R' ");
		updateInstModify.append(",APPROVED_BY=");
		updateInstModify.append("'"+JSFUtil.getLoggedInUserInfo().getUserId()+"'");
		updateInstModify.append(",APPROVED_DATE=");
		updateInstModify.append("sysdate");
		updateInstModify.append(" WHERE MODIFY_REF="+"'"+modifyRef+"'");
		Query updInstModfy=entityManager.createNativeQuery(updateInstModify.toString());
		int insert=updInstModfy.executeUpdate();
		System.out.println("InstructionModify table updated number of rows"+insert);
		return insert;
	    }
	    
	    
}
