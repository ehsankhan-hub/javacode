package com.bsf.ppm.dao;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.PaginatedDAO;

public interface UserDAO extends PaginatedDAO<UserInfo, String> {

}
