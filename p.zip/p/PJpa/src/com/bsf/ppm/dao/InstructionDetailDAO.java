package com.bsf.ppm.dao;

import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.InstructionDetails;
public interface InstructionDetailDAO extends PaginatedDAO<InstructionDetails, String> {
	
	public InstructionDetails getInstructionDetails(Long ref) throws DAOException;
	public InstructionDetails getInstructionDtlByDtlId(Long dtlId) throws DAOException;
	
	
}
