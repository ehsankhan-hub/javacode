package com.bsf.ppm.dao.jpa;

import javax.persistence.Query;

import com.bsf.ipp.GeneralConfigParameter;
import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.dao.GeneralConfigParameterDAO;
import com.bsf.ppm.exceptions.DAOException;

public class GeneralConfigParameterJpaDAO extends PaginatedJpaDAO<GeneralConfigParameter, Long> implements GeneralConfigParameterDAO {

	@Override
	public boolean isUnique(GeneralConfigParameter entity) throws DAOException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getByGeneralConfigParameterName(String paramName) throws DAOException {
		
		String paramValue;
		GeneralConfigParameter generalConfigParameter = null;
		
		try{

			StringBuffer query = new StringBuffer("Select obj from ")
					.append(getPersistentClass().getSimpleName()).append(
							"  obj  where obj.paramName=:paramName ");
			Query jpaQuery = entityManager.createQuery(query.toString());
			jpaQuery.setParameter("paramName", paramName);
			
			generalConfigParameter = (GeneralConfigParameter) jpaQuery.getSingleResult();
			paramValue = generalConfigParameter.getParamValue();
		
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}		
		
		return paramValue;	
	}
}
