package com.bsf.ppm.dao.jpa;
import javax.persistence.Query;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.PpmExeRulesCriteria;
import com.bsf.ppm.dao.PpmExecutionRuleCritDAO;
import com.bsf.ppm.exceptions.DAOException;

public class PpmExecutionRuleCritJpaDAO extends PaginatedJpaDAO<PpmExeRulesCriteria, String>  implements PpmExecutionRuleCritDAO{
	@Override
	public boolean isUnique(PpmExeRulesCriteria entity) throws DAOException {
		long recordCount = -1;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
					.append(getPersistentClass().getSimpleName()).append(
							"  obj  where obj.exeRuleName=:exeRuleName ");
			Query jpaQuery = entityManager.createQuery(query.toString());
			jpaQuery.setParameter("exeRuleName", entity.getPpmExeRulesCriteriaPK().getExeRuleName());
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
			
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()
					.getName());
		}
        
		return recordCount <= 0;
	}
    
	@Override
	public boolean isUniqueJoinTable(PpmExeRulesCriteria entity) throws DAOException {
		long recordCount = -1;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
					.append("com.bsf.ppm.PpmExeRulesCriteria").append(
							"  obj  where obj.exeRuleName=:exeRuleName and obj.fieldName=:fieldName and obj.value1=:value1");
			Query jpaQuery = entityManager.createQuery(query.toString());
			jpaQuery.setParameter("exeRuleName", entity.getPpmExeRulesCriteriaPK().getExeRuleName());
			jpaQuery.setParameter("fieldName", entity.getPpmExeRulesCriteriaPK().getFieldName());
			jpaQuery.setParameter("value1", entity.getPpmExeRulesCriteriaPK().getValue1());
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
			
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass()					.getName());
		}
        
		return recordCount <= 0;
	}
	
}
