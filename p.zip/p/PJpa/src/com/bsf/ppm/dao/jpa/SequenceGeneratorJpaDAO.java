package com.bsf.ppm.dao.jpa;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.persistence.EntityManager;
import org.apache.log4j.Logger;

import com.bsf.ppm.dao.SequenceGeneratorDAO;
import com.bsf.ppm.exceptions.DAOException;

/**
 * @author Zakir
 * Java Persistence API implementation for the SequenceGeneratorDAO.
 */
@SuppressWarnings("serial")
public class SequenceGeneratorJpaDAO  implements SequenceGeneratorDAO {

	/** Logger for SequenceGeneratorJpaDAO */
	private static Logger log = Logger.getLogger(SequenceGeneratorJpaDAO.class);
	private EntityManager entityManager;

	private org.hibernate.SessionFactory sessionFactory;
	/**
	 * @param entityManager the entityManager to set
	 */
//	@PersistenceContext
//	public void setEntityManager(EntityManager entityManager) {
//		this.entityManager = entityManager;
//	}

	/**
	 * @param <p>messageNumber message for which 
	 * the next value is retrieved from the DB sequence</p>
	 * @return Long  - next value of the sequence fetched from DB
	 * @throws DAOException
	 */
	@Override
	public Long getnextValueForMessage(String messageNumber)
			throws DAOException {
		
		
		return getnextValueForSequence(new StringBuilder("SEQ_SWIFT_MESSAGE_MT_").append(messageNumber).toString());
	}

	/**
	 * Fetch the nextValue from DB Sequence.
	 * @param sequenceName name of the DB sequence
	 * @return the Long - next value of the sequence
	 * @throws DAOException
	 */
	@SuppressWarnings("deprecation")
	@Override
	public Long getnextValueForSequence(String sequenceName)
			throws DAOException {
		Long nextValue = -1L;
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			
			//EntityManager entityManager = getJpaTemplate().getEntityManager();
			
			//EntityTransaction  entityTransaction  = entityManager.getTransaction();
			
//			if (entityManager != null) 
//				nextValue = ((Long)entityManager.createNativeQuery(
//						"select "+sequenceName+".NEXTVAL from dual").getSingleResult()).longValue();
			con = sessionFactory.getCurrentSession().connection();

			stmt  = con.createStatement();
			rs = stmt.executeQuery("select "+sequenceName+".NEXTVAL as SEQ_NEXT_VALUE from dual");
			rs.next();
			nextValue = rs.getLong("SEQ_NEXT_VALUE");

		} catch(SQLException e) {
			log.error("Could not fetch the sequence nextValue for "+sequenceName);
		}
		finally {
			try {
				rs.close();
				stmt.close();
				con.close();				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				log.error(e.getMessage());
			}

		}
		
		return nextValue;
	}


}
