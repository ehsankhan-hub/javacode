package com.bsf.ppm.dao.jpa;

import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.BatchJobHistory;
import com.bsf.ppm.dao.BatchJobHistoryDAO;
/**
 * @author Zakir
 * Java Persistence API implementation for the BatchJobHistoryDAO.
 */
@Transactional
public class BatchJobHistoryJpaDAO extends PaginatedJpaDAO<BatchJobHistory, Long> implements BatchJobHistoryDAO {

	/* (non-Javadoc)
	 * @see com.bsf.ipp.dao.jpa.AbstractJpaDAO#isUnique(java.lang.Object)
	 */
	@Override
	public boolean isUnique(BatchJobHistory entity) {
		// TODO Auto-generated method stub
		return false;
	}

}
