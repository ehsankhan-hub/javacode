package com.bsf.ppm.dao.jpa;

import javax.persistence.Query;

import com.bsf.ipp.dao.jpa.PaginatedJpaDAO;
import com.bsf.ppm.GroupPrivileges;
import com.bsf.ppm.dao.GroupPrivilegesDAO;
import com.bsf.ppm.exceptions.DAOException;

public class GroupPrivilegesJpaDAO extends PaginatedJpaDAO<GroupPrivileges, Long> implements GroupPrivilegesDAO {

	@Override
	public boolean isUnique(GroupPrivileges entity) throws DAOException {
		long recordCount = -1;
		try {
			StringBuffer query = new StringBuffer("Select count(obj) AS RECCOUNT from ")
					.append(getPersistentClass().getSimpleName()).append(
							"  obj  where obj.id !=:id  and  obj.userGroup.id=:usergroup and obj.businessObject.id=:busobj ");
			Query jpaQuery = entityManager.createQuery(query.toString());
			if(entity.getId() !=null)	{
			  jpaQuery.setParameter("id", entity.getId());
			}
			else	{
				jpaQuery.setParameter("id",Long.valueOf(-1));
			}
			jpaQuery.setParameter("usergroup",entity.getUserGroup().getId() );
			jpaQuery.setParameter("busobj",entity.getBusinessObject().getId() );
			recordCount = ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.checkUnique.entity", ex, getPersistentClass().getName());
		}
		return recordCount <= 0;
	}

	

}
