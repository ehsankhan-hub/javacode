package com.bsf.ppm.job;

import net.sf.ehcache.Cache;

import com.bsf.ppm.dao.BatchJobHistoryDAO;

public class GlobalJobListener extends AbstractJobListener {
	
	private BatchJobHistoryDAO batchJobHistoryDAO;
	
	private Cache generalConfigurationCache;
	
	public Cache getGeneralConfigurationCache() {
		return generalConfigurationCache;
	}

	public void setGeneralConfigurationCache(Cache generalConfigurationCache) {
		this.generalConfigurationCache = generalConfigurationCache;
	}

	/**
	 * @return the batchJobHistoryDAO
	 */
	public BatchJobHistoryDAO getBatchJobHistoryDAO() {
		return batchJobHistoryDAO;
	}

	/**
	 * @param batchJobHistoryDAO the batchJobHistoryDAO to set
	 */
	public void setBatchJobHistoryDAO(BatchJobHistoryDAO batchJobHistoryDAO) {
		this.batchJobHistoryDAO = batchJobHistoryDAO;
	}

	@Override
	public String getName() {
		return "IppGlobalJobListener";
	}
	
}
