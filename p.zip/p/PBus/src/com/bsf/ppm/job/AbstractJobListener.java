package com.bsf.ppm.job;

import java.sql.Timestamp;
import java.util.Calendar;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

import org.apache.log4j.Logger;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobListener;

import com.bsf.ipp.GeneralConfiguration;
import com.bsf.ppm.BatchJobHistory;
import com.bsf.ppm.batch.handler.JobHandler;
import com.bsf.ppm.dao.BatchJobHistoryDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.jpa.util.BackendUtil;

public abstract class AbstractJobListener implements JobListener {

	/* Attribute startTime to track Job Start Time */
	private long startTime;

	/** Attribute log - Logger for AbstractJobListener */
	private static final Logger log = Logger
	.getLogger(AbstractJobListener.class);
	
	/**
	 * @return the batchJobHistoryDAO
	 */
	public abstract BatchJobHistoryDAO getBatchJobHistoryDAO();
	
	public abstract Cache getGeneralConfigurationCache();

	/**
	 * @param batchJobHistoryDAO the batchJobHistoryDAO to set
	 * @return 
	 */
	public abstract void setBatchJobHistoryDAO(BatchJobHistoryDAO batchJobHistoryDAO); 

	/* (non-Javadoc)
	 * @see org.quartz.JobListener#getName()
	 */
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.quartz.JobListener#jobExecutionVetoed(org.quartz.JobExecutionContext)
	 */
	@Override
	public void jobExecutionVetoed(JobExecutionContext executionContext) {
		//Do Nothing
	}
	


	/* (non-Javadoc)
	 * @see org.quartz.JobListener#jobToBeExecuted(org.quartz.JobExecutionContext)
	 */
	@Override
	public void jobToBeExecuted(JobExecutionContext executionContext) {
		this.startTime=Calendar.getInstance().getTimeInMillis();
	}

	/* (non-Javadoc)
	 * @see org.quartz.JobListener#jobWasExecuted(org.quartz.JobExecutionContext, org.quartz.JobExecutionException)
	 */
	@Override
	public void jobWasExecuted(JobExecutionContext executionContext,
			JobExecutionException executionException) {
		try {
			
			GeneralConfiguration generalConfiguration =  getGeneralConfigByName("COREGeneralConfiguration");
			if(generalConfiguration !=null)	{
				
				String logbJobHistoryToDB = BackendUtil.getGeneralConfigParameterValue(generalConfiguration, "LogJobHistoryToDB");
				if(logbJobHistoryToDB !=null && logbJobHistoryToDB.equalsIgnoreCase("Y") )	{
					
					// Fetch JobDetail
					JobDetail jobDetail = executionContext.getJobDetail();
					//Fetch Job Handler
					JobHandler jobHandler = (JobHandler)jobDetail.getJobDataMap().get("jobHandler");
					System.out.println("jobHandler==="+jobHandler);
					//Add batchJobHistory information
					BatchJobHistory batchJobHistory = new BatchJobHistory();
					batchJobHistory.setStartTime(new Timestamp(startTime));
					batchJobHistory.setEndTime(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					batchJobHistory.setJobName(jobDetail.getName());
					batchJobHistory.setHandler(jobHandler.getClass().getSimpleName());
					batchJobHistory.setSuccessfulProcessedRecords(jobHandler.getSuccessfullItems());
					batchJobHistory.setUnsuccessfulProcessedRecords(jobHandler.getFailedItems());
					//Insert batchJobHistory
					getBatchJobHistoryDAO().save(batchJobHistory);
				}else	{
					
					log.debug("Not Logging Job History to Database");
				}
			}
		} catch (DAOException e) {
			log.warn("Entry to BATCH_JOB_HISTORY failed. "+e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			log.warn("Entry to BATCH_JOB_HISTORY failed. "+e.getMessage());
		}
	
	}
	
	private GeneralConfiguration getGeneralConfigByName(String configName) {
		
		Element elem = getGeneralConfigurationCache().get(configName);
		if (elem != null) {
			
			return (GeneralConfiguration) elem.getObjectValue();
		}
		return null;
	}
}
