/**
 * 
 */
package com.bsf.ppm.cache;

import java.util.ArrayList;
import java.util.List;
import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.bsf.ipp.dao.Cacheable;

/**
 * Implementation for cache Manager
 * 
 * @author Rakesh
 * 
 */
public class StaticDataCacheManager implements CacheManager,
		ApplicationContextAware {

	private List<String> cacheDefinitions = new ArrayList<String>();
	private ApplicationContext applicationContext;

	public List<String> getCacheDefinitions() {
		return cacheDefinitions;
	}

	public void setCacheDefinitions(List<String> cacheDefinitions) {
		this.cacheDefinitions = cacheDefinitions;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.cache.CacheManager#clear()
	 */
	@Override
	public void clear() {
		for (String cacheName : cacheDefinitions) {
			Cache staticDataCache = (Cache) applicationContext
					.getBean(cacheName);
			staticDataCache.removeAll();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.cache.CacheManager#refreshAll()
	 */
	@Override
	public void refreshAll() {
		for (String cacheName : cacheDefinitions) {
			ICacheQuery<Cacheable> cacheQuery = (ICacheQuery<Cacheable>) applicationContext
					.getBean(cacheName + "Query");
			List<Cacheable> cachedData = cacheQuery.findData();
			Cache staticDataCache = (Cache) applicationContext
					.getBean(cacheName);
			if (cachedData != null) {
				for (Cacheable cacheable : cachedData) {
					staticDataCache.put(new Element(cacheable.getKey(),
							cacheable));
				}
			}

		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.cache.CacheManager#refreshCache(java.lang.String)
	 */
	@Override
	public void refreshCache(String cacheName) throws Exception {
		Cache staticDataCache = (Cache) applicationContext.getBean(cacheName);
		staticDataCache.removeAll();
		ICacheQuery<Cacheable> cacheQuery = (ICacheQuery<Cacheable>) applicationContext
				.getBean(cacheName + "Query");
		List<Cacheable> cachedData = cacheQuery.findData();
		for (Cacheable cacheable : cachedData) {
			staticDataCache.put(new Element(cacheable.getKey(), cacheable));
		}
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		this.applicationContext = applicationContext;
	}

}
