package com.bsf.ppm.cache;
import java.util.List;

import com.bsf.ppm.BackendErrorCodes;
import com.bsf.ppm.dao.BackendErrorCodeDAO;
import com.bsf.ppm.exceptions.CacheLoadingException;

/**
 * */
public class BackendErrorCodesCacheQuery implements
		ICacheQuery<BackendErrorCodes> {
	private BackendErrorCodeDAO backendErrorCodeDAO;



	@Override
	public List<BackendErrorCodes> findData() {
		List<BackendErrorCodes> businessObjects ;
		try {
			businessObjects = backendErrorCodeDAO.findAll();
		} catch (Exception e) {
			throw new CacheLoadingException("error.load.backendErrorCodescache",e);
		}
		return businessObjects;
	}



	public void setBackendErrorCodeDAO(BackendErrorCodeDAO backendErrorCodeDAO) {
		this.backendErrorCodeDAO = backendErrorCodeDAO;
	}

}
