package com.bsf.ppm.cache;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bsf.ppm.BackendSystem;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.dao.BackendSystemDAO;
import com.bsf.ppm.exceptions.CacheLoadingException;

public class BackendSystemCacheQuery implements
		ICacheQuery<BackendSystem> {
	public BackendSystemDAO getBackendSystemDAO() {
		return backendSystemDAO;
	}

	public void setBackendSystemDAO(BackendSystemDAO backendSystemDAO) {
		this.backendSystemDAO = backendSystemDAO;
	}

	private BackendSystemDAO  backendSystemDAO;

	@Override
	public List<BackendSystem> findData() {
		List<BackendSystem> backendSystems ;
		try {
			Map<String, Object> searchCriteria =new HashMap<String, Object>();
			searchCriteria.put(IConstants.DEFAULT_STATUS_FIELD, Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
			backendSystems = backendSystemDAO.findByCriteria(searchCriteria);
		} catch (Exception e) {
			throw new CacheLoadingException("error.load.backencache",e);
		}
		return backendSystems;
	}

}
