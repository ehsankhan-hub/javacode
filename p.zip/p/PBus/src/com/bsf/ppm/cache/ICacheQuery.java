package com.bsf.ppm.cache;

import java.util.List;

public interface ICacheQuery<T> {

	public List<T> findData();
}
