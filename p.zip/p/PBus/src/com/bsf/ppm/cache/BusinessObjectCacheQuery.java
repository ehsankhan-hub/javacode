package com.bsf.ppm.cache;

import java.util.List;

import com.bsf.ppm.BusinessObject;
import com.bsf.ppm.dao.BusinessObjectDAO;
import com.bsf.ppm.exceptions.CacheLoadingException;

/**
 * */
public class BusinessObjectCacheQuery implements
		ICacheQuery<BusinessObject> {
	private BusinessObjectDAO busObjectDAO;

	public BusinessObjectDAO getBusObjectDAO() {
		return busObjectDAO;
	}


	public void setBusObjectDAO(BusinessObjectDAO busObjectDAO) {
		this.busObjectDAO = busObjectDAO;
	}

	@Override
	public List<BusinessObject> findData() {
		List<BusinessObject> businessObjects ;
		try {
			businessObjects = busObjectDAO.findAll();
		} catch (Exception e) {
			throw new CacheLoadingException("error.load.businessObjectcache",e);
		}
		return businessObjects;
	}

}
