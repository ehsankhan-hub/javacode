package com.bsf.ppm.cache;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bsf.ipp.GeneralConfiguration;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.dao.GeneralConfigurationDAO;
import com.bsf.ppm.exceptions.CacheLoadingException;

/**
 * */
public class GeneralConfigurationCacheQuery implements
		ICacheQuery<GeneralConfiguration> {
	private GeneralConfigurationDAO generalConfigurationDAO;

	public GeneralConfigurationDAO getGeneralConfigurationDAO() {
		return generalConfigurationDAO;
	}

	public void setGeneralConfigurationDAO(
			GeneralConfigurationDAO generalConfigurationDAO) {
		this.generalConfigurationDAO = generalConfigurationDAO;
	}

	@Override
	public List<GeneralConfiguration> findData() {
		List<GeneralConfiguration> generalConfigurations;
		try {
			Map<String, Object> searchCriteria =new HashMap<String, Object>();
			searchCriteria.put(IConstants.DEFAULT_STATUS_FIELD, Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
			generalConfigurations = generalConfigurationDAO.findByCriteria(searchCriteria);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CacheLoadingException("error.load.generalconfigurationcache",e);
		}
		return generalConfigurations;
	}

}
