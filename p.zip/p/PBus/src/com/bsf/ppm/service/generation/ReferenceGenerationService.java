package com.bsf.ppm.service.generation;

import java.math.BigDecimal;
import java.util.List;

import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.BusinessException;
import com.bsf.ppm.exceptions.DAOException;

/**
 * Interface for generating Transaction ReferenceNumber
 * @author Hussain
 *
 */
public interface ReferenceGenerationService {
	
	/**
	 * Generates Swift Transaction Reference for the messageNumber
	 * @param messageNumber to generate the TransactionReference. Like 103,202
	 * @return transactionReference for the corresponding message
	 * @throws DAOException 
	 * @throws BusinessException 
	 */
	public String swiftTransactionReferenceForMessage(String messageNumber, boolean returnPayment) throws DAOException, BusinessException ;
	/**
	 * Generates Swift Transaction Reference for the messageNumber
	 * @param messageNumber to generate the TransactionReference. Like 103,202
	 * @return transactionReference for the corresponding message
	 * @throws DAOException 
	 * @throws BusinessException 
	 */
	public String swiftTransactionReferenceForMessage(String messageNumber) throws DAOException, BusinessException ;
	
	/**
	 * Generates Fts Transaction Reference
	 * @return unique transactionReference for FTS request
	 * @throws BusinessException 
	 * @throws DAOException 
	 */
	public String fetchFtsTransactionReference() throws BusinessException, DAOException ;
	/**
	 * @return
	 * @throws DAOException
	 */
	public Long fetchCheckMessageSequenceNextValue() throws DAOException;
	
	/**
	 * @return
	 * @throws ApplicationException
	 */
	public String fetchMacTransactionReference() throws ApplicationException;
	/**
	 * @return
	 * @throws ApplicationException
	 */
	public String fetchB2BTransactionReference() throws ApplicationException;
	
	
	public String fetchCLNFtsTransactionReference() throws ApplicationException;
	
	public String fetchCLNUpdateReference() throws ApplicationException;
	
	
	public String fetchCLNOutUpdateReference() throws ApplicationException;
	
	public String fetchCLNScheduleNumber()throws ApplicationException;
	
	public String fetchCLNTScheduleNumber() throws ApplicationException;

	
}
