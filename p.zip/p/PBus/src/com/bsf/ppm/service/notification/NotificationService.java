package com.bsf.ppm.service.notification;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.bsf.ppm.MailAttachment;
import com.bsf.ppm.MailMessage;
import com.bsf.ppm.SmsMessage;
import com.bsf.ppm.exceptions.ServiceException;

/**
 * Interface for notifying users via mail or via SMS
 * @author Rakesh
 *
 */
public interface NotificationService {

	/**
	 * Sends mail notifications
	 * @param mailMessage
	 */
	public void notifyByMail(MailMessage mailMessage) throws ServiceException;
	
	/**
	 * Sends mail notifications from Predefined template. To, FROM,CC,
	 * BCC are stored as part of Template. This data is extracted from
	 * Mail_Template table and Mail message is created
	 * @param templateId
	 * @param valuesMap
	 * @throws ServiceException  
	 */
	public void notifyByMailTemplate(Long templateId, Map<String, Object> valuesMap) throws ServiceException ;
	
	public void notifyByMailTemplate(Long templateId, Map<String, Object> subjectValuesMap, Map<String, Object> valuesMap) throws ServiceException ;
	
	/**
	 * Sends mail notifications from Predefined template on specified date only. To, FROM,CC,
	 * BCC are stored as part of Template. This data is extracted from
	 * Mail_Template table and Mail message is created
	 * @param templateId
	 * @param valuesMap
	 * @param processingDate
	 * 
	 * @throws ServiceException  
	 */
	public void notifyByMailTemplate(Long templateId,Date processingDate, Map<String, Object> valuesMap) throws ServiceException ;
	
	/**
	 * Sends mail notifications from Predefined template. 
	 * 
	 * @param templateId
	 * @param valuesMap
	 * @param to
	 * @param cc
	 * @param bcc
	 * @throws ServiceException 
	 */
	public void notifyByMailTemplate(Long templateId, Map<String, Object> valuesMap,String to,String cc, String bcc) throws ServiceException ;
	
	public void notifyByMailTemplate(Long templateId, Map<String, Object> subjectValuesMap, Map<String, Object> valuesMap,String to,String cc, String bcc) throws ServiceException ;
	/**
	 * Sends mail notifications from Predefined template. To, FROM,CC,
	 * BCC are stored as part of Template. This data is extracted from
	 * Mail_Template table and Mail message is created with Attachments 
	 * @param templateId
	 * @param valuesMap
	 * @param mailAttachmentList
	 * @throws ServiceException
	 */
	public void notifyByMailTemplateWithAttachment(Long templateId,
			Map<String, Object> valuesMap,List<MailAttachment> mailAttachmentList) throws ServiceException;
	
	public void notifyByMailTemplateWithAttachment(Long templateId, Map<String, Object> subjectValuesMap,
			Map<String, Object> valuesMap,List<MailAttachment> mailAttachmentList) throws ServiceException;
		
	/**
	 * Sends SMS notifications
	 * @param smsMessage
	 */
	public void notifyBySMS(SmsMessage smsMessage) throws ServiceException;
	public void sendExceptionNotification(final String exceptionMessage,long templateId) throws ServiceException ;
	
	public void notifyByMailTemplateCC(Long templateId,
			Map<String, Object> valuesMap, String to, String cc, String bcc) throws ServiceException;

	public void notifyByMailTemplateCC(Long templateId,Map<String, Object> subjectValuesMap,
			Map<String, Object> valuesMap, String to, String cc, String bcc) throws ServiceException;
	
}
