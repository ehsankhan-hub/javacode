package com.bsf.ppm.service.posting;

import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.InCorrectDataException;
import com.bsf.ppm.formatting.exception.ParseException;
import com.bsf.ppm.formatting.format.FixedFormatManager;
import com.bsf.ppm.formatting.format.impl.FixedFormatManagerImpl;
import com.bsf.ppm.fts.AccountInquiryRequest;
import com.bsf.ppm.fts.AccountInquiryResponse;
import com.bsf.ppm.fts.FTSRequestPostingEntityMRKI;
import com.bsf.ppm.fts.FTSRequestPostingEntityAATR;
import com.bsf.ppm.fts.FTSRequestPostingEntityMRKM;
import com.bsf.ppm.fts.FTSRequestPostingEntityTTAC;
import com.bsf.ppm.fts.FTSResponsePostingEntity;
import com.bsf.ppm.fts.integration.FTSInterface;
import com.bsf.ppm.fts.integration.FTSInterfaceImpl;
import com.bsf.ppm.service.generation.ReferenceGenerationService;
import com.bsf.ppm.spring.SpringAppContext;

/**
 * Implementation class for {@link}FTSPostingService
 * @author Rakesh
 *
 */
@Transactional
public class FTSPostingServiceImpl implements FTSPostingService {

	/** Logger for FTSPostingServiceImpl */
	private static Logger log = Logger.getLogger(FTSPostingServiceImpl.class);

	/** Attribute ftsInterface - FTSInterface injected as Spring bean */
	private FTSInterface ftsInterface;

	/** Attribute fixedFormatManager -  FixedFormatManager to translate Objects to FTS string */
	private FixedFormatManager fixedFormatManager;

	/** Attribute referenceGenerationService - ReferenceGenerationService injected as Spring bean */
	private ReferenceGenerationService referenceGenerationService;

	/* (non-Javadoc)
	 * @see com.bsf.ppm.service.Service#getServiceName()
	 */
	@Override
	public String getServiceName() {
		return this.getClass().getName();
	}

	/** Fetches the FtsInterfaceImpl instance. 
	 * Object is created from Spring App Context.
	 * @return the ftsInterface
	 */
	public FTSInterface getFtsInterface() {
		ftsInterface = (FTSInterface) SpringAppContext.getBean("ftsInterface");
		return ftsInterface;
	}
   
		
	/**
	 * @param ftsInterface the ftsInterface to set
	 */
	public void setFtsInterface(FTSInterface ftsInterface) {
		this.ftsInterface = ftsInterface;
	}

	/**
	 * @return the referenceGenerationService
	 */
	public ReferenceGenerationService getReferenceGenerationService() {
		referenceGenerationService = (ReferenceGenerationService) SpringAppContext.getBean("referenceGenerationService");
		return referenceGenerationService;
	}

	/**
	 * @param referenceGenerationService the referenceGenerationService to set
	 */
	public void setReferenceGenerationService(
			ReferenceGenerationService referenceGenerationService) {
		this.referenceGenerationService = referenceGenerationService;
	}
	

	@Override
	public AccountInquiryResponse sendAccountInquiry(
			AccountInquiryRequest accountInquiryRequest, String applicationId)
			throws ApplicationException {

		AccountInquiryResponse accountInquiryResponse = null;
        System.out.println("accountInquiryRequest===="+accountInquiryRequest);
		//Create FixedFormatManager Instance
		fixedFormatManager = new FixedFormatManagerImpl();
		//log.info("FTS Reference for  ::::::::::::::::::::::::::::::" + accountInquiryRequest.getAccountNo());
		//log.info("FTS Reference for AccountInquiryRequest is ::::::::::::::::::::::::::::::" + accountInquiryRequest.getFTSReference() );
		//Export the accountInquiryRequest to text message
		//System.out.println("getFtsInterface()===="+getFtsInterface());
		String responseMessage = getFtsInterface().sendMessage(fixedFormatManager.export(accountInquiryRequest), applicationId, false);
		try{
			// If Account does'nt Exists Response is 160 chars length instead of 764.
			// Build accountInquiryResponse with CAMM,FTS action code, Fts Ref,Account number.
			// As fixedFormatManager generates Warnings
			if (responseMessage.length() == IConstants.FAILED_ACCOUNT_INQUIRY_REPONSE_LENGTH) {
				log.info("-cammActionCode ="+responseMessage.substring(128, 132)+ 
						",ftsActionCode ="+responseMessage.substring(149, 153)+
						",setFTSReference ="+responseMessage.substring(25, 35)+
						",setAccountNumber = "+responseMessage.substring(70, 90));
				
				//Built Empty accountInquiryResponse  with setFTSReference, setAccountNumber, cammActionCode,ftsActionCode
				accountInquiryResponse = new AccountInquiryResponse();
				accountInquiryResponse.setFTSReference(responseMessage.substring(25, 35));
				accountInquiryResponse.setAccountNumber(responseMessage.substring(70, 90));
				accountInquiryResponse.setCammActionCode(responseMessage.substring(128, 132));
				accountInquiryResponse.setFtsActionCode(responseMessage.substring(149, 153));
			}
			else {
			//format the response message as AccountInquiryResponse
			accountInquiryResponse = fixedFormatManager.load(AccountInquiryResponse.class, responseMessage);
			}
		}
		catch(ParseException e){
			throw new InCorrectDataException("error.invalid.data",e);
		}
		//return response object
		return accountInquiryResponse;
	}
	
	@Override
	public FTSResponsePostingEntity sendTransferRequest(FTSRequestPostingEntityMRKI fTSRequestPostingEntityMRKI, String applicationId)
			throws ApplicationException {

		FTSResponsePostingEntity accountInquiryResponse = null;
        log.info("calling sendTransferRequest for MRKI");
		//Create FixedFormatManager Instance
		fixedFormatManager = new FixedFormatManagerImpl();
		//log.info("FTS Reference for  ::::::::::::::::::::::::::::::" + accountInquiryRequest.getAccountNo());
		//log.info("FTS Reference for AccountInquiryRequest is ::::::::::::::::::::::::::::::" + accountInquiryRequest.getFTSReference() );
		//Export the accountInquiryRequest to text message
		//System.out.println("getFtsInterface()===="+getFtsInterface());
		String responseMessage = getFtsInterface().sendMessage(fixedFormatManager.export(fTSRequestPostingEntityMRKI), applicationId, false);
		try{
			// If Account does'nt Exists Response is 160 chars length instead of 764.
			// Build accountInquiryResponse with CAMM,FTS action code, Fts Ref,Account number.
			// As fixedFormatManager generates Warnings
			
			if (responseMessage.length() == IConstants.FAILED_ACCOUNT_INQUIRY_REPONSE_LENGTH) {
				log.info("-cammActionCode ="+responseMessage.substring(128, 132)+ 
						",ftsActionCode ="+responseMessage.substring(149, 153)+
						",setFTSReference ="+responseMessage.substring(25, 35)+
						",setAccountNumber = "+responseMessage.substring(70, 90));
								
				//Built Empty accountInquiryResponse  with setFTSReference, setAccountNumber, cammActionCode,ftsActionCode
				accountInquiryResponse = new FTSResponsePostingEntity();
				accountInquiryResponse.setSourceSystem(responseMessage.substring(0, 3));
				accountInquiryResponse.setFTSReference(responseMessage.substring(25, 35));
				accountInquiryResponse.setAccountNo(responseMessage.substring(70, 90));
				accountInquiryResponse.setCAMMActionCode(responseMessage.substring(128, 132));
				accountInquiryResponse.setFTSActionCode(responseMessage.substring(149, 153));
				//accountInquiryResponse.setSourceSystem(sourceSystem);
			}
			else {
			//format the response message as AccountInquiryResponse
			log.info("-cammActionCode ="+responseMessage.substring(128, 132)+ 
						",ftsActionCode ="+responseMessage.substring(149, 153)+
						",setFTSReference ="+responseMessage.substring(25, 35)+
						",setAccountNumber = "+responseMessage.substring(70, 90));
						
			accountInquiryResponse = fixedFormatManager.load(FTSResponsePostingEntity.class, responseMessage);
			
			}
		}
		catch(ParseException e){
			throw new InCorrectDataException("error.invalid.data",e);
		}
		//return response object
		
		return accountInquiryResponse;
	}
	
	@Override
	public FTSResponsePostingEntity sendTransferRequest(FTSRequestPostingEntityMRKM fTSRequestPostingEntityMRKM, String applicationId)
			throws ApplicationException {

		FTSResponsePostingEntity accountInquiryResponse = null;
		 
		//Create FixedFormatManager Instance
		fixedFormatManager = new FixedFormatManagerImpl();
		//log.info("FTS Reference for  ::::::::::::::::::::::::::::::" + accountInquiryRequest.getAccountNo());
		//log.info("FTS Reference for AccountInquiryRequest is ::::::::::::::::::::::::::::::" + accountInquiryRequest.getFTSReference() );
		//Export the accountInquiryRequest to text message
		//System.out.println("getFtsInterface()===="+getFtsInterface());
		String responseMessage = getFtsInterface().sendMessage(fixedFormatManager.export(fTSRequestPostingEntityMRKM), applicationId, false);
		try{
			// If Account does'nt Exists Response is 160 chars length instead of 764.
			// Build accountInquiryResponse with CAMM,FTS action code, Fts Ref,Account number.
			// As fixedFormatManager generates Warnings
			
			if (responseMessage.length() == IConstants.FAILED_ACCOUNT_INQUIRY_REPONSE_LENGTH) {
				log.info("-cammActionCode ="+responseMessage.substring(128, 132)+ 
						",ftsActionCode ="+responseMessage.substring(149, 153)+
						",setFTSReference ="+responseMessage.substring(25, 35)+
						",setAccountNumber = "+responseMessage.substring(70, 90));
								
				//Built Empty accountInquiryResponse  with setFTSReference, setAccountNumber, cammActionCode,ftsActionCode
				accountInquiryResponse = new FTSResponsePostingEntity();
				accountInquiryResponse.setSourceSystem(responseMessage.substring(0, 3));
				accountInquiryResponse.setFTSReference(responseMessage.substring(25, 35));
				accountInquiryResponse.setAccountNo(responseMessage.substring(70, 90));
				accountInquiryResponse.setCAMMActionCode(responseMessage.substring(128, 132));
				accountInquiryResponse.setFTSActionCode(responseMessage.substring(149, 153));
				//accountInquiryResponse.setSourceSystem(sourceSystem);
			}
			else {
			//format the response message as AccountInquiryResponse
			log.info("-cammActionCode ="+responseMessage.substring(128, 132)+ 
						",ftsActionCode ="+responseMessage.substring(149, 153)+
						",setFTSReference ="+responseMessage.substring(25, 35)+
						",setAccountNumber = "+responseMessage.substring(70, 90));
						
			accountInquiryResponse = fixedFormatManager.load(FTSResponsePostingEntity.class, responseMessage);
			
			}
		}
		catch(ParseException e){
			throw new InCorrectDataException("error.invalid.data",e);
		}
		//return response object
		return accountInquiryResponse;
	}
	
	@Override
	public FTSResponsePostingEntity sendTransferRequest(FTSRequestPostingEntityTTAC fTSRequestPostingEntityTTAC, String applicationId)
			throws ApplicationException {

		FTSResponsePostingEntity accountInquiryResponse = null;
		log.info("calling sendTransferRequest for TTAC");
		//Create FixedFormatManager Instance
		fixedFormatManager = new FixedFormatManagerImpl();
		//log.info("FTS Reference for  ::::::::::::::::::::::::::::::" + accountInquiryRequest.getAccountNo());
		//log.info("FTS Reference for AccountInquiryRequest is ::::::::::::::::::::::::::::::" + accountInquiryRequest.getFTSReference() );
		//Export the accountInquiryRequest to text message
		//System.out.println("getFtsInterface()===="+getFtsInterface());
		String responseMessage = getFtsInterface().sendMessage(fixedFormatManager.export(fTSRequestPostingEntityTTAC), applicationId, false);
		try{
			// If Account does'nt Exists Response is 160 chars length instead of 764.
			// Build accountInquiryResponse with CAMM,FTS action code, Fts Ref,Account number.
			// As fixedFormatManager generates Warnings
			
			if (responseMessage.length() == IConstants.FAILED_ACCOUNT_INQUIRY_REPONSE_LENGTH) {
				log.info("-cammActionCode ="+responseMessage.substring(128, 132)+ 
						",ftsActionCode ="+responseMessage.substring(149, 153)+
						",setFTSReference ="+responseMessage.substring(25, 35)+
						",setAccountNumber = "+responseMessage.substring(70, 90));
								
				//Built Empty accountInquiryResponse  with setFTSReference, setAccountNumber, cammActionCode,ftsActionCode
				accountInquiryResponse = new FTSResponsePostingEntity();
				accountInquiryResponse.setSourceSystem(responseMessage.substring(0, 3));
				accountInquiryResponse.setFTSReference(responseMessage.substring(25, 35));
				accountInquiryResponse.setAccountNo(responseMessage.substring(70, 90));
				accountInquiryResponse.setCAMMActionCode(responseMessage.substring(128, 132));
				accountInquiryResponse.setFTSActionCode(responseMessage.substring(149, 153));
				//accountInquiryResponse.setSourceSystem(sourceSystem);
			}
			else {
			//format the response message as AccountInquiryResponse
			log.info("-cammActionCode ="+responseMessage.substring(128, 132)+ 
						",ftsActionCode ="+responseMessage.substring(149, 153)+
						",setFTSReference ="+responseMessage.substring(25, 35)+
						",setAccountNumber = "+responseMessage.substring(70, 90));
						
			accountInquiryResponse = fixedFormatManager.load(FTSResponsePostingEntity.class, responseMessage);
			
			}
		}
		catch(ParseException e){
			throw new InCorrectDataException("error.invalid.data",e);
		}
		//return response object
		return accountInquiryResponse;
	}
	
	
	@Override
	public FTSResponsePostingEntity sendTransferRequestAATR(FTSRequestPostingEntityAATR fTSRequestPostingEntityAATR, String applicationId)
			throws ApplicationException {

		FTSResponsePostingEntity accountInquiryResponse = null;
		log.info("calling sendTransferRequest for AATR");
		//Create FixedFormatManager Instance
		fixedFormatManager = new FixedFormatManagerImpl();
		//log.info("FTS Reference for  ::::::::::::::::::::::::::::::" + accountInquiryRequest.getAccountNo());
		//log.info("FTS Reference for AccountInquiryRequest is ::::::::::::::::::::::::::::::" + accountInquiryRequest.getFTSReference() );
		//Export the accountInquiryRequest to text message
		//System.out.println("getFtsInterface()===="+getFtsInterface());
		String responseMessage = getFtsInterface().sendMessage(fixedFormatManager.export(fTSRequestPostingEntityAATR), applicationId, false);
		try{
			// If Account does'nt Exists Response is 160 chars length instead of 764.
			// Build accountInquiryResponse with CAMM,FTS action code, Fts Ref,Account number.
			// As fixedFormatManager generates Warnings
			System.out.println("accountInquiryRequest---TTReference Nu:"+fTSRequestPostingEntityAATR.getSourceSystem());
			if (responseMessage.length() == IConstants.FAILED_ACCOUNT_INQUIRY_REPONSE_LENGTH) {
				log.info("-cammActionCode ="+responseMessage.substring(128, 132)+ 
						",ftsActionCode ="+responseMessage.substring(149, 153)+
						",setFTSReference ="+responseMessage.substring(25, 35)+
						",setAccountNumber = "+responseMessage.substring(70, 90));
				
				accountInquiryResponse = new FTSResponsePostingEntity();
				accountInquiryResponse.setSourceSystem(responseMessage.substring(0, 3));
				accountInquiryResponse.setFTSReference(responseMessage.substring(25, 35));
				accountInquiryResponse.setAccountNo(responseMessage.substring(70, 90));
				accountInquiryResponse.setCAMMActionCode(responseMessage.substring(128, 132));
				accountInquiryResponse.setFTSActionCode(responseMessage.substring(149, 153));
				//accountInquiryResponse.setSourceSystem(sourceSystem);
			}
			else {
			//format the response message as AccountInquiryResponse
			log.info("-cammActionCode ="+responseMessage.substring(128, 132)+ 
						",ftsActionCode ="+responseMessage.substring(149, 153)+
						",setFTSReference ="+responseMessage.substring(25, 35)+
						",setAccountNumber = "+responseMessage.substring(70, 90));
			
			accountInquiryResponse = fixedFormatManager.load(FTSResponsePostingEntity.class, responseMessage);
			
			}
		}
		catch(ParseException e){
			throw new InCorrectDataException("error.invalid.data",e);
		}
		//return response object
		return accountInquiryResponse;
	}
	
	
	
}
