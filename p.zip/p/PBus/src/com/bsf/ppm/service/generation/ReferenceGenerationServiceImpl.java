package com.bsf.ppm.service.generation;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.bsf.ipp.GeneralConfiguration;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.dao.GeneralConfigurationDAO;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.BusinessException;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.exceptions.InvalidDateFormatException;
import com.bsf.ppm.exceptions.ServiceException;
import com.bsf.ppm.jpa.util.BackendUtil;
import com.bsf.ppm.spring.SpringAppContext;
import com.bsf.ppm.util.JNDIUtil;

/**
 * <p>
 * Implementation of ReferenceGenerationService. Generating Transaction
 * ReferenceNumber.
 * </p>
 * 
 * @author Hussain
 * 
 */
public class ReferenceGenerationServiceImpl implements ReferenceGenerationService {

	/** Attribute log - Logger for ReferenceGenerationServiceImpl */
	private static Logger log = Logger
	.getLogger(ReferenceGenerationServiceImpl.class);

	// private SequenceGeneratorDAO sequenceGeneratorDAO; //
	// SequenceGeneratorDAO May be implemented in future. A better way for

	/** Attribute generalConfigurationDAO for GeneralConfigurationDAO */
	private GeneralConfigurationDAO generalConfigurationDAO;


	SimpleDateFormat dateFormat = new SimpleDateFormat("yy");
	
	
	public GeneralConfigurationDAO getGeneralConfigurationDAO() {
		if(generalConfigurationDAO==null){
			generalConfigurationDAO= (GeneralConfigurationDAO) 
				SpringAppContext.getBean("generalConfigurationDAO");
		}
		return generalConfigurationDAO;
	}

	/**
	 * @param generalConfigurationDAO
	 *            the generalConfigurationDAO to set
	 */
	public void setGeneralConfigurationDAO(
			GeneralConfigurationDAO generalConfigurationDAO) {
		this.generalConfigurationDAO = generalConfigurationDAO;
	}

	
	public String swiftTransactionReferenceForMessage(String messageNumber) throws DAOException, BusinessException	{

		return	swiftTransactionReferenceForMessage(messageNumber,false);
	}
	/**
	 * Generates Swift Transaction Reference for the messageNumber
	 * 
	 * @param messageNumber
	 *            to generate the TransactionReference. Like 103, 202
	 * @return transactionReference for the corresponding message
	 * @throws DAOException
	 * @throws BusinessException
	 */
	@Override
	public String swiftTransactionReferenceForMessage(String messageNumber, boolean returnPayment)
	throws DAOException, BusinessException {

		Long sequenceNextValue;
		StringBuilder transactionReference = new StringBuilder();

		// sequenceNextValue =
		// sequenceGeneratorDAO.getnextValueForMessage(messageNumber);
		sequenceNextValue = fetchMessageSequenceNextValue(messageNumber);

		GeneralConfiguration generalConfiguration = getGeneralConfigurationDAO()
		.getById(Long.valueOf(1));

		// fetch transaction ref length from configuration param
		int transactionRefLength = new Integer(BackendUtil
				.getGeneralConfigParameterValue(generalConfiguration,
				"transaction.ref.length")).intValue();
		// Add the Transaction Code
		String code = "";
		if (returnPayment){
			code = BackendUtil.getGeneralConfigParameterValue(
					generalConfiguration, "retnpymt.transaction.code");
		}
		else{
			code = BackendUtil.getGeneralConfigParameterValue(
					generalConfiguration, "transaction.code");			
		}
		transactionReference.append(code);
		log.debug(transactionReference.toString());

		// Append Sequence Number
		transactionReference.append(sequenceNextValue);
		log.debug(transactionReference.toString());

		// Add the day of the year
		String dayFormat = BackendUtil.getGeneralConfigParameterValue(
				generalConfiguration, "transaction.day.format");
		if (dayFormat != null && dayFormat.length() > 0) {			

			if (dayFormat.equalsIgnoreCase("DDD")){				
				transactionReference.append(
						StringUtils.leftPad(""+Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
								, 3, '0'));
			}
			else if (dayFormat.equalsIgnoreCase("DD")){
				transactionReference.append(
						StringUtils.leftPad(""+Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
								, 2, '0'));
			}			
			else {
				throw new InvalidDateFormatException("error.dayformat");
			}
		}
		log.debug(transactionReference.toString());

		// Add the month of the year
		String monthFormat = BackendUtil.getGeneralConfigParameterValue(
				generalConfiguration, "transaction.month.format");
		if (monthFormat != null && monthFormat.length() > 0) {			

			if (monthFormat.equalsIgnoreCase("MM")){				
				transactionReference.append(
						StringUtils.leftPad(""+ (Calendar.getInstance().get(Calendar.MONTH)+1)
								, 2, '0'));
			}					
			else {
				throw new InvalidDateFormatException("error.monthformat");
			}
		}
		log.debug(transactionReference.toString());

		// Add the year
		String yearFormat = BackendUtil.getGeneralConfigParameterValue(
				generalConfiguration, "transaction.year.format");
		if (yearFormat != null && yearFormat.length() > 0) {

			if (yearFormat.equalsIgnoreCase("YYYY"))
				transactionReference.append(Calendar.getInstance().get(
						Calendar.YEAR));
			else if (yearFormat.equalsIgnoreCase("YY"))
				transactionReference.append(Integer.valueOf(Calendar.getInstance().get(Calendar.YEAR)).toString().substring(2));
			else {
				throw new InvalidDateFormatException("error.yearformat");
			}
		}
		log.debug(transactionReference.toString());



		// Throw exception if generated reference is not of trasactionRefLength
		// in parameter
		if (transactionReference.length() < transactionRefLength) {
			throw new ServiceException("error.service.referenceGeneration");
		}

		return transactionReference.toString();
	}

	/**
	 * Generates FTS Transaction Reference
	 * 
	 * @return unique transactionReference for FTS request
	 * @throws DAOException 
	 */
	@Override
	public String fetchFtsTransactionReference() throws BusinessException, DAOException {

		StringBuilder transactionReference = new StringBuilder();

		// Prefix 99 to FTS transaction reference Number
		//transactionReference.append("CLG");

		// Fetch FTS Sequence Next Value
		Long sequenceNextValue = fetchFtsSequenceNextValue();

		// Append Sequence Number

		transactionReference.append(String.format("%010d", sequenceNextValue));
		log.debug(transactionReference.toString());
		
		// Throw exception if generated reference is not of length 10
		if (transactionReference.length() != IConstants.FTS_TRANS_REFERENCE_LENGTH) {
			throw new ServiceException("error.service.referenceGeneration");

		}
		return transactionReference.toString();
	}
	
	public String fetchMacTransactionReference() throws ApplicationException {
		Long sequenceNextValue = getGeneralConfigurationDAO().getMacTTReference();
		return fetchTransactionReference("MACTT",sequenceNextValue);

	}

	private String fetchTransactionReference(String prefix,
			Long sequenceNextValue) throws ServiceException {
		StringBuilder transactionReference = new StringBuilder();
		// Prefix 99 to FTS transaction reference Number
		transactionReference.append(prefix);
		transactionReference.append(String.format("%06d", sequenceNextValue));
		transactionReference.append(dateFormat.format(Calendar.getInstance().getTime()));
		log.debug(transactionReference.toString());
		// Throw exception if generated reference is not of length 10
		if (transactionReference.length() != IConstants.TT_TRANS_REFERENCE_LENGTH) {
			throw new ServiceException("error.service.referenceGeneration");

		}
		return transactionReference.toString();
	}

	private Long fetchMessageSequenceNextValue(String messageNumber) throws DAOException {

		Long nextValue = null;
		// Fetch connection Object
		Connection con = JNDIUtil.getSimpleDBConnection();
		ResultSet rs = null;
		Statement stmt = null;
		try {
			stmt = con.createStatement();
			String query="select SEQ_SWIFT_MESSAGE_MT_"
				+ messageNumber + ".NEXTVAL as SEQ_NEXT_VALUE from dual";
			System.out.println(query);
			// Excecute sql for NEXTVAL
			rs = stmt.executeQuery(query);
			rs.next();
			nextValue = rs.getLong("SEQ_NEXT_VALUE");
		} catch (Exception e) {
			throw new DAOException("error.fetchMessageSequence",e);
		} finally {
			// Close the DB objects
			try {
				if(rs !=null)	{ 
					rs.close();
				}
				if(stmt!=null)	{
					stmt.close();
				}
				if(con !=null)	{
					con.close();
				}
			} catch (SQLException e) {
				throw new DAOException("error.fetchMessageSequence");
			}
		}

		return nextValue;
	}
	
	/**
	 * @return
	 * @throws DAOException
	 */
	public Long fetchCheckMessageSequenceNextValue() throws DAOException{
		return fetchMessageSequenceNextValue("11X");
	}

	private Long fetchFtsSequenceNextValue() throws DAOException {

		/*Long nextValue = null;
		// Fetch connection Object
		Connection con = JNDIUtil.getSimpleDBConnection();
		ResultSet rs = null;
		Statement stmt = null;
		try {
			stmt = con.createStatement();
			// Excecute sql for NEXTVAL
			rs = stmt
			.executeQuery("select SEQ_FTS_TRANSACTION_REFERENCE.NEXTVAL as SEQ_NEXT_VALUE from dual");
			rs.next();
			nextValue = rs.getLong("SEQ_NEXT_VALUE");

		} catch (Exception e) {
			e.printStackTrace();
			throw new DAOException("error.fetchMessageSequence",e);
		} finally {
			// Close the DB objects
			try {
				if (rs != null)
					rs.close();
				if (stmt !=null)
					stmt.close();
				if (con !=null)
					con.close();
			} catch (SQLException e) {
				throw new DAOException("error.fetchMessageSequence");
			}
		}

		return nextValue;*/
		
		// We are facing problem while obtaining JNDI connection to get next sequence value
		// So the sequence value will be obtained using Hibernate
		// The below method will return the next sequence value Hibernate will return the value
		// by executing the below method which will run native query.
		return getGeneralConfigurationDAO().getFtsReference();
	}

	@Override
	public String fetchB2BTransactionReference() throws ApplicationException {
		Long sequenceNextValue = getGeneralConfigurationDAO().getB2BTTReference();
		return fetchTransactionReference("B2BTT",sequenceNextValue);

	}

	@Override
	public String fetchCLNFtsTransactionReference() throws ApplicationException {

		StringBuilder transactionReference = new StringBuilder("CQ");

		// Fetch FTS Sequence Next Value
		Long sequenceNextValue = getGeneralConfigurationDAO().getCLNFtsReference();

		// Append Sequence Number
		transactionReference.append(String.format("%08d", sequenceNextValue));
				
		// Throw exception if generated reference is not of length 10
		if (transactionReference.length() != IConstants.FTS_TRANS_REFERENCE_LENGTH) {
			log.error("Error in Generating Referece"+transactionReference.toString());
			throw new ServiceException("error.service.referenceGeneration");
		}
		return transactionReference.toString();
	}

	@Override
	public String fetchCLNUpdateReference() throws ApplicationException {

		StringBuilder transactionReference = new StringBuilder("CQ");

		// Fetch FTS Sequence Next Value
		Long sequenceNextValue = getGeneralConfigurationDAO().getCLNUpdateReference();

		// Append Sequence Number
		transactionReference.append(String.format("%08d", sequenceNextValue));
				
		// Throw exception if generated reference is not of length 10
		if (transactionReference.length() != IConstants.FTS_TRANS_REFERENCE_LENGTH) {
			log.error("Error in Generating Referece"+transactionReference.toString());
			throw new ServiceException("error.service.referenceGeneration");
		}
		return transactionReference.toString();
	}

	@Override
	public String fetchCLNOutUpdateReference() throws ApplicationException {

		StringBuilder transactionReference = new StringBuilder("CQ");

		// Fetch FTS Sequence Next Value
		Long sequenceNextValue = getGeneralConfigurationDAO().getCLNOutUpdateReference();

		// Append Sequence Number
		transactionReference.append(String.format("%08d", sequenceNextValue));
				
		// Throw exception if generated reference is not of length 10
		if (transactionReference.length() != IConstants.FTS_TRANS_REFERENCE_LENGTH) {
			log.error("Error in Generating Referece"+transactionReference.toString());
			throw new ServiceException("error.service.referenceGeneration");
		}
		return transactionReference.toString();
	}
   
	@Override
	public String fetchCLNScheduleNumber() throws ApplicationException {
		
		String  year = (Calendar.getInstance().get(Calendar.YEAR)+"").substring(2, 4);
		
		StringBuilder scheduleNumber = new StringBuilder("PYC-"+year+"-");
		
		Long sequenceNextValue = getGeneralConfigurationDAO().getCLNOutSchedualNo();

		// Append Sequence Number
		scheduleNumber.append(String.format("%06d", sequenceNextValue));
				
		// Throw exception if generated reference is not of length 13
		if (scheduleNumber.length() != IConstants.FTS_SCHEDUAL_NO_LENGTH) {
			log.error("Error in Generating Schedual Number"+scheduleNumber.toString());
			throw new ServiceException("error.service.schedualGeneration");
		}
		return scheduleNumber.toString();
	}
	
	@Override
	public String fetchCLNTScheduleNumber() throws ApplicationException {
		
		String  year = (Calendar.getInstance().get(Calendar.YEAR)+"").substring(2, 4);
		
		StringBuilder scheduleNumber = new StringBuilder("PYC-"+year+"-T");
		
		Long sequenceNextValue = getGeneralConfigurationDAO().getCLNTOutSchedualNo();

		// Append Sequence Number
		scheduleNumber.append(String.format("%05d", sequenceNextValue));
				
		// Throw exception if generated reference is not of length 13
		if (scheduleNumber.length() != IConstants.FTS_SCHEDUAL_NO_LENGTH) {
			log.error("Error in Generating Schedual Number"+scheduleNumber.toString());
			throw new ServiceException("error.service.schedualGeneration");
		}
		return scheduleNumber.toString();
	}
	
	
}

