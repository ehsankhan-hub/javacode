package com.bsf.ppm.service.application;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

import org.apache.log4j.Logger;
import org.springframework.security.concurrent.SessionInformation;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.GeneralConfiguration;
import com.bsf.ppm.Application;
import com.bsf.ppm.batch.service.CustomSessionRegistryImpl;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.dao.ApplicationDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.jpa.util.BackendUtil;
import com.bsf.ppm.spring.SpringAppContext;

/**
 * @author Zakir
 * 
 */
@Transactional
public class ApplicationManagementImpl implements ApplicationManagement {
	private static final Logger log = Logger
	.getLogger(ApplicationManagementImpl.class);

	/**
	 * Attribute applicationDAO
	 */
	private ApplicationDAO applicationDAO;



	/**
	 * Setter method
	 * 
	 * @param applicationDAO
	 */
	public void setApplicationDAO(ApplicationDAO applicationDAO) {
		this.applicationDAO = applicationDAO;
	}

	/**
	 * @return applicationDAO
	 */
	public ApplicationDAO getApplicationDAO() {
		return applicationDAO;
	}





	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.service.application.ApplicationManagement#startApplication
	 * (com.bsf.ipp.Application)
	 */
	@Override
	public void startApplication(Application applicationEntity) {
		
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.service.application.ApplicationService#startApplicationById
	 * (java.lang.Long)
	 */
	@Override
	public void startApplicationById(String id) {
		// TODO Auto-generated method stub
		Application applicationEntity;
		try {
			// Fetch the Application Entity from Database
			applicationEntity = getApplicationDAO().getById(id);

			// Start Application
			startApplication(applicationEntity);
		} catch (DAOException e) {
			log.warn("System faild to start application  " + id);

		}
	}


	@Override
	public void startApplicationByName(String appName) {
		try {
			// Fetch the active Applications from Database
			Map<String, String> criteria = new HashMap<String, String>();
			criteria.put("applicationName",appName);			
			List<Application> activeApplications = getApplicationDAO().searchByCriteria(criteria);
			for (Iterator<Application> iterator = activeApplications.iterator(); iterator
			.hasNext();) {
				Application application = (Application) iterator.next();
				
				// Start Application
				startApplication(application);
			}
		} catch (DAOException e) {
			log.warn("System failed to start application :  " + appName);

		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.service.application.ApplicationService#startApplicationByIds
	 * (java.lang.String[])
	 */
	@Override
	public void startApplicationByIds(String[] idsArray) {
		if (idsArray != null && idsArray.length > 0) {
			for (int i = 0; i < idsArray.length; i++) {
				startApplicationById(idsArray[i]);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.service.application.ApplicationService#startAllApplications()
	 */
	@Override
	public void startAllApplications() {
		Application applicationEntity;
		List<Application> activeApplications = new ArrayList<Application>();

		try {
			// Fetch the active Applications from Database
			Map<String, String> criteria = new HashMap<String, String>();
			criteria.put(IConstants.DEFAULT_STATUS_FIELD,Integer.valueOf(
					IConstants.STATUS_TYPE.ACTIVE.ordinal()).toString());
			activeApplications = getApplicationDAO().searchByCriteria(criteria);
		} catch (DAOException e) {
			log.warn("System failed to retrieve  applications from database");
		}

		// Start the Applications
		if (activeApplications != null)
			for (Iterator<Application> iterator = activeApplications.iterator(); iterator
			.hasNext();) {
				applicationEntity = (Application) iterator.next();
				startApplication(applicationEntity);
			}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.service.application.ApplicationManagement#stopApplication
	 * (com.bsf.ipp.Application)
	 */
	@Override
	public void stopApplication(Application applicationEntity) {
		
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.service.application.ApplicationService#stopApplicationById
	 * (java.lang.Long)
	 */
	@Override
	public void stopApplicationById(String id) {
		// TODO Auto-generated method stub
		Application applicationEntity;

		try {
			// Fetch the Application Entity from Database
			applicationEntity = getApplicationDAO().getById(id);

			// stop Application
			stopApplication(applicationEntity);
		} catch (DAOException e) {
			log.warn("System failed to stop applications");
		}

	}
	
	@Override
	public void stopApplicationByName(String appName) {
		try {
			// Fetch the active Applications from Database
			Map<String, String> criteria = new HashMap<String, String>();
			criteria.put("applicationName",appName);			
			List<Application> activeApplications = getApplicationDAO().searchByCriteria(criteria);
			for (Iterator<Application> iterator = activeApplications.iterator(); iterator
			.hasNext();) {
				Application application = (Application) iterator.next();
				
				// stop Application
				stopApplication(application);
			}
		} catch (DAOException e) {
			log.warn("System failed to start application :  " + appName);

		}
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.service.application.ApplicationService#stopApplicationByIds
	 * (java.lang.String[])
	 */
	@Override
	public void stopApplicationByIds(String[] idsArray) {
		if (idsArray != null && idsArray.length > 0) {
			for (int i = 0; i < idsArray.length; i++) {
				stopApplicationById(idsArray[i]);
			}
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bsf.ppm.service.application.ApplicationService#stopAllApplications()
	 */
	@Override
	public void stopAllApplications() {
		Application applicationEntity;
		List<Application> activeApplications ;

		try {
			// Fetch the active Applications from Database
			Map<String, String> criteria = new HashMap<String, String>();
			criteria.put(IConstants.DEFAULT_STATUS_FIELD, Integer.valueOf(
					IConstants.STATUS_TYPE.ACTIVE.ordinal()).toString());
			activeApplications = getApplicationDAO().searchByCriteria(criteria);
			for (Iterator<Application> iterator = activeApplications.iterator(); iterator
			.hasNext();) {
				applicationEntity = (Application) iterator.next();
				stopApplication(applicationEntity);
			}
		} catch (DAOException e) {
			log.warn("System failed to stop applications");
		}
	}


	@Override
	public void activateApplicationByName(String appName) {
		
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seecom.bsf.ppm.service.application.ApplicationManagement#
	 * deactivateApplicationById(java.lang.Long)
	 */
	@Override
	public void deactivateApplicationByName(String appName) {
		
	}

	@Override
	public void logOutApplicationUsers(String[] idsArray) {

		CustomSessionRegistryImpl sessionReg = (CustomSessionRegistryImpl) SpringAppContext
		.getBean("sessionReg");
		if(sessionReg != null)		{

			Map<String,Set<String>> appIds = sessionReg.getAppIds();
			Iterator<String> itr = appIds.keySet().iterator();
			Set<String> apps = null;
			String sessionId = null;
			SessionInformation sessionInfo = null;
			for(String appId:idsArray)	{

				while(itr.hasNext())	{

					sessionId = (String)itr.next();
					apps = appIds.get(sessionId);
					if(apps != null)	{

						if(apps.contains(new String(appId)))	{

							sessionInfo = sessionReg.getSessionInformation(sessionId);
							if(sessionInfo != null)	{

								sessionInfo.expireNow();
							}
						}
					}
				}	
			}
		}else	{

			log.warn(this.getClass().getSimpleName()+" Unable to retrieve 'sessionReg' from SpringAppContext......");
		}
	}

	@Override
	public String getPrivilgedHost() {

		Cache  generalConfigurationCache= (Cache) SpringAppContext.getBean("generalConfigurationCache");
		String privilegedHost = null;

		Element elem = generalConfigurationCache.get("PrivilegedHostToCtrlApp");
		if (elem != null) {

			GeneralConfiguration generalConfig = (GeneralConfiguration) elem.getObjectValue();
			privilegedHost = BackendUtil.getGeneralConfigParameterValue(generalConfig,"PrivilegedHostName");
		}	
		return privilegedHost;
	}
}
