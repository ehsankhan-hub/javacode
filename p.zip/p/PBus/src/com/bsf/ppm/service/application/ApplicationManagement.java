package com.bsf.ppm.service.application;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.ppm.Application;

@Transactional
public interface ApplicationManagement {
	
	/**
	 * Starts application identified by applicationEntity
	 * @param applicationEntity
	 */
	void startApplication(Application applicationEntity);
	
	/**
	 * Starts application identified by id in Application table
	 * This starts all the services and processes related the application
	 * @param id
	 */
	void startApplicationById(String id);
	
	/**
	 * Starts application identified by appName in Application table
	 * This starts all the services and processes related the application
	 * @param id
	 */
	void startApplicationByName(String appName);
	
	/**
	 *  This starts all the services and processes related the applications 
	 *  identified by idsArray
	 *  @param idsArray
	 */	
	void startApplicationByIds(String[] idsArray);
	
	/**
	 *  Start All applications 
	 *  This starts all the services and processes related to all the active applications
	 */
	public void startAllApplications();
	
	/**
	 * Stops application identified by applicationEntity
	 * @param applicationEntity
	 */
	void stopApplication(Application applicationEntity);
	
	/**
	 * Stops application identified by id in Application table
	 * This stops all the services and processes related the application
	 * @param id
	 */
	void stopApplicationById(String id);
	
	/**
	 * Stops application identified by appName in Application table
	 * This stops all the services and processes related the application
	 * @param id
	 */
	void stopApplicationByName(String appName);
	
	/**
	 *  This starts all the services and processes related the applications 
	 *  identified by idsArray
	 *  @param idsArray
	 */		
	void stopApplicationByIds(String[] idsArray);

	/**
	 *  Stop All applications 
	 *  This stops all the services and processes related to all the active applications
	 */
	public void stopAllApplications();
	
	/**
	 * Deactivates application, services and processes related to application
	 * @param appName
	 */
	@Transactional(propagation=Propagation.REQUIRED)
	public void deactivateApplicationByName(String appName);
	
	/**
	 * Activates application, services and processes related to application
	 * @param appName
	 */
	@Transactional(propagation=Propagation.REQUIRED)
	public void activateApplicationByName(String appName);
	
	public void logOutApplicationUsers(String[] idsArray);
	
	/*
	 * This method retrieves the privileged host to stop the application from the general configuration.
	 * 
	 */
	public String getPrivilgedHost();
}
