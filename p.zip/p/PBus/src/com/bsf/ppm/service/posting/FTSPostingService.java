package com.bsf.ppm.service.posting;

import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.BusinessException;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.fts.AccountInquiryRequest;
import com.bsf.ppm.fts.AccountInquiryResponse;
import com.bsf.ppm.fts.FTSRequestPostingEntityMRKI;
import com.bsf.ppm.fts.FTSRequestPostingEntityAATR;
import com.bsf.ppm.fts.FTSRequestPostingEntityMRKM;
import com.bsf.ppm.fts.FTSRequestPostingEntityTTAC;
import com.bsf.ppm.fts.FTSResponsePostingEntity;
import com.bsf.ppm.service.LocalService;
import com.bsf.ppm.service.RemoteService;

/**
 * Interface for sending messages to Tuxedo
 * @author Rakesh
 *
 */
public interface FTSPostingService extends LocalService, RemoteService{	
	

	/**
	 * This methods sends account inquiry request to Tuxedo 
	 * @param accountInquiryRequest
	 * @return
	 * @throws DAOException 
	 * @throws BusinessException 
	 */
	public AccountInquiryResponse sendAccountInquiry(AccountInquiryRequest accountInquiryRequest,String applicationId) throws ApplicationException;
	public FTSResponsePostingEntity sendTransferRequest(FTSRequestPostingEntityMRKM fTSRequestPostingEntityMRKM, String applicationId)throws ApplicationException ;
	public FTSResponsePostingEntity sendTransferRequest(FTSRequestPostingEntityMRKI fTSRequestPostingEntityMRKI, String applicationId)throws ApplicationException ;
	public FTSResponsePostingEntity sendTransferRequest(FTSRequestPostingEntityTTAC fTSRequestPostingEntityTTAC, String applicationId)throws ApplicationException ;
	public FTSResponsePostingEntity sendTransferRequestAATR(FTSRequestPostingEntityAATR fTSRequestPostingEntityAATR, String applicationId)
	throws ApplicationException ;
}

