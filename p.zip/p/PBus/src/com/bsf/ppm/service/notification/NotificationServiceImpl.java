package com.bsf.ppm.service.notification;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.ppm.MailAddress;
import com.bsf.ppm.MailAttachment;
import com.bsf.ppm.MailMessage;
import com.bsf.ppm.MailTemplate;
import com.bsf.ppm.SmsMessage;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.dao.MailMessageDAO;
import com.bsf.ppm.dao.MailTemplateDAO;
import com.bsf.ppm.dao.SmsMessageDAO;
import com.bsf.ppm.exceptions.BusinessException;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.exceptions.ServiceException;

/**
 * Implementation of notification service to send mail via mail or SMS
 * @author Rakesh
 */
@Transactional
public class NotificationServiceImpl implements NotificationService {

	/** Attribute mailMessageDAO */
	private MailMessageDAO mailMessageDAO;

	/** Attribute mailMessageDAO */
	private MailTemplateDAO mailTemplateDAO;

	/** Attribute smsMessageDAO */
	private SmsMessageDAO smsMessageDAO;

	/**
	 * Setter method for mailMessageDAO
	 * 
	 * @param mailMessageDAO
	 */
	public void setMailMessageDAO(MailMessageDAO mailMessageDAO) {
		this.mailMessageDAO = mailMessageDAO;
	}

	/**
	 * @param mailTemplateDAO
	 *            the mailTemplateDAO to set
	 */
	public void setMailTemplateDAO(MailTemplateDAO mailTemplateDAO) {
		this.mailTemplateDAO = mailTemplateDAO;
	}

	/**
	 * Setter method for smsMessageDAO
	 * 
	 * @param smsMessageDAO
	 */
	public void setSmsMessageDAO(SmsMessageDAO smsMessageDAO) {
		this.smsMessageDAO = smsMessageDAO;
	}

	/**
	 * Sends mail notifications
	 * 
	 * @param mailMessage
	 * @throws ServiceException
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false)
	public void notifyByMail(MailMessage mailMessage) throws ServiceException {
		try {
			mailMessageDAO.save(mailMessage);
		} catch (DAOException e) {
			throw new ServiceException("error.send.mail", e);
		}
	}

	/**
	 * Sends mail notifications from Predefined template.
	 * 
	 * @param templateId
	 * @param valuesMap
	 * @param to
	 * @param cc
	 * @param bcc
	 * @throws ServiceException
	 */

	@Override
	public void notifyByMailTemplateCC(Long templateId,
			Map<String, Object> valuesMap, String to, String cc, String bcc) throws ServiceException	{

		try {
			MailTemplate tpl = mailTemplateDAO.getById(templateId);
			if(tpl != null && tpl.getCc()!= null  && !tpl.getCc().isEmpty())	{

				if(cc!=null && !cc.isEmpty())	{

					notifyByMailTemplate(templateId, valuesMap, to, cc+","+tpl.getCc(), null);
				}else	{

					notifyByMailTemplate(templateId, valuesMap, to, tpl.getCc(), null);
				}
			}else	{

				notifyByMailTemplate(templateId, valuesMap, to, cc, null);

			}
		} catch (DAOException e) {
			throw new ServiceException("error.send.mail", e);
		}
	}



	@Override
	public void notifyByMailTemplateCC(Long templateId,
			Map<String, Object> subjectValuesMap,
			Map<String, Object> valuesMap, String to, String cc, String bcc)
	throws ServiceException {
		try {
			MailTemplate tpl = mailTemplateDAO.getById(templateId);
			if(tpl != null && tpl.getCc()!= null  && !tpl.getCc().isEmpty())	{

				if(cc!=null && !cc.isEmpty())	{

					notifyByMailTemplate(templateId, subjectValuesMap, valuesMap, to, cc+","+tpl.getCc(), null);
				}else	{

					notifyByMailTemplate(templateId, subjectValuesMap, valuesMap, to, tpl.getCc(), null);
				}
			}else	{

				notifyByMailTemplate(templateId, subjectValuesMap, valuesMap, to, cc, null);

			}
		} catch (DAOException e) {
			throw new ServiceException("error.send.mail", e);
		}

	}


	@Override
	public void notifyByMailTemplate(Long templateId,
			Map<String, Object> subjectValuesMap,
			Map<String, Object> valuesMap, String to, String cc, String bcc)
	throws ServiceException {

		MailMessage mailMessage = new MailMessage();
		String messageStr;
		try {
			// Fetch the mail Template
			MailTemplate mailTemplate;

			mailTemplate = mailTemplateDAO.getById(templateId);

			if (mailTemplate != null) {

				/******** Initialize Velocity Engine and Context ********/
				// get and initialize an engine
				VelocityEngine ve = new VelocityEngine();

				// create a context and add data
				VelocityContext context = new VelocityContext();
				context.put("map", valuesMap);

				/******** Replace Parameters in template message ********/

				messageStr = mailTemplate.getMessage();
				// render the template into a StringWriter
				StringWriter writer = new StringWriter();
				ve.evaluate(context, writer, "LOG", messageStr);
				// Get replaced Message
				messageStr = writer.toString();

				/************* Build Mail Message ****************/

				mailMessage.setMessage(messageStr);

				if (subjectValuesMap !=null){

					String subject = mailTemplate.getSubject();

					// get and initialize an engine
					ve = new VelocityEngine();

					// create a context and add data
					context = new VelocityContext();
					context.put("map", subjectValuesMap);

					/******** Replace Parameters in template subject ********/

					// render the template into a StringWriter
					StringWriter wrt = new StringWriter();
					ve.evaluate(context, wrt, "LOG", subject);
					// Get replaced Message
					subject = wrt.toString();

					mailMessage.setMailSubject(subject);
				}
				else {
					mailMessage.setMailSubject(mailTemplate.getSubject());
				}

				mailMessage.setMailStatus((long) IConstants.MAIL_STATUS_TYPE.NEW.ordinal());
				mailMessage.setCreatedDate(new Timestamp(Calendar.getInstance()
						.getTimeInMillis()));

				// Build mail address list
				List<MailAddress> mailAddressesList = new ArrayList<MailAddress>();
				// add From address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getMailFrom(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.FROM)); 
				// add To address
				mailAddressesList.addAll(fetchMailAddressList(
						(to != null && !to.isEmpty()) ? to : mailTemplate
								.getMailTo(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.TO));
				// add Cc address
				mailAddressesList.addAll(fetchMailAddressList(
						(cc != null && !cc.isEmpty()) ? cc : mailTemplate
								.getCc(), mailMessage,	IConstants.MAIL_ADDRESS_TYPE.CC));
				// add Bcc address
				mailAddressesList.addAll(fetchMailAddressList(
						(bcc != null && !bcc.isEmpty()) ? bcc : mailTemplate
								.getBcc(), mailMessage,	IConstants.MAIL_ADDRESS_TYPE.BCC));
				//add List to mailMessage
				mailMessage.setMailAddressList(mailAddressesList);

				/******** Send Mail Message ********/
				notifyByMail(mailMessage);
			}
		} catch (DAOException e) {
			throw new ServiceException("error.send.mail", e);
		} catch (ParseErrorException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (MethodInvocationException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (ResourceNotFoundException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (IOException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (Exception e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false)
	public void notifyByMailTemplate(Long templateId,
			Map<String, Object> valuesMap, String to, String cc, String bcc)
	throws ServiceException {
		MailMessage mailMessage = new MailMessage();
		String messageStr;
		try {
			// Fetch the mail Template
			MailTemplate mailTemplate;

			mailTemplate = mailTemplateDAO.getById(templateId);

			if (mailTemplate != null) {

				/******** Initialize Velocity Engine and Context ********/
				// get and initialize an engine
				VelocityEngine ve = new VelocityEngine();

				// create a context and add data
				VelocityContext context = new VelocityContext();
				context.put("map", valuesMap);

				/******** Replace Parameters in template message ********/

				messageStr = mailTemplate.getMessage();
				// render the template into a StringWriter
				StringWriter writer = new StringWriter();
				ve.evaluate(context, writer, "LOG", messageStr);
				// Get replaced Message
				messageStr = writer.toString();

				/************* Build Mail Message ****************/

				mailMessage.setMessage(messageStr);
				mailMessage.setMailSubject(mailTemplate.getSubject());
				mailMessage.setMailStatus((long) IConstants.MAIL_STATUS_TYPE.NEW.ordinal());
				mailMessage.setCreatedDate(new Timestamp(Calendar.getInstance()
						.getTimeInMillis()));

				// Build mail address list
				List<MailAddress> mailAddressesList = new ArrayList<MailAddress>();
				// add From address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getMailFrom(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.FROM)); 
				// add To address
				mailAddressesList.addAll(fetchMailAddressList(
						(to != null && !to.isEmpty()) ? to : mailTemplate
								.getMailTo(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.TO));
				// add Cc address
				mailAddressesList.addAll(fetchMailAddressList(
						(cc != null && !cc.isEmpty()) ? cc : mailTemplate
								.getCc(), mailMessage,	IConstants.MAIL_ADDRESS_TYPE.CC));
				// add Bcc address
				mailAddressesList.addAll(fetchMailAddressList(
						(bcc != null && !bcc.isEmpty()) ? bcc : mailTemplate
								.getBcc(), mailMessage,	IConstants.MAIL_ADDRESS_TYPE.BCC));
				//add List to mailMessage
				mailMessage.setMailAddressList(mailAddressesList);

				/******** Send Mail Message ********/
				notifyByMail(mailMessage);
			}
		} catch (DAOException e) {
			throw new ServiceException("error.send.mail", e);
		} catch (ParseErrorException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (MethodInvocationException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (ResourceNotFoundException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (IOException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (Exception e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		}

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false)
	public void notifyByMailTemplate(Long templateId, Date processingDate,
			Map<String, Object> valuesMap) throws ServiceException {

		MailMessage mailMessage = new MailMessage();
		String messageStr;
		try {
			if (processingDate!=null){
				mailMessage.setProcessingDate(processingDate);
			}
			// Fetch the mail Template
			MailTemplate mailTemplate = mailTemplateDAO.getById(templateId);
			if (mailTemplate != null) {

				/******** Initialize Velocity Engine and Context ********/
				// get and initialize an engine
				VelocityEngine ve = new VelocityEngine();

				// create a context and add data
				VelocityContext context = new VelocityContext();
				context.put("map", valuesMap);

				/******** Replace Parameters in template message ********/

				messageStr = mailTemplate.getMessage();
				// render the template into a StringWriter
				StringWriter writer = new StringWriter();
				ve.evaluate(context, writer, "LOG", messageStr);
				// Get replaced Message
				messageStr = writer.toString();

				/************* Build Mail Message ****************/

				mailMessage.setMessage(messageStr);
				mailMessage.setMailSubject(mailTemplate.getSubject());
				mailMessage.setMailStatus((long) IConstants.MAIL_STATUS_TYPE.NEW.ordinal());
				mailMessage.setCreatedDate(new Timestamp(Calendar.getInstance()
						.getTimeInMillis()));

				// Build mail address list
				List<MailAddress> mailAddressesList = new ArrayList<MailAddress>();
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getMailFrom(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.FROM)); // add From address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getMailTo(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.TO)); // add To address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate.getCc(),
						mailMessage, IConstants.MAIL_ADDRESS_TYPE.CC)); // add Cc address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getBcc(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.BCC)); // add Bcc address
				//add List to mailMessage
				mailMessage.setMailAddressList(mailAddressesList);

				/******** Send Mail Message ********/
				notifyByMail(mailMessage);
			}
		} catch (DAOException e) {
			throw new ServiceException("error.send.mail", e);
		} catch (ParseErrorException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (MethodInvocationException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (ResourceNotFoundException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (IOException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (Exception e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		}
	}

	@Override
	public void notifyByMailTemplate(Long templateId,
			Map<String, Object> subjectValuesMap, Map<String, Object> valuesMap)
	throws ServiceException {

		MailMessage mailMessage = new MailMessage();
		String messageStr;
		try {
			// Fetch the mail Template
			MailTemplate mailTemplate = mailTemplateDAO.getById(templateId);
			if (mailTemplate != null) {

				/******** Initialize Velocity Engine and Context ********/
				// get and initialize an engine
				VelocityEngine ve = new VelocityEngine();

				// create a context and add data
				VelocityContext context = new VelocityContext();
				context.put("map", valuesMap);

				/******** Replace Parameters in template message ********/

				messageStr = mailTemplate.getMessage();
				// render the template into a StringWriter
				StringWriter writer = new StringWriter();
				ve.evaluate(context, writer, "LOG", messageStr);
				// Get replaced Message
				messageStr = writer.toString();

				/************* Build Mail Message ****************/

				mailMessage.setMessage(messageStr);

				if (subjectValuesMap !=null){

					String subject = mailTemplate.getSubject();

					// get and initialize an engine
					ve = new VelocityEngine();

					// create a context and add data
					context = new VelocityContext();
					context.put("map", subjectValuesMap);

					/******** Replace Parameters in template subject ********/

					// render the template into a StringWriter
					StringWriter wrt = new StringWriter();
					ve.evaluate(context, wrt, "LOG", subject);
					// Get replaced Message
					subject = wrt.toString();

					mailMessage.setMailSubject(subject);
				}
				else {
					mailMessage.setMailSubject(mailTemplate.getSubject());
				}

				mailMessage.setMailStatus((long) IConstants.MAIL_STATUS_TYPE.NEW.ordinal());
				mailMessage.setCreatedDate(new Timestamp(Calendar.getInstance()
						.getTimeInMillis()));

				// Build mail address list
				List<MailAddress> mailAddressesList = new ArrayList<MailAddress>();
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getMailFrom(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.FROM)); // add From address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getMailTo(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.TO)); // add To address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate.getCc(),
						mailMessage, IConstants.MAIL_ADDRESS_TYPE.CC)); // add Cc address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getBcc(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.BCC)); // add Bcc address
				//add List to mailMessage
				mailMessage.setMailAddressList(mailAddressesList);

				/******** Send Mail Message ********/
				notifyByMail(mailMessage);
			}
		} catch (DAOException e) {
			throw new ServiceException("error.send.mail", e);
		} catch (ParseErrorException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (MethodInvocationException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (ResourceNotFoundException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (IOException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (Exception e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		}
	}

	/**
	 * Sends mail notifications from Predefined template. To, FROM,CC, BCC are
	 * stored as part of Template. This data is extracted from Mail_Template
	 * table and Mail message is created
	 * 
	 * @param templateId
	 * @param valuesMap
	 * @throws BusinessException
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false)
	public void notifyByMailTemplate(Long templateId,
			Map<String, Object> valuesMap) throws ServiceException {

		MailMessage mailMessage = new MailMessage();
		String messageStr;
		try {
			// Fetch the mail Template
			MailTemplate mailTemplate = mailTemplateDAO.getById(templateId);
			if (mailTemplate != null) {

				/******** Initialize Velocity Engine and Context ********/
				// get and initialize an engine
				VelocityEngine ve = new VelocityEngine();

				// create a context and add data
				VelocityContext context = new VelocityContext();
				context.put("map", valuesMap);

				/******** Replace Parameters in template message ********/

				messageStr = mailTemplate.getMessage();
				// render the template into a StringWriter
				StringWriter writer = new StringWriter();
				ve.evaluate(context, writer, "LOG", messageStr);
				// Get replaced Message
				messageStr = writer.toString();

				/************* Build Mail Message ****************/

				mailMessage.setMessage(messageStr);
				mailMessage.setMailSubject(mailTemplate.getSubject());
				mailMessage.setMailStatus((long) IConstants.MAIL_STATUS_TYPE.NEW.ordinal());
				mailMessage.setCreatedDate(new Timestamp(Calendar.getInstance()
						.getTimeInMillis()));

				// Build mail address list
				List<MailAddress> mailAddressesList = new ArrayList<MailAddress>();
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getMailFrom(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.FROM)); // add From address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getMailTo(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.TO)); // add To address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate.getCc(),
						mailMessage, IConstants.MAIL_ADDRESS_TYPE.CC)); // add Cc address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getBcc(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.BCC)); // add Bcc address
				//add List to mailMessage
				mailMessage.setMailAddressList(mailAddressesList);

				/******** Send Mail Message ********/
				notifyByMail(mailMessage);
			}
		} catch (DAOException e) {
			throw new ServiceException("error.send.mail", e);
		} catch (ParseErrorException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (MethodInvocationException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (ResourceNotFoundException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (IOException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (Exception e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		}
	}

	
	
	@Override
	public void notifyByMailTemplateWithAttachment(Long templateId,
			Map<String, Object> subjectValuesMap,
			Map<String, Object> valuesMap,
			List<MailAttachment> mailAttachmentList) throws ServiceException {

		MailMessage mailMessage = new MailMessage();
		String messageStr;
		try {
			// Fetch the mail Template
			MailTemplate mailTemplate = mailTemplateDAO.getById(templateId);
			if (mailTemplate != null) {

				/******** Initialize Velocity Engine and Context ********/
				// get and initialize an engine
				VelocityEngine ve = new VelocityEngine();

				// create a context and add data
				VelocityContext context = new VelocityContext();
				context.put("map", valuesMap);

				/******** Replace Parameters in template message ********/

				messageStr = mailTemplate.getMessage();
				// render the template into a StringWriter
				StringWriter writer = new StringWriter();
				ve.evaluate(context, writer, "LOG", messageStr);
				// Get replaced Message
				messageStr = writer.toString();

				/************* Build Mail Message ****************/

				mailMessage.setMessage(messageStr);
				
				if (subjectValuesMap !=null){

					String subject = mailTemplate.getSubject();

					// get and initialize an engine
					ve = new VelocityEngine();

					// create a context and add data
					context = new VelocityContext();
					context.put("map", subjectValuesMap);

					/******** Replace Parameters in template subject ********/

					// render the template into a StringWriter
					StringWriter wrt = new StringWriter();
					ve.evaluate(context, wrt, "LOG", subject);
					// Get replaced Message
					subject = wrt.toString();

					mailMessage.setMailSubject(subject);
				}
				else {
					mailMessage.setMailSubject(mailTemplate.getSubject());
				}
				mailMessage.setMailStatus((long) IConstants.MAIL_STATUS_TYPE.NEW.ordinal());
				mailMessage.setCreatedDate(new Timestamp(Calendar.getInstance()
						.getTimeInMillis()));

				// Build mail address list
				List<MailAddress> mailAddressesList = new ArrayList<MailAddress>();
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getMailFrom(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.FROM)); // add From address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getMailTo(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.TO)); // add To address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate.getCc(),
						mailMessage, IConstants.MAIL_ADDRESS_TYPE.CC)); // add Cc address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getBcc(), mailMessage,	IConstants.MAIL_ADDRESS_TYPE.BCC)); // add Bcc address

				//add List to mailMessage
				mailMessage.setMailAddressList(mailAddressesList);

				/******** Add Mail Attachments *****/

				List<MailAttachment> attachmentsList = new ArrayList<MailAttachment>();
				for (Iterator iterator = mailAttachmentList.iterator(); iterator
				.hasNext();) {
					MailAttachment mailAttachment = (MailAttachment) iterator.next();
					mailAttachment.setMailMessage(mailMessage);
					attachmentsList.add(mailAttachment);
				}
				mailMessage.setMailAttachmentList(attachmentsList);

				/******** Send Mail Message ********/
				notifyByMail(mailMessage);
			}
		} catch (DAOException e) {
			throw new ServiceException("error.send.mail", e);
		} catch (ParseErrorException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (MethodInvocationException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (ResourceNotFoundException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (IOException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (Exception e) {
			throw new ServiceException("error.send.mail", e,new Object[] { templateId });
		}
	
	}

	/**
	 * Sends mail notifications from Predefined template. To, FROM,CC, BCC are
	 * stored as part of Template. This data is extracted from Mail_Template
	 * table and Mail message is created with Attachments
	 * 
	 * @param templateId
	 * @param valuesMap
	 * @param mailAttachmentList
	 * @throws ServiceException
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false)
	public void notifyByMailTemplateWithAttachment(Long templateId,
			Map<String, Object> valuesMap,
			List<MailAttachment> mailAttachmentList) throws ServiceException {
		MailMessage mailMessage = new MailMessage();
		String messageStr;
		try {
			// Fetch the mail Template
			MailTemplate mailTemplate = mailTemplateDAO.getById(templateId);
			if (mailTemplate != null) {

				/******** Initialize Velocity Engine and Context ********/
				// get and initialize an engine
				VelocityEngine ve = new VelocityEngine();

				// create a context and add data
				VelocityContext context = new VelocityContext();
				context.put("map", valuesMap);

				/******** Replace Parameters in template message ********/

				messageStr = mailTemplate.getMessage();
				// render the template into a StringWriter
				StringWriter writer = new StringWriter();
				ve.evaluate(context, writer, "LOG", messageStr);
				// Get replaced Message
				messageStr = writer.toString();

				/************* Build Mail Message ****************/

				mailMessage.setMessage(messageStr);
				mailMessage.setMailSubject(mailTemplate.getSubject());
				mailMessage.setMailStatus((long) IConstants.MAIL_STATUS_TYPE.NEW.ordinal());
				mailMessage.setCreatedDate(new Timestamp(Calendar.getInstance()
						.getTimeInMillis()));

				// Build mail address list
				List<MailAddress> mailAddressesList = new ArrayList<MailAddress>();
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getMailFrom(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.FROM)); // add From address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getMailTo(), mailMessage, IConstants.MAIL_ADDRESS_TYPE.TO)); // add To address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate.getCc(),
						mailMessage, IConstants.MAIL_ADDRESS_TYPE.CC)); // add Cc address
				mailAddressesList.addAll(fetchMailAddressList(mailTemplate
						.getBcc(), mailMessage,	IConstants.MAIL_ADDRESS_TYPE.BCC)); // add Bcc address

				//add List to mailMessage
				mailMessage.setMailAddressList(mailAddressesList);

				/******** Add Mail Attachments *****/

				List<MailAttachment> attachmentsList = new ArrayList<MailAttachment>();
				for (Iterator iterator = mailAttachmentList.iterator(); iterator
				.hasNext();) {
					MailAttachment mailAttachment = (MailAttachment) iterator.next();
					mailAttachment.setMailMessage(mailMessage);
					attachmentsList.add(mailAttachment);
				}
				mailMessage.setMailAttachmentList(attachmentsList);

				/******** Send Mail Message ********/
				notifyByMail(mailMessage);
			}
		} catch (DAOException e) {
			throw new ServiceException("error.send.mail", e);
		} catch (ParseErrorException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (MethodInvocationException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (ResourceNotFoundException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (IOException e) {
			throw new ServiceException("error.parse.template", e,new Object[] { templateId });
		} catch (Exception e) {
			throw new ServiceException("error.send.mail", e,new Object[] { templateId });
		}
	}

	/**
	 * Sends SMS notifications
	 * 
	 * @param smsMessage
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false)
	public void notifyBySMS(SmsMessage smsMessage) throws ServiceException {
		try {
			smsMessageDAO.save(smsMessage);
		} catch (DAOException e) {
			throw new ServiceException("error.send.sms", e, new Object[] {
					smsMessage.getId(), e.getMessage() });
		}
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false)
	public void sendExceptionNotification(final String exceptionMessage,
			long templateId) throws ServiceException {
		Map<String, Object> valuesMap = new HashMap<String, Object>();
		valuesMap.put("exceptionMessage", exceptionMessage);
		notifyByMailTemplate(templateId, valuesMap);

	}

	/**
	 * Create MailAddress Objects from commaSeparatedAddress and return
	 * MailAddress List
	 * @param commaSeparatedAddress
	 * @return
	 */
	private List<MailAddress> fetchMailAddressList(
			String commaSeparatedAddress, MailMessage mailMessage,
			IConstants.MAIL_ADDRESS_TYPE addressType) {
		List<MailAddress> mailAddressList = new ArrayList<MailAddress>();
		MailAddress mailAdddress = new MailAddress();

		// Split the commaSeparatedAddress into String Array
		String[] addressArray = StringUtils.split(commaSeparatedAddress, ',');
		//Build MailAddress objects and add to the list
		for (int i = 0; (addressArray != null && i < addressArray.length); i++) {
			mailAdddress = new MailAddress();
			mailAdddress.setAddressType((long) addressType.ordinal());
			mailAdddress.setMailAddress(addressArray[i]);
			mailAdddress.setMailMessage(mailMessage);
			mailAddressList.add(mailAdddress);
		}
		return mailAddressList;
	}
}
