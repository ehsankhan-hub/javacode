package com.bsf.ppm.batch.processor;

import com.bsf.ppm.Ppm_Inst_Transactions;
import com.bsf.ppm.exceptions.InstTransactionProcessorException;


/**
 * 
 * 
 * @author bsaleem
 *
 */
public interface InstTransactionProcessor extends InstProcessor{
	
	public void processMessage(Ppm_Inst_Transactions ppm_Inst_Transactions) throws InstTransactionProcessorException;

	public void processPosting(Ppm_Inst_Transactions ppm_Inst_Transactions) throws InstTransactionProcessorException;
 
}
