package com.bsf.ppm.batch;

import com.bsf.ppm.exceptions.InfrastructureException;

/**
 * Exception class for batch jobs
 * @author Rakesh
 *
 */
public class JobException extends InfrastructureException {

	/**
	 * Attribute serialVersionUID for serialization 
	 */
	private static final long serialVersionUID = 3684898032294330882L;

	/**
	 * @param message message to be displayed
	 * @param exception Exception Object
	 * @param params
	 */
	public JobException(String message, Exception exception, Object[] params) {
		super(message, exception, params);
	}
	
	/**
	 * @param message
	 * @param exception
	 */
	public JobException(String message, Exception exception) {
		super(message, exception);
	}	

}
