package com.bsf.ppm.batch.processor;

import org.apache.log4j.Logger;

import com.bsf.ipp.IPPUTIL;
import com.bsf.ppm.batch.JobException;
import com.bsf.ppm.batch.handler.JobHandler;
import com.bsf.ppm.dao.BatchJobDAO;

/**
 * Abstract implementation of processing unit of a batch job.
 * @author Rakesh
 *
 */
public abstract class AbstractJobProcessor implements JobProcessor {
	private static final Logger log = Logger.getLogger(AbstractJobProcessor.class);

	private BatchJobDAO batchJobDAO;
	protected JobHandler jobHandler;
	
	public void setJobHandler(JobHandler jobHandler) {
		this.jobHandler = jobHandler;
	}

	public JobHandler getJobHandler() {
		return jobHandler;
	}
	
	public BatchJobDAO getBatchJobDAO() {
		return batchJobDAO;
	}

	public void setBatchJobDAO(BatchJobDAO batchJobDAO) {
		this.batchJobDAO = batchJobDAO;
	}
	
	@Override
	public void processJob(Object... objects) throws JobException {
		JobHandler jh=null;
		try {
			jh = getJobHandler();
			jh.runJob();
		} catch (JobException e) {
			log.warn("Error while executing handler "+jh.getClass().getSimpleName(), e);
		}
		 catch (Exception e) {
			 e.printStackTrace();
				log.warn("Error while executing handler "+jh.getClass().getSimpleName()+":"+IPPUTIL.buildExceptionMessage(e));
			}
	}
}
