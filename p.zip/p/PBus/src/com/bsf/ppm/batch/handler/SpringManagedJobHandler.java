package com.bsf.ppm.batch.handler;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceException;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.orm.jpa.EntityManagerFactoryUtils;
import org.springframework.orm.jpa.EntityManagerHolder;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.bsf.ppm.batch.JobException;
import com.bsf.ppm.spring.SpringAppContext;

/**
 * Class for passing spring application context to the job handlers
 * @author Rakesh
 *
 */
public abstract class SpringManagedJobHandler extends AbstractJobHandler {
	
	private static final long serialVersionUID = -2817839024946026412L;
	private static final Logger log = Logger.getLogger(SpringManagedJobHandler.class);

	/* (non-Javadoc)
	 * @see com.bsf.ppm.batch.handler.AbstractJobHandler#runJob()
	 */
	@Override
	public void runJob() throws JobException {
		EntityManagerFactory emf = lookupEntityManagerFactory();
		boolean participate = false;
		if (TransactionSynchronizationManager.hasResource(emf)) {
			// Do not modify the EntityManager: just set the participate flag.
			participate = true;
		}
		//OpenSessionInViewFilter.DEFAULT_SESSION_FACTORY_BEAN_NAME;
		else {
			try {
				EntityManager em = createEntityManager(emf);
				TransactionSynchronizationManager.bindResource(emf, new EntityManagerHolder(em));
			}
			catch (PersistenceException ex) {
				throw new DataAccessResourceFailureException("Could not create JPA EntityManager", ex);
			}
		}
		try {
			runJobInContext();
		}  finally {
			if (!participate) {
				EntityManagerHolder emHolder = (EntityManagerHolder)
						TransactionSynchronizationManager.unbindResource(emf);
				EntityManagerFactoryUtils.closeEntityManager(emHolder.getEntityManager());
			}
		}
	}
	
	public abstract void runJobInContext() throws JobException;
	
	/**
	 * Look up the EntityManagerFactory that this filter should use.
	 * The default implementation looks for a bean with the specified name
	 * in Spring's root application context.
	 * @return the EntityManagerFactory to use
	 * @see #getEntityManagerFactoryBeanName
	 */
	protected EntityManagerFactory lookupEntityManagerFactory() {
//		return (EntityManagerFactory)getApplicationContext().getBean("entityManagerFactory");
		return (EntityManagerFactory)SpringAppContext.getBean("entityManagerFactory");
	}

	/**
	 * Create a JPA EntityManager to be bound to a request.
	 * <p>Can be overridden in subclasses.
	 * @param emf the EntityManagerFactory to use
	 * @see javax.persistence.EntityManagerFactory#createEntityManager()
	 */
	protected EntityManager createEntityManager(EntityManagerFactory emf) {
		return emf.createEntityManager();
	}


	
}
