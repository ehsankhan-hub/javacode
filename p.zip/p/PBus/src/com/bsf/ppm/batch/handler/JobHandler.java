package com.bsf.ppm.batch.handler;

import java.io.Serializable;

import com.bsf.ppm.batch.JobException;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.BackendSystem;

/**
 * Interface to specify handling unit of a job. All input output operations
 * business logic handling are performed by implementing classes.
 * @author Rakesh
 *
 */
public interface JobHandler extends Serializable {
	
	/**
	 * Method to perform job related operations
	 * @throws JobException
	 */
	public void runJob() throws JobException;
	/**
	 * Send mail after completion of the Handler Processing. This method is called from Job Listener
	 * If needed implement this in individual Job Handler 
	 * @throws Exception
	 */
	public void sendReportMail() throws ApplicationException;
	public void setBackendSystem(BackendSystem backendSystem);
	
	/** Setter for  processedItems
	 * @param processedItems
	 */
	public void setProcessedItems(Integer processedItems);
	/** Getter for processedItems
	 * @return processedItems
	 */
	public Integer getProcessedItems();
	/** Setter for successfullItems
	 * @param successfullItems
	 */
	public void setSuccessfullItems(Integer successfullItems);
	/** Gettter for successfullItems
	 * @return successfullItems
	 */
	public Integer getSuccessfullItems();
	/** Setter for failedItems
	 * @param failedItems
	 */
	public void setFailedItems(Integer failedItems);
	/** Getter for failedItems
	 * @return failedItems
	 */
	public Integer getFailedItems();

	
	
	
	
}
