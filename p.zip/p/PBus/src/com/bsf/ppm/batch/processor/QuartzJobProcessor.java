package com.bsf.ppm.batch.processor;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.bsf.ppm.batch.handler.JobHandler;
import com.bsf.ppm.batch.QuartzJob;

/**
 * Processing unit for a quartz job. 
 * Implementation is specific to Quartz scheduling framework
 * @author Ehsan
 *
 */
public class QuartzJobProcessor extends AbstractJobProcessor implements QuartzJob {
	/** 
	 * @see org.quartz.Job#execute(org.quartz.JobExecutionContext)
	 */
	public void execute(JobExecutionContext executionContext) throws JobExecutionException {
		try {
			// Fetch the Job Handler from JobDetail
			setJobHandler((JobHandler)executionContext.getJobDetail().getJobDataMap().get("jobHandler"));
			//call processJob
			processJob(executionContext);
		}
		catch(Exception ex){
			throw new JobExecutionException(ex);
		}
	}
}
