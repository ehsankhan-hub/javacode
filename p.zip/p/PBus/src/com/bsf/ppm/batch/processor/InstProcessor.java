package com.bsf.ppm.batch.processor;

import com.bsf.ppm.exceptions.InstTransactionProcessorException;


/**
 * 
 * 
 * @author bsaleem
 *
 */
public interface InstProcessor {
	
	public void processMessage(Long domainEntityId) throws InstTransactionProcessorException;

}
