package com.bsf.ppm.batch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.JobListener;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.bsf.ppm.batch.handler.AbstractJobHandler;
import com.bsf.ppm.batch.handler.JobHandler;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.dao.BatchJobDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.BatchJob;

/**
 * Class for storing batch execution contexts and running them. Batch jobs
 * defined as spring batch will be managed by spring's execution environment.
 * However, the scheduling of these jobs will be performed by this class.
 * 
 * @author Rakesh
 */
public class BatchExecutionManagerImpl implements BatchExecutionManager,
		ApplicationContextAware {
	private static final Logger log = Logger
			.getLogger(BatchExecutionManagerImpl.class);
	/**
	 * Attribute for passing application context to handlers
	 */
	private ApplicationContext applicationContext;

	/** Attribute batchJobDAO DAO for BatchJob Entity */
	private BatchJobDAO batchJobDAO;

	/** Attribute quartzScheduler scheduler for the batchJob */
	private Scheduler quartzScheduler;

	/** Attribute quartzScheduler scheduler for the batchJob */
	private JobListener globalJobListener;

	/** Attribute jobRegistry HashMap for storing all the jobs */
	private Map jobRegistry = new HashMap();

	/**
	 * Getter method for quartzScheduler
	 * 
	 * @return SchedulerFactoryBean reference
	 */
	public Scheduler getQuartzScheduler() {
		return quartzScheduler;
	}

	/**
	 * Setter method for quartzScheduler
	 * 
	 * @param quartzScheduler
	 *            SchedulerFactoryBean object
	 */
	public void setQuartzScheduler(Scheduler quartzScheduler) {
		this.quartzScheduler = quartzScheduler;
	}

	/**
	 * Getter method for BatchJobDAO
	 * 
	 * @return batchJobDAO
	 */
	public BatchJobDAO getBatchJobDAO() {
		return batchJobDAO;
	}

	/**
	 * Setter method for batchJobDAO
	 * 
	 * @param batchJobDAO
	 *            BatchJobDAO object
	 */
	public void setBatchJobDAO(BatchJobDAO batchJobDAO) {
		this.batchJobDAO = batchJobDAO;
	}

	/**
	 * @return the globalJobListener
	 */
	public JobListener getGlobalJobListener() {
		return globalJobListener;
	}

	/**
	 * @param globalJobListener
	 *            the globalJobListener to set
	 */
	public void setGlobalJobListener(JobListener globalJobListener) {
		this.globalJobListener = globalJobListener;
	}

	/**
	 * @return the jobRegistry
	 */
	public Map getJobRegistry() {
		return jobRegistry;
	}

	/**
	 * @param jobRegistry
	 *            the jobRegistry to set
	 */
	public void setJobRegistry(Map jobRegistry) {
		this.jobRegistry = jobRegistry;
	}

	/**
	 * @return the applicationContext
	 */
	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	/**
	 * @param applicationContext
	 *            the applicationContext to set
	 */
	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

	/**
	 * This method registers all jobs in the registry.
	 */
	public void registerAllJobs() {

		// Set the criteria for the Query to fetch ACTIVE jobs
		Map<String, Object> criterias = new HashMap<String, Object>();
		criterias.put("jobStatus", Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
		// Fetch the list of BatchJob s with the criteria
		List<com.bsf.ppm.BatchJob> batchJobList = null;
		try {
			batchJobList = batchJobDAO.findByCriteria(criterias);
		} catch (DAOException e) {
			log.warn("System failed to retrieve jobs data", e);
		}

		if (batchJobList != null) {
			for (com.bsf.ppm.BatchJob batchJob : batchJobList) {
				try {
					registerJob(batchJob);
				} catch (JobException e) {
					log.warn(e.getMessage());
				}

			}
		}
	}

	/**
	 * This method schedules and adds a new job identified by jobName into the
	 * job registry
	 * 
	 * @param jobName
	 */
	public void registerJobByName(String jobName) {

		// Set the criteria for the Query to fetch the Job identified by
		// jobName
		Map<String, Object> criterias = new HashMap<String, Object>();
		criterias.put("jobStatus", Long.valueOf(IConstants.STATUS_TYPE.ACTIVE
				.ordinal()));
		criterias.put("jobName", jobName);

		// Fetch Jobs matching the criteria
		List<com.bsf.ppm.BatchJob> batchJobList = null;
		try {
			batchJobList = batchJobDAO.findByCriteria(criterias);
		} catch (DAOException e) {
			log.warn("System failed to retrieve jobs data", e);
		}
		// Register the jobs fetched from the list
		if (batchJobList != null)
			for (com.bsf.ppm.BatchJob batchJob : batchJobList) {
				try {
					registerJob(batchJob);
				} catch (JobException e) {
					log.warn(e.getMessage());
				}
			}

	}

	/**
	 * This method schedules and adds a new job identified by id into the job
	 * registry
	 * 
	 * @param jobName
	 */
	public void registerJobById(Long jobId) {
		// Fetch the job
		BatchJob batchJob = null;
		try {
			batchJob = batchJobDAO.getById(jobId);
		} catch (DAOException e) {
			log.warn("System failed to retrieve jobs data", e);
		}
		// register the job
		if (batchJob != null) {
			try {
				registerJob(batchJob);
			} catch (JobException e) {
				log.warn(e.getMessage());
			}
		}
	}

	/**
	 * This method schedules and adds a new jobs identified by ids Array into
	 * the job registry
	 * 
	 * @param jobName
	 */
	public void registerJobByIds(String[] jobIds) {

		if (jobIds != null && jobIds.length > 0) {
			for (int i = 0; i < jobIds.length; i++) {
				// Register the individual Job
				registerJobById(Long.valueOf(jobIds[i]));
			}
		}
	}

	/**
	 * Schedules a job and adds it to the Job Registry
	 * 
	 * @param batchJob
	 *            batchJob to be scheduled
	 * @throws JobException
	 */
	public void registerJob(BatchJob batchJob) throws JobException {
		JobHandler jobHandler;
		String jobName = batchJob.getJobName();
		try {
			// Create JobProcesser Instance
			Class processorClass = Class.forName(batchJob.getProcessorClass());

			Class handlerClass = Class.forName(batchJob.getHandlerClass());
			jobHandler = (JobHandler) handlerClass.newInstance();

			// Set backend system information for configuration
			((AbstractJobHandler) jobHandler).setBackendSystem(batchJob
					.getBackendSystem());

			boolean isJobPresent = false;
			// Avoid running any job which is defined as external
			if (batchJob.getJobType() == IConstants.JOB_TYPE.INTERNAL.ordinal()) {

				// Fetch SchedulerFactoryBean instance
				Scheduler scheduler = getQuartzScheduler();
				// Global job listener added
				scheduler.addJobListener(globalJobListener);
				// Get the jobName
				// check if job is scheduled
				String[] jobNames = quartzScheduler
						.getJobNames(Scheduler.DEFAULT_GROUP);
				for (int i = 0; i < jobNames.length; i++) {
					if (jobName != null && jobName.equals(jobNames[i]))
						isJobPresent = true;
				}
				// Create Job Detail

				JobDetail jobDetail = new JobDetail();
				jobDetail.setRequestsRecovery(true);
				jobDetail.addJobListener("IppGlobalJobListener");
				jobDetail.setName(jobName);
				jobDetail.setJobClass(processorClass);
				jobDetail.getJobDataMap().put("jobHandler", jobHandler);

				// Create a Cron Trigger
				CronTrigger cronTrigger = new CronTrigger(batchJob.getJobName()
						+ "Trigger", Scheduler.DEFAULT_GROUP, batchJob
						.getCronSchedule());
				cronTrigger.setJobName(jobName);

				if (!isJobPresent) {
					// Schedule the job if not present
					scheduler.scheduleJob(jobDetail, cronTrigger);
					// Start scheduler
					scheduler.start();
				}

				// register jobDetail with jobRegistry
				jobRegistry.put(jobName, jobDetail);
			}
		} catch (Exception e) {
			throw new JobException("error.registerJob", e,
					new Object[] { jobName });
		}
	}

	/**
	 * Deletes jobs identified by name from Scheduler and also removes from the
	 * Job Registry
	 * 
	 * @param jobName
	 */
	public void removeJobByName(String jobName) {
		// Fetch Job Scheduler
		Scheduler scheduler = getQuartzScheduler();
		try {
			// Delete the job and trigger from the Scheduler
			scheduler.deleteJob(jobName, Scheduler.DEFAULT_GROUP);

			// Remove the job from registry
			jobRegistry.remove(jobName);
		} catch (SchedulerException e) {
			log.warn("System failed to remove job " + jobName);

		}
	}

	/**
	 * Deletes jobs identified by id from Scheduler and also removes from the
	 * Job Registry
	 * 
	 * @param jobName
	 */
	public void removeJobById(Long jobId) {

		BatchJob batchJob = null;
		// Fetch BatchJob
		try {
			batchJob = batchJobDAO.getById(jobId);
		} catch (DAOException e) {
			log.warn("System failed to retrieve job data " + jobId);
		}
		// Remove the job
		if (batchJob != null) {
			removeJob(batchJob);
		}

	}

	/**
	 * Deletes jobs identified by ids from Scheduler and also removes from the
	 * Job Registry
	 * 
	 * @param jobIds
	 *            array of Job Ids to be removed
	 */
	public void removeJobByIds(String[] jobIds) {
		if (jobIds != null && jobIds.length > 0) {
			for (int i = 0; i < jobIds.length; i++) {
				// Remove the individual Job
				removeJobById(Long.valueOf(jobIds[i]));
			}
		}
	}

	/**
	 * Removes the job from scheduler and also removes it from the Job Registry
	 * 
	 * @param batchJob
	 *            batchJob to be removed
	 */
	public void removeJob(BatchJob batchJob) {
		// Fetch Job Scheduler
		Scheduler scheduler = getQuartzScheduler();
		String jobName = batchJob.getJobName();
		try {
			// Delete the job and trigger from the Scheduler
			scheduler.deleteJob(jobName, Scheduler.DEFAULT_GROUP);
			// Remove the job from registry
			jobRegistry.remove(jobName);
		} catch (SchedulerException e) {
			log.warn("System failed to remove job " + jobName);
		}
	}

	//@Override
	public void releaseJobByName(String jobName) {
		// Fetch Job Scheduler
		Scheduler scheduler = getQuartzScheduler();
		try {
			// Delete the job and trigger from the Scheduler
			scheduler.deleteJob(jobName, Scheduler.DEFAULT_GROUP);
			scheduler.interrupt(jobName, Scheduler.DEFAULT_GROUP);
			
			// Remove the job from registry
			jobRegistry.remove(jobName);
		} catch (SchedulerException e) {
			log.warn("System failed to interrupt job " + jobName);

		}
	}
}
