package com.bsf.ppm.batch.processor;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;
import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;
import com.bsf.ppm.BackendSystem;
import com.bsf.ppm.LoanBlockDets;
import com.bsf.ppm.LoanInstalmentsDets;
import com.bsf.ppm.Ppm_Inst_Transactions;
import com.bsf.ppm.Ppm_Instructions;
import com.bsf.ppm.batch.process.PpmTrnsType;
import com.bsf.ppm.dao.InstTransactionsDAO;
import com.bsf.ppm.dao.InstructionDAO;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.InstTransactionProcessorException;
import com.bsf.ppm.fts.FTSResponsePostingEntity;
import com.bsf.ppm.spring.SpringAppContext;
import com.bsf.ppm.util.StringUtils;

/**
 * 
 * @author ehsan
 *
 */
@Transactional
public class InstTransactionProcessorImpl implements InstTransactionProcessor {

	private static final Logger logger = Logger.getLogger(InstTransactionProcessorImpl.class);
	
	private InstTransactionsDAO instTransactionsDAO;
	private boolean processFlag=false;
	private Cache backendSystemCache;
	private String status = "";
	private String ftsActionCode = "";
	private String cammActionCode = "";
	private String sourceSystem = "";
	private String trnsReference = "";
	private InstructionDAO instructionDAO;
	private int updateCount;
	private int countInstTrns;
	private int updCount=0;
	private LoanInstalmentsDets loanInstalmentsDets=null;
	
	public void setBackendSystemCache(Cache backendSystemCache) {
		this.backendSystemCache = backendSystemCache;
	}
	private BackendSystem getBackendByName(String backendName) {
		Element elem = backendSystemCache.get(backendName);
		if (elem != null) {
			return (BackendSystem) elem.getObjectValue();
		}
		return null;
	}
	
	public InstructionDAO getInstructionDAO() {
		instructionDAO = (InstructionDAO) SpringAppContext.getBean("instructionDAO");
		return instructionDAO;
	}
	
	PpmTrnsType ppmTrnsType=new PpmTrnsType();	

	public InstTransactionsDAO getInstTransactionsDAO() {
		return instTransactionsDAO;
	}
	public void setInstTransactionsDAO(InstTransactionsDAO instTransactionsDAO) {
		this.instTransactionsDAO = instTransactionsDAO;
	}
	@Override
	public void processMessage(Long domainEntityId) throws InstTransactionProcessorException {

	}

	@Override
	public void processMessage(Ppm_Inst_Transactions entity) throws InstTransactionProcessorException 
	{		 
		
		String score="0";
		logger.info("The LLS NtoNandNtoW flag value is :"+entity);		
		try{
			logger.info("getInstTransactionsDAO()---"+getInstTransactionsDAO());
			logger.info("entity.getInstRef()--"+entity.getInstRef());
			entity = getInstTransactionsDAO().getTrnsInstRef(entity.getInstRef());
            logger.info("Inst Reference---"+entity);
			
            if ("N".equals(entity.getStatus()))
			{
            logger.info("InstTransactionProcessorImpl-----");
			}
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	@Override
	public void processPosting(Ppm_Inst_Transactions instTrns) throws InstTransactionProcessorException 
	{
	FTSResponsePostingEntity fINUpdateResponse = null;	
	
		try{
		instTrns=getInstTransactionsDAO().getInstTransaction(instTrns.getPpmTrnsRef().trim());
		logger.info("Transaction Reference :"+instTrns.getPpmTrnsRef());
		logger.info("Ppm_Inst_Transactions table record status after picked "+instTrns.getStatus());
		if(instTrns!=null&&instTrns.getStatus().equals("1")){
		trnsReference =instTrns.getPpmTrnsRef();
		
		int count=0;	
		do{
		count++;
		logger.info("Tring to post Tuxedo count "+count);
		fINUpdateResponse=ppmTrnsType.tuxUpdateMRKI(instTrns, "",instTrns.getCammActionCode());
		logger.info("fINUpdateResponse-------"+fINUpdateResponse);
		if(count==4)
		
		break ;
		if(fINUpdateResponse!=null){
		processFlag=true;
		logger.info("(processPosting) ==> Tuxedo posting completed in "+count+" tries.");
		}
		
		}
		while(!processFlag);
		if(fINUpdateResponse!=null){
		cammActionCode=fINUpdateResponse.getCAMMActionCode();
	    ftsActionCode=fINUpdateResponse.getFTSActionCode();	
	    sourceSystem=fINUpdateResponse.getSourceSystem();
		
    	if(cammActionCode.trim().equals("0000")&&ftsActionCode.trim().equals("0000")){
    	String instRef=instTrns.getInstRef();
    	BigDecimal trnsAmount=instTrns.getTrnsAmount();
    	Ppm_Instructions instruction=getInstructionDAO().getById(instRef);
    	 
    	if(sourceSystem!=null&&instTrns!=null){
    	//instTrns.setStatus("P");
    	status="P";
    	logger.info("Trnsaction processed successfully for TransReference::"+instTrns.getPpmTrnsRef());
    	logger.info("Transaction status for this transaction::"+ " PROCESSESD");
    	logger.info("CAMM Action Code for this transaction::"+cammActionCode);
    	logger.info("FTS Action Code for this transaction::::"+ftsActionCode);
    	logger.info("SourceSystem for this transaction::::"+sourceSystem);
      
       	
    	//if SourceSystem is LLS and LOAN_INSTALMENTS_DETS TABLE updated successfully then update to PPM_INST_TRANSACTION TABLE 
       	
							if ((sourceSystem.trim().equals("LLS"))) {
								loanInstalmentsDets = getInstructionDAO()
										.getLoanInstallmentDets(instRef);
								logger.info("loanInstalmentsDets===="
										+ loanInstalmentsDets);
								if ((loanInstalmentsDets != null)) {

									updCount = getInstructionDAO()
											.updateLoanInstalmentsDets(loanInstalmentsDets);// updateEntityStatusByIds(trnsReference,
																			// "trnsRef",
																			// "status",
																			// "P");

									if (updCount == 1) {
										logger.info("Trying to update LOAN_INSTALMENTS_DETS and Ppm_Inst_Transactions table for instReference::"
												+ instTrns.getInstRef());
										logger.info("LOAN_INSTALMENTS_DETS table updated successfully for instReference::"
												+ instTrns.getInstRef());
										countInstTrns = getInstTransactionsDAO()
												.updateInstTransactions(
														instTrns,
														cammActionCode,
														ftsActionCode, status);
										// countInstTrns=0;
									} else {
										status = "E";
										getInstTransactionsDAO()
												.updateInstTransactions(
														instTrns,
														cammActionCode,
														ftsActionCode, status);
										logger.info("Trying to update LOAN_INSTALMENTS_DETS getting error--"
												+ updCount);
									}
    	
									logger.info("updateInstTransactions count==="
											+ countInstTrns);
									if (countInstTrns == 1&& instTrns.getTrnsType().trim().equals("MRKI")) {
										String branch = fINUpdateResponse
												.getInitBranch();
										String branchPadingSpace = StringUtils
												.padRightSpace(branch.trim(),
														6, " ");
										String trnsRef = instTrns
												.getPpmTrnsRef();
										String trnsRefPadingSpace = StringUtils
												.padRightSpace(trnsRef.trim(),
														13, " ");
										logger.info("trnsRefPadingSpace==="
												+ trnsRefPadingSpace);
										String debitAcct = instTrns
												.getDebitAcc();
										String transCrncy = instTrns
												.getDrActCrncy();
										logger.info("transCrncy from table="
												+ transCrncy);
										logger.info("debitAcct from table="
												+ debitAcct);
										String debitAcctWithPading = StringUtils
												.padLeft(debitAcct.trim(), 20,
														"0");
										Date valueDate = instTrns
												.getValueDate();
										logger.info("valueDate" + valueDate);
										LoanBlockDets loanBlockDets = new LoanBlockDets();
										loanBlockDets.getLoanBlockDetsCompPk()
												.setReference(
														instTrns.getInstRef());
										loanBlockDets.getLoanBlockDetsCompPk()
												.setAcctNumber(
														instTrns.getDebitAcc());
										loanBlockDets.setInstDate(instTrns
												.getValueDate());
										loanBlockDets.setAmount(instTrns
												.getTrnsAmount().toString());
										loanBlockDets
												.setBankBlckRef(branchPadingSpace
														+ trnsRefPadingSpace
														+ debitAcctWithPading);
										loanBlockDets
												.setBlockInitDate(new Timestamp(
														System.currentTimeMillis()));
										loanBlockDets
												.getLoanBlockDetsCompPk()
												.setCreatedDate(
														new Timestamp(
																System.currentTimeMillis()));
										loanBlockDets.setCreatedBy("PPMBATCH");
										getInstructionDAO()
												.insertLoanBlockDets(
														loanBlockDets);

										logger.info("LOAN_BLOCK_DETS table record insterted successfully for instReference::"
												+ instTrns.getInstRef());
										logger.info("Ppm_Inst_Transactions table updated successfully for instReference::"
												+ instTrns.getInstRef());
									}
									// Back in case of update failed on
									// LOAN_INSTALMENTS_DETS
									else if (countInstTrns != 1
											&& instTrns.getTrnsType().trim()
													.equals("MRKI")) {
										String branch = fINUpdateResponse
												.getInitBranch();
										String branchPadingSpace = StringUtils
												.padRightSpace(branch.trim(),
														6, " ");
										String trnsRef = instTrns
												.getPpmTrnsRef();
										String trnsRefPadingSpace = StringUtils
												.padRightSpace(trnsRef.trim(),
														13, " ");
										String debitAcct = instTrns
												.getDebitAcc();
										String debitAcctWithPading = StringUtils
												.padLeft(debitAcct.trim(), 20,
														"0");
										instTrns.setBlckReference(branchPadingSpace
												+ trnsRefPadingSpace
												+ debitAcctWithPading);
										fINUpdateResponse = ppmTrnsType
												.tuxUpdateMRKI(
														instTrns,
														"MRKM",
														instTrns.getCammActionCode());
										cammActionCode = fINUpdateResponse
												.getCAMMActionCode();
										if (cammActionCode.trim()
												.equals("0000")) {
											logger.info("MRKM for transtion reference ::"
													+ instTrns.getPpmTrnsRef()
													+ " Successfull");
											status = "N";
											cammActionCode = "MRKM";
											getInstTransactionsDAO()
													.updateInstTransactions(
															instTrns,
															cammActionCode,
															ftsActionCode,
															status);
											logger.info("MRKM Done successfully on Tuxedo");
										} else {
											status = "E";
											getInstTransactionsDAO()
													.updateInstTransactions(
															instTrns,
															cammActionCode,
															ftsActionCode,
															status);
											logger.info("MRKM for transtion reference ::"
													+ instTrns.getPpmTrnsRef()
													+ " Failed");
										}
										logger.info("LOAN_INSTALMENTS_DETS table not updated successfully for instReference::"
												+ instTrns.getInstRef());
										logger.info("LOAN_INSTALMENTS_DETS table update is failed it will not insert record in LOAN_BLOCK_DETS table");
										logger.info("Ppm_Inst_Transactions table not updated successfully for instReference::"
												+ instTrns.getInstRef());
									}
    	
    	
    	}
								if (loanInstalmentsDets == null) {
									// instTrns.setStatus("E");
									// status="E";
									updCount = 0;
									// updCount=getInstTransactionsDAO().updateInstTransactions(instTrns,cammActionCode,ftsActionCode,status);
									logger.info("No record found in LOAN_INSTALMENTS_DETS table for TransReference::"
											+ instTrns.getInstRef());
								}

							}

						}
					} else if (cammActionCode.trim().equals("7777")) {
						logger.info("CAMM action code found 7777 trying to Reversal for transtion reference ::"
								+ instTrns.getPpmTrnsRef());

						// Reversal for MRKI REV not supported using MRKM
						// instead of REV
						if (instTrns.getTrnsType().trim().equals("MRKI")) {
							String branch = fINUpdateResponse.getInitBranch();
							String branchPadingSpace = StringUtils
									.padRightSpace(branch.trim(), 6, " ");
							String trnsRef = instTrns.getPpmTrnsRef();
							String trnsRefPadingSpace = StringUtils
									.padRightSpace(trnsRef.trim(), 13, " ");
							String debitAcct = instTrns.getDebitAcc();
							String debitAcctWithPading = StringUtils.padLeft(
									debitAcct.trim(), 20, "0");
							instTrns.setBlckReference(branchPadingSpace
									+ trnsRefPadingSpace + debitAcctWithPading);
							fINUpdateResponse = ppmTrnsType.tuxUpdateMRKI(
									instTrns, "MRKM",
									instTrns.getCammActionCode());
						}

						if (fINUpdateResponse == null) {
							logger.info("Trying to call TUXEDO for Reversal getting network problem..."
									+ fINUpdateResponse);
						} else {

							cammActionCode = fINUpdateResponse
									.getCAMMActionCode();
							if (cammActionCode.trim().equals("0000")) {
								logger.info("Reversal for transtion reference ::"
										+ instTrns.getPpmTrnsRef()
										+ " Successfull");
								status = "N";
								cammActionCode = "MRKM";
								getInstTransactionsDAO()
										.updateInstTransactions(instTrns,
												cammActionCode, ftsActionCode,
												status);
							} else {
								status = "E";
								getInstTransactionsDAO()
										.updateInstTransactions(instTrns,
												cammActionCode, ftsActionCode,
												status);
								logger.info("Reversal for transtion reference ::"
										+ instTrns.getPpmTrnsRef() + " Failed");
							}
						}
					} else {
						status = "F";
						getInstTransactionsDAO()
								.updateInstTransactions(instTrns,
										cammActionCode, ftsActionCode, status);

						if ((sourceSystem.trim().equals("LLS"))) {
							loanInstalmentsDets = getInstructionDAO()
									.getLoanInstallmentDets(
											instTrns.getInstRef());
							logger.info("loanInstalmentsDets===="
									+ loanInstalmentsDets);
							if ((loanInstalmentsDets != null)) {

								// if posting fail updating LoanInstalment
								// Details table as blockFlat field N as
								// previous state
								updCount = getInstructionDAO().updateLoanInstalmentsDetsPostingFail(loanInstalmentsDets);// updateEntityStatusByIds(trnsReference,
																		// "trnsRef",
																		// "status",
																		// "P");
								logger.info("updCount====" + updCount);
								if (updCount == 1) {
									logger.info("Trying to update LOAN_INSTALMENTS_DETS table for instReference::"
											+ instTrns.getInstRef());
									logger.info("LOAN_INSTALMENTS_DETS table updated successfully for instReference::"
											+ instTrns.getInstRef());

								}
							}
						}
    	
    	logger.info("Trying to process Trnsaction getting error for TransReference::"+instTrns.getPpmTrnsRef());
	    logger.info("Transaction status for this transaction::"+ " FAIL");
	    logger.info("CAMM Action Code for this transaction::"+cammActionCode);
	    logger.info("FTS Action Code for this transaction::::"+ftsActionCode);
	    logger.info("SourceSystem for this transaction::::"+sourceSystem);
    	}
    	}
		else{
		status="N";	
	    getInstTransactionsDAO().updateInstTransactionsStatus(trnsReference,status);
	    logger.info("(processPosting) ==> Tuxedo posting failed in "+count+" tries.");
	    logger.info("Trying to post tuxedo getting network problem ::"+trnsReference);
	    logger.info("Transaction status for this transaction::"+ " FAIL");
	    logger.info("Tring to call Tuxedo getting network error :"+fINUpdateResponse);
		}
		
		}
		else{
		logger.info("Batch is trying to post incorrect record status is not 1 which is changed after picked");	
		}
		}
		catch(Exception ex){
			ex.printStackTrace();
			logger.error("Ecception occured===="+ex.getMessage());
			String branch=fINUpdateResponse.getInitBranch();
	        String branchPadingSpace=StringUtils.padRightSpace(branch.trim(), 6, " ");
	        String trnsRef=instTrns.getPpmTrnsRef();
	        String trnsRefPadingSpace=StringUtils.padRightSpace(trnsRef.trim(), 13, " ");
	        String debitAcct=instTrns.getDebitAcc();
	        String debitAcctWithPading=StringUtils.padLeft(debitAcct.trim(), 20, "0");
	        instTrns.setBlckReference(branchPadingSpace+trnsRefPadingSpace+debitAcctWithPading);
	    	try{
	    	fINUpdateResponse=ppmTrnsType.tuxUpdateMRKI(instTrns,"MRKM",instTrns.getCammActionCode());	
	    	if(fINUpdateResponse!=null){
	    	if(fINUpdateResponse.getCAMMActionCode().trim().equals("0000")){
	        logger.info("MRKM for transtion reference ::"+instTrns.getPpmTrnsRef()+ " Successfull");		
	        status="N";	
	        cammActionCode="MRKM";
	        getInstTransactionsDAO().updateInstTransactions(instTrns,cammActionCode,ftsActionCode,status);		
	        logger.info("MRKM Done successfully on Tuxedo");
	        }
	        else{
	        status="E";	
	        getInstTransactionsDAO().updateInstTransactions(instTrns,cammActionCode,ftsActionCode,status);	
	        logger.info("MRKM for transtion reference ::"+instTrns.getPpmTrnsRef()+ " Failed");	
	        }
	    	}
	    	else{
	    	logger.info("Trying to call TUXEDO for MRKM getting network problem..."+fINUpdateResponse);		
	    	}
	    	}
	    	catch(ApplicationException ape){
	    	ape.printStackTrace();
	    	logger.info("error occured--"+ape.getMessage());
	    	}
	        logger.info("LOAN_INSTALMENTS_DETS table not updated successfully for instReference::");	
	    	logger.info("LOAN_INSTALMENTS_DETS table update is failed it will not insert LOAN_BLOCK_DETS table");
	    	logger.info("Ppm_Inst_Transactions table not updated successfully for instReference::"+instTrns.getInstRef());
		}
		
	}
	
	
	
}
