package com.bsf.ppm.batch.notification.exception;

import com.bsf.ppm.exceptions.InfrastructureException;

public class NotificationException  extends InfrastructureException{

	public NotificationException(String key, Exception x) {
		super(key, x);
	}
	public NotificationException(String message) {
		super(message);
	}

	public NotificationException(String key,Exception x, Object[] objects) {
		super(key,x,objects);
	}


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
