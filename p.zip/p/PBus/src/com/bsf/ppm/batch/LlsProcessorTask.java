package com.bsf.ppm.batch;

import javax.persistence.OptimisticLockException;

import org.apache.log4j.Logger;


import com.bsf.ppm.Ppm_Inst_Transactions;
import com.bsf.ppm.batch.processor.InstTransactionProcessor;
import com.bsf.ppm.dao.InstTransactionsDAO;
import com.bsf.ppm.service.posting.FTSPostingService;
import com.bsf.ppm.spring.SpringAppContext;

public class LlsProcessorTask  implements Runnable {
	private static final Logger log = Logger.getLogger(LlsProcessorTask.class);

	private String task;
	private Ppm_Inst_Transactions  ppm_Inst_Transactions;
	private InstTransactionsDAO instTransactionsDAO;
    private FTSPostingService ftsPostingService;
    private InstTransactionProcessor instTransactionProcessor;
    
	public InstTransactionsDAO getInstTransactionsDAO() {
		instTransactionsDAO = (InstTransactionsDAO) SpringAppContext.getBean("instTransactionsDAO");
		
		return instTransactionsDAO;
	}
    
	public void setInstTransactionsDAO(InstTransactionsDAO instTransactionsDAO) {
		this.instTransactionsDAO = instTransactionsDAO;
	}
	
	
	public LlsProcessorTask(Ppm_Inst_Transactions  ppm_Inst_Transactions, String task){
		this.ppm_Inst_Transactions=ppm_Inst_Transactions;
		this.task = task;
	}
	
	 public InstTransactionProcessor getInstTransactionProcessor() {
		 if (instTransactionProcessor == null)
			 instTransactionProcessor = (InstTransactionProcessor) SpringAppContext
				.getBean("instTransactionProcessor");
		 return instTransactionProcessor;
	}

	public void setInstTransactionProcessor(
			InstTransactionProcessor instTransactionProcessor) {
		this.instTransactionProcessor = instTransactionProcessor;
	}

	public FTSPostingService getFtsPostingService() {
		if (ftsPostingService == null)
			ftsPostingService = (FTSPostingService)SpringAppContext
			.getBean("ftsInterface");
		return ftsPostingService;
	}

	
	public void run() {
		try{
			if ("Process".equalsIgnoreCase(task)){
				if ("MRKI".equals(ppm_Inst_Transactions.getTrnsType())){
                  
					getInstTransactionProcessor().processMessage(ppm_Inst_Transactions);
				}
			}
			else {
				getInstTransactionProcessor().processPosting(ppm_Inst_Transactions);
			}
        

		}catch(Throwable ex) {
			Exception ex1 = new Exception(ex);
			while (ex!=null && ex.getCause() !=null ){
				if ( ex.getCause() instanceof OptimisticLockException){
					//log.warn("xxxxxxx=====================================================================================================");
					//log.warn("Ignoring another thread processed it "+itmsPaymentTransaction.getMessageStatus()+",ID:"+itmsPaymentTransaction.getId());
					//log.warn("======================================================================================================");

					return;
				}
				ex=ex.getCause();
			}
			//log.warn("System failed to process message ",ex);
			/*try {
				getItmsProcessExceptionHandlerService().handleException(ex1, itmsPaymentTransaction);
			}catch (ApplicationException e) {				
			}	*/
		}	

	}

}

