package com.bsf.ppm.batch.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.security.concurrent.SessionInformation;
import org.springframework.security.concurrent.SessionRegistry;
import org.springframework.security.concurrent.SessionRegistryImpl;
import org.springframework.security.ui.session.HttpSessionDestroyedEvent;
import org.springframework.util.Assert;

/**
 * 
 * @author bsaleem
 *
 */

public class CustomSessionRegistryImpl  implements SessionRegistry, ApplicationListener {
   //~ Static fields/initializers =====================================================================================

   protected static final Log logger = LogFactory.getLog(SessionRegistryImpl.class);

   // ~ Instance fields ===============================================================================================

	public Map<String, Set<String>> getAppIds() {
		return appIds;
	}
	private Map principals = Collections.synchronizedMap(new HashMap()); // <principal:Object,SessionIdSet>
	private Map sessionIds = Collections.synchronizedMap(new HashMap());
	private Map<String,Set<String>> appIds = Collections.synchronizedMap(new HashMap<String,Set<String>>());// <sessionId:String>

	// ~ Methods =======================================================================================================

	public Object[] getAllPrincipals() {
		return principals.keySet().toArray();
	}

	public SessionInformation[] getAllSessions(Object principal, boolean includeExpiredSessions) {
		Set sessionsUsedByPrincipal = (Set) principals.get(principal);

       if (sessionsUsedByPrincipal == null) {
			return null;
		}

		List list = new ArrayList();

       synchronized (sessionsUsedByPrincipal) {
			for (Iterator iter = sessionsUsedByPrincipal.iterator(); iter.hasNext();) {
				String sessionId = (String) iter.next();
				SessionInformation sessionInformation = getSessionInformation(sessionId);

               if (sessionInformation == null) {
                   continue;
               }

               if (includeExpiredSessions || !sessionInformation.isExpired()) {
					list.add(sessionInformation);
				}
			}
		}

		return (SessionInformation[]) list.toArray(new SessionInformation[] {});
	}

	public SessionInformation getSessionInformation(String sessionId) {
		Assert.hasText(sessionId, "SessionId required as per interface contract");

		return (SessionInformation) sessionIds.get(sessionId);
	}

	public void onApplicationEvent(ApplicationEvent event) {
		if (event instanceof HttpSessionDestroyedEvent) {
			String sessionId = ((HttpSession) event.getSource()).getId();
			removeSessionInformation(sessionId);
		}
	}

	public void refreshLastRequest(String sessionId) {
		Assert.hasText(sessionId, "SessionId required as per interface contract");

		SessionInformation info = getSessionInformation(sessionId);

		if (info != null) {
			info.refreshLastRequest();
		}
	}

	public synchronized void registerNewSession(String sessionId, Object principal) {
		Assert.hasText(sessionId, "SessionId required as per interface contract");
		Assert.notNull(principal, "Principal required as per interface contract");

       if (logger.isDebugEnabled()) {
           logger.debug("Registering session " + sessionId +", for principal " + principal);
       }

       if (getSessionInformation(sessionId) != null) {
			removeSessionInformation(sessionId);
		}

       sessionIds.put(sessionId, new SessionInformation(principal, sessionId, new Date()));

       Set sessionsUsedByPrincipal = (Set) principals.get(principal);

		if (sessionsUsedByPrincipal == null) {
			sessionsUsedByPrincipal = Collections.synchronizedSet(new HashSet(4));
           principals.put(principal, sessionsUsedByPrincipal);
       }

		sessionsUsedByPrincipal.add(sessionId);
	}

	public void removeSessionInformation(String sessionId) {
		Assert.hasText(sessionId, "SessionId required as per interface contract");

		SessionInformation info = getSessionInformation(sessionId);

		if (info == null) {
           return;
       }

       if (logger.isDebugEnabled()) {
           logger.debug("Removing session " + sessionId + " from set of registered sessions");
       }

       sessionIds.remove(sessionId);
       appIds.remove(sessionId);
       Set sessionsUsedByPrincipal = (Set) principals.get(info.getPrincipal());

       if (sessionsUsedByPrincipal == null) {
           return;
       }

       if (logger.isDebugEnabled()) {
           logger.debug("Removing session " + sessionId + " from principal's set of registered sessions");
       }
       
       synchronized (sessionsUsedByPrincipal) {
           sessionsUsedByPrincipal.remove(sessionId);

           if (sessionsUsedByPrincipal.size() == 0) {
               // No need to keep object in principals Map anymore
               if (logger.isDebugEnabled()) {
                   logger.debug("Removing principal " + info.getPrincipal() + " from registry");
               }
               principals.remove(info.getPrincipal());
           }
       }
	}
	
	public synchronized void setAppIds(String sessionId,Set apps)	{
		
		appIds.put(sessionId, apps);
		
	}
}
