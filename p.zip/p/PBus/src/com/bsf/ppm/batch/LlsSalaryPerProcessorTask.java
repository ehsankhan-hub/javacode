package com.bsf.ppm.batch;

import javax.persistence.OptimisticLockException;

import org.apache.log4j.Logger;


import com.bsf.ppm.Ppm_Inst_Transactions;
import com.bsf.ppm.batch.processor.InstAllowedSalaryPercentTransactionProcessor;
import com.bsf.ppm.batch.processor.InstTransactionProcessor;
import com.bsf.ppm.dao.InstTransactionsDAO;
import com.bsf.ppm.service.posting.FTSPostingService;
import com.bsf.ppm.spring.SpringAppContext;

public class LlsSalaryPerProcessorTask  implements Runnable {
	private static final Logger log = Logger.getLogger(LlsSalaryPerProcessorTask.class);

	private String task;
	private Ppm_Inst_Transactions  ppm_Inst_Transactions;
	private InstTransactionsDAO instTransactionsDAO;
    private FTSPostingService ftsPostingService;
    private InstAllowedSalaryPercentTransactionProcessor instAllowedSalaryPercentTransProcessor;
    
	public InstTransactionsDAO getInstTransactionsDAO() {
		instTransactionsDAO = (InstTransactionsDAO) SpringAppContext.getBean("instTransactionsDAO");
		System.out.println("instTransactionsDAO Object from springContainer=="		+ instTransactionsDAO.toString());
		return instTransactionsDAO;
	}
    
	public void setInstTransactionsDAO(InstTransactionsDAO instTransactionsDAO) {
		this.instTransactionsDAO = instTransactionsDAO;
	}
	
	
	public LlsSalaryPerProcessorTask(Ppm_Inst_Transactions  ppm_Inst_Transactions, String task){
		this.ppm_Inst_Transactions=ppm_Inst_Transactions;
		this.task = task;
	}
	
	 public InstAllowedSalaryPercentTransactionProcessor getInstAllowedSalaryPercentTransProcessor() {
		if(instAllowedSalaryPercentTransProcessor==null)
		instAllowedSalaryPercentTransProcessor=(InstAllowedSalaryPercentTransactionProcessor)SpringAppContext
		.getBean("instAllowedSalaryPercentTransProcessor");
		 
		 return instAllowedSalaryPercentTransProcessor;
	}

	public void setInstAllowedSalaryPercentTransProcessor(
			InstAllowedSalaryPercentTransactionProcessor instAllowedSalaryPercentTransProcessor) {
		this.instAllowedSalaryPercentTransProcessor = instAllowedSalaryPercentTransProcessor;
	}

	
	public FTSPostingService getFtsPostingService() {
		if (ftsPostingService == null)
			ftsPostingService = (FTSPostingService)SpringAppContext
			.getBean("ftsInterface");
		return ftsPostingService;
	}

	
	public void run() {
		try{
			if ("Process".equalsIgnoreCase(task)){
				if ("MRKI".equals(ppm_Inst_Transactions.getTrnsType())){
                    System.out.println("Run method count---");
                    getInstAllowedSalaryPercentTransProcessor().processMessage(ppm_Inst_Transactions);
				}
			}
			else {
				getInstAllowedSalaryPercentTransProcessor().processPosting(ppm_Inst_Transactions);
			}
        

		}catch(Throwable ex) {
			Exception ex1 = new Exception(ex);
			while (ex!=null && ex.getCause() !=null ){
				if ( ex.getCause() instanceof OptimisticLockException){
					//log.warn("xxxxxxx=====================================================================================================");
					//log.warn("Ignoring another thread processed it "+itmsPaymentTransaction.getMessageStatus()+",ID:"+itmsPaymentTransaction.getId());
					//log.warn("======================================================================================================");

					return;
				}
				ex=ex.getCause();
			}
			//log.warn("System failed to process message ",ex);
			/*try {
				getItmsProcessExceptionHandlerService().handleException(ex1, itmsPaymentTransaction);
			}catch (ApplicationException e) {				
			}	*/
		}	

	}

}

