package com.bsf.ppm.batch.processor;

import com.bsf.ppm.batch.JobException;
import com.bsf.ppm.batch.handler.JobHandler;
import com.bsf.ppm.batch.BatchRunJob;

/**
 * Interface for providing batch job management activities
 * before running it. 
 * @author Rakesh
 */
public interface JobProcessor extends BatchRunJob {
	/**
	 * Dependency injection for the job handler, which will handle the job
	 * @param jobHandler
	 */
	public void setJobHandler(JobHandler jobHandler);
	/**
	 * Processes a batch job with the information passed through its parameters 
	 * @param objects
	 */
	public void processJob(Object... objects) throws JobException;
}
