package com.bsf.ppm.batch;

import java.util.Map;

import com.bsf.ppm.BatchJob;

/**
 * Interface for BatchExecution
 * @author Zakir
 *
 */
public interface BatchExecutionManager {

	/**
	 * This method registers all jobs in the registry.
	 */
	public void registerAllJobs();

	
	/**
	 * This method schedules and adds a new job identified by jobName into the job registry
	 * @param jobName
	 */
	public void registerJobByName(String jobName);

	/**
	 * This method schedules and adds a new job identified by id into the job registry
	 * @param jobName
	 */
	public void registerJobById(Long jobId);

	/**
	 * This method schedules and adds a new jobs identified by ids Array into the job registry
	 * @param jobName
	 */
	public void registerJobByIds(String[] jobIds);
	
	/**
	 * Schedules a job and adds it to the Job Registry
	 * @param batchJob  batchJob to be scheduled
	 * @throws JobException
	 */
	public void registerJob(BatchJob batchJob) throws JobException;
	
	/**
	 * Deletes jobs identified by name from Scheduler and also removes from the Job Registry
	 * @param jobName
	 */
	public void removeJobByName(String jobName);

	/**
	 * Deletes jobs identified by id from Scheduler and also removes from the Job Registry
	 * @param jobName
	 */
	public void removeJobById(Long jobId);

	/**
	 * Deletes jobs identified by ids from Scheduler and also removes from the Job Registry
	 * @param jobIds array of Job Ids to be removed 
	 */
	public void removeJobByIds(String[] jobIds);
	
	/**
	 * Removes the job from scheduler and also removes it from the Job Registry
	 * @param batchJob  batchJob to be removed
	 */
	public void removeJob(BatchJob batchJob);
	
	/**
	 * getter for jobRegistry
	 * @return Map Job Registry
	 */
	public Map getJobRegistry();

	/**
	 * Release or Interrupt jobs identified by name from Scheduler
	 * @param jobName
	 */
	public void releaseJobByName(String jobName);
}
