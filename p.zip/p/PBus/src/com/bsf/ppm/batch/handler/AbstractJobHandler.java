package com.bsf.ppm.batch.handler;

import com.bsf.ppm.batch.JobException;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.BackendSystem;

/**
 * Abstract class for all job handlers.
 * It provides back end system configuration for implementing classes
 * @author Rakesh
 *
 */
public abstract class AbstractJobHandler implements JobHandler {
	
	protected Integer processedItems;
	protected Integer successfullItems;
	protected Integer failedItems;
	protected BackendSystem backendSystem;
	
	public BackendSystem getBackendSystem() {
		return backendSystem;
	}

	public void setBackendSystem(BackendSystem backendSystem) {
		this.backendSystem = backendSystem;
	}

	/**
	 * @return the processedItems
	 */
	public Integer getProcessedItems() {
		return processedItems;
	}

	/**
	 * @param processedItems the processedItems to set
	 */
	public void setProcessedItems(Integer processedItems) {
		this.processedItems = processedItems;
	}

	/**
	 * @return the successfullItems
	 */
	public Integer getSuccessfullItems() {
		return successfullItems;
	}

	/**
	 * @param successfullItems the successfullItems to set
	 */
	public void setSuccessfullItems(Integer successfullItems) {
		this.successfullItems = successfullItems;
	}

	/**
	 * @return the failedItems
	 */
	public Integer getFailedItems() {
		return failedItems;
	}

	/**
	 * @param failedItems the failedItems to set
	 */
	public void setFailedItems(Integer failedItems) {
		this.failedItems = failedItems;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.batch.handler.JobHandler#sendReportMail()
	 */
	public void sendReportMail() throws ApplicationException {
	}
	
	public abstract void runJob() throws JobException;
}
