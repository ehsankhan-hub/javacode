package com.bsf.ppm.fts.integration;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.Calendar;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import sun.io.CharToByteCp1256;

import com.bsf.ipp.GeneralConfiguration;
import com.bsf.ppm.FtsPostingLog;
import com.bsf.ppm.dao.FtsPostingLogDAO;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.exceptions.FTSRequestTimeoutException;
import com.bsf.ppm.exceptions.InCorrectDataException;
import com.bsf.ppm.exceptions.InfrastructureException;
import com.bsf.ppm.exceptions.InvalidDataException;
import com.bsf.ppm.fts.AccountInquiryRequest;
import com.bsf.ppm.fts.AccountInquiryResponse;
import com.bsf.ppm.jpa.util.BackendUtil;
import com.bsf.ppm.net.util.Connection;
import com.bsf.ppm.net.util.PPMSocketPool;
import com.bsf.ppm.net.util.PPMSocketPoolFactory;
import com.bsf.ppm.net.util.PPMSocketPoolImpl;
import com.bsf.ppm.service.posting.FTSPostingService;
import com.bsf.ppm.service.posting.FTSPostingServiceImpl;

/**
 * Implementation Class for FTSInterface. Creates socket and communicates with
 * FTS - Tuxedo
 * 
 * @author Hussain
 * @author Mamdouh
 */
public class FTSInterfaceImpl implements FTSInterface {

	private static final Logger log = Logger.getLogger("com.bsf.ppm.tuxedo");
	boolean init=false;
	private PPMSocketPool ppmSocketPool;
	private Cache generalConfigurationCache;

	public Cache getGeneralConfigurationCache() {
		return generalConfigurationCache;
	} 
	public void setGeneralConfigurationCache(Cache generalConfigurationCache) {
		this.generalConfigurationCache = generalConfigurationCache;
	}

	public PPMSocketPool getPpmSocketPool() {
		return ppmSocketPool;
	}
	public void setPpmSocketPool(PPMSocketPool ppmSocketPool) {
		this.ppmSocketPool = ppmSocketPool;
	}


	/** Attribute ftsPostingLogDAO to access FtsPostingLog */
	private FtsPostingLogDAO ftsPostingLogDAO;

	public void setFtsPostingLogDAO(FtsPostingLogDAO ftsPostingLogDAO) {
		this.ftsPostingLogDAO = ftsPostingLogDAO;
	}

	public FtsPostingLogDAO getFtsPostingLogDAO() {
		return ftsPostingLogDAO;
	}	

	@SuppressWarnings("deprecation")
	@Override
	public String sendMessage(String message,String applicationId, boolean insertLog,String ftsRef) throws DAOException,
	ApplicationException {		
		Connection conn = null;
		String ftsReference="";
		Socket socket = null;
		StringBuffer responseMessage = new StringBuffer();
		FtsPostingLog ftsPostingLog = new FtsPostingLog();
		ftsPostingLog.setApplicationId(applicationId);
		try {
			//log.info("Thread ::"+Thread.currentThread().getId()+" waiting to get port....................");
			conn = ppmSocketPool.getSocketConnection();
			/************** Build FTS Message ************/
            log.info("Trying to get connection==="+conn);
			//Prefix 4 digits of message length to the ftsMessage
			DecimalFormat decimalFormat = new DecimalFormat("0000");			
			String ftsMessage = decimalFormat.format((long)message.length()) + message;

			//Replace \n \t \r \f characters with spaces
			ftsMessage = StringUtils.replace(ftsMessage, "\r\n", "  ");
			ftsMessage = StringUtils.replaceChars(ftsMessage, '\r', ' ');
			ftsMessage = StringUtils.replaceChars(ftsMessage, '\n', ' ');
			ftsMessage = StringUtils.replaceChars(ftsMessage, '\t', ' ');
			ftsMessage = StringUtils.replaceChars(ftsMessage, '\f', ' ');

			ftsReference = ftsMessage.substring(29,39);
			/************** Build Socket and IO Objects ************/

			// Create Socket with fts Backend system
			/*Socket socket = createSocket(BackendUtil.getParameterValue(backendSystem,
			"fts.system.ip"), BackendUtil.getParameterValue(
					backendSystem, "fts.port"));*/
			//log.info("Thread ::"+Thread.currentThread().getId()+" Getting the socket connection &&&&&&&&&&&&&&&&: ");
			socket = conn.getSocket();
			//log.info("Thread ::"+Thread.currentThread().getId()+" The socket connection &&&&&&&&&&&&&&&&: " + socket);			
			//socket.setSoTimeout(40000);
			log.info("Trying to get socket==="+socket);
			CharToByteCp1256 cp = new CharToByteCp1256(); 
			byte []msg = cp.convertAll(ftsMessage.toCharArray());
			OutputStream osr = socket.getOutputStream(); 
			PrintStream pStream = new PrintStream(osr,true);
			//InputStreamReader is = new InputStreamReader(socket.getInputStream()); 
			log.info("socket.getInputStream()"+socket.getInputStream());
			BufferedInputStream socketIn = new BufferedInputStream(socket.getInputStream(), 1024);

			/*************** Send FTS Message **************/
			//commented out due to problem in sending arabic characters with character stream.
			//socketOut.println(ftsMessage);
			//System.out.println(ftsMessage);

			pStream.write(msg);
			//log.info("Thread ::"+Thread.currentThread().getId()+" has written message to port::"+conn.getSocket().getPort()+":: FTS Ref::"+ ftsMessage.substring(29,39));
			log.info("|Request<"+ftsReference+">:Socket="+socket.toString()+":"+ftsMessage+"|");
			// Set Fts Log entries
			ftsPostingLog.setMessageSentTime(new Timestamp(Calendar
					.getInstance().getTimeInMillis()));	
			ftsPostingLog.setFtsMessageSent(ftsMessage);

			/*************** Read FTS Message Received *******/

			// Read text received
			/*byte[] textData = new byte[1024];

			int size = 0;
			do {
				size = socketIn.read(textData);
				responseMessage.append(new String(textData, 0, size));
			} while (size == 1024);*/
			
			/** ISSUE :
			 * The data of Response is missing over the socket due to some network or socket issues due to which the application
			 * behaviour is changing and all the other transactions is affecting due to mismatch responses.
			 * If the issues persists or complete response is not been receiving then the missing response is being
			 * assigned to other socket request or to other requested thread due to which the response is assigned to
			 * other request.  
			 * 
			 * RESOLUTION :
			 * Reading FTS Response over the sockets implementation is modified to read all the data required for response.
			 * The data over the socket is read as per length sent by FTS response.
			 * The method will read all the number of required bytes of data length, 
			 * assuming the length is first four digits values received from FTS response. 
			 * */
			
			int preLength = 4;		 // Number of Predefined digits for value of response message length.
			byte[] readData;		 // Variable to store bytes/data of response message. 
			int maxLength = 0;		 // Variable is used to validate the length of required data received.
			int socketSize = 0;		 // Variable to store length of data/bytes read from socket.
			int totalLength = 0;	 // Variable to store the integer value of response length.
			int preLengthSize = 0;	 // Variable to store the length of response message.
			byte[] responseSize = new byte[preLength]; // Variable to store data/bytes read from socket for message length.
			StringBuffer responseLength = new StringBuffer();
			preLengthSize = socketIn.read(responseSize, 0, preLength);
			totalLength = Integer.parseInt(responseLength.append(new String(responseSize, 0, preLengthSize)).toString());
			maxLength = totalLength;
			
			while (socketSize < maxLength) {
				maxLength = maxLength - socketSize;
				readData = new byte[maxLength];
				socketSize = socketIn.read(readData, 0, maxLength);
				responseMessage.append(new String(readData, 0, socketSize));
			}
			
			//log.info("Thread ::"+Thread.currentThread().getId()+" has received message from port::"+conn.getSocket().getPort()+":: FTS Ref::"+ responseMessage.substring(29,39));
			log.info("|Respnse<"+ftsReference+">:Socket="+socket.toString()+":"+responseLength.toString()+responseMessage.toString()+"|");
			// Set Fts Log entries
			ftsPostingLog.setMessageReceivedTime(new Timestamp(Calendar
					.getInstance().getTimeInMillis()));
			ftsPostingLog.setFtsMessageRecieved(responseMessage.toString());
			ftsPostingLog.setFtsReference(ftsRef);

			//socketIn.close();
			//socket.close();
			//conn.returnToPool();
			GeneralConfiguration generalConfiguration = null;
			// Save Fts Log
			try {
				/*if (insertLog)
					saveFtsPostingLog(ftsPostingLog);
				else {*/
				generalConfiguration =  getGeneralConfigByName("COREGeneralConfiguration");		
				String logAcctInquiry = BackendUtil.getGeneralConfigParameterValue(generalConfiguration, "LogFTSAcctInquiryToDB");

				if (insertLog && "Y".equalsIgnoreCase(logAcctInquiry)){
					saveFtsPostingLog(ftsPostingLog);
				}
				//}
			} catch (DAOException e) {
				log.error("|Error<"+ftsReference+">:Socket="+socket.toString()+":"+responseMessage.toString()+"|"+e.toString()+"|");
			}			
		} 
		catch (java.net.SocketTimeoutException ste) {
			ste.printStackTrace();
			log.error("|Error<"+ftsReference+">:Socket="+socket.toString()+":"+responseMessage.toString()+"|"+ste.toString()+"|");
			if(conn!=null){
				log.error("Trying to close Connection");	
				conn.close();
				log.error("Connection closed:");
				}
			throw new FTSRequestTimeoutException();
		}
		catch (IOException e) {
			log.error("|Error<"+ftsReference+">:Socket="+socket.toString()+":"+responseMessage.toString()+"|"+e.toString()+"|");
			
			if(conn!=null){
			log.error("Trying to close Connection");	
			conn.close();
			log.error("Connection closed:");
			}
			
			throw new InfrastructureException("error.fts.io");
		}
		catch (Exception e) {
			log.error("|Error<"+ftsReference+">:Socket="+socket.toString()+":"+responseMessage.toString()+"|"+e.toString()+"|");
			if(conn!=null){
			log.error("Trying to close Connection");	
			conn.close();
			log.error("Connection closed:");
			}
			throw new InCorrectDataException("error.invalid.data",e);
		}
		finally{
		if(conn!=null){
		conn.returnToPool();	
		}
		}
		// Return response message removing 4 characters that specify length
		//return responseMessage.substring(4).toString();
		return responseMessage.toString();
	
	}

	/**
	 * @param ipAddress
	 *            ipAddress of the FTS System
	 * @param port
	 *            port number on which TCP/IP is open on FTS System
	 * @return Socket created with the parameters passed
	 * @throws ApplicationException
	 */
	public Socket createSocket(String ipAddress, String port)throws ApplicationException {
		// Socket socket = null;

		try {			
			// Create socket connection
			return new Socket(ipAddress, new Integer(port).intValue());
		} catch (UnknownHostException e) {
			throw new InfrastructureException("error.fts.unknownHost");
		} catch (NumberFormatException e) {
			throw new InvalidDataException("error.fts.errorport");
		} catch (IOException e) {
			throw new InfrastructureException("error.fts.io");
		}
	}

	/**
	 * @param ftsPostingLog
	 *            FtsPostingLog entity to be saved
	 * @throws DAOException
	 */
	public void saveFtsPostingLog(FtsPostingLog ftsPostingLog)
	throws DAOException {
		// Save the ftsPostingLog
		getFtsPostingLogDAO().save(ftsPostingLog);

	}

	public static void main(String[] args) {
		
		
		

		//String s="0160ABTFININQ01200910281537009910003592          000000001001000          00000000042478000119066   IPA                             555520091028153700NOR66660010000";
		String s="BDSFININQ012016051008023200007010            000000001001001000000000000000000001382200142022   AUTO     00000000000000000000000555500000000000000NOR66660000";
		System.out.println(s.substring(74, 94));
	
		FTSPostingService FTSPS=new FTSPostingServiceImpl();
		System.out.println("FTSPS=================="+FTSPS);
		AccountInquiryRequest accountInquiryRequest=new AccountInquiryRequest();
		
		
		accountInquiryRequest=AccountInquiryRequest.getInstance();
		accountInquiryRequest.setAccountNo("30070000194");
		System.out.println("accountInquiryRequest===="+accountInquiryRequest);
		
		System.out.println("accountInquiryRequest Account nUmber===="+accountInquiryRequest.getAccountNo());
		try{
		AccountInquiryResponse accountInqRes=   FTSPS.sendAccountInquiry(accountInquiryRequest, "PPM");
		System.out.println("accountInqRes Account Status Des"+accountInqRes.getAcctStatusDesc());
		System.out.println("Account Status"+accountInqRes.getAcctStatusCode());
		
		}
		catch(ApplicationException ae){
			ae.printStackTrace();
		}
		
	
	
	
		
		
	}
   
	private GeneralConfiguration getGeneralConfigByName(String configName) {	

		Element elem = generalConfigurationCache.get(configName);
		if (elem != null) {
			return (GeneralConfiguration) elem.getObjectValue();
		}
		return null;
	}

	@Override
	public String sendMessage(String message, String applicationId,
			boolean insertLog) throws ApplicationException {
		return sendMessage(message,applicationId,insertLog,null);
	}
}
