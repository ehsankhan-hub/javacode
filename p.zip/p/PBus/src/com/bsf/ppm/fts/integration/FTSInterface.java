package com.bsf.ppm.fts.integration;

import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.exceptions.InfrastructureException;

/**
 * Interafce to communicate with FTS - Tuxedo 
 * @author Hussain
 *
 */
public interface FTSInterface {


	/**end the text to FTS and recevies the response message
	 * @param message
	 * @param applicationId
	 * @param insertLog
	 * @param ftsRef
	 * @return
	 * @throws ApplicationException
	 */
	public String sendMessage(String message,String applicationId, boolean insertLog, String ftsRef) throws ApplicationException;
	/** Send the text to FTS and recevies the response message
	 * @param message to be sent
	 * @param ftsRef 
	 * @return response Message from FTS
	 * @throws DAOException 
	 * @throws InfrastructureException 
	 * @throws ApplicationException 
	 */
	public String sendMessage(String message,String applicationId, boolean insertLog) throws ApplicationException;	
	
	
}
