package com.bsf.ppm.net.util;

import java.io.IOException;

public interface PPMSocketPool {

	Connection getSocketConnection() throws IOException, InterruptedException;
	long getExpirationTimeout();
	void notifyConnectionStateChanged();
	/**
	 * To reset connections 
	 * 
	 */
	void resetConnections();
	
	
}
