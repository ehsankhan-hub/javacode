package com.bsf.ppm.net.util;

import org.apache.log4j.Logger;

import com.bsf.ppm.dao.BackendSystemDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.jpa.util.BackendUtil;
import com.bsf.ppm.BackendSystem;

public class PPMSocketPoolFactory {

	private static final Logger log = Logger.getLogger(PPMSocketPoolFactory.class);
	private BackendSystemDAO  backendSystemDAO;

	public BackendSystemDAO getBackendSystemDAO() {
		return backendSystemDAO;
	}

	public void setBackendSystemDAO(BackendSystemDAO backendSystemDAO) {
		this.backendSystemDAO = backendSystemDAO;
	}


	public PPMSocketPool createInstance(){
		PPMSocketPoolImpl pool= null;
		// Get FTS Backend system		
		BackendSystem backendSystem = null;
		try {			
			backendSystem=backendSystemDAO.getBackendByName("FTS");
		} catch (DAOException e) {

			
			e.printStackTrace();
		}catch(Exception e)	{
			
			System.out.println("**************************************");
			e.printStackTrace();
			System.out.println("**************************************");
		}

		String portsList = BackendUtil.getParameterValue(backendSystem, "fts.port");
		String ports[] = portsList.split(",");
		int port[] = new int[ports.length];
		for (int i = 0; i < ports.length; i++) {

			port[i]=new Integer(ports[i]);
		}
		pool= new PPMSocketPoolImpl(BackendUtil.getParameterValue(backendSystem,"fts.system.ip"), port,7200000l, 4);

		return pool;
	}


}
