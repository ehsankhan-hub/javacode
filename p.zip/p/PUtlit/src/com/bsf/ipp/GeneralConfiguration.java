package com.bsf.ipp;

import java.sql.Timestamp;
import java.util.Iterator;
import java.util.Map;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import com.bsf.ipp.dao.SelectableAuditableCacheableEntity;

/**
 * <p>Pojo mapping TABLE IPPUSER.GENERAL_CONFIGURATION</p>
 * @author Kaza
 * 
 */
@Entity
@Table(name = "GENERAL_CONFIGURATION")
@SuppressWarnings("serial")
public class GeneralConfiguration extends  SelectableAuditableCacheableEntity  {

	/**
	 * Attribute id.
	 */
	private Long id;

	/**
	 * Attribute configurationName.
	 */
	private String configurationName;

	/**
	 * Attribute configurationDescription.
	 */
	private String configurationDescription;

	/**
	 * Attribute userInfo
	 */
	private UserInfo createdBy;	

	/**
	 * Attribute createdDate.
	 */
	private Timestamp createdDate;

	/**
	 * Attribute userInfo
	 */
	private UserInfo modifiedBy;	

	/**
	 * Attribute modifiedDate.
	 */
	private Timestamp modifiedDate;

	/**
	 * Attribute status.
	 */
	private Long status;

	/**
	 * List of GeneralConfigParameter
	 */
	private Map<String, GeneralConfigParameter> generalConfigParameters = null;


	/**
	 * @return id
	 */
	@Basic
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "generalConfigIdGen")
	@TableGenerator(name = "generalConfigIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "GENERAL_CONFIGURATION", valueColumnName = "ID_VALUE")		
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return configurationName
	 */
	@Basic
	@Column(name = "CONFIGURATION_NAME", length = 30)
	public String getConfigurationName() {
		return configurationName;
	}

	/**
	 * @param configurationName new value for configurationName 
	 */
	public void setConfigurationName(String configurationName) {
		this.configurationName = configurationName;
	}

	/**
	 * @return configurationDescription
	 */
	@Basic
	@Column(name = "CONFIGURATION_DESCRIPTION", length = 50)
	public String getConfigurationDescription() {
		return configurationDescription;
	}

	/**
	 * @param configurationDescription new value for configurationDescription 
	 */
	public void setConfigurationDescription(String configurationDescription) {
		this.configurationDescription = configurationDescription;
	}

	/**
	 * get userInfo
	 */
	@ManyToOne
	@JoinColumn(name = "CREATED_BY")
	public UserInfo getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * set userInfo
	 */
	public void setCreatedBy(UserInfo createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return createdDate
	 */
	@Basic
	@Column(name = "CREATED_DATE")
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate new value for createdDate 
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * get userInfo
	 */
	@ManyToOne
	@JoinColumn(name = "MODIFIED_BY")
	public UserInfo getModifiedBy() {
		return this.modifiedBy;
	}

	/**
	 * set userInfo
	 */
	public void setModifiedBy(UserInfo modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return modifiedDate
	 */
	@Basic
	@Column(name = "MODIFIED_DATE")
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate new value for modifiedDate 
	 */
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return status
	 */
	@Basic
	@Column(name = "STATUS")
	public Long getStatus() {
		return status;
	}

	/**
	 * @param status new value for status 
	 */
	public void setStatus(Long status) {
		this.status = status;
	}

	/**
	 * Get the list of GeneralConfigParameter
	 */
	@OneToMany(mappedBy="generalConfiguration", fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	@MapKey(name="paramName")
	@OrderBy("paramName")
	public Map<String,GeneralConfigParameter> getGeneralConfigParameters() {
		return this.generalConfigParameters;
	}

	/**
	 * Set the list of GeneralConfigParameter
	 */
	public void setGeneralConfigParameters(Map<String,GeneralConfigParameter> generalConfigParameters) {
		this.generalConfigParameters = generalConfigParameters;
	}

	@Transient
	public String getKey() {
		return getConfigurationName();
	}

	public String toString(){
		StringBuffer buff = new StringBuffer();
		if (getGeneralConfigParameters()!=null && getGeneralConfigParameters().size()>0){

			Map<String,GeneralConfigParameter> map = getGeneralConfigParameters();
			
			for (Map.Entry<String,GeneralConfigParameter> entry : map.entrySet()) { 
			
				GeneralConfigParameter param = entry.getValue();
				buff.append(param.getParamName() +"=" + param.getParamValue()+ ",");
			}
		}
		return buff.toString();
	}
	
	@Transient
	public String getPk() {
		return getId().toString();
	}


}