package com.bsf.ipp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlTransient;

/**
 * <p>Pojo mapping TABLE user_info</p>
 * <p></p>
 *
 * <p>Generated at Wed Mar 18 11:55:46 AST 2009</p>
 * @author Salto-db Generator v1.0.16 / EJB3
 * 
 */
@Entity
@Table(name = "user_info")
@SuppressWarnings("serial")
public class UserInfo implements Serializable {

	/**
	 * Attribute userId.
	 */
	private String userId;

	
	/**
	 * Attribute lastLoginDate.
	 */
	private Timestamp lastLoginDate;
	
	/**
	 * Attribute createdDate.
	 */
	private Timestamp createdDate;
	
	private String credential;
	
	
	
	public UserInfo(String userId) {
		this.userId=userId;
	}
	
	
	public UserInfo() {
		
	}

	@Transient
	public String getCredential() {
		return credential;
	}

	public void setCredential(String credential) {
		this.credential = credential;
	}

	/**
	 * <p> 
	 * </p>
	 * @return userId
	 */
	@Basic
	@Id
	@Column(name = "user_id", length = 20)
		public String getUserId() {
		return userId;
	}

	/**
	 * @param userId new value for userId 
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/**
	 * @return lastLoginDate
	 */
	@Basic
	@Column(name = "LAST_LOGIN_DATE")
	@XmlTransient
		public Timestamp getLastLoginDate() {
		return lastLoginDate;
	}

	/**
	 * @param lastLoginDate new value for lastLoginDate 
	 */
	public void setLastLoginDate(Timestamp lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}
	
	/**
	 * @return createdDate
	 */
	@Basic
	@Column(name = "CREATED_DATE")
	@XmlTransient
		public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate new value for createdDate 
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
}