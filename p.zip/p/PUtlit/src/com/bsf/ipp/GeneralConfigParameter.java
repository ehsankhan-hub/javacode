package com.bsf.ipp;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.TableGenerator;

/**
 * <p>Pojo mapping TABLE IPPUSER.GENERAL_CONFIG_PARAMETER</p>
 * @author Kaza
 * 
 */
@Entity
@Table(name = "GENERAL_CONFIG_PARAMETER")
@SuppressWarnings("serial")
public class GeneralConfigParameter implements Serializable {

	/**
	 * Attribute id.
	 */
	private Long id;

	/**
	 * Attribute paramName.
	 */
	private String paramName;

	/**
	 * Attribute paramValue.
	 */
	private String paramValue;

	/**
	 * Attribute generalConfiguration
	 */
	private GeneralConfiguration generalConfiguration;	

	private String description;

	/**
	 * @return id
	 */
	@Basic
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "configParamIdGen")
	@TableGenerator(name = "configParamIdGen", table = "IDGEN", allocationSize = 1, pkColumnName = "TABLE_NAME", pkColumnValue = "GENERAL_CONFIG_PARAMETER", valueColumnName = "ID_VALUE")	
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id new value for id 
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return paramName
	 */
	@Basic
	@Column(name = "PARAM_NAME", length = 100)
	public String getParamName() {
		return paramName;
	}

	/**
	 * @param paramName new value for paramName 
	 */
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	/**
	 * @return paramValue
	 */
	@Basic
	@Column(name = "PARAM_VALUE", length = 100)
	public String getParamValue() {
		return paramValue;
	}

	/**
	 * @param paramValue new value for paramValue 
	 */
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}


	/**
	 * @return description
	 */
	@Basic
	@Column(name = "DESCRIPTION", length = 400)
	public String getDescription() {
		return description;
	}

	/**
	 * @param description new value for description 
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * get generalConfiguration
	 */
	@ManyToOne
	@JoinColumn(name = "GENERAL_CONFIG_ID")
	public GeneralConfiguration getGeneralConfiguration() {
		return this.generalConfiguration;
	}

	/**
	 * set generalConfiguration
	 */
	public void setGeneralConfiguration(GeneralConfiguration generalConfiguration) {
		this.generalConfiguration = generalConfiguration;
	}



}