package com.bsf.ipp;

/**
 * @author rsaif
 *
 */
public class FtsParameter {
	private String paramName;
	private Object paramValue;
	public String getParamName() {
		return paramName;
	}
	public FtsParameter(String paramName,Object paramValue){
		this.paramName=paramName;
		this.paramValue=paramValue;
		
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public Object getParamValue() {
		return paramValue;
	}
	public void setParamValue(Object paramValue) {
		this.paramValue = paramValue;
	}
	
	

}
