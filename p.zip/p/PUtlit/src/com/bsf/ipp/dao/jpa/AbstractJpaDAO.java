package com.bsf.ipp.dao.jpa;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.GenericDAO;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.exceptions.InvalidDataException;

/**
 * @author Rashad Abstract Java Persistence API implementation for the
 *         GenericDAO. Provides Hibernate Implementation for Data Access Object
 *         methods.
 * @param <T>
 *            Entity the DAO operates on.
 * @param <ID>
 *            ID Object of the Entity T.
 */
@Transactional(readOnly = true, rollbackFor=DAOException.class)
public abstract class AbstractJpaDAO<T, ID extends Serializable> implements
GenericDAO<T, ID> {

	/** Attribute persistentClass */
	private Class<T> persistentClass;

	/** Attribute entityManager */
	protected EntityManager entityManager;

	/**
	 * Constructor for AbstractJpaDAO. Initializes the Persistence Class
	 */
	public AbstractJpaDAO() {
		this.persistentClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	}

	/**
	 * @param entityManager
	 *            new value for entityManager
	 */
	@PersistenceContext
	public void setEntityManagerNew(EntityManager entityManager) {
		this.entityManager = entityManager;
		
	}
	
	

	/**
	 * @return persistentClass Returns the Persistence Class
	 */
	public Class<T> getPersistentClass() {
		return persistentClass;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#delete(java.lang.Object)
	 */
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void delete(T entity) throws DAOException {
		try {
			entity = entityManager.merge(entity);
			entityManager.remove(entity);
		} catch (RuntimeException ex) {
			throw new DAOException("error.delete.entity", ex,
					getPersistentClass().getName());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#deleteById(java.io.Serializable)
	 */
	@Override
	public void deleteById(ID id) throws DAOException {
		delete(getById(id));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#deleteByIds(java.lang.String[])
	 */
	@Override
	public void deleteByIds(String[] ids) throws DAOException {
		try {
			// Build the query
			StringBuilder deleteQuery = new StringBuilder("Delete from ")
			.append(getPersistentClass().getSimpleName()).append(
			" as type where type.instReference =:typeId ");
			// Create Query Object
			Query query = entityManager
			.createQuery(deleteQuery.toString());
			System.out.println(deleteQuery.toString());

			// Execute delete query for each id in the array
			for (int i = 0; i < ids.length; i++) {
				query.setParameter("typeId", String.valueOf(ids[i]));
				query.executeUpdate();
			}
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.delete.entities", ex,
					getPersistentClass().getName());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#disableByIds(java.lang.String[],
	 * java.lang.String)
	 */
	@Override
	public void updateEntityStatusByIds(String[] ids, String idField,
			String statusField, long status) throws DAOException {
		try {
			// Build the Disable Query
			StringBuilder disableQuery = new StringBuilder("update ").append(
					getPersistentClass().getSimpleName()).append(
					" as type set type.").append(statusField).append(
					"=:status where type.").append(idField).append("=:typeId ");

			// Build Query Object
			Query query = entityManager.createQuery(disableQuery.toString());

			// Execute Query for each Id in the ids array
			for (int i = 0; i < ids.length; i++) {
				query.setParameter("status", status);
				query.setParameter("typeId", Long.valueOf(ids[i]));
				query.executeUpdate();
			}
		} catch (RuntimeException ex) {
			throw new DAOException("error.disable.entities", ex,
					getPersistentClass().getName());
		}
	}

	
	@Override
	public void updateEntityStatusByField(String[] fieldValues,
			String fieldName, String statusField, long status,
			UserInfo modifiedBy) throws DAOException {

		try {
			// Build the update Query
			StringBuilder disableQuery = new StringBuilder("update ")
					.append( getPersistentClass().getSimpleName())
					.append(" as type set type.").append(statusField)
					.append("=:status, type.modifiedBy=:modifiedBy")
					.append(", type.modifiedDate=:modifiedDate")
					.append("  where type.").append(fieldName)
					.append("=:typeId ");

			// Build Query Object
			Query query = entityManager.createQuery(disableQuery.toString());

			// Execute Query for each Id in the ids array
			for (int i = 0; i < fieldValues.length; i++) {
				query.setParameter("status", status);
				query.setParameter("modifiedBy", modifiedBy);
				query.setParameter("modifiedDate", new Timestamp(Calendar.getInstance().getTimeInMillis()));
				query.setParameter("typeId", fieldValues[i]);
				query.executeUpdate();
			}
		} catch (RuntimeException ex) {
			throw new DAOException("error.disable.entities", ex,
					getPersistentClass().getName());
		}

	
		
	}

	@Override
	public void updateEntityStatusByFieldString(String[] fieldValues,
			String fieldName, String statusField, String status,
			UserInfo modifiedBy) throws DAOException {

		try {
			// Build the update Query
			StringBuilder disableQuery = new StringBuilder("update ")
					.append( getPersistentClass().getSimpleName())
					.append(" as type set type.").append(statusField)
					.append("=:status")
					.append("  where type.").append(fieldName)
					.append("=:typeId ");

			// Build Query Object
			Query query = entityManager.createQuery(disableQuery.toString());

			// Execute Query for each Id in the ids array
			for (int i = 0; i < fieldValues.length; i++) {
				query.setParameter("status","'"+status+"'");
				query.setParameter("typeId", fieldValues[i]);
				query.executeUpdate();
			}
		} catch (RuntimeException ex) {
			throw new DAOException("error.update.entities", ex,
					getPersistentClass().getName());
		}
	}

	public void updateEntityStatusByIds(String[] ids,String idField, String statusField,
			long status, UserInfo modifiedBy) throws DAOException {
		try {

			// Build the Disable Query
			StringBuilder disableQuery = new StringBuilder("update ")
			.append( getPersistentClass().getSimpleName())
			.append(" as type set type.").append(statusField)
			.append("=:status, type.modifiedBy=:modifiedBy")
			.append(", type.modifiedDate=:modifiedDate")
			.append("  where type.").append(idField)
			.append("=:typeId ");

			// Build Query Object
			Query query = entityManager.createQuery(disableQuery.toString());

			// Execute Query for each Id in the ids array
			for (int i = 0; i < ids.length; i++) {
				query.setParameter("status", status);
				query.setParameter("modifiedBy", modifiedBy);
				query.setParameter("modifiedDate", new Timestamp(Calendar.getInstance().getTimeInMillis()));
				query.setParameter("typeId", Long.valueOf(ids[i]));
				query.executeUpdate();
			}
		} catch (RuntimeException ex) {
			throw new DAOException("error.disable.entities", ex,
					getPersistentClass().getName());
		}

	}
	
	
	public void updateEntityStatusByStringIds(String[] ids,String idField, String statusField,
			String status, UserInfo updatedBy) throws DAOException {
		try {

			// Build the Disable Query
			StringBuilder disableQuery = new StringBuilder("update ")
			.append( getPersistentClass().getSimpleName())
			.append(" as type set type.").append(statusField)
			.append("=:status, type.updatedBy=:updatedBy")
			.append(", type.modifiedDate=:modifiedDate")
			.append("  where type.").append(idField)
			.append("=:typeId ");

			// Build Query Object
			Query query = entityManager.createQuery(disableQuery.toString());

			// Execute Query for each Id in the ids array
			for (int i = 0; i < ids.length; i++) {
				query.setParameter("status", status);
				query.setParameter("updatedBy",updatedBy);
				query.setParameter("updateDate", new Timestamp(Calendar
				.getInstance().getTimeInMillis()));
				query.setParameter("typeId", Long.valueOf(ids[i]));
				query.executeUpdate();
			}
		} catch (RuntimeException ex) {
			throw new DAOException("error.disable.entities", ex,
					getPersistentClass().getName());
		}

	}
	
	
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#findAll()
	 */
	@Override
	public List<T> findAll() throws DAOException {
		return findByCriteria(null);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#findByCriteria(java.util.Map)
	 */
	@Override
	public T getByCriteria(Map criterias) throws DAOException,
	InvalidDataException {
		return getByCriteria(criterias, null, false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#findByCriteria(java.outil.Map,
	 * java.lang.String, boolean)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED, noRollbackFor = NoResultException.class)
	public T getByCriteria(Map criterias, String sortField,
			boolean sortAscending) throws DAOException, InvalidDataException {
		try {
			// Build the Query String with Search Criteria
			StringBuilder query = new StringBuilder("Select obj from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			if (criterias != null && criterias.size() > 0) {
				Object[] keyArray = criterias.keySet().toArray();
				for (int i = 0; i < keyArray.length; i++) {
					if (i == 0) {
						query.append(" where");
					}
					query.append(" ").append(keyArray[i]).append("=:").append(
							keyArray[i].toString());
					if (i != (keyArray.length - 1)) {
						query.append(" and");
					}
				}
			}
			if (sortField != null) {
				query.append("  ORDER BY obj.").append(sortField);
				if (sortAscending)
					query.append(" asc");
				else
					query.append(" desc");

			}
			// Build the query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Set the search Parameters for the jpaQuery
			if (criterias != null && criterias.size() > 0) {
				Object[] keyArray = criterias.keySet().toArray();
				for (int i = 0; i < keyArray.length; i++)
					jpaQuery.setParameter(keyArray[i].toString(), criterias
							.get(keyArray[i]));
			}

			/*
			 * jpaQuery.setMaxResults(1); //Execute the query and return List of
			 * objects List<T> resultList = jpaQuery.getResultList(); if
			 * (resultList != null && !resultList.isEmpty()) { return (T)
			 * resultList.get(0); }
			 */
			return (T) jpaQuery.getSingleResult();
		} catch (NoResultException e) {
			throw new InvalidDataException("error.getSingleResult");
		} catch (NonUniqueResultException nure) {
			throw new InvalidDataException("error.getSingleResult");
		} catch (RuntimeException ex) {
			throw new DAOException("error.get.entity", ex, getPersistentClass()
					.getName());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#findByCriteria(java.util.Map)
	 */
	@Override
	public List<T> findByCriteria(Map criterias) throws DAOException {
		return findByCriteria(criterias, null, false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#findAll(java.lang.String, boolean)
	 */
	public List<T> findAll(String sortField, boolean sortAscending)
	throws DAOException {
		return findByCriteria(null, sortField, sortAscending);
	}
	
	
	public List<T> findByCondition(List<SearchCondition> conditions,Map<String, IConstants.SORT_ORDER> sortCriteria)throws DAOException {
		StringBuffer query = null;
		try {
			// Build the Query String
			query = new StringBuffer("Select obj from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			Map<String, Object> namedParameter = null;
			// Set the search criteria
			if (conditions != null && conditions.size() > 0) {
				query.append(ConditionBulider.buildCondition(conditions));
			}
			// Set Order by Fields
			if (sortCriteria != null) {

				Iterator<Map.Entry<String, IConstants.SORT_ORDER>> sortItr = sortCriteria
						.entrySet().iterator();
				query.append("  ORDER BY ");
				Map.Entry<String, IConstants.SORT_ORDER> sortPairs = null;
				int j = 0;
				while (sortItr.hasNext()) {

					j++;
					sortPairs = sortItr.next();
					// if value is null set order as ascending.
					query.append(sortPairs.getKey()).append(" ").append(
							sortPairs.getValue() != null ? sortPairs.getValue()
									.name() : " ASC ");
					if (j < sortCriteria.size()) {

						query.append(",");
					}
				}
			}
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Set Named Parameters
			int i=0;
			for (SearchCondition sc : conditions) {

				if (sc.getValue() instanceof java.util.Date) {

					jpaQuery.setParameter(sc.getAttributeName()+i, sc.getValue());
					i++;
				}
				
			}
			// Execute and return the list of Items
			return (List<T>) jpaQuery.getResultList();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#findByCriteria(java.util.Map,
	 * java.lang.String, boolean)
	 */
	public List<T> findByCriteria(Map criterias, String sortField,
			boolean sortAscending) throws DAOException {
		try {
			// Build the Query String with Search Criteria
			StringBuilder query = new StringBuilder("Select obj from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			if (criterias != null && criterias.size() > 0) {
				Object[] keyArray = criterias.keySet().toArray();
				for (int i = 0; i < keyArray.length; i++) {
					if (i == 0) {
						query.append(" where");
					}
					query.append(" ").append(keyArray[i]).append("=:").append(
							keyArray[i].toString());
					if (i != (keyArray.length - 1)) {
						query.append(" and");
					}
				}
			}
			if (sortField != null) {
				query.append("  ORDER BY obj.").append(sortField);
				if (sortAscending)
					query.append(" asc");
				else
					query.append(" desc");

			}
			// Build the query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Set the search Parameters for the jpaQuery
			if (criterias != null && criterias.size() > 0) {
				Object[] keyArray = criterias.keySet().toArray();
				for (int i = 0; i < keyArray.length; i++)
					jpaQuery.setParameter(keyArray[i].toString(), criterias
							.get(keyArray[i]));

			}
			// Execute the query and return List of objects
			return (List<T>) jpaQuery.getResultList();
		} catch (RuntimeException ex) {
			throw new DAOException("error.find.entity", ex,
					getPersistentClass().getName());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#getById(java.io.Serializable, boolean)
	 */
	@Override
	public T getById(ID id, boolean newSession) throws DAOException {
		T item = null;
		try {

			if (newSession) {
				// Creates new session with Entity Manager and fetch the item
				item = (T) entityManager.find(getPersistentClass(), id);
				return item;
			} else {
				// Fetch the item with the current session
				return getById(id);
			}
		} catch (RuntimeException ex) {
			throw new DAOException("error.get.entity", ex, getPersistentClass()
					.getName(), id);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#getById(java.io.Serializable)
	 */
	@Override
	public T getById(ID id) throws DAOException {
		try {
			// Get Entity Object with the given ID
			return (T) entityManager.find(getPersistentClass(), id);
		} catch (RuntimeException ex) {
			throw new DAOException("error.get.entity", ex, getPersistentClass().getName(), id);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#isUnique(java.lang.Object)
	 */
	@Override
	public abstract boolean isUnique(T entity) throws DAOException;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#save(java.lang.Object)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
	public T save(T entity) throws DAOException {
		try {
			// Persist the Entity
			entityManager.persist(entity);
			return entity;
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.save.entity", ex,
					getPersistentClass().getName());
		}
	}


	@Transactional(propagation = Propagation.REQUIRED)
	public Object refresh(Object entity) throws DAOException {
		try {
			// refresh the Entity
			entityManager.refresh(entityManager.merge(entity));
			return entity;
		} catch (RuntimeException ex) {
			throw new DAOException("error.save.entity", ex,
					getPersistentClass().getName());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#saveOrUpdate(java.lang.Object)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
	public T saveOrUpdate(T entity) throws DAOException {
		try {
			// merge Entity
				System.out.println("entity from AbstractJPADao=="+entity);
			entity = entityManager.merge(entity);
			// Save and return the entity
			return save(entity);
		} catch (RuntimeException ex) {
			//entityManager.getTransaction().rollback();
			throw new DAOException("error.save.entity", ex,
					getPersistentClass().getName());
		}
	}
    
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#saveOrUpdate(java.lang.Object)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
	public int updateInstDtl(T entity) throws DAOException {
		try {
			// merge Entity
			entity = entityManager.merge(entity);
			
			// Save and return the entity
			return 1;
		} catch (RuntimeException ex) {
			//entityManager.getTransaction().rollback();
			throw new DAOException("error.save.entity", ex,
					getPersistentClass().getName());
		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#update(java.lang.Object)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
	public T update(T entity) throws DAOException {
		// Merge Entity
		entity = entityManager.merge(entity);
		// Save and return the entity
		return save(entity);
	}

	/**
	 * This method will execute an HQL query and return the number of affected
	 * entities.
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#updateByNamedQuery(java.lang.String,
	 * java.lang.String[], java.lang.Object[])
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public int updateByNamedQuery(String query, String namedParams[],
			Object params[]) throws DAOException {
		try {
			// Create Query object
			Query q = entityManager.createNamedQuery(query);
			// Set the parameters in Named Query
			if (namedParams != null) {
				for (int i = 0; i < namedParams.length; i++) {
					q.setParameter(namedParams[i], params[i]);
				}
			}
			// execute query and return the result
			return q.executeUpdate();
		} catch (RuntimeException ex) {
			throw new DAOException("error.updateByQuery.entity", ex,
					getPersistentClass().getName(), query);
		}
	}

	/**
	 * Execute update with specified Query
	 * 
	 * @param query
	 *            update Query to be executed
	 * @return number of records updated
	 * @throws DAOException
	 */
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	protected int updateByQuery(String query) throws DAOException {
		return updateByNamedQuery(query, null, null);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#findByNamedQuery(java.lang.String,
	 * java.lang.String[], java.lang.Object[])
	 */
	@Override
	public List<T> findByNamedQuery(String query, String namedParams[],
			Object params[]) throws DAOException {
		try {
			// Create a named Query
			Query q = entityManager.createNamedQuery(query);
			// Set Parameter values in named query
			if (namedParams != null) {
				for (int i = 0; i < namedParams.length; i++) {
					q.setParameter(namedParams[i], params[i]);
				}
			}
			// Execute query and return the List of items
			return (List<T>) q.getResultList();
		} catch (RuntimeException ex) {
			//Dawooth for DD500
			ex.printStackTrace();
			throw new DAOException("error.findByQuery.entity", ex,
					getPersistentClass().getName(), query);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#delete(java.util.List)
	 */
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void delete(List<T> delteList) throws DAOException {
		// Delete the list of entities
		for (T entity : delteList)
			delete(entity);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#searchByCriteria(java.util.Map,
	 * java.lang.String, boolean)
	 */
	public List<T> searchByCriteria(Map criterias, String sortField,
			boolean sortAscending) throws DAOException {
		StringBuffer query = null;
		try {
			// Build the Query
			query = new StringBuffer("Select obj from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			// Set the search criteria in the query
			if (criterias != null) {
				Object[] keyArray = criterias.keySet().toArray();
				for (int i = 0; i < keyArray.length; i++) {
					if (i == 0) {
						query.append(" where");
					}
					query.append(" ").append(keyArray[i]).append(" LIKE '%")
					.append(criterias.get(keyArray[i])).append("%'");
					if (i != (keyArray.length - 1)) {
						query.append(" and");
					}
				}
			}
			// Set Order by to the query
			if (sortField != null) {
				query.append("  ORDER BY obj.").append(sortField);
				if (sortAscending)
					query.append(" asc");
				else
					query.append(" desc");

			}
			// Create a JPA Query object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Execute and return the List of Items
			return (List<T>) jpaQuery.getResultList();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#searchByCriteria(java.util.Map)
	 */
	public List<T> searchByCriteria(Map criterias) throws DAOException {
		return searchByCriteria(criterias, null, false);
	}

	public List<T> executeSimpleQuery(String query) throws DAOException {
		try {
			Query jpaQuery = entityManager.createQuery(query);
			return (List<T>) jpaQuery.getResultList();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}

	}

	public int executeNamedQuery(String query, String namedParams[],
			Object params[]) throws DAOException {
		try {
			Query q = entityManager.createNamedQuery(query);
			// Set Parameter values in named query
			if (namedParams != null) {
				for (int i = 0; i < namedParams.length; i++) {
					q.setParameter(namedParams[i], params[i]);
				}
			}
			return q.executeUpdate();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeNamedQuery", ex,
					getPersistentClass().getName(), query);
		}
	}

	/** 
	 * This method will return the next fts sequence value
	 * Hibernate will return the next value by running the below native query
	 * 
	 * 
	 * @see com.bsf.ipp.dao.GenericDAO#getFtsReference()
	 */
	@Override
	public Long getFtsReference() throws DAOException {

		String sql = "select CLG_FTS_REF.NEXTVAL from dual";
		try {
			// Execute native query and get the result list
			List results= entityManager.createNativeQuery(sql).getResultList();
			// Iterate the list and get the sequence value
			BigDecimal bd = (BigDecimal)results.iterator().next();
			Long value = bd.longValue();
			return value;
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), sql);
		}
	}
	
	public int executeNativeUpdate(String query) {
		Query jpaQuery = entityManager.createNativeQuery(query.toString());
		return jpaQuery.executeUpdate();
	}


}
