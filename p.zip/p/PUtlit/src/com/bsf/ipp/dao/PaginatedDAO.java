package com.bsf.ipp.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.bsf.ipp.dao.jpa.SearchCondition;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.exceptions.DAOException;

/**
 * Paginated DAO used for GUI display. Provides pagination support on top of Generic DAO
 * Provides search and find methods for searchCriteria ,sorting, pageNumbers
 * @author rakesh
 *
 * @param <T> Entity Name DAO operates on. Valid Entity Class name
 * @param <ID> ID Object for the Entity T. 
 */
public interface PaginatedDAO<T, ID extends Serializable> extends GenericDAO<T, ID> {
	 
	/**
	 * Fetches the list of all Entity Objects from the database table matching the search criteria.
	 * @param criterias Search criteria Map with names of variables in Entity Object and corresponding values.
	 * @param firstItem Item number from the list.
	 * @param batchSize Batch size to be fetched starting at firstItem
	 * @param sortField variable/field name in the Entity Object to sort by
	 * @param sortAscending The List is ordered Ascending if sortAscending is <b>true</b>. Descending if sortAscending is <b>false</b>
	 * @return List of entity Objects of type T
	 * @throws DAOException
	 */
	public List<T> findByPages(Map criterias, int firstItem, int batchSize,String sortField,boolean sortAscending) throws DAOException;
	/**
	 * Fetches the list of all Entity Objects from the database table.
	 * @param firstItem Item number from the list.
	 * @param batchSize Batch size to be fetched starting at firstItem
	 * @param sortField variable/field name in the Entity Object to sort by
	 * @param sortAscending The List is ordered Ascending if sortAscending is <b>true</b>. Descending if sortAscending is <b>false</b>
	 * @return List of entity Objects of type T
	 * @throws DAOException
	 */
	public List<T> findByPages(int firstItem, int batchSize,String sortField,boolean sortAscending) throws DAOException;
	/**
	 * Fetches the list of all Entity Objects from the database table matching the search criteria.
	 * @param criterias Search criteria Map with names of variables in Entity Object and corresponding values.
	 * @param firstItem Item number from the list.
	 * @param batchSize Batch size to be fetched starting at firstItem
	 * @return List of entity Objects of type T
	 * @throws DAOException
	 */
	public List<T> findByPages(Map criterias, int firstItem, int batchSize) throws DAOException;
	/**
	 * Fetches the list of all Entity Objects with the firstItem number and batch size.
	 * @param firstItem Item number from the list.
	 * @param batchSize Batch size to be fetched starting at firstItem
	 * @return List of entity Objects of type T
	 * @throws DAOException
	 */
	public List<T> findByPages(int firstItem, int batchSize) throws DAOException;
	/**
	 * 
	 * @return number of entity objects retrieved from the database table 
	 * @throws DAOException
	 */
	public long getResultSize() throws DAOException;
	/**
	 * @param searchCriteria
	 * @return number of entity objects retrieved from the database table matching the search criteria
	 * @throws DAOException
	 */
	public long getResultSize(Map<String, Object> searchCriteria) throws DAOException;
	
	/**
	 * Fetches the list of all Entity Objects from the database table matching the search criteria.
	 * Result is filtered with   %like% for string types.
	 * @param criterias Search criteria Map with names of variables in Entity Object and corresponding values.
	 * @param firstItem Item number from the list.
	 * @param batchSize Batch size to be fetched starting at firstItem
	 * @param sortField variable/field name in the Entity Object to sort by
	 * @param sortAscending The List is ordered Ascending if sortAscending is <b>true</b>. Descending if sortAscending is <b>false</b>
	 * @return List of entity Objects of type T
	 */
	public List<T> searchByPages(Map criterias, int firstItem, int batchSize,String sortField,boolean sortAscending) throws DAOException;
	
	public List<T> searchByPagesSalaryPercen(Map criterias, int firstItem, int batchSize,
			String sortField, boolean sortAscending) throws DAOException;
	
	/**
	 * Fetches the list of all Entity Objects from the database table matching the search criteria & applying the sortCriteria on multiple Columns.
	 * Result is filtered with   %like% for string types.
	 * @param criterias Search criteria Map with names of variables in Entity Object and corresponding values.
	 * @param firstItem Item number from the list.
	 * @param batchSize Batch size to be fetched starting at firstItem
	 * @param sortCriteria Criteria for sorting, should be in <column name, asc/desc)> type.
	 * @return List of entity Objects of type T
	 */
	
	public List<T> searchByPages(Map criterias, int firstItem, int batchSize, Map<String,IConstants.SORT_ORDER> sortCriteria) throws DAOException;
	/**
	 * @param firstItem
	 * @param batchSize
	 * @param sortField
	 * @param sortAscending
	 * @return List of entity Objects of type T
	 * @throws DAOException
	 */
	public List<T> searchByPages(int firstItem, int batchSize,String sortField,boolean sortAscending) throws DAOException;
	
	/**
	 * Fetches the list of all Entity Objects from the database table without the search criteria & applying the sortCriteria on multiple Columns.
	 * @param firstItem
	 * @param batchSize
	 * @param sortField
	 * @param sortCriteria Criteria for sorting, should be in <column name, asc/desc)> type.
	 * @return List of entity Objects of type T
	 * @throws DAOException
	 */
	public List<T> searchByPages(int firstItem, int batchSize,Map<String,IConstants.SORT_ORDER> sortCriteria) throws DAOException;
	/**
	 * @param criterias
	 * @param firstItem
	 * @param batchSize
	 * @return List of entity Objects of type T
	 * @throws DAOException
	 */
	public List<T> searchByPages(Map criterias, int firstItem, int batchSize) throws DAOException;
	/**
	 * @param firstItem
	 * @param batchSize
	 * @return List of entity Objects of type T
	 * @throws DAOException
	 */
	public List<T> searchByPages(int firstItem, int batchSize) throws DAOException;
	/**
	 * @param searchCriteria
	 * @return number of Entity Objects retrieved after the search
	 * @throws DAOException
	 */
	public long getSearchResultSize(Map<String, Object> searchCriteria) throws DAOException;
	
	public List<T> searchByPagesWithoutPagination(Map criterias, String sortField, boolean sortAscending) throws DAOException;
	
	/**
	 * 
	 * @param criterias
	 * @param firstItem
	 * @param batchSize
	 * @param sortField
	 * @param sortAscending
	 * @param dateFIeld
	 * @param fromDate
	 * @param toDate
	 * @return
	 * @throws DAOException
	 */
	public List<T> searchByPagesDateRange(Map criterias, int firstItem, int batchSize,String sortField,boolean sortAscending, String dateFIeld, String fromDate, String toDate) throws DAOException;
	
	
	/**
	 * 
	 * @param searchCriteria
	 * @param dateFIeld
	 * @param fromDate
	 * @param toDate
	 * @return
	 * @throws DAOException
	 */
	public long getResultSizeDateRange(Map<String, Object> searchCriteria, String dateFIeld, String fromDate, String toDate) throws DAOException;
	
	
	public List<T> searchByPages(int firstItem, int batchSize,List<SearchCondition> criterias,
			Map<String,IConstants.SORT_ORDER> sortCriteria) throws DAOException;
	public long getResultSize(List<SearchCondition> criterias
	) throws DAOException;
	
	
	
	public long getResultSizeforSalaryPercent(Map<String, Object> criterias)
			throws DAOException ;
	
	/**
	 * @param query
	 * @param namedParams
	 * @param params
	 * @param firstItem
	 * @param batchSize
	 * @return
	 * @throws DAOException
	 */
	public List<T> findByNamedQuery(String query, String namedParams[],
			Object params[],int firstItem, int batchSize) throws DAOException;
	
	public List<T> searchByPages(List<SearchCondition> criterias,
			Map<String, IConstants.SORT_ORDER> sortCriteria)
			throws DAOException;
	
	public List<T> findByNamedQuery(String query, String namedParams[],
			Object parmas[],int timeOutSec) throws DAOException;
	public long getCurrentAndFutureDateRange(Map<String, Object> criterias,
			String dateField, String fromDate, String toDate)
			throws DAOException ;
	public List<T> searchByPagesCurrentAndFutureDateRange(Map criterias, int firstItem,
			int batchSize, String sortField, boolean sortAscending,
			String dateField, String fromDate, String toDate)
			throws DAOException ;
}
