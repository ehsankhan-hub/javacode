package com.bsf.ipp.dao;

import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlTransient;

import com.bsf.ppm.controller.jsf.Selectable;

/**
 * Default implementation for Selectable entities
 * @author Rakesh
 *
 */
@XmlTransient
public abstract class SelectableEntity extends Entity implements Selectable {

	/**
	 * Attribute serialVersionUID Serial Version UID for the class
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Attribute selected to define the the status of the Entity if selected
	 */
	protected boolean selected;
	
	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.Selectable#isSelected()
	 */
	@Override
	@Transient
	@XmlTransient
	public boolean isSelected() {
		return selected;
	}

	/* (non-Javadoc)
	 * @see com.bsf.ppm.controller.jsf.Selectable#setSelected(boolean)
	 */
	@Override
	public void setSelected(boolean selected) {
		this.selected = selected;
	}

}
