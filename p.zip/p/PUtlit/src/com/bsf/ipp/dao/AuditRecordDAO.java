package com.bsf.ipp.dao;

import com.bsf.ipp.AuditRecord;
import com.bsf.ppm.exceptions.DAOException;

public interface AuditRecordDAO {
	public AuditRecord save(AuditRecord auditRecord) throws DAOException;
}
