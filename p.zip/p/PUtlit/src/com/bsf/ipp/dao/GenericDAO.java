package com.bsf.ipp.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.UserInfo;
import com.bsf.ipp.dao.jpa.SearchCondition;
import com.bsf.ppm.annotations.AuditLogType;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.exceptions.InvalidDataException;

/**
 * Generic Data Access Object with DB operations
 * @author rakesh
 *
 * @param <T> Entity Name DAO operates on. Valid Entity Class name
 * @param <ID> ID Object for the Entity T. 
 */
/**
 * @author mmahaboob
 *
 * @param <T>
 * @param <ID>
 */
/**
 * @author rsaif
 *
 * @param <T>
 * @param <ID>
 */
public interface GenericDAO<T, ID extends Serializable> {

	/**
	 * Fetches the entity Object from the Database with the id specified.
	 * Creates a new Transaction.
	 * @param id
	 * @param newSession
	 * @return
	 * @throws DAOException
	 */
	T getById(ID id, boolean newSession) throws DAOException;

	/**
	 * Fetches the entity Object from the Database with the id specified.
	 * @param id
	 * @return
	 * @throws DAOException
	 */
	T getById(ID id) throws DAOException;
	
	/**
	 * Fetches the list of all Entity Objects from the database.
	 * @return
	 * @throws DAOException
	 */
	List<T> findAll() throws DAOException;
	
	/**
	 * Fetches the list of all Entity Objects from the database.
	 * The list is sorted with the criteria in sortField.
	 * The List is ordered Ascending if sortAscending is <b>true</b>. Descending if sortAscending is <b>false</b> 
	 * @param sortField
	 * @param sortAscending
	 * @return
	 * @throws DAOException
	 */
	List<T> findAll(String sortField,boolean sortAscending) throws DAOException;
	/**
	 * Fetches the list of all Entity Objects that match the search criteria from the database.
	 * The list is sorted with the criteria in sortField.
	 * The List is ordered Ascending if sortAscending is <b>true</b>. Descending if sortAscending is <b>false</b>
	 * @param criterias
	 * @param sortField
	 * @param sortAscending
	 * @return
	 * @throws DAOException
	 */
	List<T> findByCriteria(Map criterias,String sortField,boolean sortAscending) throws DAOException;
	/**
	 * Fetches the list of all Entity Objects that match the search criteria from the database.
	 * @param criterias
	 * @return
	 * @throws DAOException
	 */
	List<T> findByCriteria(Map criterias) throws DAOException;
	/**
	 * Fetches the list of all Entity Objects that match the search criteria from the database.
	 * Result is filtered with   %like% for string types.
	 * The list is sorted with the criteria in sortField.
	 * The List is ordered Ascending if sortAscending is <b>true</b>. Descending if sortAscending is <b>false</b>
	 * @param criterias
	 * @param sortField
	 * @param sortAscending
	 * @return
	 * @throws DAOException
	 */
	List<T> searchByCriteria(Map criterias,String sortField,boolean sortAscending) throws DAOException;
	/**
	 * Fetches the list of all Entity Objects that match the search criteria from the database.
	 * Result is filtered with   %like% for string types.
	 * @param criterias
	 * @return
	 * @throws DAOException
	 */
	List<T> searchByCriteria(Map criterias) throws DAOException;
	
	/**
	 * Fetches the list of all Entity Objects extracted from database by the <b>query</b> passed.
	 * @param query valid JPQL named Query.
	 * @param namedParams parameter names in the JPQL named Query
	 * @param params corresponding values for the params in the JPQL named Query
	 * @return
	 * @throws DAOException
	 */
	public List<T> findByNamedQuery(String query, String namedParams[],
			Object params[]) throws DAOException;

	/**
	 * Executes an Update on database by the <b>query</b> passed.
	 * @param query valid JPQL named Query.
	 * @param namedParams parameter names in the JPQL named Query
	 * @param params corresponding values for the params in the JPQL named Query
	 * @return
	 * @throws DAOException
	 */
	public int updateByNamedQuery(String query, String namedParams[],
			Object params[]) throws DAOException;
	
	
	/**
	 * Inserts the Entity Object to Database Table.
	 * @param entity Entity Object of type T
	 * @return
	 * @throws DAOException
	 */
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor=DAOException.class)
	@AuditLogType(value="save_entity", message="to add  entity")
	public T save(T entity) throws DAOException;

	/**
	 * Updates the Entity Object in Database Table.
	 * @param entity Entity Object of type T
	 * @return
	 * @throws DAOException
	 */
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor=DAOException.class)
	@AuditLogType(value="update_entity", message="to update entity")
	public T update(T entity) throws DAOException;

	/**
	 * Saves or Updates the Entity Object in Database Table.
	 * If the Id Exists, Database record is updated. If Id does'nt exist, creates a new record in Database Table.
	 * Note: Currently the implementation is only updating the Entity Object in DB table.
	 * @param entity Entity Object of type T
	 * @return
	 * @throws DAOException
	 */
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor=DAOException.class)
	@AuditLogType(value="update_entity", message="to update entity")
	public T saveOrUpdate(T entity) throws DAOException;

	/**
	 * Deletes the Entity Object in Database Table.
	 * @param entity Entity Object of type T
	 * @throws DAOException
	 */
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor=DAOException.class)
	@AuditLogType(value="delete_entity", message="to delete entity")
	public void delete(T entity) throws DAOException;
	/**
	 * Deletes the list of Entity Objects in Database Table.
	 * @param delteList list of Entity Objects to be deleted from the table.
	 * @throws DAOException
	 */
	public void delete(List<T> delteList)throws DAOException;
	
	/**
	 * Deletes the Entity Object in Database Table identified by id specified.
	 * @param id ID of the Entity Object that is to be deleted
	 * @throws DAOException
	 */
	public void deleteById(ID id) throws DAOException;
	
	/**
	 * Deletes the Entity Object in Database Table identified by multiple IDs specified.
	 * @param ids Multiple ids of the Entity Object that are to be deleted
	 * @throws DAOException
	 */
	public void deleteByIds(String[] ids) throws DAOException;
	
	/**
	 * Disables  the Entity Objects in Database Table identified by multiple IDs specified.
	 * @param ids Multiple ids of the Entity Object that are to be disabled
	 * @param statusField Name of the column in database that represents the active status
	 * @throws DAOException
	 */
	public void updateEntityStatusByIds(String[] ids,String idField, String statusField,long status) throws DAOException;

	/**
	 * Disables  the Entity Objects in Database Table identified by multiple IDs specified.
	 * @param ids Multiple ids of the Entity Object that are to be disabled
	 * @param idField
	 * @param statusField Name of the column in database that represents the active status
	 * @param status
	 * @param modifiedBy User id 
	 * @throws DAOException
	 */
	public void updateEntityStatusByIds(String[] ids,String idField, String statusField,long status, UserInfo modifiedBy) throws DAOException;
	
	/**
	 * Updates the Entity Objects in Database Table identified by multiple IDs specified.
	 * @param fieldValues Multiple field values of the Entity Object that are to be updated
	 * @param fieldName
	 * @param statusField Name of the column in database that represents the active status
	 * @param status
	 * @param modifiedBy User id 
	 * @throws DAOException
	 */
	public void updateEntityStatusByField(String[] fieldValues,String fieldName, String statusField,long status, UserInfo modifiedBy) throws DAOException;
	
	public void updateEntityStatusByFieldString(String[] fieldValues,String fieldName, String statusField,String status, UserInfo modifiedBy) throws DAOException;

	/**
	 * Checks if the Entity Object represents is unique in DB table. Checks if Object exist in the table.
	 * @param entity
	 * @return boolean true if the entity does'nt exist. False if entity exists
	 * @throws DAOException
	 */
	public boolean isUnique(T entity) throws DAOException;

	/**
	 * To execute a plain Query and return Entities
	 * @param query
	 * @return
	 * @throws DAOException
	 */
	public List<T> executeSimpleQuery(String query) throws DAOException;
	/**
	 * to execute JPA DML named query.
	 * @param query
	 * @param namedParams
	 * @param params
	 * @return
	 */
	public int executeNamedQuery(String query, String namedParams[],
			Object params[]) throws DAOException;
	
	/**
	 * @param criterias
	 * @return
	 * @throws DAOException
	 */
	public T getByCriteria(Map criterias) throws DAOException , InvalidDataException;

	/**
	 * @param criterias
	 * @param sortField
	 * @param sortAscending
	 * @return
	 * @throws DAOException
	 */
	public T getByCriteria(Map criterias,String sortField,boolean sortAscending) throws DAOException, InvalidDataException;

	/**
	 * to refresh entity data.
	 * @param entity
	 * @return
	 * @throws DAOException
	 */
	public Object refresh(Object entity) throws DAOException;
	
	/** 
	 * This method will return the next fts sequence value
	 * Hibernate will return the next value by running the below native query
	 * 
	 */
	public Long getFtsReference() throws DAOException;
	
	/**
	 * @param conditions
	 * @param sortCriteria
	 * @return
	 * @throws DAOException
	 */
	public List<T> findByCondition(List<SearchCondition> conditions,Map<String, IConstants.SORT_ORDER> sortCriteria)throws DAOException ;
	/**
	 * @param query
	 * @return
	 */
	public int executeNativeUpdate(String query);
	
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor=DAOException.class)
	@AuditLogType(value="update_entity", message="to update entity")
	int updateInstDtl(T entity) throws DAOException;

}