package com.bsf.ipp.dao.jpa;

public class SearchCondition {
	/**
	 * 
	 */
	private String preCondition;
    /**
     * 
     */
    public static String OR = " or ";
    /**
     * 
     */
    public static String AND = " and ";
    /**
     * 
     */
    private String attributeName;
    /**
     * 
     */
    private String operator = "=";
    /**
     * 
     */
    private Object  value;
    /**
     * 
     */
    private String openBrace="";
    /**
     * 
     */
    private String closeBrace="";
    
    
    private String valueFunction;
    

    
    

	public String getValueFunction() {
		return valueFunction;
	}

	public void setValueFunction(String valueFunction) {
		this.valueFunction = valueFunction;
	}


	public String getOpenBrace() {
		return openBrace;
	}

	public void setOpenBrace(String openBrace) {
		this.openBrace = openBrace;
	}

	public String getCloseBrace() {
		return closeBrace;
	}

	public void setCloseBrace(String closeBrace) {
		this.closeBrace = closeBrace;
	}

	public SearchCondition(String attributeName,Object value) {
	
    	this.attributeName = attributeName;
    	this.value = value;
	}
    
    public SearchCondition(String attributeName,Object value,String operator) {
    	 this(attributeName,value,operator,null);
	}
    
    public SearchCondition(String attributeName,Object value,String operator,String valueFunction) {
    	
    	this.attributeName = attributeName;
    	this.value = value;
    	this.operator = operator;
    	this.valueFunction=valueFunction;
	}
    
    
    public SearchCondition(String attributeName,Object value,String operator,String preCondition,String openBrace,String closeBrace) {
    	
    	this.attributeName = attributeName;
    	this.value = value;
    	this.operator = operator;
    	this.preCondition = preCondition;
    	this.openBrace = openBrace;
    	this.closeBrace =closeBrace; 
	}
    
	public String getPreCondition() {
		
		if(preCondition == null)
		  return " and ";
		return preCondition;
	}
	public void setPreCondition(String preCondition) {
		this.preCondition = preCondition;
	}
	public String getAttributeName() {
		return attributeName;
	}
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public Object getValue() {
		return value;
	}
	public void setValue(Object value) {
		this.value = value;
	}

	@Override
	public String toString() {
		
		return getPreCondition() + getOpenBrace() + getAttributeName() + " " + getOperator() + " " + getValue() + getCloseBrace();
	}
	
    

}
