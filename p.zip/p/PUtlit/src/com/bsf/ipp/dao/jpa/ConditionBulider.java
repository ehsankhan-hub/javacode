package com.bsf.ipp.dao.jpa;

import java.util.List;

public class ConditionBulider {
	
	public static String buildCondition(List<SearchCondition> conditions) {
		StringBuffer sql = new StringBuffer();
		boolean andFirstTime = true;
		int i=0;
		for (SearchCondition sCondition:conditions) {
			
			String andPreCondition = sCondition.getPreCondition();
			String openBrace=sCondition.getOpenBrace();
			String closeBrace=sCondition.getCloseBrace();
			if(sCondition.getValue() instanceof java.util.Date)	{
				
				if (andFirstTime) {
					sql.append(" where ");
					andFirstTime = false;
					andPreCondition = "";
				}
				sql.append(andPreCondition).append(openBrace);
				if(sCondition.getValueFunction() !=null)
					appendValueFunction(sql,sCondition.getValueFunction(),sCondition.getAttributeName(),sCondition.getOperator(),sCondition.getAttributeName()+i);
				else
				  sql.append(sCondition.getAttributeName()).append(" ").append(sCondition.getOperator()).append(":").append(sCondition.getAttributeName()+i);
				  sql.append(closeBrace);
				i++;
				
			}else {//	if (!(sCondition.getValue() instanceof String)){
				
				if (andFirstTime) {
					sql.append(" where ");
					andFirstTime = false;
					andPreCondition = "";
				}
				sql.append(andPreCondition).append(openBrace).append(sCondition.getAttributeName()).append(" ").append(sCondition.getOperator()).append(" ").append(sCondition.getValue()).append(closeBrace);
			}
		}
       return sql.toString();
	}

	private static void appendValueFunction(StringBuffer sql,
			String valueFunction, String attributeName,String operator,String value) {
		sql.append(valueFunction).append("(").append(attributeName).append(")").append(operator).append(valueFunction).append("(:").append(value).append(") ");
		
	}
}
