package com.bsf.ipp.dao.jpa;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.AuditRecord;
import com.bsf.ipp.dao.AuditRecordDAO;
import com.bsf.ppm.exceptions.DAOException;

@Transactional
public class AuditRecordJpaDAO implements AuditRecordDAO{

	/**Attribute entityManager */
	protected EntityManager entityManager;

	/**
	 * @param entityManager the entityManager to set
	 */
	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=false)
	public AuditRecord save(AuditRecord auditRecord) throws DAOException {
		entityManager.persist(auditRecord);
		return auditRecord;
	}
	
}
