package com.bsf.ipp.dao.jpa;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.exceptions.DAOException;

/**
 * Abstract Java Persistence API implementation for the PaginatedDAO.
 * 
 * @author Rashad
 * 
 * @param <T>
 *            Entity the DAO operates on.
 * @param <ID>
 *            ID Object of the Entity T.
 */
@Transactional(readOnly = true, rollbackFor=DAOException.class)
public abstract class PaginatedJpaDAO<T, ID extends Serializable> extends
		AbstractJpaDAO<T, ID> implements PaginatedDAO<T, ID> {
	
	private static final Logger log = Logger.getLogger(PaginatedJpaDAO.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#findByPages(java.util.Map, int, int,
	 * java.lang.String, boolean)
	 */
	@Override
	public List<T> findByPages(Map criterias, int firstItem, int batchSize,
			String sortField, boolean sortAscending) throws DAOException {
		StringBuffer query = null;
		try {
			// Build the Query
			query = new StringBuffer("Select obj from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			// Set the search criteria
			if (criterias != null) {
				Object[] keyArray = criterias.keySet().toArray();
				for (int i = 0; i < keyArray.length; i++) {
					if (i == 0) {
						query.append(" where");
					}
					query.append(" ").append(keyArray[i]).append(" like '%")
							.append(criterias.get(keyArray[i])).append("%'");
					if (i != (keyArray.length - 1)) {
						query.append(" and");
					}
				}
			}
			// Set Order by Field
			if (sortField != null) {
				query.append("  ORDER BY obj.").append(sortField);
				if (sortAscending)
					query.append(" asc");
				else
					query.append(" desc");

			}
			// Build Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Set limits for Rows count to be fetched
			jpaQuery.setFirstResult(firstItem);
			jpaQuery.setMaxResults(batchSize);
			// Execute and return the list of Items
			return (List<T>) jpaQuery.getResultList();

		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#findByPages(int, int, java.lang.String,
	 * boolean)
	 */
	@Override
	public List<T> findByPages(int firstItem, int batchSize, String sortField,
			boolean sortAscending) throws DAOException {
		return findByPages(null, firstItem, batchSize, sortField, sortAscending);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#findByPages(java.util.Map, int, int)
	 */
	@Override
	public List<T> findByPages(Map criterias, int firstItem, int batchSize)
			throws DAOException {
		return findByPages(criterias, firstItem, batchSize, null, false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#findByPages(int, int)
	 */
	@Override
	public List<T> findByPages(int firstItem, int batchSize)
			throws DAOException {
		return findByPages(null, firstItem, batchSize, null, false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#getResultSize()
	 */
	public long getResultSize() throws DAOException {
		// Build the Query String
		StringBuffer query = null;
		try {
			query = new StringBuffer("Select count(*) from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Return the rows count
			return ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
	}
    
	
	public List<T> searchByPagesWithoutPagination(Map criterias, 
			String sortField, boolean sortAscending) throws DAOException {
		
		StringBuffer query = null;
		try {
			// Build the Query String
			query = new StringBuffer("Select obj from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			Map<String, Object> namedParameter = null;
			// Set the search criteria
			if (criterias != null && criterias.size() > 0) {
				namedParameter = new HashMap<String, Object>();

				Iterator<Map.Entry<String, Object>> it = criterias.entrySet()
						.iterator();
				int i = 0;
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					i++;
					pairs = it.next();
					if (i == 1) {

						query.append(" where ");
					}

					if (pairs.getValue() instanceof String) {

						query.append(" ").append(pairs.getKey()).append(
								" like '%").append(pairs.getValue()).append(
								"%'");
					} else if (pairs.getValue() instanceof Date) {

						// nextDate sets the nextDate from the current Date.
						Date nextDate = new Date(((Date) pairs.getValue())
								.getTime() + 86400000l);
						query.append(" ").append(pairs.getKey()).append(" >=:")
								.append(pairs.getKey()).append(" and ").append(
										pairs.getKey()).append(" <:").append(
										"nextDate" + i);
						namedParameter.put(pairs.getKey(), pairs.getValue());
						namedParameter.put("nextDate" + i, nextDate);
						
					} else {

						query.append(" ").append(pairs.getKey()).append("=:")
								.append(pairs.getKey());
						namedParameter.put(pairs.getKey(), pairs.getValue());
					}

					if (i < criterias.size())
						query.append(" and ");
				}
			}
			// Set Order by Field
			if (sortField != null) {
				query.append("  ORDER BY obj.").append(sortField);
				if (sortAscending)
					query.append(" asc");
				else
					query.append(" desc");

			}
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Set the parameter values for the Query
			if (namedParameter != null && namedParameter.size() > 0) {
				Iterator<Map.Entry<String, Object>> it = namedParameter
						.entrySet().iterator();
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					pairs = it.next();
					jpaQuery.setParameter(pairs.getKey(), pairs.getValue());
				}
				
			}
			// Set limits for Rows count to be fetched
			
			// Execute and return the list of Items
			List<T> list = new ArrayList<T>();
			try{
				list = (List<T>) jpaQuery.getResultList();
			}catch(PersistenceException cExeption){
				log.error("Message of Exception : "+cExeption);
			}
			return list;
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#getResultSize(java.util.Map)
	 */
	public long getResultSizeforSalaryPercent(Map<String, Object> criterias)
			throws DAOException {
		StringBuffer query = null;
		try {
			// Build the Query String
			query = new StringBuffer("Select count(*) from ").append(
					getPersistentClass().getSimpleName()).append(" obj where custCode  is not null and");
			Map<String, Object> namedParameter = null;
			// Set the search criteria
			if (criterias != null && criterias.size() > 0) {

				namedParameter = new HashMap<String, Object>();
				Object[] keyArray = criterias.keySet().toArray();
				criterias.keySet();
				System.out.println("Key----"+criterias.keySet());
				//for (int i = 0; i < keyArray.length; i++) {
				for(String key:criterias.keySet()){

					
					System.out.println("criterias.get="+criterias.get(keyArray[0]));
					if (key.equals("status")) {
						query.append(" ").append(keyArray[0])
								.append(" ='").append(criterias.get(keyArray[0])).append("'");
					}
					
					else if (key.equals("custCode")) {

						query.append(" and ").append(keyArray[1])
								.append(" ='").append(criterias.get(keyArray[1])).append("'");
					}
					
					
					
				}
			}
			System.out.println("query.toString()"+query.toString());
			
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			
			
		/*	if (namedParameter != null && namedParameter.size() > 0) {
				Iterator<Map.Entry<String, Object>> it = namedParameter
						.entrySet().iterator();
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					pairs = it.next();
					//System.out.println("pairs.getKey()"+pairs.getKey());
					//System.out.println("pairs.getValue()"+pairs.getValue());
					jpaQuery.setParameter(pairs.getKey(), pairs.getValue());
				}
			}*/
			// Return the rows count matching the search criteria
			//String s = "Select count(*) from PPM_INSTRUCTIONS obj where  status='1'";
			//Query q = entityManager.createNativeQuery(s.toString());
			//System.out.println("Result : " +q.getSingleResult());
			
			return ((Long) jpaQuery.getSingleResult()).intValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
	}
	
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#getResultSize(java.util.Map)
	 */
	public long getResultSize(Map<String, Object> criterias)
			throws DAOException {
		StringBuffer query = null;
		try {
			// Build the Query String
			query = new StringBuffer("Select count(*) from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			Map<String, Object> namedParameter = null;
			// Set the search criteria
			if (criterias != null && criterias.size() > 0) {

				namedParameter = new HashMap<String, Object>();
				Object[] keyArray = criterias.keySet().toArray();
				for (int i = 0; i < keyArray.length; i++) {

					if (i == 0) {

						query.append(" where ");
					}
					if (criterias.get(keyArray[i]) instanceof String) {

						query.append(" ").append(keyArray[i])
								.append(" like '%").append(
										criterias.get(keyArray[i]))
								.append("%'");
					} else if (criterias.get(keyArray[i]) instanceof StringBuffer) {

						query.append(" ").append(keyArray[i]).append(" in ")
								.append(criterias.get(keyArray[i]));
					} else if (criterias.get(keyArray[i]) instanceof Date) {

						Date nextDate = new Date(((Date) criterias
								.get(keyArray[i])).getTime() + 86400000l);
						query.append(" ").append(keyArray[i]).append(" >=:")
								.append(keyArray[i]).append(" and ").append(
										keyArray[i]).append("<:").append(
										"nextDate" + i);
						namedParameter.put(keyArray[i].toString(), criterias
								.get(keyArray[i]));
						namedParameter.put("nextDate" + i, nextDate);

					} else {

						query.append(" ").append(keyArray[i]).append("=:")
								.append(keyArray[i]);
						namedParameter.put(keyArray[i].toString(), criterias
								.get(keyArray[i]));
					}
					if (i != (keyArray.length - 1)) {

						query.append(" and");
					}
				}
			}
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			
			
			if (namedParameter != null && namedParameter.size() > 0) {
				Iterator<Map.Entry<String, Object>> it = namedParameter
						.entrySet().iterator();
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					pairs = it.next();
					//System.out.println("pairs.getKey()"+pairs.getKey());
					//System.out.println("pairs.getValue()"+pairs.getValue());
					jpaQuery.setParameter(pairs.getKey(), pairs.getValue());
				}
			}
			// Return the rows count matching the search criteria
			//String s = "Select count(*) from PPM_INSTRUCTIONS obj where  status='1'";
			//Query q = entityManager.createNativeQuery(s.toString());
			//System.out.println("Result : " +q.getSingleResult());
			
			return ((Long) jpaQuery.getSingleResult()).intValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#searchByPages(java.util.Map, int, int,
	 * java.lang.String, boolean)
	 */
	public List<T> searchByPages(Map criterias, int firstItem, int batchSize,
			String sortField, boolean sortAscending) throws DAOException {
		
		StringBuffer query = null;
		try {
			// Build the Query String
			query = new StringBuffer("Select obj from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			Map<String, Object> namedParameter = null;
			// Set the search criteria
			if (criterias != null && criterias.size() > 0) {
				namedParameter = new HashMap<String, Object>();

				Iterator<Map.Entry<String, Object>> it = criterias.entrySet()
						.iterator();
				int i = 0;
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					i++;
					pairs = it.next();
					if (i == 1) {

						query.append(" where ");
					}

					if (pairs.getValue() instanceof String) {

						query.append(" ").append(pairs.getKey()).append(
								" like '%").append(pairs.getValue()).append(
								"%'");
					} else if (pairs.getValue() instanceof Date) {

						// nextDate sets the nextDate from the current Date.
						Date nextDate = new Date(((Date) pairs.getValue())
								.getTime() + 86400000l);
						query.append(" ").append(pairs.getKey()).append(" >=:")
								.append(pairs.getKey()).append(" and ").append(
										pairs.getKey()).append(" <:").append(
										"nextDate" + i);
						namedParameter.put(pairs.getKey(), pairs.getValue());
						namedParameter.put("nextDate" + i, nextDate);
						
					} else {

						query.append(" ").append(pairs.getKey()).append("=:")
								.append(pairs.getKey());
						namedParameter.put(pairs.getKey(), pairs.getValue());
					}

					if (i < criterias.size())
						query.append(" and ");
				}
			}
			// Set Order by Field
			if (sortField != null) {
				query.append("  ORDER BY obj.").append(sortField);
				if (sortAscending)
					query.append(" asc");
				else
					query.append(" desc");

			}
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Set the parameter values for the Query
			if (namedParameter != null && namedParameter.size() > 0) {
				Iterator<Map.Entry<String, Object>> it = namedParameter
						.entrySet().iterator();
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					pairs = it.next();
					jpaQuery.setParameter(pairs.getKey(), pairs.getValue());
				}
				
			}
			// Set limits for Rows count to be fetched
			jpaQuery.setFirstResult(firstItem);
			jpaQuery.setMaxResults(batchSize);
			// Execute and return the list of Items
			List<T> list = new ArrayList<T>();
			try{
				list = (List<T>) jpaQuery.getResultList();
			}catch(PersistenceException cExeption){
				log.error("Message of Exception : "+cExeption);
			}
			return list;
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
	}

	
	public List<T> searchByPagesSalaryPercen(Map criterias, int firstItem, int batchSize,
			String sortField, boolean sortAscending) throws DAOException {
		
		StringBuffer query = null;
		try {
			// Build the Query String
			/*query = new StringBuffer("Select obj from ").append(
					getPersistentClass().getSimpleName()).append(" obj");*/
			Map<String, Object> namedParameter = null;
			// Set the search criteria
			query = new StringBuffer("Select obj from ").append(
					getPersistentClass().getSimpleName()).append(" obj where custCode  is not null and");
			
			// Set the search criteria
			if (criterias != null && criterias.size() > 0) {

				namedParameter = new HashMap<String, Object>();
				Object[] keyArray = criterias.keySet().toArray();
				criterias.keySet();
				System.out.println("Key----"+criterias.keySet());
				//for (int i = 0; i < keyArray.length; i++) {
				for(Object key:criterias.keySet()){

					
					System.out.println("criterias.get="+criterias.get(keyArray[0]));
					if (key.equals("status")) {
						query.append(" ").append(keyArray[0])
								.append(" ='").append(criterias.get(keyArray[0])).append("'");
					}
					
					else if (key.equals("custCode")) {

						query.append(" and ").append(keyArray[1])
								.append(" ='").append(criterias.get(keyArray[1])).append("'");
					}
					
					
					
				}
			}
			// Set Order by Field
			if (sortField != null) {
				query.append("  ORDER BY obj.").append(sortField);
				if (sortAscending)
					query.append(" asc");
				else
					query.append(" desc");

			}
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Set the parameter values for the Query
			if (namedParameter != null && namedParameter.size() > 0) {
				Iterator<Map.Entry<String, Object>> it = namedParameter
						.entrySet().iterator();
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					pairs = it.next();
					jpaQuery.setParameter(pairs.getKey(), pairs.getValue());
				}
				
			}
			// Set limits for Rows count to be fetched
			jpaQuery.setFirstResult(firstItem);
			jpaQuery.setMaxResults(batchSize);
			// Execute and return the list of Items
			List<T> list = new ArrayList<T>();
			try{
				list = (List<T>) jpaQuery.getResultList();
			}catch(PersistenceException cExeption){
				log.error("Message of Exception : "+cExeption);
			}
			return list;
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#searchByPagesDateRange(java.util.Map,
	 * int, int, java.lang.String, boolean, java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	public List<T> searchByPagesDateRange(Map criterias, int firstItem,
			int batchSize, String sortField, boolean sortAscending,
			String dateField, String fromDate, String toDate)
			throws DAOException {
		StringBuffer query = null;
		try {
			// Build the Query String
			query = new StringBuffer("Select obj from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			Map<String, Object> namedParameter = null;
			// Set the search criteria
			if (criterias != null && criterias.size() > 0) {
				namedParameter = new HashMap<String, Object>();

				Iterator<Map.Entry<String, Object>> it = criterias.entrySet().iterator();
				int i = 0;
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					i++;
					pairs = it.next();
					if (i == 1) {

						query.append(" where ");
					}

					if (pairs.getValue() instanceof String) {
                       			query.append(" ").append(pairs.getKey()).append(
								" = '").append(pairs.getValue()).append(
								"'");
					} else if (pairs.getValue() instanceof Date) {
                       System.out.println("Date type param"+pairs.getValue().toString());
						// nextDate sets the nextDate from the current Date.
						Date nextDate = new Date(((Date) pairs.getValue())
								.getTime() + 86400000l);
						query.append(" ").append(pairs.getKey()).append(" >=:")
								.append(pairs.getKey()).append(" and ").append(
										pairs.getKey()).append(" <:").append(
										"nextDate" + i);
						namedParameter.put(pairs.getKey(), pairs.getValue());
						namedParameter.put("nextDate" + i, nextDate);

					} else {

						query.append(" ").append(pairs.getKey()).append("=:")
								.append(pairs.getKey());
						namedParameter.put(pairs.getKey(), pairs.getValue());
					}

					if (i < criterias.size())
						query.append(" and ");
				}
			}
			// set date Range
			if (dateField != null && fromDate != null && toDate != null) {
				System.out.println("dateField==="+dateField);
				if (criterias != null && criterias.size() > 0) {
					query.append(" and ");
				} else {
					query.append(" where ");
				}
				query.append(dateField + " between ");
				query.append("'" + fromDate + "'");
				query.append(" and ");
				query.append("'" + toDate + "'");
			}
			// Set Order by Field
			if (sortField != null) {
				query.append("  ORDER BY obj.").append(sortField);
				if (sortAscending)
					query.append(" asc");
				else
					query.append(" desc");

			}
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Set the parameter values for the Query
			if (namedParameter != null && namedParameter.size() > 0) {
				Iterator<Map.Entry<String, Object>> it = namedParameter
						.entrySet().iterator();
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					pairs = it.next();
					jpaQuery.setParameter(pairs.getKey(), pairs.getValue());
				}

			}
			// Set limits for Rows count to be fetched
			jpaQuery.setFirstResult(firstItem);
			jpaQuery.setMaxResults(batchSize);
			// Execute and return the list of Items
			return (List<T>) jpaQuery.getResultList();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
	}
    
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#searchByPagesDateRange(java.util.Map,
	 * int, int, java.lang.String, boolean, java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	public List<T> searchByPagesCurrentAndFutureDateRange(Map criterias, int firstItem,
			int batchSize, String sortField, boolean sortAscending,
			String dateField, String fromDate, String toDate)
			throws DAOException {
		StringBuffer query = null;
		try {
			// Build the Query String
			query = new StringBuffer("Select obj from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			Map<String, Object> namedParameter = null;
			// Set the search criteria
			if (criterias != null && criterias.size() > 0) {
				namedParameter = new HashMap<String, Object>();

				Iterator<Map.Entry<String, Object>> it = criterias.entrySet().iterator();
				int i = 0;
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					i++;
					pairs = it.next();
					if (i == 1) {

						query.append(" where ");
					}

					if (pairs.getValue() instanceof String) {
                       	query.append(" ").append(pairs.getKey()).append(
								" like '%").append(pairs.getValue()).append(
								"%'");
					}
					
					/*if (pairs.getValue() instanceof String) {
	                       System.out.println("String type param searchByPagesCurrentAndFutureDateRange=="+pairs.getValue());
							query.append(" ").append(pairs.getKey()).append(
									">=to_Date('").append(pairs.getValue()).append("',").append(
									"'mm/dd/yyyy')");
						}*/
					else if (pairs.getValue() instanceof Date) {
						String currentDate=pairs.getValue().toString();
                       System.out.println("Date type param"+currentDate);
						// nextDate sets the nextDate from the current Date.
						Date nextDate = new Date(((Date) pairs.getValue())
								.getTime() + 86400000l);
						query.append(" ").append(pairs.getKey()).append(" >=:")
								.append(pairs.getKey()).append(" and ").append(
										pairs.getKey()).append(" <:").append(
										"nextDate" + i);
						namedParameter.put(pairs.getKey(), pairs.getValue());
						namedParameter.put("nextDate" + i, nextDate);

					} else {

						query.append(" ").append(pairs.getKey()).append("=:")
								.append(pairs.getKey());
						namedParameter.put(pairs.getKey(), pairs.getValue());
					}

					if (i < criterias.size())
						query.append(" and ");
				}
			}
			// set date Range
			if (dateField != null && fromDate != null) {
				System.out.println("dateField==="+dateField);
				if (criterias != null && criterias.size() > 0) {
					query.append(" and ");
				} else {
					query.append(" where ");
				}
				
				query.append(dateField + " between ");
				query.append("'" + fromDate + "'");
				query.append(" and ");
				query.append("'" + toDate + "'");
				//query.append(dateField + " >= ");
				//query.append("'" + fromDate + "'");
				//query.append(" and ");
				//query.append("'" + toDate + "'");
			}
			// Set Order by Field
			if (sortField != null) {
				query.append("  ORDER BY obj.").append(sortField);
				if (sortAscending)
					query.append(" asc");
				else
					query.append(" desc");

			}
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Set the parameter values for the Query
			if (namedParameter != null && namedParameter.size() > 0) {
				Iterator<Map.Entry<String, Object>> it = namedParameter
						.entrySet().iterator();
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					pairs = it.next();
					jpaQuery.setParameter(pairs.getKey(), pairs.getValue());
				}

			}
			// Set limits for Rows count to be fetched
			jpaQuery.setFirstResult(firstItem);
			jpaQuery.setMaxResults(batchSize);
			// Execute and return the list of Items
			return (List<T>) jpaQuery.getResultList();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#searchByPages(int, int,
	 * java.lang.String, boolean)
	 */
	@Override
	public List<T> searchByPages(int firstItem, int batchSize,
			String sortField, boolean sortAscending) throws DAOException {
		return searchByPages(null, firstItem, batchSize, sortField,
				sortAscending);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#searchByPages(java.util.Map, int, int)
	 */
	@Override
	public List<T> searchByPages(Map criterias, int firstItem, int batchSize)
			throws DAOException {
		return searchByPages(criterias, firstItem, batchSize, null, false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#searchByPages(int, int)
	 */
	@Override
	public List<T> searchByPages(int firstItem, int batchSize)
			throws DAOException {
		return searchByPages(null, firstItem, batchSize, null, false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#getSearchResultSize(java.util.Map)
	 */
	public long getSearchResultSize(Map<String, Object> searchCriteria)
			throws DAOException {
		StringBuffer query = null;
		try {
			// Build the Query String
			query = new StringBuffer("Select count(*) from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			Map<String, Object> namedParameter = null;
			// Set the search criteria for where clause
			if (searchCriteria != null && searchCriteria.size() > 0) {
				namedParameter = new HashMap<String, Object>();
				query.append(" where ");
				Iterator<Map.Entry<String, Object>> it = searchCriteria
						.entrySet().iterator();
				int i = 0;
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					i++;
					pairs = it.next();
					if (pairs.getValue() instanceof String)
						query.append(" ").append(pairs.getKey()).append(
								" like '%").append(pairs.getValue()).append(
								"%'");
					else {
						query.append(" ").append(pairs.getKey()).append("=:")
								.append(pairs.getKey());
						namedParameter.put(pairs.getKey(), pairs.getValue());
					}

					if (i < searchCriteria.size())
						query.append(" and ");
				}
			}
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Return the rows count matching the search criteria
			return ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#searchByPages(java.util.Map, int, int,
	 * java.lang.String, boolean)
	 */
	@Override
	public List<T> searchByPages(Map criterias, int firstItem, int batchSize,
			Map<String, IConstants.SORT_ORDER> sortCriteria)
			throws DAOException {
		StringBuffer query = null;
		try {
			// Build the Query String
			query = new StringBuffer("Select obj from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			Map<String, Object> namedParameter = null;
			// Set the search criteria
			if (criterias != null && criterias.size() > 0) {
				namedParameter = new HashMap<String, Object>();

				Iterator<Map.Entry<String, Object>> it = criterias.entrySet()
						.iterator();
				int i = 0;
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					i++;
					pairs = it.next();
					if (i == 1) {

						query.append(" where ");
					}

					if (pairs.getValue() instanceof String) {

						query.append(" ").append(pairs.getKey()).append(
								" like '%").append(pairs.getValue()).append(
								"%'");
					} else if (pairs.getValue() instanceof StringBuffer) {

						query.append(" ").append(pairs.getKey()).append(" in ")
								.append(pairs.getValue());
					} else if (pairs.getValue() instanceof Date) {

						// nextDate sets the nextDate from the current Date.
						Date nextDate = new Date(((Date) pairs.getValue())
								.getTime() + 86400000l);
						query.append(" ").append(pairs.getKey()).append(" >=:")
								.append(pairs.getKey()).append(" and ").append(
										pairs.getKey()).append(" <:").append(
										"nextDate" + i);
						namedParameter.put(pairs.getKey(), pairs.getValue());
						namedParameter.put("nextDate" + i, nextDate);
					} else {

						query.append(" ").append(pairs.getKey()).append("=:")
								.append(pairs.getKey());
						namedParameter.put(pairs.getKey(), pairs.getValue());
					}
					if (i < criterias.size())
						query.append(" and ");
				}
			}
			// Set Order by Fields
			if (sortCriteria != null) {

				Iterator<Map.Entry<String, IConstants.SORT_ORDER>> sortItr = sortCriteria
						.entrySet().iterator();
				query.append("  ORDER BY ");
				Map.Entry<String, IConstants.SORT_ORDER> sortPairs = null;
				int j = 0;
				while (sortItr.hasNext()) {

					j++;
					sortPairs = sortItr.next();
					// if value is null set order as ascending.
					query.append(sortPairs.getKey()).append(" ").append(
							sortPairs.getValue() != null ? sortPairs.getValue()
									.name() : " ASC ");
					if (j < sortCriteria.size()) {

						query.append(",");
					}
				}
			}
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Set the parameter values for the Query
			if (namedParameter != null && namedParameter.size() > 0) {
				Iterator<Map.Entry<String, Object>> it = namedParameter
						.entrySet().iterator();
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					pairs = it.next();
					jpaQuery.setParameter(pairs.getKey(), pairs.getValue());
				}

			}
			// Set limits for Rows count to be fetched
			jpaQuery.setFirstResult(firstItem);
			jpaQuery.setMaxResults(batchSize);
			// Execute and return the list of Items
			return (List<T>) jpaQuery.getResultList();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
	}

	public long getResultSize(List<SearchCondition> criterias)
			throws DAOException {
		StringBuffer query = null;
		try {
			// Build the Query String
			query = new StringBuffer("Select count(*) from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			Map<String, Object> namedParameter = null;
			// Set the search criteria
			if (criterias != null && criterias.size() > 0) {

				query.append(ConditionBulider.buildCondition(criterias));
			}
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Set Named Parameters
			int i=0;
			for (SearchCondition sc : criterias) {

				if (sc.getValue() instanceof java.util.Date) {

					jpaQuery.setParameter(sc.getAttributeName()+i, sc.getValue());
					i++;
				}
			}
			// Return the rows count matching the search criteria
			return ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
		
	}

	@Override
	public List<T> searchByPages(int firstItem, int batchSize,
			List<SearchCondition> criterias,
			Map<String, IConstants.SORT_ORDER> sortCriteria)
			throws DAOException {
		StringBuffer query = null;
		try {
			// Build the Query String
			query = new StringBuffer("Select obj from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			Map<String, Object> namedParameter = null;
			// Set the search criteria
			if (criterias != null && criterias.size() > 0) {
				query.append(ConditionBulider.buildCondition(criterias));
			}
			// Set Order by Fields
			if (sortCriteria != null) {

				Iterator<Map.Entry<String, IConstants.SORT_ORDER>> sortItr = sortCriteria
						.entrySet().iterator();
				query.append("  ORDER BY ");
				Map.Entry<String, IConstants.SORT_ORDER> sortPairs = null;
				int j = 0;
				while (sortItr.hasNext()) {

					j++;
					sortPairs = sortItr.next();
					// if value is null set order as ascending.
					query.append(sortPairs.getKey()).append(" ").append(
							sortPairs.getValue() != null ? sortPairs.getValue()
									.name() : " ASC ");
					if (j < sortCriteria.size()) {

						query.append(",");
					}
				}
			}
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Set Named Parameters
			int i=0;
			for (SearchCondition sc : criterias) {

				if (sc.getValue() instanceof java.util.Date) {

					jpaQuery.setParameter(sc.getAttributeName()+i, sc.getValue());
					i++;
				}
				
			}
			// Set limits for Rows count to be fetched
			jpaQuery.setFirstResult(firstItem);
			jpaQuery.setMaxResults(batchSize);
			// Execute and return the list of Items
			return (List<T>) jpaQuery.getResultList();
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
	}

	@Override
	public List<T> searchByPages(List<SearchCondition> criterias,
			Map<String, IConstants.SORT_ORDER> sortCriteria)
			throws DAOException {
		StringBuffer query = null;
		try {
			// Build the Query String
			query = new StringBuffer("Select obj from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			Map<String, Object> namedParameter = null;
			// Set the search criteria
			if (criterias != null && criterias.size() > 0) {
				query.append(ConditionBulider.buildCondition(criterias));
			}
			// Set Order by Fields
			if (sortCriteria != null) {

				Iterator<Map.Entry<String, IConstants.SORT_ORDER>> sortItr = sortCriteria
						.entrySet().iterator();
				query.append("  ORDER BY ");
				Map.Entry<String, IConstants.SORT_ORDER> sortPairs = null;
				int j = 0;
				while (sortItr.hasNext()) {

					j++;
					sortPairs = sortItr.next();
					// if value is null set order as ascending.
					query.append(sortPairs.getKey()).append(" ").append(
							sortPairs.getValue() != null ? sortPairs.getValue()
									.name() : " ASC ");
					if (j < sortCriteria.size()) {

						query.append(",");
					}
				}
			}
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());
			// Set Named Parameters
			int i=0;
			for (SearchCondition sc : criterias) {

				if (sc.getValue() instanceof java.util.Date) {

					jpaQuery.setParameter(sc.getAttributeName()+i, sc.getValue());
					i++;
				}
				
			}
			// Execute and return the list of Items
			return (List<T>) jpaQuery.getResultList();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
	}
	
	@Override
	public List<T> searchByPages(int firstItem, int batchSize,
			Map<String, IConstants.SORT_ORDER> sortCriteria)
			throws DAOException {
		return searchByPages(null, firstItem, batchSize, sortCriteria);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#getResultSizeDateRange(java.util.Map,
	 * java.lang.String, java.lang.String, java.lang.String)
	 */
	public long getResultSizeDateRange(Map<String, Object> criterias,
			String dateField, String fromDate, String toDate)
			throws DAOException {
		StringBuffer query = null;
		try {
			// Build the Query String
			query = new StringBuffer("Select count(*) from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			Map<String, Object> namedParameter = null;
			// Set the search criteria
			if (criterias != null && criterias.size() > 0) {

				namedParameter = new HashMap<String, Object>();
				Object[] keyArray = criterias.keySet().toArray();
				for (int i = 0; i < keyArray.length; i++) {

					if (i == 0) {

						query.append(" where ");
					}
					if (criterias.get(keyArray[i]) instanceof String) {

						query.append(" ").append(keyArray[i])
								.append(" like '%").append(
										criterias.get(keyArray[i]))
								.append("%'");
					} else if (criterias.get(keyArray[i]) instanceof StringBuffer) {

						query.append(" ").append(keyArray[i]).append(" in ")
								.append(criterias.get(keyArray[i]));
					} else if (criterias.get(keyArray[i]) instanceof Date) {

						Date nextDate = new Date(((Date) criterias
								.get(keyArray[i])).getTime() + 86400000l);
						query.append(" ").append(keyArray[i]).append(" >=:")
								.append(keyArray[i]).append(" and ").append(
										keyArray[i]).append("<:").append(
										"nextDate" + i);
						namedParameter.put(keyArray[i].toString(), criterias
								.get(keyArray[i]));
						namedParameter.put("nextDate" + i, nextDate);

					} else {

						query.append(" ").append(keyArray[i]).append("=:")
								.append(keyArray[i]);
						namedParameter.put(keyArray[i].toString(), criterias
								.get(keyArray[i]));
					}
					if (i != (keyArray.length - 1)) {

						query.append(" and");
					}
				}

			}

			// set date Range
			if (dateField != null && fromDate != null && toDate != null) {
				if (criterias != null && criterias.size() > 0) {
					query.append(" and ");
				} else {
					query.append(" where ");
				}
				query.append(dateField + " between ");
				query.append("'" + fromDate + "'");
				query.append(" and ");
				query.append("'" + toDate + "'");
			}
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());

			if (namedParameter != null && namedParameter.size() > 0) {
				Iterator<Map.Entry<String, Object>> it = namedParameter
						.entrySet().iterator();
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					pairs = it.next();
					jpaQuery.setParameter(pairs.getKey(), pairs.getValue());
				}
			}
			// Return the rows count matching the search criteria
			return ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ipp.dao.PaginatedDAO#getResultSizeDateRange(java.util.Map,
	 * java.lang.String, java.lang.String, java.lang.String)
	 */
	public long getCurrentAndFutureDateRange(Map<String, Object> criterias,
			String dateField, String fromDate, String toDate)
			throws DAOException {
		StringBuffer query = null;
		try {
			// Build the Query String
			query = new StringBuffer("Select count(*) from ").append(
					getPersistentClass().getSimpleName()).append(" obj");
			Map<String, Object> namedParameter = null;
			// Set the search criteria
			if (criterias != null && criterias.size() > 0) {

				namedParameter = new HashMap<String, Object>();
				Object[] keyArray = criterias.keySet().toArray();
				for (int i = 0; i < keyArray.length; i++) {

					if (i == 0) {

						query.append(" where ");
					}
					if (criterias.get(keyArray[i]) instanceof String) {

						query.append(" ").append(keyArray[i])
								.append(" = '").append(
										criterias.get(keyArray[i]))
								.append("'");
					} else if (criterias.get(keyArray[i]) instanceof StringBuffer) {

						query.append(" ").append(keyArray[i]).append(" in ")
								.append(criterias.get(keyArray[i]));
					} else if (criterias.get(keyArray[i]) instanceof Date) {

						Date nextDate = new Date(((Date) criterias
								.get(keyArray[i])).getTime() + 86400000l);
						query.append(" ").append(keyArray[i]).append(" >=:")
								.append(keyArray[i]).append(" and ").append(
										keyArray[i]).append("<:").append(
										"nextDate" + i);
						namedParameter.put(keyArray[i].toString(), criterias
								.get(keyArray[i]));
						namedParameter.put("nextDate" + i, nextDate);

					} else {

						query.append(" ").append(keyArray[i]).append("=:")
								.append(keyArray[i]);
						namedParameter.put(keyArray[i].toString(), criterias
								.get(keyArray[i]));
					}
					if (i != (keyArray.length - 1)) {

						query.append(" and");
					}
				}

			}
			System.out.println("toDate=="+toDate);

			// set date Range
			if (dateField != null && fromDate != null && toDate != null) {
				if (criterias != null && criterias.size() > 0) {
					query.append(" and ");
				} else {
					query.append(" where ");
				}
				query.append(dateField + " between ");
				query.append("'" + fromDate + "'");
				query.append(" and ");
				query.append("'" + toDate + "'");
			}
			// Create Query Object
			Query jpaQuery = entityManager.createQuery(query.toString());

			if (namedParameter != null && namedParameter.size() > 0) {
				Iterator<Map.Entry<String, Object>> it = namedParameter
						.entrySet().iterator();
				Map.Entry<String, Object> pairs = null;
				while (it.hasNext()) {
					pairs = it.next();
					jpaQuery.setParameter(pairs.getKey(), pairs.getValue());
				}
			}
			// Return the rows count matching the search criteria
			return ((Long) jpaQuery.getSingleResult()).longValue();
		} catch (RuntimeException ex) {
			throw new DAOException("error.executeQuery", ex,
					getPersistentClass().getName(), query);
		}
	}
	
	
	public List<T> findByNamedQuery(String query, String namedParams[],
			Object params[],int firstItem, int batchSize) throws DAOException {
		try {
			// Create a named Query
			Query q = entityManager.createNamedQuery(query);
			// Set Parameter values in named query
			if (namedParams != null) {
				for (int i = 0; i < namedParams.length; i++) {
					q.setParameter(namedParams[i], params[i]);
				}
			}
			q.setFirstResult(firstItem);
			q.setMaxResults(batchSize);
			// Execute query and return the List of items
			return (List<T>) q.getResultList();
		} catch (RuntimeException ex) {
			throw new DAOException("error.findByQuery.entity", ex,
					getPersistentClass().getName(), query);
		}
	}
	
	public List<T> findByNamedQuery(String query, String namedParams[],
			Object params[],int timeOutSec) throws DAOException {
		try {
			// Create a named Query
			Query q = entityManager.createNamedQuery(query);
			// Set Parameter values in named query
			if (namedParams != null) {
				for (int i = 0; i < namedParams.length; i++) {
					q.setParameter(namedParams[i], params[i]);
				}
			}
			q.setHint("javax.persistence.query.timeout", timeOutSec);
			// Execute query and return the List of items
			return (List<T>) q.getResultList();
		} catch (RuntimeException ex) {
			//Dawooth for DD500
			ex.printStackTrace();
			throw new DAOException("error.findByQuery.entity", ex,
					getPersistentClass().getName(), query);
		}
	}
}
