package com.bsf.ipp.dao;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlTransient;

/**
 * Base class for all the entities.
 * @author Rakesh
 *
 */
@XmlTransient
public class Entity implements Serializable {

}
