package com.bsf.ipp.dao;

public abstract class SelectableAuditableCacheableEntity extends SelectableAuditableEntity  implements Cacheable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
