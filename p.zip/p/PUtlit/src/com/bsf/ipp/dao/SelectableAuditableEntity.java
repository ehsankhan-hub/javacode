package com.bsf.ipp.dao;

import java.util.List;

import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.bsf.ppm.auditing.model.Auditable;

/**
 * @author Rashad
 * Abstract class for Selectable and Auditable behavior to the entities
 * 
 */
@XmlTransient
public abstract class SelectableAuditableEntity extends SelectableEntity implements Auditable {
	/**
	 * Attribute serialVersionUID for the SerialVersionUID of the class
	 */
	private static final long serialVersionUID = -4687311450303932568L;
	
	/**
	 * Attribute auditMessage Audit Message used for the entity.
	 */
	protected String auditMessage;

	/* (non-Javadoc)
	 * @see com.bsf.ipp.auditing.model.Auditable#getAuditMessage()
	 */
	@Override
	@Transient
	public String getAuditMessage() {
		return ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE);
	}
	
	/* (non-Javadoc)
	 * @see com.bsf.ipp.auditing.model.Auditable#getPk()
	 */
	@Transient
	public abstract String getPk();
	
	/*@Transient
	public abstract List getListPk();
	*/
	/*@Transient
	public abstract String getValeu1Pk() ;*/
}
