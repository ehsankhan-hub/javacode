package com.bsf.ipp.dao;

import java.io.Serializable;


/**
 * All internal message structures implement MessageObject base interface.
 * Different adapters will handle preparing these messages differently.
 * @author Rakesh
 *
 */
public interface MessageObject extends Serializable {

}
