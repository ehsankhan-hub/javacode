package com.bsf.ipp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.LinkedList;

public class IPPUTIL {
	public static byte[] getBytes(Object obj) throws java.io.IOException {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(bos);
		oos.writeObject(obj);
		oos.flush();
		oos.close();
		bos.close();
		byte[] data = bos.toByteArray();
		return data;
	}

	public static Object decodeToObject(byte[] objBytes) throws Exception {

		ByteArrayInputStream bais = new ByteArrayInputStream(objBytes);
		ObjectInputStream ois = new ObjectInputStream(bais);
		Object obj = ois.readObject();
		bais.close();
		ois.close();
		return obj;
	}
	public static String buildExceptionMessage(Throwable e) {
		StringBuilder sb=new StringBuilder();
		LinkedList<String> list=new LinkedList<String> ();
		list.addFirst(e.getMessage());
		while(e.getCause() != null){
			e=e.getCause();
			list.addFirst(e.getMessage());
		}
		for(String s:list){
			sb.append(s).append("<br>");
			
		}
    	return	sb.toString();
	
	}
	public static String getEftType(String messageType){
	   if("103".equals(messageType)){
		   return "SCPAY";
	   }else  if("202".equals(messageType)){
		   return "SIPAY";
	   }else  if("102".equals(messageType)){
		   return "BCPAY";
	   }else{
		   return "";
	   }
	}
}
