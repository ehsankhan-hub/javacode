package com.bsf.ipp;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.TableGenerator;


/**
 * <p>
 * Pojo mapping TABLE audit_record
 * </p>
 * <p>
 * </p>
 * 
 * <p>
 * Generated at Wed Mar 18 11:55:46 AST 2009
 * </p>
 * 
 * @author Salto-db Generator v1.0.16 / EJB3
 * 
 */
@Entity
@Table(name = "audit_record")
@SuppressWarnings("serial")
public class AuditRecord implements Serializable {

	/**
	 * Attribute id.
	 */
	private Long id;

	/**
	 * Attribute operationType.
	 */
	private String operationType;

	/**
	 * Attribute operationKey.
	 */
	private String operationKey;

	/**
	 * Attribute auditRecordType.
	 */
	private String auditRecordType;

	/**
	 * Attribute message.
	 */
	private String message;

	/**
	 * Attribute operationDate.
	 */
	private Timestamp operationDate;

	/**
	 * Attribute auditRecord
	 */
	private AuditRecord auditRecord;

	/**
	 * Attribute userInfo
	 */
	//private UserInfo userInfo;
	private String userId;

	/**
	 * List of AuditRecord
	 */
	private Set<AuditRecord> auditRecords = null;

	/**
	 * <p>
	 * </p>
	 * 
	 * @return id
	 */
	@Id
	@Basic
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "auditLogIdGen")
	@TableGenerator(name = "auditLogIdGen", table = "idgen", allocationSize = 1, pkColumnName = "table_name", pkColumnValue = "AUDIT_LOG", valueColumnName = "id_value")
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            new value for id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * <p>
	 * </p>
	 * 
	 * @return operationType
	 */
	@Basic
	@Column(name = "operation_type", length = 50)
	public String getOperationType() {
		return operationType;
	}

	/**
	 * @param operationType
	 *            new value for operationType
	 */
	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	/**
	 * <p>
	 * </p>
	 * 
	 * @return operationKey
	 */
	@Basic
	@Column(name = "operation_key", length = 200)
	public String getOperationKey() {
		return operationKey;
	}

	/**
	 * @param operationKey
	 *            new value for operationKey
	 */
	public void setOperationKey(String operationKey) {
		this.operationKey = operationKey;
	}

	/**
	 * <p>
	 * </p>
	 * 
	 * @return auditRecordType
	 */
	@Basic
	@Column(name = "audit_record_type", length = 10)
	public String getAuditRecordType() {
		return auditRecordType;
	}

	/**
	 * @param auditRecordType
	 *            new value for auditRecordType
	 */
	public void setAuditRecordType(String auditRecordType) {
		this.auditRecordType = auditRecordType;
	}

	/**
	 * <p>
	 * </p>
	 * 
	 * @return message
	 */
	@Basic
	@Column(name = "message", length = 1000)
	public String getMessage() {
		return message;
	}

	/**
	 * @param message
	 *            new value for message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * <p>
	 * </p>
	 * 
	 * @return operationDate
	 */
	@Basic
	@Column(name = "operation_date")
	public Timestamp getOperationDate() {
		return operationDate;
	}

	/**
	 * @param operationDate
	 *            new value for operationDate
	 */
	public void setOperationDate(Timestamp operationDate) {
		this.operationDate = operationDate;
	}

	/**
	 * get auditRecord
	 */
	@ManyToOne
	@JoinColumn(name = "parent_id")
	public AuditRecord getAuditRecord() {
		return this.auditRecord;
	}

	/**
	 * set auditRecord
	 */
	public void setAuditRecord(AuditRecord auditRecord) {
		this.auditRecord = auditRecord;
	}


	@Basic
	@Column(name = "user_id", length = 20)
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Get the list of AuditRecord
	 */
	
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "auditRecord", cascade=CascadeType.ALL)
	public Set<AuditRecord> getAuditRecords() {
		if (this.auditRecords == null)
			auditRecords = new HashSet<AuditRecord>();
		return auditRecords;
	}

	/**
	 * Set the list of AuditRecord
	 */
	public void setAuditRecords(Set<AuditRecord> auditRecords) {
		this.auditRecords = auditRecords;
	}

}