package com.bsf.ipp;

/**
 * @author rsaif
 *
 */
public class ContactObject {
	private String primaryEmail;
	private String secondaryEmail;
	public String getPrimaryEmail() {
		return primaryEmail;
	}
	public void setPrimaryEmail(String primaryEmail) {
		this.primaryEmail = primaryEmail;
	}
	public String getSecondaryEmail() {
		return secondaryEmail;
	}
	public void setSecondaryEmail(String secondaryEmail) {
		this.secondaryEmail = secondaryEmail;
	}
	
	public ContactObject(String primaryEmail,String secondaryEmail){
		this.primaryEmail=primaryEmail;
		this.secondaryEmail=secondaryEmail;
	}
	

}
