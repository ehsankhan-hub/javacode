package com.bsf.ppm.batch;

public interface ExternalJob extends BatchRunJob {

}
