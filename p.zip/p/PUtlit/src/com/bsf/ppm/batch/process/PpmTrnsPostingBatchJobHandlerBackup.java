package com.bsf.ppm.batch.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.bsf.ppm.batch.JobException;
import com.bsf.ppm.batch.handler.SpringManagedJobHandler;
import com.bsf.ppm.batch.processor.InstTransactionProcessor;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.constants.IConstants.SORT_ORDER;
import com.bsf.ppm.dao.InstTransactionsDAO;
import com.bsf.ppm.dao.InstructionDAO;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.fts.FTSResponsePostingEntity;
import com.bsf.ppm.Ppm_Inst_Transactions;
import com.bsf.ppm.Ppm_Instructions;
import com.bsf.ppm.spring.SpringAppContext;
import com.bsf.ipp.dao.jpa.SearchCondition;

/**
 * 
 * @author Ehsan Ahmad Khan
 * 
 */
@Transactional(readOnly = true, rollbackFor = DAOException.class)
public class PpmTrnsPostingBatchJobHandlerBackup extends SpringManagedJobHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7259004937647187624L;

	/**
	 * logger
	 */

	private static final Logger logger = Logger
			.getLogger(PpmTrnsPostingBatchJobHandlerBackup.class);

	private InstTransactionsDAO instTransactionsDAO;
	private InstructionDAO instructionDAO;
	private ThreadPoolTaskExecutor ppmProcessTaskExecutor;
	private InstTransactionProcessor instTransactionProcessor;

	private PpmTrnsType ppmTrnsType = new PpmTrnsType();

	public InstTransactionsDAO getInstTransactionsDAO() {
		instTransactionsDAO = (InstTransactionsDAO) SpringAppContext
				.getBean("instTransactionsDAO");

		return instTransactionsDAO;
	}

	public PpmTrnsType getPpmTrnsType() {
		ppmTrnsType = (PpmTrnsType) SpringAppContext.getBean("salryP");
		return ppmTrnsType;
	}

	public InstructionDAO getInstructionDAO() {
		instructionDAO = (InstructionDAO) SpringAppContext
				.getBean("instructionDAO");
		return instructionDAO;
	}

	public void setInstTransactionsDAO(InstTransactionsDAO instTransactionsDAO) {
		this.instTransactionsDAO = instTransactionsDAO;
	}

	public ThreadPoolTaskExecutor getTaskExecutor() {
		if (ppmProcessTaskExecutor == null)
			ppmProcessTaskExecutor = (ThreadPoolTaskExecutor) SpringAppContext
					.getBean("ppmProcessTaskExecutor");
		return ppmProcessTaskExecutor;
	}

	public void setTaskExecutor(ThreadPoolTaskExecutor ppmProcessTaskExecutor) {
		this.ppmProcessTaskExecutor = ppmProcessTaskExecutor;
	}

	public InstTransactionProcessor getInstTransactionProcessor() {
		if (instTransactionProcessor == null)
			instTransactionProcessor = (InstTransactionProcessor) SpringAppContext
					.getBean("itmsCustomerMessageProcessor");
		return instTransactionProcessor;
	}

	public void setInstTransactionProcessor(
			InstTransactionProcessor instTransactionProcessor) {
		this.instTransactionProcessor = instTransactionProcessor;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
	public void runJobInContext() throws JobException {

		List<Ppm_Inst_Transactions> lstPendingTransactions = null;
		String schemaName="";
		try {

			logger.info("PPM Job is started ......................");

			Map<String, IConstants.SORT_ORDER> sortCriteria = new HashMap<String, IConstants.SORT_ORDER>();
			sortCriteria.put("id", SORT_ORDER.ASC);

			List<SearchCondition> searchCondition = new ArrayList<SearchCondition>();
			searchCondition.add(new SearchCondition("ppm_process_status",
					"'N'", IConstants.SYMBOL_EQUAL));
			searchCondition.add(new SearchCondition("sourceSystem", "'SPP'",
					IConstants.SYMBOL_EQUAL));
			try {

				lstPendingTransactions = (List<Ppm_Inst_Transactions>) getInstTransactionsDAO().getTrnsBackendProcDtl();
				//Getting database schema name to create Citizen Accounts
				schemaName=getPpmTrnsType().getDatabaseSchema();
				logger.info("Database schema name : "+schemaName);	
			} catch (DAOException e) {

				logger.error(
						"System failed to retrieve entities data for Ppm_Inst_Transactions",
						e);
				throw e;
			}

			if (lstPendingTransactions != null
					&& lstPendingTransactions.size() > 0) {
				int instPendSize = lstPendingTransactions.size();
				logger.info("Total number of instructions received to process ="
						+ instPendSize);


				for (int i = 0; i < instPendSize; i++) {
					Ppm_Inst_Transactions pendingTrans = lstPendingTransactions.get(i);
					// --------------------------------------Start---------------------------------------------------------

					if (pendingTrans.getTrnsType().trim().equals("TTAC")) {

						logger.info("TTAC Case For SPP for Transaction Ref= "
								+ pendingTrans.getInstRef());

						PostTTAC_SPP(pendingTrans);

					} else if ( ((pendingTrans.getTrnsType().trim().equals("AATR"))||(pendingTrans.getTrnsType().trim().equals("CPTR")))
							&& pendingTrans.getCreditAcc() != null) {

						logger.info("AATR Case For SPP for Transaction Ref= "
								+ pendingTrans.getInstRef());

						PostAATR_SPP(pendingTrans);

					} else if (pendingTrans.getTrnsType().trim().equals("AATR")
							&& pendingTrans.getCreditAcc() == null) {

						logger.info("AATR Case For Salary Percentage for Transaction Ref= "
								+ pendingTrans.getInstRef());

						PostAATR_SPP_SAL(pendingTrans,schemaName);
					}

					// --------------------------------END---------------------------------------------------------------

				}
			}
		} catch (Exception de) {

			logger.error("Error while Processing SPP & Salary Percentage Posting Batch "
					+ de.getMessage());
		}
		logger.info("PPM Job is ended ......................");
	}

	private void PostAATR_SPP_SAL(Ppm_Inst_Transactions pendingTrans,String schemName)
			throws ApplicationException {
		try {

			// debit acct balance check
			
			Integer debitAcctbalance = getPpmTrnsType().getcustDebitAccountBalance(pendingTrans);
			if ( debitAcctbalance != null) { // debitAcctbalance == null |
											// debitAcctbalance == -1
				logger.info("AATR CAMM Action code at the time of debit account balance check ="
						+ debitAcctbalance.toString());
				if (debitAcctbalance == -1) {
					getInstTransactionsDAO().updateInstTransactions(
							pendingTrans, "", "",
							"F");

					return;
				}

			} else if (debitAcctbalance == null) {

				logger.info("AATR CAMM Action code at the time of debit account balance check ="
						+ debitAcctbalance);

				getInstTransactionsDAO().updateInstTransactions(pendingTrans,
						"", "", "F");

				return;
			}

			List<String> ctznResult;

			ctznResult = getPpmTrnsType().getCtznAccount(pendingTrans.getDebitAcc(),schemName);

			if (ctznResult.size() > 0 && (!IsEmpty(ctznResult.get(0)))
					&& ctznResult.get(1).equals("0000")) {

				getInstTransactionsDAO().updateInstTransactionsCtznAccount(
						ctznResult.get(0), pendingTrans.getPpmTrnsRef());
				//set in transaction entity
				pendingTrans.setCreditAcc(ctznResult.get(0));
				
			} else {
				// citizen account have error.
				logger.info("Error in Citizen account = " + ctznResult.get(1));
				getInstTransactionsDAO().updateInstTransactions(pendingTrans,
						ctznResult.get(1), "", "F");

				return;
			}
			

			FTSResponsePostingEntity tuxedoResponse = getPpmTrnsType()
					.tuxUpdateAATR(pendingTrans, "");

			if (tuxedoResponse.getCAMMActionCode().equals("0000")
					&& tuxedoResponse.getFTSActionCode().equals("0000")) {
				
				getInstTransactionsDAO().updateInstTransactions(pendingTrans,
						tuxedoResponse.getFTSActionCode(),
						tuxedoResponse.getCAMMActionCode(), "P");

			} else {

				logger.info("(PostAATR_SPP_SAL)===> CAM Action code ="
						+ tuxedoResponse.getFTSActionCode()
						+ "Fin Action code = "
						+ tuxedoResponse.getFTSActionCode());

				getInstTransactionsDAO().updateInstTransactions(pendingTrans,
						tuxedoResponse.getCAMMActionCode(),
						tuxedoResponse.getFTSActionCode(), "F");
			}
			/*
			 * else { if (tuxedoResponse.getCAMMActionCode().equals("7777"))
			 * Reversed(pendingTrans, "REV");
			 * 
			 * getInstTransactionsDAO().updateInstTransactions(pendingTrans,
			 * tuxedoResponse.getFTSActionCode(),
			 * tuxedoResponse.getCAMMActionCode(), "F"); return;
			 * 
			 * }
			 */
		} catch (Exception e) {
			logger.error("Error in Method PostAATR_SPP_SAL " + e.getMessage());
			getInstTransactionsDAO().updateInstTransactions(pendingTrans, "",
					"", "ER");
			// throw e;
		}
	}

	private void PostAATR_SPP(Ppm_Inst_Transactions pendingTrans)
			throws DAOException, ApplicationException {
		String creditAcctStatus = null;
		Integer debitAcctbalance = null;
		int updateCount=0;
		try {
			// Changes to handle multiple salary for Salary
			// Percentage project start
			// activate Instructions
			Ppm_Instructions instruction = getInstructionDAO().getById(
					pendingTrans.getInstRef());

			activatingStatement(pendingTrans);

			// debit acct balance check
			debitAcctbalance = getPpmTrnsType().getcustDebitAccountBalance(
					pendingTrans);

			if ((debitAcctbalance != null && debitAcctbalance == -1)
					|| (!getPpmTrnsType().getAccountStatus(pendingTrans))) {
				logger.info("(PostAATR_SPP)==> Balance for debit account is not matching with transaction amount or status is wrong. ");
				getInstTransactionsDAO().updateInstTransactions(pendingTrans,
						"", "", "F");
				return;
			} else if (debitAcctbalance == null) {
				logger.info("(PostAATR_SPP)==> Balance for debit account is null");
				getInstTransactionsDAO().updateInstTransactions(pendingTrans,
						"", "", "E");
				return;

			}
			
			// Credit Account status check
			
			if (IsEmpty(pendingTrans.getCreditAcc())) {
				logger.info("(PostAATR_SPP)==> Credit account is null");
				getInstTransactionsDAO().updateInstTransactions(pendingTrans,
						"", "", "E");
				return;
			}

			creditAcctStatus = getPpmTrnsType().getcustCreditAccountStatus(pendingTrans,"");

			if (creditAcctStatus != null && creditAcctStatus.equals("CLOSE")) {
            
				logger.info("(PostAATR_SPP)===> Credit account status is  ="
						+ creditAcctStatus);

				getInstTransactionsDAO().updateInstTransactions(pendingTrans,
						"", "", "CL");
				return;
			} //else if (creditAcctStatus == null) {
			else {
				// Credit account Status check for Virtual accounts
				if (pendingTrans.getTrnsType().equals("CPTR")) {
					creditAcctStatus = getPpmTrnsType().getcustCreditAccountStatus(pendingTrans,"CMPINQ01");
			}
				if (creditAcctStatus == null
						&& pendingTrans.getTrnsType().equals("CPTR")) {
					logger.info("(PostAATR_SPP)==> Credit account status is null");
					getInstTransactionsDAO().updateInstTransactions(
							pendingTrans, "", "", "CL");
					return;
				}// SFL
				else {
				// calling postingSFL to handle CPTR (Company payment). 	
				updateCount=	postingSFL(pendingTrans, instruction);
					
				}

			}
			
		
			switch (updateCount) {
			case 1:
				Success(pendingTrans);
				break;
			case 2:
				Closed(pendingTrans);
				break;

			default:
				logger.info("Number of Instruction " + updateCount
						+ " is updated");
				// Reversed(pendingTrans, "REV");

			}

		} catch (Exception e) {
			logger.error(
					"Error occured in transaction. Error " + e.getMessage(), e);
			String strError = (debitAcctbalance == null) ? ""
					: debitAcctbalance.toString();
			getInstTransactionsDAO().updateInstTransactions(pendingTrans,
					strError, "", "ER");
		}

	}

	private void PostTTAC_SPP(Ppm_Inst_Transactions pendingTrans)
			throws DAOException, ApplicationException,
			com.bsf.ppm.batch.process.exception.DAOException {

		Ppm_Instructions instruction = getInstructionDAO().getById(
				pendingTrans.getInstRef());
		activatingStatement(pendingTrans);

		Integer debitAcctbalance = getPpmTrnsType().getcustDebitAccountBalance(
				pendingTrans);

		// check credit account not null
		if (IsEmpty(pendingTrans.getCreditAcc())) {
			logger.info("(PostTTAC_SPP)==> Credit account is null");

			getInstTransactionsDAO().updateInstTransactions(pendingTrans, "",
					"", "E");
			return;
		}

		if (debitAcctbalance != null && debitAcctbalance > -1) {
			if (getPpmTrnsType().getAccountStatus(pendingTrans)) {
				try {
					FTSResponsePostingEntity tuxPostResponse = getPpmTrnsType()
							.tuxUpdateTTAC(pendingTrans, "");

					if (tuxPostResponse.getCAMMActionCode().equals("0000")
							&& tuxPostResponse.getFTSActionCode()
									.equals("0000")) {

						getInstTransactionsDAO().updateInstTransactions(
								pendingTrans,
								tuxPostResponse.getFTSActionCode(),
								tuxPostResponse.getCAMMActionCode(), "P");

					} else {
						logger.info("(PostTTACC)===> AMMActionCode is other than 0000 ");

						getInstTransactionsDAO().updateInstTransactions(
								pendingTrans,
								tuxPostResponse.getCAMMActionCode(),
								tuxPostResponse.getFTSActionCode(), "F");

					}
					

					int updateCount = getInstructionDAO().updateInstruction(
							pendingTrans, instruction,
							pendingTrans.getTrnsAmount());

					switch (updateCount) {
					case 1:
						Success(pendingTrans);
						break;
					case 2:
						Closed(pendingTrans);
						break;

					default:
						logger.info("Number of Instruction " + updateCount
								+ " is updated");
						// Reversed(pendingTrans, "REV");

					}

				} catch (Exception e) {
					logger.info(
							"Excepttion Occured in PostTTAC method ="
									+ e.getMessage(), e);

					getInstTransactionsDAO().updateInstTransactions(
							pendingTrans, "", "", "ER");

				}

			}// end of checking debit account status
			else {
				// when debit acct status is other than "DB,FB,OP"(avaibale in
				// database) then mark the transaction status as fail
				logger.info("debit acct status is other than DB,FB,OP(avaibale in database) then mark the transaction status as fail");

				getInstTransactionsDAO().updateInstTransactions(pendingTrans,
						"", "", "F");
				return;

			}

		} // posted ttac and no response error handling
		else {
			// when debit balance is less than transaction amount then mark the
			// transaction status as fail
			logger.info("debit balance is less than transaction amount then mark the transaction status as fail");

			getInstTransactionsDAO().updateInstTransactions(pendingTrans, "",
					"", "F");
			return;
		}
	}

	private void Reversed(Ppm_Inst_Transactions pendingTrans, String status)
			throws ApplicationException {

		FTSResponsePostingEntity tuxedoResponse = null;

		try {

			tuxedoResponse = getPpmTrnsType().tuxUpdateTTAC(pendingTrans,
					status);
			if (tuxedoResponse.getCAMMActionCode().trim().equals("0000")) {
				logger.info("Reversal for transtion reference ::"
						+ pendingTrans.getPpmTrnsRef() + " Successfull");

			}
			getInstTransactionsDAO().updateInstTransactions(pendingTrans,
					tuxedoResponse.getCAMMActionCode(),
					tuxedoResponse.getFTSActionCode(), "E");

		} catch (Exception e) {

			getInstTransactionsDAO().updateInstTransactions(pendingTrans,
					tuxedoResponse.getCAMMActionCode(),
					tuxedoResponse.getFTSActionCode(), "E");

		}

	}

	private void Closed(Ppm_Inst_Transactions pendingTrans) {

		logger.info("(Closed)===> Payment already cleared for instReference::"
				+ pendingTrans.getInstRef());
	}

	private void Success(Ppm_Inst_Transactions pendingTrans) throws DAOException {

		logger.info("PPM_INSTRUCTIONS table updated successfully for instReference::"
				+ pendingTrans.getInstRef());

		/*
		 * countInstTrns = getInstTransactionsDAO().updateInstTransactions(
		 * pendingTrans, cammCode, ftsCode, "P"); if (countInstTrns == 1) {
		 * logger .info(
		 * "Ppm_Inst_Transactions table updated successfully for instReference::"
		 * + instTransactions.getInstRef()); }
		 */

	}

	/**
	 * This method will fetch instruction and updating instruction as ACT
	 * 
	 * @param instTrns2
	 * @throws DAOException
	 */
	private void activatingStatement(Ppm_Inst_Transactions transaction)
			throws DAOException {
		if (transaction.getStatus().equals("Pending")
				&& !"P".equals(transaction.getInstRef().subSequence(0, 1))) {
			Ppm_Instructions ppmInstruction = getInstructionDAO().getById(transaction.getInstRef());
			logger.info("InstReference==" + ppmInstruction.getInstReference());
			if (!"P".equals(ppmInstruction.getInstReference().subSequence(0, 1))) {
				ppmInstruction.setStatus("ACT");
				getInstructionDAO().update(ppmInstruction);
			}
		}
	}
	
	
	/**
	 * @throws Exception
	 * @throws DAOException
	 */
	public int postingSFL(Ppm_Inst_Transactions pendingTrans,
			Ppm_Instructions instruction) throws Exception, DAOException {
		boolean tuxResFlag=false;
		FTSResponsePostingEntity tuxedoResponseBKC = null;
		FTSResponsePostingEntity tuxedoResponse = null;
		int updateCount = 0;
		tuxedoResponse = getPpmTrnsType().tuxUpdateAATR(pendingTrans, "");
		if (tuxedoResponse != null
				&& tuxedoResponse.getCAMMActionCode().equals("0000")
				&& tuxedoResponse.getFTSActionCode().equals("0000")) {
			getInstTransactionsDAO().updateInstTransactions(pendingTrans,
					tuxedoResponse.getFTSActionCode(),
					tuxedoResponse.getCAMMActionCode(), "P");
			updateCount = getInstructionDAO().updateInstruction(pendingTrans,
					instruction, pendingTrans.getTrnsAmount());

		} else {
			// Financial for Virtual Accounts instead of FINUPD04 using CMPUPD04
			tuxedoResponseBKC = getPpmTrnsType().tuxUpdateAATR(pendingTrans,
					"CMPUPD04");

			if ((tuxedoResponseBKC != null
					&& tuxedoResponseBKC.getCAMMActionCode().equals("0000") && tuxedoResponseBKC
					.getFTSActionCode().equals("0000"))) {
				getInstTransactionsDAO().updateInstTransactions(pendingTrans,
						tuxedoResponseBKC.getFTSActionCode(),
						tuxedoResponseBKC.getCAMMActionCode(), "P");
				 updateCount = getInstructionDAO().updateInstruction(pendingTrans,
				 instruction, pendingTrans.getTrnsAmount());

			} else {
				tuxResFlag=true;
				logger.info("CAM Action code ="
						+ tuxedoResponseBKC.getFTSActionCode()
						+ "Fin Action code = "
						+ tuxedoResponseBKC.getFTSActionCode());

				getInstTransactionsDAO().updateInstTransactions(pendingTrans,
						tuxedoResponseBKC.getCAMMActionCode(),
						tuxedoResponseBKC.getFTSActionCode(), "F");

			}
		}
		if (!tuxResFlag&&tuxedoResponse != null
				&& !tuxedoResponse.getCAMMActionCode().equals("0000")
				&& !tuxedoResponse.getFTSActionCode().equals("0000")) {
			logger.info("CAM Action code =" + tuxedoResponse.getFTSActionCode()
					+ "Fin Action code = " + tuxedoResponse.getFTSActionCode());

			getInstTransactionsDAO().updateInstTransactions(pendingTrans,
					tuxedoResponse.getCAMMActionCode(),
					tuxedoResponse.getFTSActionCode(), "F");
		}
		return updateCount;
	}

	public boolean IsEmpty(String str) {
		if (str != null && !str.isEmpty() && str != "")
			return false;
		else
			return true;
	}

}