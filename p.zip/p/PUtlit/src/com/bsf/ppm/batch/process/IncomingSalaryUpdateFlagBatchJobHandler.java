package com.bsf.ppm.batch.process;

import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.bsf.ppm.batch.JobException;
import com.bsf.ppm.batch.handler.SpringManagedJobHandler;
import com.bsf.ppm.dao.LoanBlockDetsDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.spring.SpringAppContext;

/**
 * 
 * @author Ehsan Ahmad Khan
 * 
 */
@Transactional(readOnly = true, rollbackFor=DAOException.class)
public class IncomingSalaryUpdateFlagBatchJobHandler extends SpringManagedJobHandler{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7259004937647187867L;

	/** 
	 * logger
	 */
	
	private static final Logger logger = Logger.getLogger(IncomingSalaryUpdateFlagBatchJobHandler.class);
	
	private LoanBlockDetsDAO loanBlockDetsDAO;
  
	public LoanBlockDetsDAO getLoanBlockDetsDAO() {
		loanBlockDetsDAO = (LoanBlockDetsDAO) SpringAppContext.getBean("loanBlockDetsDAO");
		
		return loanBlockDetsDAO;
	}
	public void setLoanBlockDetsDAO(LoanBlockDetsDAO loanBlockDetsDAO) {
		this.loanBlockDetsDAO = loanBlockDetsDAO;
	}
	@Override
	 @Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
	 public void runJobInContext() throws JobException {
		try {
			logger.info("Job is running successfully ");

			int updateCount = getLoanBlockDetsDAO().updateIncomingSalaries();
			if (updateCount > 0) {
				logger.info("Trying to process Incoming_Salaries to Y table  ::" + updateCount);
			} else {
				logger.info("No record found to Update Incoming_Salaries table");
			}
		}
	catch(DAOException de){
	de.printStackTrace();	
	}
	
		
	//By SARaheem
		
		
		try {
			logger.info("Job (part 2) is running successfully  ");

			int updateCount = getLoanBlockDetsDAO().updateIncomingSalariesStatus_P();
			if (updateCount > 0) {
				logger.info("Trying to process Incoming_Salaries to P table ::" + updateCount);
			} else {
				logger.info("No record found to Update Incoming_Salaries table");
			}
		}
	catch(DAOException de){
	de.printStackTrace();	
	}
		
		
		
		
		
		
		
	}
}
