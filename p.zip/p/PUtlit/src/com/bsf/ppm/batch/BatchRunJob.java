package com.bsf.ppm.batch;

public interface BatchRunJob {
	
}
