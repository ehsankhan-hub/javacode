package com.bsf.ppm.batch.process.exception;

public class ProcessException extends ApplicationException {

	public ProcessException() {
		// TODO Auto-generated constructor stub
	}

	public ProcessException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ProcessException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ProcessException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
