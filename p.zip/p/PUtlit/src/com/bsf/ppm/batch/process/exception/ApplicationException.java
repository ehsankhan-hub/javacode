package com.bsf.ppm.batch.process.exception;

import org.apache.log4j.Logger;

public class ApplicationException extends Exception {

	private static final Logger logger = Logger
			.getLogger(ApplicationException.class);

	public ApplicationException() {
		logger.error("Error occured in application");
	}

	public ApplicationException(String arg0) {
		super(arg0);
		logger.error("Error occured in application. Error " + arg0);
	}

	public ApplicationException(Throwable arg0) {
		super(arg0);
		logger.error(
				"Error occured in application. Error " + arg0.getMessage(),
				arg0);
	}

	public ApplicationException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		logger.error("Error occured in application. Error " + arg0, arg1);
	}

}
