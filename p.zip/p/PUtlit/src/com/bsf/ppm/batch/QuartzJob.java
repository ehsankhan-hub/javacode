package com.bsf.ppm.batch;

import org.quartz.StatefulJob;

public interface QuartzJob extends StatefulJob, BatchRunJob {

}
