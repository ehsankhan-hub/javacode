package com.bsf.ppm.batch.process;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.bsf.ppm.LoanBlockDets;
import com.bsf.ppm.ParameterValue;
import com.bsf.ppm.Ppm_Inst_Transactions;
import com.bsf.ppm.batch.process.exception.DAOException;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.dao.InstTransactionsDAO;
import com.bsf.ppm.dao.ParameterValueDAO;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.fts.AccountInquiryRequest;
import com.bsf.ppm.fts.AccountInquiryResponse;
import com.bsf.ppm.fts.FTSRequestPostingEntityAATR;
import com.bsf.ppm.fts.FTSRequestPostingEntityMRKI;
import com.bsf.ppm.fts.FTSRequestPostingEntityTTAC;
import com.bsf.ppm.fts.FTSResponsePostingEntity;
import com.bsf.ppm.service.posting.FTSPostingService;
import com.bsf.ppm.service.posting.FTSPostingServiceImpl;
import com.bsf.ppm.spring.SpringAppContext;
import com.bsf.ppm.util.JNDIUtil;
import com.bsf.ppm.util.StringUtils;

public class PpmTrnsType {
	private static final Logger log = Logger.getLogger("com.bsf.ppm.tuxedo");
	private FTSPostingService ftsService = null;
	FTSRequestPostingEntityAATR postEntityAATR = null;
	FTSRequestPostingEntityTTAC postEntityTTAC = null;
	FTSRequestPostingEntityMRKI postEntityMRKI = null;
	private String trnsStatus = "";
	private String trnsType = "";
	private String instReference = "";
	private Date trnsDate = null;
	private Date valueDate = null;
	private String trnsCrncy = "";
	private BigDecimal trnsAmount;
	private Double trnsAmountSar;
	private String genNarrative = "";
	private String screenNarrative = "";
	private String benBankAddress1;
	private String benBankAddress2;
	private String benName;
	private String benBank;
	private String benCountry;
	private String benBankCode;
	private String paymentDtls;
	private String debitActNo = "";
	private String debitActCrncy = "";
	private Double debitAmount;
	private Date debitValueDate = null;
	private String creditActNo = "";
	private String creditActCrncy = "";
	private Double creditAmount;
	private Date creditValueDate = null;
	private String commCrncy = "";
	private Double commAmount;
	private String commAct = "";
	private String chrgesCrncy = "";
	private Double chrgesAmount;
	private String chrgesAct = "";
	// private String sourceSystem="";
	private String processStatus = "";
	private String trnsAmt = "";
	private String sourceSystem = "";
	private String trnsReference = "";
	private String blckReference = "";
	private String businessDate = "";
	private String remitterName;
	private List<ParameterValue> parameterValue = null;
	private ParameterValueDAO parameterVDAO;

	private String acctStatusFromDB = "";
	private boolean customerAcctFlag = false;
	private AccountInquiryResponse accountInqRes = null;
	private InstTransactionsDAO instTransactionsDAO = null;
	private String debitActDBFlag = "";
	private String overDraftFlag = "";
	private String acctTypeFromDB = "";
	private boolean debitActforPercenSalaryDBFlag = false;
	private DataSource dataSource;

	public InstTransactionsDAO getInstTransactionsDAO() {
		instTransactionsDAO = (InstTransactionsDAO) SpringAppContext
				.getBean("instTransactionsDAO");

		return instTransactionsDAO;
	}

	public List<ParameterValue> getParameterValue() {
		return parameterValue;
	}

	public void setParameterValue(List<ParameterValue> parameterValue) {
		this.parameterValue = parameterValue;
	}

	public ParameterValueDAO getParameterVDAO() {
		parameterVDAO = (ParameterValueDAO) SpringAppContext
				.getBean("parameterVDAO");
		return parameterVDAO;
	}

	public void setParameterVDAO(ParameterValueDAO parameterVDAO) {
		this.parameterVDAO = parameterVDAO;
	}

	// Transaction type AATR message preparation and posting to tuxedo
	public FTSResponsePostingEntity tuxUpdateAATR(
			Ppm_Inst_Transactions instTrns, String pPm_Trns_Status)
			throws Exception {
		postEntityAATR = new FTSRequestPostingEntityAATR();
		FTSRequestPostingEntityAATR trnsMsg = null;
		ftsService = new FTSPostingServiceImpl();
		FTSResponsePostingEntity fINUpdateResponse = null;
		// businessDate=getInstTransactionsDAO().loadBusinessDate();
		// get the new instance of FTSRequestPostingEntity
		trnsMsg = postEntityAATR.getInstance();
       if(pPm_Trns_Status.equals("CMPUPD04"))
		trnsMsg.setRequestFunction("CMPUPD04");
       else
    	trnsMsg.setRequestFunction("FINUPD04");   
       
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		try {

			if (IsEmpty(instTrns.getDebitAcc())
					|| IsEmpty(instTrns.getCreditAcc())) {
				return fINUpdateResponse;

			}

			processStatus = instTrns.getStatus();
			trnsType = instTrns.getTrnsType();
			trnsReference = instTrns.getPpmTrnsRef();
			trnsDate = instTrns.getTrnsDate();
			valueDate = instTrns.getValueDate();
			trnsCrncy = instTrns.getTrnsCrncy();
			trnsAmount = instTrns.getTrnsAmount();
			trnsAmountSar = instTrns.getAmountInSar();
			genNarrative = instTrns.getGenNarrative();
			screenNarrative = instTrns.getScnNarrative();
			benBankAddress1 = instTrns.getBenBankAddress1();
			benBankCode = instTrns.getBenBankCode();
			benName = instTrns.getBenName();
			benBank = instTrns.getBenBank();
			benCountry = instTrns.getBenCountry();
			paymentDtls = instTrns.getPaymentDtls();
			debitActNo = instTrns.getDebitAcc();
			debitActCrncy = instTrns.getDrActCrncy();
			debitAmount = instTrns.getDrAmount();
			// debitValueDate=instTrns.getDrValueDate();
			creditActNo = instTrns.getCreditAcc();

			creditActCrncy = instTrns.getCrActCrncy();
			creditAmount = instTrns.getCrAmount();
			creditValueDate = instTrns.getCrValueDate();
			commCrncy = instTrns.getCommCrncy();
			commAmount = instTrns.getCommAmount();
			commAct = instTrns.getCommAct();
			chrgesCrncy = instTrns.getChrgCrncy();
			chrgesAmount = instTrns.getChrgAmount();
			chrgesAct = instTrns.getChrgAct();
			sourceSystem = instTrns.getSourceSystem();
			trnsStatus = instTrns.getPpmTrnsStatus();
			instReference = instTrns.getInstRef();
			;
			// Set the source system as SPP
			if (sourceSystem != null || !"".equals(sourceSystem)) {
				trnsMsg.setSourceSystem(sourceSystem);
			}
			if (trnsAmount != null
					&& trnsAmount.compareTo(BigDecimal.ZERO) != 0) {
				trnsAmt = StringUtils.getFormattedAmount(trnsAmount.toString(),
						2);
				trnsMsg.setTransAmount(trnsAmt);
			}
			if (trnsAmountSar != null && trnsAmountSar != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						trnsAmountSar.toString(), 2);
				trnsMsg.setTransAmountSar(trnsAmt);
			} else {
				trnsMsg.setTransAmountSar(trnsAmount.toString());
			}
			if (debitAmount != null && debitAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						debitAmount.toString(), 2);
				trnsMsg.setDebitAmount(trnsAmt);
			}
			if (creditAmount != null && creditAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						creditAmount.toString(), 2);
				trnsMsg.setCreditAmount(trnsAmt);
			}
			if (commAmount != null && commAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(commAmount.toString(),
						2);
				trnsMsg.setCommissionAmount(trnsAmt);
			}
			if (chrgesAmount != null && chrgesAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						chrgesAmount.toString(), 2);
				trnsMsg.setChargesAmount(trnsAmt);
			}
			if (commCrncy != null && !"".equals(commCrncy)) {
				trnsMsg.setCommissionCrncy(commCrncy);
			}

			trnsMsg.setTransType(trnsType.trim());
			trnsMsg.setFTSReference(trnsReference);
			trnsMsg.setTransDate(trnsDate);
			trnsMsg.setValueDate(valueDate);
			trnsMsg.setTransCrncy(trnsCrncy);
			//if transaction is for SFL(Saudi Fransi Leasing) get the General Narrative from ppm_parameter_value
			if(pPm_Trns_Status.equals("CMPUPD04")){
			ParameterValue parmValeu=getParameterVDAO().getSFLGenralNarrative();
			if(parmValeu==null){
			trnsMsg.setGenNarrative("خصم قسط التمويل التأجيري  SFL Instalment Deduction");
			}
			else{
			trnsMsg.setGenNarrative(parmValeu.getValue1());
			}
			}
		    else{
			trnsMsg.setGenNarrative(genNarrative);
		    }
			
			trnsMsg.setScreenNarrative(trnsReference);
			trnsMsg.setDebitAcctNo(debitActNo);
			trnsMsg.setDebitAcctCrncy(debitActCrncy);
			trnsMsg.setDebitValueDate(valueDate);
			trnsMsg.setCreditAcctCrncy(creditActCrncy);
			trnsMsg.setCreditValueDate(valueDate);
			if (commAct != null || !"".equals(commAct)) {
				trnsMsg.setCommissionAcct(commAct);
			}
			trnsMsg.setChargesCrncy(debitActCrncy);
			if (chrgesAct != null || !"".equals(chrgesAct)) {
				trnsMsg.setChargesAcct(chrgesAct);
			}
			trnsStatus = instTrns.getPpmTrnsStatus();
			
			if (trnsStatus != null || !"".equals(trnsStatus)) {
				trnsMsg.setTransactionStatus(trnsStatus);
			}
			// AATR related fields

			trnsMsg.setCreditAcctNo(creditActNo);
			//For SFL not picking from ppm_inst_transactions table and column ppm_gen_narratives setting Customer ID as Credit Account 
			if(pPm_Trns_Status.equals("CMPUPD04"))
			trnsMsg.setDebitNarrative(creditActNo);
			
			else
			trnsMsg.setDebitNarrative(genNarrative.trim());
			
			trnsMsg.setCreditNarrative(screenNarrative);

			if ("SPP".equals(sourceSystem.trim())) {

				return fINUpdateResponse = ftsService.sendTransferRequestAATR(
						trnsMsg, "SPP");
			} else if ("LLS".equals(sourceSystem.trim())) {
				return fINUpdateResponse = ftsService.sendTransferRequestAATR(
						trnsMsg, "LLS");
			} else {
				return fINUpdateResponse = ftsService.sendTransferRequestAATR(
						trnsMsg, "PPM");
			}

			// }

		} catch (Exception ex) {
			log.error(
					"(tuxUpdateAATR)===> Exception in tuxUpdateAATR:"
							+ ex.getMessage(), ex);
			throw ex;
		}
	}

	// Transaction type AATR for BKR message preparation and posting to tuxedo
	public FTSResponsePostingEntity tuxUpdateAATRBKC(
			Ppm_Inst_Transactions instTrns, String pPm_Trns_Status)
			throws Exception {
		postEntityAATR = new FTSRequestPostingEntityAATR();
		FTSRequestPostingEntityAATR trnsMsg = null;
		ftsService = new FTSPostingServiceImpl();
		FTSResponsePostingEntity fINUpdateResponse = null;
		// businessDate=getInstTransactionsDAO().loadBusinessDate();
		// get the new instance of FTSRequestPostingEntity
		trnsMsg = postEntityAATR.getInstance();

		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		try {

			if (IsEmpty(instTrns.getDebitAcc())
					|| IsEmpty(instTrns.getCreditAcc())) {
				return fINUpdateResponse;

			}

			processStatus = instTrns.getStatus();
			trnsType = instTrns.getTrnsType();
			trnsReference = instTrns.getPpmTrnsRef();
			trnsDate = instTrns.getTrnsDate();
			valueDate = instTrns.getValueDate();
			trnsCrncy = instTrns.getTrnsCrncy();
			trnsAmount = instTrns.getTrnsAmount();
			trnsAmountSar = instTrns.getAmountInSar();
			genNarrative = instTrns.getGenNarrative();
			screenNarrative = instTrns.getScnNarrative();
			benBankAddress1 = instTrns.getBenBankAddress1();
			benBankCode = instTrns.getBenBankCode();
			benName = instTrns.getBenName();
			benBank = instTrns.getBenBank();
			benCountry = instTrns.getBenCountry();
			paymentDtls = instTrns.getPaymentDtls();
			debitActNo = instTrns.getDebitAcc();
			debitActCrncy = instTrns.getDrActCrncy();
			debitAmount = instTrns.getDrAmount();
			// debitValueDate=instTrns.getDrValueDate();
			creditActNo = instTrns.getCreditAcc();

			creditActCrncy = instTrns.getCrActCrncy();
			creditAmount = instTrns.getCrAmount();
			creditValueDate = instTrns.getCrValueDate();
			commCrncy = instTrns.getCommCrncy();
			commAmount = instTrns.getCommAmount();
			commAct = instTrns.getCommAct();
			chrgesCrncy = instTrns.getChrgCrncy();
			chrgesAmount = instTrns.getChrgAmount();
			chrgesAct = instTrns.getChrgAct();
			sourceSystem = instTrns.getSourceSystem();
			trnsStatus = instTrns.getPpmTrnsStatus();
			instReference = instTrns.getInstRef();
			;
			// Set the source system as SPP
			if (sourceSystem != null || !"".equals(sourceSystem)) {
				trnsMsg.setSourceSystem(sourceSystem);
			}
			if (trnsAmount != null
					&& trnsAmount.compareTo(BigDecimal.ZERO) != 0) {
				trnsAmt = StringUtils.getFormattedAmount(trnsAmount.toString(),
						2);
				trnsMsg.setTransAmount(trnsAmt);
			}
			if (trnsAmountSar != null && trnsAmountSar != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						trnsAmountSar.toString(), 2);
				trnsMsg.setTransAmountSar(trnsAmt);
			} else {
				trnsMsg.setTransAmountSar(trnsAmount.toString());
			}
			if (debitAmount != null && debitAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						debitAmount.toString(), 2);
				trnsMsg.setDebitAmount(trnsAmt);
			}
			if (creditAmount != null && creditAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						creditAmount.toString(), 2);
				trnsMsg.setCreditAmount(trnsAmt);
			}
			if (commAmount != null && commAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(commAmount.toString(),
						2);
				trnsMsg.setCommissionAmount(trnsAmt);
			}
			if (chrgesAmount != null && chrgesAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						chrgesAmount.toString(), 2);
				trnsMsg.setChargesAmount(trnsAmt);
			}
			if (commCrncy != null && !"".equals(commCrncy)) {
				trnsMsg.setCommissionCrncy(commCrncy);
			}

			trnsMsg.setTransType(trnsType.trim());
			trnsMsg.setFTSReference(trnsReference);
			trnsMsg.setTransDate(trnsDate);
			trnsMsg.setValueDate(valueDate);
			trnsMsg.setTransCrncy(trnsCrncy);
			trnsMsg.setGenNarrative(genNarrative);
			trnsMsg.setScreenNarrative(trnsReference);
			trnsMsg.setDebitAcctNo(debitActNo);
			trnsMsg.setDebitAcctCrncy(debitActCrncy);
			trnsMsg.setDebitValueDate(valueDate);
			trnsMsg.setCreditAcctCrncy(creditActCrncy);
			trnsMsg.setCreditValueDate(valueDate);
			if (commAct != null || !"".equals(commAct)) {
				trnsMsg.setCommissionAcct(commAct);
			}
			trnsMsg.setChargesCrncy(debitActCrncy);
			if (chrgesAct != null || !"".equals(chrgesAct)) {
				trnsMsg.setChargesAcct(chrgesAct);
			}
			if (pPm_Trns_Status.equalsIgnoreCase("")) {
				trnsStatus = instTrns.getPpmTrnsStatus();
			} else {
				trnsStatus = "REV";
			}

			if (trnsStatus != null || !"".equals(trnsStatus)) {
				trnsMsg.setTransactionStatus(trnsStatus);
			}
			// AATR related fields

			trnsMsg.setCreditAcctNo(creditActNo);
			trnsMsg.setDebitNarrative(genNarrative.trim());
			trnsMsg.setCreditNarrative(screenNarrative);

			if ("SPP".equals(sourceSystem.trim())) {

				return fINUpdateResponse = ftsService.sendTransferRequestAATR(
						trnsMsg, "SPP");
			} else if ("LLS".equals(sourceSystem.trim())) {
				return fINUpdateResponse = ftsService.sendTransferRequestAATR(
						trnsMsg, "LLS");
			} else {
				return fINUpdateResponse = ftsService.sendTransferRequestAATR(
						trnsMsg, "PPM");
			}

			// }

		} catch (Exception ex) {
			log.error(
					"(tuxUpdateAATR)===> Exception in tuxUpdateAATR:"
							+ ex.getMessage(), ex);
			throw ex;
		}
	}

	// Transaction type TTAC message preparation and posting to tuxedo
	public FTSResponsePostingEntity tuxUpdateTTAC(
			Ppm_Inst_Transactions instTrns, String pPm_Trns_Status)
			throws Exception {
		postEntityTTAC = new FTSRequestPostingEntityTTAC();
		ftsService = new FTSPostingServiceImpl();
		FTSRequestPostingEntityTTAC trnsMsg = null;
		FTSResponsePostingEntity fINUpdateResponse = null;
		trnsMsg = postEntityTTAC.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");

		try {
			if (IsEmpty(instTrns.getDebitAcc())
					|| IsEmpty(instTrns.getCreditAcc())) {
				return fINUpdateResponse;

			}
			
			
			creditActNo = instTrns.getCreditAcc().toUpperCase().trim();
			remitterName = instTrns.getRemitterName();
			processStatus = instTrns.getStatus();
			trnsType = instTrns.getTrnsType();
			trnsReference = instTrns.getPpmTrnsRef();
			trnsDate = instTrns.getTrnsDate();
			valueDate = instTrns.getValueDate();
			trnsCrncy = instTrns.getTrnsCrncy();
			trnsAmount = instTrns.getTrnsAmount();
			trnsAmountSar = instTrns.getAmountInSar();
			genNarrative = instTrns.getGenNarrative();
			screenNarrative = instTrns.getScnNarrative();
			benBankAddress1 = instTrns.getBenBankAddress1();
			benBankAddress2 = instTrns.getBenBankAddress2();
			benBankCode = instTrns.getBenBankCode();
			benName = instTrns.getBenName();
			benBank = instTrns.getBenBank();
			benCountry = instTrns.getBenCountry();
			paymentDtls = instTrns.getPaymentDtls();
			debitActNo = instTrns.getDebitAcc();
			debitActCrncy = instTrns.getDrActCrncy();
			debitAmount = instTrns.getDrAmount();
			// debitValueDate=instTrns.getDrValueDate();
			
			creditActCrncy = instTrns.getCrActCrncy();
			creditAmount = instTrns.getCrAmount();
			creditValueDate = instTrns.getCrValueDate();
			commCrncy = instTrns.getCommCrncy();
			commAmount = instTrns.getCommAmount();
			commAct = instTrns.getCommAct();
			chrgesCrncy = instTrns.getChrgCrncy();
			chrgesAmount = instTrns.getChrgAmount();
			chrgesAct = instTrns.getChrgAct();
			sourceSystem = instTrns.getSourceSystem();
			trnsStatus = instTrns.getPpmTrnsStatus();
			instReference = instTrns.getInstRef();
			// get Credit Account for TTAC Transaction type from
			// F_CORRESPONDENTS table
			String creditAcct = getInstTransactionsDAO().getCreditAcct(
					trnsCrncy);
			// Set the source system as SPP
			if (sourceSystem != null || !"".equals(sourceSystem)) {
				trnsMsg.setSourceSystem(sourceSystem);
			}
			if (trnsAmount != null
					&& trnsAmount.compareTo(BigDecimal.ZERO) != 0) {
				trnsAmt = StringUtils.getFormattedAmount(trnsAmount.toString(),
						2);
				trnsMsg.setTransAmount(trnsAmt);
			}
			if (trnsAmountSar != null && trnsAmountSar != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						trnsAmountSar.toString(), 2);
				trnsMsg.setTransAmountSar(trnsAmt);
			} else {
				trnsMsg.setTransAmountSar(trnsAmount.toString());
			}
			if (debitAmount != null && debitAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						debitAmount.toString(), 2);
				trnsMsg.setDebitAmount(trnsAmt);
			}
			if (creditAmount != null && creditAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						creditAmount.toString(), 2);
				trnsMsg.setCreditAmount(trnsAmt);
			}
			if (commAmount != null && commAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(commAmount.toString(),
						2);
				trnsMsg.setCommissionAmount(trnsAmt);
			}
			if (chrgesAmount != null && chrgesAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						chrgesAmount.toString(), 2);
				trnsMsg.setChargesAmount(trnsAmt);
			}
			if (commCrncy != null && !"".equals(commCrncy)) {
				trnsMsg.setCommissionCrncy(commCrncy);
			}
			String valueDateStr = formatter.format(valueDate);
			ParameterValue parameterValue = getInstTransactionsDAO()
					.getSARIHolidays(valueDateStr);

			String dayStr = "";
			Date weekendValueDate = null;
			int day = valueDate.getDay();
			Calendar cal = Calendar.getInstance();
			cal.setTime(valueDate);

			if (parameterValue != null) {
				String value2 = parameterValue.getValue2();
				// if(value2!=null&&!"".equals(value2)){
				Date newDate = formatter.parse(value2);
				cal.setTime(newDate);
				cal.add(Calendar.DATE, 1);
				weekendValueDate = cal.getTime();
				day = weekendValueDate.getDay();
				// }
			}
			if (day == 5) {
				cal.add(Calendar.DATE, 2);
				weekendValueDate = cal.getTime();
				dayStr = "Friday";
			} else if (day == 6) {
				cal.add(Calendar.DATE, 1);
				weekendValueDate = cal.getTime();
				dayStr = "Saturday";
			} else {
				weekendValueDate = valueDate;
			}

			trnsMsg.setTransType(trnsType.trim());
			trnsMsg.setFTSReference(trnsReference);
			trnsMsg.setTransDate(trnsDate);
			trnsMsg.setValueDate(weekendValueDate);
			trnsMsg.setTransCrncy(trnsCrncy);
			trnsMsg.setGenNarrative(genNarrative);
			trnsMsg.setScreenNarrative(trnsReference);
			trnsMsg.setDebitAcctNo(debitActNo);
			trnsMsg.setDebitAcctCrncy(debitActCrncy);
			trnsMsg.setDebitValueDate(weekendValueDate);
			trnsMsg.setCreditAcctCrncy(creditActCrncy);
			trnsMsg.setCreditValueDate(weekendValueDate);
			if (commAct != null || !"".equals(commAct)) {
				trnsMsg.setCommissionAcct(commAct);
			}
			trnsMsg.setChargesCrncy(debitActCrncy);
			if (chrgesAct != null || !"".equals(chrgesAct)) {
				trnsMsg.setChargesAcct(chrgesAct);
			}
			if (pPm_Trns_Status.equalsIgnoreCase("")) {
				trnsStatus = instTrns.getPpmTrnsStatus();
			} else {
				trnsStatus = "REV";
			}
			if (trnsStatus != null || !"".equals(trnsStatus)) {
				trnsMsg.setTransactionStatus(trnsStatus);
			}

			// TTAC related fields
			SimpleDateFormat formatterTTAC = new SimpleDateFormat("yy");
			SimpleDateFormat formatterTTACValueDate = new SimpleDateFormat(
					"yyyyMMdd");
			String valDat = formatterTTACValueDate.format(valueDate);

			trnsMsg.setBenBank(benBank);
			trnsMsg.setBenBankCode(benBankCode);
			trnsMsg.setBenCountry(benCountry);
			// This method is for setTtReferenceNo
			// trnsMsg.setTtReferenceNumber("PPMTT"+ formatterTTAC.format(new
			// Date()));
			Date yy = new Date();

			Long ttReference = getInstTransactionsDAO().getTTReferenceSeqGen();
			String ttRefereBind = "PPMTT"
					+ StringUtils.padLeft(ttReference.toString(), 6, "0")
					+ formatterTTAC.format(yy);
			trnsMsg.setTtReferenceNumber(ttRefereBind);
			trnsMsg.setPaymentVaueDate(weekendValueDate);
			trnsMsg.setRmtrName(remitterName);

			/*
			 * if(benBankAddress2!=null&&!"".equals(benBankAddress2)){
			 * trnsMsg.setRmtrNationalty(benBankAddress2); } else{
			 * trnsMsg.setRmtrNationalty(benBankAddress2); }
			 */
			trnsMsg.setBenName(benName);
			if (benBankAddress1 != null && !"".equals(benBankAddress1)) {
				trnsMsg.setBenBankAddress1(benBankAddress1);
			} else {
				trnsMsg.setBenBankAddress1("SA");
			}
			trnsMsg.setProcessingSeq(0);
			trnsMsg.setBenAccNo(creditActNo);
			trnsMsg.setCreditAcctNo(creditAcct);

			log.info("Credit Account Before " + creditAcct
					+ "Credit Account After " + trnsMsg.getCreditAcctNo());
			trnsMsg.setPaymentDtls(paymentDtls); // Payment details
			trnsMsg.setChargesAcct("A");// Charge collection 'A'
			trnsMsg.setBenBankCountry("SAU");
			trnsMsg.setIsIban("Y"); // req_is_iban :='Y';
			trnsMsg.setIbanNumber(creditActNo);// req_iban_number

			if ("SPP".equals(sourceSystem.trim())) {
				return fINUpdateResponse = ftsService.sendTransferRequest(
						trnsMsg, "SPP");
			} else if ("LLS".equals(sourceSystem.trim())) {
				return fINUpdateResponse = ftsService.sendTransferRequest(
						trnsMsg, "LLS");
			} else {
				return fINUpdateResponse = ftsService.sendTransferRequest(
						trnsMsg, "PPM");
			}

			// }

		} catch (Exception ex) {
			log.error(
					"(FTSResponsePostingEntity)===> Exception in tuxUpdateTTAC:"
							+ ex.getMessage(), ex);
			throw ex;
		}

	}

	// Transaction type MRKI message preparation and posting to tuxedo
	public FTSResponsePostingEntity tuxUpdateMRKI(
			Ppm_Inst_Transactions instTrns, String pPm_Trns_Status,
			String cammStatus) throws ApplicationException {
		boolean processFlag = false;
		postEntityMRKI = new FTSRequestPostingEntityMRKI();
		ftsService = new FTSPostingServiceImpl();
		FTSRequestPostingEntityMRKI trnsMsg;
		FTSResponsePostingEntity fINUpdateResponse = null;
		// businessDate=getInstTransactionsDAO().loadBusinessDate();
		// get the new instance of FTSRequestPostingEntityMRKI
		trnsMsg = postEntityMRKI.getInstance();

		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		try {
			// Date busnDate = formatter.parse(businessDate);
			// System.out.println(busnDate);
			// System.out.println(formatter.format(busnDate));
			processStatus = instTrns.getStatus();
			trnsType = instTrns.getTrnsType();
			trnsReference = instTrns.getPpmTrnsRef();
			blckReference = instTrns.getBlckReference();
			trnsDate = instTrns.getTrnsDate();
			valueDate = instTrns.getValueDate();
			trnsCrncy = instTrns.getTrnsCrncy();
			trnsAmount = instTrns.getTrnsAmount();
			trnsAmountSar = instTrns.getAmountInSar();
			genNarrative = instTrns.getGenNarrative();
			screenNarrative = instTrns.getScnNarrative();
			benBankAddress1 = instTrns.getBenBankAddress1();
			benBankCode = instTrns.getBenBankCode();
			benName = instTrns.getBenName();
			benBank = instTrns.getBenBank();
			benCountry = instTrns.getBenCountry();
			paymentDtls = instTrns.getPaymentDtls();
			debitActNo = instTrns.getDebitAcc();
			debitActCrncy = instTrns.getDrActCrncy();
			debitAmount = instTrns.getDrAmount();
			// debitValueDate=instTrns.getDrValueDate();
			creditActNo = instTrns.getCreditAcc();

			creditActCrncy = instTrns.getCrActCrncy();
			creditAmount = instTrns.getCrAmount();
			creditValueDate = instTrns.getCrValueDate();
			commCrncy = instTrns.getCommCrncy();
			commAmount = instTrns.getCommAmount();
			commAct = instTrns.getCommAct();
			chrgesCrncy = instTrns.getChrgCrncy();
			chrgesAmount = instTrns.getChrgAmount();
			chrgesAct = instTrns.getChrgAct();
			sourceSystem = instTrns.getSourceSystem();

			instReference = instTrns.getInstRef();
			String trnsRefPadingSpace = StringUtils.padRightSpace(
					trnsReference, 13, " ");

			// Set the source system as SPP
			if (sourceSystem != null || !"".equals(sourceSystem)) {
				trnsMsg.setSourceSystem(sourceSystem);
			}
			if (trnsAmount != null
					&& trnsAmount.compareTo(BigDecimal.ZERO) != 0) {
				trnsAmt = StringUtils.getFormattedAmount(trnsAmount.toString(),
						2);
				trnsMsg.setTransAmount(trnsAmt);
			}
			if (trnsAmountSar != null && trnsAmountSar != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						trnsAmountSar.toString(), 2);
				trnsMsg.setTransAmountSar(trnsAmt);
			}
			if (debitAmount != null && debitAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						debitAmount.toString(), 2);
				trnsMsg.setDebitAmount(trnsAmt);
			}
			if (creditAmount != null && creditAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						creditAmount.toString(), 2);
				trnsMsg.setCreditAmount(trnsAmt);
			}
			if (commAmount != null && commAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(commAmount.toString(),
						2);
				trnsMsg.setCommissionAmount(trnsAmt);
			}
			if (chrgesAmount != null && chrgesAmount != 0.0) {
				trnsAmt = "";
				trnsAmt = StringUtils.getFormattedAmount(
						chrgesAmount.toString(), 2);
				trnsMsg.setChargesAmount(trnsAmt);
			}
			if (commCrncy != null && !"".equals(commCrncy)) {
				trnsMsg.setCommissionCrncy(commCrncy);
			}
			trnsMsg.setTransType(trnsType.trim());
			trnsMsg.setFTSReference(trnsReference);
			trnsMsg.setTransDate(trnsDate);
			trnsMsg.setValueDate(valueDate);
			trnsMsg.setTransCrncy(trnsCrncy);
			trnsMsg.setGenNarrative(genNarrative);
			trnsMsg.setScreenNarrative(trnsReference);
			trnsMsg.setDebitAcctNo(debitActNo);
			trnsMsg.setDebitAcctCrncy(debitActCrncy);
			trnsMsg.setDebitValueDate(valueDate);
			trnsMsg.setCreditAcctCrncy(creditActCrncy);
			trnsMsg.setCreditValueDate(valueDate);
			if (commAct != null && !"".equals(commAct)) {
				trnsMsg.setCommissionAcct(commAct);
			}
			trnsMsg.setChargesCrncy(chrgesCrncy);
			if (chrgesAct != null && !"".equals(chrgesAct)) {
				trnsMsg.setChargesAcct(chrgesAct);
			}

			if (pPm_Trns_Status.equalsIgnoreCase("")) {
				trnsStatus = instTrns.getPpmTrnsStatus();
			} else {
				trnsStatus = "MRKM";
				trnsMsg.setBlckReference(blckReference);
			}
			if ("MRKM".equalsIgnoreCase(cammStatus)) {
				Long reference = getInstTransactionsDAO().getReferenceSeqGen();
				String refePading = "LLS"
						+ StringUtils.padLeft(reference.toString(), 7, "0");
				log.info("New PPM_INST_REF for reversal==" + refePading);
				log.info("Orignal  PPM_INST_REF==" + trnsRefPadingSpace);
				trnsMsg.setFTSReference(refePading);
			}

			if (trnsStatus != null && !"".equals(trnsStatus)) {
				trnsMsg.setTransactionStatus(trnsStatus);
			}

			// MRKI related fields

			// trnsMsg.setCreditAcctNo("");
			trnsMsg.setDetailLength(532);

			trnsMsg.setRsstReference(trnsRefPadingSpace); // use the trans ref
															// -- 13 digit right
															// pad with space
			trnsMsg.setRsstReasonCode("5");// pass vale '5'
			trnsMsg.setRsstReasonDes("LLS blocking for loan Ref"
					+ instReference); // 'LLS blocking for loan Ref: ' +
										// Instruction refrence
			trnsMsg.setRsstExpDate(valueDate);// take value date from same
												// reading table
			trnsMsg.setValueDate(new Date());

			/*
			 * int count=0; do{ count++;
			 * log.info("Tring to post Tuxedo count "+count);
			 */
			fINUpdateResponse = ftsService.sendTransferRequest(trnsMsg, "LLS");
			/*
			 * log.info("fINUpdateResponse-------"+fINUpdateResponse);
			 * if(count==3)
			 * 
			 * break ; log.info("IF Count is 3 "+processFlag);
			 * if(fINUpdateResponse!=null){ processFlag=true;
			 * log.info("Trying to post tuxedo 3 times "+processFlag); }
			 * 
			 * } while(!processFlag);
			 */

			// return fINUpdateResponse;

		} catch (Exception ex) {
			log.error("Exception in tuxUpdateMRKI:" + ex.getStackTrace());

		}

		return fINUpdateResponse;
	}

	// Tuxedo inquiry before posting to Tuxedo to check the Account Status

	public boolean getAccountStatus(Ppm_Inst_Transactions ppmInstTransactions)
			throws DAOException {
		String accountNo = ppmInstTransactions.getDebitAcc().toUpperCase();
		try {
			FTSPostingService FTSPS = new FTSPostingServiceImpl();
			AccountInquiryRequest accountInquiryRequest = new AccountInquiryRequest();
			accountInquiryRequest = AccountInquiryRequest.getInstance();
			accountInquiryRequest.setAccountNo(accountNo);
			AccountInquiryResponse accountInqResponse = FTSPS
					.sendAccountInquiry(accountInquiryRequest, "SPP");
			if (accountInqResponse != null) {
				String actStatusTux = accountInqResponse.getAcctStatusCode();
				List<ParameterValue> parameterAcctTypeValue = getParameterVDAO().getAccountType("DRACTSTUS");
				if (parameterAcctTypeValue.size() > 0) {
					for (ParameterValue parmaValue : parameterAcctTypeValue) {
						String acctTypeFromValue = parmaValue.getValue1();
						if (acctTypeFromValue.trim().equalsIgnoreCase(
								actStatusTux.trim())) {
							log.info("(getAccountStatus)===> Debit Account "
									+ accountNo + " status = "
									+ acctTypeFromValue);
							return true;
						}

					}
				} else {

					log.info("(getAccountStatus)===> Debit Account "
							+ accountNo
							+ " status is not avaiable in Database ");
				}
			}
		} catch (Exception ex) {
			log.error(
					"(getAccountStatus)===> Error occured = " + ex.getMessage(),
					ex);

			throw new DAOException("Account inquiry error:", ex);
		}
		return false;
	}

	// Tuxedo inquiry before posting to Tuxedo to check the balance;
	public Integer getcustDebitAccountBalance(
			Ppm_Inst_Transactions ppmInstTransactions)
			throws ApplicationException {

		int retval = 0;
		if (IsEmpty(ppmInstTransactions.getDebitAcc())) {
			log.info("Debit Acct is null or empty"
					+ ppmInstTransactions.getDebitAcc());
			return null;
		}
		String accountNo = ppmInstTransactions.getDebitAcc().toUpperCase();

		log.info("Inquiring debit account " + accountNo);

		try {
			FTSPostingService FTSPS = new FTSPostingServiceImpl();
			AccountInquiryRequest accountInquiryRequest = new AccountInquiryRequest();
			accountInquiryRequest = AccountInquiryRequest.getInstance();
			accountInquiryRequest.setAccountNo(accountNo);
			AccountInquiryResponse accuntInqResponse = FTSPS
					.sendAccountInquiry(accountInquiryRequest, "SPP");

			log.info("Account Inquiry CAMM Code "
					+ accuntInqResponse.getCammActionCode());
			if (accuntInqResponse != null
					&& accuntInqResponse.getFtsActionCode().equals("0000")
					&& accuntInqResponse.getCammActionCode().equals("0000")) {
				Double debitAcctBlanc = accuntInqResponse.getAvailableBalance();
				BigDecimal debActBlnDoubleToBigDec = null;

				if (debitAcctBlanc != null) {
					debActBlnDoubleToBigDec = BigDecimal
							.valueOf(debitAcctBlanc);
					retval = debActBlnDoubleToBigDec
							.compareTo(ppmInstTransactions.getTrnsAmount());
					log.info("Debit balance is "
							+ accuntInqResponse.getAvailableBalance()
							+ " and transction amount is "
							+ ppmInstTransactions.getTrnsAmount()
							+ " comparison is " + retval);

				} else {
					log.info("After account inquiry of " + accountNo
							+ " balance is " + debitAcctBlanc);
				}
			} else {
				log.error("After account inquiry of " + accountNo
						+ " is either null or CAMM or FTS code is not 0000.");
				return null;
			}
		} catch (ApplicationException ae) {
			log.error(
					"(getcustDebitAccountBalance)===> Error occured while doing account inquiry. Error "
							+ ae.getMessage(), ae);
			throw ae;
		}

		return retval;
	}

	//

	// Tuxedo inquiry before posting to Tuxedo to check the Account Status and
	// balance;
	public String getcustCreditAccountStatus(
			Ppm_Inst_Transactions ppmInstTransactions,String inqType)
			throws ApplicationException {
		accountInqRes = null;
		String accountNo = null;
		String acctStatusFlag = null;
		if (ppmInstTransactions.getCreditAcc() != null)
			accountNo = ppmInstTransactions.getCreditAcc().toUpperCase();

		try {

			FTSPostingService FTSPS = new FTSPostingServiceImpl();
			AccountInquiryRequest accountInquiryRequest = new AccountInquiryRequest();
			accountInquiryRequest = AccountInquiryRequest.getInstance();
			if(inqType.equals("CMPINQ01"))
			accountInquiryRequest.setRequestFunction("CMPINQ01");	
			accountInquiryRequest.setAccountNo(accountNo);
			accountInqRes = FTSPS.sendAccountInquiry(accountInquiryRequest,
					"SPP");

			if (accountInqRes != null) {
				String ftsActionCode = accountInqRes.getFtsActionCode();
				String cammActionCode = accountInqRes.getCammActionCode();
				String actStatusTux = accountInqRes.getAcctStatusCode();

				if (ftsActionCode.equals("0000")
						&& cammActionCode.equals("0000")) {

					if (("CL".equalsIgnoreCase(actStatusTux.trim()))
							|| ("FB".equalsIgnoreCase(actStatusTux.trim()))) {
						acctStatusFlag = "CLOSE";

					} else {
						acctStatusFlag = actStatusTux.trim();
						log.info("(getcustCreditAccountStatus)===> CAMM Action code ="
								+ acctStatusFlag);
					}

				} else {

					log.info("(getcustCreditAccountStatus)===> CAMM Action code ="
							+ cammActionCode
							+ " FTS Action Code = "
							+ ftsActionCode);
				}

			} else {
				log.info("(getcustCreditAccountStatus)===> Account Inquiry failed");
			}

		} catch (ApplicationException ae) {

			log.error(
					"(getcustCreditAccountStatus)===> Error occured while checking Credit account status. Error= "
							+ ae.getMessage(), ae);
			throw ae;
		}

		return acctStatusFlag;
	}
    
	public String getDatabaseSchema()throws DAOException{
	ParameterValue varameterValue=null;
	Map criteria=new HashMap();
	criteria.put("parmtypecode", "DATABSENAME");
	try{	
	varameterValue=getParameterVDAO().getByCriteria(criteria);
	}
	catch(Exception e){
	e.printStackTrace();
	}
	return varameterValue.getValue1();
	}
	

	
	public List<String> getCtznAccount(String dbAccountNo,String databaseSchem) throws DAOException,
			Exception {

		Connection con = null;
		CallableStatement stmt = null;
		List<String> lstResult = new ArrayList<String>();
         
		try {
			con = dataSource.getConnection();
			DatabaseMetaData dmd = con.getMetaData();
			log.info("Database URL===> " + dmd.getURL());
			log.info("(getCtznAccount)===> DDA Account" + dbAccountNo);
								
			if (con != null) {
				stmt = con.prepareCall("{call " +databaseSchem +".CTZN_ACCT_PKG.retrieve_ctzn_acct(?, ?,?)}");
				stmt.setString(1, dbAccountNo);
				stmt.registerOutParameter(2, java.sql.Types.VARCHAR);
				stmt.registerOutParameter(3, java.sql.Types.VARCHAR);
				stmt.execute();

				lstResult.add(stmt.getString(2));
				lstResult.add(stmt.getString(3));

				log.info("(getCtznAccount)===> Citizen Account="
						+ stmt.getString(2));
				log.info("(getCtznAccount)===> Result" + stmt.getString(3));
			}
		} catch (Exception e) {

			log.error(
					"(getCtznAccount)===> Error while calling CTZN Account stored procedure. Error = "
							+ e.getMessage(), e);
			throw e;
		} finally {

			try {

				if (stmt != null)
					stmt.close();

			} catch (Exception ex) {
				log.error(
						"(getCtznAccount)===> Error while closing the stmt CTZN Account stored procedure. Error = "
								+ ex.getMessage(), ex);
				throw ex;
			}

			try {

				if (con != null)
					con.close();

			} catch (Exception ex) {
				log.error(
						"(getCtznAccount)===> Error while closing the connection CTZN Account stored procedure. Error = "
								+ ex.getMessage(), ex);
				throw ex;
			}

		}
		return lstResult;
	}

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public boolean IsEmpty(String str) {
		if (str != null && !str.isEmpty() && str != "")
			return false;
		else
			return true;
	}
	
	
}
