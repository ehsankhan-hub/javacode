package com.bsf.ppm.batch.process;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.SearchCondition;
import com.bsf.ppm.Ppm_Inst_Transactions;
import com.bsf.ppm.batch.JobException;
import com.bsf.ppm.batch.LlsSalaryPerProcessorTask;

import com.bsf.ppm.batch.handler.SpringManagedJobHandler;
import com.bsf.ppm.batch.processor.InstTransactionProcessor;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.constants.IConstants.SORT_ORDER;
import com.bsf.ppm.dao.InstTransactionsDAO;
import com.bsf.ppm.dao.InstructionDAO;
import com.bsf.ppm.exceptions.DAOException;

import com.bsf.ppm.spring.SpringAppContext;

public class LLSAllowedSalaryPercentageBatchJobHandler extends SpringManagedJobHandler{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7259004937647187624L;

	/**
	 * logger
	 */

	private static final Logger logger = Logger.getLogger(LLSAllowedSalaryPercentageBatchJobHandler.class);

	private String applicationId = IConstants.MODULE_NAME.PPM.name();

	private int countNoOfInst = 1;

	List<Ppm_Inst_Transactions> pendingInstruction = null;
	private InstTransactionsDAO instTransactionsDAO;
	private InstructionDAO instructionDAO;
	private ThreadPoolTaskExecutor ppmProcessTaskExecutor;
	private InstTransactionProcessor instTransactionProcessor;
	
	Ppm_Inst_Transactions instTrns;
	Ppm_Inst_Transactions instTransactions=null;
	PpmTrnsType ppmTrnsType=new PpmTrnsType();	
	
	public InstTransactionsDAO getInstTransactionsDAO() {
		instTransactionsDAO = (InstTransactionsDAO) SpringAppContext.getBean("instTransactionsDAO");
		System.out.println("instTransactionsDAO Object from springContainer=="		+ instTransactionsDAO.toString());
		return instTransactionsDAO;
	}

	public InstructionDAO getInstructionDAO() {
		instructionDAO = (InstructionDAO) SpringAppContext.getBean("instructionDAO");
		return instructionDAO;
	}
	
	public void setInstTransactionsDAO(InstTransactionsDAO instTransactionsDAO) {
		this.instTransactionsDAO = instTransactionsDAO;
	}
	
	public ThreadPoolTaskExecutor getTaskExecutor() {
		if (ppmProcessTaskExecutor == null)
			ppmProcessTaskExecutor = (ThreadPoolTaskExecutor) SpringAppContext
			.getBean("ppmProcessTaskExecutor");
		return ppmProcessTaskExecutor;
	}

	public void setTaskExecutor(ThreadPoolTaskExecutor ppmProcessTaskExecutor) {
		this.ppmProcessTaskExecutor = ppmProcessTaskExecutor;
	}
	
			
	 public InstTransactionProcessor getInstTransactionProcessor() {
		 if (instTransactionProcessor == null)
			 instTransactionProcessor = (InstTransactionProcessor) SpringAppContext
				.getBean("itmsCustomerMessageProcessor");
		 return instTransactionProcessor;
	}

	public void setInstTransactionProcessor(
			InstTransactionProcessor instTransactionProcessor) {
		this.instTransactionProcessor = instTransactionProcessor;
	}
	
	private void postMessage(List<Ppm_Inst_Transactions> pendingMessages){
		try{
		
		boolean updateFlag=getInstTransactionsDAO().updateStatus(pendingMessages);
		
		logger.info("Status has been changed from N to 1  "+updateFlag);
			//throw new DAOException("Exception by Batch");
		
		for (Ppm_Inst_Transactions ppmInstTransaction : pendingMessages) {
			
			getTaskExecutor().execute(new LlsSalaryPerProcessorTask(ppmInstTransaction, "Posting"));
		}
		
		
		}
		catch(Exception ex){
			ex.printStackTrace();
			logger.error("Exception occured==="+ex.getMessage());
		}
		
	}

		
	 @Override
	 @Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
	 public void runJobInContext() throws JobException {
     try{   
    	 
	    logger.info("AllowedSalaryPercentageBach Job is running successfully ......................");	
	    //Calendar cal = Calendar.getInstance();
	    //Fetch the MAXIMUM rows from table
	    String recordsToPost =getInstTransactionsDAO().getMaxRecordsToPost();
	    
	    System.out.println("recordsToPost---"+recordsToPost);
	    Map<String, IConstants.SORT_ORDER> sortCriteria = new HashMap<String, IConstants.SORT_ORDER>();	
		sortCriteria.put("id", SORT_ORDER.ASC);		
        //Total LLSP transactions
		List<SearchCondition> totalLlsTrans = new ArrayList<SearchCondition>();
		totalLlsTrans.add(new SearchCondition("ppm_process_status", "'N'", IConstants.SYMBOL_EQUAL));
		totalLlsTrans.add(new SearchCondition("sourceSystem", "'LLS'", IConstants.SYMBOL_EQUAL));
		
		try {
			pendingInstruction = getInstTransactionsDAO().searchByPages(0, Integer.parseInt(recordsToPost), totalLlsTrans, sortCriteria);
			
			
			logger.warn("Total LLSP transactions from CAMM =="+pendingInstruction.size());	
		} catch (DAOException e) {
			logger.warn("System failed to retrieve entities data for Ppm_Inst_Transactions", e);
			}
		
		boolean canPost= false;
		if (pendingInstruction != null && pendingInstruction.size() > 0 ) {
			
			postMessage(pendingInstruction);
		
		}				
		
		//pendingInstruction=(List<Ppm_Inst_Transactions>)getInstTransactionsDAO().getTrnsBackendProcDtl();
		

		}
	catch(Exception de){
	    de.printStackTrace();
	  	
	}
	
	countNoOfInst++;
    } 
	
	 
	 
	 
	
	
    
	
 	
   
	

}
