package com.bsf.ppm.batch.process;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.core.task.TaskRejectedException;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.ipp.dao.jpa.SearchCondition;
import com.bsf.ppm.Ppm_Inst_Transactions;
import com.bsf.ppm.batch.JobException;
import com.bsf.ppm.batch.LlsProcessorTask;
import com.bsf.ppm.batch.handler.SpringManagedJobHandler;
import com.bsf.ppm.batch.processor.InstTransactionProcessor;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.constants.IConstants.SORT_ORDER;
import com.bsf.ppm.dao.InstTransactionsDAO;
import com.bsf.ppm.dao.InstructionDAO;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.service.posting.FTSPostingService;
import com.bsf.ppm.service.posting.FTSPostingServiceImpl;
import com.bsf.ppm.spring.SpringAppContext;

/**
 * 
 * @author Ehsan Ahmad Khan
 * 
 */
//@Transactional(readOnly = true, rollbackFor=DAOException.class)
public class LLSTrnsPostingBatchJobHandler extends SpringManagedJobHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7259004937647187624L;

	/**
	 * logger
	 */

	private static final Logger logger = Logger.getLogger(LLSTrnsPostingBatchJobHandler.class);

	

	/**
	 * {@link FTSPostingService} reference to {@link FTSPostingServiceImpl}
	 * instance
	 */


	// private FTSRequestPostingEntityMRKI trnsMsg;
	
	
	List<Ppm_Inst_Transactions> pendingInstruction = null;
	private InstTransactionsDAO instTransactionsDAO;
	private InstructionDAO instructionDAO;
	private ThreadPoolTaskExecutor ppmProcessTaskExecutor;
	private InstTransactionProcessor instTransactionProcessor;
	
	
	
	Ppm_Inst_Transactions instTrns;
	Ppm_Inst_Transactions instTransactions=null;
	PpmTrnsType ppmTrnsType=new PpmTrnsType();	
	public InstTransactionsDAO getInstTransactionsDAO() {
		instTransactionsDAO = (InstTransactionsDAO) SpringAppContext.getBean("instTransactionsDAO");
		System.out.println("instTransactionsDAO Object from springContainer=="		+ instTransactionsDAO.toString());
		return instTransactionsDAO;
	}

	public InstructionDAO getInstructionDAO() {
		instructionDAO = (InstructionDAO) SpringAppContext.getBean("instructionDAO");
		return instructionDAO;
	}
	
	public void setInstTransactionsDAO(InstTransactionsDAO instTransactionsDAO) {
		this.instTransactionsDAO = instTransactionsDAO;
	}
	
	public ThreadPoolTaskExecutor getTaskExecutor() {
		if (ppmProcessTaskExecutor == null)
			ppmProcessTaskExecutor = (ThreadPoolTaskExecutor) SpringAppContext
			.getBean("ppmProcessTaskExecutor");
		return ppmProcessTaskExecutor;
	}

	public void setTaskExecutor(ThreadPoolTaskExecutor ppmProcessTaskExecutor) {
		this.ppmProcessTaskExecutor = ppmProcessTaskExecutor;
	}
	
			
	 public InstTransactionProcessor getInstTransactionProcessor() {
		 if (instTransactionProcessor == null)
			 instTransactionProcessor = (InstTransactionProcessor) SpringAppContext
				.getBean("itmsCustomerMessageProcessor");
		 return instTransactionProcessor;
	}

	public void setInstTransactionProcessor(
			InstTransactionProcessor instTransactionProcessor) {
		this.instTransactionProcessor = instTransactionProcessor;
	}
	
	/*private void postMessage(List<Ppm_Inst_Transactions> pendingMessages){
		try{
		
				
		boolean updateFlag=getInstTransactionsDAO().updateStatus(pendingMessages);
		
		logger.info("Status has been changed from N to 1  "+updateFlag);
			//throw new DAOException("Exception by Batch");
		
		for (Ppm_Inst_Transactions ppmInst_Transactions : pendingMessages) {
			
			try{
				
				getTaskExecutor().execute(new LlsProcessorTask(ppmInst_Transactions, "Posting"));
			}catch(TaskRejectedException tre){
				ppmInst_Transactions.setStatus("N");
				getInstTransactionsDAO().update(ppmInst_Transactions);
			}
			
			
		}
		
		
		}
		catch(Exception ex){
			ex.printStackTrace();
			logger.error("Exception occured==="+ex.getMessage());
		}		
		
	}*/

		
	 @Override
	 @Transactional(propagation = Propagation.REQUIRED, rollbackFor = DAOException.class)
	 public void runJobInContext() throws JobException {

		try {
			logger.info("LLS Job is running successfully ......................");
			String recordsToPost = getInstTransactionsDAO().getMaxRecordsToPost();
			Map<String, IConstants.SORT_ORDER> sortCriteria = new HashMap<String, IConstants.SORT_ORDER>();
			sortCriteria.put("id", SORT_ORDER.ASC);
			// Total LLS transactions
			List<SearchCondition> totalLlsTrans = new ArrayList<SearchCondition>();
			totalLlsTrans.add(new SearchCondition("ppm_process_status", "'N'",
					IConstants.SYMBOL_EQUAL));
			totalLlsTrans.add(new SearchCondition("sourceSystem", "'LLS'",
					IConstants.SYMBOL_EQUAL));
			pendingInstruction = getInstTransactionsDAO().searchByPages(0,Integer.parseInt(recordsToPost), totalLlsTrans,
					sortCriteria);
			logger.warn("Total LLS transactions==" + pendingInstruction.size());
			if (pendingInstruction != null && pendingInstruction.size() > 0) {
				//postMessage(pendingInstruction);
				boolean updateFlag = getInstTransactionsDAO().updateStatus(pendingInstruction);
				logger.info("Status has been changed from N to 1  "	+ updateFlag);
				for (Ppm_Inst_Transactions ppmInst_Transactions : pendingInstruction) {
					try {
						
						//if(ppmInst_Transactions.getPpmTrnsRef().equals("PPM20204")){
						//	throw new TaskRejectedException(recordsToPost);
						//}

					getTaskExecutor().execute(new LlsProcessorTask(ppmInst_Transactions,"Posting"));
						
						
					} catch (TaskRejectedException tre) {
						logger.error("Exception occured ="+tre.getMessage());
						getInstTransactionsDAO().updateInstTransactionsStatusTaskRejected(ppmInst_Transactions.getPpmTrnsRef(),"N");
					    return;
					}

				}

			}

		} catch (DAOException daoe) {
			logger.warn(
					"System failed to retrieve entities data for Ppm_Inst_Transactions",
					daoe);
		} catch (Exception de) {
			de.printStackTrace();

		}
		 
		 
	 } 
	
	
}