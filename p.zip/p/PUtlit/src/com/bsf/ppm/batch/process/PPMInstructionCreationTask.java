package com.bsf.ppm.batch.process;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bsf.ppm.C_Block_Deblock;
import com.bsf.ppm.InstructionDetails;
import com.bsf.ppm.PpmDebitBlockStaging;
import com.bsf.ppm.PpmDebitExempt;
import com.bsf.ppm.Ppm_Instructions;
import com.bsf.ppm.StatusHistory;
import com.bsf.ppm.dao.InstructionDAO;
import com.bsf.ppm.dao.PpmDebitBlockStagingDAO;
import com.bsf.ppm.dao.jpa.InstructionJpaDAO;
import com.bsf.ppm.dao.jpa.PpmDebitBlockStagingJpaDAO;

public class PPMInstructionCreationTask implements Runnable {

	private PpmDebitBlockStaging ppmDebitBlockStaging;
	private PpmDebitExempt ppmDebitExempt;
	private PpmDebitBlockStagingDAO ppmDebitBlockStagingDAO;
	private String salaryPercent="67";
	private String ctznAccount;
	private InstructionDAO instructionDAO;
	private C_Block_Deblock acctDetails;
   
	public PPMInstructionCreationTask(C_Block_Deblock acctDetails){
		
		this.acctDetails=acctDetails;
		
	}
	
	@Override
	public void run() {
		Ppm_Instructions ppmInstruction = null;
		InstructionDetails itemDetail = null;
		try {

			String ppmReference = getPpmDebitBlockStagingDAO()
					.getPPMReferenceSalaryPercen();
			Long ppmInstDtlRef = getPpmDebitBlockStagingDAO()
					.getInstDetaiSeqGenSalaryPercen();
			ppmInstruction = new Ppm_Instructions();
			itemDetail = new InstructionDetails();
			ppmInstruction.setInstReference(ppmReference);
			ppmInstruction.setInstgroupcode("SPP");
			ppmInstruction.setInstProrty(6);
			ppmInstruction.setExeType("EVENT_TRIGGER");
			ppmInstruction.setInstActionType("AATR");
			ppmInstruction.setCustCode(getPpmDebitBlockStaging().getCustCode());
			ppmInstruction.setAcctcurcode("SAR");
			ppmInstruction.setNoofBen(1);
			ppmInstruction.setInstBranch("004");
			ppmInstruction.setStartDateG(new Date());
			ppmInstruction.setEndDateG(new Date("2099/05/05"));
			ppmInstruction.setInstPercent(new Double(salaryPercent));
			ppmInstruction.setDayofPayment(27);
			ppmInstruction.setEventTriggerOn("EVENTPAY");
			ppmInstruction.setStatus("ACT");
			ppmInstruction.setClandertype("G");
			ppmInstruction.setNoOfInst(10000);
			ppmInstruction.setCreatedDate(new Timestamp(System
					.currentTimeMillis()));
			ppmInstruction.setCreatedBy("BatchJob");
			itemDetail.setInstDtlId(ppmInstDtlRef.toString());
			itemDetail.setBenAcc(ctznAccount);
			itemDetail.setBenPftCtr("004");
			itemDetail.setAccountstatus("OP");
			itemDetail.setBenAccCrncy("SAR");
			itemDetail.setiDType("ID");
			itemDetail.setCustIdNumber("2150");
			itemDetail.setAcctType("2150");
			itemDetail.setInstTrnsTyp("NT");
			itemDetail.setInstAccCrncy("SAR");
			itemDetail.setInstReference(ppmReference);
			itemDetail.setAccountstatus("OP");
			ppmInstruction.setInstdetails(itemDetail);
			if (getPpmDebitBlockStaging().getCustCode() != null) {
				// logger.info("Trying to create Instruction for CPT number="+
				// ppmDebitBlockStaging.get(i).getCustCode());

				// getInstructionDAO().save(ppmInstruction);

				getInstructionDAO().saveInstruction(ppmInstruction);

				// logger.info("Instruction created successfully for account number="
				// + ppmDebitBlockStaging.get(i).getCustCode());
				Map<String, String> mapDebitBlockCrit = new HashMap<String, String>();
				mapDebitBlockCrit.put("custCode", getPpmDebitBlockStaging()
						.getCustCode());

				// PpmDebitBlockStaging
				// ppmDebitBlock=getPpmDebitBlockStagingDAO().getByCriteria(mapDebitBlockCrit);

				PpmDebitBlockStaging ppmDebitUpdatedBlock = getPpmDebitBlockStagingDAO()
						.findPpmDebitBlockStagingSalaryPercent(getPpmDebitBlockStaging());
				ppmDebitUpdatedBlock.setStatus("A");
				ppmDebitUpdatedBlock.setUpdatedDate(new Date());
				ppmDebitUpdatedBlock.setUpdatedBy("BatchJob");
				// logger.info("Updating instruction status as A in staging table for "
				// + ppmDebitUpdatedBlock.getCustCode());
				getPpmDebitBlockStagingDAO().updatePpmDebitBlockStaging(
						ppmDebitUpdatedBlock);
				// logger.info("Status updated as A successfully in staging table for "
				// + ppmDebitUpdatedBlock.getCustCode());
			}

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	public PpmDebitBlockStaging getPpmDebitBlockStaging() {
		return ppmDebitBlockStaging;
	}

	public void setPpmDebitBlockStaging(
			PpmDebitBlockStaging ppmDebitBlockStaging) {
		this.ppmDebitBlockStaging = ppmDebitBlockStaging;
	}

	public PpmDebitExempt getPpmDebitExempt() {
		return ppmDebitExempt;
	}

	public void setPpmDebitExempt(PpmDebitExempt ppmDebitExempt) {
		this.ppmDebitExempt = ppmDebitExempt;
	}

	public PpmDebitBlockStagingDAO getPpmDebitBlockStagingDAO() {
		ppmDebitBlockStagingDAO = new PpmDebitBlockStagingJpaDAO();
		return ppmDebitBlockStagingDAO;
	}

	public String getSalaryPercent() {
		return salaryPercent;
	}

	public void setSalaryPercent(String salaryPercent) {
		this.salaryPercent = salaryPercent;
	}

	public String getCtznAccount() {
		return ctznAccount;
	}

	public void setCtznAccount(String ctznAccount) {
		this.ctznAccount = ctznAccount;
	}

	public InstructionDAO getInstructionDAO() {
		instructionDAO = new InstructionJpaDAO();
		return instructionDAO;
	}

}
