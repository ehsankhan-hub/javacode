package com.bsf.ppm.constants;

public class IConstants {
	public static final String NEW_LINE_SWIFT_CHAR="\r\n";
    public static String SYSTEM_USER_ID="system";
	public static String SELECT_ALL_OPTION = "ALL";
	public static String SELECT_ALL_PENDING_OPTION = "ALL PENDING";
	public static String SELECT_ALL_COMPLETED_OPTION = "ALL COMPLETED";
	public static String DEFAULT_ID_FIELD = "id";
	public static String DEFAULT_STATUS_FIELD = "status";
	public static String DEFAULT_BSF_BIC = "BSFRSARIXXX";
	public static String DEFAULT_BSF_BANK_NAME = "BANQUE SAUDI FRANSI";

	public static final String DEFAULT_SAMA_BIC = "SAMASARIXXX";
	public static Integer FTS_TRANS_REFERENCE_LENGTH = 10;
	public static Integer FTS_SCHEDUAL_NO_LENGTH = 13;
	public static Integer TT_TRANS_REFERENCE_LENGTH = 13;
	public static String SYMBOL_EQUAL = "=";
	public static String SYMBOL_NOTEQUAL = "!=";
	public static String SYMBOL_GREATER_THAN = ">";
	public static String SYMBOL_GREATER_OR_EQUAL = ">=";
	public static String SYMBOL_LESS_THAN = "<";
	public static String SYMBOL_LESS_OR_THAN = "<=";
	public static String SYMBOL_LIKE = " like ";
	public static String SYMBOL_NOT_LIKE = " not like ";
	public static String SYMBOL_IN = "IN";
	public static String SYMBOL_NOT_IN= "NOT IN";
	public static String SYMBOL_IS=" IS ";
	public static String SYMBOL_BETWEEN=" between ";
	public static final String BSF_IBAN_BANK_CODE = "55";
	public static final String CURRENCY_SAUDI_RIYAL = "SAR";
	public static final String COUNTRY_SAUDI_ARABIA = "SA";
	public static final String COUNTRY_UNITED_STATES = "US";
	public static final String COUNTRY_UNITED_KINGDOM = "GB";
	public static final String COUNTRY_SAUDI_ARABIA_BSF_MAPPING = "SAU";
	public static final int LENGTH_BSF_ACCOUNT_NUMBER = 11;
	public static final int IBAN_LENGTH_SAUDI_ARABIA = 24;
	public static final String OUTGOING_MESSAGE_BLOCK_2_TYPE = "I";
	public static final String OUTGOING_MESSAGE_BLOCK_2_MESSAGE_PRIORITY = "N";
	public static final Integer FAILED_ACCOUNT_INQUIRY_REPONSE_LENGTH = 160;
	public static final String ACCEPTED="Accepted";
	public static final String REJECTED="Rejected";
	public static final String ACCEPTED_STATUS="A";
	public static final String REJECTED_STATUS="R"; 
	public static final String TTA_HO_BRANCH_CODE="022";
	
	// all branches branch code
	public static String ALL_BRANCHES="ALL";
	
	public static final String SUCCESS="SUCCESS";
	public static final String FAILURE="FAILURE";
	
	/**
	 *<p>
	 * attribute used as a suffix for controller class name to define default
	 * list navigation page see JSF XML configuration file
	 * </p>
	 */
	public static String CRUD_LIST_NAVIGATION = "_list";
	/**
	 *<p>
	 * attribute used as a suffix for controller class name to define default
	 * list navigation page see JSF XML configuration file
	 * </p>
	 */
	public static String CRUD_INQUERY_LIST_NAVIGATION="_inquiryList";
	
	/**
	 *<p>
	 * attribute used as a suffix for controller class name to define default
	 * list navigation page see JSF XML configuration file
	 * </p>
	 */
	public static String CRUD_INQUERY_TRNS_LIST_NAVIGATION="_list";
	
	/**
	 *<p>
	 * attribute used as a suffix for controller class name to define default
	 * list navigation page see JSF XML configuration file
	 * </p>
	 */
	public static String CRUD_TRNS_LIST_NAVIGATION="_instList";
	
	
	/**
	 *<p>
	 * attribute used as a suffix for controller class name to define default
	 * list navigation page see JSF XML configuration file
	 * </p>
	 */
	public static String CRUD_MAINTENENCE_LIST_NAVIGATION="_maintenenceList";
	
	/**
	 *<p>
	 * attribute used as a suffix for controller class name to define default
	 * list navigation page see JSF XML configuration file
	 * </p>
	 */
	public static String CRUD_MAINTVALIDATE_LIST_NAVIGATION="_maintValidateList";
	
	/**
	 *<p>
	 * attribute used as a suffix for controller class name to define default
	 * list navigation page see JSF XML configuration file
	 * </p>
	 */
	public static String CRUD_EDIT_MAINT_VALIDATE_NAVIGATION="_editMaintValidate";
	
	
	/**
	 *<p>
	 * attribute used as a suffix for controller class name to define default
	 * create navigation page see JSF XML configuration file
	 * </p>
	 */
	public static String CRUD_CREATE_NAVIGATION = "_create";
	/**
	 *<p>
	 * attribute used as a suffix for controller class name to define default
	 * edit navigation page see JSF XML configuration file
	 * </p>
	 */
	public static String CRUD_EDIT_NAVIGATION = "_edit";
	
	
	
	/**
	 *<p>
	 * attribute used as a suffix for controller class name to define default
	 * edit navigation page see JSF XML configuration file
	 * </p>
	 */
	public static String CRUD_EDIT_VALIDATION_NAVIGATION = "_editValidation";
	
	/**
	 *<p>
	 * attribute used as a suffix for controller class name to define default
	 * edit navigation page see JSF XML configuration file
	 * </p>
	 */
	public static String CRUD_EDIT_MODIFY_NAVIGATION = "_editModify";
	
	
	/**
	 *<p>
	 * attribute used as a suffix for controller class name to define default
	 * delete navigation page see JSF XML configuration file
	 * </p>
	 */
	public static String CRUD_DELETE_NAVIGATION = "_delete";
	/**
	 *<p>
	 * attribute used as a suffix for controller class name to define detail
	 * list navigation page see JSF XML configuration file
	 * </p>
	 */
	public static String CRUD_DETAIL_NAVIGATION = "_detail";
	/**
	 *<p>
	 * attribute used as a suffix for controller class name to define default
	 * list navigation page see JSF XML configuration file
	 * </p>
	 */
	public static String LOGOUT_URL = "logOut";
	public static String ABOUT_URL = "about";
   
	public enum InstMessageStatusType {
		PENDING_POSTING	
	}
	
	public enum STATUS_TYPE {
		INACTIVE, ACTIVE
	}

	public enum MESSAGE_TYPE {
		ALL, MESSAGE, WARNING, ERROR
	}

	/**
	 * <p>
	 * Defines Mail address types. FROM-1, TO-2, CC-3, BCC-4 ALL status is added
	 * for GUI purpose. This should not be used to set the Mail Address type
	 * </p>
	 */
	public enum MAIL_ADDRESS_TYPE {
		ALL, FROM, TO, CC, BCC
	}

	/**
	 * <p>
	 * To Track Mail status. NEW-1 and PICKED-2. ALL status is added for GUI
	 * purpose. This should not be used to set the Mail Status
	 * </p>
	 */
	public enum MAIL_STATUS_TYPE {
		ALL, NEW, PICKED
	}

	/**
	 * <p>
	 * To Track SMS status. NEW-1 and PICKED-2. ALL status is added for GUI
	 * purpose. This should not be used to set the Sms Status
	 * </p>
	 */
	public enum SMS_STATUS_TYPE {
		ALL, NEW, PICKED
	}

	/**
	 * <p>
	 * To Track SMS status. NEW-1 and PICKED-2. ALL status is added for GUI
	 * purpose. This should not be used to set the Sms Status
	 * </p>
	 */
	public enum SMS_LANGUAGE_TYPE {
		ar_SA {
			public String toString() {
				return "ar_SA";
			}
		},
		en_US {
			public String toString() {
				return "en_US";
			}
		}
	}


	public enum JOB_TYPE {
		ALL, INTERNAL, EXTERNAL
	}

	public enum JOB_RUNNING_STATUS {
		STOPPED, STARTED ;
		
		public String getName(int i) {

			switch (i) {
			case 0:
				return "Stopped"; 
			case 1:
				return "Started";
			default:
				return "UNK";
			}
		}
	}
	
	/**
	 * Attribute INVALIDCHAR defines invalid characters Used for validate user
	 * input in CRUD controllers
	 */
	public static String INVALIDCHAR = "[\\<\\>\\.\\!\\'\\\"\\)\\(\\\\]";
	/**
	 * <p>
	 * Attribute INVALIDCHAR_NO_DOT defines invalid characters excluding '.'
	 * Used for package and Class names
	 */
	public static String INVALIDCHAR_NO_DOT = "[\\<\\>\\\\!\\'\\\"\\)\\(]";

	public enum MODULE_NAME {
		ROOT, CORE, CCLG, CCLN, PPM;
	}

	public enum APPLICATION_NAME {
		CCLG, CCLN;

		public String getName(int i) {
			switch (i) {
			case 0:
				return "CCLG";
			case 1:
				return "CCLN";
			default:
				return "";
			}
		}
		public String getName(){
			return getName(this.ordinal());
		}
	}

	
	public static String FTS_SERVICE_NAME = "FTSPostingService";

	public enum CURRENCY {
		SAR
	}

	
	public enum SORT_ORDER	{		
		ASC,DESC;
	}
	
	public  static String SarieMessageAdaptable ="SarieMessageAdaptable";
	public static String MTProcessorStatus = "MTProcessorStatus"; 
	public static final int  NUMBER_RESEND_TIMEOUT_FTSREQUEST=3;
	public static final int   NOTIFICATION_MAILTEMPLATE_ID=5;
	public static final int NOTIFICATION_OUTGOING_MSG_TPL_ID=7;
	public static final int NOTIFICATION_OUTGOING_MSG_ADAPTER_TPL_ID=8;
	public static final int NOTIFICATION_AUTHORIZATION_STATUS_INQUIRY_TPL_ID=9;
	public static final int   STATISTICS_JOB_MAIL_TEMPLATE_ID=10;
	public static final long   NOTIFICATION_WORKFLOW_EXCEPTION_ID=14;
	public static final long   NOTIFICATION_DLQ_ID=13;
	public static final long   DAILY_REPORT_NOTIFY_TEMPLATE_ID=15;
	public static final long   DAILY_REPORT_AUDIT_REJECTED_TEMPLATE_ID=20;
	public static final long   DAILY_REPORT_INCOMING_SWIFT_PAYMENT_REPORT_TEMPLATE_ID=22;
	public static final int   MESSAGE_PROCESSING_FAILED_NOTIFICATION_MAIL_TEMPLATE_ID=45;
	

	/* maximum number of files that we can handle it  */
	public static final int MAX_JOB_FILES=10;
	
	public static final String FIXED_VALUE = "";
	public static final String CCLG_STATUS_FIELD = "chqStatus";
 
	
	public enum YesNoType {
		NO, YES;
	}

	public enum RATE_INDICATOR {
		NOT_SUPPORTED,SAME_CUR,CROS_CUR,AUTO_FX,URG_AUTO_FX;
		
	}
	
	public static String TC_STATUS_FIELD = "tcStatus";

	public static String USER_GROUPS="select A.App_Code AS aCode, P.Profile_Code AS pCode, U.Dept_Code AS dCode"+
	" from Portal_Applications A, Portal_Profile_List P, Users U, Portal_Access_Control C"+
	" where U.User_Code =?" +
	" and A.App_Code = 'PPM'" +
	" and C.User_Id = U.Id" +
	" and A.Id = P.App_Id" +
	" and C.Profile_Id = P.Id";
}


