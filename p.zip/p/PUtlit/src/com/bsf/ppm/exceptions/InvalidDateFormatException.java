package com.bsf.ppm.exceptions;

public class InvalidDateFormatException  extends BusinessException{

	public InvalidDateFormatException(String key) {
		super(key);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
