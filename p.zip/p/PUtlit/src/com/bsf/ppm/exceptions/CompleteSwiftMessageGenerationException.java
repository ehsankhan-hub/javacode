package com.bsf.ppm.exceptions;

import com.bsf.ppm.exceptions.BusinessException;

/**
 * @author rsaif
 *
 */
public class CompleteSwiftMessageGenerationException extends BusinessException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public CompleteSwiftMessageGenerationException(String key,Object... params) {
		super(key,params);
	}
	public CompleteSwiftMessageGenerationException(String key, Exception x, Object... params){
		super(key,x,params);

	}

}
