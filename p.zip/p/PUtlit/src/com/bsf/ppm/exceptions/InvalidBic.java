package com.bsf.ppm.exceptions;


public class InvalidBic extends BusinessException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidBic(String key, Object... params) {
		super(key, params);
	}

}
