package com.bsf.ppm.exceptions;


/**
 * Data Access Layer Exceptions
 */
public class DAOException extends ApplicationException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4943050678129288148L;

	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 */
	public DAOException(String key) {
		this(key, null, (Object[]) null);
	}

	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 * @param param
	 *            exception message parameter
	 */
	public DAOException(String key, Object param) {
		this(key, null, param);
	}

	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 * @param params
	 *            exception message parameters
	 */
	public DAOException(String key, Object... params) {
		this(key, null, params);
	}

	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 * @param param
	 *            exception message parameter
	 * @param x
	 *            underlying exception
	 */
	public DAOException(String key, Exception x, Object... params) {
		super("bundles.DAOErrorMessages", key, x, params);
	}
}
