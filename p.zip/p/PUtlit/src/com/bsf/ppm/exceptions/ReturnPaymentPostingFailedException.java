package com.bsf.ppm.exceptions;


public class ReturnPaymentPostingFailedException extends BusinessException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;	
	
	public ReturnPaymentPostingFailedException(String key, Exception x, Object[] params) {
		super(key, x, params);
	}
	public ReturnPaymentPostingFailedException(String key, Object[] params){
		super(key, null, params);
	}	
}
