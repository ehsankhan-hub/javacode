package com.bsf.ppm.exceptions;

/**
 * Generic exception class for IPP infrastructure.
 */
public class InfrastructureException extends ApplicationException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7874146928994820533L;

	/**
	 * Construct exception.
	 * 
	 * @param message
	 *            exception message, or localization key for actual message
	 */
	public InfrastructureException(String message) {
		this(message, null, (Object[]) null);
	}

	/**
	 * Construct exception.
	 * 
	 * @param message
	 *            exception message, or localization key for actual message
	 * @param param
	 *            exception message parameter
	 */
	public InfrastructureException(String message, Object... params) {
		this(message, null, params);
	}

	/**
	 * Construct exception. Message is set to (x == null) ? null : x.toString().
	 * 
	 * @param x
	 *            underlying exception
	 */
	public InfrastructureException(Exception x) {
		this(null, x, (Object[]) null);
	}

	/**
	 * Construct exception.
	 * 
	 * @param message
	 *            exception message, or localization key for actual message
	 * @param x
	 *            underlying exception
	 */
	public InfrastructureException(String message, Exception x) {
		this(message, x, (Object[]) null);
	}

	/**
	 * Construct exception.
	 * 
	 * @param message
	 *            exception message, or localization key for actual message
	 * @param param
	 *            exception message parameter
	 * @param x
	 *            underlying exception
	 */
	public InfrastructureException(String message, Exception x,
			Object... params) {
		super("bundles.SystemErrorMessages", message, x, params);
	}
}
