package com.bsf.ppm.exceptions;

public interface IException {
	public String getMessage();
}
