package com.bsf.ppm.exceptions;


public class OtmsReversePaymentFailedException extends BusinessException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;	
	
	public OtmsReversePaymentFailedException(String key, Exception x, Object[] params) {
		super(key, x, params);
	}
	public OtmsReversePaymentFailedException(String key, Object[] params){
		super(key, null, params);
	}	
}
