package com.bsf.ppm.exceptions;

public class InCorrectDataException extends BusinessException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4943050678129288148L;

	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 */
	public InCorrectDataException(String key) {
		this(key, null, (Object[]) null);
	}

	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 * @param param
	 *            exception message parameter
	 */
	public InCorrectDataException(String key, Object param) {
		this(key, null, param);
	}

	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 * @param params
	 *            exception message parameters
	 */
	public InCorrectDataException(String key, Object... params) {
		this(key, null, params);
	}

	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 * @param param
	 *            exception message parameter
	 * @param x
	 *            underlying exception
	 */
	public InCorrectDataException(String key, Exception x, Object... params) {
		super(key, x, params);
	}
	
	public InCorrectDataException(String key, Exception x) {
		this(key, x, (Object[]) null);
	}	
}
