package com.bsf.ppm.exceptions;


import com.bsf.ppm.Ppm_Inst_Transactions;

public class InstTransactionProcessorException extends BusinessException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Ppm_Inst_Transactions ppm_Inst_Transactions;
	public InstTransactionProcessorException(String key, Exception x, Object[] params) {
		super(key, x, params);
	}
	public InstTransactionProcessorException(Exception exception, Ppm_Inst_Transactions entity, String key, Object[] params){
		super(key, exception, params);
		this.ppm_Inst_Transactions = entity;
	}
	
	
	public Ppm_Inst_Transactions getPpm_Inst_Transactions() {
		return ppm_Inst_Transactions;
	}
	public void setPpm_Inst_Transactions(Ppm_Inst_Transactions ppm_Inst_Transactions) {
		this.ppm_Inst_Transactions = ppm_Inst_Transactions;
	}
	
	
}
