package com.bsf.ppm.exceptions;

import com.bsf.ppm.util.I18N;

@SuppressWarnings("serial")
public class UnrecoverableException extends RuntimeException implements
		IException {
	private String resource;
	private Throwable cause;
	private String key;
	private Object[] params;

	protected UnrecoverableException(String resource, String message,
			Exception exception, Object... params) {
		super(message);
		this.resource = resource;
		this.cause = exception;
		this.params = params;
	}

	public UnrecoverableException(String key, Exception x, Object[] params) {
		this("bundles.SystemErrorMessages", key, x, params);
	}
	
	public UnrecoverableException(String key, Exception x) {
		this("bundles.SystemErrorMessages", key, x);
	}

	/**
	 * Return underlying exception.
	 * 
	 * @return underlying exception <b>null</b> if none
	 */

	public Throwable getCause() {
		return cause;
	}

	/**
	 * Return exception message. Overriden to ensure message is localized.
	 * 
	 * @return localized exception message
	 */
	public String getMessage() {
		return getLocalizedMessage();
	}

	/**
	 * Return localized exception message. The result is the top-level reason,
	 * and details plus a chain of underlying exceptions (allowing the root
	 * cause to be ascertained). The string returned is formatted according to
	 * the value of the specified localization key (if it could be located).
	 * 
	 * @return localized exception message
	 */
	public String getLocalizedMessage() {
		StringBuffer result = new StringBuffer();
		result.append(getFormattedMessage());
		if (getCause() != null) {
			StringBuffer cause = new StringBuffer();
			getReason(cause, getCause());
			result.append('\n');
			result.append(cause.toString());
		}
		return result.toString();
	}

	/**
	 * Convert exception to string representation.
	 * 
	 * @return localized exception message
	 */
	public String toString() {
		return getLocalizedMessage();
	}

	/**
	 * Get formatted message for this exception instance.
	 */
	private String getFormattedMessage() {
		return I18N.getText(resource, super.getMessage(), params);
	}

	/**
	 * Get string representation of underlying cause of exception.
	 */
	private void getReason(StringBuffer buffer, Throwable exception) {
		if (exception == null)
			return;
		else if (exception instanceof UnrecoverableException) {
			UnrecoverableException x = (UnrecoverableException) exception;
			buffer.append(x.getFormattedMessage());
			if (x.getCause() != null) {
				buffer.append('\n');
				getReason(buffer, x.getCause());
			}
		} else
			buffer.append(exception.toString());
	}
}
