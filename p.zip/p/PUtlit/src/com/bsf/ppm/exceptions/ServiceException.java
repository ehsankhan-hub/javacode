package com.bsf.ppm.exceptions;


public class ServiceException extends BusinessException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ServiceException(String key) {
		super(key);
	}
	public ServiceException(String key,Exception x) {
		super(key,x);
	}
	public ServiceException(String key,Exception x, Object[] objects) {
		super(key,x,objects);
	}

}
