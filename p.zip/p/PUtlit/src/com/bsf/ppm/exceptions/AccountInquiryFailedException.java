package com.bsf.ppm.exceptions;

public class AccountInquiryFailedException extends Exception {

	public AccountInquiryFailedException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AccountInquiryFailedException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AccountInquiryFailedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public AccountInquiryFailedException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
