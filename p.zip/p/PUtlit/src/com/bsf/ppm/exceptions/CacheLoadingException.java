package com.bsf.ppm.exceptions;

public class CacheLoadingException  extends UnrecoverableException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 */
	public CacheLoadingException(String key) {
		this(key, null, (Object[]) null);
	}

	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 * @param param
	 *            exception message parameter
	 */
	public CacheLoadingException(String key, Object param) {
		this(key, null, param);
	}

	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 * @param params
	 *            exception message parameters
	 */
	public CacheLoadingException(String key, Object... params) {
		this(key, null, params);
	}

	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 * @param param
	 *            exception message parameter
	 * @param x
	 *            underlying exception
	 */
	public CacheLoadingException(String key, Exception x, Object... params) {
		super( key, x, params);
	}

}
