package com.bsf.ppm.exceptions;

public class FTSRequestTimeoutException  extends InfrastructureException{

	public FTSRequestTimeoutException(Exception x) {
		super(x);
	}
	
	public FTSRequestTimeoutException(String  message) {
		super(message);
	}
	public FTSRequestTimeoutException() {
		super("fts.timeout");
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
