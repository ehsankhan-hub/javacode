package com.bsf.ppm.exceptions;

public class SwiftFileParsingException  extends InfrastructureException{

	public SwiftFileParsingException(String key, Exception x) {
		super(key, x);
	}
	public SwiftFileParsingException(String message) {
		super(message);
	}
	
	public SwiftFileParsingException(Exception x) {
		super("swift.parssingerror",x);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
