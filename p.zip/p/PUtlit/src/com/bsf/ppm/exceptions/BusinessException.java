package com.bsf.ppm.exceptions;

/**
 * Top-level service level exception
 */
public class BusinessException extends ApplicationException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4943050678129288148L;

	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 */
	public BusinessException(String key) {
		this(key, null, (Object[]) null);
	}

	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 * @param param
	 *            exception message parameter
	 */
	public BusinessException(String key, Object param) {
		this(key, null, param);
	}

	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 * @param params
	 *            exception message parameters
	 */
	public BusinessException(String key, Object... params) {
		this(key, null, params);
	}

	/**
	 * Construct exception.
	 * 
	 * @param key
	 *            location key for exception message
	 * @param param
	 *            exception message parameter
	 * @param x
	 *            underlying exception
	 */
	public BusinessException(String key, Exception x, Object... params) {
		super("bundles.BusinessErrorMessages", key, x, params);
	}
}
