package com.bsf.ppm.util;


public class ChargeRequestVO {

	/**
	 * Attribute id.
	 */
	private Long id;
	
	private String referenceNumber;

	private String application;
	
	/** 
	 * Attribute referenceNumber.
	 */
	private Long messageId;

	/**
	 * Attribute debitCurrency.
	 */
	private String debitCurrency;

	/**
	 * Attribute .
	 */
	private double chargeAmount;
	/**
	 * Attribute .
	 */
	private String chargeDetails;
	/**
	 * Attribute .
	 */
	private String senderReceiverInfo;

	/**
	 * Attribute .
	 */
	private String orderingInstitution;
	
	private String orderingInstitutionType; 

	private String accountWithInstitution ;
	
	private String accountWithInstitutionType;

	/**
	 * Attribute senderBank.
	 */
	private String senderBank;

	private String formatType;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public String getDebitCurrency() {
		return debitCurrency;
	}

	public void setDebitCurrency(String debitCurrency) {
		this.debitCurrency = debitCurrency;
	}

	public double getChargeAmount() {
		return chargeAmount;
	}

	public void setChargeAmount(double chargeAmount) {
		this.chargeAmount = chargeAmount;
	}

	public String getChargeDetails() {
		return chargeDetails;
	}

	public void setChargeDetails(String chargeDetails) {
		this.chargeDetails = chargeDetails;
	}

	public String getSenderReceiverInfo() {
		return senderReceiverInfo;
	}

	public void setSenderReceiverInfo(String senderReceiverInfo) {
		this.senderReceiverInfo = senderReceiverInfo;
	}

	public String getOrderingInstitution() {
		return orderingInstitution;
	}

	public void setOrderingInstitution(String orderingInstitution) {
		this.orderingInstitution = orderingInstitution;
	}

	public String getAccountWithInstitution() {
		return accountWithInstitution;
	}

	public void setAccountWithInstitution(String accountWithInstitution) {
		this.accountWithInstitution = accountWithInstitution;
	}

	public String getSenderBank() {
		return senderBank;
	}

	public void setSenderBank(String senderBank) {
		this.senderBank = senderBank;
	}

	public String getFormatType() {
		return formatType;
	}

	public void setFormatType(String formatType) {
		this.formatType = formatType;
	}

	public String getOrderingInstitutionType() {
		return orderingInstitutionType;
	}

	public void setOrderingInstitutionType(String orderingInstitutionType) {
		this.orderingInstitutionType = orderingInstitutionType;
	}

	public String getAccountWithInstitutionType() {
		return accountWithInstitutionType;
	}

	public void setAccountWithInstitutionType(String accountWithInstitutionType) {
		this.accountWithInstitutionType = accountWithInstitutionType;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}
}
