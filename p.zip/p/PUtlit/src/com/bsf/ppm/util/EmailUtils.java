package com.bsf.ppm.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * @author Sandeep
 *
 */

public class EmailUtils {
	
	public static boolean isValidEmailId(String emailId) 
	{
		// Split email address separate by comma 
		String[] emailIdArray = emailId.split(",\\s*");
		
		// Define email pattern string 
		String EMAIL_PATTERN = 
		"^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"; 
		// Set the email pattern string 
		Pattern p = Pattern.compile(EMAIL_PATTERN);
		
		boolean result = false; 
		for (int i = 0; i < emailIdArray.length; i++) { 
			// Match the given string with the pattern 
			Matcher m = p.matcher(emailIdArray[i]);
			// get result 
			result = m.matches();
			// if email not correct stop this loop 
			if (!result) { 
				break; 
			}
		}
		return result; 
	}

}
