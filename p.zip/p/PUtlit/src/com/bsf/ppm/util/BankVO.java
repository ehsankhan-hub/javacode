package com.bsf.ppm.util;

import java.util.Date;

public class BankVO {
	
	/**
	 * Attribute messageId.
	 */
	private Long messageId;
	
	/**
	 * Attribute relatedRefNumber.
	 */
	private String relatedRefNumber;

	/**
	 * Attribute referenceNumber.
	 */
	private String referenceNumber;
	
	/**
	 * Attribute messageType.
	 */
	private String messageType;

	/**
	 * Attribute valueDate.
	 */
	private Date valueDate;

	/**
	 * Attribute sumAmount.
	 */
	private Double sumAmount;

	/**
	 * Attribute orderingInstitution.
	 */
	private String orderingInstitution;

	/**
	 * Attribute orderingInstitutionType.
	 */
	private String orderingInstitutionType;

	/**
	 * Attribute senderCorrespondent.
	 */
	private String senderCorrespondent;

	/**
	 * Attribute senderCorrespondentType.
	 */
	private String senderCorrespondentType;

	/**
	 * Attribute receiverCorrespondent.
	 */
	private String receiverCorrespondent;

	/**
	 * Attribute receiverCorrespondentType.
	 */
	private String receiverCorrespondentType;
	
	/**
	 * Attribute timeIndication.
	 */
	private String timeIndication;

	/**
	 * Attribute createdDate.
	 */
	private Date createdDate;	
	
	/**
	 * Attribute formatType.
	 */
	private String formatType;

	/**
	 * Processing status of the message
	 */
	private Integer messageStatus;
	
	/**
	 * Attribute receiverBankCode.
	 */
	private String receiverBankCode;
	
	/**
	 * Attribute currency.
	 */
	private String currency;

	/**
	 * Attribute amount.
	 */
	private Double amount;

	/**
	 * Attribute intermediary.
	 */
	private String intermediaryInstitution;

	/**
	 * Attribute intermediaryType.
	 */
	private String intermediaryInstitutionType;

	/**
	 * Attribute accountwithInstitution.
	 */
	private String accountwithInstitution;

	/**
	 * Attribute accountwithInstitutionType.
	 */
	private String accountwithInstitutionType;

	/**
	 * Attribute beneficiaryInstitution.
	 */
	private String beneficiaryInstitution;

	/**
	 * Attribute beneficiaryInstitutionType.
	 */
	private String beneficiaryInstitutionType;

	/**
	 * Attribute senderReceiverInformation.
	 */
	private String senderReceiverInformation;

	private String application;


	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public String getRelatedRefNumber() {
		return relatedRefNumber;
	}

	public void setRelatedRefNumber(String relatedRefNumber) {
		this.relatedRefNumber = relatedRefNumber;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public Date getValueDate() {
		return valueDate;
	}

	public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}

	public Double getSumAmount() {
		return sumAmount;
	}

	public void setSumAmount(Double sumAmount) {
		this.sumAmount = sumAmount;
	}

	public String getOrderingInstitution() {
		return orderingInstitution;
	}

	public void setOrderingInstitution(String orderingInstitution) {
		this.orderingInstitution = orderingInstitution;
	}

	public String getOrderingInstitutionType() {
		return orderingInstitutionType;
	}

	public void setOrderingInstitutionType(String orderingInstitutionType) {
		this.orderingInstitutionType = orderingInstitutionType;
	}

	public String getSenderCorrespondent() {
		return senderCorrespondent;
	}

	public void setSenderCorrespondent(String senderCorrespondent) {
		this.senderCorrespondent = senderCorrespondent;
	}

	public String getSenderCorrespondentType() {
		return senderCorrespondentType;
	}

	public void setSenderCorrespondentType(String senderCorrespondentType) {
		this.senderCorrespondentType = senderCorrespondentType;
	}

	public String getReceiverCorrespondent() {
		return receiverCorrespondent;
	}

	public void setReceiverCorrespondent(String receiverCorrespondent) {
		this.receiverCorrespondent = receiverCorrespondent;
	}

	public String getReceiverCorrespondentType() {
		return receiverCorrespondentType;
	}

	public void setReceiverCorrespondentType(String receiverCorrespondentType) {
		this.receiverCorrespondentType = receiverCorrespondentType;
	}

	public String getTimeIndication() {
		return timeIndication;
	}

	public void setTimeIndication(String timeIndication) {
		this.timeIndication = timeIndication;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getFormatType() {
		return formatType;
	}

	public void setFormatType(String formatType) {
		this.formatType = formatType;
	}

	public Integer getMessageStatus() {
		return messageStatus;
	}

	public void setMessageStatus(Integer messageStatus) {
		this.messageStatus = messageStatus;
	}

	public String getReceiverBankCode() {
		return receiverBankCode;
	}

	public void setReceiverBankCode(String receiverBankCode) {
		this.receiverBankCode = receiverBankCode;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getIntermediaryInstitution() {
		return intermediaryInstitution;
	}

	public void setIntermediaryInstitution(String intermediaryInstitution) {
		this.intermediaryInstitution = intermediaryInstitution;
	}

	public String getIntermediaryInstitutionType() {
		return intermediaryInstitutionType;
	}

	public void setIntermediaryInstitutionType(String intermediaryInstitutionType) {
		this.intermediaryInstitutionType = intermediaryInstitutionType;
	}

	public String getAccountwithInstitution() {
		return accountwithInstitution;
	}

	public void setAccountwithInstitution(String accountwithInstitution) {
		this.accountwithInstitution = accountwithInstitution;
	}

	public String getAccountwithInstitutionType() {
		return accountwithInstitutionType;
	}

	public void setAccountwithInstitutionType(String accountwithInstitutionType) {
		this.accountwithInstitutionType = accountwithInstitutionType;
	}

	public String getBeneficiaryInstitution() {
		return beneficiaryInstitution;
	}

	public void setBeneficiaryInstitution(String beneficiaryInstitution) {
		this.beneficiaryInstitution = beneficiaryInstitution;
	}

	public String getBeneficiaryInstitutionType() {
		return beneficiaryInstitutionType;
	}

	public void setBeneficiaryInstitutionType(String beneficiaryInstitutionType) {
		this.beneficiaryInstitutionType = beneficiaryInstitutionType;
	}

	public String getSenderReceiverInformation() {
		return senderReceiverInformation;
	}

	public void setSenderReceiverInformation(String senderReceiverInformation) {
		this.senderReceiverInformation = senderReceiverInformation;
	}		
	
	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}	
}

