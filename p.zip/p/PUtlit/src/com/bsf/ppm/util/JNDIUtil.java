package com.bsf.ppm.util;

import java.io.File;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.bsf.ppm.exceptions.DAOException;

public class JNDIUtil {
	private static final Logger logger = Logger
			.getLogger(SessionFactoryCisprodManager.class);

	private static Map cache = new HashMap();
	@Autowired
	@Qualifier("dataSourceSlry")
	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public static Object lookup(Context ctx, String location)
			throws NamingException {

		return lookup(ctx, location, false);
	}
	
	public static Connection getSimpleDBConnection()	{
		
		InitialContext ic = null;
		DataSource dataSource = null;
		Connection conn = null;
		try {
				 ic = new InitialContext();
				 dataSource = (DataSource)lookup(ic,"java:jdbc/ppm");
				 if(dataSource != null)	{
					 
					 conn = dataSource.getConnection();
				 }
		}catch(NamingException ne){
			
			
		}catch(SQLException sqle)	{
			
			
		}
		return conn;
	}
/// CIS Database related Changes start
	private static SessionFactory sessionFactory;

	private static Session session;

	@SuppressWarnings("deprecation")
	private static SessionFactory getSessionFactory() throws DAOException {
		if (sessionFactory == null) {
			try {
				return new AnnotationConfiguration().configure("/hibernateCisprod.cfg.xml").buildSessionFactory();
			} catch (Exception e) {
				logger.error(
						"Error occured in creating session factory. Error "
								+ e.getMessage(), e);
				throw new DAOException("Session Factory creation failed", e);
			}

		}
		return sessionFactory;
	}

	public static Session getSession() throws DAOException {
		if (session != null) {
			return session;
		} else {
			try {
				session = getSessionFactory().openSession();
				return session;
			} catch (HibernateException e) {
				logger.error(
						"Failed to create session. Error " + e.getMessage(), e);
				throw new DAOException("Failed to create session. Error "
						+ e.getMessage(), e);
			} catch (DAOException e) {
				logger.error(
						"Failed to create session. Error " + e.getMessage(), e);
				throw new DAOException("Failed to create session. Error "
						+ e.getMessage(), e);
			}
		}
	}
	
	public static Session getCurrentSession() throws DAOException {
		if (session != null) {
			return session;
		} else {
			try {
				session = getSessionFactory().openSession();
				return session;
			} catch (HibernateException e) {
				logger.error(
						"Failed to create session. Error " + e.getMessage(), e);
				throw new DAOException("Failed to create session. Error "
						+ e.getMessage(), e);
			} catch (DAOException e) {
				logger.error(
						"Failed to create session. Error " + e.getMessage(), e);
				throw new DAOException("Failed to create session. Error "
						+ e.getMessage(), e);
			}
		}
	}
	
	

	public boolean closeSession() throws DAOException {
		if (session != null) {
			session.close();
			return true;
		}
		return false;
	}	

	
	
	
	
/// CIS Database related Changes end	
	
	
	
 public static Connection getCisDatabaseConnection()	{
		
		InitialContext ic = null;
		DataSource dataSource = null;
		Connection conn = null;
		try {
				 ic = new InitialContext();
				 dataSource = (DataSource)lookup(ic,"java:jdbc/cis");
				 if(dataSource != null)	{
					 
					 conn = dataSource.getConnection();
				 }
		}catch(NamingException ne){
			
			
		}catch(SQLException sqle)	{
			
			
		}
		return conn;
	}
/// CIS Database related Changes end 	
	

	public static Object lookup(Context ctx, String location, boolean fromCache)
			throws NamingException {

		Object obj = null;

		if (fromCache) {
			obj = cache.get(location);

			if (obj == null) {
				obj = lookupLocation(ctx, location);

				cache.put(location, obj);
			}
		} else {
			obj = lookupLocation(ctx, location);
		}
		return obj;
	}

	private static Object lookupLocation(Context ctx, String location)
			throws NamingException {

		Object obj = null;

		try {
			obj = ctx.lookup(location);
		} catch (NamingException n1) {

			// java:comp/env/ObjectName to ObjectName

			if (location.indexOf("java:comp/env/") != -1) {
				try {
					obj = ctx.lookup(StringUtils.replace(location, "java:comp/env/", ""));
							
				} catch (NamingException n2) {

					// java:comp/env/ObjectName to java:ObjectName

					obj = ctx.lookup(StringUtils.replace(location, "comp/env/",""));
				}
			}

			// java:ObjectName to ObjectName

			else if (location.indexOf("java:") != -1) {
				try {
					obj = ctx.lookup(StringUtils.replace(location, "java:", ""));
				} catch (NamingException n2) {

					// java:ObjectName to java:comp/env/ObjectName

					obj = ctx.lookup(StringUtils.replace(location, "java:",
							"java:comp/env/"));
				}
			}

			// ObjectName to java:ObjectName

			else if (location.indexOf("java:") == -1) {
				try {
					obj = ctx.lookup("java:" + location);
				} catch (NamingException n2) {

					// ObjectName to java:comp/env/ObjectName

					obj = ctx.lookup("java:comp/env/" + location);
				}
			} else {
				throw new NamingException();
			}
		}

		return obj;
	}
	
	public static Connection getConnection()throws DAOException{
		Connection con=null;
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con =java.sql.DriverManager.getConnection("jdbc:oracle:thin:@EXAD-SCAN:1521:OLTPDEV","oepaysd2","oepaysd2");
		
		/*Class.forName("oracle.jdbc.driver.OracleDriver");
		con  =  java.sql.DriverManager.getConnection("jdbc:oracle:thin:@EXAH-SCAN:1521/BDSP","ppmappuser","ppm2017");*/
		}
		catch(ClassNotFoundException cnf){
			cnf.printStackTrace();
		}
		catch(SQLException sql){
		sql.printStackTrace();
		}
		return con;
	}
	

	
	

	public static final Serializable getFromJndi(String location)
			throws NamingException {
		InitialContext context = new InitialContext();
		return (Serializable) context.lookup(location);
	}

}