package com.bsf.ppm.util;

import java.util.HashMap;
import java.util.Map;

public class GregHijriCalendarGenerator {

	public static void main(String[] args) {

		int noOfGregDaysPerMonth[]={31,29,31,30,31,30,31,31,30,31,30,31};
		int noOfHijriDaysPerMonth1432[]={29,30,30,30,29,30,29,30,29,30,29,29};
		int noOfHijriDaysPerMonth1433[]={30,29,30,30,29,30,30,29,30,29,30,29};
		int noOfHijriDaysPerMonth1434[]={29,30,30,30,29,30,29,30,29,30,29,29};
		
		Map<Integer,int[]> map = new HashMap<Integer,int[]>();
		map.put(1432, noOfHijriDaysPerMonth1432);
		map.put(1433, noOfHijriDaysPerMonth1433);
		map.put(1434, noOfHijriDaysPerMonth1434);
		
		int id=731;
		int gregDay=1;
		int gregMon=0;
		int gregYear=2012;
		int hijriDay=7;
		int hijriMon=1;
		int hijriYear=1433;

		while(gregYear<2013 && hijriYear<1437){
			while (gregDay<=noOfGregDaysPerMonth[gregMon] && hijriYear<1437){
			
				if (hijriMon>11){
					hijriMon=0;
					hijriYear+=1;
				}
				
				int totalHijriDays= ((int[])map.get(hijriYear))[hijriMon];
				if (hijriDay > totalHijriDays){
					hijriDay=1;
					hijriMon+=1;
					
					if (hijriMon>11){
						hijriMon=0;	
						hijriYear+=1;
					}
					
				}
				System.out.println("Insert into IPP.GREG_HIJRI_CALENDAR   (ID, GREG_DATE, HIJRI_DATE, STATUS, CREATED_BY) Values(" +
						id +", TO_DATE('" +
						(gregMon+1)+"/"+ gregDay +"/"+ gregYear +	"', 'MM/DD/YYYY'),'"+		
						(hijriMon+1)+"/"+ hijriDay +"/"+ hijriYear +			
				"', 1, 'system');");
				gregDay+=1;
				id+=1;
				hijriDay+=1;
			}
			gregDay=1;
			gregMon+=1;
			
			if (gregMon>11){
				gregMon=0;
				gregYear+=1;
			}
		}
	}
}
