package com.bsf.ppm.util;

import java.util.Date;

public class CreditInfo {

	private double creditAmount;	
	private Date asOfDate;
	private double exchangeRate;
	private boolean isAsOfDateTodayDate;
	
	public boolean isAsOfDateTodayDate() {
		return isAsOfDateTodayDate;
	}
	public void setAsOfDateTodayDate(boolean isAsOfDateTodayDate) {
		this.isAsOfDateTodayDate = isAsOfDateTodayDate;
	}
	public double getCreditAmount() {
		return creditAmount;
	}
	public void setCreditAmount(double creditAmount) {
		this.creditAmount = creditAmount;
	}
	public Date getAsOfDate() {
		return asOfDate;
	}
	public void setAsOfDate(Date asOfDate) {
		this.asOfDate = asOfDate;
	}
	public double getExchangeRate() {
		return exchangeRate;
	}
	public void setExchangeRate(double exchangeRate) {
		this.exchangeRate = exchangeRate;
	}
	
}
