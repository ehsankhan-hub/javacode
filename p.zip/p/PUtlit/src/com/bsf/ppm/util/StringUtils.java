package com.bsf.ppm.util;

import java.io.BufferedReader;
import java.io.UnsupportedEncodingException;
import java.sql.Clob;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.SystemUtils;

public class StringUtils {
	public static String removeNonAlpha(final String str) {
		final StringBuffer result = new StringBuffer();
		if (str != null) {
			for (int i = 0; i < str.length(); i++) {
				char c = str.charAt(i);
				if (Character.isLetter(c) || Character.isDigit(c)) {
					result.append((char) c);
				}
			}
			return result.toString();
		}
		return str;
	}

	public static String formatBIC(String bicCode){
		StringBuffer bic = new StringBuffer();
		if (bicCode.length()==8){
			bic.append(bicCode).append("XXXX");			
		}
		else if(bicCode.length()==11){
			if (!bicCode.substring(8,9).equalsIgnoreCase("X")){
				bic.append(bicCode.substring(0, 8)).append("X").append(bicCode.substring(8));			
			}
			else
			{
				bic.append(bicCode).append("X");
			}
		}
		else
			bic.append(bicCode);

		return bic.toString();
	}
	
	public static String getBIC(String bicCode){
		StringBuffer bic = new StringBuffer();
		if (bicCode == null)
			return bicCode;
		
		if (bicCode.length()== 11){
			bic.append(bicCode);			
		}
		else if(bicCode.length()== 8){			
				bic.append(bicCode);			
		}
		else if (bicCode.length()>11)
			bic.append(bicCode.substring(0,11));

		return bic.toString();
	}

	public static String replaceNewLineCharacter(String str){
		if (str == null)
			return null;
		return str.replaceAll("\r\n", System.getProperty("line.separator"));
	}
	
	
	
	
	/*
	 * @param String
	 * @param int
	 * @return String
	 * This function takes string and adds new line characters \r\n after each Y characters 
	 * and  makes string format N*Y X format where N is number of lines and Y is number of characters in each row.
	 * Example :- If wants to make 35 x 50X format (i.e 35 lines and 50 character each line format )
	 * 
	 * 1)   Validate total number of characters from controller validate method for 1750-70=1680 chars.
	 * 		2 character space is reserved for \r\n character in each line.
	 *   	Total number of lines 35 so total reserve space 35x2=70
	 * 	
	 * 2) Pass original string and 48 (expected character in each row - 2  i.e  50-2=48.
	 * 	  2 character space is reserved for \r\n character in each line.  
	 * 
	 */
	public static String includeLinesInString(String origString,int numberOfCharInEachRow) {
		String modString = "";
		try {
			int startIndex = 0;
			int i = 0;
			for (i = 0; i <= origString.length(); i++) {

				if (i % numberOfCharInEachRow == 0 && i != 0) {
					modString = modString + origString.substring(startIndex, i)
					+ "\r\n";
					startIndex = i;
				}
			}
			modString = modString
			+ origString.substring(startIndex, origString.length() - 1);

		} catch (Exception exp) {			
			exp.printStackTrace();
		}
		return modString;
	}

	public static String formatStringSwift(String origString,int noOfLines, int maxChars) {
		StringBuffer modString = new StringBuffer();
		try {
			if (origString == null)
				return origString;
			int lineNo=0;
			int startIndex = 0;
			int i = 0;
			char c = 'c';
			int noOfChars = 0;
			for (i = 0; i < origString.length(); i++) {
				noOfChars++;
				
				if (lineNo >= noOfLines)
					break;
				c = origString.charAt(i);				
				if (noOfChars == maxChars) {
					modString.append(origString.substring(startIndex,i+1)).append("\r\n");
					startIndex = i+1;
					lineNo++;
					noOfChars = 0;
				}
				else if (c =='\r' ){
					i=i+1;
					c = origString.charAt(i);					
					if (  c=='\n' && noOfChars <= maxChars){						
						lineNo++;						
						modString.append(origString.substring(startIndex, i+1));						
						startIndex = i+1;
						noOfChars = 0;
					}
				}
				else if (startIndex < origString.length() && origString.substring(startIndex).length() <= maxChars) {
					if (startIndex < 0)
						startIndex = 0;
					modString.append(origString.substring(startIndex));
					break;
				}
			}			
		} catch (Exception exp) {			
			exp.printStackTrace();
		}
		String temp = modString.toString() ;
		temp = temp.replaceAll("(\r\n|\r|\n|\n\r)", "\r\n");		
		return temp;
	}	
	
	/**
	 * 
	 * @param bic
	 * @return
	 */
	public static String getCountryCodeFromBic(String bic){
		String countryCode="";
		if(bic!=null && bic.length()>7){
			countryCode=bic.substring(4, 6);
		}
		return countryCode;
	}
	  /**
	 * @param str
	 * @param wrapLength
	 * @param newLineStr
	 * @param wrapLongWords
	 * @param narrativeStartString
	 * @param maxLines
	 * @return
	 */
	public static boolean isWrapable(String str, int wrapLength, String newLineStr, boolean wrapLongWords,String narrativeStartString,int maxLines) {
		String wrapedString=wrap(str, wrapLength, newLineStr, wrapLongWords, narrativeStartString, maxLines+1);
		String[] lines = wrapedString.split(newLineStr);
		  return lines.length<=maxLines;
	  
	  }

	  /**
	 * @param str
	 * @param wrapLength
	 * @param newLineStr
	 * @param wrapLongWords
	 * @param narrativeStartString
	 * @param maxLines
	 * @return
	 */
	public static String wrap(String str, int wrapLength, String newLineStr, boolean wrapLongWords,String narrativeStartString,int maxLines) {
		  if(narrativeStartString==null)
			  narrativeStartString="";
		   int  lineNo=0;
		  String tempStr =null;
		  // in case of 72
		   if(org.apache.commons.lang.StringUtils.isNotBlank(narrativeStartString)) 
				   wrapLength=wrapLength-narrativeStartString.length();
	        if (org.apache.commons.lang.StringUtils.isBlank(str)) {
	            return null;
	        }
	        else{
	        	str=str.replaceAll(" {2,}", " ").trim();
	        }
	        if (newLineStr == null) {
	            newLineStr = SystemUtils.LINE_SEPARATOR;
	        }
	        if (wrapLength < 1) {
	            wrapLength = 1;
	        }
	        int inputLineLength = str.length();
	        int offset = 0;
	        StringBuffer wrappedLine = new StringBuffer(inputLineLength + 32);
	        
	        while (((inputLineLength - offset) > wrapLength) && lineNo<maxLines) {
	            if (Character.isWhitespace(str.charAt(offset))) {
	                offset++;
	                continue;
	            }
	           // int spaceToWrapAt = str.lastIndexOf(' ', wrapLength + offset);
	           // int newLineIndex = str.indexOf("\r\n");
	            int spaceToWrapAt=getSpaceToWrapAt(str,wrapLength , offset,true);
	            if((inputLineLength - offset) < wrapLength ){
	            	spaceToWrapAt=str.substring(offset).indexOf(newLineStr);
	            }


	            if (spaceToWrapAt >= offset) {
	                // normal case
	            	tempStr=str.substring(offset, spaceToWrapAt);
	            	if(appendLine(wrappedLine,tempStr,newLineStr,narrativeStartString))
	            	   lineNo++;
	                offset = spaceToWrapAt + 1;
	                
	            } else {
	                // really long word or URL
	                if (wrapLongWords) {
	                    // wrap really long word one line at a time
	                	tempStr=str.substring(offset, wrapLength + offset);
	                	if(appendLine(wrappedLine,tempStr,newLineStr,narrativeStartString))
		                 	lineNo++;
	                    offset += wrapLength;
	                } else {
	                    // do not wrap really long word, just extend beyond limit
	                   // spaceToWrapAt = str.indexOf(' ', wrapLength + offset);
	                	spaceToWrapAt=getSpaceToWrapAt(str,wrapLength , offset,false);
	                    if (spaceToWrapAt >= 0) {
	                    	tempStr=str.substring(offset, spaceToWrapAt);
	    	            	if(appendLine(wrappedLine,tempStr,newLineStr,narrativeStartString))
	    	            	   lineNo++;
	                        offset = spaceToWrapAt + 1;
	                    } else {
	                        wrappedLine.append(str.substring(offset));
	                        offset = inputLineLength;
	                    }
	                }
	        	}

	        	}
	        //
	       // || str.substring(offset).contains(newLineStr)
	        
        	if(str.substring(offset).contains(newLineStr)) {
        		String lines[] = str.substring(offset).split(newLineStr);
        		if(lines !=null){
        			for(String lintStr:lines){
	        		 if(lineNo>=maxLines)
	        			 break;
	       	          if(appendLine(wrappedLine,lintStr,newLineStr,narrativeStartString))
	       	            lineNo++;
       
        		}
        	}
        }else {
	        // Whatever is left in line is short enough to just pass through
	        //wrappedLine.append(narrativeStartString).append(str.substring(offset));
	        if(lineNo<maxLines)
	          appendLine(wrappedLine,str.substring(offset),newLineStr,narrativeStartString);
        }

	        return wrappedLine.toString().trim();
	    }

	private static int getSpaceToWrapAt(String str,int wrapLength ,int offset,boolean wrapLongWord) {
		 int spaceToWrapAt;
		if(wrapLongWord)
			spaceToWrapAt= str.lastIndexOf(' ', wrapLength + offset);
		else
	        spaceToWrapAt = str.indexOf(' ', wrapLength + offset);

         int newLineIndex = str.indexOf("\r\n", offset);
         if(newLineIndex>offset && spaceToWrapAt>newLineIndex){
        	 return newLineIndex;
         }else if(newLineIndex-offset-wrapLength<=0 && newLineIndex>spaceToWrapAt){
        	 return newLineIndex;
         }
         return spaceToWrapAt;
	}

	private static boolean appendLine(StringBuffer wrappedLine, String tempStr, String newLineStr,String narrativeStartString) {
		tempStr=removeInvalidChars(tempStr);
		if(tempStr !=null ){
			if (tempStr.startsWith("/") ||tempStr.startsWith("//")){
	            wrappedLine.append(tempStr);
	            wrappedLine.append(newLineStr);
		  }
		  else {
			wrappedLine.append(narrativeStartString);
            wrappedLine.append(tempStr);
            wrappedLine.append(newLineStr);
		}
		}
		else {
			return false;
		}
		return true;
		
	}

	private static String removeInvalidChars(String tempStr) {
		int i=0;
		char c;
		while(i<tempStr.length() ){
			c=tempStr.charAt(i);
			if(c==':'||c=='-' || Character.isWhitespace(c))
				i++;
			else 
			  break;
			
		}
		if(i<tempStr.length()){
			tempStr=tempStr.replaceAll("(\r\n|\r|\n|\n\r)", " ");
		 return tempStr.substring(i);
		}
		else 
			return null;
		
	}
	

	/**
	 * 
	 * @param inputString
	 * @return
	 */
	public static String formatBenDataString(String inputString){
		String newLineChar="\r\n";
		String updatedString="";
		if(inputString==null || inputString.length()==0){
			System.out.println("Null String");
			return "";
		}
		String[] inputStrArray =inputString.split(newLineChar);	

		/**
		 * String Update Start
		 */
		if(inputStrArray!=null && inputStrArray.length==1){
			if(inputStrArray[0].length()==0){
				System.out.println("No Data to format");
			}
			else if(inputStrArray[0].length()>0 && inputStrArray[0].length()<=33){
				updatedString=inputStrArray[0]+newLineChar;
			}
			else if(inputStrArray[0].length()>33 && inputStrArray[0].length()<=66){
				updatedString=inputStrArray[0].substring(0,33)+newLineChar;
				updatedString=updatedString+inputStrArray[0].substring(33)+newLineChar;
			}
			else{
				System.out.println("More than 2 lines");
			}
		}
		else if(inputStrArray!=null && inputStrArray.length==2){
			updatedString=updatedString+inputStrArray[0]+newLineChar;
			updatedString=updatedString+inputStrArray[1]+newLineChar;
		}
		System.out.println("Updated String="+updatedString);
		return updatedString;
	}
	/**
	 * @param nameAddress
	 * @return
	 */
	public static String formatPaymentNameAddress(String nameAddress){
		if(org.apache.commons.lang.StringUtils.isNotBlank(nameAddress)){
			nameAddress=nameAddress.replaceAll("\r\n|\r|\n| {2,}", " ");
		}
		return nameAddress;
	}
	/**
	 * @param nameAddress
	 * @return
	 */
	public static boolean  validatePaymentNameAddress(String nameAddress){
		return isWrapable(nameAddress, 35, "\r\n", true, "", 2);
	}
	/**
	 * @param senderReceiverInfo
	 * @return
	 */
	public static boolean  validatePaymentSenderReceiverInfo(String senderReceiverInfo){
		return isWrapable(senderReceiverInfo, 35, "\r\n", true, "//", 6);
	}
	
	/**
	 * @param inputString
	 * @param fieldName
	 * @return
	 */
	public static String validateBenDataBeforeFormating(String inputString,String fieldName){
		String newLineChar="\r\n";
		String[] inputStrArray =inputString.split(newLineChar);
		String alert=null;
		/**
		 *  Validation Start 
		 */
		// getting total chars without new line characters
		String inputStringWithOutNewLine="";
		if(inputStrArray!=null){
			for(int i=0;i<inputStrArray.length;i++){
				inputStringWithOutNewLine=inputStringWithOutNewLine+inputStrArray[i];
			}
		}
		// Validation for length
		if(inputStringWithOutNewLine!=null && inputStringWithOutNewLine.length()>66){
			alert="35*2 formats violated. Please correct "+fieldName +".";
			return alert;
		}
		// validation 1 no more than 2 lines allowed
		if(inputStrArray!=null && inputStrArray.length>2){
			alert="35*2 formats violated. Please correct "+fieldName +".";
			return alert;
	
		}
		
		String arrayStringVal="";
		if(inputStrArray!=null && inputStrArray.length==2){
			for(int i=0 ;i<inputStrArray.length;i++){
				arrayStringVal=inputStrArray[i];
				if(arrayStringVal!=null && arrayStringVal.length()>33){
					alert="35*2 formats violated. Please correct "+fieldName +".";
					return alert;
			
				}
			}
		}
		
		return alert;
	}
	
	/**
	 * @param s
	 */
	public static void printCharsCodes(String s)
	{
		String buff = "";
		for (int i = 0; i < s.length(); i++) {
			buff += (int)s.charAt(i) + " ";
		}
		System.out.println(buff);
	}
	
	/**
	 * @param bytes
	 */
	public static void printBytes(byte[] bytes)
	{
		String buff = "";
		for (int i = 0; i < bytes.length; i++) {
			buff += "[" + i + "]" + bytes[i] + " ";
		}
		System.out.println(buff);
	}
	
	public static String converClobToString(Clob clobText) throws Exception {
		BufferedReader reader = null;
		reader = new BufferedReader(clobText.getCharacterStream());
		StringBuilder sb = new StringBuilder();				            
		String line; 	 
		while ((line = reader.readLine()) != null) { 
			sb.append(line);					
		}
		return sb.toString();
	}
	
	public static String toHex(String arg) {
	
		try {
		char[] HEX_CHARS = "0123456789abcdef".toCharArray();
		byte[] buf = arg.getBytes("utf-8");
		  char[] chars = new char[2 * buf.length];
		    for (int i = 0; i < buf.length; ++i)
		    {
		        chars[2 * i] = HEX_CHARS[(buf[i] & 0xF0) >>> 4];
		        chars[2 * i + 1] = HEX_CHARS[buf[i] & 0x0F];
		    }
		    return new String(chars);
		} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		return arg;
	}
		
		/*byte[] bytes;
		try {
			bytes = arg.getBytes("ISO8859_6");
			BigInteger bigInt = new BigInteger(bytes);
			String hexString = bigInt.toString(16);
			return hexString;
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/ // you didn't say what charset you wanted
		
		/*try {
			return String.format("%x", new BigInteger(arg.getBytes("ISO8859_6")));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		//return arg;
	//}
	
	public static String padLeft(String str, int length, String padChar) {
		String pad = "";
		
	    for (int i = 0; i < length; i++) {
	        pad += padChar;
	    }
	    return pad.substring(str.length()) + str;
	}
	
	
	public static String padRightSpace(String str, int length, String padChar) {
	    String pad = "";
	    for (int i = 0; i < length; i++) {
	        pad += padChar;
	    }
	    String subString=pad.substring(str.length());
	    System.out.println("str+subString="+str+subString);
	    return str+subString;
	}
	
	
	public static void main(String[] args) {
		String str=padLeft("12345",7,"0");
		System.out.println("str=="+str);
		//String amount=getFormattedAmount("2.345",3);
		//System.out.println("amount=="+amount);
		//String inputString="1234567890123456789012345678901234567890123456789012345678901234567";
		//System.out.println(inputString.length());
		//String s="BUPA INSURANCE\r\n  SERVICES LIMITED BUP\r\nA INTERNATIONAL RUSSELL HOUSE R USS\r\nC DDTERNATIONAL RUSSELL HOUSE R USS\r\n";
		//System.out.println(wrap(s,35,"\r\n",true,"",4));
		
	//	int index=inputString.indexOf("\r\n");
	//	System.out.println("Index="+index);
		
	//	if(inputString.contains("\r\n")){
	//		System.out.println("Yes");
	//	}
		
	//	if(inputString.length()>33*2){
	//			System.out.println(inputString.length()+ "This length not allowed");
	//	}
		//String validationError =validateBenDataBeforeFormating(inputString,"test");
		//String str=getFormattedAmount("300",2);
		//System.out.println(str);
		System.out.println("---------------Validation Message--------------------------------");
	
	//	System.out.println("---------------InputString--------------------------------");
	//	System.out.println(inputString);
	//	System.out.println("---------------outputString--------------------------------");
	//	System.out.println(formatedString);
	//	System.out.println("----------------------------------------------------------");
	//	System.out.println("Input string length		="+inputString.length());
	//	System.out.println("formated string length	="+formatedString.length());
	}
	
	public static String getFormattedAmount(String amount,int decimalPlaces)
	{
		String formatAmount = "";
			if(amount == null){
				return "0.000";
			}
		try
		{
			DecimalFormat dft =new DecimalFormat("0.00");
			if(decimalPlaces == 3)
			formatAmount = dft.format(Double.parseDouble(amount)/1000);
			else
			formatAmount = dft.format(Double.parseDouble(amount));	
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return formatAmount;
	
	}


}
