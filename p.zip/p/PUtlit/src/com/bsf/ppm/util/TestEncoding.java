package com.bsf.ppm.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestEncoding {

	
	public static void main(String[] args) {
		
		Connection connection = null;
		try {
		    // Load the JDBC driver
		    String driverName = "oracle.jdbc.driver.OracleDriver";
		    Class.forName(driverName);
	
		    OutputStreamWriter osw = null;
		    try {
		    File f=new File("d:\\encoding.txt");
		    FileWriter fw = null;
		    OutputStream os = new FileOutputStream(f);
		    osw = new OutputStreamWriter(os,"cp1256");
		   
				 
				
				
			
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    // Create a connection to the database
		    String serverName = "bsfrhl64.bsf.com";
		    String portNumber = "1521";
		    String sid = "bsfdev";
		    String url = "jdbc:oracle:thin:@" + serverName + ":" + portNumber + ":" + sid;
		    String username = "IPPAPPUSER";
		    String password = "ippapp#2009";
		    connection = DriverManager.getConnection(url, username, password);
		    String sql="select compliance_matching_name from itms_payment_transaction where id=67527";
		    Statement stmt=connection.createStatement();
		    ResultSet rs = stmt.executeQuery(sql);
		    
		    while(rs.next()){
		    	
		    	String temp=rs.getString(1);
		    	System.out.println(StringUtils.toHex("MOHAMMAD ABDULLAH"));
		    	try {
					osw.write(temp);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    	
		    }
		    if(osw !=null)
				try {
					osw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		} catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		} catch (SQLException e) {
		    e.printStackTrace();
		}
	}
}
