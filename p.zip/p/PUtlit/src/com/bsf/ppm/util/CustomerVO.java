package com.bsf.ppm.util;

import java.util.Date;


/**
 * @author mmahaboob
 *
 */
public class CustomerVO {

	private String referenceNumber;
	
	private String application;
	
	/**
	 * Attribute messageId.
	 */
	private Long messageId;	
	/**
	 * Attribute messageType.
	 */
	private String messageType;

	/**
	 * Attribute timeIndication.
	 */
	private String timeIndication;

	/**
	 * Attribute bankOperationCode.
	 */
	private String bankOperationCode;

	/**
	 * Attribute institutionCode.
	 */
	private String instructionCode;

	/**
	 * Attribute valueDate.
	 */
	private Date valueDate;

	/**
	 * Attribute currency.
	 */
	private String currency;

	/**
	 * Attribute settledAmount.
	 */
	private Double settledAmount;
	
	/**
	 * Attribute senderCorrespondent.
	 */
	private String senderCorrespondent;

	/**
	 * Attribute senderCorrespondentType.
	 */
	private String senderCorrespondentType;

	/**
	 * Attribute receiverCorrespondent.
	 */
	private String receiverCorrespondent;

	/**
	 * Attribute receiverCorrespondentType.
	 */
	private String receiverCorrespondentType;

	/**
	 * Attribute thirdInstitution.
	 */
	private String thirdInstitution;

	/**
	 * Attribute thirdInstitutionType.
	 */
	private String thirdInstitutionType;

	/**
	 * Attribute intermediaryInstitution.
	 */
	private String intermediaryInstitution;

	/**
	 * Attribute intermediaryInstitutionType.
	 */
	private String intermediaryInstitutionType;

	/**
	 * Attribute sumReceiverCharges.
	 */
	private String sumReceiverCharges;

	/**
	 * Attribute senderReceiverInformation.
	 */
	private String senderReceiverInformation;

	/**
	 * Attribute envelopContents.
	 */
	private String envelopContents;
	
	/**
	 * Attribute formatType.
	 */
	private String formatType;

	/**
	 * Attribute receiverBankCode.
	 */
	private String receiverBankCode;	

	/**
	 * Attribute transactionTypeCode.
	 */
	private String transactionTypeCode;	

	/**
	 * Attribute instructedCurrency.
	 */
	private String instructedCurrency;

	/**
	 * Attribute instructedAmount.
	 */
	private Double instructedAmount;

	/**
	 * Attribute exchangeRate.
	 */
	private Double exchangeRate;

	/**
	 * Attribute orderingCustomer.
	 */
	private String orderingCustomer;

	/**
	 * Attribute orderingCustomerType.
	 */
	private String orderingCustomerType;

	/**
	 * Attribute orderingInstitution.
	 */
	private String orderingInstitution;

	/**
	 * Attribute orderingInstitutionType.
	 */
	private String orderingInstitutionType;

	/**
	 * Attribute accountwithInstitution.
	 */
	private String accountwithInstitution;

	/**
	 * Attribute accountwithInstitutionType.
	 */
	private String accountwithInstitutionType;

	/**
	 * Attribute beneficiaryCustomer.
	 */
	private String beneficiaryCustomer;

	/**
	 * Attribute beneficiaryCustomerType.
	 */
	private String beneficiaryCustomerType;

	/**
	 * Attribute chargeDetails.
	 */
	private String chargeDetails;

	/**
	 * Attribute senderCharges.
	 */
	private String senderCharges;

	/**
	 * Attribute receiverCharges.
	 */
	private Double receiverCharges;
	
	/**
	 * Attribute transactionDetails.
	 */
	private String transactionDetails;
	
	/**
	 * Attribute regulatoryReporting.
	 */
	private String regulatoryReporting;	
	

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getTimeIndication() {
		return timeIndication;
	}

	public void setTimeIndication(String timeIndication) {
		this.timeIndication = timeIndication;
	}

	public String getBankOperationCode() {
		return bankOperationCode;
	}

	public void setBankOperationCode(String bankOperationCode) {
		this.bankOperationCode = bankOperationCode;
	}

	public String getInstructionCode() {
		return instructionCode;
	}

	public void setInstructionCode(String instructionCode) {
		this.instructionCode = instructionCode;
	}

	public Date getValueDate() {
		return valueDate;
	}

	public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Double getSettledAmount() {
		return settledAmount;
	}

	public void setSettledAmount(Double settledAmount) {
		this.settledAmount = settledAmount;
	}

	public String getSenderCorrespondent() {
		return senderCorrespondent;
	}

	public void setSenderCorrespondent(String senderCorrespondent) {
		this.senderCorrespondent = senderCorrespondent;
	}

	public String getSenderCorrespondentType() {
		return senderCorrespondentType;
	}

	public void setSenderCorrespondentType(String senderCorrespondentType) {
		this.senderCorrespondentType = senderCorrespondentType;
	}

	public String getReceiverCorrespondent() {
		return receiverCorrespondent;
	}

	public void setReceiverCorrespondent(String receiverCorrespondent) {
		this.receiverCorrespondent = receiverCorrespondent;
	}

	public String getReceiverCorrespondentType() {
		return receiverCorrespondentType;
	}

	public void setReceiverCorrespondentType(String receiverCorrespondentType) {
		this.receiverCorrespondentType = receiverCorrespondentType;
	}

	public String getThirdInstitution() {
		return thirdInstitution;
	}

	public void setThirdInstitution(String thirdInstitution) {
		this.thirdInstitution = thirdInstitution;
	}

	public String getThirdInstitutionType() {
		return thirdInstitutionType;
	}

	public void setThirdInstitutionType(String thirdInstitutionType) {
		this.thirdInstitutionType = thirdInstitutionType;
	}

	public String getIntermediaryInstitution() {
		return intermediaryInstitution;
	}

	public void setIntermediaryInstitution(String intermediaryInstitution) {
		this.intermediaryInstitution = intermediaryInstitution;
	}

	public String getIntermediaryInstitutionType() {
		return intermediaryInstitutionType;
	}

	public void setIntermediaryInstitutionType(String intermediaryInstitutionType) {
		this.intermediaryInstitutionType = intermediaryInstitutionType;
	}

	public String getSumReceiverCharges() {
		return sumReceiverCharges;
	}

	public void setSumReceiverCharges(String sumReceiverCharges) {
		this.sumReceiverCharges = sumReceiverCharges;
	}

	public String getSenderReceiverInformation() {
		return senderReceiverInformation;
	}

	public void setSenderReceiverInformation(String senderReceiverInformation) {
		this.senderReceiverInformation = senderReceiverInformation;
	}

	public String getEnvelopContents() {
		return envelopContents;
	}

	public void setEnvelopContents(String envelopContents) {
		this.envelopContents = envelopContents;
	}

	public String getFormatType() {
		return formatType;
	}

	public void setFormatType(String formatType) {
		this.formatType = formatType;
	}

	public String getReceiverBankCode() {
		return receiverBankCode;
	}

	public void setReceiverBankCode(String receiverBankCode) {
		this.receiverBankCode = receiverBankCode;
	}

	public String getTransactionTypeCode() {
		return transactionTypeCode;
	}

	public void setTransactionTypeCode(String transactionTypeCode) {
		this.transactionTypeCode = transactionTypeCode;
	}
	
	public String getInstructedCurrency() {
		return instructedCurrency;
	}

	public void setInstructedCurrency(String instructedCurrency) {
		this.instructedCurrency = instructedCurrency;
	}

	public Double getInstructedAmount() {
		return instructedAmount;
	}

	public void setInstructedAmount(Double instructedAmount) {
		this.instructedAmount = instructedAmount;
	}

	public Double getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(Double exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getOrderingCustomer() {
		return orderingCustomer;
	}

	public void setOrderingCustomer(String orderingCustomer) {
		this.orderingCustomer = orderingCustomer;
	}

	public String getOrderingCustomerType() {
		return orderingCustomerType;
	}

	public void setOrderingCustomerType(String orderingCustomerType) {
		this.orderingCustomerType = orderingCustomerType;
	}

	public String getOrderingInstitution() {
		return orderingInstitution;
	}

	public void setOrderingInstitution(String orderingInstitution) {
		this.orderingInstitution = orderingInstitution;
	}

	public String getOrderingInstitutionType() {
		return orderingInstitutionType;
	}

	public void setOrderingInstitutionType(String orderingInstitutionType) {
		this.orderingInstitutionType = orderingInstitutionType;
	}

	public String getAccountwithInstitution() {
		return accountwithInstitution;
	}

	public void setAccountwithInstitution(String accountwithInstitution) {
		this.accountwithInstitution = accountwithInstitution;
	}

	public String getAccountwithInstitutionType() {
		return accountwithInstitutionType;
	}

	public void setAccountwithInstitutionType(String accountwithInstitutionType) {
		this.accountwithInstitutionType = accountwithInstitutionType;
	}

	public String getBeneficiaryCustomer() {
		return beneficiaryCustomer;
	}

	public void setBeneficiaryCustomer(String beneficiaryCustomer) {
		this.beneficiaryCustomer = beneficiaryCustomer;
	}

	public String getBeneficiaryCustomerType() {
		return beneficiaryCustomerType;
	}

	public void setBeneficiaryCustomerType(String beneficiaryCustomerType) {
		this.beneficiaryCustomerType = beneficiaryCustomerType;
	}
	
	public String getChargeDetails() {
		return chargeDetails;
	}

	public void setChargeDetails(String chargeDetails) {
		this.chargeDetails = chargeDetails;
	}

	public String getSenderCharges() {
		return senderCharges;
	}

	public void setSenderCharges(String senderCharges) {
		this.senderCharges = senderCharges;
	}

	public Double getReceiverCharges() {
		return receiverCharges;
	}

	public void setReceiverCharges(Double receiverCharges) {
		this.receiverCharges = receiverCharges;
	}

	public String getRegulatoryReporting() {
		return regulatoryReporting;
	}

	public void setRegulatoryReporting(String regulatoryReporting) {
		this.regulatoryReporting = regulatoryReporting;
	}

	public String getTransactionDetails() {
		return transactionDetails;
	}

	public void setTransactionDetails(String transactionDetails) {
		this.transactionDetails = transactionDetails;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}		
}
