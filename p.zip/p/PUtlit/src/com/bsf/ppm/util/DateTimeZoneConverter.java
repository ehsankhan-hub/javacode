package com.bsf.ppm.util;

import java.util.TimeZone;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.DateTimeConverter;

public class DateTimeZoneConverter extends DateTimeConverter {
	 
    public DateTimeZoneConverter() {
        super();
        this.setTimeZone(TimeZone.getTimeZone("GMT+3"));
        // handle the format here set in the attribute
        this.setPattern("yyMMdd");
    }
 
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        //Date date = null;
        // formats to handle
        return super.getAsObject(context, component, value);
    }
 
    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        /*
    	String dateStr = null;
    	if( value != null) {
    		Date d=  (Date)value;
    		SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMdd");
    		dateStr = dateFormat.format(d);
    	}
    	//handle the html output        
        return dateStr;
        */
    	return super.getAsString(context, component, value);
    }
}
