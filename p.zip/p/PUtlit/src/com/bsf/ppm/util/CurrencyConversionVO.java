package com.bsf.ppm.util;

import java.util.Date;

public class CurrencyConversionVO {

	private boolean limitSpecified;
	private boolean convertCurrency;
	private boolean exchangeRateSpecified;
	private double buyExchangeRate;
	private double sellExchangeRate;
	private double creditAmount;
	private double ceilingAmount;
	private Date asOfDate;	
	private boolean isAsOfDateTodayDate;
	private double units;
		
	public boolean isAsOfDateTodayDate() {
		return isAsOfDateTodayDate;
	}
	public void setAsOfDateTodayDate(boolean isAsOfDateTodayDate) {
		this.isAsOfDateTodayDate = isAsOfDateTodayDate;
	}
	public Date getAsOfDate() {
		return asOfDate;
	}
	public void setAsOfDate(Date asOfDate) {
		this.asOfDate = asOfDate;
	}
	public double getCeilingAmount() {
		return ceilingAmount;
	}
	public void setCeilingAmount(double ceilingAmount) {
		this.ceilingAmount = ceilingAmount;
	}
	public boolean isLimitSpecified() {
		return limitSpecified;
	}
	public void setLimitSpecified(boolean limitSpecified) {
		this.limitSpecified = limitSpecified;
	}
	public boolean isConvertCurrency() {
		return convertCurrency;
	}
	public void setConvertCurrency(boolean convertCurrency) {
		this.convertCurrency = convertCurrency;
	}
	public double getBuyExchangeRate() {
		return buyExchangeRate;
	}
	public void setBuyExchangeRate(double exchangeRate) {
		this.buyExchangeRate = exchangeRate;
	}
	
	public double getSellExchangeRate() {
		return sellExchangeRate;
	}
	public void setSellExchangeRate(double exchangeRate) {
		this.sellExchangeRate = exchangeRate;
	}
	public double getCreditAmount() {
		return creditAmount;
	}
	public void setCreditAmount(double creditAmount) {
		this.creditAmount = creditAmount;
	}
	public boolean isExchangeRateSpecified() {
		return exchangeRateSpecified;
	}
	public void setExchangeRateSpecified(boolean exchangeRateSpecified) {
		this.exchangeRateSpecified = exchangeRateSpecified;
	}
	/**
	 * @return the units
	 */
	public double getUnits() {
		return units;
	}
	/**
	 * @param units the units to set
	 */
	public void setUnits(double units) {
		this.units = units;
	}	
	
	
}
