package com.bsf.ppm.util;

public class AccountVO {

	private String accountNumber;
	private String accountType;
	private String bic;
	private String correspondentBic;	
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getBic() {
		return bic;
	}
	public void setBic(String bic) {
		this.bic = bic;
	}
	public String getCorrespondentBic() {
		return correspondentBic;
	}
	public void setCorrespondentBic(String correspondentBic) {
		this.correspondentBic = correspondentBic;
	}	
}
