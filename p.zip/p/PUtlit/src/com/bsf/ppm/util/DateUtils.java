package com.bsf.ppm.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


/**
 * Utility Class for Date Functions.
 * @author Hussain
 *
 */
public class DateUtils {

	/**
	 * 
	 * @param fromDate
	 * @param toDate
	 * @return long date difference in days
	 * Method to compute difference between two dates
	 */
	public static long computeDateDifference(Date fromDate, Date toDate) {

		// Get msec from each, and subtract.
		long diff = toDate.getTime() - fromDate.getTime();
		return diff / (1000 * 60 * 60 * 24);

	}

	public static int compareTruncatedDates(Date d1, Date d2) {
		Calendar c1 = Calendar.getInstance();
		c1.setTime(d1);
		c1 = org.apache.commons.lang.time.DateUtils.truncate(c1, Calendar.DAY_OF_MONTH);

		Calendar c2 = Calendar.getInstance();
		c2.setTime(d2);
		c2 = org.apache.commons.lang.time.DateUtils.truncate(c2, Calendar.DAY_OF_MONTH);

		return c1.compareTo(c2);
	}

	public static boolean isDaysAfter(Date d1, Date d2)
	{
		return compareTruncatedDates(d1, d2) > 0;
	}

	public static boolean isDaysBefore(Date d1, Date d2)
	{
		return compareTruncatedDates(d1, d2) < 0;
	}

	public static boolean isSameDay(Date d1, Date d2)
	{
		return compareTruncatedDates(d1, d2) == 0;
	}

	public static boolean isToday(Date d)
	{
		return isSameDay(d, Calendar.getInstance().getTime());
	}

	public static boolean isFutureDay(Date d)
	{
		return isDaysAfter(d, Calendar.getInstance().getTime());
	}

	public static Date getDateFromTimeString(Date day, String time)
	{
		String[] parts = null;
		if(time !=null)
			parts=time.split(":");
		if(parts != null && parts.length ==2)
		{
			Calendar c = Calendar.getInstance();
			c.setTime(day);
			c = org.apache.commons.lang.time.DateUtils.truncate(c, Calendar.DAY_OF_MONTH);
			c.add(Calendar.HOUR_OF_DAY, Integer.parseInt(parts[0]));
			c.add(Calendar.MINUTE, Integer.parseInt(parts[1]));

			return c.getTime();
		}

		return null;
	}

	public static java.util.Date timeStampToDate(java.sql.Timestamp timestamp) {
		long milliseconds = timestamp.getTime() + (timestamp.getNanos() / 1000000);
		return new java.util.Date(milliseconds);
	}

	public static void main(String[] args) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -30);
		Date d1 = new java.util.Date();
		Date d2 = calendar.getTime();
		System.out.println(d1);
		System.out.println(d2);
		System.out.println(compareTruncatedDates(d1, d2));
        System.out.println(getTodayDateAsString("yymmdd"));
		System.out.println("12:30 --> " + getDateFromTimeString(d1, "12:30"));
		System.out.println(computeDateDifference(d1,d2));
	}

	
	/**
	 * @param format
	 * @return
	 */
	public static String getTodayDateAsString(String format){
		SimpleDateFormat sdf=new SimpleDateFormat(format);
		return sdf.format(new Date(System.currentTimeMillis()));
	}


}
