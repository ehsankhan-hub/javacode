package com.bsf.ppm.util;

public class ReturnPaymentDO {

	private String currency;
	private Double amount;
	private Double sarAmount;
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Double getSarAmount() {
		return sarAmount;
	}
	public void setSarAmount(Double sarAmount) {
		this.sarAmount = sarAmount;
	}
}
