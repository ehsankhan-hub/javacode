package com.bsf.ppm.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SequenceGenerator {
	
	public void generate() {
		List<String> tablesList = new ArrayList<String>();

		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con  = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@10.10.38.22:1521:ipp","ippuser","is1234");
			String[] tableTypes = {"TABLE"};
			DatabaseMetaData dbMd = con.getMetaData();
			//dbMd.getTables(null, null, null, tableTypes);
			
			ResultSet rs = dbMd.getTables("", "IPPUSER", null, tableTypes);
			while (rs.next()) {
				tablesList.add(rs.getString("TABLE_NAME"));
			}
			
			writeToFile(tablesList);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	public void writeToFile(List<String> tablesList){

			File file = new File("C://BSF//IPP//Documents//Design//create_sequences.sql");
			try {
				file.createNewFile();
				FileWriter fw = new FileWriter(file);
				
				for (String tableName : tablesList) {
					
					if (!tableName.startsWith("JBPM") && !tableName.startsWith("BIN$")
							&& !tableName.startsWith("PLSQL") && !tableName.startsWith("SQL")){
						fw.write(getSequenceSql(tableName));
					}
					
				}
				//Class Closure
				fw.close();				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

			
	}
	private String getSequenceSql(String tableName) {
		StringBuilder sb = new StringBuilder();
		if (tableName.length()>24)  tableName= tableName.substring(0, 24);
		sb.append("drop sequence "+tableName+"_SEQ")
			.append("\n")
			.append("/")
			.append("\n")
			.append("create sequence "+tableName+"_SEQ")
			.append("\n")
			.append("start with 1")
			.append("\n")
			.append("increment by 1")
			.append("\n")
			.append("minvalue 1")
			.append("\n")
			.append("/")
			.append("\n")
			.append("\n");		
		return sb.toString();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SequenceGenerator sg = new SequenceGenerator();
		sg.generate();		
	}

}
