package com.bsf.ppm.util;

import java.util.Date;

public class DateVO {

	private Date valueDate;
	private boolean dateRuleSpecified;
	private boolean correctCutOffTime;	
		
	public boolean isCorrectCutOffTime() {
		return correctCutOffTime;
	}
	public void setCorrectCutOffTime(boolean correctCutOffTime) {
		this.correctCutOffTime = correctCutOffTime;
	}
	public Date getValueDate() {
		return valueDate;
	}
	public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}
	public boolean isDateRuleSpecified() {
		return dateRuleSpecified;
	}
	public void setDateRuleSpecified(boolean dateRuleSpecified) {
		this.dateRuleSpecified = dateRuleSpecified;
	}
	
}
