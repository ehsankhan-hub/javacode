package com.bsf.ppm.util;

import org.apache.log4j.Logger;


public class LogUtil {

	/*protected static final Logger ispaHistoryLog = Logger.getLogger("com.bsf.ipp.ispa.history");
	protected static final Logger ispaMsgChangeLog = Logger.getLogger("com.bsf.ipp.ispa.msgChange");
	
	protected static final Logger itmsHistoryLog = Logger.getLogger("com.bsf.ipp.itms.history");
	protected static final Logger itmsMsgChangeLog = Logger.getLogger("com.bsf.ipp.itms.msgChange");
	
	protected static final Logger otmsHistoryLog = Logger.getLogger("com.bsf.ipp.otms.history");
	protected static final Logger otmsMsgChangeLog = Logger.getLogger("com.bsf.ipp.otms.msgChange");*/
	
	protected static final Logger outwardCreditLog = Logger.getLogger("com.bsf.cclg.outwardCredit");
	protected static final Logger clgHistoryLog = Logger.getLogger("com.bsf.cclg.history");
	protected static final Logger clgMsgChangeLog = Logger.getLogger("com.bsf.cclg.msgChange");
	
	//CCLN 
	protected static final Logger clnHistoryLog = Logger.getLogger("com.bsf.ccln.inward.history");
	
}
