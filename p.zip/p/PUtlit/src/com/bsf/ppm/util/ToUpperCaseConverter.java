package com.bsf.ppm.util;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

public class ToUpperCaseConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext context, UIComponent comp, String value) {
		return (value != null) ? value.toUpperCase() : null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent comp, Object value) {
		return (value != null) ? value.toString().toUpperCase() : null;
	}

}
