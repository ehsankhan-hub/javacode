package com.bsf.ppm.auditing.interceptor;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.hibernate.EmptyInterceptor;
import org.hibernate.Transaction;
import org.hibernate.type.Type;

import com.bsf.ppm.auditing.AuditingException;
import com.bsf.ppm.auditing.IAuditLogger;
import com.bsf.ppm.auditing.model.Auditable;
import com.bsf.ppm.spring.SpringAppContext;

/**
 * Audit interceptor for entities
 * 
 * @author Rakesh
 */
public class EntityAuditLogInterceptor extends EmptyInterceptor {

	private static Logger log = Logger.getLogger(EntityAuditLogInterceptor.class);
	private IAuditLogger auditLogger;

	public boolean onSave(Object entity, Serializable id, Object[] state,
			String[] propertyNames, Type[] types) {
		if (entity instanceof Auditable) {
			getAuditLogger().addEntityAuditRecord((Auditable) entity,
					"save_entity");
		} else {
			getAuditLogger().removeCurrentServiceAuditRecord();

		}
		return false;
	}

	public void onDelete(Object entity, Serializable id, Object[] state,
			String[] propertyNames, Type[] types) {
		if (entity instanceof Auditable) {
			getAuditLogger().addEntityAuditRecord((Auditable) entity,
					"delete_entity");
		} else {
			getAuditLogger().removeCurrentServiceAuditRecord();

		}
	}

	public boolean onFlushDirty(Object entity, Serializable id,
			Object[] currentState, Object[] previousState,
			String[] propertyNames, Type[] types) {
		if (entity instanceof Auditable) {
			getAuditLogger().addEntityAuditRecord((Auditable) entity,
					"update_entity");
		} else {
			getAuditLogger().removeCurrentServiceAuditRecord();

		}
		return false;
	}

	/**
	 * @return Returns the auditLogger.
	 */
	public IAuditLogger getAuditLogger() {
		if (auditLogger == null) {
			auditLogger = (IAuditLogger) SpringAppContext
					.getBean("auditLogger");
		}
		return auditLogger;
	}

	public void setAuditLogger(IAuditLogger auditLogger) {
		this.auditLogger = auditLogger;
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see org.hibernate.EmptyInterceptor#afterTransactionCompletion(org.hibernate.Transaction)
	 */
	@Override
	public void afterTransactionCompletion(Transaction tx) {
		if (getAuditLogger() != null) {
			try {
				if (getAuditLogger().getCurrentServiceAuditRecord() != null) {
					getAuditLogger().saveCurrentServiceAuditRecord();

				}

			} catch (AuditingException e) {
				log.warn("EntityAuditLogInterceptor:afterTransactionCompletion:exception>"+e.getMessage());
			}
			getAuditLogger().removeCurrentServiceAuditRecord();
		}
	}
}
