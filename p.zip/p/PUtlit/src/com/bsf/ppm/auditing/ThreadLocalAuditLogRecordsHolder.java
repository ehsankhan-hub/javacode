
package com.bsf.ppm.auditing;

import java.util.Stack;

import com.bsf.ipp.AuditRecord;


public class ThreadLocalAuditLogRecordsHolder implements IAuditLogRecordsHolder {
	
	private static ThreadLocal serviceAuditRecordsStackHolder	= new ThreadLocal();
		
	public void addServiceAuditRecordToStack(AuditRecord auditRecord) {
		getServiceAuditRecordsStack().push(auditRecord);
	}
	
	public void removeCurrentServiceAuditRecordFromStack() {
		if(!getServiceAuditRecordsStack().empty())
			getServiceAuditRecordsStack().pop();
	}
	
	public AuditRecord getCurrentActiveServiceRecord() {
		if(!getServiceAuditRecordsStack().empty())
			return (AuditRecord)getServiceAuditRecordsStack().peek();
		else
			return null;
	}
	
	private Stack getServiceAuditRecordsStack() {
		if(serviceAuditRecordsStackHolder.get() == null) {
			serviceAuditRecordsStackHolder.set(new Stack());
		}
		return (Stack)serviceAuditRecordsStackHolder.get();
	}
	
}
