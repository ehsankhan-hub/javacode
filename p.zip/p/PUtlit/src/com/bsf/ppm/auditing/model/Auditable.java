package com.bsf.ppm.auditing.model;

import java.io.Serializable;


/**
 * @author Rakesh
 * Interface for auditable entities
 */
public interface Auditable extends Serializable{
	/**
	 * Gets the key for entity
	 * @return Primary Key Primary Key for the entity. 
	 */
	public String getPk();
	
	/**
	 * Gets audit message for entity
	 * @return Audit Message
	 */
	public String getAuditMessage();
}
