package com.bsf.ppm.auditing;

import com.bsf.ipp.AuditRecord;

/**
 * 
 * @author Rakesh
 *
 */
public interface IAuditLogRecordsHolder {
	public void addServiceAuditRecordToStack(AuditRecord auditRecord);
	public void removeCurrentServiceAuditRecordFromStack();
	public AuditRecord getCurrentActiveServiceRecord();
}