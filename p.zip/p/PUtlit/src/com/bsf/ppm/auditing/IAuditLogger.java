
package com.bsf.ppm.auditing;

import com.bsf.ipp.AuditRecord;
import com.bsf.ppm.auditing.model.Auditable;


/**
 * Interface for audit service
 * @author Rakesh
 */
public interface IAuditLogger {
	public void beginServiceLevelAuditing(String message, String auditLogType, int txPropagationBehavior, String serviceKey);
	public void addEntityAuditRecord(Auditable auditable, String auditLogType);
	public AuditRecord saveCurrentServiceAuditRecord() throws AuditingException;
	public AuditRecord removeCurrentServiceAuditRecord();
	public AuditRecord getCurrentServiceAuditRecord() throws AuditingException ;

}
