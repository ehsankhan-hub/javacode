
package com.bsf.ppm.auditing;

import java.sql.Timestamp;
import java.util.Calendar;

import org.springframework.security.context.SecurityContextHolder;
import org.springframework.transaction.interceptor.TransactionAttribute;

import com.bsf.ipp.AuditRecord;
import com.bsf.ipp.dao.AuditRecordDAO;
import com.bsf.ppm.auditing.model.Auditable;

/**
 * Main class for audit logging.
 * @author Rakesh
 */
public class AuditLogger implements IAuditLogger{
	
	private IAuditLogRecordsHolder auditLogRecordsHolder;
	private AuditRecordDAO auditRecordDAO;
	
	
	public void beginServiceLevelAuditing(String message, String logType, int txPropagationBehavior, String serviceKey) {
		if(checkIfNewServiceAuditRecordRequired(txPropagationBehavior)) {
			//only create a new service auditing record when a new tx starts or
			//if there is no previously created service auditing record...
			AuditRecord auditRecord = createServiceAuditRecord(message, serviceKey, logType);
			getAuditLogRecordsHolder().addServiceAuditRecordToStack(auditRecord);
		}
    }
	
	public boolean checkIfNewServiceAuditRecordRequired(int txPropagationBehavior) {
		boolean newTxRequired = txPropagationBehavior == TransactionAttribute.PROPAGATION_REQUIRES_NEW ;
		boolean currentAuditRecordNull = getAuditLogRecordsHolder().getCurrentActiveServiceRecord() == null;
		return (newTxRequired || currentAuditRecordNull);
	}

    public void addEntityAuditRecord(Auditable auditable, String logType) {
        if(getAuditLogRecordsHolder().getCurrentActiveServiceRecord() != null) {
            AuditRecord auditRecord = createEntityAuditRecord(auditable,logType);
            AuditRecord currentAuditRecord = getAuditLogRecordsHolder().getCurrentActiveServiceRecord();
            auditRecord.setAuditRecord(currentAuditRecord);       
            currentAuditRecord.getAuditRecords().add(auditRecord);          	
        }
    }
    
	public AuditRecord saveCurrentServiceAuditRecord() throws AuditingException {	
		AuditRecord auditRecord = getAuditLogRecordsHolder().getCurrentActiveServiceRecord();
		getAuditLogRecordsHolder().removeCurrentServiceAuditRecordFromStack();
		try {

			if (auditRecord!=null) {
				auditRecordDAO.save(auditRecord);
			}
			return auditRecord;
		} catch(Exception ex) {
			throw new AuditingException("error.audit.saveRecord",ex, new Object[]{auditRecord.getOperationKey()});
		}
	}
	
	public AuditRecord removeCurrentServiceAuditRecord() {
		AuditRecord auditRecord = getAuditLogRecordsHolder().getCurrentActiveServiceRecord();
		getAuditLogRecordsHolder().removeCurrentServiceAuditRecordFromStack();
		return auditRecord;
	}
    
    private AuditRecord createServiceAuditRecord(String message, String serviceKey, String type) {
    	AuditRecord auditRecord = new AuditRecord();
    	auditRecord.setMessage(message);
    	auditRecord.setOperationType(type);
    	auditRecord.setOperationKey(serviceKey);
    	auditRecord.setUserId(getUserName());
    	auditRecord.setOperationDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
    	return auditRecord;
    }
    
    private AuditRecord createEntityAuditRecord(Auditable auditable, String type) {
    	AuditRecord auditRecord = new AuditRecord();
    	auditRecord.setOperationType(type);
    	//auditRecord.setOperationKey(auditable.getClass().getName()+ ":" + (auditable).getPk());
    	auditRecord.setOperationKey(auditable.getClass().getSimpleName());
    	auditRecord.setUserId(getUserName());
    	auditRecord.setOperationDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
    	auditRecord.setMessage(auditable.toString());
    	return auditRecord;
    }

	public IAuditLogRecordsHolder getAuditLogRecordsHolder() {
		return auditLogRecordsHolder;
	}

	public void setAuditLogRecordsHolder(
			IAuditLogRecordsHolder auditLogRecordsHolder) {
		this.auditLogRecordsHolder = auditLogRecordsHolder;
	}
	
	
	/**
	 * @return the auditRecordDAO
	 */
	public AuditRecordDAO getAuditRecordDAO() {
		return auditRecordDAO;
	}

	/**
	 * @param auditRecordDAO the auditRecordDAO to set
	 */
	public void setAuditRecordDAO(AuditRecordDAO auditRecordDAO) {
		this.auditRecordDAO = auditRecordDAO;
	}

	private String getUserName()	{
		
		String userName = null;
		if(SecurityContextHolder.getContext().getAuthentication() != null)	{
			userName = SecurityContextHolder.getContext().getAuthentication().getName();
		}else	{
			userName = "system";
		}
		return userName;
		
	}
	public AuditRecord getCurrentServiceAuditRecord() throws AuditingException {	
		return getAuditLogRecordsHolder().getCurrentActiveServiceRecord();

	}
}
