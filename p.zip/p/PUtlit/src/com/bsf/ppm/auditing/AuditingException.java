package com.bsf.ppm.auditing;

import com.bsf.ppm.exceptions.InfrastructureException;

public class AuditingException extends InfrastructureException {

	public AuditingException(String message, Exception x, Object[] params) {
		super(message, x, params);
	}
}
