package com.bsf.ppm.aspects;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

/**
 * 
 * Advice class for logging performance details for any class or method
 * @author Rakesh
 * 
 */
@Aspect
public class PerformanceLoggingAdvice {
	
	/** Time in milliseconds */
	long startTime = 0;

	/** Time in milliseconds */
	long finishTime = 0;

	protected static final Logger log = Logger
			.getLogger(PerformanceLoggingAdvice.class);

	@Pointcut("execution(* *save(..))")
	public void performanceTracer() {}
	
	@Before("performanceTracer()")
	public void logBefore(JoinPoint joinPoint)
			throws Throwable {
		startTime = System.currentTimeMillis();
		if (log.isDebugEnabled()) {
			log.debug("Executing method " + joinPoint.getSignature().getName() + " on object "
					+ joinPoint.getTarget().getClass().getName());
		}
	}

	@AfterReturning("performanceTracer()")
	public void logAfter(JoinPoint joinPoint) throws Throwable {
		finishTime = System.currentTimeMillis();
		double totalDuration = finishTime - startTime;
		if (log.isDebugEnabled()) {
			log.debug("Finished executing method " + joinPoint.getSignature().getName()
					+ " on object " + joinPoint.getTarget().getClass().getName() + " in "
					+ totalDuration / 1000 + " seconds.");
		}
	}

}
