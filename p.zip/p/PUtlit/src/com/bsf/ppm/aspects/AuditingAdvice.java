package com.bsf.ppm.aspects;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.transaction.interceptor.TransactionAttribute;
import org.springframework.transaction.interceptor.TransactionAttributeSource;
import org.springframework.transaction.interceptor.TransactionInterceptor;

import com.bsf.ppm.annotations.AuditLogType;
import com.bsf.ppm.auditing.IAuditLogger;



public class AuditingAdvice {
	protected final static Log logger = LogFactory
			.getLog(AuditingAdvice.class);

	/**
*/
	private TransactionInterceptor transactionInterceptor;
	private IAuditLogger auditLogger;

	public void setTransactionInterceptor(
			TransactionInterceptor transactionInterceptor) {
		this.transactionInterceptor = transactionInterceptor;
	}

	@Pointcut("execution(* com.bsf.ipp.dao..*.*(..))")
	public void daoAuditor() {
	}

	@Pointcut("execution(* com.bsf.ipp.service..*.*(..))")
	public void serviceAuditor() {
	}

	@Around("daoAuditor() || serviceAuditor()")
	public Object audit(ProceedingJoinPoint joinPoint) throws Throwable {
		org.aspectj.lang.Signature sig = joinPoint.getSignature();
		Method method = ((MethodSignature) sig).getMethod();
		TransactionAttribute transactionAttribute = identifyTransactionAttribute(method);
		beginAuditing(method, transactionAttribute);
		return joinPoint.proceed();

	}
	
	private TransactionAttribute identifyTransactionAttribute(
			Method method) {
		Class targetClass = method.getDeclaringClass();
		TransactionAttributeSource transactionAttributeSource = transactionInterceptor
				.getTransactionAttributeSource();
		TransactionAttribute transactionAttribute = transactionAttributeSource
				.getTransactionAttribute(method,
						targetClass);
		return transactionAttribute;
	}

	private void beginAuditing(Method method,
			TransactionAttribute transactionAttribute) {
		AuditLogType annotation = method.getAnnotation(AuditLogType.class);
		if (annotation != null) {
			String auditLogType = annotation.value();
			String auditMessage = annotation.message();
			if (auditLogType != null && transactionAttribute != null) {
				String serviceKey = method.getDeclaringClass().getName() + "."
						+ method.getName();
				getAuditLogger().beginServiceLevelAuditing(auditMessage,
						auditLogType,
						transactionAttribute.getPropagationBehavior(),
						serviceKey);
			}
		}
	}

	/**
	 * @return Returns the auditLogger.
	 */
	public IAuditLogger getAuditLogger() {
		return auditLogger;
	}

	/**
	 * @param auditLogger
	 *            The auditLogger to set.
	 */
	public void setAuditLogger(IAuditLogger auditLogger) {
		this.auditLogger = auditLogger;
	}
}
