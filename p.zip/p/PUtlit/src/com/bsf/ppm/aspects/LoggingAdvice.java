package com.bsf.ppm.aspects;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

import com.bsf.ppm.exceptions.UnrecoverableException;

/**
 * Logging aspect for method level logging. Order specifies that in what order
 * the advice will be applied.
 * 
 * @author Rakesh
 * 
 */
@Aspect
public class LoggingAdvice {

	private static final Logger log = Logger.getLogger(LoggingAdvice.class);

	@Pointcut("execution(* com.bsf.ppm.dao..*.*(..))")
	public void daoTracer() {
	}

	@Pointcut("execution(* com.bsf.ppm.service..*.*(..))")
	public void serviceTracer() {
	}

	@Before("daoTracer() || serviceTracer()")
	public void logBefore(JoinPoint joinPoint) {
		//if (log.isDebugEnabled()) {
			StringBuffer logData = new StringBuffer("Before calling ")
					.append(joinPoint.getSignature().getName());
			if (joinPoint.getArgs() != null) {
				logData.append(" with arguments :");
				for (int i = 0; i < joinPoint.getArgs().length; i++) {
					logData.append(joinPoint.getArgs()[i]);
					if (i != joinPoint.getArgs().length - 1)
						logData.append(",");
				}
			}
			//log.info(logData.toString());
		//}
	}

	@AfterReturning(pointcut = "daoTracer() || serviceTracer()")
	public void logAfter(JoinPoint joinPoint) {
		//if (log.isDebugEnabled()) {
			StringBuffer logData = new StringBuffer("After calling ")
					.append(joinPoint.getSignature().getName());
			if (joinPoint.getArgs() != null) {
				logData.append(" with arguments :");
				for (int i = 0; i < joinPoint.getArgs().length; i++) {
					logData.append(joinPoint.getArgs()[i]);
					if (i != joinPoint.getArgs().length - 1)
						logData.append(",");
				}
			}
			//log.info(logData.toString());
		//}
	}

	@AfterThrowing(pointcut = "daoTracer() || serviceTracer()", throwing = "ex")
	public void logThrowing(JoinPoint joinPoint, Exception ex) {
		if(ex instanceof UnrecoverableException){
			StringWriter sw = new StringWriter();
			ex.printStackTrace(new PrintWriter(sw));
			String stacktrace = sw.toString();
			log.error("Method " + joinPoint.getSignature().getName()
					+ " threw an exception " + ex.getMessage());
			log.error(stacktrace);
			return ;
		}
		log.warn("Method " + joinPoint.getSignature().getName()
				+ " threw an exception " + ex.getMessage());
	}
}
