package com.bsf.ppm.parser;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.bsf.ppm.constants.IConstants;

/** This class represents short example how to parse XML file,
 * get XML nodes values and its values.<br><br>
 * It implements method to save XML document to XML file too
 * @author Abdul Raoof
 */

public class ParseXMLFile {
	private static final Logger log = Logger.getLogger(ParseXMLFile.class);
	//private final static String xmlFileName = "D:\\webproject\\payroll\\payroll\\messages\\325.xml";
    private final static String targetFileName = "D:\\webproject\\payroll\\payroll\\messages\\example2.xml";
    
    public HashMap bodyMap = null;
    public HashMap xmlMap =null;
    /** Creates a new instance of ParseXMLFile */
    public HashMap ParseXMLFile(String xmlFileName) {
       try{ 
        bodyMap = new HashMap();
        xmlMap = new HashMap();
        // parse XML file -> XML document will be build
        Document doc = parseFile(xmlFileName);
        // get root node of xml tree structure
        Node root = doc.getDocumentElement();
        // write node and its child nodes into System.out
        //System.out.println("Statemend of XML document...");
        bodyMap=loadDocumentToOutput(root,0);
        //writeDocumentToOutput(root,0);
        //System.out.println("... end of xml Parsing");
        // write Document into XML file
        //saveXMLDocument(targetFileName, doc);
       }
       catch(Exception e) {
       System.out.println("Error :: "+e.getMessage());} 
       
       return bodyMap;
    }
    
    /** Returns element value
     * @param elem element (it is XML tag)
     * @return Element value otherwise empty String
     */
    public final static String getElementValue( Node elem ) {
        Node kid;
        if( elem != null){
            if (elem.hasChildNodes()){
                for( kid = elem.getFirstChild(); kid != null; kid = kid.getNextSibling() ){
                    if( kid.getNodeType() == Node.TEXT_NODE  ){
                        return kid.getNodeValue();
                    }
                }
            }
        }
        return "";
    }
    
    private String getIndentSpaces(int indent) {
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < indent; i++) {
            buffer.append(" ");
        }
        return buffer.toString();
    }
    
    /** Writes node and all child nodes into System.out
     * @param node XML node from from XML tree wrom which will output statement start
     * @param indent number of spaces used to indent output
     */
    public void writeDocumentToOutput(Node node,int indent) {
        // get element name
        String nodeName = node.getNodeName();
        // get element value
        String nodeValue = getElementValue(node);
        // get attributes of element
        NamedNodeMap attributes = node.getAttributes();
        System.out.println(getIndentSpaces(indent) + "NodeName: " + nodeName + ", NodeValue: " + nodeValue);
        for (int i = 0; i < attributes.getLength(); i++) {
            Node attribute = attributes.item(i);
            System.out.println(getIndentSpaces(indent + 2) + "AttributeName: " + attribute.getNodeName() + ", attributeValue: " + attribute.getNodeValue());
        }
        // write all child nodes recursively
        NodeList children = node.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() == Node.ELEMENT_NODE) {
                writeDocumentToOutput(child,indent + 2);
            }
        }
    }
    
     /** Load node and all child nodes into System.out
     * @param node XML node from from XML tree wrom which will output statement start
     * @param indent number of spaces used to indent output
     */
    public HashMap loadDocumentToOutput(Node node,int indent) {
        
        // get element name
        String nodeName = node.getNodeName();
        // get element value
        String nodeValue = getElementValue(node);
        // get attributes of element
        NamedNodeMap attributes = node.getAttributes();        
        xmlMap.put(nodeName,nodeValue.replace("\n", ""));      
        
        
        for (int i = 0; i < attributes.getLength(); i++) {
            Node attribute = attributes.item(i);            
            xmlMap.put(nodeName+attribute.getNodeName(),attribute.getNodeValue());            
            //System.out.println(getIndentSpaces(indent + 2) + "AttributeName: " + attribute.getNodeName() + ", attributeValue: " + attribute.getNodeValue());
        }
        // write all child nodes recursively
        NodeList children = node.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() == Node.ELEMENT_NODE) {
                loadDocumentToOutput(child,indent + 2);
            }
        }
       return  xmlMap;
    }
    public static String startUpper(String strArg)
    {String string1 ="";
	  if (strArg!=null)
	  string1 = strArg.substring(0,1).toUpperCase() + strArg.substring(1);   
	  
	  return string1;     	
    }
    /** Saves XML Document into XML file.
     * @param fileName XML file name
     * @param doc XML document to save
     * @return <B>true</B> if method success <B>false</B> otherwise
     */    
    public boolean saveXMLDocument(String fileName, Document doc) {
        System.out.println("Saving XML file... " + fileName);
        // open output stream where XML Document will be saved
        File xmlOutputFile = new File(fileName);
        FileOutputStream fos;
        Transformer transformer;
        try {
            fos = new FileOutputStream(xmlOutputFile);
        }
        catch (FileNotFoundException e) {
            System.out.println("Error occured: " + e.getMessage());
            return false;
        }
        // Use a Transformer for output
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        try {
            transformer = transformerFactory.newTransformer();
        }
        catch (TransformerConfigurationException e) {
            System.out.println("Transformer configuration error: " + e.getMessage());
            return false;
        }
        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(fos);
        // transform source into result will do save
        try {
            transformer.transform(source, result);
        }
        catch (TransformerException e) {
            System.out.println("Error transform: " + e.getMessage());
        }
        System.out.println("XML file saved.");
        return true;
    }
    
    /** Parses XML file and returns XML document.
     * @param fileName XML file to parse
     * @return XML document or <B>null</B> if error occured
     */
    public Document parseFile(String fileName) {
        System.out.println("Parsing XML file... " + fileName);
        DocumentBuilder docBuilder;
        Document doc = null;
        DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
        docBuilderFactory.setIgnoringElementContentWhitespace(true);
        try {
            docBuilder = docBuilderFactory.newDocumentBuilder();
        }
        catch (ParserConfigurationException e) {
            System.out.println("Wrong parser configuration: " + e.getMessage());
            return null;
        }
        File sourceFile = new File(fileName);
        try {
            doc = docBuilder.parse(sourceFile);
        }
        catch (SAXException e) {
            System.out.println("Wrong XML file structure: " + e.getMessage());
            return null;
        }
        catch (IOException e) {
            System.out.println("Could not read source file: " + e.getMessage());
        }
        System.out.println("XML file parsed");
        return doc;
    }
    
    /**
	 * get field value 
	 * @return
	 */ 
 
public String getFieldValue(String myline,String inCV,String inDV,int inPOS,int inLen) {	  	
     try{    	 	 
	if (inCV.equalsIgnoreCase(IConstants.FIXED_VALUE)) 
            return inDV;
        else if ((myline.length() >= (inPOS+inLen)) && (inLen>0))
            return myline.substring(inPOS, (inPOS+inLen));
        else if (inLen>0)
            return myline.substring(inPOS, myline.length());
        else  
            return "";
            
        }catch (java.lang.StringIndexOutOfBoundsException ex) {				
        	log.warn("Error - getFieldValue :: Check your Input file :: "+ ex.getMessage());
	 throw new java.lang.StringIndexOutOfBoundsException("Error : 1 - Incoming Data is not in required format. Refer the Template for correct format.<BR> 2 - Data is missing, Check your Input file.");
	 					
	}              		         
 }
/**
 * Change data Type 
 * @return
 */ 

public int getN(Object str) {
		int Numb = 0;			
		try{
			 Numb=Integer.parseInt(str.toString());
		   }catch (Exception ex) {				
			   log.warn("Error - getN :: Number is not valid :: "+ ex.getMessage());					
		   }      
		return Numb;
}  

public String getLastDir(String fname){ 
    String lastdir="";      
try{
 File pfile = new File (fname);
     if(!pfile.exists()){throw new Exception(fname+" : File not Found Exception, Check file exist!");}          
 lastdir=pfile.getParent();        
 lastdir=lastdir.substring(lastdir.lastIndexOf(File.separator)+1,lastdir.length());          
}catch(Exception e){
	log.warn("Error - getLastDir :: Failed for last dir : "+ e.getMessage());	     	
 }
return lastdir.toUpperCase();
}

public boolean writeToFile(String strFilePathNameArg, byte byteDataToWriteArg[], boolean bAppendArg)
{
    try
    {
        FileOutputStream fosCur = new FileOutputStream(strFilePathNameArg, bAppendArg);
        fosCur.write(byteDataToWriteArg);
        fosCur.close();
    }
    catch(FileNotFoundException _ex)
    {   log.warn("Error :: "+_ex.getMessage() );
        return false;
    }
    catch(IOException _ex)
    {   log.warn("Error :: "+_ex.getMessage() );
    	  return false;
    }
    return true;
}

    /** Starts XML parsing example
     * @param args the command line arguments
     */
   /* public static void main(String[] args) {
        new ParseXMLFile();
    }*/
}

