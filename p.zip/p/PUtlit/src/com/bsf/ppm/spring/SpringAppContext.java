package com.bsf.ppm.spring;

import org.springframework.context.ApplicationContext;

/**
 * Class to share spring context through static references
 * 
 * @author Rakesh
 * 
 */
public class SpringAppContext {

	/**
	 * Spring context
	 */
	private static ApplicationContext ctx;

	/**
	 * Sets application context to the class
	 * 
	 * @param applicationContext
	 */
	public static void setApplicationContext(
			ApplicationContext applicationContext) {
		ctx = applicationContext;
	}

	/**
	 * Getter for Application Context
	 * 
	 * @return the ctx
	 */
	public static ApplicationContext getApplicationContext() {
		return ctx;
	}

	/**
	 * Gets bean from context
	 * 
	 * @param beanName
	 * @return
	 */
	public static Object getBean(String beanName) {
		if (ctx != null)
			return ctx.getBean(beanName);
		return null;
	}
}
