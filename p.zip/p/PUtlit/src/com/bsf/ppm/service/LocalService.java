package com.bsf.ppm.service;

/**
 * Interface for local services
 * @author Rakesh
 *
 */
public interface LocalService extends Service {

}
