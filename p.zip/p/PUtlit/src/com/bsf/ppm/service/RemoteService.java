package com.bsf.ppm.service;

import java.rmi.Remote;

/**
 * Interface for remote services
 * @author Rakesh
 *
 */
public interface RemoteService extends Service, Remote {

}
