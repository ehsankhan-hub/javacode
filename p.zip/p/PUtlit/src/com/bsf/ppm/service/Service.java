package com.bsf.ppm.service;

/**
 * Marker inerface for all services
 * @author Rakesh
 *
 */
public interface Service {
	public String getServiceName();
}
