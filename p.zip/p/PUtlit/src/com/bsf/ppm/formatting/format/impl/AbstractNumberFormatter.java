package com.bsf.ppm.formatting.format.impl;

import com.bsf.ppm.formatting.annotations.Sign;
import com.bsf.ppm.formatting.format.AbstractFixedFormatter;
import com.bsf.ppm.formatting.format.FormatInstructions;

/**
 * Apply signing to values
 */
public abstract class AbstractNumberFormatter<T> extends AbstractFixedFormatter<T> {

  /**
   * Override and applies signing instead of align.
   *
   * @param value the value
   * @param instructions the instructions
   * @return the parsed object
   */
  public T parse(String value, FormatInstructions instructions) {
    T result = null;
    if (value != null) {
      Sign signing = instructions.getFixedFormatNumberData().getSigning();
      String rawString = signing.remove(value, instructions);
      result = asObject(rawString, instructions);
    }
    return result;
  }

  /**
     * Override and applies signing instead of align.
     *
     * @param obj the object to format
     * @param instructions the instructions
     * @return the raw value
     */
    public String format(T obj, FormatInstructions instructions, String precision) {
      return instructions.getFixedFormatNumberData().getSigning().apply(asString(obj, instructions, precision), instructions);
    }
}
