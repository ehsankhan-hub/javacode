package com.bsf.ppm.formatting.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;

/**
 * Define representations for {@link Boolean#TRUE} and {@link Boolean#FALSE}
 * @since 1.0.0
 */

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.FIELD})
public @interface FixedFormatBoolean {

  /**
   * The default <code>true</code> value
   */
  public static final String TRUE_VALUE = "T";

  /**
   * The default <code>false</code> value
   */
  public static final String FALSE_VALUE = "F";

  /**
   * The string to map a boolean true value to.
   * @return contains the string representation of a <code>true</code> value
   */
  String trueValue() default TRUE_VALUE;

  /**
   * The string to map a boolean false value to.
   * @return contains the string representation of a <code>false</code> value
   */
  String falseValue() default FALSE_VALUE;
}
