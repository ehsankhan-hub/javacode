package com.bsf.ppm.formatting.format;

import com.bsf.ppm.formatting.annotations.Align;
import com.bsf.ppm.formatting.format.data.FixedFormatBooleanData;
import com.bsf.ppm.formatting.format.data.FixedFormatDecimalData;
import com.bsf.ppm.formatting.format.data.FixedFormatNumberData;
import com.bsf.ppm.formatting.format.data.FixedFormatPatternData;

/**
 * Contains instructions on how to export and load fixed formatted data.
 *
 */
public class FormatInstructions {

  private int length;
  private Align alignment;
  private char paddingChar;
  private FixedFormatPatternData fixedFormatPatternData;
  private FixedFormatBooleanData fixedFormatBooleanData;
  private FixedFormatNumberData fixedFormatNumberData;
  private FixedFormatDecimalData fixedFormatDecimalData;

  public FormatInstructions(int length, Align alignment, char paddingChar, FixedFormatPatternData fixedFormatPatternData, FixedFormatBooleanData fixedFormatBooleanData, FixedFormatNumberData fixedFormatNumberData, FixedFormatDecimalData fixedFormatDecimalData) {
    this.length = length;
    this.alignment = alignment;
    this.paddingChar = paddingChar;
    this.fixedFormatPatternData = fixedFormatPatternData;
    this.fixedFormatBooleanData = fixedFormatBooleanData;
    this.fixedFormatNumberData = fixedFormatNumberData;
    this.fixedFormatDecimalData = fixedFormatDecimalData;
  }

  public int getLength() {
    return length;
  }

  public Align getAlignment() {
    return alignment;
  }

  public char getPaddingChar() {
    return paddingChar;
  }

  public FixedFormatPatternData getFixedFormatPatternData() {
    return fixedFormatPatternData;
  }

  public FixedFormatBooleanData getFixedFormatBooleanData() {
    return fixedFormatBooleanData;
  }

  public FixedFormatDecimalData getFixedFormatDecimalData() {
    return fixedFormatDecimalData;
  }

  public FixedFormatNumberData getFixedFormatNumberData() {
    return fixedFormatNumberData;
  }

  public String toString() {
    return "FormatInstructions{" +
        "length=" + length +
        ", alignment=" + alignment +
        ", paddingChar='" + paddingChar + "'" + 
        ", fixedFormatPatternData=" + fixedFormatPatternData +
        ", fixedFormatBooleanData=" + fixedFormatBooleanData +
        ", fixedFormatNumberData=" + fixedFormatNumberData +
        ", fixedFormatDecimalData=" + fixedFormatDecimalData +
        '}';
  }
}
