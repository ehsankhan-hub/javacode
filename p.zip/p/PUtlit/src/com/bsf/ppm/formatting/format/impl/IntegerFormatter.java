package com.bsf.ppm.formatting.format.impl;

import com.bsf.ppm.formatting.format.FormatInstructions;

/**
 * Formatter for {@link Integer} data
 *
 */
public class IntegerFormatter extends AbstractNumberFormatter<Integer> {

  public Integer asObject(String string, FormatInstructions instructions) {
    return Integer.parseInt(string);
  }

  public String asString(Integer obj, FormatInstructions instructions, String precision) {
    String result = null;
    if (obj != null) {
      result = Integer.toString(obj);
    }
    return result;
  }

}
