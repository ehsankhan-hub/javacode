package com.bsf.ppm.formatting.format.data;

import com.bsf.ppm.formatting.annotations.FixedFormatNumber;
import com.bsf.ppm.formatting.annotations.Sign;

/**
 * Data object containing the exact same data as {@link FixedFormatNumber}
 *
 */
public class FixedFormatNumberData {

  public static final FixedFormatNumberData DEFAULT = new FixedFormatNumberData(Sign.NOSIGN, FixedFormatNumber.DEFAULT_POSITIVE_SIGN, FixedFormatNumber.DEFAULT_NEGATIVE_SIGN);

  private Sign signing;
  private char positiveSign;
  private char negativeSign;

  public FixedFormatNumberData(Sign signing, char positiveSign, char negativeSign) {
    this.signing = signing;
    this.positiveSign = positiveSign;
    this.negativeSign = negativeSign;
  }

  
  public Sign getSigning() {
    return signing;
  }

  public Character getPositiveSign() {
    return positiveSign;
  }

  public Character getNegativeSign() {
    return negativeSign;
  }


  public String toString() {
    return "FixedFormatNumberData{" +
        "signing=" + signing +
        ", positiveSign='" + positiveSign + "'" +
        ", negativeSign='" + negativeSign + "'" + 
        '}';
  }
}
