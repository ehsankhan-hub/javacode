package com.bsf.ppm.formatting.format.impl;

import com.bsf.ppm.formatting.format.FormatInstructions;

/**
 * Formatter for {@link Float} data
 *
 */
public class FloatFormatter extends AbstractDecimalFormatter<Float> {
  
  public Float asObject(String string, FormatInstructions instructions) {
      String toConvert = getStringToConvert(string, instructions);
      return Float.parseFloat("".equals(toConvert) ? "0" : toConvert);
    }

}
