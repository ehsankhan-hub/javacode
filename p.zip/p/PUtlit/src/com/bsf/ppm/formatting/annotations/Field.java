package com.bsf.ppm.formatting.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.bsf.ppm.formatting.format.FixedFormatter;
import com.bsf.ppm.formatting.format.impl.ByTypeFormatter;

/**
 * This annotation descibes how a setter/getter pairs should be formatted by the fixedFormatManager.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface Field {

  /**
   * A one based offset to insert data at in a record.
   * @return the offset as an int
   */
  int offset();

  /**
   * The length of the formatted field
   * @return the length as an int
   */
  int length();

  /**
   * @return The direction of the padding. Defaults to {@link Align#RIGHT}.
   */
  Align align() default Align.LEFT;

  /**
   * The character to pad with if the length is longer than the formatted data
   * @return the padding character
   */
  char paddingChar() default ' ';

  Class<? extends FixedFormatter> formatter() default ByTypeFormatter.class;

}
