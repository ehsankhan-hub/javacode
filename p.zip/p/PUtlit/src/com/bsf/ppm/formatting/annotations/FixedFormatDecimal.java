package com.bsf.ppm.formatting.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.FIELD})
public @interface FixedFormatDecimal {

  public static final int DECIMALS = 2;
  public static final boolean USE_DECIMAL_DELIMITER = false;
  public static final char DECIMAL_DELIMITER = '.';

  int decimals() default DECIMALS;

  boolean useDecimalDelimiter() default USE_DECIMAL_DELIMITER;

  char decimalDelimiter() default DECIMAL_DELIMITER;
}
