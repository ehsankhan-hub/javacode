package com.bsf.ppm.formatting.exception;

import java.lang.reflect.Method;

import com.bsf.ppm.formatting.format.FormatContext;
import com.bsf.ppm.formatting.format.FormatInstructions;

/**
 * Used in cases where data couldn't be parse according to the context and instructions.
 *
 */
public class ParseException extends FixedFormatException {

  public ParseException(String completeString, String data, Class clazz, Method method, FormatContext formatContext, FormatInstructions formatInstructions, Throwable e) {
    super("failed to parse '" + data + "' at offset " + formatContext.getOffset() + " as " + formatContext.getDataType().getName() + " from '" + completeString + "'. Got format instructions from " + clazz.getName() + "." + method.getName() + ". See details{" + formatContext.toString() + ", " +formatInstructions.toString() + "}", e);
  }
}
