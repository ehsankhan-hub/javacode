package com.bsf.ppm.formatting.format;

/**
 * Contains context for loading and exporting fixedformat data.
 * The context describes what kind of formatter to use, what datatype to convert and what offset to fetch data from.
 */
public class FormatContext<T> {

  private int offset;
  private Class<T> dataType;
  private Class<? extends FixedFormatter> formatter;

  public FormatContext(int offset, Class<T> dataType, Class<? extends FixedFormatter> formatter) {
    this.offset = offset;
    this.dataType = dataType;
    this.formatter = formatter;
  }

  public int getOffset() {
    return offset;
  }

  public Class<T> getDataType() {
    return dataType;
  }

  public Class<? extends FixedFormatter> getFormatter() {
    return formatter;
  }


  public String toString() {
    return "FormatContext{" +
        "offset=" + offset +
        ", dataType=" + dataType.getName() +
        ", formatter=" + formatter.getName() +
        '}';
  }
}
