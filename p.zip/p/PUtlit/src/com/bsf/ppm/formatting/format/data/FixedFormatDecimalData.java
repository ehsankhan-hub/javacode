package com.bsf.ppm.formatting.format.data;

import com.bsf.ppm.formatting.annotations.FixedFormatDecimal;

/**
 * Data object containing the exact same data as {@link FixedFormatDecimal}
 *
 */
public class FixedFormatDecimalData {

  private int decimals;
  private boolean useDecimalDelimiter;
  private char decimalDelimiter;
  public static final FixedFormatDecimalData DEFAULT = new FixedFormatDecimalData(FixedFormatDecimal.DECIMALS, FixedFormatDecimal.USE_DECIMAL_DELIMITER, FixedFormatDecimal.DECIMAL_DELIMITER);
 
  public FixedFormatDecimalData(int decimals, boolean useDecimalDelimiter, char decimalDelimiter) {
    this.decimals = decimals;
    this.useDecimalDelimiter = useDecimalDelimiter;
    this.decimalDelimiter = decimalDelimiter;
  }

  public int getDecimals() {
    return decimals;
  }

  public boolean isUseDecimalDelimiter() {
    return useDecimalDelimiter;
  }

  public char getDecimalDelimiter() {
    return decimalDelimiter;
  }


  public String toString() {
    return "FixedFormatDecimalData{" +
        "decimals=" + decimals +
        ", useDecimalDelimiter=" + useDecimalDelimiter +
        ", decimalDelimiter='" + decimalDelimiter + "'" + 
        '}';
  }
}
