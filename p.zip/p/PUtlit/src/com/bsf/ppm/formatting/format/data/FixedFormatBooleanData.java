package com.bsf.ppm.formatting.format.data;

import com.bsf.ppm.formatting.annotations.FixedFormatBoolean;

/**
 * Data object containing the exact same data as {@link FixedFormatBoolean} 
 * 
 */
public class FixedFormatBooleanData {

  public static final FixedFormatBooleanData DEFAULT = new FixedFormatBooleanData(FixedFormatBoolean.TRUE_VALUE, FixedFormatBoolean.FALSE_VALUE);

  private String trueValue;

  private String falseValue;

  public FixedFormatBooleanData(String trueValue, String falseValue) {
    this.trueValue = trueValue;
    this.falseValue = falseValue;
  }

  public String getTrueValue() {
    return trueValue;
  }

  public String getFalseValue() {
    return falseValue;
  }


  public String toString() {
    return "FixedFormatBooleanData{" +
        "trueValue='" + trueValue + "'" +
        ", falseValue='" + falseValue + "'" +
        '}';
  }
}
