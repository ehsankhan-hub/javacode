package com.bsf.ppm.formatting.format;

/**
 * Handles default formatting and parsing based on FixedFormatAnnotation values.
 */
public abstract class AbstractFixedFormatter<T> implements FixedFormatter<T> {
  public T parse(String value, FormatInstructions instructions) {
    T result = null;
    if (value != null) {
      instructions.getFixedFormatNumberData();
      result = asObject(instructions.getAlignment().remove(value, instructions.getPaddingChar()), instructions);
    }
    return result;
  }

  public String format(T value, FormatInstructions instructions, String precision) {
    return instructions.getAlignment().apply(asString(value, instructions,precision), instructions.getLength(), instructions.getPaddingChar());
  }

  public abstract T asObject(String string, FormatInstructions instructions);

  public abstract String asString(T obj, FormatInstructions instructions, String precision);
}
