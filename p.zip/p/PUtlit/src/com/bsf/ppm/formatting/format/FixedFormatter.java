package com.bsf.ppm.formatting.format;

import com.bsf.ppm.formatting.annotations.Field;
import com.bsf.ppm.formatting.exception.FixedFormatException;
import com.bsf.ppm.formatting.format.impl.DateFormatter;

/**
 * Formatter capable of transforming data to and from a string used in text records.
 * <p/>
 * A concrete class is used together with the @{@link Field} annotation.
 * <p/>
 * Example: <p><code>@Field(offset = 1, length = 20, formatter = {@link DateFormatter}.class)</code></p>
 */
public interface FixedFormatter<T> {

  T parse(String value, FormatInstructions instructions) throws FixedFormatException;

  String format(T value, FormatInstructions instructions, String precision) throws FixedFormatException;
}
