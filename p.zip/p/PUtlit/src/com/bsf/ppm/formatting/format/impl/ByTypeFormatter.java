package com.bsf.ppm.formatting.format.impl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.bsf.ppm.formatting.exception.FixedFormatException;
import com.bsf.ppm.formatting.format.FixedFormatter;
import com.bsf.ppm.formatting.format.FormatContext;
import com.bsf.ppm.formatting.format.FormatInstructions;

/**
 * Formatter capable of formatting a bunch of known java standard library classes. So far:
 * {@link String}, {@link Integer}, {@link Long}, {@link Date},
 * {@link Character}, {@link Boolean}, {@link Double}, {@link Float} and {@link BigDecimal}
 */
public class ByTypeFormatter implements FixedFormatter {
  private FormatContext context;

  private static final Map<Class<? extends Serializable>, Class<? extends FixedFormatter>> KNOWN_FORMATTERS = new HashMap<Class<? extends Serializable>, Class<? extends FixedFormatter>>();

  static {
    KNOWN_FORMATTERS.put(String.class, StringFormatter.class);
    KNOWN_FORMATTERS.put(int.class, IntegerFormatter.class);
    KNOWN_FORMATTERS.put(Integer.class, IntegerFormatter.class);
    KNOWN_FORMATTERS.put(long.class, LongFormatter.class);
    KNOWN_FORMATTERS.put(Long.class, LongFormatter.class);
    KNOWN_FORMATTERS.put(Date.class, DateFormatter.class);
    KNOWN_FORMATTERS.put(Date.class, DateFormatter.class);
    KNOWN_FORMATTERS.put(char.class, CharacterFormatter.class);
    KNOWN_FORMATTERS.put(Character.class, CharacterFormatter.class);
    KNOWN_FORMATTERS.put(boolean.class, BooleanFormatter.class);
    KNOWN_FORMATTERS.put(Boolean.class, BooleanFormatter.class);
    KNOWN_FORMATTERS.put(double.class, DoubleFormatter.class);
    KNOWN_FORMATTERS.put(Double.class, DoubleFormatter.class);
    KNOWN_FORMATTERS.put(float.class, FloatFormatter.class);
    KNOWN_FORMATTERS.put(Float.class, FloatFormatter.class);
    KNOWN_FORMATTERS.put(BigDecimal.class,  BigDecimalFormatter.class);
  }

  public ByTypeFormatter(FormatContext context) {
    this.context = context;
  }


  public Object parse(String value, FormatInstructions instructions) {
    FixedFormatter formatter = actualFormatter(context.getDataType());
    return formatter.parse(value, instructions);
  }

  public String format(Object value, FormatInstructions instructions, String precision) {
    FixedFormatter formatter = actualFormatter(context.getDataType());
    return formatter.format(value, instructions,precision);
  }

  public FixedFormatter actualFormatter(final Class<? extends Object> dataType) {
    Class<? extends FixedFormatter> formatterClass = KNOWN_FORMATTERS.get(dataType);

    if (formatterClass != null) {
      try {
        return formatterClass.getConstructor().newInstance();
      } catch (NoSuchMethodException e) {
        throw new FixedFormatException("Could not create instance of[" + formatterClass.getName() + "] because no default constructor exists");
      } catch (Exception e) {
        throw new FixedFormatException("Could not create instance of[" + formatterClass.getName() + "]", e);
      }
    } else {
      throw new FixedFormatException(ByTypeFormatter.class.getName() + " cannot handle datatype[" + dataType.getName() + "]. Provide your own custom FixedFormatter for this datatype.");
    }
  }
}
