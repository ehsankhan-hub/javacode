package com.bsf.ppm.formatting.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Wrapper for more than one field.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface Fields {

  /**
   * Defines a list of field annotations.
   * Useful a field is to be mapped different places in the text
   * @return a list of {@link Field} annotations
   */
  public abstract Field[] value();
}
