package com.bsf.ppm.formatting.format.impl;

import org.apache.commons.lang.StringUtils;

import com.bsf.ppm.formatting.exception.FixedFormatException;
import com.bsf.ppm.formatting.format.AbstractFixedFormatter;
import com.bsf.ppm.formatting.format.FormatInstructions;

/**
 * Formatter for {@link Boolean} data
 */
public class BooleanFormatter extends AbstractFixedFormatter<Boolean> {

  public Boolean asObject(String string, FormatInstructions instructions) throws FixedFormatException {
    Boolean result = false;
    if (!StringUtils.isEmpty(string)) {
      if (instructions.getFixedFormatBooleanData().getTrueValue().equals(string)) {
        result = true;
      } else if (instructions.getFixedFormatBooleanData().getFalseValue().equals(string)) {
        result = false;
      } else {
        throw new FixedFormatException("Could not convert string[" + string + "] to boolean value according to booleanData[" + instructions.getFixedFormatBooleanData() + "]");
      }
    }
    return result;
  }

  public String asString(Boolean obj, FormatInstructions instructions, String precision) {
    String result = instructions.getFixedFormatBooleanData().getFalseValue();
    if (obj != null) {
      result = obj ? instructions.getFixedFormatBooleanData().getTrueValue() : instructions.getFixedFormatBooleanData().getFalseValue();
    }
    return result;
  }

}
