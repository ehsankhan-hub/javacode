package com.bsf.ppm.formatting.format.impl;

import java.math.RoundingMode;
import java.text.DecimalFormat;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bsf.ppm.formatting.format.FormatInstructions;

/**
 * Base class for formatting decimal data
 *
 */
public abstract class AbstractDecimalFormatter<T> extends AbstractNumberFormatter<T> {

  private static final Log LOG = LogFactory.getLog(AbstractDecimalFormatter.class);

  protected static final char DECIMAL_SEPARATOR;
  protected static final char GROUPING_SEPARATOR;
  protected static final String ZERO_STRING;
  protected static final DecimalFormat FORMATTER;

  static {
    FORMATTER = new DecimalFormat();
    FORMATTER.setDecimalSeparatorAlwaysShown(true);

    DECIMAL_SEPARATOR = FORMATTER.getDecimalFormatSymbols().getDecimalSeparator();
    GROUPING_SEPARATOR = FORMATTER.getDecimalFormatSymbols().getGroupingSeparator();
    ZERO_STRING = "0" + DECIMAL_SEPARATOR + "0";

  }

  public String asString(T obj, FormatInstructions instructions, String precision) {
	  String result = null;
	  String rawString = obj != null ? obj.toString() : ZERO_STRING;
    //System.out.println("rawString before formating"+rawString);
    if (precision ==null || precision.equals(""))
    	precision="0";

    // Apply Decimal Pattern to the Double value according to Precision
    if (obj instanceof Double) {
    	DecimalFormat df = new DecimalFormat();
    	df.setRoundingMode(RoundingMode.DOWN);
    	
        df.applyPattern(fetchDeciamlPatternFromPrecision(precision));
        rawString = df.format(((Double) obj).doubleValue());
       // System.out.println("rawString after formating"+rawString);
    }
    
    if (LOG.isDebugEnabled()) {
      LOG.debug("rawString: " + rawString + " - G[" + GROUPING_SEPARATOR + "] D[" + DECIMAL_SEPARATOR + "]");
    }
    
    rawString = rawString.replaceAll("\\" + GROUPING_SEPARATOR, "");
    boolean useDecimalDelimiter = instructions.getFixedFormatDecimalData().isUseDecimalDelimiter();
    
    // If the Formatted Double has a decimal separator. Apply the precision 
    if (rawString.indexOf(DECIMAL_SEPARATOR) != -1) {
    	String beforeDelimiter = rawString.substring(0, rawString.indexOf(DECIMAL_SEPARATOR));
    	String afterDelimiter = rawString.substring(rawString.indexOf(DECIMAL_SEPARATOR)+1, rawString.length());
    
	    if (LOG.isDebugEnabled()) {
	      LOG.debug("beforeDelimiter[" + beforeDelimiter + "], afterDelimiter[" + afterDelimiter + "]");
	    }
	    //int decimals = instructions.getFixedFormatDecimalData().getDecimals();
	
	    //trim decimals
	    afterDelimiter = StringUtils.substring(afterDelimiter, 0, NumberUtils.toInt(precision));
	    afterDelimiter = StringUtils.rightPad(afterDelimiter, NumberUtils.toInt(precision), '0');
	
	    String delimiter = useDecimalDelimiter ? "" + instructions.getFixedFormatDecimalData().getDecimalDelimiter() : "";
	    
	   	result = beforeDelimiter + delimiter + afterDelimiter;
	    if (LOG.isDebugEnabled()) {
	        LOG.debug("result[" + result + "]");
	    }	   	
    } 
    else {
    	result = rawString;
    }
    //System.out.println("----------------------------result String = "+result);
    return result;
  }
 
  protected String getStringToConvert(String string, FormatInstructions instructions) {
    String toConvert;
    boolean useDecimalDelimiter = instructions.getFixedFormatDecimalData().isUseDecimalDelimiter();
    if(useDecimalDelimiter) {
	      char delimiter = instructions.getFixedFormatDecimalData().getDecimalDelimiter();
	      toConvert = string.replace(delimiter, '.'); //convert to normal delimiter
    } else {
	      int decimals = instructions.getFixedFormatDecimalData().getDecimals();
	      if (decimals > 0 && string.length() >= decimals) {
	    	  
	        String beforeDelimiter = string.substring(0, string.length()-decimals);
	        String afterDelimiter = string.substring(string.length()-decimals, string.length());
	        toConvert = beforeDelimiter + '.' + afterDelimiter;
	      } else {
	        toConvert = string;
	      }
    }
    return toConvert;
  }

  /**
 * Build the decimal pattern of 16 chars depending on precession.
 * Default Pattern does not take a decimal. It is like ################
 * @param precision
 * @return decimal pattern of 16 chars depending on precession.
 */
  private String fetchDeciamlPatternFromPrecision(String precision){
      StringBuffer sb = new StringBuffer("################"); //default 13 digits and 2 decimals
      if (precision !=null || !precision.equals("")) {
      	int precLength = NumberUtils.toInt(precision);

      	if (precLength != 0) {
      		sb = new StringBuffer();
	      	for (int i = 0; i < 15-precLength; i++) {
	      		sb.append('#');
			}
	      	sb.append(".");
	      	for (int i = 0; i < precLength; i++) {
	      		sb.append('#');
			}
      	}
      	//System.out.println(precLength+"Applying Pattern = "+sb.toString());
      }
           
      return sb.toString();
  }
}
