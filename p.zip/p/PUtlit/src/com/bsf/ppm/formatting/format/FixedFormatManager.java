package com.bsf.ppm.formatting.format;

import com.bsf.ppm.formatting.exception.FixedFormatException;

/**
 * Interface used to interact with fixed format annotations.
 *
 * A <code>FixedFormatManager</code> is associated with one type of fixed format data.
 */
public interface FixedFormatManager {

  /**
   * Create an instance of the fixedFormatClass and load the data string into the object according to the annotations.
   * @param clazz the class to instanciate
   * @param data the data to load
   * @return an object loaded with the fixedformat data
   * @throws FixedFormatException in case the fixedFormatRecord class cannot be loaded
   */
  <T> T load(Class<T> clazz, String data) throws FixedFormatException;

  <T> String export(T instance) throws FixedFormatException;

  <T> String export(String data, T instance) throws FixedFormatException;


}
