package com.bsf.ppm.formatting.format.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.bsf.ppm.formatting.exception.FixedFormatException;
import com.bsf.ppm.formatting.format.AbstractFixedFormatter;
import com.bsf.ppm.formatting.format.FormatInstructions;

/**
 * Formatter for {@link java.util.Date} data
 *
 */
public class DateFormatter extends AbstractFixedFormatter<Date> {

  public Date asObject(String string, FormatInstructions instructions) throws FixedFormatException {
    Date result = null;

    if (!StringUtils.isEmpty(string)) {
      try {
        result = getFormatter(instructions.getFixedFormatPatternData().getPattern()).parse(string);
      } catch (ParseException e) {
        throw new FixedFormatException("Could not parse value[" + string + "] by pattern[" + instructions.getFixedFormatPatternData().getPattern() + "] to " + Date.class.getName());
      }
    }
    return result;
  }

  public String asString(Date date, FormatInstructions instructions, String precision) {
    String result = null;
    if (date != null) {
      result = getFormatter(instructions.getFixedFormatPatternData().getPattern()).format(date);
    }
    return result;
  }

  DateFormat getFormatter(String pattern) {
    return new SimpleDateFormat(pattern);
  }
}
