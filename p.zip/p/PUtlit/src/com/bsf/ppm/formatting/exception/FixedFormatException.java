package com.bsf.ppm.formatting.exception;


/**
 * Thrown when errors occur while loading or exporting data.
 */
public class FixedFormatException extends RuntimeException {
  public FixedFormatException(String s) {
    super(s);
  }

  public FixedFormatException(String s, Throwable throwable) {
    super(s, throwable);
  }
}
