package com.bsf.ppm.formatting.format.data;

import com.bsf.ppm.formatting.annotations.FixedFormatPattern;

/**
 * Data object containing the exact same data as {@link FixedFormatPattern}
 */
public class FixedFormatPatternData {

  private String pattern;
  public static final FixedFormatPatternData DEFAULT = new FixedFormatPatternData(FixedFormatPattern.DATE_PATTERN);

  public FixedFormatPatternData(String pattern) {
    this.pattern = pattern;
  }

  public String getPattern() {
    return pattern;
  }


  public String toString() {
    return "FixedFormatPatternData{" +
        "pattern='" + pattern + '\'' +
        '}';
  }
}
