package com.bsf.ppm.formatting.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;

/**
 */

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.FIELD})
public @interface FixedFormatNumber {

  public static final char DEFAULT_POSITIVE_SIGN = '+';
  public static final char DEFAULT_NEGATIVE_SIGN = '-';


  Sign sign() default Sign.NOSIGN;
  char positiveSign() default DEFAULT_POSITIVE_SIGN;
  char negativeSign() default DEFAULT_NEGATIVE_SIGN;
}
