package com.bsf.ppm.formatting.format.impl;

import com.bsf.ppm.formatting.format.FormatInstructions;

/**
 * Formatter for {@link Double} data
 */
public class DoubleFormatter extends AbstractDecimalFormatter<Double> {

  public Double asObject(String string, FormatInstructions instructions) {
    String toConvert = getStringToConvert(string, instructions);
    return Double.parseDouble("".equals(toConvert) ? "0" : toConvert);
  }
}
