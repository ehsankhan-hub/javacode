package com.bsf.ppm.formatting.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;

/**
 * Used together with FixedFormatField annotations to provide a pattern for the data.
 * This annotation is required for {@link java.util.Date} datatype.
 * */

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.FIELD})
public @interface FixedFormatPattern {

  public static final String DATE_PATTERN = "yyyyMMdd";

  /**
   * The pattern used in formatting and parsing a fixed format field.
   * Date: yyyyMMdd
   * Other: ####-######.##
   * Currency: ???
   * @return the pattern
   */
  String value();
}
