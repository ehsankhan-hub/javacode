package com.bsf.ppm.formatting.format.impl;

import java.math.BigDecimal;

import com.bsf.ppm.formatting.format.FormatInstructions;

/**
 * Formatter for {@link BigDecimal} data
 *
 */
public class BigDecimalFormatter extends AbstractDecimalFormatter<BigDecimal> {

    public BigDecimal asObject(String string, FormatInstructions instructions) {
      String toConvert = getStringToConvert(string, instructions);
      return new BigDecimal("".equals(toConvert) ? "0" : toConvert);
    }
}
