package com.bsf.ppm.formatting.format.impl;

import com.bsf.ppm.formatting.format.FormatInstructions;

public class LongFormatter extends AbstractNumberFormatter<Long> {

  public Long asObject(String string, FormatInstructions instructions) {
    return Long.parseLong(string);
  }

  public String asString(Long obj, FormatInstructions instructions, String precision) {
    String result = null;
    if (obj != null) {
    result = Long.toString(obj);
    }
    return result;
  }
}
