package com.bsf.ppm.formatting.format.impl;

import com.bsf.ppm.formatting.format.AbstractFixedFormatter;
import com.bsf.ppm.formatting.format.FormatInstructions;

/**
 * Formatter for {@link String} data
 */
public class StringFormatter extends AbstractFixedFormatter<String> {

  public String asObject(String string, FormatInstructions instructions) {
    return string;
  }

  public String asString(String string, FormatInstructions instructions, String precision) {
    String result = null;
    if (string != null) {
    result = string;
    }
    return result;
  }
}
