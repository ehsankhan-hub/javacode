package com.bsf.ppm.formatting.format.impl;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bsf.ppm.formatting.format.AbstractFixedFormatter;
import com.bsf.ppm.formatting.format.FormatInstructions;

/**
 * Formatter for {@link Character} data
 *
 */
public class CharacterFormatter extends AbstractFixedFormatter<Character> {

  private static final Log LOG = LogFactory.getLog(CharacterFormatter.class);

  public Character asObject(String string, FormatInstructions instructions) {
    Character result = null;
    if (!StringUtils.isEmpty(string)) {
      result = string.charAt(0);
      if (string.length() > 1) {
        LOG.warn("found more than one character[" + string + "] after reading instructions from record. Will return first character[" + result + "]");
      }
    }
    return result;
  }

  public String asString(Character obj, FormatInstructions instructions, String precision) {
    String result = "";
    if (obj != null) {
      result = Character.toString(obj);
    }
    return result;
  }
}
