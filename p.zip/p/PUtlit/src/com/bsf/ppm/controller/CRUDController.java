package com.bsf.ppm.controller;

import java.io.Serializable;

import com.bsf.ipp.dao.GenericDAO;


/**
 * Generic CRUD Controller Interface for the CRUD Operations.
 * @author rsaif 
 * @param <T> This is an Entity Class Name of Database model.
 * @param <ID> Unique identity Class Name  
 */
public interface CRUDController <T, ID extends Serializable>  {
	
	/**
	 * @return Generic DAO of the Type T and with ID
	 */
	public GenericDAO<T, ID> getDAO();

	/**
	 * Processing for for list page.
	 * @return Create page Navigation case defined in faces-config.xml
	 */
	public String listSetup();
	
	/**
	 * Processing for add/insert operations.
	 * @return Create page Navigation case defined in faces-config.xml
	 */
	public String createSetup();
	
	/**
	 * Processing for EDIT operation.
	 * @return Edit page Navigation case defined in faces-config.xml
	 */
	public String editSetup();
	
	/**
	 * Processing for the details page.
	 * @return Detail page Navigation case defined in faces-config.xml
	 */
	public String detailSetup();
	
	/**
	 * Update the entity in the database. Serves user update action on Edit page.
	 * @return List page Navigation case defined in faces-config.xml
	 */
	public String update();

	/**
	 * Creates the entity in the database. Serves user create/Save action on Create page.
	 * @return List page Navigation case defined in faces-config.xml
	 */
	public String create();
	
	/**
	 * Deletes the entity in the database. Serves user delete action on Details page.
	 * @return List page Navigation case defined in faces-config.xml
	 */
	public String deleteItem();
	
	/**
	 * Deletes the list of items in the database. Serves user delete action on List page.
	 * @return List page Navigation case defined in faces-config.xml
	 */
	public String deleteItems();
	
	/**
	 * Navigates to the previous page of the list. Serves user previous action on the List page.
	 * @return List page Navigation case defined in faces-config.xml
	 */
	public String prev();
	
	/**
	 * Navigates to the next page of the list. Serves user next action on the List page.
	 * @return List page Navigation case defined in faces-config.xml
	 */
	public String next();
	
	/**
	 * Navigate to the first page in the list.
	 * @return List page Navigation case defined in faces-config.xml
	 */
	public String cancel();
	
	/**
	 * Search Operation performed with the search criteria provided
	 * @return List Page Navigation case defined in faces-config.xml
	 */
	public String searchSetup();
	
	/**To check  if entity is unique
	 * @return
	 */
	public boolean isUnique();
	/**
	 * Disable the entity in the database. Serves user delete action on Details page.
	 * @return List page Navigation case defined in faces-config.xml
	 */
	public String disableItem();
	
	/**
	 * Disable the list of items in the database. Serves user delete action on List page.
	 * @return List page Navigation case defined in faces-config.xml
	 */
	public String disableItems();

}
