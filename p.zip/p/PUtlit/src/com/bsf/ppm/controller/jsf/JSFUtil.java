package com.bsf.ppm.controller.jsf;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.application.FacesMessage.Severity;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.security.wrapper.SavedRequestAwareWrapper;

import com.bsf.ipp.UserInfo;
import com.sun.faces.util.MessageFactory;

public class JSFUtil {
	/**
	 * This method used to retrieve UIComponent in the view tree starting from
	 * base componant based on Component Id
	 * 
	 * @param base
	 * @param id
	 * @return
	 */
	public static UIComponent findComponent(UIComponent base, String id) {

		// Is the "base" component itself the match we are looking for?
		if (id.equals(base.getId())) {
			return base;
		}

		// Search through our facets and children
		UIComponent kid = null;
		UIComponent result = null;
		Iterator kids = base.getFacetsAndChildren();
		while (kids.hasNext() && (result == null)) {
			kid = (UIComponent) kids.next();
			if (id.equals(kid.getId())) {
				result = kid;
				break;
			}
			result = findComponent(kid, id);
			if (result != null) {
				break;
			}
		}
		return result;
	}

	/**
	 * This method used to retrieve UIComponent in the view tree starting from
	 * the root Component based on Component Id
	 * 
	 * @param id
	 * @return
	 */
	public static UIComponent findComponentInRoot(String id) {
		UIComponent ret = null;

		FacesContext context = FacesContext.getCurrentInstance();
		if (context != null) {
			UIComponent root = context.getViewRoot();
			ret = findComponent(root, id);
		}

		return ret;
	}

	/**
	 * This method used to retrieve Value of UIComponent in the view tree starting from
	 * the root Component based on Component Id
	 * 
	 * @param id
	 * @return component Value as Object
	 */
	public static Object findComponentValueInRoot(String id) {
		UIComponent ret = findComponentInRoot(id);
		Object componentValue = null;
		if (ret != null) 
				componentValue=ret.getAttributes().get("value");
		return componentValue;
	}
	
	/**
	 * This Method used to get event Attribute
	 * 
	 * @param event
	 * @param name
	 * @return
	 */
	public static String getAttribute(ActionEvent event, String name) {
		return (String) event.getComponent().getAttributes().get(name);
	}

	/**
	 * This Method used to get message
	 * 
	 * @param context
	 * @param messageBundle
	 * @param MessageId
	 * @param param
	 * @return
	 */
	public static FacesMessage getMessage(FacesContext context,
			String messageBundle, String MessageId, Object... param) {
	   return	getMessage(context,messageBundle,MessageId,FacesMessage.SEVERITY_INFO,param);
	}
	/**
	 * This Method used to get message
	 * 
	 * @param context
	 * @param messageBundle
	 * @param MessageId
	 * @param param
	 * @return
	 */
	public static FacesMessage getMessage(FacesContext context,
			String messageBundle, String MessageId,Severity severity, Object... param) {
		context.getApplication().setMessageBundle(messageBundle);
		return MessageFactory.getMessage(context, MessageId,severity,param);
	}

	/**
	 * 
	 * @param entities
	 * @param selectOne
	 * @return
	 */
	public static SelectItem[] getSelectItems(List<?> entities,
			boolean selectOne) {
		int size = selectOne ? entities.size() + 1 : entities.size();
		SelectItem[] items = new SelectItem[size];
		int i = 0;
		if (selectOne) {
			items[0] = new SelectItem("", "---");
			i++;
		}
		for (Object x : entities) {
			items[i++] = new SelectItem(x, x.toString());
		}
		return items;
	}

	/**
	 * 
	 * @param ex
	 * @param defaultMsg
	 */
	public static void ensureAddErrorMessage(Exception ex, String defaultMsg) {
		String msg = ex.getLocalizedMessage();
		if (msg != null && msg.length() > 0) {
			addErrorMessage(msg);
		} else {
			addErrorMessage(defaultMsg);
		}
	}

	/**
	 * 
	 * @param messages
	 */
	public static void addErrorMessages(List<String> messages) {
		for (String message : messages) {
			addErrorMessage(message);
		}
	}

	/**
	 * Method to add ERROR message to FacesMessage
	 * 
	 * @param msg
	 */
	public static void addErrorMessage(String msg) {
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
				msg, msg);
		FacesContext.getCurrentInstance().addMessage(null, facesMsg);
	}

	/**
	 * Method to add info message to FacesMessage
	 * 
	 * @param msg
	 */
	public static void addSuccessMessage(String msg) {
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO,
				msg, msg);
		FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg);
	}

	/**
	 * Method to get RequestParameter from facesContext
	 * 
	 * @param key
	 * @return
	 */
	public static String getRequestParameter(String key) {
		return FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get(key);
	}

	/**
	 * 
	 * @param requestParameterName
	 * @param converter
	 * @param component
	 * @return
	 */
	public static Object getObjectFromRequestParameter(
			String requestParameterName, Converter converter,
			UIComponent component) {
		String theId = JSFUtil.getRequestParameter(requestParameterName);
		return converter.getAsObject(FacesContext.getCurrentInstance(),
				component, theId);
	}

	/**
	 * 
	 * @param <T>
	 * @param arr
	 * @return
	 */
	public static <T> Collection<T> arrayToCollection(T[] arr) {
		if (arr == null) {
			return new ArrayList<T>();
		}
		return Arrays.asList(arr);
	}

	/**
	 * 
	 * @param c
	 * @return
	 */
	public static Object[] collectionToArray(Collection<?> c) {
		if (c == null) {
			return new Object[0];
		}
		return c.toArray();
	}

	/**
	 * 
	 * @param object
	 * @param converter
	 * @return
	 */
	public static String getAsConvertedString(Object object, Converter converter) {
		return converter.getAsString(FacesContext.getCurrentInstance(), null,
				object);
	}

	/**
	 * 
	 * @param object
	 * @return
	 */
	public static String getAsString(Object object) {
		if (object instanceof Collection<?>) {
			Collection<?> collection = (Collection<?>) object;
			if (collection.size() == 0) {
				return "(No Items)";
			}
			StringBuffer sb = new StringBuffer();
			int i = 0;
			for (Object item : collection) {
				if (i > 0) {
					sb.append("<br />");
				}
				sb.append(item);
				i++;
			}
			return sb.toString();
		}
		return String.valueOf(object);
	}
	public static UserInfo getLoggedInUserInfo()	{
		
		FacesContext context = FacesContext.getCurrentInstance();
		if ( context == null)
			return null;
		HttpSession session = (HttpSession) context.getExternalContext().getSession(false);
		return (UserInfo)session.getAttribute("userInfo"); 
	}
	
	public static String getClearingCenter(){
		FacesContext context = FacesContext.getCurrentInstance();
		if ( context == null)
			return null;
		HttpSession session = (HttpSession) context.getExternalContext().getSession(false);
		return (String)session.getAttribute("clearingCenter"); 
		//return "024";
	}
	
	public static String setClearingCenter(String clearingCenter){
		FacesContext context = FacesContext.getCurrentInstance();
		if ( context == null)
			return "01";
		else{
			HttpSession session = (HttpSession) context.getExternalContext().getSession(false);
			session.setAttribute("clearingCenter", clearingCenter);
			return "00";
		}
	}
	
	public static String getClientIPAddress(){
		FacesContext context = FacesContext.getCurrentInstance();
		if ( context == null){
			try {
				InetAddress  ip = InetAddress.getLocalHost();
				return ip.getHostAddress();
			} catch (UnknownHostException e) {
				e.printStackTrace();
			}
			return "No IP Address";
		}
		SavedRequestAwareWrapper request = (SavedRequestAwareWrapper) context.getExternalContext().getRequest();
		return request.getRemoteAddr();
	}
	
	/**
	 * Takes as input List of id's and return as String, useful for querying  entities based on entity's ids
	 * @param ids
	 * @return
	 */
	public static StringBuffer getIdsAsStringList(List<Long> ids){
		
		StringBuffer sb = null;
		if(ids.size() >0)	{
			
			sb = new StringBuffer("(");
			for(Long id:ids)	{
				
				sb.append(id).append(",");
			}
			sb.replace(sb.length()-1,sb.length(),")");
		}
		return sb;
	}
	public static Object getBeanByName(String objectName){
		FacesContext context = FacesContext.getCurrentInstance();
		return context.getELContext().getELResolver().getValue(context.getELContext(), null, objectName);
		//context.getELContext().getFunctionMapper().
	}
	
	public static String getCollectionCenter(){
		FacesContext context = FacesContext.getCurrentInstance();
		if ( context == null)
			return null;
		HttpSession session = (HttpSession) context.getExternalContext().getSession(false);
		return (String)session.getAttribute("collectionCenter");
	}
	
	public static String formatParticulars(String currency, int count, Double amount, String brn ){
		StringBuilder transactionReference = new StringBuilder(currency);
		transactionReference.append(StringUtils.leftPad(count+"", 6, "0"));
		transactionReference.append(StringUtils.leftPad(amount+"", 16, "0"));
		transactionReference.append(StringUtils.leftPad(brn, 3, "0"));
		return transactionReference.toString();
	}
	
	public static String getBusinessDate(){                                                                               
		String businessDate = null;                                                                                                                                                                                               
		return businessDate;                                                                                          
	}                                                                                                                     
	  
}
