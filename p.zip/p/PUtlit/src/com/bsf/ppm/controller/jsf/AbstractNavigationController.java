package com.bsf.ppm.controller.jsf;

import java.io.Serializable;

public abstract class AbstractNavigationController<T,ID extends Serializable> extends
		AbstractCrudController<T, ID> {

	protected int currDetailItem= -1;
	private int itemsSize;
	

	public void setItemsSize(int itemsSize) {
		this.itemsSize = itemsSize;
	}

	public int getCurrDetailItem() {
		return currDetailItem;
	}

	public void setCurrDetailItem(int currDetailItem) {
		this.currDetailItem = currDetailItem;
	}
	
	public String nextMessage()	{


		if(currDetailItem==-1)	{

			currDetailItem=1;
		}else	{

			currDetailItem++;
		}
		return detailSetup();
	}

	public String prevMessage()	{


		currDetailItem--;
		return detailSetup();
	}
	public int getItemsSize() {

		if (getItems() != null) {

			return getItems().size();
		} else {
			return 0;
		}
	}
}
