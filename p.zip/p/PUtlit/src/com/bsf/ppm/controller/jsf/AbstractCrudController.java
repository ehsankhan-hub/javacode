package com.bsf.ppm.controller.jsf;

import java.io.BufferedReader;
import java.io.File;
import java.io.Serializable;
import java.sql.Clob;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;

import org.apache.log4j.Logger;

import com.bsf.ipp.GeneralConfigParameter;
import com.bsf.ipp.GeneralConfiguration;
import com.bsf.ipp.IPPUTIL;
import com.bsf.ipp.dao.PaginatedDAO;
import com.bsf.ipp.dao.jpa.SearchCondition;
import com.bsf.ppm.PpmParameterType;
import com.bsf.ppm.constants.IConstants;
import com.bsf.ppm.constants.IConstants.YesNoType;
import com.bsf.ppm.controller.CRUDController;
import com.bsf.ppm.controller.pagination.PaginationInfo;
import com.bsf.ppm.exceptions.ApplicationException;
import com.bsf.ppm.exceptions.DAOException;
import com.bsf.ppm.spring.SpringAppContext;
import com.bsf.ppm.util.Formatter;
import com.sun.faces.util.MessageFactory;

/**
 * Abstract Class for the CRUD Operations.
 * 
 * @author rsaif
 * @param <T>
 *            This is an Entity Class Name of Database model.
 * @param <ID>
 *            Unique identity Class Name
 */
public abstract class AbstractCrudController<T, ID extends Serializable>
implements CRUDController<T, ID> {
	protected static Logger log = Logger.getLogger(AbstractCrudController.class);

	private String baseDir;
	private JRDataSource  dataSource;
	public JRDataSource getDataSource() {
		return dataSource;
	}
	public void setDataSource(JRDataSource dataSource) {
		this.dataSource = dataSource;
	}
	public void setBaseDir(String baseDir) {
		this.baseDir = baseDir;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#getDAO()
	 */
	public abstract PaginatedDAO<T, ID> getDAO();

	/**
	 * List of items to be deleted. This should be implemented in subclass to
	 * get the list of items for deletion.
	 * 
	 * @return List of Items to be deleted.
	 */
	public abstract List<T> getSelectedItems();

	/**
	 * Setter for the Item
	 * 
	 * @param item
	 */
	public abstract void setItem(T item);

	/**
	 * Setter for the list of items
	 * 
	 * @param items
	 */
	public abstract void setItems(List<T> items);

	/**
	 * Getter for Item.
	 * 
	 * @return Item of type T
	 */
	public abstract T getItem();

	/**
	 * Getter for the list of items.
	 * 
	 * @return List of items of type T
	 */
	public abstract List<T> getItems();

	/**
	 * Pagination properties
	 */
	private PaginationInfo pageInfo;
	/**
	 * Field/Variable name in the Entity to sort by
	 */
	protected String sortField;
	/**
	 * The List is ordered Ascending if sortAscending is <b>true</b>. Descending
	 * if sortAscending is <b>false</b>
	 */
	protected boolean sortAscending;
	/**
	 * Search criteria Map with names of variables in Entity Object and
	 * corresponding values.
	 */
	private Map<String, Object> searchCriteria;

	private List<SearchCondition> searchCondition;

	protected int currDetailItem;

	// Report Parameters

	public String getSortField() {
		return sortField;
	}

	public void setSortField(String sortField) {
		this.sortField = sortField;
	}

	/** Attribute jasperReport for JasperReport to be created **/
	protected JasperReport jasperReport = null;

	/** Attribute jasperPrint for JasperPrint to be created **/
	protected JasperPrint jasperPrint = null;

	/** Report File object for Jasper Rpt **/
	protected File reportFile = null;

	/**
	 * Constructor for AbstractCrudController. searchCriteria and pageInfo are
	 * initialized
	 */
	public AbstractCrudController() {
		searchCriteria = new HashMap<String, Object>();
		pageInfo = new PaginationInfo();
		System.out.println("page infor"+pageInfo.getNumOfRecords());
	}

	/**
	 * Getter for the search criteria
	 * 
	 * @return Map for the search criteria
	 */
	public Map<String, Object> getSearchCriteria() {
		return searchCriteria;
	}

	public Cache generalConfigurationCache;

	public void setGeneralConfigurationCache(Cache generalConfigurationCache) {
		this.generalConfigurationCache = generalConfigurationCache;
	}

	@PostConstruct
	public void loadDefaultBatchSize(){

		GeneralConfiguration generalConfig =  getGeneralConfigByName("CCLGGeneralConfiguration");		
		String defaultBatchSize = null;

		if (generalConfig != null && generalConfig.getGeneralConfigParameters() != null
				&& generalConfig.getGeneralConfigParameters().containsKey("defaultBatchSize")){
			defaultBatchSize =  generalConfig.getGeneralConfigParameters().get("defaultBatchSize")
			.getParamValue();
		}
		try{
			if (getPageInfo() != null && defaultBatchSize != null)
				getPageInfo().setBatchSize(Integer.parseInt(defaultBatchSize));
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	private GeneralConfiguration getGeneralConfigByName(String configName) {
		if (generalConfigurationCache == null)
			generalConfigurationCache = (Cache)SpringAppContext.getBean("generalConfigurationCache");
		Element elem = generalConfigurationCache.get(configName);
		if (elem != null) {
			return (GeneralConfiguration) elem.getObjectValue();
		}
		return null;
	}
	/**
	 * Setter for the search criteria
	 * 
	 * @param searchCriteria
	 *            Map with names of variables in Entity Object and corresponding
	 *            values.
	 */
	public void setSearchCriteria(Map<String, Object> searchCriteria) {
		this.searchCriteria = searchCriteria;
	}

	public List<SearchCondition> getSearchCondition() {
		return searchCondition;
	}

	public void setSearchCondition(List<SearchCondition> searchCondition) {
		this.searchCondition = searchCondition;
	}

	@SuppressWarnings("unchecked")
	protected void convertSearchCriteria(List<SearchCondition> searchCondition,
			Map searchCriterias) {
		Iterator itr = searchCriterias.keySet().iterator();
		String key = null;

		while (itr.hasNext()) {

			key = (String) itr.next();
			searchCondition.add(new SearchCondition(key, searchCriterias
					.get(key)));
		}
	}

	/**
	 *This method used to convert search criteria key 'date' value map object to
	 *  SearchCondition object 
	 * @param stringBasedCriterias
	 * @param searchCondition
	 * @param searchCriterias
	 */
	protected void convertStringBasedSearchCriteria(
			String[] stringBasedCriterias,
			List<SearchCondition> searchCondition, Map searchCriterias) {
		for (String criteria : stringBasedCriterias) {
			Object carteriaValue = searchCriterias.get(criteria);
			if (carteriaValue != null) {
				searchCondition.add(new SearchCondition(criteria, "'"
						+ carteriaValue + "'", IConstants.SYMBOL_EQUAL));
			}
		}

	}

	/**
	 *This method used to convert search criteria key 'string' value map object to
	 *  SearchCondition object only for lower case values 
	 * @param stringBasedCriterias
	 * @param searchCondition
	 * @param searchCriterias
	 */
	protected void convertStringBasedSearchCriteriaLowerCaseValue(
			String[] stringBasedCriterias,
			List<SearchCondition> searchCondition, Map searchCriterias) {
		for (String criteria : stringBasedCriterias) {
			Object carteriaValue = searchCriterias.get(criteria);
			if (carteriaValue != null) {
				searchCondition.add(new SearchCondition(criteria, "'"
						+ carteriaValue.toString().toLowerCase() + "'", IConstants.SYMBOL_EQUAL));
			}

		}

	}

	/**
	 *This method used to convert search criteria key 'date' value map object to
	 *  SearchCondition object 
	 * @param stringBasedCriterias
	 * @param searchCondition
	 * @param searchCriterias
	 */
	protected void convertStringLikeBasedSearchCriteria(
			String[] stringBasedCriterias,
			List<SearchCondition> searchCondition, Map searchCriterias) {
		for (String criteria : stringBasedCriterias) {
			Object carteriaValue = searchCriterias.get(criteria);
			if (carteriaValue != null) {
				searchCondition.add(new SearchCondition(criteria, "'"
						+ carteriaValue + "'", IConstants.SYMBOL_LIKE));
			}

		}

	}

	/**
	 *This method used to convert search criteria key  value map object to
	 *and key value operator  object to  SearchCondition object 
	 * @param operatorBasedCriterias
	 * @param searchCondition
	 * @param searchCriterias
	 */
	protected void convertOperatorBasedSearchCriteria1(
			String[] operatorBasedCriterias,
			List<SearchCondition> searchCondition, Map searchCriterias) {
		String operator=null;
		String operatorValue=null;
		for (String criteria : operatorBasedCriterias) {
			operator=criteria.concat("Operator");
			operatorValue=searchCriterias.get(operator).toString();
			Object carteriaValue = searchCriterias.get(criteria);
			if (carteriaValue != null) {
				if(operatorValue.equalsIgnoreCase("between")){
					String secCriteria="to_".concat(criteria);
					String secCriteriaValue="to_".concat(searchCriterias.get(secCriteria).toString());
					" ".concat(carteriaValue.toString()).concat(" and ").concat(secCriteriaValue).concat(" ");

				}
				else{
					searchCondition.add(new SearchCondition(criteria, carteriaValue,searchCriterias.get(operator).toString()));
				}

			}
		}

	}

	protected void convertOperatorBasedSearchCriteria(
			String[] operatorBasedCriterias,
			List<SearchCondition> searchCondition, Map searchCriterias) {
		String operator=null;
		for (String criteria : operatorBasedCriterias) {
			operator=criteria.concat("Operator");
			Object carteriaValue = searchCriterias.get(criteria);
			if (carteriaValue != null) {
				searchCondition.add(new SearchCondition(criteria, carteriaValue,searchCriterias.get(operator).toString()));

			}
		}

	}

	protected void convertOperatorDateBasedSearchCriteria(
			String[] operatorDateBasedCriterias,
			List<SearchCondition> searchCondition, Map searchCriterias) {
		String operator,operatorValue=null;
		for (String criteria : operatorDateBasedCriterias) {
			operator=criteria.concat("Operator");
			operatorValue="=";
			if(searchCriterias.get(operator) !=null){
				operatorValue=searchCriterias.get(operator).toString();
			}
			Object carteriaValue = searchCriterias.get(criteria);
			if (carteriaValue instanceof Date) {
				searchCondition.add(new SearchCondition(criteria, carteriaValue,operatorValue,"trunc"));

			}
		}

	}
	/**
	 * @param numberBasedCriterias
	 * @param searchCondition
	 * @param searchCriterias
	 */
	protected void convertNumberBasedSearchCriteria(String[] numberBasedCriterias,List<SearchCondition> searchCondition,
			Map searchCriterias) {
		for (String criteria : numberBasedCriterias) {
			Object carteriaValue = searchCriterias.get(criteria);
			if (carteriaValue != null) {
				searchCondition.add(new SearchCondition(criteria,carteriaValue));
			}

		}

	}

	/**
	 * @param numberBasedCriterias
	 * @param searchCondition
	 * @param searchCriterias
	 */
	protected void convertRangeBasedSearchCriteria(String[] rangeBasedCriterias,List<SearchCondition> searchCondition,
			Map searchCriterias) {
		for (String criteria : rangeBasedCriterias) {

			Object from = searchCriteria.get(criteria + "From");
			Object to = searchCriteria.get(criteria + "To");
			if (from != null && from.toString().length()>0) {
				searchCondition.add(new SearchCondition(criteria, from, IConstants.SYMBOL_GREATER_OR_EQUAL));
			}
			if(to != null && to.toString().length()>0){
				searchCondition.add(new SearchCondition(criteria, to, IConstants.SYMBOL_LESS_OR_THAN));
			}		
		}

	}


	/**
	 * This method used to convert search criteria key ('date' value )map object to
	 *  SearchCondition object 
	 * @param stringBasedCriterias
	 * @param searchCondition
	 * @param searchCriterias
	 */
	protected void convertDateBasedSearchCriteria(
			String[] stringBasedCriterias,
			List<SearchCondition> searchCondition, Map searchCriterias) {
		for (String criteria : stringBasedCriterias) {
			Object carteriaValue = searchCriterias.get(criteria);
			if (carteriaValue != null) {
				if (carteriaValue instanceof String) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
					try {
						searchCondition.add(new SearchCondition(criteria,
								sdf.parse(carteriaValue.toString()),
								IConstants.SYMBOL_LESS_OR_THAN));
					} catch (java.text.ParseException e) {
						e.printStackTrace();
					}
				} else if (carteriaValue instanceof java.util.Date) {
					searchCondition.add(new SearchCondition(criteria,
							carteriaValue, IConstants.SYMBOL_LESS_OR_THAN));
				}
			}
		}
	}
	/**
	 * Getter for the paginationInfo
	 * 
	 * @return PaginationInfo
	 */
	public PaginationInfo getPageInfo() {
		return pageInfo;
	}

	/**
	 * Setter for paginationInfo
	 * 
	 * @param pageInfo
	 */
	public void setPageInfo(PaginationInfo pageInfo) {
		this.pageInfo = pageInfo;
	}

	public int getCurrDetailItem() {
		return currDetailItem;
	}

	public void setCurrDetailItem(int currDetailItem) {
		this.currDetailItem = currDetailItem;
	}
	/**
	 * This method used to reload items of list items based on current page and
	 * search criteria <br>
	 * items for list reloaded after (CRUD) operations (create , update and
	 * delete ) items and after sort or search for items
	 */
	public void reloadItems() {
		reloadItemsBySearchCriteria(getSearchCriteria());
	}
	
	
	/**
	 * This method used to reload items of list items based on current page and
	 * search criteria <br>
	 * items for list reloaded after (CRUD) operations (create , update and
	 * delete ) items and after sort or search for items
	 */
	public void reloadItemsForBlockUnblock(){
		reloadItemsBySearchCriteriaforBlockUnblock(getSearchCriteria());
	}
	/**
	 * @param searchCriteria
	 */
	protected  void reloadItemsBySearchCriteria(Map<String, Object> searchCriteria) {
		FacesMessage facesMessage = null;
		try {
             
			/*** if search criteria is set. Filter data by search criteria ***/
			if (searchCriteria != null && searchCriteria.size() > 0) {
				// Set total number of Items fetched after the search criteria
				// is applied
						
				
				getPageInfo().setNumOfRecords((int) getDAO().getResultSize(searchCriteria));

				// Add one to the number of pages, if (total records) %
				// batchSize >0
				if (getPageInfo().getNumOfRecords()
						% getPageInfo().getBatchSize() > 0) {
					getPageInfo().setNumOfPages(
							(getPageInfo().getNumOfRecords() / getPageInfo()
									.getBatchSize()) + 1);
				} else {
					// Number of pages = (total records)/batchSize.
					// getBatchSize() returns 1 even if batch size is set to
					// Zero
					getPageInfo().setNumOfPages(
							getPageInfo().getNumOfRecords()/ getPageInfo().getBatchSize());
				}
				// Set the List of Items fetched after the search
				setItems(getDAO().searchByPages(
						searchCriteria,
						(getPageInfo().getCurrentPage() * getPageInfo().getBatchSize()), getPageInfo().getBatchSize(),sortField, sortAscending));

			} else {
				/*** No search Criteria is specified ***/
				// Set total number of Items fetched after the search criteria
				// is applied
				getPageInfo().setNumOfRecords((int) getDAO().getResultSize());

				// Add one to the number of pages, if (total records) %
				// batchSize >0
				if (getPageInfo().getNumOfRecords()
						% getPageInfo().getBatchSize() > 0) {
					getPageInfo().setNumOfPages(getPageInfo().getNumOfRecords()/ getPageInfo().getBatchSize() + 1);
				} else {
					// Number of pages = (total records)/batchSize.
					// getBatchSize() returns 1 even if batch size is set to
					// Zero
					getPageInfo().setNumOfPages(getPageInfo().getNumOfRecords()/ getPageInfo().getBatchSize());
				}
				// Set the List of Items fetched
				setItems(getDAO().searchByPages((getPageInfo().getCurrentPage() * getPageInfo().getBatchSize()), getPageInfo().getBatchSize(),sortField, sortAscending));
			}
		} catch (ApplicationException e) {
			e.printStackTrace();

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.retrieve", FacesMessage.SEVERITY_ERROR, getItem());
			FacesContext.getCurrentInstance().addMessage("retrieveError",
					facesMessage);
		} catch (Exception e) {
			e.printStackTrace();
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"controller.generalException", FacesMessage.SEVERITY_ERROR,
					getEntityName(), IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);

		}
	}
    
	
	
	/**
	 * @param searchCriteria
	 */
	protected  void reloadItemsBySearchCriteriaforBlockUnblock(Map<String, Object> searchCriteria) {
		FacesMessage facesMessage = null;
		try {
              System.out.println("searchCriteria reloadItemsBySearchCriteriaforBlockUnblock=="+searchCriteria);
			/*** if search criteria is set. Filter data by search criteria ***/
			if (searchCriteria!=null&& searchCriteria.size() > 0) {
				// Set total number of Items fetched after the search criteria
				// is applied
				getPageInfo().setNumOfRecords((int) getDAO().getResultSize(searchCriteria));

				// Add one to the number of pages, if (total records) %
				// batchSize >0
				/*if (getPageInfo().getNumOfRecords()
						% getPageInfo().getBatchSize() > 0) {
					getPageInfo().setNumOfPages(
							(getPageInfo().getNumOfRecords() / getPageInfo()
									.getBatchSize()) + 1);
				} else {
					// Number of pages = (total records)/batchSize.
					// getBatchSize() returns 1 even if batch size is set to
					// Zero
					getPageInfo().setNumOfPages(
							getPageInfo().getNumOfRecords()/ getPageInfo().getBatchSize());
				}*/
				// Set the List of Items fetched after the search
				setItems(getDAO().searchByPagesWithoutPagination(searchCriteria,sortField, sortAscending));

			} else {
				//*** No search Criteria is specified ***//*
				// Set total number of Items fetched after the search criteria
				// is applied
				getPageInfo().setNumOfRecords(0);

				// Add one to the number of pages, if (total records) %
				// batchSize >0
				/*if (getPageInfo().getNumOfRecords()
						% getPageInfo().getBatchSize() > 0) {
					getPageInfo().setNumOfPages(getPageInfo().getNumOfRecords()/ getPageInfo().getBatchSize() + 1);
				} else {
					// Number of pages = (total records)/batchSize.
					// getBatchSize() returns 1 even if batch size is set to
					// Zero
					getPageInfo().setNumOfPages(getPageInfo().getNumOfRecords()/ getPageInfo().getBatchSize());
				}*/
				// Set the List of Items fetched
 				setItems(getDAO().searchByPages((0 * 0), 1,sortField, sortAscending));
				
			}
		} catch (ApplicationException e) {
			e.printStackTrace();

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.retrieve", FacesMessage.SEVERITY_ERROR, getItem());
			FacesContext.getCurrentInstance().addMessage("retrieveError",
					facesMessage);
		} catch (Exception e) {
			e.printStackTrace();
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"controller.generalException", FacesMessage.SEVERITY_ERROR,
					getEntityName(), IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);

		}
		
	}

	/**
	 * To be used in advanced search like payment queues
	 * @param searchCondition
	 * @param sortCriteria
	 */
	public void reloadItemsBySearchCondition(List<SearchCondition> searchCondition,Map<String, IConstants.SORT_ORDER> sortCriteria) {
		try {
			currDetailItem = -1;
			/*** if search criteria is set. Filter data by search criteria ***/
			if (searchCondition != null && searchCondition.size() > 0) {
				// Set total number of Items fetched after the search criteria
				// is applied
				getPageInfo().setNumOfRecords((int) getDAO().getResultSize(getSearchCondition()));

				// Add one to the number of pages, if (total records) %
				// batchSize >0
				if (getPageInfo().getNumOfRecords()% getPageInfo().getBatchSize() > 0) {
					getPageInfo().setNumOfPages((getPageInfo().getNumOfRecords() / getPageInfo().getBatchSize()) + 1);
				} else {
					// Number of pages = (total records)/batchSize.
					// getBatchSize() returns 1 even if batch size is set to
					// Zero
					getPageInfo().setNumOfPages(getPageInfo().getNumOfRecords()/ getPageInfo().getBatchSize());
				}
				// Set the List of Items fetched after the search
				setItems(getDAO().searchByPages(

						(getPageInfo().getCurrentPage() * getPageInfo().getBatchSize()), getPageInfo().getBatchSize(),searchCondition, sortCriteria));
			       System.out.println("First Page="+(getPageInfo().getCurrentPage() * getPageInfo().getBatchSize()));
			       System.out.println("Second Page="+getPageInfo().getBatchSize());
			       System.out.println("Second page part="+searchCondition+"Second page part="+ sortCriteria);
			} else {
				/*** No search Criteria is specified ***/
				// Set total number of Items fetched after the search criteria
				// is applied
				getPageInfo().setNumOfRecords((int) getDAO().getResultSize());

				// Add one to the number of pages, if (total records) %
				// batchSize >0
				if (getPageInfo().getNumOfRecords()
						% getPageInfo().getBatchSize() > 0) {
					getPageInfo().setNumOfPages(getPageInfo().getNumOfRecords()/ getPageInfo().getBatchSize() + 1);
				} else {
					// Number of pages = (total records)/batchSize.
					// getBatchSize() returns 1 even if batch size is set to
					// Zero
					getPageInfo().setNumOfPages(getPageInfo().getNumOfRecords()/ getPageInfo().getBatchSize());
				}
				// Set the List of Items fetched
				setItems(getDAO().searchByPages((getPageInfo().getCurrentPage() * getPageInfo().getBatchSize()), getPageInfo().getBatchSize(),sortCriteria));
			}
		} catch (Exception e) {
			// Set the error Message from the ResourceBundle
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"entity.retrieve", FacesMessage.SEVERITY_ERROR, getItem());
			FacesContext.getCurrentInstance().addMessage("retrieveError",
					facesMessage);
		}
	}

	public void reloadAllItemsBySearchCondition(List<SearchCondition> searchCondition,Map<String, IConstants.SORT_ORDER> sortCriteria) {
		try {
			// Set the List of Items fetched
			setItems(getDAO().findByCondition(searchCondition, sortCriteria));

		} catch (Exception e) {
			// Set the error Message from the ResourceBundle
			FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
					.getCurrentInstance(), "bundles.UIMessages",
					"entity.retrieve", FacesMessage.SEVERITY_ERROR, getItem());
			FacesContext.getCurrentInstance().addMessage("retrieveError",
					facesMessage);
		}
	}

	/**
	 * This method used to reload items of list items based on current page and
	 * search criteria if date range specified<br>
	 * items for list reloaded after (CRUD) operations (create , update and
	 * delete ) items and after sort or search for items
	 * 
	 * @param dateField
	 * @param fromDate
	 * @param toDate
	 * 
	 */
	public void reloadItemsDateRange(String dateField, String fromDate,
			String toDate) {
		FacesMessage facesMessage = null;
		try {
			
			/*** if search criteria is set. Filter data by search criteria ***/
			if (getSearchCriteria() != null && getSearchCriteria().size() > 0) {

				// Set total number of Items fetched after the search criteria
				// is applied
				getPageInfo().setNumOfRecords(
						(int) getDAO().getResultSizeDateRange(
								getSearchCriteria(), dateField, fromDate,
								toDate));
				// Add one to the number of pages, if (total records) %
				// batchSize >0
				if (getPageInfo().getNumOfRecords()
						% getPageInfo().getBatchSize() > 0) {
					getPageInfo().setNumOfPages(
							(getPageInfo().getNumOfRecords() / getPageInfo()
									.getBatchSize()) + 1);
				} else {
					// Number of pages = (total records)/batchSize.
					// getBatchSize() returns 1 even if batch size is set to
					// Zero
					getPageInfo().setNumOfPages(
							getPageInfo().getNumOfRecords()
							/ getPageInfo().getBatchSize());
				}
				// Set the List of Items fetched after the search
				setItems(getDAO().searchByPagesDateRange(
						getSearchCriteria(),
						(getPageInfo().getCurrentPage() * getPageInfo()
								.getBatchSize()), getPageInfo().getBatchSize(),
								sortField, sortAscending, dateField, fromDate, toDate));
			} else {
				/*** No search Criteria is specified ***/
				// Set total number of Items fetched after the search criteria
				// is applied
				getPageInfo().setNumOfRecords(
						(int) getDAO().getResultSizeDateRange(
								getSearchCriteria(), dateField, fromDate,
								toDate));

				// Add one to the number of pages, if (total records) %
				// batchSize >0
				if (getPageInfo().getNumOfRecords()
						% getPageInfo().getBatchSize() > 0) {
					getPageInfo().setNumOfPages(
							getPageInfo().getNumOfRecords()
							/ getPageInfo().getBatchSize() + 1);
				} else {
					// Number of pages = (total records)/batchSize.
					// getBatchSize() returns 1 even if batch size is set to
					// Zero
					getPageInfo().setNumOfPages(
							getPageInfo().getNumOfRecords()
							/ getPageInfo().getBatchSize());
				}
				// Set the List of Items fetched
				setItems(getDAO().searchByPagesDateRange(
						getSearchCriteria(),
						(getPageInfo().getCurrentPage() * getPageInfo()
								.getBatchSize()), getPageInfo().getBatchSize(),
								sortField, sortAscending, dateField, fromDate, toDate));
			}
		} catch (ApplicationException e) {

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.retrieve", FacesMessage.SEVERITY_ERROR, getItem());
			FacesContext.getCurrentInstance().addMessage("retrieveError",
					facesMessage);
		} catch (Exception e) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"controller.generalException", FacesMessage.SEVERITY_ERROR,
					getEntityName(), IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
		}

	}
    
	
	/**
	 * This method used to reload items of list items based on current page and
	 * search criteria if date range specified<br>
	 * items for list reloaded after (CRUD) operations (create , update and
	 * delete ) items and after sort or search for items
	 * 
	 * @param dateField
	 * @param fromDate
	 * 
	 */
	public void reloadItemsCurrentAndFutureDateRange(String dateField, String fromDate,String toDate) {
		FacesMessage facesMessage = null;
		try {

			/*** if search criteria is set. Filter data by search criteria ***/
			if (getSearchCriteria() != null && getSearchCriteria().size() > 0) {

				// Set total number of Items fetched after the search criteria
				// is applied
				getPageInfo().setNumOfRecords(
						(int) getDAO().getCurrentAndFutureDateRange(
								getSearchCriteria(), dateField, fromDate,
								toDate));
				// Add one to the number of pages, if (total records) %
				// batchSize >0
				if (getPageInfo().getNumOfRecords()
						% getPageInfo().getBatchSize() > 0) {
					getPageInfo().setNumOfPages(
							(getPageInfo().getNumOfRecords() / getPageInfo()
									.getBatchSize()) + 1);
				} else {
					// Number of pages = (total records)/batchSize.
					// getBatchSize() returns 1 even if batch size is set to
					// Zero
					getPageInfo().setNumOfPages(
							getPageInfo().getNumOfRecords()
							/ getPageInfo().getBatchSize());
				}
				// Set the List of Items fetched after the search
				setItems(getDAO().searchByPagesCurrentAndFutureDateRange(
						getSearchCriteria(),
						(getPageInfo().getCurrentPage() * getPageInfo()
								.getBatchSize()), getPageInfo().getBatchSize(),
								sortField, sortAscending, dateField, fromDate, toDate));
			} else {
				/*** No search Criteria is specified ***/
				// Set total number of Items fetched after the search criteria
				// is applied
				System.out.println("toDate==="+toDate);
				getPageInfo().setNumOfRecords(
						(int) getDAO().getCurrentAndFutureDateRange(
								getSearchCriteria(), dateField, fromDate,
								toDate));

				// Add one to the number of pages, if (total records) %
				// batchSize >0
				if (getPageInfo().getNumOfRecords()
						% getPageInfo().getBatchSize() > 0) {
					getPageInfo().setNumOfPages(
							getPageInfo().getNumOfRecords()
							/ getPageInfo().getBatchSize() + 1);
				} else {
					// Number of pages = (total records)/batchSize.
					// getBatchSize() returns 1 even if batch size is set to
					// Zero
					getPageInfo().setNumOfPages(
							getPageInfo().getNumOfRecords()
							/ getPageInfo().getBatchSize());
				}
				// Set the List of Items fetched
setItems(getDAO().searchByPagesDateRange(getSearchCriteria(),(getPageInfo().getCurrentPage() * getPageInfo().getBatchSize()), getPageInfo().getBatchSize(),
								sortField, sortAscending, dateField, fromDate, toDate));
			}
		} catch (ApplicationException e) {
			e.printStackTrace();

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.retrieve", FacesMessage.SEVERITY_ERROR, getItem());
			FacesContext.getCurrentInstance().addMessage("retrieveError",
					facesMessage);
		} catch (Exception e) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"controller.generalException", FacesMessage.SEVERITY_ERROR,
					getEntityName(), IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
		}

	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#listSetup()
	 */
	public String listSetupString() {

		// Initialize default values for SearchCriteria and PageInfo
		if (getSearchCriteria() != null) {
			setSearchCriteria(new HashMap<String, Object>());
			getSearchCriteria().put(getStatusFieldName(),"A");
		}
		// Set 0 as the first page
		if (getPageInfo() != null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		reloadItems();
		// returns the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#listSetup()
	 */
	public String listSetup() {

		// Initialize default values for SearchCriteria and PageInfo
		if (getSearchCriteria() != null) {
			setSearchCriteria(new HashMap<String, Object>());
			getSearchCriteria().put(getStatusFieldName(),
					Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
		}
		// Set 0 as the first page
		if (getPageInfo() != null)
			getPageInfo().setCurrentPage(0);
		// Load the items in the list
		reloadItems();
		// returns the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#next()
	 */
	public String next() {

		// Set the page number in PaginationInfo
		getPageInfo().setCurrentPage(getPageInfo().getCurrentPage() + 1);

		// Reload the items in the list
		reloadItems();

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#prev()
	 */
	public String prev() {

		// Set the page number in PaginationInfo
		if (getPageInfo().getCurrentPage() > 0) {
			getPageInfo().setCurrentPage(getPageInfo().getCurrentPage() - 1);
		}
		// Reload the items in the list
		reloadItems();

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#cancel()
	 */
	public String cancel() {

		// Set the page number in PaginationInfo to Zero
		// getPageInfo().setCurrentPage(0);

		// Reload the items in the list
		reloadItems();

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#create()
	 */
	public String create() {
		FacesMessage facesMessage = null;

		try {
			// Create the Item in the Database
			if (isUnique()) {
				getDAO().save(getItem());
				// getDAO().refresh(getItem());

			} else {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"entity.duplicate", FacesMessage.SEVERITY_ERROR,
						getEntityName());
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return null; 

			}

		} catch (ApplicationException e) {
			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.add.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);

			// Return Navigation case of the create page
			return null;
		} catch (Exception e) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"controller.generalException", FacesMessage.SEVERITY_ERROR,
					getEntityName(), IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			return null;

		}
		// Initialize the Search Criteria

		// searchCriteria = new HashMap<String, Object>();

		// Reload the items in the list displayed to the user
		reloadItems();
		getPageInfo().setCurrentPage(0);

		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.add.success", getEntityName(),
				getItem());
		FacesContext.getCurrentInstance()
		.addMessage("successAdd", facesMessage);
		// Return navigation case of the list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#isUnique()
	 */
	public boolean isUnique() {
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#editSetup()
	 */
	public String editSetup() {
		// return the Navigation case for list page

		return getClass().getSimpleName() + IConstants.CRUD_EDIT_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#update()
	 */
	public String update() {
		FacesMessage facesMessage = null;
		try {
			// update the Item in the Database Table
			if (isUniqueForUpdate()) {
				getDAO().saveOrUpdate(getItem());

			} else {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"entity.duplicate", FacesMessage.SEVERITY_ERROR,
						getItem());
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";
			}
		} catch (ApplicationException e) {
			log.warn("System failed to update ",e);

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.update.error", FacesMessage.SEVERITY_ERROR,
					getEntityName(), getItem());
			FacesContext.getCurrentInstance().addMessage("createError",
					facesMessage);

			// Return the navigation case for edit page
			return "";
		} catch (Exception e) {
			log.warn("System failed to update ",e);

			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"controller.generalException", FacesMessage.SEVERITY_ERROR,
					getEntityName(), IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			return "";

		}
		// Set the page number to Zero
		getPageInfo().setCurrentPage(0);

		// Set the search criteria
		// searchCriteria = new HashMap<String, Object>();

		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.update.success", getEntityName(),
				getItem());
		FacesContext.getCurrentInstance()
		.addMessage("successAdd", facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/**
	 * @return result of the unique checking
	 */
	public boolean isUniqueForUpdate() {
		return true;
	}

	/**
	 * Fetch the number of pages to display as a List
	 * 
	 * @return List of Pages as numbers
	 */
	public List<SelectItem> getPagesList() {
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		int i = 0;
		// Build the list with page numbers
		do {
			list.add(new SelectItem(String.valueOf(i), String.valueOf(i + 1)));
			i++;
		} while (i < (getPageInfo().getNumOfPages()));
		return list;
	}

	/**
	 * Prepares search criteria that is used in method reloadItems Specify the
	 * initial criteria to be set for fetching the list
	 * 
	 * @return
	 */
	public Map<String, Object> prepareSearchCriteria() {
		Map<String, Object> newSearchMap = new HashMap<String, Object>();

		// Get the Map from the search criteria
		Iterator<Map.Entry<String, Object>> iterator = getSearchCriteria()
		.entrySet().iterator();

		// Build the Map for the search criteria. Select non empty entries in
		// the Map.
		Map.Entry<String, Object> mapEntry = null;
		Object value = null;
		while (iterator.hasNext()) {
			mapEntry = iterator.next();
			value = mapEntry.getValue();
			if (value instanceof Object) {
				
				if (value instanceof Long) {
					if (Long.valueOf(value.toString()) > -1)
						newSearchMap
						.put(mapEntry.getKey(), mapEntry.getValue());
				} else if (value.toString().trim().length() > 0) {
					newSearchMap.put(mapEntry.getKey(), mapEntry.getValue());
				}
			}
		}
		return newSearchMap;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#searchSetup()
	 */
	public String searchSetup() {

		// Set PageInfo with current Page 0
		getPageInfo().setCurrentPage(0);

		// Set the search criteria
		setSearchCriteria(prepareSearchCriteria());

		// Reload the items in the list
		reloadItems();
		
		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/**
	 * Method to clear search criteria and reset for navigation to list page
	 * Reloads the items to be displayed in the list
	 * 
	 * @return Navigation Case for List Page
	 */
	public String resetSearchCriteria() {
		searchCriteria = new HashMap<String, Object>();
		// Set PageInfo with current Page 0
		getPageInfo().setCurrentPage(0);

		// Reload the items in the list
		reloadItems();

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/**
	 * Method to sort table based on sort field attribute
	 * 
	 * @param ActionEvent
	 *            ActionEvent that triggered the event
	 */
	public void sortMyList(ActionEvent event) {

		// Get sort field name
		String sortFieldAttribute = JSFUtil.getAttribute(event, "sortField");
		if (sortField == null || !sortField.equals(sortFieldAttribute)) {
			sortField = sortFieldAttribute;
		}
		// Sort Ascending/ Descending
		sortAscending = !sortAscending;

		// Sort the list
		if (sortField != null) {

			// Set PageInfo with current Page 0
			getPageInfo().setCurrentPage(0);

			// Reload the items in the list
			reloadItems();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#deleteItem()
	 */
	public String deleteItem() {
		FacesMessage facesMessage = null;
		try {
			// Delete the item from the database
			getDAO().delete(getItem());
		} catch (DAOException e) {

			// Set the error Message from the ResourceBundle
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.deleteItem.error", FacesMessage.SEVERITY_ERROR,
					getItem(), getEntityName());
			FacesContext.getCurrentInstance().addMessage("entity.deleteItem",
					facesMessage);
			return "";
		} catch (Exception e) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"controller.generalException", FacesMessage.SEVERITY_ERROR,
					getEntityName(), IPPUTIL.buildExceptionMessage(e));
			FacesContext.getCurrentInstance().addMessage(null, facesMessage);
			return "";

		}
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.deleteItem.success",
				getEntityName(), getItem(), getEntityName());
		FacesContext.getCurrentInstance().addMessage("successDeleteItem",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#deleteItems()
	 */
	public String deleteItems() {
		
	
		
		FacesMessage facesMessage = null;
		if (getSelectedItems() == null || getSelectedItems().size() < 1) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		// Fetch the items to be deleted.
		List<T> itemsFordelete = getSelectedItems();

		if (itemsFordelete != null && itemsFordelete.size() > 0) {
			try {
				// Delete the items from the Database Table
				getDAO().delete(itemsFordelete);

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"entity.deleteItems.error",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance().addMessage("deleteItems",
						facesMessage);
				return "";

			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.deleteItems.success",
				itemsFordelete.size(), getEntityName());
		FacesContext.getCurrentInstance().addMessage("successDeleteItems",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/**
	 * Loads the ITems and returns the navigation case to list page
	 * 
	 * @return
	 */
	public String displayPage() {
		reloadItems();
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItem()
	 */
	public String disableItem() {
		FacesMessage facesMessage = null;
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getItem());

		if (idArrays != null && idArrays.length > 0) {
			try {
				getDAO()
				.updateEntityStatusByIds(
						idArrays,
						getIdFieldName(),
						getStatusFieldName(),
						Long.valueOf(IConstants.STATUS_TYPE.INACTIVE
								.ordinal()),
								JSFUtil.getLoggedInUserInfo());

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil
				.getMessage(FacesContext.getCurrentInstance(),
						"bundles.UIMessages",
						"entity.deActivateItem.error",
						FacesMessage.SEVERITY_ERROR, getItem(),
						getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"entity.deleteItem", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.deActivateItem.success",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage("successDeleteItem",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItem()
	 */
	public String enableItem() {
		FacesMessage facesMessage = null;
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getItem());
		System.out.println("=====AbstractCrudController. enableItem ");
		if (idArrays != null && idArrays.length > 0) {
			try {
				// Delete the items from the Database Table
				// getStatusFieldName should be implemented in subclass
				getDAO().updateEntityStatusByIds(idArrays, getIdFieldName(),
						getStatusFieldName(),
						Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()),
						JSFUtil.getLoggedInUserInfo());

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil
				.getMessage(FacesContext.getCurrentInstance(),
						"bundles.UIMessages",
						"entity.activateItem.error",
						FacesMessage.SEVERITY_ERROR, getItem(),
						getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"activateItem.error", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.activateItem.success",
				getEntityName(), getItem());
		FacesContext.getCurrentInstance().addMessage(
				"itemActivatedSuccessfully", facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItems()
	 */
	public String disableItems() {
		FacesMessage facesMessage = null;
		if (getSelectedItems() == null || getSelectedItems().size() < 1) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getSelectedItems());
		System.out.println("=====AbstractCrudController. disableItems ");
		if (idArrays != null && idArrays.length > 0) {
			try {
				// Delete the items from the Database Table
				// getStatusFieldName should be implemented in subclass
				getDAO()
				.updateEntityStatusByIds(
						idArrays,
						getIdFieldName(),
						getStatusFieldName(),
						Long.valueOf(IConstants.STATUS_TYPE.INACTIVE
								.ordinal()),
								JSFUtil.getLoggedInUserInfo());
			} catch (DAOException e) {
				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"entity.deActivateItems.error",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance().addMessage(
						"deActivateItemsError", facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		getPageInfo().setCurrentPage(0);
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.deActivateItems.success",
				idArrays.length, getEntityName());
		FacesContext.getCurrentInstance().addMessage("successDeleteItems",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bsf.ppm.controller.CRUDController#disableItems()
	 */
	public String enableItems() {
		FacesMessage facesMessage = null;
		if (getSelectedItems() == null || getSelectedItems().size() < 1) {
			facesMessage = JSFUtil.getMessage(
					FacesContext.getCurrentInstance(), "bundles.UIMessages",
					"entity.noRowSelected", FacesMessage.SEVERITY_ERROR,
					getEntityName());
			FacesContext.getCurrentInstance().addMessage("noRow", facesMessage);
			return "";
		}
		// Fetch the items to be deleted.
		String[] idArrays = getIDsArray(getSelectedItems());
		System.out.println("=====AbstractCrudController. enableItems ");
		if (idArrays != null && idArrays.length > 0) {
			try {
				// Delete the items from the Database Table
				// getStatusFieldName should be implemented in subclass
				getDAO().updateEntityStatusByIds(idArrays, getIdFieldName(),
						getStatusFieldName(),
						Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()),
						JSFUtil.getLoggedInUserInfo());

			} catch (DAOException e) {

				// Set the error Message from the ResourceBundle
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"entity.activateItems.error",
						FacesMessage.SEVERITY_ERROR, getEntityName());
				FacesContext.getCurrentInstance().addMessage("activatItems",
						facesMessage);
				return "";
			} catch (Exception e) {
				facesMessage = JSFUtil.getMessage(FacesContext
						.getCurrentInstance(), "bundles.UIMessages",
						"controller.generalException",
						FacesMessage.SEVERITY_ERROR, getEntityName(), IPPUTIL
						.buildExceptionMessage(e));
				FacesContext.getCurrentInstance()
				.addMessage(null, facesMessage);
				return "";

			}
		}
		getPageInfo().setCurrentPage(0);
		// Reload the items in the list
		reloadItems();
		facesMessage = JSFUtil.getMessage(FacesContext.getCurrentInstance(),
				"bundles.UIMessages", "entity.activateItems.success",
				idArrays.length, getEntityName());
		FacesContext.getCurrentInstance().addMessage("successActivateItems",
				facesMessage);

		// return the Navigation case for list page
		return getClass().getSimpleName() + IConstants.CRUD_LIST_NAVIGATION;
	}

	/**
	 * Override this method if indent to use the disable() method
	 * 
	 * @param itemsToDelete
	 * @return String array of the Ids of the item
	 */
	public String[] getIDsArray(List<T> itemsToDelete) {
		throw new UnsupportedOperationException(
		"Method  getIDsArray() not supported   ");
	}

	/**
	 * Override this method if indent to use the disable() method on a single
	 * item
	 * 
	 * @param item
	 * @return String array of the Id of the item
	 */
	public String[] getIDsArray(T item) {
		throw new UnsupportedOperationException(
		"Method  getIDsArray() not supported  ");
	}

	/**
	 * Returns List of Status as SelectItem to be displayed in search criteria
	 * 
	 * @return List of Status Items for the Select Options
	 */
	public List<SelectItem> getStatusList() {
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		IConstants.STATUS_TYPE[] statusArray = IConstants.STATUS_TYPE.values();
		for (int i = 0; i < IConstants.STATUS_TYPE.values().length; i++) {
			list.add(new SelectItem(Long.valueOf(statusArray[i].ordinal()),
					statusArray[i].name()));
		}
		Iterator itr=list.iterator();
		while(itr.hasNext()){
			SelectItem si=(SelectItem)itr.next();
		}
		
		return list;
	}

	/**
	 * Fetch the status criteria selected by the Actor and check if it is ACTIVE
	 * 
	 * @return true if the status criteria is ACTIVE else false
	 */
	public boolean isSearchCriteriaActiveString() {
		String status = (String) getSearchCriteria().get(getStatusFieldName());
		if(status!=null){
		return (status.equals("A"));
		}
		else{
		return true;
		}

	}

	
	/**
	 * Fetch the status criteria selected by the Actor and check if it is ACTIVE
	 * 
	 * @return true if the status criteria is ACTIVE else false
	 */
	public boolean isSearchCriteriaActive() {
		long status = (Long) getSearchCriteria().get(getStatusFieldName());
		return (status == Long.valueOf(IConstants.STATUS_TYPE.ACTIVE.ordinal()));
		
	}

	
	/**
	 * Override this method to fetch the Entity name. This name is displayed in
	 * the messages displayed.
	 * 
	 * @return Name of the entity used in the Controller
	 */
	public String getEntityName() {
		return "";
	}

	/**
	 * Override this method if indent to use the disable() method and the id
	 * field is not default ID (default=id)
	 * 
	 * @return
	 */
	public String getIdFieldName() {
		return IConstants.DEFAULT_ID_FIELD;
	}

	/**
	 * Override this method if indent to use the disable() method and the status
	 * field is not default status (status)
	 * 
	 * @return
	 */
	public String getStatusFieldName() {
		return IConstants.DEFAULT_STATUS_FIELD;

	}

	protected void setupReportParameters(String reportFileName) {

		FacesContext context = FacesContext.getCurrentInstance();
		ExternalContext ec = context.getExternalContext();
		HttpServletRequest request = (HttpServletRequest) ec.getRequest();
		ServletContext application = request.getSession().getServletContext();
		reportFile = new File(application.getRealPath("/report/"
				+ reportFileName));

		try {
			jasperReport = (JasperReport) JRLoader.loadObject(reportFile
					.getPath());
		} catch (JRException e) {
			log.warn("setupReportParameters Error:" + e.getMessage());
		}
	}

	protected void registerJasperPrint(java.util.Map repParameters, List rptList) {

		JRBeanCollectionDataSource source = new JRBeanCollectionDataSource(
				rptList);
		try {
			jasperPrint = JasperFillManager.fillReport(jasperReport,
					repParameters, source);
			HttpServletRequest request = (HttpServletRequest) FacesContext
			.getCurrentInstance().getExternalContext().getRequest();

			Map imagesMap = new HashMap();
			request.getSession().setAttribute("IMAGES_MAP", imagesMap);
			request.getSession(false).setAttribute("report", jasperPrint);
			JasperExportManager.exportReportToPdfFile(jasperPrint, "C:\\Simple_Report.pdf");
		} catch (Exception e) {

			log.warn("registerJasperPrint Error:" + e.getMessage());
		}
	}

	public boolean isSortAscending() {
		return sortAscending;
	}

	public void setSortAscending(boolean sortAscending) {
		this.sortAscending = sortAscending;
	}

	protected String vaildateChars(String value, FacesContext context,
			String componentId) {
		if (value != null) {
			FacesMessage message = null;
			value = value.trim();
			if (value == null) {
				message = MessageFactory.getMessage(context,
						"entity.add.error.invalidChar",
						FacesMessage.SEVERITY_ERROR, componentId, value
						+ "......");
				throw new ValidatorException(message);
			}
			Pattern p = Pattern.compile(IConstants.INVALIDCHAR);
			Matcher m = p.matcher(value.toString());
			if (m.find()) {
				if (value.toString().length() > 30)
					value = value.toString().substring(0, 25);
				context.getApplication().setMessageBundle(
				"bundles.ValidatorMessages");
				message = MessageFactory.getMessage(context,
						"entity.add.error.invalidChar",
						FacesMessage.SEVERITY_ERROR, componentId, value
						+ "......");
				throw new ValidatorException(message);
			}
		}
		return value;
	}

	public String getBaseDir(){
		FacesContext context = FacesContext.getCurrentInstance();
		ExternalContext ec = context.getExternalContext();
		HttpServletRequest request = (HttpServletRequest) ec.getRequest();
		ServletContext application = request.getSession().getServletContext();
		File baseDir = new File(application.getRealPath("/"));
		System.out.println("baseDir===="+baseDir);
		return baseDir.getPath();

	}
    
	/**
	 * Returns List of Status as SelectItem to be displayed in search criteria
	 * 
	 * @return List of applications names Items for the Select Options
	 */
	public List<SelectItem> getApplicationList() {
		ArrayList<SelectItem> list = new ArrayList<SelectItem>();
		IConstants.MODULE_NAME[] statusArray = IConstants.MODULE_NAME.values();
		for (int i = 1; i < IConstants.MODULE_NAME.values().length; i++) {
			list.add(new SelectItem(statusArray[i].name(),
					statusArray[i].name()));
		}
		return list;
	}

	protected  List<GeneralConfigParameter>  getGeneralConfigParameterList(String configName){
		GeneralConfiguration  generalConfiguration = getGeneralConfigByName(configName);
		if(generalConfiguration !=null && generalConfiguration.getGeneralConfigParameters() !=null)
			return new ArrayList<GeneralConfigParameter>(generalConfiguration.getGeneralConfigParameters().values());
		return null;
	}
	
	protected void addItemErrorMsg(String errorCode, Object... params) {
		FacesMessage facesMessage = JSFUtil.getMessage(FacesContext
				.getCurrentInstance(), "bundles.UIMessages", errorCode,
				FacesMessage.SEVERITY_ERROR, params);
		FacesContext.getCurrentInstance().addMessage(null, facesMessage);

	}
	/**
	 * @return
	 */
	public ArrayList<SelectItem> getYesNoList() {
		ArrayList<SelectItem> yesNoList = new ArrayList<SelectItem>();
		YesNoType[] yesNo = YesNoType.values();
		for (YesNoType ynt : yesNo) {
			yesNoList.add(new SelectItem(ynt.name(), ynt.name()));
		}
		return yesNoList;
	}
	/**
	 * @param swiftMessage
	 * @param lineSeparator
	 * @return
	 * @throws Exception
	 */
	protected String converClobToString(Clob swiftMessage,String lineSeparator) throws Exception {
		BufferedReader reader = null;
		reader = new BufferedReader(swiftMessage.getCharacterStream());
		StringBuilder sb = new StringBuilder();				            
		String line; 	 
		while ((line = reader.readLine()) != null) { 
			sb.append(line).append(lineSeparator);					
		}
		return sb.toString();
	}
	
	public String getFormattedAmount(Double formatAmount, Long precision) {
		
		String value = "";
		if (precision !=null)	
			//value = Formatter.format("%20."+getPrecision()+"f", amount);
			value = Formatter.format("%20."+precision+"f", formatAmount);
		else
			value = Formatter.format("%20.2f", formatAmount);
		
		return value = value.trim();
	}
}
