package com.bsf.ppm.controller.jsf;


/**
 * @author Rakesh
 * Defines behavior Selectable for the entities.
 */
public interface Selectable {
	/**
	 * Returns the select status of the Entity. 
	 * @return selected state returns true if the item is selected
	 */
	public boolean isSelected();
	
	/**
	 * Setter for the Selected state 
	 * @param selected
	 */
	public void setSelected(boolean selected);
}
