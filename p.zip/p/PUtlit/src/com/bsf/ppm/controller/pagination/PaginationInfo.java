package com.bsf.ppm.controller.pagination;

/**
 * @author Rashad
 * Pagination Information for List display pages. Defines attributes for pagination
 *
 */
public class PaginationInfo {
	/**
	 * Attribute currentPage Current page displayed
	 */
	private int currentPage;
	/**
	 * Attribute batchSize Number of items displayed in a page.
	 */
	private int batchSize = 15;
	/**
	 * Attribute numOfPages Number of pages the items would be listed with the set batchSize
	 */
	private int numOfPages;
	/**
	 * Attribute numOfRecords Total number of records fetched that are to be paginated.
	 */
	private int numOfRecords;
	
	private String recordRange;
	
	public String getRecordRange() {
		
		int curPageStartRecord = 0;
		int currPageEndRecord = 0;
		if(numOfRecords >  0)	{
			
			if(currentPage==0)	{
				
				curPageStartRecord = 1;
				if(numOfRecords < batchSize){
				
					currPageEndRecord = numOfRecords;
				}else	{
					
					if((numOfRecords - curPageStartRecord) <  batchSize)	{
						
						currPageEndRecord = curPageStartRecord+ (numOfRecords - curPageStartRecord);
					}
					else	{	
						currPageEndRecord = batchSize;
					}
				}
			}else{
				if(currentPage==1)	{
					curPageStartRecord = (currentPage*(batchSize+1));
					if((numOfRecords - curPageStartRecord) <  batchSize)	{
						
						currPageEndRecord = curPageStartRecord+ (numOfRecords - curPageStartRecord);
					}else	{
						
						currPageEndRecord = curPageStartRecord + batchSize-1;
					}
				}else	{
					
					curPageStartRecord = (currentPage*(batchSize));
					if((numOfRecords - curPageStartRecord) <  batchSize)	{
						
						currPageEndRecord = curPageStartRecord+ (numOfRecords - curPageStartRecord);
					}else	{
						currPageEndRecord = curPageStartRecord + batchSize;
					}
				}
			}
		}
		
		
		return curPageStartRecord  +"-"+ currPageEndRecord;
	}
	
	
	public int getRecordRangeStart() {
		
		int curPageStartRecord = 0;
		int currPageEndRecord = 0;
		if(numOfRecords >  0)	{
			
			if(currentPage==0)	{
				
				curPageStartRecord = 1;
				if(numOfRecords < batchSize){
				
					currPageEndRecord = numOfRecords;
				}else	{
					
					if((numOfRecords - curPageStartRecord) <  batchSize)	{
						
						currPageEndRecord = curPageStartRecord+ (numOfRecords - curPageStartRecord);
					}
					else	{	
						currPageEndRecord = batchSize;
					}
				}
			}else{
				if(currentPage==1)	{
					curPageStartRecord = (currentPage*(batchSize+1));
					if((numOfRecords - curPageStartRecord) <  batchSize)	{
						
						currPageEndRecord = curPageStartRecord+ (numOfRecords - curPageStartRecord);
					}else	{
						
						currPageEndRecord = curPageStartRecord + batchSize-1;
					}
				}else	{
					
					curPageStartRecord = (currentPage*(batchSize));
					if((numOfRecords - curPageStartRecord) <  batchSize)	{
						
						currPageEndRecord = curPageStartRecord+ (numOfRecords - curPageStartRecord);
					}else	{
						currPageEndRecord = curPageStartRecord + batchSize;
					}
				}
			}
		}
		
		
		return curPageStartRecord;
	}

	public void setRecordRange(String recordRange) {
		this.recordRange = recordRange;
	}

	/**
	 * Getter method for numOfRecords
	 * @return numOfRecords Number of records
	 */
	public int getNumOfRecords() {
		return numOfRecords;
	}

	/**
	 * Setter method for numOfRecords
	 * @param numOfRecords Number of records
	 */
	public void setNumOfRecords(int numOfRecords) {
		this.numOfRecords = numOfRecords;
	}

	/**
	 * Getter method for currentPage
	 * @return currentPage Current page displayed
	 */
	public int getCurrentPage() {
		if(currentPage>=numOfPages)
			currentPage= numOfPages-1;
		if(currentPage<0)
			currentPage=0;
		return currentPage;
	}
	/**
	 * Setter method for currentPage
	 * @param currentPage Current page displayed
	 */
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	/**
	 * Getter method for batchSize
	 * @return batchSize Number of items displayed in a page
	 */
	public int getBatchSize() {
		return (batchSize ==0)? 1 : batchSize; // Added to avoid Divide by Zero, while calculating number of pages
	}
	/**
	 * @param batchSize
	 */
	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}
	/**
	 * @return
	 */
	public int getNumOfPages() {
		return numOfPages;
	}
	/**
	 * @param numOfPages
	 */
	public void setNumOfPages(int numOfPages) {
		this.numOfPages = numOfPages;
	}
	

}
