package com.bsf.ppm.threadpool;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.apache.log4j.Logger;
import org.apache.commons.pool.ObjectPool;
import org.apache.commons.pool.PoolableObjectFactory;

/**
 * This class will maintain a simple pool of object instances.
 * It internally used a <code>HashSet</code>
 */
public class BasicObjectPool implements ObjectPool {
	private static Logger logger = 
			Logger.getLogger(BasicObjectPool.class.getName());

	private PoolableObjectFactory factory;
	private Config config;
	private Set activeObjects, idleObjects;
	private volatile boolean inMaintain = false;

	public BasicObjectPool() {
		activeObjects = Collections.synchronizedSet(new HashSet());
		idleObjects = Collections.synchronizedSet(new HashSet());
		config = new Config();
	}
	public BasicObjectPool(PoolableObjectFactory factory, 
			BasicObjectPool.Config config) {
		this();
		this.factory = factory;
		if(config!=null) this.config = config;
	}

	public void addObject() throws Exception {
		if(config.maxIdle==-1 || config.maxIdle > getNumIdle()) 
			idleObjects.add(factory.makeObject());
		else
			maintain();
	}
	
	public Object borrowObject() throws Exception {
		if(getNumIdle()<=0 && 
			(config.maxActive==-1 || config.maxActive > getNumActive()) ) {
			addObject();
		}
		Object obj = idleObjects.iterator().next();
		idleObjects.remove(obj);
		if(obj==null) throw new NullPointerException("No free objects");
		factory.activateObject(obj);
		activeObjects.add(obj);
		return obj;
	}

	/**Clears any objects sitting idle in the pool*/
	public void clear() {
		Iterator iterator = idleObjects.iterator();
		while(iterator.hasNext()) {
			try	{
				invalidateObject(iterator.next());	
			} catch(Exception e) {
				logger.warn("Error in BasicObjectPool.clear : "+e);
			}			
		}
		idleObjects.clear();
	}

	/**Close this pool, and free any resources associated with it.*/
	public void close() throws Exception {
		clear();
		/*
		Iterator iterator = activeObjects.iterator();
		while(iterator.hasNext()) {
			try {
				invalidateObject(iterator.next());
			} catch(Exception e) {
				logger.warning("Error in BasicObjectPool.close : "+e);
			}
		}
		*/
		activeObjects.clear();
	}

	/**Return the number of instances currently borrowed from my pool */
	public int getNumActive() {
		return activeObjects.size();
	}
	/**Return the number of instances currently idle in my pool */
	public int getNumIdle() {
		return idleObjects.size();
	}
	
	/**Invalidates an object from the pool */
	public void invalidateObject(Object obj) throws Exception {
		factory.destroyObject(obj);
	}

	/**Return an instance to my pool*/
	public void returnObject(Object obj) throws Exception {
		activeObjects.remove(obj);
		if(factory.validateObject(obj)==false) {			
			return;
		}
		factory.passivateObject(obj);
		idleObjects.add(obj);
		if(config.maxIdle!=-1 && config.maxIdle < getNumIdle()) {
			maintain();
		}
	}
	
	/**Sets the factory I use to create new instances */
	public void setFactory(PoolableObjectFactory factory) {
		this.factory = factory;
	}

	private void maintain() {
		if(inMaintain==true) {
			return;
		}
		inMaintain = true;
		logger.debug("Starting maintain: "+getNumIdle());
		while(getNumIdle()>config.maxIdle) {
			try {
				synchronized(idleObjects) {
					Object obj = idleObjects.iterator().next();
					idleObjects.remove(obj);
					invalidateObject(obj);
				}
			} catch(Exception e) {
				logger.warn("Error in BasicObjectPool.maintain : "+e);
			}
		}
		inMaintain = false;
		logger.debug("Finished maintain: "+getNumIdle());
	}

	public static class Config {
		public int maxActive = 4;
		public int maxIdle = 4;
	}

	/**
	 * Returns the iterator of all active objects
	 * @since 1.3.1
	 */
	public Iterator getAllActiveObjects() {
		Set _set = new HashSet();
		_set.addAll(activeObjects);
		return _set.iterator(); //*/activeObjects.iterator();
	}
}
