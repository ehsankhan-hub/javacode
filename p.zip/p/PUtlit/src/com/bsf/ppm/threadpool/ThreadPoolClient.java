package com.bsf.ppm.threadpool;

/**
 * Any client which needs to run in thread pool should implement this interface
 * @author Rakesh
 *
 */
public interface ThreadPoolClient {
	/**
	 * This method is called by the worker thread.
	 * All processinglogic should go here.
	 */
	public void runInThread();
}
