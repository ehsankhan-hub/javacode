package com.bsf.ppm.threadpool;

/**
 * This class encapsulate the Object pool configuration.
 * The xml is &lt;object-pool&gt;...&lt;/object-pool&gt;
 */
public class ObjectPoolConfig {
	private int maxActive = -1;
	private int maxIdle = 10;

	/**
     * Returns the maximum active objects allowed in the pool.
     * @see #setMaxActive
	 * @since 1.3
     */
	public int getMaxActive() {
		return maxActive;
	}
    /**
     * Sets the maximum active objects allowed in the pool.
	 * XML Tag: &lt;max-activ&gt;&lt;/max-activ&gt;
     * @param maximum allowed active objects	 
     * @see #getMaxActive
	 * @since 1.3
     */
	public void setMaxActive(int maxActive) {
		this.maxActive = maxActive;
	}

	/**
     * Returns the maximum idle objects allowed in the pool.
     * @see #setMaxIdle
	 * @since 1.3
     */
	public int getMaxIdle() {
		return maxIdle;
	}
    /**
     * Sets the maximum Idle objects allowed in the pool.
	 * XML Tag: &lt;max-idle&gt;&lt;/max-idle&gt;
     * @param maximum allowed active objects
     * @see #getMaxIdle
	 * @since 1.3
     */
	public void setMaxIdle(int maxIdle) {
		this.maxIdle = maxIdle;
	}

	/**
	 * Returns XML config of this class.
	 * @since 1.3
	 */
	public String toXML(String pad) {
		if(pad==null) pad="";
		StringBuffer sb = new StringBuffer();
		sb.append(pad+"<object-pool>\n");
		sb.append(pad+"\t<max-active>"+getMaxActive()+"</max-active>\n");
		sb.append(pad+"\t<max-idle>"+getMaxIdle()+"</max-idle>\n");
		sb.append(pad+"</object-pool>\n");
		return sb.toString();
	}
}
