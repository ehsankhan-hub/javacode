package com.bsf.ppm.threadpool;

import org.apache.commons.pool.BasePoolableObjectFactory;

/**
 * Class to create threads for thread pool
 * @author Rakesh
 *
 */
public class ThreadObjectFactory extends BasePoolableObjectFactory {
	
    private RequestWorkerPool pool;
	private static int instanceCount = 0;
	private int id = -1;

	public ThreadObjectFactory(RequestWorkerPool pool) {
		super();
		this.pool=pool;
		id = ++instanceCount;
	}

	//Creates an instance that can be returned by the pool. 
	public Object makeObject() { 
        return new RequestWorkerThread(pool, id);
	} 

	//Uninitialize an instance to be returned to the pool. 
    public void passivateObject(Object obj) { 
    } 

	//Reinitialize an instance to be returned by the pool. 
    public void activateObject(Object obj) {
	}
	
	//Destroys an instance no longer needed by the pool. 
	public void destroyObject(Object obj) {
		if(obj==null) return;
		Thread thread = (Thread) obj;
		thread.interrupt();
		thread = null;
	}

	//Ensures that the instance is safe to be returned by the pool. 
	public boolean validateObject(Object obj) {
		if(obj==null) return false;
		Thread thread = (Thread)obj;
		return thread.isAlive();
	}
}
