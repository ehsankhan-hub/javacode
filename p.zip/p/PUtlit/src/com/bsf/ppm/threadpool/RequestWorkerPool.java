package com.bsf.ppm.threadpool;

import java.util.Iterator;
import org.apache.log4j.Logger;

import org.apache.commons.pool.ObjectPool;

/**
 * Thread pool to handle services coming through incoming swift and sarie channels
 * @author rakesh
 *
 */
public class RequestWorkerPool {
    
    private static Logger logger = Logger.getLogger(RequestWorkerPool.class);
    private ObjectPool pool;
    public ThreadObjectFactory factory;
            
    public RequestWorkerPool(ObjectPoolConfig opConfig) {
    	
        BasicObjectPool.Config config = new BasicObjectPool.Config();
        config.maxActive = opConfig.getMaxActive();
        config.maxIdle  = opConfig.getMaxIdle();
        factory = new ThreadObjectFactory(this);
        pool = new BasicObjectPool(factory, config);
    }

    public synchronized void addClient(ThreadPoolClient threadPoolClient) {
        RequestWorkerThread ct = null;
        try {
            ct = (RequestWorkerThread)pool.borrowObject();
            ct.setThreadPoolClient(threadPoolClient);
            if(ct.isAlive()==false) {
                ct.start();
                wait(1000); //just in case
                Thread.yield();
            } else {
                synchronized(ct) {
                    ct.notify();
                }
            }
        } catch(Exception e) {
            logger.warn("Error in addClient: "+e);
            try {
                if(ct!=null) pool.returnObject(ct);
            } catch(Exception er) {
                logger.warn("Error in returning thread: "+er);
            }
        }
    }

    public void returnObject(Object object) {
        try {
            pool.returnObject(object);
        } catch(Exception e) {
            logger.warn("IGONRED:Error while returning object : "+e);
        }
    }

    protected void finalize() throws Throwable {
        try {
            close();
        } catch(Exception e) {
            logger.warn("IGONRED:finalize in pool close : "+e);
        }
        super.finalize();
    }

    public void close() throws Exception {
        pool.close();
    }

    public void clear() throws Exception {
        pool.clear();
    }

    /**
     * Return the number of instances currently borrowed from my pool.
     * @since 1.4.1
     */
    public int getNumActive() {
        return pool.getNumActive();
    }

    /**
     * Return the number of instances currently idle in my pool.
     * @since 1.4.1
     */
    public int getNumIdle() {
        return pool.getNumIdle();
    }

    /**
     * Returns iterator containing all the active
     * threads i.e ClientHandler handling connected clients.
     * @since 1.3.1
     */
    public final Iterator getAllClientThread() {
        return ((BasicObjectPool)pool).getAllActiveObjects();
    }
}
