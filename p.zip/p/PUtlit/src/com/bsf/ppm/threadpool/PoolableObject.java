package com.bsf.ppm.threadpool;

import org.apache.commons.pool.PoolableObjectFactory;

/**
 * Interface to be implemented by any user class of QuickServer
 * so that QuickServer can create a pool of objects and reuse objects
 * from that pool.
 * @since 1.3
 */
public interface PoolableObject {
	/**
	 * Returns  weather or not this Object impelementation 
	 * can be pooled.
	 */
	public boolean isPoolable();

	/**
	 * Will return a  
	 * {@link org.apache.commons.pool.PoolableObjectFactory} object for
	 * this Object implementation if it is poolable
	 * else will return <code>null</code>
	 */
	public PoolableObjectFactory getPoolableObjectFactory();
}
