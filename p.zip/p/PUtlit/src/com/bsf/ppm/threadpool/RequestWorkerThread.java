package com.bsf.ppm.threadpool;

import java.util.HashMap;
import java.util.Map;

import com.bsf.ppm.aspects.LoggingAdvice;

import org.apache.log4j.Logger;


/**
 * Thread to handle processing request worker activities
 * @author Rakesh
 *
 */
public class RequestWorkerThread extends Thread {
	private static final Logger logger = Logger.getLogger(RequestWorkerThread.class);

	private static Map idMap = new HashMap();

	private String name = "RequestWorkerThreadInPool ";

	private RequestWorkerPool pool;

	private ThreadPoolClient threadPoolClient;

	private int id;

	protected volatile char state = 'U';

	public RequestWorkerThread(RequestWorkerPool pool) {
		this(pool, -1);
	}

	static class InstanceId {
		private int id = 0;

		public int getNextId() {
			return ++id;
		}
	};

	private static int getNewId(int instanceCount) {
		InstanceId instanceId = (InstanceId) idMap.get("" + instanceCount);
		if (instanceId == null) {
			instanceId = new InstanceId();
			idMap.put("" + instanceCount, instanceId);
		}
		return instanceId.getNextId();
	}

	public RequestWorkerThread(RequestWorkerPool pool, int instanceCount) {
		id = getNewId(instanceCount);
		name = name + instanceCount + " (ID=" + id + ")";
		this.pool = pool;
		setName(name);
	}

	public long getId() {
		return id;
	}

	public void run() {
		state = 'S';
		synchronized (pool) {
			pool.notify();
		}
		state = 'L';
		while (true) {
			if (threadPoolClient == null) {
				logger.info("RequestWorkerThread returned a null handler.. Ok");
			} else {
				logger.debug("Running handler using thread: " + getName());
				state = 'R';
				threadPoolClient.runInThread();
				state = 'I';
				logger.debug("Client returned the thread: " + getName());
				threadPoolClient=null;
				if (pool == null) {
					logger.info("Could not returning client thread "
							+ getName() + ", pool was null!");
					state = 'D';
					break;
				}
			}
			logger.debug("Returning client thread to pool: " + getName());
			state = 'P';
			pool.returnObject(RequestWorkerThread.this);
			synchronized (this) {
				try {
					state = 'W';
					wait();
					state = 'L';
				} catch (Exception e) {
					state = 'D';
					logger.info("Closing thread "
							+ Thread.currentThread().getName()
							+ " since interrupted.");
					break;
				}
			}
		}// end while
	}

	
	public ThreadPoolClient getThreadPoolClient() {
		return threadPoolClient;
	}

	public void setThreadPoolClient(ThreadPoolClient threadPoolClient) {
		this.threadPoolClient = threadPoolClient;
	}

	public String toString() {
		return super.toString() + " - " + state + " - worker " + threadPoolClient;
	}

}
