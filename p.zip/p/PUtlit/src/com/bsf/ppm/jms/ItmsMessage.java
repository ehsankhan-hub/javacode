package com.bsf.ppm.jms;

public interface ItmsMessage extends IppMessage {

}
