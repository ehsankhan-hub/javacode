package com.bsf.ppm.jms;

import java.io.Serializable;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bsf.ppm.exceptions.DAOException;

/**
 * @author Administrator
 */
@Transactional(rollbackFor=DAOException.class)
public class JmsSender implements  IJmsSender{
	private static Log log = LogFactory.getLog(JmsSender.class);

	private JmsTemplate jmsTemplate;

	/**
	 * @return Returns the jmsTemplate.
	 */
	public JmsTemplate getJmsTemplate() {
		return jmsTemplate;
	}

	/**
	 * @param jmsTemplate
	 *            The jmsTemplate to set.
	 */
	public void setJmsTemplate(JmsTemplate jmsTemplate) {
		this.jmsTemplate = jmsTemplate;
	}
	@Transactional(propagation = Propagation.REQUIRED)
	public void sendMessage(String queueName, final Serializable messageData) {
		sendMessage(queueName, messageData, null);
	}
	@Transactional(propagation = Propagation.REQUIRED)
	public void sendMessage(String queueName, final Serializable messageData,
			final Map<String, String> headerData) {
		jmsTemplate.send(queueName, new MessageCreator() {
			public Message createMessage(Session session) throws JMSException {
				log.debug("Creating the message from message data");
				ObjectMessage objectMessage = session.createObjectMessage();
				objectMessage.setObject(messageData);
				if (headerData != null && headerData.size() > 0) {
					String[] keyArray = headerData.keySet().toArray(
							new String[0]);
					// objectMessage.sets
					for (String key : keyArray) {
						// objectMessage.setStringProperty(iterator,
						// headerData.get(iterator));
						objectMessage.setStringProperty(key, headerData
								.get(key));
					}
				}
				return objectMessage;
			}
		});
	}
}
