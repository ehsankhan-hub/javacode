package com.bsf.ppm.jms;

import com.bsf.ppm.constants.IConstants;


/**
 * Class to hold the information about entity where the message is available.
 * @author Rakesh
 *
 */
public class ItmsMessageData implements ItmsMessage {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4811445271580388847L;
	private String entityName;
	private Long entityId;
	private Long applicationId;
	private String messageType;
	private String eftmessageType;
	private String uti;
	
	
	//private Long processsInstanceId;
	
	/**
	 * @return the uti
	 */
	public String getUti() {
		return uti;
	}
	/**
	 * @param uti the uti to set
	 */
	public void setUti(String uti) {
		this.uti = uti;
	}
	public String getEftmessageType() {
		return eftmessageType;
	}
	public void setEftmessageType(String eftmessageType) {
		this.eftmessageType = eftmessageType;
	}
	/**
	 * @return the messageType
	 */
	public String getMessageType() {
		return messageType;
	}
	/**
	 * @param messageType the messageType to set
	 */
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	/**
	 * @return the domainEntityName
	 */
	public String getEntityName() {
		return entityName;
	}
	/**
	 * @param domainEntityName the domainEntityName to set
	 */
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	/**
	 * @return the domainEntityId
	 */
	public Long getEntityId() {
		return entityId;
	}
	/**
	 * @param domainEntityId the domainEntityId to set
	 */
	public void setEntityId(Long entityId) {
		this.entityId = entityId;
	}


	/**
	 * @return the applicationId
	 */
	public Long getApplicationId() {
		return applicationId;
	}
	/**
	 * @param applicationId the applicationId to set
	 */
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	public String toString(){
		return "Message Data=[ApplicationId="+IConstants.MODULE_NAME.values()[applicationId.intValue()].name()+",EntityId="+entityId+",EntityName="+entityName+"]";
	}

	
}
