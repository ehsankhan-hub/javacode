package com.bsf.ppm.jms;

import java.io.Serializable;

public interface IppMessage extends Serializable {

}
