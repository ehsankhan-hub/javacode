package com.bsf.ppm.jms;

import java.io.Serializable;
import java.util.Map;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.naming.InitialContext;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class JmsSenderImpl2 implements IJmsSender {
	@Transactional(propagation = Propagation.MANDATORY)
	public void sendMessage(String queueName, Serializable messageData) {
		sendMessage(queueName, messageData, null);
	}
	@Transactional(propagation = Propagation.MANDATORY)
	public void sendMessage1(String queueName, Serializable messageData,
			Map<String, String> headerData) throws Exception {

		/*InitialContext ctx = new InitialContext();
		QueueConnectionFactory qcf = (QueueConnectionFactory) ctx.lookup("java:/JmsXA");
		Queue queue = (Queue) ctx.lookup("queue/" + queueName);
        QueueConnection queueConnection= qcf.createQueueConnection();
		QueueSession queueSession = queueConnection.createQueueSession(true,
                Session.SESSION_TRANSACTED);
        QueueSender queueSender = queueSession.createSender(queue);
        queueConnection.start();

        ObjectMessage objectMessage = queueSession.createObjectMessage();
		objectMessage.setObject(messageData);
		if (headerData != null && headerData.size() > 0) {
			String[] keyArray = headerData.keySet().toArray(
					new String[0]);
			// objectMessage.sets
			for (String key : keyArray) {
				// objectMessage.setStringProperty(iterator,
				// headerData.get(iterator));
				objectMessage.setStringProperty(key, headerData
						.get(key));
			}
		}

		queueSender.send(objectMessage);
		queueSender.close();
        queueConnection.close();*/

	}

	@Transactional(propagation = Propagation.MANDATORY)
	public void sendMessage(String queueName, Serializable messageData,
			Map<String, String> headerData) {
		
		try {
			sendMessage1(queueName,messageData,headerData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
