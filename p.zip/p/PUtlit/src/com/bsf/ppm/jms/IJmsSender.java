package com.bsf.ppm.jms;

import java.io.Serializable;
import java.util.Map;


public interface IJmsSender {
	public void sendMessage(String queueName, final Serializable messageData);

	public void sendMessage(String queueName, final Serializable messageData,
			final Map<String, String> headerData);
}
