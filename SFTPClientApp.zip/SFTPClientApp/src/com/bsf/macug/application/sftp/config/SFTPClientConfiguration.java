package com.bsf.macug.application.sftp.config;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.bsf.macug.application.sftp.config.dto.SFTPConnectionParameterDTO;
import com.bsf.macug.application.sftp.config.dto.SFTPFileInfoDTO;
import com.bsf.macug.application.sftp.excetion.SFTChannelOpenException;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.SftpException;

public class SFTPClientConfiguration {

	private static final Logger logger = LogManager.getLogger(SFTPClientConfiguration.class);

	public SFTPFileInfoDTO moveFile(SFTPFileInfoDTO fileInfoDTO, SFTPConnectionParameterDTO connectionDTO,
			Properties prop) {
		fileInfoDTO.setArchiveStatus(false);
		try {
			connectionDTO.getSftpChannel().rename(fileInfoDTO.getDependentRemoteFile(),
					fileInfoDTO.getDependentRemoteArchivePath());
			logger.info("Moved file from " + fileInfoDTO.getDependentRemoteFile() + " to "
					+ fileInfoDTO.getDependentRemoteArchivePath());
			connectionDTO.getSftpChannel().rename(fileInfoDTO.getRemotePath(), fileInfoDTO.getRemoteArchivePath());
			logger.info("Moved file from " + fileInfoDTO.getRemotePath() + " to " + fileInfoDTO.getRemoteArchivePath());
			fileInfoDTO.setArchiveStatus(true);
		} catch (SftpException e) {
			logger.error("SFTP error occured while moving file. Error " + e.getMessage(), e);
		} catch (Exception e) {
			logger.error("Error occured while moving file. Error " + e.getMessage(), e);
		}
		return fileInfoDTO;
	}

	public SFTPFileInfoDTO downloadFile(SFTPFileInfoDTO fileInfoDTO, SFTPConnectionParameterDTO connectionDTO,
			Properties prop) {
		fileInfoDTO.setDownloadStatus(false);
		try {
			if (fileInfoDTO.getDependentRemoteFile() != null) {
				connectionDTO.getSftpChannel().get(fileInfoDTO.getDependentRemoteFile(),
						fileInfoDTO.getDependentLocalFile());
				logger.info(
						fileInfoDTO.getDependentRemoteFile() + " downloaded to " + fileInfoDTO.getDependentLocalFile());
				connectionDTO.getSftpChannel().get(fileInfoDTO.getRemotePath(), fileInfoDTO.getLocalPath());
				logger.info(fileInfoDTO.getRemotePath() + " downloaded to " + fileInfoDTO.getLocalPath());
				fileInfoDTO.setDownloadStatus(true);
			} else {
				logger.error("File is not set for download, dependent file is " + fileInfoDTO.getDependentRemoteFile());
			}
		} catch (SftpException e) {
			fileInfoDTO.setDownloadStatus(false);
			logger.error("SFTP Error in downloading file. Error " + e.getMessage(), e);
		} catch (Exception e) {
			fileInfoDTO.setDownloadStatus(false);
			logger.error("Error in downloading file. Error " + e.getMessage(), e);
		}
		return fileInfoDTO;
	}

	public boolean uploadFile(String fileName, String localFile, String remotePath,
			SFTPConnectionParameterDTO connectionDTO, Properties prop) {
		boolean blStatus = false;
		FileInputStream finUpload = null;
		try {
			File flocal = new File(localFile);
			finUpload = new FileInputStream(flocal);
			connectionDTO.getSftpChannel().put(finUpload, remotePath);
			int chmodInt = Integer.parseInt("777", 8);
			connectionDTO.getSftpChannel().chmod(chmodInt, remotePath);
			blStatus = true;
		} catch (SftpException e) {
			blStatus = false;
			logger.error("SFTP Error in uploading file. Error " + e.getMessage(), e);
		} catch (Exception e) {
			logger.error("Error in uploading file. Error " + e.getMessage(), e);
			blStatus = false;
		} finally {
			if (finUpload != null) {
				try {
					finUpload.close();
				} catch (Exception clEx) {
					logger.error("Error in closing file input stream. Error " + clEx.getMessage(), clEx);
				}
			}
		}
		return blStatus;
	}
	
	public boolean uploadTuxedoFile(String fileName, String localFile, String remotePath,
			SFTPConnectionParameterDTO connectionDTO, Properties prop) {
		boolean blStatus = false;
		FileInputStream finUpload = null;
		try {
			File flocal = new File(localFile);
			finUpload = new FileInputStream(flocal);
			connectionDTO.getSftpChannel().put(finUpload, remotePath);
			//int chmodInt = Integer.parseInt("777", 8);
			//connectionDTO.getSftpChannel().chmod(chmodInt, remotePath);
			blStatus = true;
		} catch (SftpException e) {
			blStatus = false;
			logger.error("SFTP Error in uploading file. Error " + e.getMessage(), e);
		} catch (Exception e) {
			logger.error("Error in uploading file. Error " + e.getMessage(), e);
			blStatus = false;
		} finally {
			if (finUpload != null) {
				try {
					finUpload.close();
				} catch (Exception clEx) {
					logger.error("Error in closing file input stream. Error " + clEx.getMessage(), clEx);
				}
			}
		}
		return blStatus;
	}

	public List<SFTPFileInfoDTO> fetchAllRemoteFiles(SFTPFileInfoDTO fileInfoDTO, Properties prop) {
		List<SFTPFileInfoDTO> lstFileInfo = null;
		SFTPClientConnectionManager connectionManager = new SFTPClientConnectionManager();
		SFTPConnectionParameterDTO connectionDTO = null;
		try {
			String dependentFileExt = fileInfoDTO.getDependentExt();
			connectionDTO = connectionManager.openSFTPChannel(prop);
			logger.info("Channel opened for SFTP listing files");
			connectionDTO.getSftpChannel().cd(fileInfoDTO.getRemoteFolder());
			logger.info("Changed to remote directory " + fileInfoDTO.getRemoteFolder());
			Vector lstFiles = connectionDTO.getSftpChannel().ls(fileInfoDTO.getRemoteFolder());
			if (lstFiles != null) {
				lstFileInfo = new ArrayList<SFTPFileInfoDTO>();
				logger.info("List of files inside the remote directory is " + lstFileInfo.size());
			}
			DateFormat format = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
			String strArchiveFolder = fileInfoDTO.getRemoteArchivePath();
			String strDestinationFolder = fileInfoDTO.getDestination();
			for (Object objFile : lstFiles) {
				try {
					SFTPFileInfoDTO remoteFileInfoDTO = new SFTPFileInfoDTO(fileInfoDTO);
					LsEntry lsEntryFile = (LsEntry) objFile;
					if (!lsEntryFile.getAttrs().isDir()) {
						String strMTTime = lsEntryFile.getAttrs().getMtimeString();
						Date dtFileDate = format.parse(strMTTime);
						if (!checkCurrentDay(dtFileDate)) {
							continue;
						}
						String filename = lsEntryFile.getFilename();
						if (filename.equals(".") || filename.equals("..")) {
							continue;
						}
						if (!checkfileExtAllowed(filename, remoteFileInfoDTO.getFileFilter()))
							continue;
						if (!checkFileNameAllowed(filename, remoteFileInfoDTO.getStartWith()))
							continue;
						logger.info("Found file " + filename);
						String strFullPath = remoteFileInfoDTO.getRemoteFolder() + filename;
						String strArchivePath = strArchiveFolder + filename;
						remoteFileInfoDTO.setFileName(filename);
						remoteFileInfoDTO.setRemotePath(strFullPath);
						remoteFileInfoDTO.setRemoteArchivePath(strArchivePath);
						remoteFileInfoDTO.setDestinationFilePath(strDestinationFolder + filename);
						if (dependentFileExt != null) {
							remoteFileInfoDTO = getDependentFileName(dependentFileExt, strArchiveFolder,
									strDestinationFolder, remoteFileInfoDTO);
						}
						logger.info("Dependent path, Archive path and destination path set for the found file");
						lstFileInfo.add(remoteFileInfoDTO);
					}
				} catch (Exception e) {
					logger.error("Error in fetching remote files. Error " + e.getMessage(), e);
				}
			}
		} catch (SFTChannelOpenException e) {
			logger.error("Error in opening SFTP channel for listing files. Error " + e.getMessage(), e);
		} catch (SftpException e) {
			logger.error("SFTP error occured for listing files. Error " + e.getMessage(), e);
		} catch (Exception e) {
			logger.error("Error occured in listing files. Error " + e.getMessage(), e);
		} finally {
			connectionManager.closeOpenedConnection(connectionDTO);
		}
		return lstFileInfo;
	}

	private boolean checkFileNameAllowed(String filename, String startWith) {
		if (startWith.contains(",")) {
			String[] arrFileStarts = startWith.split(",");
			if (arrFileStarts != null) {
				for (String fileStart : arrFileStarts) {
					if (filename.startsWith(fileStart)) {
						return true;
					}
				}
			}
		} else if (filename.startsWith(startWith))
			return true;
		return false;
	}

	private SFTPFileInfoDTO getDependentFileName(String dependentFileExt, String strArchiveFolder,
			String strDestinationFolder, SFTPFileInfoDTO fileInfoDTO) {
		String strFileNameWithOutext = fileInfoDTO.getFileName().substring(0,
				fileInfoDTO.getFileName().lastIndexOf("."));
		String dependentFile = fileInfoDTO.getRemoteFolder() + strFileNameWithOutext + "." + dependentFileExt;
		String dependentArchiveFile = strArchiveFolder + strFileNameWithOutext + "." + dependentFileExt;
		String strLocalFile = fileInfoDTO.getLocalPath() + "/" + strFileNameWithOutext + "." + dependentFileExt;
		String strDestination = strDestinationFolder + strFileNameWithOutext + "." + dependentFileExt;
		fileInfoDTO.setDependentRemoteFile(dependentFile);
		fileInfoDTO.setDependentLocalFile(strLocalFile);
		fileInfoDTO.setDependentRemoteArchivePath(dependentArchiveFile);
		fileInfoDTO.setDetsinationDependentPath(strDestination);
		return fileInfoDTO;
	}

	private boolean checkCurrentDay(Date dtFileDate) {
		DateFormat dfToday = new SimpleDateFormat("yyyy-MM-dd");
		String strToday = dfToday.format(new Date());
		String strFileDate = dfToday.format(dtFileDate);
		if (strToday.equals(strFileDate))
			return true;
		return false;
	}

	private boolean checkfileExtAllowed(String filename, String filterExtension) {
		try {
		//	logger.info("File filter extension is " + filterExtension);
			if (filename.contains(".")) {
				String strFileExtension = filename.substring(filename.lastIndexOf("."));
				if (filterExtension != null) {
					if (filterExtension.contains(",")) {
						String[] arrExt = filterExtension.split(",");
						if (arrExt != null) {
							for (String extension : arrExt) {
								if (strFileExtension.contains(extension)) {
									return true;
								}
							}
						}
					} else {
						if (strFileExtension.contains(filterExtension)) {
							return true;
						}
					}
				} else {
					logger.error("File filter extension is empty or null");
				}
			} else {
				logger.error("File name should contain . with extension which is missing for file " + filename);
			}
		} catch (Exception e) {
			logger.error("Error in checking file extension allowed. Error " + e.getMessage(), e);
		}
		return false;
	}

}
