package com.bsf.macug.application.sftp.utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class FileUtils {

	private static final Logger logger = LogManager.getLogger(FileUtils.class);
	
	public List<String> listAllFolder(String folder){
		List<String> lstFolder = null;
		File sourceFolders = new File(folder);
		File[] lstFiles = sourceFolders.listFiles();
		if(lstFiles!=null) {
			lstFolder = new ArrayList<String>();
			for (File sourceFolder : lstFiles) {
				if(sourceFolder.isDirectory()) {
					lstFolder.add(sourceFolder.getAbsolutePath());
				}
			}
		}
		return lstFolder;
	}

	public List<String> listAllFiles(String folder) {
		List<String> lstFileName = null;
		File f = new File(folder);
		File[] lstFiles = f.listFiles();
		if (lstFiles != null) {
			lstFileName = new ArrayList<String>();
			for (File file : lstFiles) {
				if (!file.isDirectory())
					lstFileName.add(file.getName());
			}
		}
		return lstFileName;
	}

	public boolean moveLocalFile(String sourceFile, String destinationFile, String errorFolder, boolean blDependent) {
		boolean blStatus = false;
		try {
			File fDestination = new File(destinationFile);
			if (fDestination.exists()) {
				logger.error(fDestination.getAbsolutePath() + " file already exist, moving to error folder");
				return moveToErrorFolder(sourceFile, errorFolder, blDependent);
			}
			Path sourcePath = Paths.get(sourceFile);
			Path destPath = Paths.get(destinationFile);
			logger.info("Trying to move " + sourceFile + " to " + destinationFile);
			blStatus = moveFile(sourcePath, destPath);
			logger.info("Moving status is " + blStatus);
		} catch (IOException e) {
			logger.error("IO Error occured in moving local file. Error " + e.getMessage(), e);
			return false;
		} catch (Exception e) {
			logger.error("Error occured in moving local file. Error " + e.getMessage(), e);
			return false;
		}
		return blStatus;
	}

	private boolean moveToErrorFolder(String sourceFile, String errorFile, boolean blDependent) {
		boolean blStatus = false;
		DateFormat dfToday = new SimpleDateFormat("yyyyMMddhhmmssSSS");
		errorFile = errorFile + "_ERR_" + dfToday.format(new Date()) + "_" + generateRandom();
		logger.info("Error file path is " + errorFile);
		Path sourcePath = Paths.get(sourceFile);
		Path destPath = Paths.get(errorFile);
		try {
			blStatus = moveFile(sourcePath, destPath);
		} catch (Exception e) {
			logger.error("Error occured in moving file to error folder. Error " + e.getMessage(), e);
			return false;
		}
		return blStatus;
	}

	private String generateRandom() {
		Random randNum = new Random();
		return String.format("%04d", randNum.nextInt(10000));
	}

	private boolean moveFile(Path sourcePath, Path destination) throws IOException {
		Files.move(sourcePath, destination, StandardCopyOption.REPLACE_EXISTING);
		logger.info("Local file " + sourcePath + " moved to " + destination);
		return true;
	}
}
