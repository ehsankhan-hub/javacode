package com.bsf.macug.application.sftp.config;

import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.bsf.macug.application.sftp.config.dto.SFTPConnectionParameterDTO;
import com.bsf.macug.application.sftp.excetion.SFTChannelOpenException;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class SFTPClientConnectionManager {

	private static final Logger logger = LogManager.getLogger(SFTPClientConnectionManager.class);

	public SFTPConnectionParameterDTO openSFTPChannel(Properties prop) throws SFTChannelOpenException {
		SFTPConnectionParameterDTO connectionDTO = null;
		try {
			String remoteHost = prop.getProperty("remote.host");
			String remoteUser = prop.getProperty("remote.user");
			String remotePassword = prop.getProperty("remote.password");
			JSch jsch = new JSch();
			int port = 22;
			logger.info("Trying to create connection with " + remoteHost + " on port " + port);
			Session session = jsch.getSession(remoteUser, remoteHost, port);
			session.setPassword(remotePassword);
			session.setConfig(getSessionProperty());
			session.connect();
			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftpChannel = (ChannelSftp) channel;
			logger.info("Connected to " + remoteHost + " with user info " + session.getUserName());
			connectionDTO = new SFTPConnectionParameterDTO();
			connectionDTO.setSession(session);
			connectionDTO.setSftpChannel(sftpChannel);
			return connectionDTO;
		} catch (Exception e) {
			logger.error("Error in getting SFTP channel. Error " + e.getMessage(), e);
			throw new SFTChannelOpenException();
		}
	}
	
	public SFTPConnectionParameterDTO openTuxedoSFTPChannel(Properties prop) throws SFTChannelOpenException {
		SFTPConnectionParameterDTO connectionDTO = null;
		try {
			String remoteHost = prop.getProperty("remote.tuxedo.hostname");
			String remoteUser = prop.getProperty("remote.tuxedo.username");
			String remotePassword = prop.getProperty("remote.tuxedo.userpassword");
			JSch jsch = new JSch();
			int port = 22;
			logger.info("Trying to create tuxedo connection with " + remoteHost + " on port " + port);
			Session session = jsch.getSession(remoteUser, remoteHost, port);
			session.setPassword(remotePassword);
			session.setConfig(getSessionProperty());
			session.connect();
			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftpChannel = (ChannelSftp) channel;
			logger.info("Connected to " + remoteHost + " with user info " + session.getUserName());
			connectionDTO = new SFTPConnectionParameterDTO();
			connectionDTO.setSession(session);
			connectionDTO.setSftpChannel(sftpChannel);
			return connectionDTO;
		} catch (Exception e) {
			logger.error("Error in getting tuxedo SFTP channel. Error " + e.getMessage(), e);
			throw new SFTChannelOpenException();
		}
	}

	private Properties getSessionProperty() {
		java.util.Properties configProp = new java.util.Properties();
		configProp.put("StrictHostKeyChecking", "no");
		return configProp;
	}

	public void closeOpenedConnection(SFTPConnectionParameterDTO connectionDTO) {
		try {
			if (connectionDTO != null) {
				if (connectionDTO.getSftpChannel() != null) {
					if (!connectionDTO.getSftpChannel().isClosed()) {
						connectionDTO.getSftpChannel().disconnect();
						logger.info("Channel closed");
					}
				}
				if (connectionDTO.getSession() != null) {
					if (connectionDTO.getSession().isConnected()) {
						connectionDTO.getSession().disconnect();
						logger.info("Session closed");
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error in closing session or channel. Error " + e.getMessage(), e);
		}

	}

}
