package com.bsf.macug.application.sftp.payment;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.bsf.macug.application.sftp.config.SFTPClientConfiguration;
import com.bsf.macug.application.sftp.config.SFTPClientConnectionManager;
import com.bsf.macug.application.sftp.config.dto.SFTPConnectionParameterDTO;
import com.bsf.macug.application.sftp.excetion.SFTChannelOpenException;
import com.bsf.macug.application.sftp.utils.FileUtils;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;

public class PaymentFileActUploader implements Runnable {

	private static final Logger logger = LogManager.getLogger(PaymentFileActUploader.class);

	private static Properties properties;

	@Override
	public void run() {
		FileUtils utils = new FileUtils();
		SFTPClientConnectionManager connectionManager = null;
		SFTPConnectionParameterDTO connectionDTO = null;
		String strSource = getProperties().getProperty("local.fileact.source");
		List<String> lstFiles = utils.listAllFiles(strSource);
		if (lstFiles != null) {
			connectionManager = new SFTPClientConnectionManager();
			try {
				String strDestination = getProperties().getProperty("local.fileact.destination");
				String strError = getProperties().getProperty("local.fileact.error");
				SFTPClientConfiguration clientConfiguration = new SFTPClientConfiguration();
				connectionDTO = connectionManager.openSFTPChannel(getProperties());
				ChannelSftp sftpChannel = connectionDTO.getSftpChannel();
				String strRemotePath = getProperties().getProperty("remote.fileact.data");
				sftpChannel.cd(strRemotePath);
				connectionDTO.setSftpChannel(sftpChannel);
				List<String> lstEnvelopes = new ArrayList<String>();
				String strFilterExt = getProperties().getProperty("local.fileact.filter");
				for (String localFile : lstFiles) {
					if (isEnvelopeFile(localFile, strFilterExt)) {
						lstEnvelopes.add(localFile);
						continue;
					}
					String strLocalPath = strSource +File.separator+ localFile;
					String strUploadPath = strRemotePath + localFile;
					if (clientConfiguration.uploadFile(localFile, strLocalPath, strUploadPath, connectionDTO,
							getProperties())) {
						logger.info(localFile + " uploaded successfully");
						FileUtils fileUtils = new FileUtils();
						if (fileUtils.moveLocalFile(strLocalPath, strDestination + "/" + localFile,
								strError + localFile, false)) {
							logger.info("File moved successfully.");
						} else {
							logger.error("File failed to move.");
						}
					}
				}
				sftpChannel = connectionDTO.getSftpChannel();
				strRemotePath = getProperties().getProperty("remote.fileact.envelope");
				sftpChannel.cd(strRemotePath);
				connectionDTO.setSftpChannel(sftpChannel);
				for (String envelop : lstEnvelopes) {
					String strLocalPath = strSource + "/" + envelop;
					String strUploadPath = strRemotePath + envelop;
					if (clientConfiguration.uploadFile(envelop, strLocalPath, strUploadPath, connectionDTO,
							getProperties())) {
						logger.info(envelop + " uploaded successfully");
						FileUtils fileUtils = new FileUtils();
						if (fileUtils.moveLocalFile(strLocalPath, strDestination + "/" + envelop, strError + envelop,
								false)) {
							logger.info("File moved successfully.");
						} else {
							logger.error("File failed to move.");
						}
					}
				}
			} catch (SFTChannelOpenException e) {
				logger.error("Error in SFTP channel of upload. Error " + e.getMessage(), e);
			} catch (SftpException e) {
				logger.error("Error in SFTP of upload. Error " + e.getMessage(), e);
			} catch (Exception e) {
				logger.error("Error in upload. Error " + e.getMessage(), e);
			} finally {
				connectionManager.closeOpenedConnection(connectionDTO);
			}

		}

	}

	private boolean isEnvelopeFile(String localFile, String filterExt) {
		if (filterExt != null) {
			if (filterExt.equals(localFile.substring(localFile.lastIndexOf(".") + 1)))
				return true;
		}
		return false;
	}

	public static Properties getProperties() {
		return properties;
	}

	public static void setProperties(Properties properties) {
		PaymentFileActUploader.properties = properties;
	}

}
