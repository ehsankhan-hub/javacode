package com.bsf.macug.application.sftp.service;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.bsf.macug.application.sftp.payment.PaymentFileActDownloader;
import com.bsf.macug.application.sftp.payment.PaymentFileActUploader;
import com.bsf.macug.application.sftp.payment.PaymentFinDownloader;
import com.bsf.macug.application.sftp.payment.PaymentFinUploader;
import com.bsf.macug.application.sftp.payment.PayrollFileActDownloader;
import com.bsf.macug.application.sftp.statement.StatementUploader;

public class SFTPService {

	private static final Logger logger = LogManager.getLogger(SFTPService.class);

	public void startSFTPService() {
		try {
			Properties prop = readProperties();
			prop = createTodayFolders(prop);
			PaymentFinDownloader.setProperties(prop);
			PaymentFileActDownloader.setProperties(prop);
			PayrollFileActDownloader.setProperties(prop);
			PaymentFileActUploader.setProperties(prop);
			PaymentFinUploader.setProperties(prop);
			StatementUploader.setProperties(prop);
			Thread thPaymentFin = new Thread(new PaymentFinDownloader());
			Thread thPaymentFileAct = new Thread(new PaymentFileActDownloader());
			Thread thPayrollFileAct = new Thread(new PayrollFileActDownloader());
			Thread thFileActUpload = new Thread(new PaymentFileActUploader());
			Thread thFinUpload = new Thread(new PaymentFinUploader());
			Thread thStatementUpload = new Thread(new StatementUploader());
			thPayrollFileAct.start();
			thPaymentFin.start();
			thPaymentFileAct.start();
			thFileActUpload.start();
			thStatementUpload.start();
			thFinUpload.start();
		} catch (Exception e) {
			logger.error("Error in starting sftp client. Error " + e.getMessage(), e);
		}
	}

	private Properties createTodayFolders(Properties prop) {
		String localPath = prop.getProperty("local.fileact.payment");
		DateFormat dfToday = new SimpleDateFormat("yyyy-MM-dd");
		File flocalPath = new File(localPath + dfToday.format(new Date()));
		if (flocalPath.mkdirs())
			logger.info("FileAct folder created on path " + flocalPath.getAbsolutePath());
		prop.put("local.fileact.payment", flocalPath.getAbsolutePath());
		localPath = prop.getProperty("local.fin.payment");
		flocalPath = new File(localPath + dfToday.format(new Date()));
		if (flocalPath.mkdirs())
			logger.info("Fin folder created on path " + flocalPath.getAbsolutePath());
		prop.put("local.fin.payment", flocalPath.getAbsolutePath());
		localPath = prop.getProperty("local.fileact.payroll");
		flocalPath = new File(localPath + dfToday.format(new Date()));
		if (flocalPath.mkdirs())
			logger.info("Fileact payroll folder created on path " + flocalPath.getAbsolutePath());
		prop.put("local.fileact.payroll", flocalPath.getAbsolutePath());
		localPath = prop.getProperty("local.fileact.source");
		flocalPath = new File(localPath);
		if (flocalPath.mkdirs())
			logger.info("Fileact payroll folder created on path " + flocalPath.getAbsolutePath());
		prop.put("local.fileact.source", flocalPath.getAbsolutePath());
		localPath = prop.getProperty("local.fileact.destination");
		flocalPath = new File(localPath + dfToday.format(new Date()));
		if (flocalPath.mkdirs())
			logger.info("Fileact payroll folder created on path " + flocalPath.getAbsolutePath());
		prop.put("local.fileact.destination", flocalPath.getAbsolutePath());
		return prop;
	}

	private Properties readProperties() throws IOException {
		FileReader reader = new FileReader("D:/macug/sftp/resources/sftp.properties");
		Properties prop = new Properties();
		prop.load(reader);
		return prop;
	}

}
