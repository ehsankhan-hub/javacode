package com.bsf.macug.application.sftp.payment;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.bsf.macug.application.sftp.config.SFTPClientConfiguration;
import com.bsf.macug.application.sftp.config.SFTPClientConnectionManager;
import com.bsf.macug.application.sftp.config.dto.SFTPConnectionParameterDTO;
import com.bsf.macug.application.sftp.excetion.SFTChannelOpenException;
import com.bsf.macug.application.sftp.utils.FileUtils;

public class PaymentFinUploader implements Runnable {

	private static final Logger logger = LogManager.getLogger(PaymentFinUploader.class);

	private static Properties properties;

	@Override
	public void run() {
		try {
			FileUtils utils = new FileUtils();
			SFTPClientConnectionManager connectionManager = null;
			SFTPConnectionParameterDTO connectionDTO = null;
			String strSource = getProperties().getProperty("local.fin.response.source");
			String strBackup = getProperties().getProperty("local.fin.response.destination");
			String strError = getProperties().getProperty("local.fin.response.error");
			String strRemotePath = getProperties().getProperty("remote.fin.response.data");
			strBackup = createTodayFolder(strBackup);
			strError = createTodayFolder(strError);
			logger.info("Trying to fecth all fin upload customer folders from the path "+strSource);
			List<String> lstCustomerFolder = utils.listAllFolder(strSource);
			if (lstCustomerFolder != null) {
				try {
					connectionManager = new SFTPClientConnectionManager();
					connectionDTO = connectionManager.openTuxedoSFTPChannel(getProperties());
					SFTPClientConfiguration clientConfiguration = new SFTPClientConfiguration();
					for (String customerFolder : lstCustomerFolder) {
						try {
							mt199Processor(customerFolder, strBackup, strError, strRemotePath, connectionDTO,
									clientConfiguration, utils);
						} catch (Exception e) {
							logger.error("Error in uploading fin files from folder " + customerFolder + ". Error "
									+ e.getMessage(), e);
						}
					}
				} catch (SFTChannelOpenException e) {
					logger.error("Error in SFTP open channel/connection" + e.getMessage(), e);
				} catch (Exception e) {
					logger.error("Error " + e.getMessage(), e);
				} finally {
					connectionManager.closeOpenedConnection(connectionDTO);
				}
			}
		} catch (Exception e) {
			logger.error("Error in statement uploading. Error " + e.getMessage(), e);
		}
	}

	private void mt199Processor(String customerFolder, String strBackup, String strError, String strRemotePath,
			SFTPConnectionParameterDTO connectionDTO, SFTPClientConfiguration clientConfiguration, FileUtils utils) {

		File companyFolder = new File(customerFolder);
		strBackup = createCompanyFolder(strBackup, companyFolder.getName());
		strError = createCompanyFolder(strError, companyFolder.getName());
		File[] lstFiles = companyFolder.listFiles();
		if (lstFiles != null) {
			if (lstFiles.length > 0) {
				for (File statementFile : lstFiles) {
					try {
						if (statementFile.isFile()) {
							String strRemoteFilePath = strRemotePath + statementFile.getName();
							String strBackupFilePath = strBackup + statementFile.getName();
							String strErrorFilePath = strError + statementFile.getName();
							logger.info("Trying to upload file " + statementFile.getName() + " to remote path "
									+ strRemoteFilePath);
							if (clientConfiguration.uploadTuxedoFile(statementFile.getName(),
									statementFile.getAbsolutePath(), strRemoteFilePath, connectionDTO,
									getProperties())) {
								utils.moveLocalFile(statementFile.getAbsolutePath(), strBackupFilePath,
										strErrorFilePath, false);
							}
						}
					} catch (Exception e) {
						logger.error("Error in moving statement file . Error " + e.getMessage(), e);
						moveToErrorFolder(statementFile, strError);
					}
				}
			}
		}

	}

	private void moveToErrorFolder(File statementFile, String strError) {
		try {
			DateFormat dfToday = new SimpleDateFormat("yyMMdd_hhmmssSSS");
			Random randNum = new Random();
			String strErrorFilePath = strError + statementFile.getName() + dfToday.format(new Date()) + " -"
					+ String.format("%04d", randNum.nextInt(10000));
			Path sourcePath = Paths.get(statementFile.getAbsolutePath());
			Path destination = Paths.get(strErrorFilePath);
			Files.move(sourcePath, destination, StandardCopyOption.REPLACE_EXISTING);
		} catch (Exception e) {
			logger.error("Error in moving file to error folder. Error " + e.getMessage(), e);
		}

	}

	private String createCompanyFolder(String strPath, String customerFolderName) {
		strPath = strPath + customerFolderName + "/";
		File customerFolder = new File(strPath);
		if (!customerFolder.exists()) {
			customerFolder.mkdirs();
		}
		return strPath;
	}

	private String createTodayFolder(String strPath) {
		DateFormat dfToday = new SimpleDateFormat("yyyy-MM-dd");
		strPath = strPath + dfToday.format(new Date()) + "/";
		File path = new File(strPath);
		if (!path.exists())
			path.mkdirs();
		return strPath;
	}

	public static Properties getProperties() {
		return properties;
	}

	public static void setProperties(Properties properties) {
		PaymentFinUploader.properties = properties;
	}
}
