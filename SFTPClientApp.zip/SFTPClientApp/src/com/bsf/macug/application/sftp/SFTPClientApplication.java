package com.bsf.macug.application.sftp;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.bsf.macug.application.sftp.service.SFTPService;

public class SFTPClientApplication {

	private static final Logger logger = LogManager.getLogger(SFTPClientApplication.class);

	public static void main(String args[]) {
		logger.info("MACUG SFTP aplication started");
		SFTPService service = new SFTPService();
		service.startSFTPService();
	}

}
