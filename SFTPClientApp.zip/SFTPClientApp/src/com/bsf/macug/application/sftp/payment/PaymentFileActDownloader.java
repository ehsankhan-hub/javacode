package com.bsf.macug.application.sftp.payment;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.bsf.macug.application.sftp.config.SFTPClientConfiguration;
import com.bsf.macug.application.sftp.config.SFTPClientConnectionManager;
import com.bsf.macug.application.sftp.config.dto.SFTPConnectionParameterDTO;
import com.bsf.macug.application.sftp.config.dto.SFTPFileInfoDTO;
import com.bsf.macug.application.sftp.excetion.SFTChannelOpenException;
import com.bsf.macug.application.sftp.utils.FileUtils;

public class PaymentFileActDownloader implements Runnable {

	private static final Logger logger = LogManager.getLogger(PaymentFileActDownloader.class);

	private static Properties properties;

	@Override
	public void run() {
		SFTPClientConnectionManager connectionManager = null;
		SFTPConnectionParameterDTO connectionDTO = null;
		try {
			SFTPClientConfiguration clientConfiguration = new SFTPClientConfiguration();
			SFTPFileInfoDTO fileInfoDTO = getFileDetails(getProperties());
			logger.info("Fetching all files from remote server");
			List<SFTPFileInfoDTO> lstFileInfoDTO = clientConfiguration.fetchAllRemoteFiles(fileInfoDTO,
					getProperties());
			connectionManager = new SFTPClientConnectionManager();
			if (lstFileInfoDTO != null) {
				if (lstFileInfoDTO.size() > 0) {
					connectionDTO = connectionManager.openSFTPChannel(getProperties());
					for (SFTPFileInfoDTO sftpFileInfoDTO : lstFileInfoDTO) {
						sftpFileInfoDTO = clientConfiguration.downloadFile(sftpFileInfoDTO, connectionDTO,
								getProperties());
						if (sftpFileInfoDTO.isDownloadStatus()) {
							sftpFileInfoDTO = clientConfiguration.moveFile(sftpFileInfoDTO, connectionDTO,
									getProperties());
							if (sftpFileInfoDTO.isArchiveStatus()) {
								logger.info("FileAct payment file archived successfully");
							}
						}
					}
					String sourcePath = fileInfoDTO.getLocalPath();
					String strDestination = fileInfoDTO.getDestination();
					String strLocalErrorFile = fileInfoDTO.getLocalerrorPath();
					FileUtils fileUtils = new FileUtils();
					List<String> lstSourceFiles = fileUtils.listAllFiles(sourcePath);
					List<String> lstCTLFiles = null;
					if (lstSourceFiles != null) {
						lstCTLFiles = new ArrayList<String>();
						for (String filePath : lstSourceFiles) {
							try {
								if (getProperties().getProperty("local.fileact.payment.filter")
										.equals(filePath.substring(filePath.lastIndexOf(".") + 1))) {
									lstCTLFiles.add(filePath);
									continue;
								}
								fileUtils.moveLocalFile(sourcePath + "/" + filePath, strDestination + filePath,
										strLocalErrorFile, false);
								logger.info("Local fileact payment moved successfully");
							} catch (Exception e) {
								logger.error("Error in moving local file . Error " + e.getMessage(), e);
							}
						}
					}
					if (lstCTLFiles != null) {
						for (String ctlFile : lstCTLFiles) {
							try {
								fileUtils.moveLocalFile(sourcePath + "/" + ctlFile, strDestination + ctlFile,
										strLocalErrorFile, false);
							} catch (Exception e) {
								logger.error("Error in moving fileact payment ctl file. Error " + e.getMessage(), e);
							}
						}
					}
				}
			}
		} catch (SFTChannelOpenException e) {
			logger.error("SFTP Channel error in payment fileact file. Error " + e.getMessage(), e);
		} catch (Exception e) {
			logger.error("SFTP error in payment fileact file. Error " + e.getMessage(), e);
		} finally {
			connectionManager.closeOpenedConnection(connectionDTO);
		}

	}

	private SFTPFileInfoDTO getFileDetails(Properties properties2) {
		// DateFormat dfToday = new SimpleDateFormat("yyyy-MM-dd");
		String strRemotePath = getProperties().getProperty("remote.fileact.payment");
		String strLocalPath = getProperties().getProperty("local.fileact.payment");
		String strErrorPath = getProperties().getProperty("local.fileact.payment.error");
		String strFilter = getProperties().getProperty("local.fileact.payment.filter");
		String strDestination = getProperties().getProperty("local.fileact.payment.destination");
		String strDependentExt = getProperties().getProperty("local.fileact.payment.dependentExt");
		String strFileStart = getProperties().getProperty("local.fileact.payment.fileNameStart");
		String strRemoteArchive = getProperties().getProperty("remote.fileact.payment.archive");
		SFTPFileInfoDTO fileInfoDTO = new SFTPFileInfoDTO();
		fileInfoDTO.setRemoteFolder(strRemotePath);
		fileInfoDTO.setLocalPath(strLocalPath);
		fileInfoDTO.setFileFilter(strFilter);
		fileInfoDTO.setLocalerrorPath(strErrorPath);
		fileInfoDTO.setDestination(strDestination);
		fileInfoDTO.setDependentExt(strDependentExt);
		fileInfoDTO.setStartWith(strFileStart);
		fileInfoDTO.setRemoteArchivePath(strRemoteArchive);
		logger.info("SFTP file informations for FIN download are " + fileInfoDTO.toString());
		return fileInfoDTO;
	}

	public static Properties getProperties() {
		return properties;
	}

	public static void setProperties(Properties properties) {
		PaymentFileActDownloader.properties = properties;
	}

}
