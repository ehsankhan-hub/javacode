package com.bsf.macug.application.sftp;

import java.util.Properties;
import java.util.Vector;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.ChannelSftp.LsEntry;

public class SFTPMover {

	/*public static void main(String[] args) {
		String remoteHost = "stelink2";
		String remoteUser = "itms1";
		String remotePassword = "Break@123";
		JSch jsch = new JSch();
		int port = 22;
		Session session = null;
		ChannelSftp sftpChannel = null;
		try {
			session = jsch.getSession(remoteUser, remoteHost, port);
			session.setPassword(remotePassword);
			session.setConfig(getSessionProperty());
			session.connect();
			Channel channel = session.openChannel("sftp");
			channel.connect();
			sftpChannel = (ChannelSftp) channel;
			sftpChannel.cd("/steform/FRANSI/fileactout/");
			Vector lstFiles = sftpChannel.ls("/steform/FRANSI/fileactout/");
			for (Object objFile : lstFiles) {
				LsEntry lsEntryFile = (LsEntry) objFile;
				if (!lsEntryFile.getAttrs().isDir()) {
					String filename = lsEntryFile.getFilename();
					if (filename.equals(".") || filename.equals("..")) {
						continue;
					}
					String strFullPath = "/steform/FRANSI/fileactout/" + filename;
					String strArchivePath = "/steform/FRANSI/fileactout/archive/" + filename;
					sftpChannel.rename(strFullPath, strArchivePath);
					System.out.println(strFullPath+" moved to "+strArchivePath);
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			sftpChannel.disconnect();
			session.disconnect();
		}

	}*/

	/*private static Properties getSessionProperty() {
		java.util.Properties configProp = new java.util.Properties();
		configProp.put("StrictHostKeyChecking", "no");
		return configProp;
	}*/

}
