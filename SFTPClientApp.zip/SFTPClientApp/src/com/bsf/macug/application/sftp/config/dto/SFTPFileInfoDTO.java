package com.bsf.macug.application.sftp.config.dto;

public class SFTPFileInfoDTO {

	private String fileName;
	private String startWith;
	private String remoteFolder;
	private String remotePath;
	private String dependentRemoteFile;
	private String dependentLocalFile;
	private String dependentRemoteArchivePath;
	private String dependentExt;
	private String localPath;
	private String localerrorPath;
	private String remoteArchivePath;
	private String destination;
	private String fileFilter;
	private boolean downloadStatus;
	private boolean archiveStatus;
	private boolean moveStatus;
	private String destinationFilePath;
	private String detsinationDependentPath;
	private String uploadFileName;
	private String uploadRemotePath;
	private String uploadLocalPath;
	private boolean uploadStatus;

	public SFTPFileInfoDTO() {
		super();
	}

	public SFTPFileInfoDTO(SFTPFileInfoDTO infoDTO) {
		super();
		this.fileName = infoDTO.getFileName();
		this.startWith = infoDTO.getStartWith();
		this.remoteFolder = infoDTO.getRemoteFolder();
		this.remotePath = infoDTO.getRemotePath();
		this.dependentRemoteFile = infoDTO.getDependentRemoteFile();
		this.dependentLocalFile = infoDTO.getDependentLocalFile();
		this.dependentRemoteArchivePath = infoDTO.getDependentRemoteArchivePath();
		this.dependentExt = infoDTO.getDependentExt();
		this.localPath = infoDTO.getLocalPath();
		this.localerrorPath = infoDTO.getLocalerrorPath();
		this.remoteArchivePath = infoDTO.getRemoteArchivePath();
		this.destination = infoDTO.getDestination();
		this.fileFilter = infoDTO.getFileFilter();
		this.downloadStatus = infoDTO.isDownloadStatus();
		this.archiveStatus = infoDTO.isArchiveStatus();
		this.moveStatus = infoDTO.isMoveStatus();
		this.destinationFilePath = infoDTO.getDestinationFilePath();
		this.detsinationDependentPath = infoDTO.getDetsinationDependentPath();
		this.uploadFileName = infoDTO.getUploadFileName();
		this.uploadRemotePath = infoDTO.getUploadRemotePath();
		this.uploadLocalPath = infoDTO.getUploadLocalPath();
		this.uploadStatus = infoDTO.isUploadStatus();
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getStartWith() {
		return startWith;
	}

	public void setStartWith(String startWith) {
		this.startWith = startWith;
	}

	public String getRemoteFolder() {
		return remoteFolder;
	}

	public void setRemoteFolder(String remoteFolder) {
		this.remoteFolder = remoteFolder;
	}

	public String getRemotePath() {
		return remotePath;
	}

	public void setRemotePath(String remotePath) {
		this.remotePath = remotePath;
	}

	public String getDependentRemoteFile() {
		return dependentRemoteFile;
	}

	public void setDependentRemoteFile(String dependentRemoteFile) {
		this.dependentRemoteFile = dependentRemoteFile;
	}

	public String getDependentLocalFile() {
		return dependentLocalFile;
	}

	public void setDependentLocalFile(String dependentLocalFile) {
		this.dependentLocalFile = dependentLocalFile;
	}

	public String getDependentRemoteArchivePath() {
		return dependentRemoteArchivePath;
	}

	public void setDependentRemoteArchivePath(String dependentRemoteArchivePath) {
		this.dependentRemoteArchivePath = dependentRemoteArchivePath;
	}

	public String getDependentExt() {
		return dependentExt;
	}

	public void setDependentExt(String dependentExt) {
		this.dependentExt = dependentExt;
	}

	public String getLocalPath() {
		return localPath;
	}

	public void setLocalPath(String localPath) {
		this.localPath = localPath;
	}

	public String getLocalerrorPath() {
		return localerrorPath;
	}

	public void setLocalerrorPath(String localerrorPath) {
		this.localerrorPath = localerrorPath;
	}

	public String getRemoteArchivePath() {
		return remoteArchivePath;
	}

	public void setRemoteArchivePath(String remoteArchivePath) {
		this.remoteArchivePath = remoteArchivePath;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getFileFilter() {
		return fileFilter;
	}

	public void setFileFilter(String fileFilter) {
		this.fileFilter = fileFilter;
	}

	public boolean isDownloadStatus() {
		return downloadStatus;
	}

	public void setDownloadStatus(boolean downloadStatus) {
		this.downloadStatus = downloadStatus;
	}

	public boolean isArchiveStatus() {
		return archiveStatus;
	}

	public void setArchiveStatus(boolean archiveStatus) {
		this.archiveStatus = archiveStatus;
	}

	public boolean isMoveStatus() {
		return moveStatus;
	}

	public void setMoveStatus(boolean moveStatus) {
		this.moveStatus = moveStatus;
	}

	public String getDestinationFilePath() {
		return destinationFilePath;
	}

	public void setDestinationFilePath(String destinationFilePath) {
		this.destinationFilePath = destinationFilePath;
	}

	public String getDetsinationDependentPath() {
		return detsinationDependentPath;
	}

	public void setDetsinationDependentPath(String detsinationDependentPath) {
		this.detsinationDependentPath = detsinationDependentPath;
	}

	public String getUploadFileName() {
		return uploadFileName;
	}

	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}

	public String getUploadRemotePath() {
		return uploadRemotePath;
	}

	public void setUploadRemotePath(String uploadRemotePath) {
		this.uploadRemotePath = uploadRemotePath;
	}

	public String getUploadLocalPath() {
		return uploadLocalPath;
	}

	public void setUploadLocalPath(String uploadLocalPath) {
		this.uploadLocalPath = uploadLocalPath;
	}

	public boolean isUploadStatus() {
		return uploadStatus;
	}

	public void setUploadStatus(boolean uploadStatus) {
		this.uploadStatus = uploadStatus;
	}

	@Override
	public String toString() {
		return "SFTPFileInfoDTO [fileName=" + fileName + ", startWith=" + startWith + ", remoteFolder=" + remoteFolder
				+ ", remotePath=" + remotePath + ", dependentRemoteFile=" + dependentRemoteFile
				+ ", dependentLocalFile=" + dependentLocalFile + ", dependentRemoteArchivePath="
				+ dependentRemoteArchivePath + ", dependentExt=" + dependentExt + ", localPath=" + localPath
				+ ", localerrorPath=" + localerrorPath + ", remoteArchivePath=" + remoteArchivePath + ", destination="
				+ destination + ", fileFilter=" + fileFilter + ", downloadStatus=" + downloadStatus + ", archiveStatus="
				+ archiveStatus + ", moveStatus=" + moveStatus + ", destinationFilePath=" + destinationFilePath
				+ ", detsinationDependentPath=" + detsinationDependentPath + ", uploadFileName=" + uploadFileName
				+ ", uploadRemotePath=" + uploadRemotePath + ", uploadLocalPath=" + uploadLocalPath + ", uploadStatus="
				+ uploadStatus + "]";
	}

}
