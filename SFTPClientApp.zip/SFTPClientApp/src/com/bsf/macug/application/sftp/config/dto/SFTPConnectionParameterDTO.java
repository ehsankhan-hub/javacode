package com.bsf.macug.application.sftp.config.dto;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;

public class SFTPConnectionParameterDTO {

	private ChannelSftp sftpChannel;
	private Session session;

	public SFTPConnectionParameterDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ChannelSftp getSftpChannel() {
		return sftpChannel;
	}

	public void setSftpChannel(ChannelSftp sftpChannel) {
		this.sftpChannel = sftpChannel;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

}
